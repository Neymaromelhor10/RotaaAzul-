// ============================================================================
// SERVIÇO DE PAGAMENTOS, COMISSÕES, ESTORNOS, IDEMPOTÊNCIA E CONCILIAÇÃO FINANCEIRA
// Projeto: Ubatuba Mar & Praias — Marketplace de Turismo Náutico (Rota Azul)
// Missões: 02.21 & 02.22 — Infraestrutura Financeira, Correção Adversarial e Integração
// ============================================================================

import {
  AppRole,
  BookingStatusType,
  CommissionModelType,
  FinancialEntryType,
  LedgerStatusType,
  PartnerCommissionModelUI,
  PaymentMethodType,
  PaymentStatusType,
  PricingModelType,
  RequestBookingRefundResponse,
  PAYMENT_METHOD_VALUES,
  PAYMENT_STATUS_VALUES,
  deriveLedgerStatusFromBookingStatus,
  isValidPaymentStatus,
  isValidPaymentStatusTransition,
  normalizeBookingStatus,
} from '../types/database.types';
import {
  OperationalAuthContext,
  OperationalBookingRecord,
  OperationalHistoryEntry,
  OperationalPartnerRecord,
  OperationalStateSnapshot,
  OperationalTourRecord,
  OperationResult,
  authorizeOperationalAction,
} from './operationsService';
import { supabase, isSupabaseConfigured } from './supabaseClient';

// ============================================================================
// 1. ARITMÉTICA MONETÁRIA DETERMINÍSTICA EM CENTAVOS INTEIROS (F07 — SEM EPSILON BIAS)
// ============================================================================

/**
 * Converte um valor monetário decimal para centavos inteiros com arredondamento
 * comercial HALF_UP exato baseado na representação decimal (sem viés de +1e-9).
 * Exemplos verificados:
 *  - toIntegerCents(10.00499999999) === 1000
 *  - toIntegerCents(10.005) === 1001
 *  - toIntegerCents(10.555) === 1056
 *  - toIntegerCents(1.005) === 101
 */
export function toIntegerCents(value: number): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n === 0) return 0;
  const sign = n < 0 ? -1 : 1;
  const absVal = Math.abs(n);

  // Extrai representação decimal limpa sem notação científica
  const rawStr =
    absVal >= 1e-6 && absVal < 1e20 ? absVal.toString() : absVal.toFixed(12);
  const [intPartRaw, fracPartRaw = ''] = rawStr.split('.');
  const intCents = parseInt(intPartRaw || '0', 10) * 100;
  const paddedFrac = (fracPartRaw + '000').slice(0, 3);
  const firstTwoDigits = parseInt(paddedFrac.slice(0, 2), 10);
  const thirdDigit = parseInt(paddedFrac.slice(2, 3), 10);
  const remAfterThird = fracPartRaw.length > 3 ? fracPartRaw.slice(3) : '';

  // Proteção contra representação binária IEEE-754 como 19.99 * 100 -> 1998.9999999999998
  // Se os dígitos a partir do 3º forem '9999999999...', trata-se de artefato binário de centavo exato
  if (thirdDigit === 9 && /^9{8,}$/.test(remAfterThird)) {
    return sign * (intCents + firstTwoDigits + 1);
  }

  const totalCents = intCents + firstTwoDigits + (thirdDigit >= 5 ? 1 : 0);
  return sign * totalCents;
}

/**
 * Converte centavos inteiros de volta para número decimal de 2 casas.
 */
export function fromIntegerCents(cents: number): number {
  if (!Number.isFinite(cents) || cents === 0) return 0;
  return Math.round(cents) / 100;
}

/**
 * Arredonda um valor em reais para 2 casas decimais exatas via centavos inteiros.
 */
export function roundCurrencyExact(value: number): number {
  return fromIntegerCents(toIntegerCents(value));
}

/**
 * Divisão inteira BigInt com arredondamento comercial HALF_UP exato:
 * round(numerator / denominator) sem utilizar ponto flutuante IEEE-754.
 */
export function roundHalfUpBigIntDivision(
  numerator: bigint,
  denominator: bigint
): bigint {
  if (denominator === 0n) return 0n;
  const isNegative = numerator < 0n !== denominator < 0n;
  const absNum = numerator < 0n ? -numerator : numerator;
  const absDen = denominator < 0n ? -denominator : denominator;
  const quotient = absNum / absDen;
  const remainder = absNum % absDen;
  const rounded = remainder * 2n >= absDen ? quotient + 1n : quotient;
  return isNegative ? -rounded : rounded;
}

/**
 * Soma um array de valores monetários em centavos inteiros sem deriva de ponto flutuante.
 */
export function sumCurrencyExact(values: readonly number[]): number {
  let totalCents = 0;
  for (const val of values) {
    totalCents += toIntegerCents(Number(val) || 0);
  }
  return fromIntegerCents(totalCents);
}

// ============================================================================
// 2. TIPOS DE DOMÍNIO FINANCEIRO (PARIDADE COM MIGRATIONS 000022 E 000023)
// ============================================================================

export interface CommissionRuleSnapshot {
  pricingModel: PricingModelType;
  unitPrice: number;
  passengers: number;
  commissionModel: CommissionModelType;
  commissionRatePercent: number;
  commissionFixedAmount: number;
  commissionRuleLabel: string;
}

export interface ServerFinancialCalculationResult {
  grossAmount: number;
  commissionAmount: number;
  netPartnerAmount: number;
  grossCents: number;
  commissionCents: number;
  netPartnerCents: number;
  ruleSnapshot: CommissionRuleSnapshot;
}

export interface BookingPaymentRecord {
  id: string;
  bookingId: string;
  bookingCode: string;
  partnerId: string;
  tourId: string;
  paymentMethod: PaymentMethodType;
  paymentStatus: PaymentStatusType;
  currency: 'BRL';
  grossAmount: number;
  paidGrossAmount: number;
  refundedGrossAmount: number;
  commissionAmount: number;
  platformCommissionAmount: number;
  reversedCommissionAmount: number;
  effectiveGrossAmount: number;
  effectiveCommissionAmount: number;
  netPartnerAmount: number;
  effectiveNetPartnerAmount: number;
  commissionModelSnapshot: CommissionModelType;
  commissionRateSnapshot: number;
  commissionFixedSnapshot: number;
  commissionRuleLabel: string;
  commissionRuleSnapshot: {
    commissionModel: CommissionModelType;
    commissionRate: number;
    commissionFixed: number;
    commissionRuleLabel: string;
  };
  idempotencyKey: string;
  lastOperationIdempotencyKey: string | null;
  externalPaymentReference: string | null;
  externalTransactionId: string | null;
  confirmationOrigin?: 'GATEWAY_WEBHOOK' | 'MANUAL_ADMIN' | null;
  failureReason: string | null;
  refundReason: string | null;
  requestedRefundAmount?: number | null;
  paidAt: string | null;
  failedAt: string | null;
  cancelledAt: string | null;
  refundedAt: string | null;
  createdBy: string | null;
  updatedBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface BookingPaymentHistoryEntry {
  id: string;
  paymentId: string;
  bookingId: string;
  bookingCode: string;
  partnerId: string;
  previousStatus: PaymentStatusType | null;
  newStatus: PaymentStatusType;
  actorId: string | null;
  actorRole: AppRole;
  actorName: string;
  idempotencyKey: string | null;
  amountSnapshot: number;
  refundAmountSnapshot: number;
  reason: string | null;
  metadata: Record<string, unknown>;
  createdAt: string;
}

export interface FinancialLedgerEntry {
  id: string;
  bookingId: string;
  bookingCode: string;
  paymentId: string | null;
  partnerId: string;
  entryType: FinancialEntryType;
  grossDelta: number;
  commissionDelta: number;
  netPartnerDelta: number;
  currency: 'BRL';
  idempotencyKey: string;
  description: string;
  actorId: string | null;
  actorRole: AppRole;
  createdAt: string;
}

export interface IdempotentOperationPayloadFingerprint {
  operation:
    | 'INITIATE_PAYMENT'
    | 'TRANSITION_PAYMENT'
    | 'REQUEST_REFUND'
    | 'PROCESS_REFUND'
    | 'REVERT_FAILED_REFUND';
  bookingId: string;
  paymentMethod?: PaymentMethodType;
  targetStatus?: PaymentStatusType;
  externalTransactionId?: string;
  reason?: string;
  markBookingCancelled?: boolean;
  confirmationOrigin?: string;
  refundAmountCents?: number;
  inputRefundAmountCents?: number | null;
  reversedCommissionCents?: number;
}

export interface FinancialStoreSnapshot {
  payments: BookingPaymentRecord[];
  paymentHistory: BookingPaymentHistoryEntry[];
  ledgerEntries: FinancialLedgerEntry[];
  processedIdempotencyKeys: Record<
    string,
    {
      bookingId: string;
      paymentId: string;
      operation: string;
      resultStatus: PaymentStatusType;
      timestamp: string;
      payloadFingerprint?: IdempotentOperationPayloadFingerprint;
    }
  >;
}

export function createEmptyFinancialStore(): FinancialStoreSnapshot {
  return {
    payments: [],
    paymentHistory: [],
    ledgerEntries: [],
    processedIdempotencyKeys: {},
  };
}

// ============================================================================
// 3. MOTOR DE CÁLCULO DE VALORES, COMISSÕES E REPASSES (F07 — BIGINT EXATO)
// ============================================================================

export function normalizePartnerCommissionModel(
  rawModel: PartnerCommissionModelUI | string | undefined
): CommissionModelType {
  if (rawModel === 'FIXED_PER_PASSENGER' || rawModel === 'FIXED_AMOUNT') {
    return 'FIXED_PER_PASSENGER';
  }
  if (rawModel === 'FIXED_PER_BOOKING') {
    return 'FIXED_PER_BOOKING';
  }
  if (
    rawModel === 'HYBRID_PERCENT_PLUS_FIXED' ||
    rawModel === 'CUSTOM_OVERRIDE'
  ) {
    return 'HYBRID_PERCENT_PLUS_FIXED';
  }
  return 'PERCENTAGE';
}

export function calculateServerCommissionAndNet(params: {
  tour: Pick<
    OperationalTourRecord,
    | 'price'
    | 'pricingModel'
    | 'tourType'
    | 'capacity'
    | 'commissionModelOverride'
    | 'commissionRateOverride'
    | 'commissionFixedOverride'
  >;
  partner: Pick<
    OperationalPartnerRecord,
    'commissionModel' | 'commissionRate' | 'commissionFixed'
  >;
  passengers: number;
}): ServerFinancialCalculationResult {
  const { tour, partner } = params;
  const pax = Math.max(1, Math.floor(Number(params.passengers) || 1));
  const unitPriceCents = Math.max(0, toIntegerCents(Number(tour.price) || 0));

  const pricingModel: PricingModelType =
    tour.pricingModel === 'POR_EMBARCACAO' || tour.tourType === 'Privativo'
      ? 'POR_EMBARCACAO'
      : 'POR_PESSOA';

  const grossCents =
    pricingModel === 'POR_EMBARCACAO' ? unitPriceCents : unitPriceCents * pax;

  const effectiveModel: CommissionModelType = tour.commissionModelOverride
    ? normalizePartnerCommissionModel(tour.commissionModelOverride)
    : normalizePartnerCommissionModel(partner.commissionModel);

  const effectiveRatePercent = Math.max(
    0,
    Math.min(
      100,
      Number(
        tour.commissionRateOverride !== undefined &&
          tour.commissionRateOverride !== null
          ? tour.commissionRateOverride
          : partner.commissionRate ?? 15
      ) || 0
    )
  );

  // Taxa percentual em basis points inteiros (ex: 15.5% -> 1550 bps de 10000)
  const rateBps = BigInt(toIntegerCents(effectiveRatePercent));

  const effectiveFixedCents = Math.max(
    0,
    toIntegerCents(
      Number(
        tour.commissionFixedOverride !== undefined &&
          tour.commissionFixedOverride !== null
          ? tour.commissionFixedOverride
          : partner.commissionFixed ?? 0
      ) || 0
    )
  );

  let rawCommissionCents = 0;
  let ruleLabel = '';

  if (effectiveModel === 'PERCENTAGE') {
    rawCommissionCents = Number(
      roundHalfUpBigIntDivision(BigInt(grossCents) * rateBps, 10000n)
    );
    ruleLabel = `Percentual Padrão (${effectiveRatePercent}%)`;
  } else if (effectiveModel === 'FIXED_PER_PASSENGER') {
    rawCommissionCents = effectiveFixedCents * pax;
    ruleLabel = `Taxa Fixa por Passageiro (R$ ${fromIntegerCents(effectiveFixedCents).toFixed(2)}/pax)`;
  } else if (effectiveModel === 'FIXED_PER_BOOKING') {
    rawCommissionCents = effectiveFixedCents;
    ruleLabel = `Taxa Fixa por Reserva (R$ ${fromIntegerCents(effectiveFixedCents).toFixed(2)})`;
  } else {
    const pctPartCents = Number(
      roundHalfUpBigIntDivision(BigInt(grossCents) * rateBps, 10000n)
    );
    rawCommissionCents = pctPartCents + effectiveFixedCents;
    ruleLabel = `Regra Híbrida (${effectiveRatePercent}% + R$ ${fromIntegerCents(effectiveFixedCents).toFixed(2)})`;
  }

  const commissionCents = Math.max(0, Math.min(grossCents, rawCommissionCents));
  const netPartnerCents = grossCents - commissionCents;

  return {
    grossAmount: fromIntegerCents(grossCents),
    commissionAmount: fromIntegerCents(commissionCents),
    netPartnerAmount: fromIntegerCents(netPartnerCents),
    grossCents,
    commissionCents,
    netPartnerCents,
    ruleSnapshot: {
      pricingModel,
      unitPrice: fromIntegerCents(unitPriceCents),
      passengers: pax,
      commissionModel: effectiveModel,
      commissionRatePercent: effectiveRatePercent,
      commissionFixedAmount: fromIntegerCents(effectiveFixedCents),
      commissionRuleLabel: ruleLabel,
    },
  };
}


export function calculateProportionalRefundSplit(params: {
  grossAmount: number;
  commissionAmount: number;
  netPartnerAmount: number;
  prevRefundedGrossAmount: number;
  prevReversedCommissionAmount: number;
  newRefundGrossAmount: number;
}): {
  refundGrossDelta: number;
  refundCommissionDelta: number;
  refundNetPartnerDelta: number;
  newTotalRefundedGross: number;
  newTotalReversedCommission: number;
  effectiveGrossAmount: number;
  effectiveCommissionAmount: number;
  effectiveNetPartnerAmount: number;
  isFullRefund: boolean;
} {
  const grossCents = toIntegerCents(params.grossAmount);
  const commCents = toIntegerCents(params.commissionAmount);
  const prevRefGrossCents = toIntegerCents(params.prevRefundedGrossAmount);
  const prevRevCommCents = toIntegerCents(params.prevReversedCommissionAmount);
  const newRefDeltaCents = toIntegerCents(params.newRefundGrossAmount);

  const newTotalRefGrossCents = prevRefGrossCents + newRefDeltaCents;
  const isFullRefund = newTotalRefGrossCents >= grossCents;

  let newTotalRevCommCents: number;
  if (isFullRefund || grossCents <= 0) {
    newTotalRevCommCents = commCents;
  } else {
    newTotalRevCommCents = Number(
      roundHalfUpBigIntDivision(
        BigInt(commCents) * BigInt(newTotalRefGrossCents),
        BigInt(grossCents)
      )
    );
    newTotalRevCommCents = Math.min(
      commCents,
      Math.max(prevRevCommCents, newTotalRevCommCents)
    );
  }

  const refCommDeltaCents = newTotalRevCommCents - prevRevCommCents;
  const refNetDeltaCents = newRefDeltaCents - refCommDeltaCents;
  const effGrossCents = grossCents - newTotalRefGrossCents;
  const effCommCents = commCents - newTotalRevCommCents;
  const effNetCents = effGrossCents - effCommCents;

  return {
    refundGrossDelta: fromIntegerCents(newRefDeltaCents),
    refundCommissionDelta: fromIntegerCents(refCommDeltaCents),
    refundNetPartnerDelta: fromIntegerCents(refNetDeltaCents),
    newTotalRefundedGross: fromIntegerCents(newTotalRefGrossCents),
    newTotalReversedCommission: fromIntegerCents(newTotalRevCommCents),
    effectiveGrossAmount: fromIntegerCents(effGrossCents),
    effectiveCommissionAmount: fromIntegerCents(effCommCents),
    effectiveNetPartnerAmount: fromIntegerCents(effNetCents),
    isFullRefund,
  };
}

export function validateFinancialConsistency(params: {
  grossAmount: number;
  commissionAmount: number;
  netPartnerAmount: number;
  paidGrossAmount?: number;
  refundedGrossAmount?: number;
  reversedCommissionAmount?: number;
  effectiveCommissionAmount?: number;
  effectiveNetPartnerAmount?: number;
}): OperationResult<void> {
  const grossCents = toIntegerCents(params.grossAmount);
  const commCents = toIntegerCents(params.commissionAmount);
  const netCents = toIntegerCents(params.netPartnerAmount);

  if (grossCents < 0 || commCents < 0 || netCents < 0) {
    return {
      ok: false,
      errorCode: 'NEGATIVE_FINANCIAL_AMOUNT',
      errorMessage: 'Valores financeiros não podem ser negativos.',
    };
  }

  if (commCents > grossCents) {
    return {
      ok: false,
      errorCode: 'COMMISSION_EXCEEDS_GROSS',
      errorMessage: `A comissão (R$ ${fromIntegerCents(commCents).toFixed(2)}) nunca pode ser maior que o valor bruto (R$ ${fromIntegerCents(grossCents).toFixed(2)}).`,
    };
  }

  if (grossCents !== commCents + netCents) {
    return {
      ok: false,
      errorCode: 'FINANCIAL_FORMULA_MISMATCH',
      errorMessage: `Inconsistência contábil: Bruto (${fromIntegerCents(grossCents).toFixed(2)}) != Comissão (${fromIntegerCents(commCents).toFixed(2)}) + Líquido (${fromIntegerCents(netCents).toFixed(2)}).`,
    };
  }

  if (params.paidGrossAmount !== undefined) {
    const paidCents = toIntegerCents(params.paidGrossAmount);
    if (paidCents < 0 || paidCents > grossCents) {
      return {
        ok: false,
        errorCode: 'INVALID_PAID_AMOUNT',
        errorMessage: 'O valor pago não pode ser negativo nem exceder o valor bruto da reserva.',
      };
    }
  }

  if (params.refundedGrossAmount !== undefined) {
    const refCents = toIntegerCents(params.refundedGrossAmount);
    const paidCents =
      params.paidGrossAmount !== undefined
        ? toIntegerCents(params.paidGrossAmount)
        : grossCents;
    if (refCents < 0 || refCents > paidCents) {
      return {
        ok: false,
        errorCode: 'REFUND_EXCEEDS_PAID_AMOUNT',
        errorMessage: `O valor estornado (R$ ${fromIntegerCents(refCents).toFixed(2)}) não pode exceder o valor pago (R$ ${fromIntegerCents(paidCents).toFixed(2)}).`,
      };
    }
  }

  if (
    params.reversedCommissionAmount !== undefined &&
    params.effectiveCommissionAmount !== undefined
  ) {
    const revCommCents = toIntegerCents(params.reversedCommissionAmount);
    const effCommCents = toIntegerCents(params.effectiveCommissionAmount);
    if (
      revCommCents < 0 ||
      effCommCents < 0 ||
      revCommCents + effCommCents !== commCents
    ) {
      return {
        ok: false,
        errorCode: 'COMMISSION_REVERSAL_MISMATCH',
        errorMessage:
          'A soma da comissão revertida e da comissão efetiva deve ser igual à comissão original.',
      };
    }
  }

  return { ok: true };
}

// ============================================================================
// 4. CRIAÇÃO E INICIAÇÃO DE PAGAMENTO DE RESERVA (COM IDEMPOTÊNCIA F06)
// ============================================================================

export interface InitiateBookingPaymentInput {
  bookingId: string;
  paymentMethod: PaymentMethodType;
  idempotencyKey: string;
  externalPaymentReference?: string | null;
}

export interface InitiateBookingPaymentResult {
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  payment: BookingPaymentRecord;
  idempotentReplay: boolean;
}

export function initiateBookingPayment(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  input: InitiateBookingPaymentInput
): OperationResult<InitiateBookingPaymentResult> {
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 8) {
    return {
      ok: false,
      errorCode: 'IDEMPOTENCY_KEY_REQUIRED',
      errorMessage:
        'Chave de idempotência financeira obrigatória (mínimo 8 caracteres).',
    };
  }

  if (!(PAYMENT_METHOD_VALUES as readonly string[]).includes(input.paymentMethod)) {
    return {
      ok: false,
      errorCode: 'INVALID_PAYMENT_METHOD',
      errorMessage: `Método de pagamento inválido: "${String(input.paymentMethod)}".`,
    };
  }

  const booking = opState.bookings.find(
    (b) => b.id === input.bookingId || b.code === input.bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${input.bookingId}" não encontrada para iniciar pagamento.`,
    };
  }

  if (authCtx.actorRole === 'partner') {
    const authCheck = authorizeOperationalAction(
      authCtx,
      ['partner', 'admin'],
      booking.partnerId,
      opState
    );
    if (!authCheck.ok) {
      return {
        ok: false,
        errorCode: authCheck.errorCode || 'CROSS_TENANT_ACCESS_DENIED',
        errorMessage:
          authCheck.errorMessage ||
          'Parceiro não autorizado para iniciar pagamento desta reserva.',
      };
    }
  } else if (authCtx.actorRole === 'admin') {
    const authCheck = authorizeOperationalAction(
      authCtx,
      ['admin'],
      undefined,
      opState
    );
    if (!authCheck.ok) {
      return {
        ok: false,
        errorCode: authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
        errorMessage:
          authCheck.errorMessage || 'Sessão administrativa inválida.',
      };
    }
  }

  const cleanIdempKey = input.idempotencyKey.trim();
  const cleanExtRef = (input.externalPaymentReference || '').trim();
  const existingByBooking = finStore.payments.find(
    (p) => p.bookingId === booking.id
  );

  // F06: Verificação de replay idempotente com validação integral do payload
  const existingKeyRecord = finStore.processedIdempotencyKeys[cleanIdempKey];
  if (existingKeyRecord) {
    const fp = existingKeyRecord.payloadFingerprint;
    if (
      existingKeyRecord.bookingId !== booking.id ||
      existingKeyRecord.operation !== 'INITIATE_PAYMENT' ||
      (fp &&
        (fp.paymentMethod !== input.paymentMethod ||
          (fp.externalTransactionId || '') !== cleanExtRef))
    ) {
      return {
        ok: false,
        errorCode: 'FINANCIAL_IDEMPOTENCY_CONFLICT',
        errorMessage:
          'Conflito de idempotência financeira: chave já utilizada para outra operação ou com parâmetros divergentes.',
      };
    }
    if (existingByBooking) {
      return {
        ok: true,
        data: {
          operationalState: opState,
          financialStore: finStore,
          payment: existingByBooking,
          idempotentReplay: true,
        },
      };
    }
  }

  if (existingByBooking) {
    if (existingByBooking.idempotencyKey === cleanIdempKey) {
      if (
        existingByBooking.paymentMethod !== input.paymentMethod ||
        (existingByBooking.externalPaymentReference || '') !== cleanExtRef
      ) {
        return {
          ok: false,
          errorCode: 'FINANCIAL_IDEMPOTENCY_CONFLICT',
          errorMessage:
            'Conflito de idempotência financeira: a chave informada já está vinculada a outro método ou referência de pagamento.',
        };
      }
      return {
        ok: true,
        data: {
          operationalState: opState,
          financialStore: finStore,
          payment: existingByBooking,
          idempotentReplay: true,
        },
      };
    }

    if (
      existingByBooking.paymentStatus === 'PAGO' ||
      existingByBooking.paymentStatus === 'ESTORNO_PARCIAL' ||
      existingByBooking.paymentStatus === 'ESTORNO_PENDENTE'
    ) {
      return {
        ok: false,
        errorCode: 'PAYMENT_ALREADY_CONFIRMED',
        errorMessage: `A reserva ${booking.code} já possui pagamento confirmado (${existingByBooking.paymentStatus}). Dupla cobrança bloqueada.`,
      };
    }

    if (existingByBooking.paymentStatus === 'ESTORNADO') {
      return {
        ok: false,
        errorCode: 'PAYMENT_ALREADY_REFUNDED',
        errorMessage: `A reserva ${booking.code} já teve pagamento integralmente estornado.`,
      };
    }
  }

  const bookingStatus = normalizeBookingStatus(booking.status);
  if (bookingStatus === 'CANCELADA' || bookingStatus === 'RECUSADA') {
    return {
      ok: false,
      errorCode: 'BOOKING_CANCELLED_OR_REJECTED',
      errorMessage: `Não é permitido iniciar pagamento para reserva em estado ${bookingStatus}.`,
    };
  }

  const tour = opState.tours.find((t) => t.id === booking.tourId);
  const partner = opState.partners.find((p) => p.id === booking.partnerId);
  if (!tour || !partner) {
    return {
      ok: false,
      errorCode: 'CATALOG_ENTITY_MISSING',
      errorMessage:
        'Passeio ou parceiro vinculado à reserva não encontrado para cálculo financeiro no servidor.',
    };
  }

  // Preserva o snapshot histórico da reserva quando já calculado na criação
  const calc = calculateServerCommissionAndNet({
    tour,
    partner,
    passengers: booking.passengers,
  });

  const grossAmount =
    toIntegerCents(booking.grossAmount) > 0
      ? roundCurrencyExact(booking.grossAmount)
      : calc.grossAmount;
  const commissionAmount =
    toIntegerCents(booking.grossAmount) > 0
      ? roundCurrencyExact(booking.commissionAmount)
      : calc.commissionAmount;
  const netPartnerAmount =
    toIntegerCents(booking.grossAmount) > 0
      ? roundCurrencyExact(booking.netPartnerAmount)
      : calc.netPartnerAmount;
  const ruleLabel =
    booking.commissionRuleUsed && booking.commissionRuleUsed.trim().length > 0
      ? booking.commissionRuleUsed
      : calc.ruleSnapshot.commissionRuleLabel;

  const nowIso = new Date().toISOString();
  const paymentId = existingByBooking?.id || `pay-${booking.id}`;
  const prevStatus: PaymentStatusType | null = existingByBooking
    ? existingByBooking.paymentStatus
    : null;

  const nextStatus: PaymentStatusType = existingByBooking
    ? 'PROCESSANDO'
    : 'PENDENTE';

  const paymentRecord: BookingPaymentRecord = {
    id: paymentId,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    tourId: booking.tourId,
    paymentMethod: input.paymentMethod,
    paymentStatus: nextStatus,
    currency: 'BRL',
    grossAmount,
    paidGrossAmount: 0,
    refundedGrossAmount: 0,
    commissionAmount,
    platformCommissionAmount: commissionAmount,
    reversedCommissionAmount: 0,
    effectiveGrossAmount: grossAmount,
    effectiveCommissionAmount: commissionAmount,
    netPartnerAmount,
    effectiveNetPartnerAmount: netPartnerAmount,
    commissionModelSnapshot: calc.ruleSnapshot.commissionModel,
    commissionRateSnapshot: calc.ruleSnapshot.commissionRatePercent,
    commissionFixedSnapshot: calc.ruleSnapshot.commissionFixedAmount,
    commissionRuleLabel: ruleLabel,
    commissionRuleSnapshot: {
      commissionModel: calc.ruleSnapshot.commissionModel,
      commissionRate: calc.ruleSnapshot.commissionRatePercent,
      commissionFixed: calc.ruleSnapshot.commissionFixedAmount,
      commissionRuleLabel: ruleLabel,
    },
    idempotencyKey: existingByBooking?.idempotencyKey || cleanIdempKey,
    lastOperationIdempotencyKey: cleanIdempKey,
    externalPaymentReference:
      cleanExtRef || existingByBooking?.externalPaymentReference || null,
    externalTransactionId: existingByBooking?.externalTransactionId || null,
    confirmationOrigin: existingByBooking?.confirmationOrigin || null,
    failureReason: null,
    refundReason: null,
    requestedRefundAmount: null,
    paidAt: null,
    failedAt: null,
    cancelledAt: null,
    refundedAt: null,
    createdBy: authCtx.actorId,
    updatedBy: authCtx.actorId,
    createdAt: existingByBooking?.createdAt || nowIso,
    updatedAt: nowIso,
  };

  const historyEntry: BookingPaymentHistoryEntry = {
    id: `phist-${Date.now()}-${finStore.paymentHistory.length + 1}`,
    paymentId: paymentRecord.id,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    previousStatus: prevStatus,
    newStatus: paymentRecord.paymentStatus,
    actorId: authCtx.actorId,
    actorRole: authCtx.actorRole,
    actorName: authCtx.actorName,
    idempotencyKey: cleanIdempKey,
    amountSnapshot: paymentRecord.grossAmount,
    refundAmountSnapshot: 0,
    reason: prevStatus
      ? `Reinício de tentativa de pagamento via ${input.paymentMethod}`
      : `Pagamento iniciado via ${input.paymentMethod}`,
    metadata: {
      paymentMethod: input.paymentMethod,
      externalPaymentReference: paymentRecord.externalPaymentReference,
    },
    createdAt: nowIso,
  };

  let nextLedgerEntries = [...finStore.ledgerEntries];
  const provKey = `ledger-prov-${booking.id}`;
  const hasProvisioned = nextLedgerEntries.some(
    (e) =>
      e.bookingId === booking.id && e.entryType === 'COMMISSION_PROVISIONED'
  );
  if (!hasProvisioned) {
    nextLedgerEntries = [
      {
        id: `fl-${Date.now()}-${nextLedgerEntries.length + 1}`,
        bookingId: booking.id,
        bookingCode: booking.code,
        paymentId: paymentRecord.id,
        partnerId: booking.partnerId,
        entryType: 'COMMISSION_PROVISIONED',
        grossDelta: 0,
        commissionDelta: 0,
        netPartnerDelta: 0,
        currency: 'BRL',
        idempotencyKey: provKey,
        description: `Provisão inicial de comissão (${paymentRecord.commissionRuleLabel}) para reserva ${booking.code}`,
        actorId: authCtx.actorId,
        actorRole: authCtx.actorRole,
        createdAt: nowIso,
      },
      ...nextLedgerEntries,
    ];
  }

  const nextPayments = existingByBooking
    ? finStore.payments.map((p) =>
        p.id === paymentRecord.id ? paymentRecord : p
      )
    : [paymentRecord, ...finStore.payments];

  const nextFinStore: FinancialStoreSnapshot = {
    payments: nextPayments,
    paymentHistory: [historyEntry, ...finStore.paymentHistory],
    ledgerEntries: nextLedgerEntries,
    processedIdempotencyKeys: {
      ...finStore.processedIdempotencyKeys,
      [cleanIdempKey]: {
        bookingId: booking.id,
        paymentId: paymentRecord.id,
        operation: 'INITIATE_PAYMENT',
        resultStatus: paymentRecord.paymentStatus,
        timestamp: nowIso,
        payloadFingerprint: {
          operation: 'INITIATE_PAYMENT',
          bookingId: booking.id,
          paymentMethod: input.paymentMethod,
          externalTransactionId: cleanExtRef,
        },
      },
    },
  };

  const nextBookings: OperationalBookingRecord[] = opState.bookings.map((b) =>
    b.id === booking.id
      ? {
          ...b,
          grossAmount: paymentRecord.grossAmount,
          commissionAmount: paymentRecord.platformCommissionAmount,
          netPartnerAmount: paymentRecord.netPartnerAmount,
          commissionRuleUsed: paymentRecord.commissionRuleLabel,
        }
      : b
  );

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    bookings: nextBookings,
    auditLogs: [
      {
        id: `aud-pay-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || authCtx.actorId || 'Sistema',
        role: authCtx.actorRole,
        action: 'PAYMENT_INITIATED',
        target: booking.code,
        details: `Pagamento iniciado via ${input.paymentMethod} (${paymentRecord.paymentStatus}) | Bruto R$ ${paymentRecord.grossAmount.toFixed(2)}`,
      },
      ...opState.auditLogs,
    ],
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: nextFinStore,
      payment: paymentRecord,
      idempotentReplay: false,
    },
  };
}

// ============================================================================
// 5. TRANSIÇÃO DE PAGAMENTO: PROCESSANDO, PAGO, FALHOU, CANCELADO (F01 & F06)
// ============================================================================

export interface TransitionBookingPaymentInput {
  bookingId: string;
  targetStatus: 'PROCESSANDO' | 'PAGO' | 'FALHOU' | 'CANCELADO' | 'ESTORNO_PARCIAL';
  idempotencyKey: string;
  externalTransactionId?: string | null;
  reason?: string | null;
  markBookingCancelled?: boolean;
  confirmationOrigin?: 'GATEWAY_WEBHOOK' | 'MANUAL_ADMIN';
  clientGrossAmountAttempt?: number | null;
  clientCommissionAmountAttempt?: number | null;
  clientNetPartnerAmountAttempt?: number | null;
}

export interface TransitionBookingPaymentResult {
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  payment: BookingPaymentRecord;
  booking: OperationalBookingRecord;
  idempotentReplay: boolean;
}

export function transitionBookingPaymentStatus(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  input: TransitionBookingPaymentInput
): OperationResult<TransitionBookingPaymentResult> {
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 8) {
    return {
      ok: false,
      errorCode: 'IDEMPOTENCY_KEY_REQUIRED',
      errorMessage:
        'Chave de idempotência obrigatória para transição de pagamento.',
    };
  }

  // F01: Bloqueia integralmente o perfil tourist de alterar estados financeiros diretamente
  if (authCtx.actorRole === 'tourist') {
    return {
      ok: false,
      errorCode: 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN',
      errorMessage:
        'O perfil turista não possui permissão para alterar diretamente o estado financeiro de pagamentos.',
    };
  }

  const booking = opState.bookings.find(
    (b) => b.id === input.bookingId || b.code === input.bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${input.bookingId}" não encontrada.`,
    };
  }

  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    booking.partnerId,
    opState
  );
  if (!authCheck.ok || !authCheck.data) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'UNAUTHORIZED_FINANCIAL_OPERATION',
      errorMessage:
        authCheck.errorMessage ||
        'Apenas administrador ou parceiro responsável podem processar transições financeiras.',
    };
  }

  if (
    input.clientGrossAmountAttempt !== undefined &&
    input.clientGrossAmountAttempt !== null &&
    toIntegerCents(input.clientGrossAmountAttempt) !== toIntegerCents(booking.grossAmount)
  ) {
    return {
      ok: false,
      errorCode: 'PAYMENT_CLIENT_AMOUNT_MISMATCH',
      errorMessage: 'Valor bruto enviado pelo cliente diverge do valor oficial calculado no servidor.',
    };
  }
  if (
    input.clientCommissionAmountAttempt !== undefined &&
    input.clientCommissionAmountAttempt !== null &&
    toIntegerCents(input.clientCommissionAmountAttempt) !== toIntegerCents(booking.commissionAmount)
  ) {
    return {
      ok: false,
      errorCode: 'COMMISSION_TAMPERING_FORBIDDEN',
      errorMessage: 'Adulteração de comissão pelo cliente bloqueada.',
    };
  }
  if (
    input.clientNetPartnerAmountAttempt !== undefined &&
    input.clientNetPartnerAmountAttempt !== null &&
    toIntegerCents(input.clientNetPartnerAmountAttempt) !== toIntegerCents(booking.netPartnerAmount)
  ) {
    return {
      ok: false,
      errorCode: 'NET_AMOUNT_TAMPERING_FORBIDDEN',
      errorMessage: 'Adulteração de valor líquido do parceiro pelo cliente bloqueada.',
    };
  }

  // F01 & D12: Parceiros NUNCA podem confirmar pagamento como PAGO ou reverter estorno para ESTORNO_PARCIAL
  if (
    (input.targetStatus === 'PAGO' || input.targetStatus === 'ESTORNO_PARCIAL') &&
    authCheck.data.effectiveRole === 'partner'
  ) {
    return {
      ok: false,
      errorCode: 'PARTNER_PAYMENT_CONFIRM_FORBIDDEN',
      errorMessage:
        'Parceiros não possuem autorização para confirmar pagamentos como PAGO. A confirmação exige retorno autenticado do gateway ou conciliação administrativa auditada.',
    };
  }

  const cleanIdempKey = input.idempotencyKey.trim();
  const cleanTxId = (input.externalTransactionId || '').trim();
  const cleanReason = (input.reason || '').trim();
  const markCancelledFlag = Boolean(input.markBookingCancelled);
  const confirmationOrigin: 'GATEWAY_WEBHOOK' | 'MANUAL_ADMIN' =
    input.confirmationOrigin || 'MANUAL_ADMIN';

  const currentPayment = finStore.payments.find(
    (p) => p.bookingId === booking.id
  );
  if (!currentPayment) {
    return {
      ok: false,
      errorCode: 'PAYMENT_RECORD_NOT_FOUND',
      errorMessage: `Nenhum registro de pagamento iniciado para a reserva ${booking.code}.`,
    };
  }

  // F06 & D12: Validação estrita de equivalência de payload em replay idempotente
  const existingKeyRecord = finStore.processedIdempotencyKeys[cleanIdempKey];
  if (existingKeyRecord) {
    const fp = existingKeyRecord.payloadFingerprint;
    const expectedTargetAfterEstornoPendente =
      toIntegerCents(currentPayment.refundedGrossAmount) > 0
        ? 'ESTORNO_PARCIAL'
        : input.targetStatus;
    const targetMatches =
      fp
        ? fp.targetStatus === input.targetStatus ||
          ((fp.targetStatus === 'PAGO' || fp.targetStatus === 'ESTORNO_PARCIAL') &&
            (input.targetStatus === 'PAGO' || input.targetStatus === 'ESTORNO_PARCIAL') &&
            existingKeyRecord.resultStatus === expectedTargetAfterEstornoPendente)
        : true;
    if (
      existingKeyRecord.bookingId !== booking.id ||
      existingKeyRecord.operation !== 'TRANSITION_PAYMENT' ||
      (existingKeyRecord.resultStatus !== input.targetStatus &&
        existingKeyRecord.resultStatus !== expectedTargetAfterEstornoPendente) ||
      !targetMatches ||
      (fp &&
        ((fp.externalTransactionId || '') !== cleanTxId ||
          (fp.reason || '') !== cleanReason ||
          Boolean(fp.markBookingCancelled) !== markCancelledFlag))
    ) {
      return {
        ok: false,
        errorCode: 'FINANCIAL_IDEMPOTENCY_CONFLICT',
        errorMessage:
          'Conflito de idempotência financeira: chave já utilizada para outra operação ou com parâmetros divergentes.',
      };
    }
    return {
      ok: true,
      data: {
        operationalState: opState,
        financialStore: finStore,
        payment: currentPayment,
        booking,
        idempotentReplay: true,
      },
    };
  }

  if (currentPayment.paymentStatus === input.targetStatus) {
    if (
      currentPayment.lastOperationIdempotencyKey === cleanIdempKey &&
      (currentPayment.externalTransactionId || '') ===
        (cleanTxId || currentPayment.externalTransactionId || '')
    ) {
      return {
        ok: true,
        data: {
          operationalState: opState,
          financialStore: finStore,
          payment: currentPayment,
          booking,
          idempotentReplay: true,
        },
      };
    }
    if (input.targetStatus === 'PAGO') {
      return {
        ok: false,
        errorCode: 'DUPLICATE_PAYMENT_CONFIRMATION_BLOCKED',
        errorMessage: `O pagamento da reserva ${booking.code} já se encontra confirmado como PAGO. Duplicidade bloqueada.`,
      };
    }
  }

  // F02-B & D12: Suporte ao retorno seguro de ESTORNO_PENDENTE quando o processamento do estorno falha no gateway
  const isRevertingFailedRefund =
    currentPayment.paymentStatus === 'ESTORNO_PENDENTE' &&
    (input.targetStatus === 'PAGO' || input.targetStatus === 'ESTORNO_PARCIAL');

  if (
    !isRevertingFailedRefund &&
    (input.targetStatus === 'ESTORNO_PARCIAL' ||
      !isValidPaymentStatusTransition(
        currentPayment.paymentStatus,
        input.targetStatus
      ))
  ) {
    return {
      ok: false,
      errorCode: 'INVALID_PAYMENT_STATUS_TRANSITION',
      errorMessage: `Transição financeira inválida: ${currentPayment.paymentStatus} -> ${input.targetStatus}.`,
    };
  }

  if (input.targetStatus === 'PAGO' && !isRevertingFailedRefund) {
    const normBkStatus = normalizeBookingStatus(booking.status);
    if (normBkStatus === 'CANCELADA' || normBkStatus === 'RECUSADA') {
      return {
        ok: false,
        errorCode: 'CANNOT_PAY_CANCELLED_BOOKING',
        errorMessage: `Não é permitido confirmar pagamento para reserva em estado ${normBkStatus}.`,
      };
    }
    if (cleanTxId.length < 4) {
      return {
        ok: false,
        errorCode: 'EXTERNAL_TRANSACTION_ID_REQUIRED',
        errorMessage:
          'O identificador da transação (externalTransactionId, mín. 4 caracteres) é obrigatório para confirmar pagamento como PAGO.',
      };
    }
    if (
      confirmationOrigin === 'MANUAL_ADMIN' &&
      cleanReason.length < 5
    ) {
      return {
        ok: false,
        errorCode: 'MANUAL_CONFIRMATION_REASON_REQUIRED',
        errorMessage:
          'Confirmação manual administrativa de pagamento exige justificativa auditável (mínimo 5 caracteres).',
      };
    }
  }

  if (isRevertingFailedRefund && cleanReason.length < 5) {
    return {
      ok: false,
      errorCode: 'REASON_REQUIRED',
      errorMessage:
        'É obrigatório informar o motivo da falha do estorno (mínimo 5 caracteres) para restaurar o estado do pagamento.',
    };
  }

  if (
    (input.targetStatus === 'FALHOU' || input.targetStatus === 'CANCELADO') &&
    cleanReason.length < 3
  ) {
    return {
      ok: false,
      errorCode: 'REASON_REQUIRED',
      errorMessage: `É obrigatório informar o motivo (mínimo 3 caracteres) para marcar o pagamento como ${input.targetStatus}.`,
    };
  }

  const nowIso = new Date().toISOString();
  const effectiveTargetStatus: PaymentStatusType = isRevertingFailedRefund
    ? toIntegerCents(currentPayment.refundedGrossAmount) > 0
      ? 'ESTORNO_PARCIAL'
      : 'PAGO'
    : input.targetStatus;

  const updatedPayment: BookingPaymentRecord = {
    ...currentPayment,
    paymentStatus: effectiveTargetStatus,
    paidGrossAmount:
      effectiveTargetStatus === 'PAGO' ||
      effectiveTargetStatus === 'ESTORNO_PARCIAL'
        ? currentPayment.grossAmount
        : currentPayment.paidGrossAmount,
    externalTransactionId:
      cleanTxId || currentPayment.externalTransactionId || null,
    confirmationOrigin:
      effectiveTargetStatus === 'PAGO' && !isRevertingFailedRefund
        ? confirmationOrigin
        : currentPayment.confirmationOrigin,
    failureReason:
      effectiveTargetStatus === 'FALHOU' ||
      effectiveTargetStatus === 'CANCELADO'
        ? cleanReason
        : currentPayment.failureReason,
    refundReason: isRevertingFailedRefund
      ? `Falha no processamento do estorno: ${cleanReason}`
      : currentPayment.refundReason,
    requestedRefundAmount: isRevertingFailedRefund
      ? null
      : currentPayment.requestedRefundAmount,
    lastOperationIdempotencyKey: cleanIdempKey,
    paidAt:
      effectiveTargetStatus === 'PAGO' && !currentPayment.paidAt
        ? nowIso
        : currentPayment.paidAt,
    failedAt:
      effectiveTargetStatus === 'FALHOU' ? nowIso : currentPayment.failedAt,
    cancelledAt:
      effectiveTargetStatus === 'CANCELADO'
        ? nowIso
        : currentPayment.cancelledAt,
    updatedBy: authCtx.actorId,
    updatedAt: nowIso,
  };

  const consistencyCheck = validateFinancialConsistency({
    grossAmount: updatedPayment.grossAmount,
    commissionAmount: updatedPayment.platformCommissionAmount,
    netPartnerAmount: updatedPayment.netPartnerAmount,
    paidGrossAmount: updatedPayment.paidGrossAmount,
    refundedGrossAmount: updatedPayment.refundedGrossAmount,
    reversedCommissionAmount: updatedPayment.reversedCommissionAmount,
    effectiveCommissionAmount: updatedPayment.effectiveCommissionAmount,
    effectiveNetPartnerAmount: updatedPayment.effectiveNetPartnerAmount,
  });
  if (!consistencyCheck.ok) {
    return {
      ok: false,
      errorCode: consistencyCheck.errorCode,
      errorMessage: consistencyCheck.errorMessage,
    };
  }

  const historyEntry: BookingPaymentHistoryEntry = {
    id: `phist-${Date.now()}-${finStore.paymentHistory.length + 1}`,
    paymentId: updatedPayment.id,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    previousStatus: currentPayment.paymentStatus,
    newStatus: effectiveTargetStatus,
    actorId: authCtx.actorId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    idempotencyKey: cleanIdempKey,
    amountSnapshot: updatedPayment.grossAmount,
    refundAmountSnapshot: updatedPayment.refundedGrossAmount,
    reason:
      cleanReason ||
      (effectiveTargetStatus === 'PAGO'
        ? `Pagamento confirmado (${confirmationOrigin}: ${updatedPayment.externalTransactionId})`
        : `Transição para ${effectiveTargetStatus}`),
    metadata: {
      externalTransactionId: updatedPayment.externalTransactionId,
      confirmationOrigin: updatedPayment.confirmationOrigin,
    },
    createdAt: nowIso,
  };

  let nextLedgerEntries = [...finStore.ledgerEntries];
  if (effectiveTargetStatus === 'PAGO' && !isRevertingFailedRefund) {
    const payConfKey = `ledger-payconf-${booking.id}`;
    const alreadyLoggedConfirmed = nextLedgerEntries.some(
      (e) => e.idempotencyKey === payConfKey
    );
    if (!alreadyLoggedConfirmed) {
      nextLedgerEntries = [
        {
          id: `fl-${Date.now()}-${nextLedgerEntries.length + 1}`,
          bookingId: booking.id,
          bookingCode: booking.code,
          paymentId: updatedPayment.id,
          partnerId: booking.partnerId,
          entryType: 'PAYMENT_CONFIRMED',
          grossDelta: updatedPayment.grossAmount,
          commissionDelta: updatedPayment.platformCommissionAmount,
          netPartnerDelta: updatedPayment.netPartnerAmount,
          currency: 'BRL',
          idempotencyKey: payConfKey,
          description: `Pagamento confirmado (${updatedPayment.paymentMethod} • Origem: ${confirmationOrigin} • Ref: ${updatedPayment.externalTransactionId})`,
          actorId: authCtx.actorId,
          actorRole: authCheck.data.effectiveRole,
          createdAt: nowIso,
        },
        ...nextLedgerEntries,
      ];
    }
  } else if (effectiveTargetStatus === 'CANCELADO') {
    // Se havia apenas provisão sem confirmação de pagamento, reverte a provisão para zerar soma
    const hasConfirmedPaymentEntry = nextLedgerEntries.some(
      (e) => e.bookingId === booking.id && e.entryType === 'PAYMENT_CONFIRMED'
    );
    const hasProvisionedEntry = nextLedgerEntries.some(
      (e) =>
        e.bookingId === booking.id && e.entryType === 'COMMISSION_PROVISIONED'
    );
    const cancelRevKey = `ledger-cancel-unpaid-${booking.id}`;
    const alreadyReversed = nextLedgerEntries.some(
      (e) => e.idempotencyKey === cancelRevKey
    );
    if (hasProvisionedEntry && !hasConfirmedPaymentEntry && !alreadyReversed) {
      nextLedgerEntries = [
        {
          id: `fl-${Date.now()}-${nextLedgerEntries.length + 1}`,
          bookingId: booking.id,
          bookingCode: booking.code,
          paymentId: updatedPayment.id,
          partnerId: booking.partnerId,
          entryType: 'COMPENSATORY_ADJUSTMENT',
          grossDelta: 0,
          commissionDelta: 0,
          netPartnerDelta: 0,
          currency: 'BRL',
          idempotencyKey: cancelRevKey,
          description: `Baixa de provisão por cancelamento de pagamento não confirmado (${cleanReason})`,
          actorId: authCtx.actorId,
          actorRole: authCheck.data.effectiveRole,
          createdAt: nowIso,
        },
        ...nextLedgerEntries,
      ];
    }
  }

  let updatedBooking: OperationalBookingRecord = { ...booking };
  const currentBkStatus = normalizeBookingStatus(booking.status);

  if (effectiveTargetStatus === 'PAGO' && !isRevertingFailedRefund) {
    const nextBkStatus: BookingStatusType =
      currentBkStatus === 'SOLICITADA' ||
      currentBkStatus === 'AGUARDANDO_CONFIRMACAO'
        ? 'CONFIRMADA'
        : currentBkStatus;
    const nextLedger: LedgerStatusType =
      nextBkStatus === 'PASSEIO_REALIZADO'
        ? 'CONFIRMADA'
        : deriveLedgerStatusFromBookingStatus(
            nextBkStatus,
            booking.ledgerStatus
          );
    updatedBooking = {
      ...booking,
      status: nextBkStatus,
      ledgerStatus: nextLedger,
      commissionConsolidated: nextBkStatus === 'PASSEIO_REALIZADO',
    };
  } else if (
    (effectiveTargetStatus === 'CANCELADO' ||
      (effectiveTargetStatus === 'FALHOU' && markCancelledFlag)) &&
    currentBkStatus !== 'PASSEIO_REALIZADO'
  ) {
    updatedBooking = {
      ...booking,
      status: 'CANCELADA',
      ledgerStatus: 'REVERTIDA',
      commissionConsolidated: false,
      rejectionReason: cleanReason || booking.rejectionReason,
    };
  }

  const opHistoryEntry: OperationalHistoryEntry = {
    id: `hist-pay-${Date.now()}-${opState.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'BOOKING',
    entityId: booking.id,
    entityName: booking.code,
    partnerId: booking.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    action: `PAYMENT_${effectiveTargetStatus}`,
    summary: `Pagamento da reserva ${booking.code}: ${currentPayment.paymentStatus} -> ${effectiveTargetStatus} (Reserva: ${updatedBooking.status} / Ledger: ${updatedBooking.ledgerStatus}).`,
  };

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    bookings: opState.bookings.map((b) =>
      b.id === booking.id ? updatedBooking : b
    ),
    changeHistory: [opHistoryEntry, ...opState.changeHistory],
    auditLogs: [
      {
        id: `aud-paytr-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || authCtx.actorId || 'Sistema',
        role: authCheck.data.effectiveRole,
        action:
          effectiveTargetStatus === 'PAGO' && !isRevertingFailedRefund
            ? confirmationOrigin === 'GATEWAY_WEBHOOK'
              ? 'PAYMENT_CONFIRMED_GATEWAY'
              : 'PAYMENT_CONFIRMED_MANUAL_ADMIN'
            : isRevertingFailedRefund
            ? 'PAYMENT_REFUND_FAILED_REVERTED'
            : `PAYMENT_STATUS_${effectiveTargetStatus}`,
        target: booking.code,
        details: `${currentPayment.paymentStatus} -> ${effectiveTargetStatus} | Motivo: ${cleanReason || confirmationOrigin}`,
      },
      ...opState.auditLogs,
    ],
  };

  const nextFinStore: FinancialStoreSnapshot = {
    payments: finStore.payments.map((p) =>
      p.id === updatedPayment.id ? updatedPayment : p
    ),
    paymentHistory: [historyEntry, ...finStore.paymentHistory],
    ledgerEntries: nextLedgerEntries,
    processedIdempotencyKeys: {
      ...finStore.processedIdempotencyKeys,
      [cleanIdempKey]: {
        bookingId: booking.id,
        paymentId: updatedPayment.id,
        operation: 'TRANSITION_PAYMENT',
        resultStatus: effectiveTargetStatus,
        timestamp: nowIso,
        payloadFingerprint: {
          operation: 'TRANSITION_PAYMENT',
          bookingId: booking.id,
          targetStatus: input.targetStatus,
          externalTransactionId: cleanTxId,
          reason: cleanReason,
          markBookingCancelled: markCancelledFlag,
          confirmationOrigin,
        },
      },
    },
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: nextFinStore,
      payment: updatedPayment,
      booking: updatedBooking,
      idempotentReplay: false,
    },
  };
}

// ============================================================================
// 6. ESTORNO EM DUAS ETAPAS (F02 & F06):
//    6.1 Solicitação de Estorno (requestBookingRefund -> ESTORNO_PENDENTE)
//    6.2 Confirmação/Processamento Contábil de Estorno (processBookingRefund -> ESTORNADO / ESTORNO_PARCIAL, exclusivo Admin)
//    6.3 Reversão de Estorno Pendente com Falha (revertFailedPendingRefund -> PAGO / ESTORNO_PARCIAL, exclusivo Admin)
// ============================================================================

export interface RequestBookingRefundInput {
  bookingId: string;
  reason: string;
  idempotencyKey: string;
  requestedRefundAmount?: number | null;
}

export interface RequestBookingRefundResult {
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  payment: BookingPaymentRecord;
  requestedRefundAmount: number;
  idempotentReplay: boolean;
}

/**
 * Etapa 1 do Estorno (F02): Registra solicitação de estorno movendo o pagamento
 * de PAGO ou ESTORNO_PARCIAL para ESTORNO_PENDENTE, sem alterar comissões nem
 * lançar reversão no livro-razão antes da confirmação administrativa/gateway.
 */
export function requestBookingRefund(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  input: RequestBookingRefundInput
): OperationResult<RequestBookingRefundResult> {
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 8) {
    return {
      ok: false,
      errorCode: 'IDEMPOTENCY_KEY_REQUIRED',
      errorMessage:
        'Chave de idempotência obrigatória para solicitar estorno (mínimo 8 caracteres).',
    };
  }

  if (authCtx.actorRole === 'tourist') {
    return {
      ok: false,
      errorCode: 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN',
      errorMessage:
        'O perfil turista não pode acionar diretamente a operação financeira de estorno.',
    };
  }

  if (!input.reason || input.reason.trim().length < 5) {
    return {
      ok: false,
      errorCode: 'REFUND_REASON_REQUIRED',
      errorMessage:
        'É obrigatório informar justificativa detalhada (mínimo 5 caracteres) para solicitar estorno.',
    };
  }

  const booking = opState.bookings.find(
    (b) => b.id === input.bookingId || b.code === input.bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${input.bookingId}" não encontrada.`,
    };
  }

  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    booking.partnerId,
    opState
  );
  if (!authCheck.ok || !authCheck.data) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'UNAUTHORIZED_FINANCIAL_OPERATION',
      errorMessage:
        authCheck.errorMessage ||
        'Sem permissão para solicitar estorno desta reserva.',
    };
  }

  const currentPayment = finStore.payments.find(
    (p) => p.bookingId === booking.id
  );
  if (!currentPayment) {
    return {
      ok: false,
      errorCode: 'PAYMENT_RECORD_NOT_FOUND',
      errorMessage: `Nenhum pagamento registrado para a reserva ${booking.code}.`,
    };
  }

  const paidCents = toIntegerCents(currentPayment.paidGrossAmount);
  const alreadyRefundedCents = toIntegerCents(
    currentPayment.refundedGrossAmount
  );
  const remainingRefundableCents = paidCents - alreadyRefundedCents;

  const inputRequestedCents: number | null =
    input.requestedRefundAmount === undefined ||
    input.requestedRefundAmount === null
      ? null
      : toIntegerCents(input.requestedRefundAmount);

  const cleanIdempKey = input.idempotencyKey.trim();
  const cleanReason = input.reason.trim();

  // F06 & D09: Verificação de replay idempotente ANTES de recalcular default sobre saldo pós-estorno
  const existingKeyRecord = finStore.processedIdempotencyKeys[cleanIdempKey];
  if (existingKeyRecord) {
    const fp = existingKeyRecord.payloadFingerprint;
    const amountMatches = fp
      ? inputRequestedCents === null
        ? fp.inputRefundAmountCents === null ||
          fp.inputRefundAmountCents === undefined ||
          fp.refundAmountCents === remainingRefundableCents
        : fp.refundAmountCents === inputRequestedCents
      : true;
    if (
      existingKeyRecord.bookingId !== booking.id ||
      existingKeyRecord.operation !== 'REQUEST_REFUND' ||
      !amountMatches ||
      (fp && (fp.reason || '') !== cleanReason)
    ) {
      return {
        ok: false,
        errorCode: 'FINANCIAL_IDEMPOTENCY_CONFLICT',
        errorMessage:
          'Conflito de idempotência financeira: chave já utilizada em outra solicitação de estorno ou com parâmetros divergentes.',
      };
    }
    const replayRequestedCents =
      fp?.refundAmountCents ??
      (inputRequestedCents ??
        (remainingRefundableCents > 0
          ? remainingRefundableCents
          : toIntegerCents(currentPayment.grossAmount)));
    return {
      ok: true,
      data: {
        operationalState: opState,
        financialStore: finStore,
        payment: currentPayment,
        requestedRefundAmount: fromIntegerCents(replayRequestedCents),
        idempotentReplay: true,
      },
    };
  }

  const requestedCents =
    inputRequestedCents === null
      ? remainingRefundableCents > 0
        ? remainingRefundableCents
        : toIntegerCents(currentPayment.grossAmount)
      : inputRequestedCents;

  if (currentPayment.paymentStatus === 'ESTORNO_PENDENTE') {
    if (
      currentPayment.lastOperationIdempotencyKey === cleanIdempKey &&
      toIntegerCents(
        currentPayment.requestedRefundAmount ??
          fromIntegerCents(remainingRefundableCents)
      ) === requestedCents &&
      (currentPayment.refundReason || '') === cleanReason
    ) {
      return {
        ok: true,
        data: {
          operationalState: opState,
          financialStore: finStore,
          payment: currentPayment,
          requestedRefundAmount: fromIntegerCents(requestedCents),
          idempotentReplay: true,
        },
      };
    }
    return {
      ok: false,
      errorCode: 'REFUND_ALREADY_PENDING',
      errorMessage: `A reserva ${booking.code} já possui uma solicitação de estorno pendente de processamento (ESTORNO_PENDENTE).`,
    };
  }

  if (
    currentPayment.paymentStatus !== 'PAGO' &&
    currentPayment.paymentStatus !== 'ESTORNO_PARCIAL'
  ) {
    return {
      ok: false,
      errorCode: 'REFUND_NOT_ALLOWED_FOR_STATUS',
      errorMessage: `Não é permitido solicitar estorno para pagamento em estado ${currentPayment.paymentStatus}. Apenas pagamentos PAGO ou ESTORNO_PARCIAL aceitam solicitação de estorno.`,
    };
  }

  if (requestedCents <= 0) {
    return {
      ok: false,
      errorCode: 'INVALID_REFUND_AMOUNT',
      errorMessage: 'O valor solicitado para estorno deve ser maior que zero.',
    };
  }

  if (requestedCents > remainingRefundableCents) {
    return {
      ok: false,
      errorCode: 'REFUND_EXCEEDS_REMAINING_PAID',
      errorMessage: `O valor solicitado para estorno (R$ ${fromIntegerCents(requestedCents).toFixed(2)}) excede o saldo disponível (R$ ${fromIntegerCents(remainingRefundableCents).toFixed(2)}).`,
    };
  }

  const nowIso = new Date().toISOString();
  const updatedPayment: BookingPaymentRecord = {
    ...currentPayment,
    paymentStatus: 'ESTORNO_PENDENTE',
    refundReason: cleanReason,
    requestedRefundAmount: fromIntegerCents(requestedCents),
    lastOperationIdempotencyKey: cleanIdempKey,
    updatedBy: authCtx.actorId,
    updatedAt: nowIso,
  };

  const historyEntry: BookingPaymentHistoryEntry = {
    id: `phist-reqref-${Date.now()}-${finStore.paymentHistory.length + 1}`,
    paymentId: updatedPayment.id,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    previousStatus: currentPayment.paymentStatus,
    newStatus: 'ESTORNO_PENDENTE',
    actorId: authCtx.actorId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    idempotencyKey: cleanIdempKey,
    amountSnapshot: updatedPayment.grossAmount,
    refundAmountSnapshot: updatedPayment.refundedGrossAmount,
    reason: `Solicitação de estorno registrada (R$ ${fromIntegerCents(requestedCents).toFixed(2)}): ${cleanReason}`,
    metadata: {
      requestedRefundAmount: fromIntegerCents(requestedCents),
      previousStatus: currentPayment.paymentStatus,
    },
    createdAt: nowIso,
  };

  const opHistoryEntry: OperationalHistoryEntry = {
    id: `hist-reqref-${Date.now()}-${opState.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'BOOKING',
    entityId: booking.id,
    entityName: booking.code,
    partnerId: booking.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    action: 'PAYMENT_ESTORNO_PENDENTE',
    summary: `Solicitação de estorno registrada para reserva ${booking.code} (R$ ${fromIntegerCents(requestedCents).toFixed(2)}) — aguardando confirmação administrativa.`,
  };

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    changeHistory: [opHistoryEntry, ...opState.changeHistory],
    auditLogs: [
      {
        id: `aud-reqref-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || authCtx.actorId || 'Sistema',
        role: authCheck.data.effectiveRole,
        action: 'PAYMENT_REFUND_REQUESTED',
        target: booking.code,
        details: `${currentPayment.paymentStatus} -> ESTORNO_PENDENTE | Solicitado: R$ ${fromIntegerCents(requestedCents).toFixed(2)} | Motivo: ${cleanReason}`,
      },
      ...opState.auditLogs,
    ],
  };

  const nextFinStore: FinancialStoreSnapshot = {
    payments: finStore.payments.map((p) =>
      p.id === updatedPayment.id ? updatedPayment : p
    ),
    paymentHistory: [historyEntry, ...finStore.paymentHistory],
    ledgerEntries: finStore.ledgerEntries,
    processedIdempotencyKeys: {
      ...finStore.processedIdempotencyKeys,
      [cleanIdempKey]: {
        bookingId: booking.id,
        paymentId: updatedPayment.id,
        operation: 'REQUEST_REFUND',
        resultStatus: 'ESTORNO_PENDENTE',
        timestamp: nowIso,
        payloadFingerprint: {
          operation: 'REQUEST_REFUND',
          bookingId: booking.id,
          refundAmountCents: requestedCents,
          inputRefundAmountCents: inputRequestedCents,
          reason: cleanReason,
        },
      },
    },
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: nextFinStore,
      payment: updatedPayment,
      requestedRefundAmount: fromIntegerCents(requestedCents),
      idempotentReplay: false,
    },
  };
}

export interface ProcessBookingRefundInput {
  bookingId: string;
  refundAmount?: number | null; // null ou omitido = estorno integral do saldo pago restante
  reason: string;
  idempotencyKey: string;
  markBookingCancelled?: boolean;
  simulateMidTransactionFailure?: boolean;
}

export interface ProcessBookingRefundResult {
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  payment: BookingPaymentRecord;
  booking: OperationalBookingRecord;
  refundedNowAmount: number;
  reversedCommissionNowAmount: number;
  idempotentReplay: boolean;
}

/**
 * Etapa 2 do Estorno (F02): Confirma e processa contabilmente o estorno
 * (ESTORNO_PENDENTE / PAGO / ESTORNO_PARCIAL -> ESTORNADO ou ESTORNO_PARCIAL).
 * Restrito EXCLUSIVAMENTE ao Administrador (ou gateway servidor).
 */
export function processBookingRefund(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  input: ProcessBookingRefundInput
): OperationResult<ProcessBookingRefundResult> {
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 8) {
    return {
      ok: false,
      errorCode: 'IDEMPOTENCY_KEY_REQUIRED',
      errorMessage:
        'Chave de idempotência obrigatória para processar estorno (mínimo 8 caracteres).',
    };
  }

  // F02: Bloqueio explícito de tourist e partner na confirmação de estorno
  if (authCtx.actorRole === 'tourist') {
    return {
      ok: false,
      errorCode: 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN',
      errorMessage:
        'O perfil turista não pode confirmar ou processar estornos financeiros.',
    };
  }

  if (authCtx.actorRole === 'partner') {
    return {
      ok: false,
      errorCode: 'PARTNER_REFUND_CONFIRM_FORBIDDEN',
      errorMessage:
        'Parceiros podem apenas solicitar estorno (ESTORNO_PENDENTE). A confirmação e processamento contábil do estorno são restritos ao Administrador.',
    };
  }

  if (!input.reason || input.reason.trim().length < 5) {
    return {
      ok: false,
      errorCode: 'REFUND_REASON_REQUIRED',
      errorMessage:
        'É obrigatório informar justificativa detalhada (mínimo 5 caracteres) para confirmar estorno.',
    };
  }

  const booking = opState.bookings.find(
    (b) => b.id === input.bookingId || b.code === input.bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${input.bookingId}" não encontrada para estorno.`,
    };
  }

  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin'],
    booking.partnerId,
    opState
  );
  if (!authCheck.ok || !authCheck.data) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'PARTNER_REFUND_CONFIRM_FORBIDDEN',
      errorMessage:
        authCheck.errorMessage ||
        'Somente o Administrador possui autorização para confirmar e processar estornos.',
    };
  }

  const currentPayment = finStore.payments.find(
    (p) => p.bookingId === booking.id
  );
  if (!currentPayment) {
    return {
      ok: false,
      errorCode: 'PAYMENT_RECORD_NOT_FOUND',
      errorMessage: `Nenhum pagamento registrado para a reserva ${booking.code}.`,
    };
  }

  const paidCents = toIntegerCents(currentPayment.paidGrossAmount);
  const alreadyRefundedCents = toIntegerCents(
    currentPayment.refundedGrossAmount
  );
  const remainingRefundableCents = paidCents - alreadyRefundedCents;

  const inputRefundCents: number | null =
    input.refundAmount === undefined || input.refundAmount === null
      ? null
      : toIntegerCents(input.refundAmount);

  const cleanIdempKey = input.idempotencyKey.trim();
  const cleanReason = input.reason.trim();
  const markCancelledFlag =
    input.markBookingCancelled !== undefined
      ? Boolean(input.markBookingCancelled)
      : true;

  // F06 & D09: Verificação de replay idempotente ANTES de recalcular default sobre saldo pós-estorno
  const existingKeyRecord = finStore.processedIdempotencyKeys[cleanIdempKey];
  if (existingKeyRecord) {
    const fp = existingKeyRecord.payloadFingerprint;
    const amountMatches = fp
      ? inputRefundCents === null
        ? fp.inputRefundAmountCents === null ||
          fp.inputRefundAmountCents === undefined ||
          fp.refundAmountCents === remainingRefundableCents
        : fp.refundAmountCents === inputRefundCents
      : true;
    if (
      existingKeyRecord.bookingId !== booking.id ||
      existingKeyRecord.operation !== 'PROCESS_REFUND' ||
      !amountMatches ||
      (fp &&
        ((fp.reason || '') !== cleanReason ||
          Boolean(fp.markBookingCancelled) !== markCancelledFlag))
    ) {
      return {
        ok: false,
        errorCode: 'FINANCIAL_IDEMPOTENCY_CONFLICT',
        errorMessage:
          'Conflito de idempotência financeira: chave de estorno já utilizada para outra reserva ou com valor/parâmetros divergentes.',
      };
    }
    return {
      ok: true,
      data: {
        operationalState: opState,
        financialStore: finStore,
        payment: currentPayment,
        booking,
        refundedNowAmount: fromIntegerCents(fp?.refundAmountCents ?? 0),
        reversedCommissionNowAmount: fromIntegerCents(
          fp?.reversedCommissionCents ?? 0
        ),
        idempotentReplay: true,
      },
    };
  }

  const requestedRefundCents =
    inputRefundCents === null
      ? currentPayment.requestedRefundAmount != null &&
        toIntegerCents(currentPayment.requestedRefundAmount) > 0
        ? toIntegerCents(currentPayment.requestedRefundAmount)
        : remainingRefundableCents
      : inputRefundCents;

  if (input.simulateMidTransactionFailure) {
    return {
      ok: false,
      errorCode: 'TRANSACTION_ABORTED_ROLLBACK',
      errorMessage: 'Transação de estorno abortada com rollback integral por falha simulada.',
    };
  }

  if (currentPayment.paymentStatus === 'ESTORNADO') {
    return {
      ok: false,
      errorCode: 'REFUND_ALREADY_COMPLETED_DUPLICATE',
      errorMessage: `O pagamento da reserva ${booking.code} já foi integralmente estornado.`,
    };
  }

  if (
    currentPayment.paymentStatus !== 'PAGO' &&
    currentPayment.paymentStatus !== 'ESTORNO_PARCIAL' &&
    currentPayment.paymentStatus !== 'ESTORNO_PENDENTE'
  ) {
    return {
      ok: false,
      errorCode: 'REFUND_NOT_ALLOWED_FOR_STATUS',
      errorMessage: `Não é permitido processar estorno para pagamento em estado ${currentPayment.paymentStatus}.`,
    };
  }

  if (requestedRefundCents <= 0) {
    return {
      ok: false,
      errorCode: 'INVALID_REFUND_AMOUNT',
      errorMessage: 'O valor do estorno deve ser maior que zero.',
    };
  }

  if (requestedRefundCents > remainingRefundableCents) {
    return {
      ok: false,
      errorCode: 'REFUND_EXCEEDS_REMAINING_PAID',
      errorMessage: `O valor solicitado para estorno (R$ ${fromIntegerCents(requestedRefundCents).toFixed(2)}) excede o saldo disponível para reembolso (R$ ${fromIntegerCents(remainingRefundableCents).toFixed(2)}).`,
    };
  }

  if (
    currentPayment.paymentStatus === 'ESTORNO_PENDENTE' &&
    currentPayment.requestedRefundAmount != null &&
    toIntegerCents(currentPayment.requestedRefundAmount) > 0 &&
    requestedRefundCents > toIntegerCents(currentPayment.requestedRefundAmount)
  ) {
    return {
      ok: false,
      errorCode: 'REFUND_EXCEEDS_REQUESTED_AMOUNT',
      errorMessage: `O valor confirmado para estorno (R$ ${fromIntegerCents(requestedRefundCents).toFixed(2)}) excede o valor solicitado pendente (R$ ${currentPayment.requestedRefundAmount.toFixed(2)}).`,
    };
  }

  const newTotalRefundedCents = alreadyRefundedCents + requestedRefundCents;
  const isFullRefund = newTotalRefundedCents === paidCents;
  const nextPaymentStatus: PaymentStatusType = isFullRefund
    ? 'ESTORNADO'
    : 'ESTORNO_PARCIAL';

  const originalCommCents = toIntegerCents(
    currentPayment.platformCommissionAmount
  );
  const alreadyReversedCommCents = toIntegerCents(
    currentPayment.reversedCommissionAmount
  );

  // F07: Cálculo proporcional de estorno de comissão via BigInt HALF_UP sem ponto flutuante
  let targetTotalReversedCommCents: number;
  if (isFullRefund) {
    targetTotalReversedCommCents = originalCommCents;
  } else {
    targetTotalReversedCommCents = Number(
      roundHalfUpBigIntDivision(
        BigInt(originalCommCents) * BigInt(newTotalRefundedCents),
        BigInt(paidCents)
      )
    );
    targetTotalReversedCommCents = Math.min(
      originalCommCents,
      Math.max(alreadyReversedCommCents, targetTotalReversedCommCents)
    );
  }

  const reversedCommNowCents =
    targetTotalReversedCommCents - alreadyReversedCommCents;
  const newEffectiveCommCents =
    originalCommCents - targetTotalReversedCommCents;
  const retainedGrossCents = paidCents - newTotalRefundedCents;
  const newEffectiveNetPartnerCents = retainedGrossCents - newEffectiveCommCents;
  const netPartnerReductionNowCents =
    requestedRefundCents - reversedCommNowCents;

  const nowIso = new Date().toISOString();

  const updatedPayment: BookingPaymentRecord = {
    ...currentPayment,
    paymentStatus: nextPaymentStatus,
    refundedGrossAmount: fromIntegerCents(newTotalRefundedCents),
    reversedCommissionAmount: fromIntegerCents(targetTotalReversedCommCents),
    effectiveGrossAmount: fromIntegerCents(retainedGrossCents),
    effectiveCommissionAmount: fromIntegerCents(newEffectiveCommCents),
    effectiveNetPartnerAmount: fromIntegerCents(newEffectiveNetPartnerCents),
    refundReason: cleanReason,
    requestedRefundAmount: null,
    lastOperationIdempotencyKey: cleanIdempKey,
    refundedAt: nowIso,
    updatedBy: authCtx.actorId,
    updatedAt: nowIso,
  };

  const consistencyCheck = validateFinancialConsistency({
    grossAmount: updatedPayment.grossAmount,
    commissionAmount: updatedPayment.platformCommissionAmount,
    netPartnerAmount: updatedPayment.netPartnerAmount,
    paidGrossAmount: updatedPayment.paidGrossAmount,
    refundedGrossAmount: updatedPayment.refundedGrossAmount,
    reversedCommissionAmount: updatedPayment.reversedCommissionAmount,
    effectiveCommissionAmount: updatedPayment.effectiveCommissionAmount,
    effectiveNetPartnerAmount: updatedPayment.effectiveNetPartnerAmount,
  });
  if (!consistencyCheck.ok) {
    return {
      ok: false,
      errorCode: consistencyCheck.errorCode,
      errorMessage: consistencyCheck.errorMessage,
    };
  }

  // D10: Quando o Admin processa estorno direto sobre pagamento em PAGO ou ESTORNO_PARCIAL,
  // registra a solicitação administrativa implícita (ESTORNO_PENDENTE / REFUND_REQUESTED)
  // antes da finalização para manter a trilha em 2 etapas consistente na conciliação financeira
  const implicitAdminReqEntry: BookingPaymentHistoryEntry | null =
    currentPayment.paymentStatus !== 'ESTORNO_PENDENTE'
      ? {
          id: `phist-admreq-${Date.now()}-${finStore.paymentHistory.length + 1}`,
          paymentId: updatedPayment.id,
          bookingId: booking.id,
          bookingCode: booking.code,
          partnerId: booking.partnerId,
          previousStatus: currentPayment.paymentStatus,
          newStatus: 'ESTORNO_PENDENTE',
          actorId: authCtx.actorId,
          actorRole: authCheck.data.effectiveRole,
          actorName: authCtx.actorName,
          idempotencyKey: `adm-req-${cleanIdempKey}`,
          amountSnapshot: updatedPayment.grossAmount,
          refundAmountSnapshot: currentPayment.refundedGrossAmount,
          reason: `Solicitação administrativa direta de estorno: ${cleanReason}`,
          metadata: {
            operationType: 'REFUND_REQUESTED',
            requestedRefundAmount: fromIntegerCents(requestedRefundCents),
            implicitAdminDirectRefund: true,
          },
          createdAt: nowIso,
        }
      : null;

  const historyEntry: BookingPaymentHistoryEntry = {
    id: `phist-${Date.now()}-${finStore.paymentHistory.length + 2}`,
    paymentId: updatedPayment.id,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    previousStatus: 'ESTORNO_PENDENTE',
    newStatus: nextPaymentStatus,
    actorId: authCtx.actorId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    idempotencyKey: cleanIdempKey,
    amountSnapshot: updatedPayment.grossAmount,
    refundAmountSnapshot: updatedPayment.refundedGrossAmount,
    reason: cleanReason,
    metadata: {
      operationType: isFullRefund ? 'REFUND_FULL' : 'REFUND_PARTIAL',
      refundedNowAmount: fromIntegerCents(requestedRefundCents),
      reversedCommissionNowAmount: fromIntegerCents(reversedCommNowCents),
      isFullRefund,
    },
    createdAt: nowIso,
  };

  const refundLedgerEntry: FinancialLedgerEntry = {
    id: `fl-ref-${Date.now()}-${finStore.ledgerEntries.length + 1}`,
    bookingId: booking.id,
    bookingCode: booking.code,
    paymentId: updatedPayment.id,
    partnerId: booking.partnerId,
    entryType: isFullRefund ? 'REFUND_FULL' : 'REFUND_PARTIAL',
    grossDelta: -fromIntegerCents(requestedRefundCents),
    commissionDelta: -fromIntegerCents(reversedCommNowCents),
    netPartnerDelta: -fromIntegerCents(netPartnerReductionNowCents),
    currency: 'BRL',
    idempotencyKey: `ledger-ref-${cleanIdempKey}`,
    description: `${isFullRefund ? 'Estorno integral' : 'Estorno parcial'} da reserva ${booking.code}: ${cleanReason}`,
    actorId: authCtx.actorId,
    actorRole: authCheck.data.effectiveRole,
    createdAt: nowIso,
  };

  const commReversalEntry: FinancialLedgerEntry = {
    id: `fl-crev-${Date.now()}-${finStore.ledgerEntries.length + 2}`,
    bookingId: booking.id,
    bookingCode: booking.code,
    paymentId: updatedPayment.id,
    partnerId: booking.partnerId,
    entryType: isFullRefund
      ? 'COMMISSION_REVERSAL_FULL'
      : 'COMMISSION_REVERSAL_PARTIAL',
    grossDelta: 0,
    commissionDelta: 0,
    netPartnerDelta: 0,
    currency: 'BRL',
    idempotencyKey: `ledger-crev-${cleanIdempKey}`,
    description: `Marco de reversão ${isFullRefund ? 'integral' : 'proporcional'} de comissão (R$ ${fromIntegerCents(reversedCommNowCents).toFixed(2)} abatidos no lançamento de estorno) da reserva ${booking.code}`,
    actorId: authCtx.actorId,
    actorRole: authCheck.data.effectiveRole,
    createdAt: nowIso,
  };

  const shouldCancelBooking = isFullRefund && markCancelledFlag;
  const currentBkStatus = normalizeBookingStatus(booking.status);
  const nextBkStatus: BookingStatusType =
    shouldCancelBooking && currentBkStatus !== 'PASSEIO_REALIZADO'
      ? 'CANCELADA'
      : currentBkStatus;
  const nextLedgerStatus: LedgerStatusType = isFullRefund
    ? 'REVERTIDA'
    : booking.ledgerStatus;

  const updatedBooking: OperationalBookingRecord = {
    ...booking,
    status: nextBkStatus,
    ledgerStatus: nextLedgerStatus,
    commissionConsolidated:
      !isFullRefund && nextBkStatus === 'PASSEIO_REALIZADO',
    rejectionReason: shouldCancelBooking
      ? cleanReason
      : booking.rejectionReason,
  };

  const opHistoryEntry: OperationalHistoryEntry = {
    id: `hist-ref-${Date.now()}-${opState.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'BOOKING',
    entityId: booking.id,
    entityName: booking.code,
    partnerId: booking.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName,
    action: `PAYMENT_${nextPaymentStatus}`,
    summary: `Estorno confirmado na reserva ${booking.code}: R$ ${fromIntegerCents(requestedRefundCents).toFixed(2)} (${nextPaymentStatus}). Comissão efetiva: R$ ${updatedPayment.effectiveCommissionAmount.toFixed(2)} | Líquido parceiro: R$ ${updatedPayment.effectiveNetPartnerAmount.toFixed(2)}.`,
  };

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    bookings: opState.bookings.map((b) =>
      b.id === booking.id ? updatedBooking : b
    ),
    changeHistory: [opHistoryEntry, ...opState.changeHistory],
    auditLogs: [
      {
        id: `aud-ref-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || authCtx.actorId || 'Admin Master',
        role: authCheck.data.effectiveRole,
        action: 'PAYMENT_REFUND_PROCESSED',
        target: booking.code,
        details: `${currentPayment.paymentStatus} -> ${nextPaymentStatus} | Estornado: R$ ${fromIntegerCents(requestedRefundCents).toFixed(2)} | Motivo: ${cleanReason}`,
      },
      ...opState.auditLogs,
    ],
  };

  const nextFinStore: FinancialStoreSnapshot = {
    payments: finStore.payments.map((p) =>
      p.id === updatedPayment.id ? updatedPayment : p
    ),
    paymentHistory: implicitAdminReqEntry
      ? [historyEntry, implicitAdminReqEntry, ...finStore.paymentHistory]
      : [historyEntry, ...finStore.paymentHistory],
    ledgerEntries: [
      refundLedgerEntry,
      commReversalEntry,
      ...finStore.ledgerEntries,
    ],
    processedIdempotencyKeys: {
      ...finStore.processedIdempotencyKeys,
      [cleanIdempKey]: {
        bookingId: booking.id,
        paymentId: updatedPayment.id,
        operation: 'PROCESS_REFUND',
        resultStatus: nextPaymentStatus,
        timestamp: nowIso,
        payloadFingerprint: {
          operation: 'PROCESS_REFUND',
          bookingId: booking.id,
          refundAmountCents: requestedRefundCents,
          inputRefundAmountCents: inputRefundCents,
          reversedCommissionCents: reversedCommNowCents,
          reason: cleanReason,
          markBookingCancelled: markCancelledFlag,
        },
      },
    },
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: nextFinStore,
      payment: updatedPayment,
      booking: updatedBooking,
      refundedNowAmount: fromIntegerCents(requestedRefundCents),
      reversedCommissionNowAmount: fromIntegerCents(reversedCommNowCents),
      idempotentReplay: false,
    },
  };
}

/**
 * Reverte uma solicitação de estorno pendente (ESTORNO_PENDENTE) quando o processamento
 * falha no adquirente/gateway, retornando coerentemente a PAGO (se não houve estorno prévio)
 * ou ESTORNO_PARCIAL (se já havia estorno parcial confirmado).
 */
export function revertFailedPendingRefund(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  params: {
    bookingId: string;
    idempotencyKey: string;
    reason: string;
  }
): OperationResult<TransitionBookingPaymentResult> {
  const booking = opState.bookings.find(
    (b) => b.id === params.bookingId || b.code === params.bookingId
  );
  const currentPay = booking
    ? finStore.payments.find((p) => p.bookingId === booking.id)
    : undefined;
  const revertTarget: 'PAGO' | 'ESTORNO_PARCIAL' =
    currentPay && toIntegerCents(currentPay.refundedGrossAmount) > 0
      ? 'ESTORNO_PARCIAL'
      : 'PAGO';
  return transitionBookingPaymentStatus(opState, finStore, authCtx, {
    bookingId: params.bookingId,
    targetStatus: revertTarget,
    idempotencyKey: params.idempotencyKey,
    reason: params.reason,
    confirmationOrigin: 'MANUAL_ADMIN',
  });
}

// ============================================================================
// 7. SINCRONIZAÇÃO FINANCEIRA EM CANCELAMENTOS E LIQUIDAÇÃO (F02 & F04)
//    - NUNCA eleva artificialmente o perfil tourist a admin!
//    - Reserva com pagamento PAGO ou ESTORNO_PARCIAL -> transita pagamento para
//      ESTORNO_PENDENTE (aguardando confirmação administrativa).
//    - Reserva com pagamento PENDENTE, PROCESSANDO ou FALHOU -> transita para CANCELADO.
// ============================================================================

export function handleBookingCancellationFinancialSync(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  bookingId: string,
  reason: string
): OperationResult<{
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  actionTaken:
    | 'NO_PAYMENT_RECORD'
    | 'CANCELLED_UNPAID_PAYMENT'
    | 'MARKED_REFUND_PENDING'
    | 'REFUNDED_PAID_PAYMENT'
    | 'ALREADY_SETTLED';
}> {
  const booking = opState.bookings.find(
    (b) => b.id === bookingId || b.code === bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${bookingId}" não encontrada para sincronização financeira de cancelamento.`,
    };
  }

  const cleanReason =
    (reason || '').trim().length >= 5
      ? reason.trim()
      : 'Cancelamento da reserva sincronizado com o módulo financeiro';
  const nowIso = new Date().toISOString();

  const payment = finStore.payments.find((p) => p.bookingId === booking.id);
  if (!payment) {
    // Cria registro financeiro encerrado como CANCELADO para manter paridade entre as 5 tabelas
    const closedPayment: BookingPaymentRecord = {
      id: `pay-${booking.id}`,
      bookingId: booking.id,
      bookingCode: booking.code,
      partnerId: booking.partnerId,
      tourId: booking.tourId,
      paymentMethod: booking.channel === 'WHATSAPP' ? 'PIX' : 'LINK_PAGAMENTO',
      paymentStatus: 'CANCELADO',
      currency: 'BRL',
      grossAmount: roundCurrencyExact(booking.grossAmount),
      paidGrossAmount: 0,
      refundedGrossAmount: 0,
      commissionAmount: roundCurrencyExact(booking.commissionAmount),
      platformCommissionAmount: roundCurrencyExact(booking.commissionAmount),
      reversedCommissionAmount: roundCurrencyExact(booking.commissionAmount),
      effectiveGrossAmount: 0,
      effectiveCommissionAmount: 0,
      netPartnerAmount: roundCurrencyExact(booking.netPartnerAmount),
      effectiveNetPartnerAmount: 0,
      commissionModelSnapshot: 'PERCENTAGE',
      commissionRateSnapshot: 15,
      commissionFixedSnapshot: 0,
      commissionRuleLabel:
        booking.commissionRuleUsed || 'Cancelada sem cobrança',
      commissionRuleSnapshot: {
        commissionModel: 'PERCENTAGE',
        commissionRate: 15,
        commissionFixed: 0,
        commissionRuleLabel: booking.commissionRuleUsed || 'Cancelada sem cobrança',
      },
      idempotencyKey: `cancel-init-${booking.id}`,
      lastOperationIdempotencyKey: `cancel-sync-${booking.id}`,
      externalPaymentReference: null,
      externalTransactionId: null,
      confirmationOrigin: null,
      failureReason: cleanReason,
      refundReason: null,
      requestedRefundAmount: null,
      paidAt: null,
      failedAt: null,
      cancelledAt: nowIso,
      refundedAt: null,
      createdBy: authCtx.actorId,
      updatedBy: authCtx.actorId,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const closedHist: BookingPaymentHistoryEntry = {
      id: `phist-canc-${Date.now()}-${finStore.paymentHistory.length + 1}`,
      paymentId: closedPayment.id,
      bookingId: booking.id,
      bookingCode: booking.code,
      partnerId: booking.partnerId,
      previousStatus: null,
      newStatus: 'CANCELADO',
      actorId: authCtx.actorId,
      actorRole: authCtx.actorRole,
      actorName: authCtx.actorName,
      idempotencyKey: `cancel-sync-${booking.id}`,
      amountSnapshot: closedPayment.grossAmount,
      refundAmountSnapshot: 0,
      reason: cleanReason,
      metadata: { syncSource: 'BOOKING_CANCELLATION' },
      createdAt: nowIso,
    };

    return {
      ok: true,
      data: {
        operationalState: {
          ...opState,
          bookings: opState.bookings.map((b) =>
            b.id === booking.id
              ? {
                  ...b,
                  status:
                    b.status === 'RECUSADA' ? 'RECUSADA' : 'CANCELADA',
                  ledgerStatus: 'REVERTIDA',
                  commissionConsolidated: false,
                  rejectionReason: cleanReason,
                }
              : b
          ),
        },
        financialStore: {
          ...finStore,
          payments: [closedPayment, ...finStore.payments],
          paymentHistory: [closedHist, ...finStore.paymentHistory],
        },
        actionTaken: 'CANCELLED_UNPAID_PAYMENT',
      },
    };
  }

  if (
    payment.paymentStatus === 'CANCELADO' ||
    payment.paymentStatus === 'ESTORNADO'
  ) {
    return {
      ok: true,
      data: {
        operationalState: opState,
        financialStore: finStore,
        actionTaken: 'ALREADY_SETTLED',
      },
    };
  }

  if (
    payment.paymentStatus === 'PENDENTE' ||
    payment.paymentStatus === 'PROCESSANDO' ||
    payment.paymentStatus === 'FALHOU'
  ) {
    // Cancela o pagamento não confirmado preservando o papel real do ator (sem elevação artificial)
    const updatedPayment: BookingPaymentRecord = {
      ...payment,
      paymentStatus: 'CANCELADO',
      reversedCommissionAmount: payment.platformCommissionAmount,
      effectiveGrossAmount: 0,
      effectiveCommissionAmount: 0,
      effectiveNetPartnerAmount: 0,
      failureReason: cleanReason,
      lastOperationIdempotencyKey: `cancel-unpaid-${booking.id}`,
      cancelledAt: nowIso,
      updatedBy: authCtx.actorId,
      updatedAt: nowIso,
    };

    const historyEntry: BookingPaymentHistoryEntry = {
      id: `phist-canc-${Date.now()}-${finStore.paymentHistory.length + 1}`,
      paymentId: updatedPayment.id,
      bookingId: booking.id,
      bookingCode: booking.code,
      partnerId: booking.partnerId,
      previousStatus: payment.paymentStatus,
      newStatus: 'CANCELADO',
      actorId: authCtx.actorId,
      actorRole: authCtx.actorRole,
      actorName: authCtx.actorName,
      idempotencyKey: `cancel-unpaid-${booking.id}`,
      amountSnapshot: updatedPayment.grossAmount,
      refundAmountSnapshot: 0,
      reason: cleanReason,
      metadata: { syncSource: 'BOOKING_CANCELLATION' },
      createdAt: nowIso,
    };

    let nextLedgerEntries = [...finStore.ledgerEntries];
    const hasConfirmedPaymentEntry = nextLedgerEntries.some(
      (e) => e.bookingId === booking.id && e.entryType === 'PAYMENT_CONFIRMED'
    );
    const hasProvisionedEntry = nextLedgerEntries.some(
      (e) =>
        e.bookingId === booking.id && e.entryType === 'COMMISSION_PROVISIONED'
    );
    const cancelRevKey = `ledger-cancel-unpaid-${booking.id}`;
    const alreadyReversed = nextLedgerEntries.some(
      (e) => e.idempotencyKey === cancelRevKey
    );
    if (hasProvisionedEntry && !hasConfirmedPaymentEntry && !alreadyReversed) {
      nextLedgerEntries = [
        {
          id: `fl-${Date.now()}-${nextLedgerEntries.length + 1}`,
          bookingId: booking.id,
          bookingCode: booking.code,
          paymentId: updatedPayment.id,
          partnerId: booking.partnerId,
          entryType: 'COMPENSATORY_ADJUSTMENT',
          grossDelta: 0,
          commissionDelta: 0,
          netPartnerDelta: 0,
          currency: 'BRL',
          idempotencyKey: cancelRevKey,
          description: `Baixa de provisão por cancelamento da reserva ${booking.code}: ${cleanReason}`,
          actorId: authCtx.actorId,
          actorRole: authCtx.actorRole,
          createdAt: nowIso,
        },
        ...nextLedgerEntries,
      ];
    }

    const nextOpState: OperationalStateSnapshot = {
      ...opState,
      bookings: opState.bookings.map((b) =>
        b.id === booking.id
          ? {
              ...b,
              status: b.status === 'RECUSADA' ? 'RECUSADA' : 'CANCELADA',
              ledgerStatus: 'REVERTIDA',
              commissionConsolidated: false,
              rejectionReason: cleanReason,
            }
          : b
      ),
    };

    return {
      ok: true,
      data: {
        operationalState: nextOpState,
        financialStore: {
          ...finStore,
          payments: finStore.payments.map((p) =>
            p.id === updatedPayment.id ? updatedPayment : p
          ),
          paymentHistory: [historyEntry, ...finStore.paymentHistory],
          ledgerEntries: nextLedgerEntries,
        },
        actionTaken: 'CANCELLED_UNPAID_PAYMENT',
      },
    };
  }

  // F02 & F04: Reserva com pagamento PAGO ou ESTORNO_PARCIAL vai para ESTORNO_PENDENTE
  // (NUNCA marca como ESTORNADO automaticamente sem confirmação administrativa!)
  const remainingRefundable = fromIntegerCents(
    Math.max(
      0,
      toIntegerCents(payment.paidGrossAmount) -
        toIntegerCents(payment.refundedGrossAmount)
    )
  );

  const pendingRefundPayment: BookingPaymentRecord = {
    ...payment,
    paymentStatus: 'ESTORNO_PENDENTE',
    refundReason: cleanReason,
    requestedRefundAmount: remainingRefundable,
    lastOperationIdempotencyKey: `cancel-refpend-${booking.id}`,
    updatedBy: authCtx.actorId,
    updatedAt: nowIso,
  };

  const pendingHistEntry: BookingPaymentHistoryEntry = {
    id: `phist-refpend-${Date.now()}-${finStore.paymentHistory.length + 1}`,
    paymentId: pendingRefundPayment.id,
    bookingId: booking.id,
    bookingCode: booking.code,
    partnerId: booking.partnerId,
    previousStatus: payment.paymentStatus,
    newStatus: 'ESTORNO_PENDENTE',
    actorId: authCtx.actorId,
    actorRole: authCtx.actorRole,
    actorName: authCtx.actorName,
    idempotencyKey: `cancel-refpend-${booking.id}`,
    amountSnapshot: pendingRefundPayment.grossAmount,
    refundAmountSnapshot: pendingRefundPayment.refundedGrossAmount,
    reason: `Reserva cancelada; pagamento movido para ESTORNO_PENDENTE aguardando confirmação administrativa: ${cleanReason}`,
    metadata: {
      syncSource: 'BOOKING_CANCELLATION',
      requestedRefundAmount: remainingRefundable,
    },
    createdAt: nowIso,
  };

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    bookings: opState.bookings.map((b) =>
      b.id === booking.id
        ? {
            ...b,
            status: b.status === 'RECUSADA' ? 'RECUSADA' : 'CANCELADA',
            ledgerStatus: 'REVERTIDA',
            commissionConsolidated: false,
            rejectionReason: cleanReason,
          }
        : b
    ),
    auditLogs: [
      {
        id: `aud-cancrefp-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || authCtx.actorId || 'Sistema',
        role: authCtx.actorRole,
        action: 'BOOKING_CANCEL_PAYMENT_REFUND_PENDING',
        target: booking.code,
        details: `Reserva cancelada com pagamento confirmado (${payment.paymentStatus} -> ESTORNO_PENDENTE | Saldo a estornar: R$ ${remainingRefundable.toFixed(2)})`,
      },
      ...opState.auditLogs,
    ],
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: {
        ...finStore,
        payments: finStore.payments.map((p) =>
          p.id === pendingRefundPayment.id ? pendingRefundPayment : p
        ),
        paymentHistory: [pendingHistEntry, ...finStore.paymentHistory],
      },
      actionTaken: 'MARKED_REFUND_PENDING',
    },
  };
}

/**
 * Liquida comissão/repasse ao parceiro (ledgerStatus = PAGA) no store local/operacional (F04-D),
 * exigindo que a reserva esteja em PASSEIO_REALIZADO e possua pagamento confirmado
 * (PAGO ou ESTORNO_PARCIAL com líquido efetivo > 0).
 */
export function settleBookingCommissionInStore(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  params: {
    bookingId: string;
    adjustmentNotes?: string | null;
  }
): OperationResult<{
  operationalState: OperationalStateSnapshot;
  financialStore: FinancialStoreSnapshot;
  booking: OperationalBookingRecord;
}> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin']);
  if (!authCheck.ok) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'ADMIN_ACCESS_REQUIRED',
      errorMessage:
        authCheck.errorMessage ||
        'Somente o Administrador pode liquidar comissões e repasses a parceiros.',
    };
  }

  const booking = opState.bookings.find(
    (b) => b.id === params.bookingId || b.code === params.bookingId
  );
  if (!booking) {
    return {
      ok: false,
      errorCode: 'BOOKING_NOT_FOUND',
      errorMessage: `Reserva "${params.bookingId}" não encontrada.`,
    };
  }

  if (booking.ledgerStatus === 'PAGA') {
    return {
      ok: false,
      errorCode: 'LEDGER_ALREADY_PAID',
      errorMessage: `A comissão da reserva ${booking.code} já foi liquidada anteriormente (status: PAGA).`,
    };
  }

  const normStatus = normalizeBookingStatus(booking.status);
  if (normStatus !== 'PASSEIO_REALIZADO' || booking.ledgerStatus !== 'CONFIRMADA') {
    return {
      ok: false,
      errorCode: 'LEDGER_SETTLEMENT_FORBIDDEN',
      errorMessage: `Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (reserva: ${normStatus}, ledger: ${booking.ledgerStatus}).`,
    };
  }

  const payment = finStore.payments.find((p) => p.bookingId === booking.id);
  if (
    !payment ||
    (payment.paymentStatus !== 'PAGO' &&
      payment.paymentStatus !== 'ESTORNO_PARCIAL') ||
    toIntegerCents(payment.effectiveNetPartnerAmount) <= 0
  ) {
    return {
      ok: false,
      errorCode: 'LEDGER_SETTLEMENT_REQUIRES_CONFIRMED_PAYMENT',
      errorMessage: `A liquidação de comissão e repasse da reserva ${booking.code} exige pagamento confirmado (PAGO ou ESTORNO_PARCIAL com saldo líquido positivo). Status financeiro atual: ${payment?.paymentStatus || 'SEM_PAGAMENTO'}.`,
    };
  }

  const nowIso = new Date().toISOString();
  const payoutKey = `ledger-payout-settled-${booking.id}`;
  const alreadySettledEntry = finStore.ledgerEntries.some(
    (e) => e.idempotencyKey === payoutKey
  );

  const nextLedgerEntries = alreadySettledEntry
    ? finStore.ledgerEntries
    : [
        {
          id: `fl-settle-${Date.now()}-${finStore.ledgerEntries.length + 1}`,
          bookingId: booking.id,
          bookingCode: booking.code,
          paymentId: payment.id,
          partnerId: booking.partnerId,
          entryType: 'PARTNER_PAYOUT_SETTLED' as FinancialEntryType,
          grossDelta: 0,
          commissionDelta: 0,
          netPartnerDelta: 0,
          currency: 'BRL' as const,
          idempotencyKey: payoutKey,
          description:
            (params.adjustmentNotes || '').trim() ||
            `Liquidação de repasse ao parceiro e comissão da reserva ${booking.code} (Líquido: R$ ${payment.effectiveNetPartnerAmount.toFixed(2)})`,
          actorId: authCtx.actorId,
          actorRole: 'admin' as AppRole,
          createdAt: nowIso,
        },
        ...finStore.ledgerEntries,
      ];

  const updatedBooking: OperationalBookingRecord = {
    ...booking,
    ledgerStatus: 'PAGA',
    commissionConsolidated: true,
  };

  const nextOpState: OperationalStateSnapshot = {
    ...opState,
    bookings: opState.bookings.map((b) =>
      b.id === booking.id ? updatedBooking : b
    ),
    auditLogs: [
      {
        id: `aud-settle-${Date.now()}-${opState.auditLogs.length + 1}`,
        timestamp: nowIso,
        actor: authCtx.actorName || 'Admin Master',
        role: 'admin',
        action: 'SETTLE_COMMISSION_LEDGER',
        target: booking.code,
        details: `Comissão e repasse liquidados (PAGA) | Líquido Parceiro: R$ ${payment.effectiveNetPartnerAmount.toFixed(2)}`,
      },
      ...opState.auditLogs,
    ],
  };

  return {
    ok: true,
    data: {
      operationalState: nextOpState,
      financialStore: {
        ...finStore,
        ledgerEntries: nextLedgerEntries,
      },
      booking: updatedBooking,
    },
  };
}

// ============================================================================
// 8. CONCILIAÇÃO FINANCEIRA COMPLETA ENTRE AS 5 ENTIDADES (F05)
// ============================================================================

export type FinancialDivergenceCode =
  | 'VALUE_FORMULA_MISMATCH'
  | 'GROSS_MISMATCH_WITH_BOOKING'
  | 'COMMISSION_EXCEEDS_GROSS'
  | 'COMPLETED_BOOKING_UNPAID'
  | 'CANCELLED_BOOKING_UNREFUNDED_PAYMENT'
  | 'SETTLED_COMMISSION_WITHOUT_CONFIRMED_PAYMENT'
  | 'INCONSISTENT_REFUND_STATE'
  | 'REFUND_WITHOUT_REQUEST'
  | 'PENDING_REFUND_IMPROPERLY_FINALIZED'
  | 'DUPLICATE_LEDGER_ENTRY'
  | 'ORPHAN_PAYMENT_WITHOUT_BOOKING'
  | 'ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT'
  | 'PAYMENT_HISTORY_MISMATCH'
  | 'LEDGER_ENTRIES_SUM_MISMATCH';

export interface FinancialReconciliationItem {
  bookingId: string;
  bookingCode: string;
  partnerId: string;
  partnerName: string;
  tourTitle: string;
  bookingDate: string;
  bookingStatus: BookingStatusType;
  ledgerStatus: LedgerStatusType;
  paymentStatus: PaymentStatusType | 'SEM_REGISTRO_PAGAMENTO';
  expectedGrossAmount: number;
  recordedGrossAmount: number;
  paidGrossAmount: number;
  refundedGrossAmount: number;
  expectedCommissionAmount: number;
  effectiveCommissionAmount: number;
  expectedNetPartnerAmount: number;
  effectiveNetPartnerAmount: number;
  isReconciled: boolean;
  divergences: {
    code: FinancialDivergenceCode;
    description: string;
  }[];
}

export interface FinancialReconciliationReport {
  generatedAt: string;
  partnerFilter: string | null;
  isHealthy: boolean;
  discrepanciesCount: number;
  totalBookingsAudited: number;
  reconciledCount: number;
  divergentCount: number;
  orphanPaymentsCount: number;
  orphanHistoryCount?: number;
  summaryMetrics: {
    totalGrossExpected: number;
    totalPaidConfirmed: number;
    totalRefunded: number;
    totalPendingCollection: number;
    totalCommissionProvisioned: number;
    totalCommissionConsolidated: number;
    totalCommissionReversed: number;
    totalNetPartnerConsolidated: number;
    totalNetPartnerPending: number;
  };
  items: FinancialReconciliationItem[];
}

export function runFinancialReconciliation(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  partnerFilterId?: string | null
): OperationResult<FinancialReconciliationReport> {
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    authCtx.actorRole === 'partner'
      ? partnerFilterId || authCtx.actorPartnerId
      : undefined,
    opState
  );
  if (!authCheck.ok || !authCheck.data) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'UNAUTHORIZED_RECONCILIATION',
      errorMessage:
        authCheck.errorMessage ||
        'Sem permissão para executar conciliação financeira.',
    };
  }

  const effectivePartnerScope =
    authCheck.data.effectiveRole === 'partner'
      ? authCheck.data.authorizedPartnerId
      : partnerFilterId && partnerFilterId !== 'TODOS'
      ? partnerFilterId
      : null;

  const scopedBookings = opState.bookings.filter((b) =>
    effectivePartnerScope ? b.partnerId === effectivePartnerScope : true
  );
  const bookingIdsSet = new Set(opState.bookings.map((b) => b.id));

  let totalGrossExpectedCents = 0;
  let totalPaidConfirmedCents = 0;
  let totalRefundedCents = 0;
  let totalPendingCollectionCents = 0;
  let totalCommissionProvisionedCents = 0;
  let totalCommissionConsolidatedCents = 0;
  let totalCommissionReversedCents = 0;
  let totalNetPartnerConsolidatedCents = 0;
  let totalNetPartnerPendingCents = 0;

  const items: FinancialReconciliationItem[] = [];

  for (const bk of scopedBookings) {
    const normBkStatus = normalizeBookingStatus(bk.status);
    const payment = finStore.payments.find((p) => p.bookingId === bk.id);
    const paymentHist = finStore.paymentHistory.filter(
      (h) => h.bookingId === bk.id
    );
    const bkLedgerEntries = finStore.ledgerEntries.filter(
      (e) => e.bookingId === bk.id
    );
    const tour = opState.tours.find((t) => t.id === bk.tourId);
    const partner = opState.partners.find((p) => p.id === bk.partnerId);

    // F05-B: Usa sempre o snapshot histórico imutável da reserva quando gravado (grossAmount > 0),
    // evitando falsos positivos quando o preço ou comissão do catálogo muda no futuro.
    const bkGrossCents = toIntegerCents(bk.grossAmount);
    const bkCommCents = toIntegerCents(bk.commissionAmount);
    const bkNetCents = toIntegerCents(bk.netPartnerAmount);

    let expGrossCents = bkGrossCents;
    let expCommCents = bkCommCents;
    let expNetCents = bkNetCents;

    if (expGrossCents <= 0 && tour && partner) {
      const calc = calculateServerCommissionAndNet({
        tour,
        partner,
        passengers: bk.passengers,
      });
      expGrossCents = calc.grossCents;
      expCommCents = calc.commissionCents;
      expNetCents = calc.netPartnerCents;
    }

    const recGrossCents = payment
      ? toIntegerCents(payment.grossAmount)
      : bkGrossCents;
    const paidCents = payment ? toIntegerCents(payment.paidGrossAmount) : 0;
    const refundedCents = payment
      ? toIntegerCents(payment.refundedGrossAmount)
      : 0;
    const effCommCents = payment
      ? toIntegerCents(payment.effectiveCommissionAmount)
      : normBkStatus === 'CANCELADA' || normBkStatus === 'RECUSADA'
      ? 0
      : bkCommCents;
    const effNetCents = payment
      ? toIntegerCents(payment.effectiveNetPartnerAmount)
      : normBkStatus === 'CANCELADA' || normBkStatus === 'RECUSADA'
      ? 0
      : bkNetCents;

    const divergences: {
      code: FinancialDivergenceCode;
      description: string;
    }[] = [];

    // 1. Validar fórmula Bruto = Comissão + Líquido na reserva e no pagamento
    if (bkGrossCents !== bkCommCents + bkNetCents) {
      divergences.push({
        code: 'VALUE_FORMULA_MISMATCH',
        description: `Na reserva ${bk.code}, Bruto (${bk.grossAmount}) != Comissão (${bk.commissionAmount}) + Líquido (${bk.netPartnerAmount}).`,
      });
    }

    if (bkCommCents > bkGrossCents) {
      divergences.push({
        code: 'COMMISSION_EXCEEDS_GROSS',
        description: `Comissão registrada (${bk.commissionAmount}) excede o valor bruto (${bk.grossAmount}).`,
      });
    }

    // 2. Validar equivalência com o snapshot histórico esperado (Bruto, Comissão e Líquido)
    if (
      bkGrossCents !== expGrossCents ||
      bkCommCents !== expCommCents ||
      bkNetCents !== expNetCents
    ) {
      divergences.push({
        code: 'GROSS_MISMATCH_WITH_BOOKING',
        description: `Divergência entre snapshot histórico esperado (Bruto R$ ${fromIntegerCents(expGrossCents).toFixed(2)}, Com. R$ ${fromIntegerCents(expCommCents).toFixed(2)}, Líq. R$ ${fromIntegerCents(expNetCents).toFixed(2)}) e gravado na reserva.`,
      });
    }

    if (payment) {
      const payCommCents = toIntegerCents(payment.platformCommissionAmount);
      const payNetCents = toIntegerCents(payment.netPartnerAmount);
      if (
        recGrossCents !== bkGrossCents ||
        payCommCents !== bkCommCents ||
        payNetCents !== bkNetCents
      ) {
        divergences.push({
          code: 'GROSS_MISMATCH_WITH_BOOKING',
          description: `Valores do registro de pagamento (Bruto R$ ${payment.grossAmount.toFixed(2)}, Com. R$ ${payment.platformCommissionAmount.toFixed(2)}, Líq. R$ ${payment.netPartnerAmount.toFixed(2)}) divergem da reserva (Bruto R$ ${bk.grossAmount.toFixed(2)}, Com. R$ ${bk.commissionAmount.toFixed(2)}, Líq. R$ ${bk.netPartnerAmount.toFixed(2)}).`,
        });
      }

      if (refundedCents > paidCents) {
        divergences.push({
          code: 'INCONSISTENT_REFUND_STATE',
          description: `Valor estornado (R$ ${payment.refundedGrossAmount.toFixed(2)}) maior que o valor pago (R$ ${payment.paidGrossAmount.toFixed(2)}).`,
        });
      }

      if (
        payment.paymentStatus === 'ESTORNADO' &&
        (refundedCents !== paidCents ||
          effCommCents !== 0 ||
          effNetCents !== 0 ||
          bk.ledgerStatus !== 'REVERTIDA')
      ) {
        divergences.push({
          code: 'INCONSISTENT_REFUND_STATE',
          description:
            'Pagamento marcado como ESTORNADO integralmente ainda retém comissão/saldo líquido positivo ou livro-razão de comissão não revertido.',
        });
      }

      // F05-A: Auditoria cruzada com booking_payment_history
      if (paymentHist.length === 0) {
        divergences.push({
          code: 'PAYMENT_HISTORY_MISMATCH',
          description: `Pagamento ${payment.id} da reserva ${bk.code} não possui trilha de auditoria em booking_payment_history.`,
        });
      } else {
        const latestHist = paymentHist[0];
        if (latestHist && latestHist.newStatus !== payment.paymentStatus) {
          divergences.push({
            code: 'PAYMENT_HISTORY_MISMATCH',
            description: `Último estado no histórico de pagamento (${latestHist.newStatus}) diverge do estado atual em booking_payments (${payment.paymentStatus}).`,
          });
        }
      }

      // Seção 6: Detecção de estornos confirmados sem solicitação prévia em 2 etapas (REFUND_WITHOUT_REQUEST)
      if (
        payment.paymentStatus === 'ESTORNADO' ||
        payment.paymentStatus === 'ESTORNO_PARCIAL' ||
        refundedCents > 0
      ) {
        const hasRefundRequestInHistory = paymentHist.some(
          (h) =>
            h.newStatus === 'ESTORNO_PENDENTE' ||
            h.previousStatus === 'ESTORNO_PENDENTE' ||
            h.metadata?.operationType === 'REFUND_REQUESTED' ||
            h.metadata?.operationType === 'REFUND_REQUESTED_ON_BOOKING_CANCEL'
        );
        if (!hasRefundRequestInHistory) {
          divergences.push({
            code: 'REFUND_WITHOUT_REQUEST',
            description: `Pagamento ${payment.id} (${bk.code}) possui estorno (${payment.paymentStatus}, R$ ${payment.refundedGrossAmount.toFixed(2)}) sem solicitação prévia (ESTORNO_PENDENTE) no histórico.`,
          });
        }
      }

      // Seção 6: Detecção de estornos pendentes indevidamente finalizados (PENDING_REFUND_IMPROPERLY_FINALIZED)
      const improperFinalizedByRole = paymentHist.some(
        (h) =>
          (h.newStatus === 'ESTORNADO' || h.newStatus === 'ESTORNO_PARCIAL') &&
          (h.actorRole === 'partner' || h.actorRole === 'tourist')
      );
      const pendingRequestEntry = paymentHist.find(
        (h) =>
          h.newStatus === 'ESTORNO_PENDENTE' &&
          typeof h.metadata?.requestedRefundAmount === 'number'
      );
      const finalizedEntry = paymentHist.find(
        (h) => h.newStatus === 'ESTORNADO' || h.newStatus === 'ESTORNO_PARCIAL'
      );
      const finalizedExceedsRequested =
        pendingRequestEntry &&
        finalizedEntry &&
        typeof pendingRequestEntry.metadata?.requestedRefundAmount === 'number' &&
        typeof finalizedEntry.metadata?.refundedNowAmount === 'number' &&
        toIntegerCents(Number(finalizedEntry.metadata.refundedNowAmount)) >
          toIntegerCents(Number(pendingRequestEntry.metadata.requestedRefundAmount));
      const pendingAlreadyDeducted =
        payment.paymentStatus === 'ESTORNO_PENDENTE' &&
        (toIntegerCents(payment.effectiveGrossAmount) !== paidCents - refundedCents ||
          (refundedCents > 0 &&
            !paymentHist.some((h) => h.newStatus === 'ESTORNO_PARCIAL')));

      if (
        improperFinalizedByRole ||
        finalizedExceedsRequested ||
        pendingAlreadyDeducted
      ) {
        divergences.push({
          code: 'PENDING_REFUND_IMPROPERLY_FINALIZED',
          description: `Estorno pendente da reserva ${bk.code} foi finalizado indevidamente (por papel não autorizado, acima do valor solicitado ou com abatimento prematuro em ESTORNO_PENDENTE).`,
        });
      }

      // F05-A: Auditoria cruzada com a soma algébrica de financial_ledger_entries
      const confirmedEntries = bkLedgerEntries.filter(
        (e) =>
          e.entryType === 'PAYMENT_CONFIRMED' ||
          e.entryType === 'REFUND_FULL' ||
          e.entryType === 'REFUND_PARTIAL' ||
          e.entryType === 'COMPENSATORY_ADJUSTMENT'
      );
      const hasSplitViolationInEntries = bkLedgerEntries.some(
        (e) =>
          toIntegerCents(e.grossDelta) !==
          toIntegerCents(e.commissionDelta) + toIntegerCents(e.netPartnerDelta)
      );
      if (
        payment.paymentStatus === 'PAGO' ||
        payment.paymentStatus === 'ESTORNO_PENDENTE' ||
        payment.paymentStatus === 'ESTORNO_PARCIAL' ||
        payment.paymentStatus === 'ESTORNADO'
      ) {
        const ledgerNetGrossCents = confirmedEntries.reduce(
          (acc, e) => acc + toIntegerCents(e.grossDelta),
          0
        );
        const ledgerNetCommCents = confirmedEntries.reduce(
          (acc, e) => acc + toIntegerCents(e.commissionDelta),
          0
        );
        const ledgerNetPartnerCents = confirmedEntries.reduce(
          (acc, e) => acc + toIntegerCents(e.netPartnerDelta),
          0
        );
        const expectedRetainedGrossCents = paidCents - refundedCents;
        if (
          confirmedEntries.length === 0 ||
          hasSplitViolationInEntries ||
          ledgerNetGrossCents !== expectedRetainedGrossCents ||
          ledgerNetCommCents !== effCommCents ||
          ledgerNetPartnerCents !== effNetCents
        ) {
          divergences.push({
            code: 'LEDGER_ENTRIES_SUM_MISMATCH',
            description: `Soma algébrica de financial_ledger_entries (Bruto R$ ${fromIntegerCents(ledgerNetGrossCents).toFixed(2)}, Com. R$ ${fromIntegerCents(ledgerNetCommCents).toFixed(2)}, Líq. R$ ${fromIntegerCents(ledgerNetPartnerCents).toFixed(2)}) diverge do saldo retido em booking_payments (Bruto R$ ${fromIntegerCents(expectedRetainedGrossCents).toFixed(2)}, Com. R$ ${fromIntegerCents(effCommCents).toFixed(2)}, Líq. R$ ${fromIntegerCents(effNetCents).toFixed(2)}).`,
          });
        }
      } else if (hasSplitViolationInEntries) {
        divergences.push({
          code: 'LEDGER_ENTRIES_SUM_MISMATCH',
          description: `Violação da invariante gross_delta = commission_delta + net_partner_delta em financial_ledger_entries da reserva ${bk.code}.`,
        });
      }
    }

    // 3. Reserva concluída (PASSEIO_REALIZADO) sem pagamento confirmado compatível (D13: aceita ESTORNADO quando houve estorno integral pós-realização com ledger REVERTIDA)
    if (normBkStatus === 'PASSEIO_REALIZADO') {
      if (
        !payment ||
        (payment.paymentStatus !== 'PAGO' &&
          payment.paymentStatus !== 'ESTORNO_PARCIAL' &&
          payment.paymentStatus !== 'ESTORNADO')
      ) {
        divergences.push({
          code: 'COMPLETED_BOOKING_UNPAID',
          description: `Passeio realizado (${bk.code}) sem pagamento confirmado (${payment ? payment.paymentStatus : 'SEM_PAGAMENTO'}).`,
        });
      }
    }

    // 4. Reserva cancelada/recusada com pagamento dessincronizado ou saldo retido incompatível
    if (normBkStatus === 'CANCELADA' || normBkStatus === 'RECUSADA') {
      if (
        payment &&
        (payment.paymentStatus === 'PENDENTE' ||
          payment.paymentStatus === 'PROCESSANDO' ||
          payment.paymentStatus === 'FALHOU' ||
          payment.paymentStatus === 'PAGO' ||
          payment.paymentStatus === 'ESTORNO_PARCIAL' ||
          payment.paymentStatus === 'ESTORNO_PENDENTE' ||
          toIntegerCents(payment.effectiveGrossAmount) > 0 ||
          effCommCents > 0 ||
          effNetCents > 0)
      ) {
        divergences.push({
          code: 'CANCELLED_BOOKING_UNREFUNDED_PAYMENT',
          description: `Reserva ${bk.code} está ${normBkStatus}, porém o pagamento encontra-se em ${payment.paymentStatus} com saldo efetivo retido de R$ ${payment.effectiveGrossAmount.toFixed(2)}.`,
        });
      }
    }

    // 5. F05-D: Comissão liquidada (PAGA) sem pagamento confirmado correspondente
    if (bk.ledgerStatus === 'PAGA') {
      if (
        normBkStatus !== 'PASSEIO_REALIZADO' ||
        !payment ||
        (payment.paymentStatus !== 'PAGO' &&
          payment.paymentStatus !== 'ESTORNO_PARCIAL') ||
        effNetCents <= 0
      ) {
        divergences.push({
          code: 'SETTLED_COMMISSION_WITHOUT_CONFIRMED_PAYMENT',
          description: `Comissão da reserva ${bk.code} consta como PAGA no livro-razão sem pagamento confirmado correspondente.`,
        });
      }
    }

    // 6. Duplicidade de lançamentos unitários ou chaves no livro-razão
    const paymentConfirmedEntries = bkLedgerEntries.filter(
      (e) => e.entryType === 'PAYMENT_CONFIRMED'
    );
    const refundFullEntries = bkLedgerEntries.filter(
      (e) => e.entryType === 'REFUND_FULL'
    );
    const payoutSettledEntries = bkLedgerEntries.filter(
      (e) => e.entryType === 'PARTNER_PAYOUT_SETTLED'
    );
    const entryKeys = bkLedgerEntries.map((e) => e.idempotencyKey);
    const hasDuplicateEntryKey = new Set(entryKeys).size !== entryKeys.length;
    if (
      paymentConfirmedEntries.length > 1 ||
      refundFullEntries.length > 1 ||
      payoutSettledEntries.length > 1 ||
      hasDuplicateEntryKey
    ) {
      divergences.push({
        code: 'DUPLICATE_LEDGER_ENTRY',
        description: `Foram detectados lançamentos duplicados em financial_ledger_entries para a reserva ${bk.code}.`,
      });
    }

    // Acumulação dos totalizadores
    if (normBkStatus !== 'CANCELADA' && normBkStatus !== 'RECUSADA') {
      totalGrossExpectedCents += bkGrossCents;
    }

    if (
      payment &&
      (payment.paymentStatus === 'PAGO' ||
        payment.paymentStatus === 'ESTORNO_PARCIAL' ||
        payment.paymentStatus === 'ESTORNADO' ||
        payment.paymentStatus === 'ESTORNO_PENDENTE')
    ) {
      totalPaidConfirmedCents += paidCents - refundedCents;
      totalRefundedCents += refundedCents;
      totalCommissionReversedCents += toIntegerCents(
        payment.reversedCommissionAmount
      );
    } else if (normBkStatus !== 'CANCELADA' && normBkStatus !== 'RECUSADA') {
      totalPendingCollectionCents += bkGrossCents;
    }

    if (
      normBkStatus === 'PASSEIO_REALIZADO' &&
      payment &&
      (payment.paymentStatus === 'PAGO' ||
        payment.paymentStatus === 'ESTORNO_PARCIAL')
    ) {
      totalCommissionConsolidatedCents += effCommCents;
      totalNetPartnerConsolidatedCents += effNetCents;
    } else if (normBkStatus !== 'CANCELADA' && normBkStatus !== 'RECUSADA') {
      totalCommissionProvisionedCents += effCommCents;
      totalNetPartnerPendingCents += effNetCents;
    }

    items.push({
      bookingId: bk.id,
      bookingCode: bk.code,
      partnerId: bk.partnerId,
      partnerName: bk.partnerName,
      tourTitle: bk.tourTitle,
      bookingDate: bk.date,
      bookingStatus: normBkStatus,
      ledgerStatus: bk.ledgerStatus,
      paymentStatus: payment ? payment.paymentStatus : 'SEM_REGISTRO_PAGAMENTO',
      expectedGrossAmount: fromIntegerCents(expGrossCents),
      recordedGrossAmount: fromIntegerCents(recGrossCents),
      paidGrossAmount: fromIntegerCents(paidCents),
      refundedGrossAmount: fromIntegerCents(refundedCents),
      expectedCommissionAmount: fromIntegerCents(expCommCents),
      effectiveCommissionAmount: fromIntegerCents(effCommCents),
      expectedNetPartnerAmount: fromIntegerCents(expNetCents),
      effectiveNetPartnerAmount: fromIntegerCents(effNetCents),
      isReconciled: divergences.length === 0,
      divergences,
    });
  }

  // 7. F05-C: Detecção de pagamentos órfãos sem reserva correspondente
  const orphanPayments = finStore.payments.filter(
    (p) =>
      !bookingIdsSet.has(p.bookingId) &&
      (!effectivePartnerScope || p.partnerId === effectivePartnerScope)
  );
  for (const orph of orphanPayments) {
    items.push({
      bookingId: orph.bookingId,
      bookingCode: orph.bookingCode || 'ORPHAN-BOOKING',
      partnerId: orph.partnerId,
      partnerName: 'Pagamento Órfão sem Reserva',
      tourTitle: orph.tourId,
      bookingDate: orph.createdAt.slice(0, 10),
      bookingStatus: 'EM_DISPUTA',
      ledgerStatus: 'EM_DISPUTA',
      paymentStatus: orph.paymentStatus,
      expectedGrossAmount: 0,
      recordedGrossAmount: orph.grossAmount,
      paidGrossAmount: orph.paidGrossAmount,
      refundedGrossAmount: orph.refundedGrossAmount,
      expectedCommissionAmount: 0,
      effectiveCommissionAmount: orph.effectiveCommissionAmount,
      expectedNetPartnerAmount: 0,
      effectiveNetPartnerAmount: orph.effectiveNetPartnerAmount,
      isReconciled: false,
      divergences: [
        {
          code: 'ORPHAN_PAYMENT_WITHOUT_BOOKING',
          description: `Pagamento ${orph.id} (${orph.bookingCode}) não possui reserva correspondente em bookings.`,
        },
      ],
    });
  }

  // 8. Seção 6: Detecção de históricos de pagamento sem pagamento correspondente (ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT)
  const paymentIdsSet = new Set(finStore.payments.map((p) => p.id));
  const orphanHistories = finStore.paymentHistory.filter(
    (h) =>
      (!paymentIdsSet.has(h.paymentId) || !bookingIdsSet.has(h.bookingId)) &&
      (!effectivePartnerScope || h.partnerId === effectivePartnerScope)
  );
  for (const orphHist of orphanHistories) {
    items.push({
      bookingId: orphHist.bookingId,
      bookingCode: orphHist.bookingCode || 'ORPHAN-HISTORY',
      partnerId: orphHist.partnerId,
      partnerName: 'Histórico Órfão sem Pagamento',
      tourTitle: orphHist.paymentId,
      bookingDate: orphHist.createdAt.slice(0, 10),
      bookingStatus: 'EM_DISPUTA',
      ledgerStatus: 'EM_DISPUTA',
      paymentStatus: orphHist.newStatus,
      expectedGrossAmount: 0,
      recordedGrossAmount: orphHist.amountSnapshot,
      paidGrossAmount: 0,
      refundedGrossAmount: orphHist.refundAmountSnapshot,
      expectedCommissionAmount: 0,
      effectiveCommissionAmount: 0,
      expectedNetPartnerAmount: 0,
      effectiveNetPartnerAmount: 0,
      isReconciled: false,
      divergences: [
        {
          code: 'ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT',
          description: `Histórico de pagamento ${orphHist.id} referencia pagamento (${orphHist.paymentId}) ou reserva (${orphHist.bookingId}) inexistente.`,
        },
      ],
    });
  }

  const divergentCount = items.filter((i) => !i.isReconciled).length;

  return {
    ok: true,
    data: {
      generatedAt: new Date().toISOString(),
      partnerFilter: effectivePartnerScope,
      isHealthy: divergentCount === 0,
      discrepanciesCount: divergentCount,
      totalBookingsAudited: items.length,
      reconciledCount: items.length - divergentCount,
      divergentCount,
      orphanPaymentsCount: orphanPayments.length,
      orphanHistoryCount: orphanHistories.length,
      summaryMetrics: {
        totalGrossExpected: fromIntegerCents(totalGrossExpectedCents),
        totalPaidConfirmed: fromIntegerCents(totalPaidConfirmedCents),
        totalRefunded: fromIntegerCents(totalRefundedCents),
        totalPendingCollection: fromIntegerCents(totalPendingCollectionCents),
        totalCommissionProvisioned: fromIntegerCents(
          totalCommissionProvisionedCents
        ),
        totalCommissionConsolidated: fromIntegerCents(
          totalCommissionConsolidatedCents
        ),
        totalCommissionReversed: fromIntegerCents(totalCommissionReversedCents),
        totalNetPartnerConsolidated: fromIntegerCents(
          totalNetPartnerConsolidatedCents
        ),
        totalNetPartnerPending: fromIntegerCents(totalNetPartnerPendingCents),
      },
      items,
    },
  };
}

// ============================================================================
// 9. VISÕES FINANCEIRAS AUTORIZADAS POR PERFIL (ADMIN E PARCEIRO)
// ============================================================================

export interface PartnerFinancialSummaryView {
  partnerId: string;
  partnerName: string;
  totalBookingsCount: number;
  paidBookingsCount: number;
  pendingPaymentCount: number;
  refundedOrCancelledCount: number;
  grossVolumeTotal: number;
  totalGrossOwnBookings: number;
  commissionRetainedByPlatform: number;
  netPartnerConsolidated: number;
  netPartnerPending: number;
  refundedTotal: number;
  payments: BookingPaymentRecord[];
  ownPayments: BookingPaymentRecord[];
  recentHistory: BookingPaymentHistoryEntry[];
}

export function computePartnerFinancialSummary(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext,
  targetPartnerId: string
): OperationResult<PartnerFinancialSummaryView> {
  if (authCtx.actorRole === 'tourist') {
    return {
      ok: false,
      errorCode: 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN',
      errorMessage: 'Turistas não têm acesso ao painel financeiro de parceiros.',
    };
  }
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    targetPartnerId,
    opState
  );
  if (!authCheck.ok || !authCheck.data) {
    return {
      ok: false,
      errorCode:
        authCheck.errorCode === 'CROSS_TENANT_ACCESS_DENIED'
          ? 'CROSS_TENANT_FINANCIAL_ACCESS_DENIED'
          : authCheck.errorCode || 'CROSS_TENANT_FINANCIAL_ACCESS_DENIED',
      errorMessage:
        authCheck.errorMessage ||
        'Acesso negado aos dados financeiros de outro parceiro.',
    };
  }

  const partner = opState.partners.find((p) => p.id === targetPartnerId);
  if (!partner) {
    return {
      ok: false,
      errorCode: 'PARTNER_NOT_FOUND',
      errorMessage: `Parceiro "${targetPartnerId}" não encontrado.`,
    };
  }

  const reconRes = runFinancialReconciliation(
    opState,
    finStore,
    authCtx,
    targetPartnerId
  );
  if (!reconRes.ok || !reconRes.data) {
    return {
      ok: false,
      errorCode: reconRes.errorCode,
      errorMessage: reconRes.errorMessage,
    };
  }

  const partnerPayments = finStore.payments.filter(
    (p) => p.partnerId === targetPartnerId
  );
  const partnerHistory = finStore.paymentHistory
    .filter((h) => h.partnerId === targetPartnerId)
    .slice(0, 30);

  const items = reconRes.data.items;
  const paidBookingsCount = items.filter(
    (i) =>
      i.paymentStatus === 'PAGO' || i.paymentStatus === 'ESTORNO_PARCIAL'
  ).length;
  const pendingPaymentCount = items.filter(
    (i) =>
      i.paymentStatus === 'PENDENTE' ||
      i.paymentStatus === 'PROCESSANDO' ||
      (i.paymentStatus === 'SEM_REGISTRO_PAGAMENTO' &&
        i.bookingStatus !== 'CANCELADA' &&
        i.bookingStatus !== 'RECUSADA')
  ).length;
  const refundedOrCancelledCount = items.filter(
    (i) =>
      i.paymentStatus === 'ESTORNADO' ||
      i.paymentStatus === 'CANCELADO' ||
      i.bookingStatus === 'CANCELADA' ||
      i.bookingStatus === 'RECUSADA'
  ).length;

  const sm = reconRes.data.summaryMetrics;

  return {
    ok: true,
    data: {
      partnerId: partner.id,
      partnerName: partner.name,
      totalBookingsCount: items.length,
      paidBookingsCount,
      pendingPaymentCount,
      refundedOrCancelledCount,
      grossVolumeTotal: sm.totalGrossExpected,
      totalGrossOwnBookings: sm.totalGrossExpected,
      commissionRetainedByPlatform: roundCurrencyExact(
        sm.totalCommissionConsolidated + sm.totalCommissionProvisioned
      ),
      netPartnerConsolidated: sm.totalNetPartnerConsolidated,
      netPartnerPending: sm.totalNetPartnerPending,
      refundedTotal: sm.totalRefunded,
      payments: partnerPayments,
      ownPayments: partnerPayments,
      recentHistory: partnerHistory,
    },
  };
}

export interface AdminFinancialSummaryView {
  reconciliation: FinancialReconciliationReport;
  byPartnerBreakdown: {
    partnerId: string;
    partnerName: string;
    bookingsCount: number;
    grossExpected: number;
    paidConfirmed: number;
    commissionConsolidated: number;
    commissionProvisioned: number;
    netPartnerConsolidated: number;
    netPartnerPending: number;
    refundedAmount: number;
    divergentCount: number;
  }[];
  recentLedgerEntries: FinancialLedgerEntry[];
  recentPaymentHistory: BookingPaymentHistoryEntry[];
}

export function computeAdminFinancialSummary(
  opState: OperationalStateSnapshot,
  finStore: FinancialStoreSnapshot,
  authCtx: OperationalAuthContext
): OperationResult<AdminFinancialSummaryView> {
  if (authCtx.actorRole === 'tourist') {
    return {
      ok: false,
      errorCode: 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN',
      errorMessage: 'Turistas não têm acesso ao painel financeiro administrativo.',
    };
  }
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin'],
    undefined,
    opState
  );
  if (!authCheck.ok) {
    return {
      ok: false,
      errorCode: authCheck.errorCode || 'UNAUTHORIZED_FINANCIAL_ADMIN',
      errorMessage:
        authCheck.errorMessage ||
        'Somente o perfil Administrador pode consultar a visão financeira global da plataforma.',
    };
  }

  const globalReconRes = runFinancialReconciliation(
    opState,
    finStore,
    authCtx,
    null
  );
  if (!globalReconRes.ok || !globalReconRes.data) {
    return {
      ok: false,
      errorCode: globalReconRes.errorCode,
      errorMessage: globalReconRes.errorMessage,
    };
  }

  const byPartnerBreakdown = opState.partners.map((partner) => {
    const pRecon = runFinancialReconciliation(
      opState,
      finStore,
      authCtx,
      partner.id
    );
    const sm = pRecon.data?.summaryMetrics;
    return {
      partnerId: partner.id,
      partnerName: partner.name,
      bookingsCount: pRecon.data?.totalBookingsAudited || 0,
      grossExpected: sm?.totalGrossExpected || 0,
      paidConfirmed: sm?.totalPaidConfirmed || 0,
      commissionConsolidated: sm?.totalCommissionConsolidated || 0,
      commissionProvisioned: sm?.totalCommissionProvisioned || 0,
      netPartnerConsolidated: sm?.totalNetPartnerConsolidated || 0,
      netPartnerPending: sm?.totalNetPartnerPending || 0,
      refundedAmount: sm?.totalRefunded || 0,
      divergentCount: pRecon.data?.divergentCount || 0,
    };
  });

  return {
    ok: true,
    data: {
      reconciliation: globalReconRes.data,
      byPartnerBreakdown,
      recentLedgerEntries: finStore.ledgerEntries.slice(0, 50),
      recentPaymentHistory: finStore.paymentHistory.slice(0, 50),
    },
  };
}

// ============================================================================
// 10. SANITIZAÇÃO LGPD DE REGISTROS FINANCEIROS PRESERVANDO TOTAIS CONTÁBEIS (F08-D)
// ============================================================================

export function sanitizeFinancialRecordsForLgpd(
  finStore: FinancialStoreSnapshot,
  bookingId: string,
  lgpdProtocol: string
): {
  financialStore: FinancialStoreSnapshot;
  paymentsSanitized: number;
  historySanitized: number;
  ledgerSanitized: number;
  financialTotalsPreserved: boolean;
} {
  const cleanProtocol = (lgpdProtocol || 'LGPD-ANON').trim();
  const redactedReason = `Registro financeiro preservado sob anonimização LGPD (${cleanProtocol})`;

  let paymentsSanitized = 0;
  const nextPayments = finStore.payments.map((p) => {
    if (p.bookingId !== bookingId) return p;
    paymentsSanitized += 1;
    return {
      ...p,
      failureReason: p.failureReason ? redactedReason : null,
      refundReason: p.refundReason ? redactedReason : null,
    };
  });

  let historySanitized = 0;
  const nextHistory = finStore.paymentHistory.map((h) => {
    if (h.bookingId !== bookingId) return h;
    historySanitized += 1;
    return {
      ...h,
      actorName:
        h.actorRole === 'tourist' ? 'TITULAR ANONIMIZADO LGPD' : h.actorName,
      reason: h.reason ? redactedReason : null,
      metadata: {
        ...h.metadata,
        lgpd_sanitized: true,
        lgpd_protocol: cleanProtocol,
      },
    };
  });

  let ledgerSanitized = 0;
  const nextLedger = finStore.ledgerEntries.map((e) => {
    if (e.bookingId !== bookingId) return e;
    ledgerSanitized += 1;
    return {
      ...e,
      description: `${redactedReason} [${e.entryType}]`,
    };
  });

  return {
    financialStore: {
      ...finStore,
      payments: nextPayments,
      paymentHistory: nextHistory,
      ledgerEntries: nextLedger,
    },
    paymentsSanitized,
    historySanitized,
    ledgerSanitized,
    financialTotalsPreserved: true,
  };
}

// ============================================================================
// 11. HIDRATAÇÃO DETERMINÍSTICA DO STORE FINANCEIRO (PÓS-F5 & SUPABASE — F03)
// ============================================================================

export function hydrateFinancialStoreFromServerRows(params: {
  paymentRows: Record<string, unknown>[];
  paymentHistoryRows: Record<string, unknown>[];
  financialLedgerRows: Record<string, unknown>[];
  bookings: readonly { id: string; code: string }[];
}): FinancialStoreSnapshot {
  const codeById = new Map<string, string>(
    params.bookings.map((b) => [b.id, b.code])
  );

  const paymentHistory: BookingPaymentHistoryEntry[] =
    params.paymentHistoryRows.map((row, idx) => {
      const bId = String(row.booking_id || row.bookingId || '');
      const bCode = String(
        row.booking_code || row.bookingCode || codeById.get(bId) || ''
      );
      const prevRaw = row.previous_status ?? row.previousStatus;
      const newRaw = String(row.new_status ?? row.newStatus ?? 'PENDENTE');
      const rawMeta =
        row.metadata_json && typeof row.metadata_json === 'object'
          ? (row.metadata_json as Record<string, unknown>)
          : row.metadata && typeof row.metadata === 'object'
          ? (row.metadata as Record<string, unknown>)
          : {};
      const opType =
        row.operation_type != null ? String(row.operation_type) : undefined;
      return {
        id: String(row.id || `phist-srv-${idx + 1}`),
        paymentId: String(row.payment_id || row.paymentId || `pay-${bId}`),
        bookingId: bId,
        bookingCode: bCode,
        partnerId: String(row.partner_id || row.partnerId || ''),
        previousStatus:
          prevRaw != null && isValidPaymentStatus(String(prevRaw))
            ? (String(prevRaw) as PaymentStatusType)
            : null,
        newStatus: isValidPaymentStatus(newRaw)
          ? (newRaw as PaymentStatusType)
          : 'PENDENTE',
        actorId:
          row.actor_user_id != null
            ? String(row.actor_user_id)
            : row.actor_id != null
            ? String(row.actor_id)
            : row.actorId != null
            ? String(row.actorId)
            : null,
        actorRole: (row.actor_role || row.actorRole || 'admin') as AppRole,
        actorName: String(row.actor_name || row.actorName || 'Servidor'),
        idempotencyKey:
          row.idempotency_key != null
            ? String(row.idempotency_key)
            : row.idempotencyKey != null
            ? String(row.idempotencyKey)
            : null,
        amountSnapshot: roundCurrencyExact(
          Number(
            row.operation_amount ??
              row.amount_snapshot ??
              row.amountSnapshot ??
              0
          )
        ),
        refundAmountSnapshot: roundCurrencyExact(
          Number(row.refund_amount_snapshot ?? row.refundAmountSnapshot ?? 0)
        ),
        reason: row.reason != null ? String(row.reason) : null,
        metadata: opType ? { ...rawMeta, operationType: opType } : rawMeta,
        createdAt: String(
          row.created_at || row.createdAt || new Date().toISOString()
        ),
      };
    });

  const payments: BookingPaymentRecord[] = params.paymentRows.map((row) => {
    const bId = String(row.booking_id || row.bookingId || '');
    const bCode = String(
      row.booking_code || row.bookingCode || codeById.get(bId) || ''
    );
    const rawStatus = String(
      row.payment_status || row.paymentStatus || 'PENDENTE'
    );
    const paymentStatus: PaymentStatusType = isValidPaymentStatus(rawStatus)
      ? rawStatus
      : 'PENDENTE';
    const rawMethod = String(
      row.payment_method || row.paymentMethod || 'PIX'
    );
    const paymentMethod: PaymentMethodType = (
      PAYMENT_METHOD_VALUES as readonly string[]
    ).includes(rawMethod)
      ? (rawMethod as PaymentMethodType)
      : 'PIX';

    const grossAmount = roundCurrencyExact(
      Number(row.gross_amount ?? row.grossAmount ?? 0)
    );
    const isConfirmedLineage =
      paymentStatus === 'PAGO' ||
      paymentStatus === 'ESTORNO_PENDENTE' ||
      paymentStatus === 'ESTORNO_PARCIAL' ||
      paymentStatus === 'ESTORNADO' ||
      row.confirmed_at != null ||
      row.paid_at != null;
    const paidGrossAmount = roundCurrencyExact(
      Number(
        row.paid_gross_amount ??
          row.paidGrossAmount ??
          (isConfirmedLineage ? grossAmount : 0)
      )
    );
    const refundedGrossAmount = roundCurrencyExact(
      Number(row.refunded_gross_amount ?? row.refundedGrossAmount ?? 0)
    );
    const commissionAmount = roundCurrencyExact(
      Number(
        row.commission_amount ??
          row.platform_commission_amount ??
          row.platformCommissionAmount ??
          0
      )
    );
    const reversedCommissionAmount = roundCurrencyExact(
      Number(
        row.refunded_commission_amount ??
          row.reversed_commission_amount ??
          row.reversedCommissionAmount ??
          0
      )
    );
    const snapObj =
      row.commission_rule_snapshot &&
      typeof row.commission_rule_snapshot === 'object'
        ? (row.commission_rule_snapshot as Record<string, unknown>)
        : row.commissionRuleSnapshot &&
          typeof row.commissionRuleSnapshot === 'object'
        ? (row.commissionRuleSnapshot as Record<string, unknown>)
        : {};
    const snapModel = normalizePartnerCommissionModel(
      String(
        row.commission_model_snapshot ??
          row.commissionModelSnapshot ??
          snapObj.commission_model ??
          snapObj.commissionModel ??
          'PERCENTAGE'
      )
    );
    const snapRate = Number(
      row.commission_rate_snapshot ??
        row.commissionRateSnapshot ??
        snapObj.commission_rate ??
        snapObj.commissionRate ??
        15
    );
    const snapFixed = roundCurrencyExact(
      Number(
        row.commission_fixed_snapshot ??
          row.commissionFixedSnapshot ??
          snapObj.commission_fixed ??
          snapObj.commissionFixed ??
          0
      )
    );
    const snapLabel = String(
      row.commission_rule_label ??
        row.commissionRuleLabel ??
        snapObj.commission_rule_label ??
        snapObj.commissionRuleLabel ??
        ''
    );

    const paymentId = String(row.id || row.payment_id || `pay-${bId}`);
    const relatedHist = paymentHistory.filter(
      (h) => h.paymentId === paymentId || h.bookingId === bId
    );
    const pendingReqHist = relatedHist.find(
      (h) =>
        h.newStatus === 'ESTORNO_PENDENTE' &&
        (typeof h.metadata?.requested_refund_amount === 'number' ||
          typeof h.metadata?.requestedRefundAmount === 'number' ||
          h.amountSnapshot > 0)
    );
    const resolvedRequestedRefund =
      paymentStatus === 'ESTORNO_PENDENTE'
        ? row.requested_refund_amount != null
          ? roundCurrencyExact(Number(row.requested_refund_amount))
          : row.requestedRefundAmount != null
          ? roundCurrencyExact(Number(row.requestedRefundAmount))
          : pendingReqHist
          ? roundCurrencyExact(
              Number(
                pendingReqHist.metadata?.requested_refund_amount ??
                  pendingReqHist.metadata?.requestedRefundAmount ??
                  pendingReqHist.amountSnapshot
              )
            )
          : roundCurrencyExact(grossAmount - refundedGrossAmount)
        : null;

    const confHist = relatedHist.find((h) => h.newStatus === 'PAGO');
    const rawOrigin =
      row.confirmation_origin ??
      row.confirmationOrigin ??
      confHist?.metadata?.confirmation_origin ??
      confHist?.metadata?.confirmationOrigin;
    const confirmationOrigin: 'GATEWAY_WEBHOOK' | 'MANUAL_ADMIN' | null =
      rawOrigin === 'GATEWAY_WEBHOOK' || rawOrigin === 'MANUAL_ADMIN'
        ? rawOrigin
        : null;

    return {
      id: paymentId,
      bookingId: bId,
      bookingCode: bCode,
      partnerId: String(row.partner_id || row.partnerId || ''),
      tourId: String(row.tour_id || row.tourId || ''),
      paymentMethod,
      paymentStatus,
      currency: 'BRL',
      grossAmount,
      paidGrossAmount,
      refundedGrossAmount,
      commissionAmount,
      platformCommissionAmount: commissionAmount,
      reversedCommissionAmount,
      effectiveGrossAmount: roundCurrencyExact(
        Number(
          row.effective_gross_amount ??
            row.effectiveGrossAmount ??
            grossAmount - refundedGrossAmount
        )
      ),
      effectiveCommissionAmount: roundCurrencyExact(
        Number(
          row.effective_commission_amount ??
            row.effectiveCommissionAmount ??
            commissionAmount - reversedCommissionAmount
        )
      ),
      netPartnerAmount: roundCurrencyExact(
        Number(row.net_partner_amount ?? row.netPartnerAmount ?? 0)
      ),
      effectiveNetPartnerAmount: roundCurrencyExact(
        Number(
          row.effective_net_partner_amount ?? row.effectiveNetPartnerAmount ?? 0
        )
      ),
      commissionModelSnapshot: snapModel,
      commissionRateSnapshot: snapRate,
      commissionFixedSnapshot: snapFixed,
      commissionRuleLabel: snapLabel,
      commissionRuleSnapshot: {
        commissionModel: snapModel,
        commissionRate: snapRate,
        commissionFixed: snapFixed,
        commissionRuleLabel: snapLabel,
      },
      idempotencyKey: String(
        row.idempotency_key ?? row.idempotencyKey ?? `idemp-${bId}`
      ),
      lastOperationIdempotencyKey:
        row.last_operation_idempotency_key != null
          ? String(row.last_operation_idempotency_key)
          : row.lastOperationIdempotencyKey != null
          ? String(row.lastOperationIdempotencyKey)
          : null,
      externalPaymentReference:
        row.external_payment_reference != null
          ? String(row.external_payment_reference)
          : row.externalPaymentReference != null
          ? String(row.externalPaymentReference)
          : null,
      externalTransactionId:
        row.external_transaction_id != null
          ? String(row.external_transaction_id)
          : row.externalTransactionId != null
          ? String(row.externalTransactionId)
          : null,
      confirmationOrigin,
      failureReason:
        row.failure_or_cancel_reason != null
          ? String(row.failure_or_cancel_reason)
          : row.failure_reason != null
          ? String(row.failure_reason)
          : row.failureReason != null
          ? String(row.failureReason)
          : null,
      refundReason:
        row.refund_reason != null
          ? String(row.refund_reason)
          : row.refundReason != null
          ? String(row.refundReason)
          : null,
      requestedRefundAmount: resolvedRequestedRefund,
      paidAt:
        row.confirmed_at != null
          ? String(row.confirmed_at)
          : row.paid_at != null
          ? String(row.paid_at)
          : row.paidAt != null
          ? String(row.paidAt)
          : null,
      failedAt:
        row.failed_at != null
          ? String(row.failed_at)
          : row.failedAt != null
          ? String(row.failedAt)
          : null,
      cancelledAt:
        row.cancelled_at != null
          ? String(row.cancelled_at)
          : row.cancelledAt != null
          ? String(row.cancelledAt)
          : null,
      refundedAt:
        row.refunded_at != null
          ? String(row.refunded_at)
          : row.refundedAt != null
          ? String(row.refundedAt)
          : null,
      createdBy:
        row.created_by != null
          ? String(row.created_by)
          : row.createdBy != null
          ? String(row.createdBy)
          : null,
      updatedBy:
        row.updated_by != null
          ? String(row.updated_by)
          : row.updatedBy != null
          ? String(row.updatedBy)
          : null,
      createdAt: String(
        row.created_at || row.createdAt || new Date().toISOString()
      ),
      updatedAt: String(
        row.updated_at || row.updatedAt || new Date().toISOString()
      ),
    };
  });

  const ledgerEntries: FinancialLedgerEntry[] = params.financialLedgerRows.map(
    (row, idx) => {
      const bId = String(row.booking_id || row.bookingId || '');
      const bCode = String(
        row.booking_code || row.bookingCode || codeById.get(bId) || ''
      );
      return {
        id: String(row.id || `fl-srv-${idx + 1}`),
        bookingId: bId,
        bookingCode: bCode,
        paymentId:
          row.payment_id != null
            ? String(row.payment_id)
            : row.paymentId != null
            ? String(row.paymentId)
            : null,
        partnerId: String(row.partner_id || row.partnerId || ''),
        entryType: String(
          row.entry_type || row.entryType || 'COMMISSION_PROVISIONED'
        ) as FinancialEntryType,
        grossDelta: roundCurrencyExact(
          Number(row.gross_delta ?? row.grossDelta ?? 0)
        ),
        commissionDelta: roundCurrencyExact(
          Number(row.commission_delta ?? row.commissionDelta ?? 0)
        ),
        netPartnerDelta: roundCurrencyExact(
          Number(row.net_partner_delta ?? row.netPartnerDelta ?? 0)
        ),
        currency: 'BRL',
        idempotencyKey: String(
          row.idempotency_key ?? row.idempotencyKey ?? `fl-idemp-${idx + 1}`
        ),
        description: String(row.description || ''),
        actorId:
          row.actor_user_id != null
            ? String(row.actor_user_id)
            : row.actor_id != null
            ? String(row.actor_id)
            : row.actorId != null
            ? String(row.actorId)
            : null,
        actorRole: (row.actor_role || row.actorRole || 'admin') as AppRole,
        createdAt: String(
          row.created_at || row.createdAt || new Date().toISOString()
        ),
      };
    }
  );

  const processedIdempotencyKeys: FinancialStoreSnapshot['processedIdempotencyKeys'] =
    {};
  for (const p of payments) {
    if (p.idempotencyKey) {
      processedIdempotencyKeys[p.idempotencyKey] = {
        bookingId: p.bookingId,
        paymentId: p.id,
        operation: 'INITIATE_PAYMENT',
        resultStatus: p.paymentStatus,
        timestamp: p.createdAt,
        payloadFingerprint: {
          operation: 'INITIATE_PAYMENT',
          bookingId: p.bookingId,
          paymentMethod: p.paymentMethod,
          externalTransactionId: p.externalPaymentReference || p.externalTransactionId || '',
        },
      };
    }
    if (p.lastOperationIdempotencyKey && !processedIdempotencyKeys[p.lastOperationIdempotencyKey]) {
      processedIdempotencyKeys[p.lastOperationIdempotencyKey] = {
        bookingId: p.bookingId,
        paymentId: p.id,
        operation: 'TRANSITION_PAYMENT',
        resultStatus: p.paymentStatus,
        timestamp: p.updatedAt,
      };
    }
  }

  for (const h of paymentHistory) {
    if (!h.idempotencyKey) continue;
    const opType = String(h.metadata?.operationType || '');
    if (opType === 'REFUND_REQUESTED') {
      processedIdempotencyKeys[h.idempotencyKey] = {
        bookingId: h.bookingId,
        paymentId: h.paymentId,
        operation: 'REQUEST_REFUND',
        resultStatus: 'ESTORNO_PENDENTE',
        timestamp: h.createdAt,
        payloadFingerprint: {
          operation: 'REQUEST_REFUND',
          bookingId: h.bookingId,
          refundAmountCents: toIntegerCents(
            Number(
              h.metadata?.requested_refund_amount ??
                h.metadata?.requestedRefundAmount ??
                h.amountSnapshot
            )
          ),
          reason: String(h.metadata?.input_reason ?? h.reason ?? ''),
        },
      };
    } else if (opType === 'REFUND_FULL' || opType === 'REFUND_PARTIAL') {
      processedIdempotencyKeys[h.idempotencyKey] = {
        bookingId: h.bookingId,
        paymentId: h.paymentId,
        operation: 'PROCESS_REFUND',
        resultStatus: h.newStatus,
        timestamp: h.createdAt,
        payloadFingerprint: {
          operation: 'PROCESS_REFUND',
          bookingId: h.bookingId,
          refundAmountCents: toIntegerCents(
            Number(
              h.metadata?.refund_gross_delta ??
                h.metadata?.refundedNowAmount ??
                h.amountSnapshot
            )
          ),
          reason: String(h.metadata?.input_reason ?? h.reason ?? ''),
          markBookingCancelled: Boolean(
            h.metadata?.mark_booking_cancelled ??
              h.metadata?.markBookingCancelled ??
              false
          ),
        },
      };
    } else if (opType.startsWith('TRANSITION_') || opType === 'REFUND_FAILED_REVERT') {
      processedIdempotencyKeys[h.idempotencyKey] = {
        bookingId: h.bookingId,
        paymentId: h.paymentId,
        operation: 'TRANSITION_PAYMENT',
        resultStatus: h.newStatus,
        timestamp: h.createdAt,
        payloadFingerprint: {
          operation: 'TRANSITION_PAYMENT',
          bookingId: h.bookingId,
          targetStatus: h.newStatus,
          externalTransactionId: String(
            h.metadata?.external_transaction_id ??
              h.metadata?.externalTransactionId ??
              ''
          ),
          reason: String(h.metadata?.input_reason ?? h.reason ?? ''),
        },
      };
    }
  }

  return {
    payments,
    paymentHistory,
    ledgerEntries,
    processedIdempotencyKeys,
  };
}

/**
 * Inicializa o store financeiro demonstrativo alinhado com as reservas iniciais (INITIAL_BOOKINGS),
 * garantindo que passeios realizados (bk-101, bk-102) já possuam pagamentos confirmados e
 * reservas aguardando confirmação (bk-103) possuam pagamento pendente conciliado.
 */
export function seedInitialDemoFinancialStore(
  bookings: readonly OperationalBookingRecord[]
): FinancialStoreSnapshot {
  const payments: BookingPaymentRecord[] = [];
  const paymentHistory: BookingPaymentHistoryEntry[] = [];
  const ledgerEntries: FinancialLedgerEntry[] = [];
  const processedIdempotencyKeys: FinancialStoreSnapshot['processedIdempotencyKeys'] =
    {};

  for (const bk of bookings) {
    const normStatus = normalizeBookingStatus(bk.status);
    const isCompleted = normStatus === 'PASSEIO_REALIZADO';
    const isCancelled = normStatus === 'CANCELADA' || normStatus === 'RECUSADA';
    const pStatus: PaymentStatusType = isCompleted
      ? 'PAGO'
      : isCancelled
      ? 'CANCELADO'
      : 'PENDENTE';
    const method: PaymentMethodType =
      bk.channel === 'WHATSAPP' ? 'PIX' : 'CARTAO_CREDITO';
    const gross = roundCurrencyExact(bk.grossAmount);
    const comm = roundCurrencyExact(bk.commissionAmount);
    const net = roundCurrencyExact(bk.netPartnerAmount);
    const nowIso = '2026-11-08T10:00:00.000Z';
    const initKey = `seed-init-${bk.id}`;
    const confKey = `seed-conf-${bk.id}`;

    const payRec: BookingPaymentRecord = {
      id: `pay-${bk.id}`,
      bookingId: bk.id,
      bookingCode: bk.code,
      partnerId: bk.partnerId,
      tourId: bk.tourId,
      paymentMethod: method,
      paymentStatus: pStatus,
      currency: 'BRL',
      grossAmount: gross,
      paidGrossAmount: isCompleted ? gross : 0,
      refundedGrossAmount: 0,
      commissionAmount: comm,
      platformCommissionAmount: comm,
      reversedCommissionAmount: isCancelled ? comm : 0,
      effectiveGrossAmount: isCancelled ? 0 : gross,
      effectiveCommissionAmount: isCancelled ? 0 : comm,
      netPartnerAmount: net,
      effectiveNetPartnerAmount: isCancelled ? 0 : net,
      commissionModelSnapshot: 'PERCENTAGE',
      commissionRateSnapshot: 15,
      commissionFixedSnapshot: 0,
      commissionRuleLabel: bk.commissionRuleUsed || 'Regra Padrão',
      commissionRuleSnapshot: {
        commissionModel: 'PERCENTAGE',
        commissionRate: 15,
        commissionFixed: 0,
        commissionRuleLabel: bk.commissionRuleUsed || 'Regra Padrão',
      },
      idempotencyKey: initKey,
      lastOperationIdempotencyKey: isCompleted ? confKey : initKey,
      externalPaymentReference: `ref-${bk.code.toLowerCase()}`,
      externalTransactionId: isCompleted
        ? `tx-gw-${bk.code.toLowerCase()}`
        : null,
      confirmationOrigin: isCompleted ? 'GATEWAY_WEBHOOK' : null,
      failureReason: isCancelled ? bk.rejectionReason || 'Cancelada' : null,
      refundReason: null,
      requestedRefundAmount: null,
      paidAt: isCompleted ? nowIso : null,
      failedAt: null,
      cancelledAt: isCancelled ? nowIso : null,
      refundedAt: null,
      createdBy: 'seed-system',
      updatedBy: 'seed-system',
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    payments.push(payRec);

    paymentHistory.push({
      id: `phist-seed-${bk.id}`,
      paymentId: payRec.id,
      bookingId: bk.id,
      bookingCode: bk.code,
      partnerId: bk.partnerId,
      previousStatus: isCompleted ? 'PENDENTE' : null,
      newStatus: pStatus,
      actorId: 'seed-system',
      actorRole: 'admin',
      actorName: 'Sistema / Seed Inicial',
      idempotencyKey: isCompleted ? confKey : initKey,
      amountSnapshot: gross,
      refundAmountSnapshot: 0,
      reason: isCompleted
        ? `Pagamento confirmado via gateway (${payRec.externalTransactionId})`
        : `Pagamento iniciado (${method})`,
      metadata: { seed: true },
      createdAt: nowIso,
    });

    ledgerEntries.push({
      id: `fl-prov-seed-${bk.id}`,
      bookingId: bk.id,
      bookingCode: bk.code,
      paymentId: payRec.id,
      partnerId: bk.partnerId,
      entryType: 'COMMISSION_PROVISIONED',
      grossDelta: 0,
      commissionDelta: 0,
      netPartnerDelta: 0,
      currency: 'BRL',
      idempotencyKey: `ledger-prov-${bk.id}`,
      description: `Provisão inicial de comissão (${payRec.commissionRuleLabel}) para reserva ${bk.code}`,
      actorId: 'seed-system',
      actorRole: 'admin',
      createdAt: nowIso,
    });

    if (isCompleted) {
      ledgerEntries.push({
        id: `fl-conf-seed-${bk.id}`,
        bookingId: bk.id,
        bookingCode: bk.code,
        paymentId: payRec.id,
        partnerId: bk.partnerId,
        entryType: 'PAYMENT_CONFIRMED',
        grossDelta: gross,
        commissionDelta: comm,
        netPartnerDelta: net,
        currency: 'BRL',
        idempotencyKey: `ledger-payconf-${bk.id}`,
        description: `Pagamento confirmado (${method} • Ref: ${payRec.externalTransactionId})`,
        actorId: 'seed-system',
        actorRole: 'admin',
        createdAt: nowIso,
      });
    }

    processedIdempotencyKeys[initKey] = {
      bookingId: bk.id,
      paymentId: payRec.id,
      operation: 'INITIATE_PAYMENT',
      resultStatus: 'PENDENTE',
      timestamp: nowIso,
    };
    if (isCompleted) {
      processedIdempotencyKeys[confKey] = {
        bookingId: bk.id,
        paymentId: payRec.id,
        operation: 'TRANSITION_PAYMENT',
        resultStatus: 'PAGO',
        timestamp: nowIso,
      };
    }
  }

  return {
    payments,
    paymentHistory,
    ledgerEntries,
    processedIdempotencyKeys,
  };
}

// ============================================================================
// 12. WRAPPERS DE RPC SUPABASE PARA MODO CONECTADO (F02 & F03)
// ============================================================================

export async function rpcCreateOrInitiateBookingPayment(
  params: InitiateBookingPaymentInput
): Promise<{
  executedOnServer: boolean;
  data: Record<string, unknown> | null;
  error: string | null;
}> {
  if (!isSupabaseConfigured || !supabase) {
    return { executedOnServer: false, data: null, error: null };
  }
  const { data, error } = await supabase.rpc(
    'create_or_initiate_booking_payment',
    {
      p_booking_id: params.bookingId,
      p_payment_method: params.paymentMethod,
      p_idempotency_key: params.idempotencyKey,
      p_client_gross_amount: null,
      p_external_transaction_id: params.externalPaymentReference ?? null,
    }
  );
  if (error) {
    return { executedOnServer: true, data: null, error: error.message };
  }
  return {
    executedOnServer: true,
    data: data as Record<string, unknown>,
    error: null,
  };
}

export async function rpcConfirmOrFailBookingPayment(
  params: TransitionBookingPaymentInput
): Promise<{
  executedOnServer: boolean;
  data: Record<string, unknown> | null;
  error: string | null;
}> {
  if (!isSupabaseConfigured || !supabase) {
    return { executedOnServer: false, data: null, error: null };
  }
  const { data, error } = await supabase.rpc(
    'confirm_or_fail_booking_payment',
    {
      p_booking_id: params.bookingId,
      p_target_status: params.targetStatus,
      p_idempotency_key: params.idempotencyKey,
      p_external_transaction_id: params.externalTransactionId ?? null,
      p_client_gross_amount: null,
      p_reason: params.reason ?? null,
    }
  );
  if (error) {
    return { executedOnServer: true, data: null, error: error.message };
  }
  return {
    executedOnServer: true,
    data: data as Record<string, unknown>,
    error: null,
  };
}

export async function rpcRequestBookingRefund(
  params: RequestBookingRefundInput
): Promise<{
  executedOnServer: boolean;
  data: RequestBookingRefundResponse | null;
  error: string | null;
}> {
  if (!isSupabaseConfigured || !supabase) {
    return { executedOnServer: false, data: null, error: null };
  }
  const { data, error } = await supabase.rpc('request_booking_refund', {
    p_booking_id: params.bookingId,
    p_refund_amount: params.requestedRefundAmount ?? null,
    p_idempotency_key: params.idempotencyKey,
    p_reason: params.reason,
  });
  if (error) {
    return { executedOnServer: true, data: null, error: error.message };
  }
  return {
    executedOnServer: true,
    data: data as RequestBookingRefundResponse,
    error: null,
  };
}

export async function rpcProcessBookingRefund(
  params: ProcessBookingRefundInput
): Promise<{
  executedOnServer: boolean;
  data: Record<string, unknown> | null;
  error: string | null;
}> {
  if (!isSupabaseConfigured || !supabase) {
    return { executedOnServer: false, data: null, error: null };
  }
  const { data, error } = await supabase.rpc('process_booking_refund', {
    p_booking_id: params.bookingId,
    p_refund_amount: params.refundAmount ?? null,
    p_reason: params.reason,
    p_idempotency_key: params.idempotencyKey,
    p_mark_booking_cancelled:
      params.markBookingCancelled !== undefined
        ? params.markBookingCancelled
        : true,
  });
  if (error) {
    return { executedOnServer: true, data: null, error: error.message };
  }
  return {
    executedOnServer: true,
    data: data as Record<string, unknown>,
    error: null,
  };
}

export async function rpcGetFinancialReconciliationReport(
  partnerId?: string | null
): Promise<{
  executedOnServer: boolean;
  data: Record<string, unknown> | null;
  error: string | null;
}> {
  if (!isSupabaseConfigured || !supabase) {
    return { executedOnServer: false, data: null, error: null };
  }
  const { data, error } = await supabase.rpc(
    'get_financial_reconciliation_report',
    {
      p_partner_id: partnerId ?? null,
    }
  );
  if (error) {
    return { executedOnServer: true, data: null, error: error.message };
  }
  return {
    executedOnServer: true,
    data: data as Record<string, unknown>,
    error: null,
  };
}

export { PAYMENT_STATUS_VALUES, PAYMENT_METHOD_VALUES, isValidPaymentStatus };


export function attemptDirectFinancialHistoryMutation(): OperationResult<never> {
  return {
    ok: false,
    errorCode: 'FINANCIAL_HISTORY_IMMUTABLE_FORBIDDEN',
    errorMessage:
      'Os registros de booking_payment_history e financial_ledger_entries são append-only e imutáveis.',
  };
}
