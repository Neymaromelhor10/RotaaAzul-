// ============================================================================
// CAMADA OPERACIONAL, PAINEL ADMINISTRATIVO E GESTÃO DE PARCEIROS (ROTA AZUL)
// Projeto: Ubatuba Mar & Praias — Missão 02.18 (Missão C — Operação e Parceiros)
// Arquitetura em 5 Camadas:
//   1. Tratamento Padronizado de Erros & Contratos Operacionais
//   2. Autorização Fail-Closed e Separação Estrita de Perfis (Admin / Parceiro / Turista)
//   3. Validadores de Domínio e Integridade Relacional/Capacidade
//   4. Repositório & Adaptador de Persistência com Histórico Auditável
//   5. Serviços de Negócio (Indicadores Admin, Parceiros, Passeios, Embarcações,
//      Consulta Administrativa de Reservas sem Tokens/Segredos e Saídas/Ocupação)
// ============================================================================

import {
  ACTIVE_CAPACITY_BOOKING_STATUSES,
  AppRole,
  AvailabilityBlockType,
  BookingChannelType,
  BookingStatusType,
  LedgerStatusType,
  PartnerCommissionModelUI,
  PartnerStatus,
  PricingModelType,
  TourOperationType,
  VesselOperationMode,
  VesselType,
  deriveLedgerStatusFromBookingStatus,
  normalizeBookingStatus,
  validateBookingStatusTransition,
} from '../types/database.types';
import {
  getBrazilCurrentDateIso,
  getBrazilFutureDateIso,
  isBookingDateValidInBrazil,
} from './bookingService';
import { VerifiedServerSessionContext } from './authTypes';

// ============================================================================
// 1. TIPOS OPERACIONAIS E TRATAMENTO PADRONIZADO DE ERROS (SEÇÕES 3, 4, 5 E 6)
// ============================================================================

export type OperationalErrorCode =
  | 'UNAUTHORIZED_OPERATION'
  | 'CROSS_TENANT_ACCESS_DENIED'
  | 'AUTH_REQUIRED_MISSAO_02_19'
  | 'VALIDATION_ERROR'
  | 'DUPLICATE_ENTITY'
  | 'NOT_FOUND'
  | 'DEPENDENCY_CONFLICT'
  | 'CAPACITY_CONFLICT'
  | 'PAST_DEPARTURE_IMMUTABLE'
  | 'INVALID_STATUS_TRANSITION';

export interface OperationResult<T> {
  ok: boolean;
  data?: T;
  errorCode?: OperationalErrorCode;
  errorMessage?: string;
  fieldErrors?: Record<string, string>;
}

export function createSuccessResult<T>(data: T): OperationResult<T> {
  return { ok: true, data };
}

export function createErrorResult<T = never>(
  errorCode: OperationalErrorCode,
  errorMessage: string,
  fieldErrors?: Record<string, string>
): OperationResult<T> {
  return {
    ok: false,
    errorCode,
    errorMessage,
    fieldErrors,
  };
}

export type DeparturePointType =
  | 'Saco da Ribeira'
  | 'Praia do Itaguá'
  | 'Praia de Picinguaba'
  | 'Praia da Enseada';

export const ALLOWED_DEPARTURE_POINTS: readonly DeparturePointType[] = [
  'Saco da Ribeira',
  'Praia do Itaguá',
  'Praia de Picinguaba',
  'Praia da Enseada',
] as const;

export type TourCategoryType =
  | 'Passeios de lancha'
  | 'Passeios de escuna'
  | 'Passeios compartilhados'
  | 'Passeios privativos'
  | 'Passeios para famílias'
  | 'Passeios para grupos'
  | 'Experiências personalizadas';

export type VesselOperationalStatus = 'DISPONIVEL' | 'MANUTENCAO' | 'INATIVA';

export type DepartureStatusType =
  | 'DISPONIVEL'
  | 'PARCIALMENTE_OCUPADA'
  | 'LOTADA'
  | 'BLOQUEADA_AGENDA'
  | 'ENCERRADA_PASSADA'
  | 'INATIVA';

export interface OperationalPartnerRecord {
  id: string;
  name: string;
  legalName: string;
  cnpj: string;
  whatsapp: string;
  email: string;
  baseMarina: string;
  status: PartnerStatus;
  isActive?: boolean;
  verified: boolean;
  rating: number;
  reviewsCount: number;
  yearsOperating: number;
  commissionModel: PartnerCommissionModelUI;
  commissionRate: number;
  commissionFixed: number;
  bio: string;
  avatarImage: string;
  rejectionReason?: string;
  updatedAt?: string;
}

export interface OperationalVesselRecord {
  id: string;
  slug: string;
  name: string;
  partnerId: string;
  type: VesselType;
  operationMode: VesselOperationMode;
  capacity: number;
  lengthFeet: number;
  engineSpec: string;
  baseLocation: string;
  description: string;
  features: string[];
  structure: string[];
  safetyEquipment: string[];
  heroImage: string;
  gallery: string[];
  videoTitle: string;
  rating: number;
  isActive?: boolean;
  availabilityStatus?: VesselOperationalStatus;
  updatedAt?: string;
}

export interface OperationalTourRecord {
  id: string;
  slug: string;
  title: string;
  vesselId: string;
  partnerId: string;
  category: TourCategoryType;
  tourType: TourOperationType;
  vesselType: VesselType;
  pricingModel: PricingModelType;
  price: number;
  capacity: number;
  durationHours: number;
  departureTime: string;
  returnTime: string;
  checkInTime: string;
  departurePoint: DeparturePointType;
  itineraryId: string;
  destinationsVisited: string[];
  swimmingStops: { place: string; duration: string; description: string }[];
  includedItems: string[];
  importantInfo: string[];
  cancellationPolicy: string;
  customCommissionPercent?: number;
  customCommissionFixed?: number;
  status: 'APROVADO' | 'PENDENTE_APROVACAO' | 'REPROVADO' | 'SUSPENSO' | 'RASCUNHO';
  isActive?: boolean;
  featured: boolean;
  heroImage: string;
  gallery: string[];
  videoTitle: string;
  rating: number;
  reviewsCount: number;
  seoKeywords: string[];
  updatedAt?: string;
}

export interface OperationalBookingRecord {
  id: string;
  code: string;
  tourId: string;
  tourTitle: string;
  vesselId: string;
  vesselName: string;
  partnerId: string;
  partnerName: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  date: string;
  passengers: number;
  channel: BookingChannelType;
  utmSource: string;
  utmCampaign: string;
  status: BookingStatusType;
  ledgerStatus?: LedgerStatusType;
  grossAmount: number;
  commissionRuleUsed: string;
  commissionAmount: number;
  netPartnerAmount: number;
  commissionConsolidated: boolean;
  createdAt: string;
  lookupToken?: string;
  idempotencyKey?: string;
  notes?: string;
  rejectionReason?: string;
}

export interface OperationalAvailabilityBlockRecord {
  id: string;
  partnerId: string;
  vesselId: string;
  vesselName: string;
  blockDate: string;
  blockType: AvailabilityBlockType;
  adjustedCapacity?: number;
  reason: string;
}

export interface OperationalAuditLogRecord {
  id: string;
  timestamp: string;
  actor: string;
  role: AppRole;
  action: string;
  target: string;
  details: string;
}

export interface OperationalHistoryEntry {
  id: string;
  timestamp: string;
  entityType: 'PARTNER' | 'TOUR' | 'VESSEL' | 'BOOKING' | 'DEPARTURE';
  entityId: string;
  entityName: string;
  partnerId: string;
  actorRole: AppRole;
  actorName: string;
  action: string;
  summary: string;
}

export interface OperationalStateSnapshot {
  partners: OperationalPartnerRecord[];
  vessels: OperationalVesselRecord[];
  tours: OperationalTourRecord[];
  bookings: OperationalBookingRecord[];
  availabilityBlocks: OperationalAvailabilityBlockRecord[];
  auditLogs: OperationalAuditLogRecord[];
  changeHistory: OperationalHistoryEntry[];
  isConnectedMode?: boolean;
  isDemoEnvironment?: boolean;
  currentBrazilDate?: string;
}

// ============================================================================
// 2. AUTORIZAÇÃO FAIL-CLOSED E SEPARAÇÃO DE RESPONSABILIDADES (SEÇÕES 4 E 6)
// ============================================================================

export interface OperationalAuthContext {
  actorRole: AppRole;
  actorId: string;
  actorName?: string;
  actorPartnerId?: string | null;
  authorizedPartnerIds?: string[];
  isConnectedMode?: boolean;
  serverVerifiedRole?: AppRole;
  hasServerVerifiedSession?: boolean;
  verifiedSession?: VerifiedServerSessionContext | null;
}

/**
 * Valida a autorização de qualquer operação administrativa ou de parceiro em modo fail-closed.
 * - Não confia em estado local quando isConnectedMode === true: exige sessão autenticada verificada no servidor (Missão 02.19).
 * - Bloqueia turistas de acessar qualquer operação administrativa ou de parceiros.
 * - Impede que um parceiro acesse ou modifique registros de outro parceiro (isolamento multi-tenant).
 */
export function authorizeOperationalAction(
  authCtx: OperationalAuthContext | null | undefined,
  allowedRoles: readonly ('admin' | 'partner')[],
  targetPartnerId?: string | null,
  state?: { partners?: readonly OperationalPartnerRecord[] } | null
): OperationResult<{ effectiveRole: 'admin' | 'partner'; authorizedPartnerId: string | null }> {
  if (!authCtx || typeof authCtx !== 'object') {
    return createErrorResult(
      'UNAUTHORIZED_OPERATION',
      'Contexto de autorização ausente. Operação bloqueada por segurança (fail-closed).'
    );
  }

  // Integração Missão 02.19 (Seção 9): quando há VerifiedServerSessionContext, valida os 5 fatores no servidor:
  // 1) Identidade autenticada e token não expirado; 2) Situação ativa da conta; 3) Perfil autorizado no servidor;
  // 4) Associação usuário-parceiro determinada pelo servidor (bloqueando manipulação de actorPartnerId); 5) Permissão da operação.
  if (authCtx.verifiedSession) {
    const vs = authCtx.verifiedSession;
    if (
      vs.accountState === 'SESSION_EXPIRED' ||
      (typeof vs.sessionExpiresAt === 'number' && vs.sessionExpiresAt <= Date.now())
    ) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'SESSION_EXPIRED: Sua sessão expirou. Autentique-se novamente para realizar esta operação.'
      );
    }
    if (!vs.isAuthenticated || !vs.sessionTokenVerified || !vs.userId) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'UNAUTHENTICATED: Identidade não autenticada ou token de sessão não verificado pelo servidor.'
      );
    }
    if (!vs.isActiveProfile || vs.accountState === 'ACCOUNT_DISABLED') {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'ACCOUNT_DISABLED: Sua conta encontra-se desativada e não pode executar operações.'
      );
    }
    if (
      vs.accountState === 'PARTNER_PENDING_APPROVAL' ||
      vs.partnerOnboardingStage === 'PENDENTE' ||
      vs.partnerOnboardingStage === 'EM_ANALISE'
    ) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'ACCOUNT_PENDING_APPROVAL: Cadastro de parceiro pendente de aprovação administrativa.'
      );
    }
    if (
      vs.accountState === 'PARTNER_SUSPENDED' ||
      vs.accountState === 'PARTNER_REJECTED' ||
      vs.partnerOnboardingStage === 'SUSPENSO' ||
      vs.partnerOnboardingStage === 'REJEITADO' ||
      vs.partnerStatus === 'SUSPENSO'
    ) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'ACCOUNT_SUSPENDED: Conta de parceiro suspensa ou reprovada pela administração.'
      );
    }
    if (authCtx.actorRole && authCtx.actorRole !== vs.serverRole) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        `PRIVILEGE_ESCALATION_BLOCKED: Divergência entre perfil enviado pelo cliente ("${authCtx.actorRole}") e perfil verificado no servidor ("${vs.serverRole}").`
      );
    }
    if (vs.serverRole === 'tourist') {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'Turistas não possuem permissão para executar operações administrativas ou de parceiros.'
      );
    }
    if (!allowedRoles.includes(vs.serverRole)) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        `O perfil autenticado "${vs.serverRole}" não possui permissão para executar esta operação.`
      );
    }
    if (vs.serverRole === 'partner') {
      const serverPartnerId = vs.primaryPartnerId;
      if (
        !serverPartnerId ||
        !vs.authorizedPartnerIds.includes(serverPartnerId) ||
        vs.partnerStatus !== 'APROVADO' ||
        vs.partnerOnboardingStage !== 'APROVADO'
      ) {
        return createErrorResult(
          'CROSS_TENANT_ACCESS_DENIED',
          'Usuário parceiro não possui associação ativa e homologada no servidor.'
        );
      }
      if (
        authCtx.actorPartnerId &&
        authCtx.actorPartnerId !== serverPartnerId
      ) {
        return createErrorResult(
          'CROSS_TENANT_ACCESS_DENIED',
          `Manipulação de actorPartnerId bloqueada: o servidor determinou o parceiro "${serverPartnerId}", rejeitando "${authCtx.actorPartnerId}".`
        );
      }
      if (targetPartnerId && targetPartnerId !== serverPartnerId) {
        return createErrorResult(
          'CROSS_TENANT_ACCESS_DENIED',
          `Isolamento multiempresa: o parceiro autenticado "${serverPartnerId}" não tem permissão sobre "${targetPartnerId}".`
        );
      }
      // M02.20-F02: Revalidação em tempo real contra o estado vivo do parceiro (bloqueia sessões pré-existentes caso o parceiro tenha sido suspenso ou desativado)
      if (state && Array.isArray(state.partners)) {
        const livePartner = state.partners.find((p) => p.id === serverPartnerId);
        if (livePartner) {
          if (livePartner.status === 'SUSPENSO' || livePartner.isActive === false) {
            return createErrorResult(
              'UNAUTHORIZED_OPERATION',
              `ACCOUNT_SUSPENDED: O parceiro "${livePartner.name}" encontra-se suspenso ou desativado operacionalmente pela administração.`
            );
          }
          if (livePartner.status === 'PENDENTE') {
            return createErrorResult(
              'UNAUTHORIZED_OPERATION',
              `ACCOUNT_PENDING_APPROVAL: O parceiro "${livePartner.name}" aguarda aprovação administrativa.`
            );
          }
        }
      }
      return createSuccessResult({
        effectiveRole: 'partner',
        authorizedPartnerId: serverPartnerId,
      });
    }
    return createSuccessResult({
      effectiveRole: 'admin',
      authorizedPartnerId: targetPartnerId || null,
    });
  }

  // Em modo conectado ao Supabase, jamais confiar apenas em estado local de UI sem sessão verificada pelo servidor
  if (authCtx.isConnectedMode) {
    if (!authCtx.hasServerVerifiedSession || !authCtx.actorId) {
      return createErrorResult(
        'AUTH_REQUIRED_MISSAO_02_19',
        'Esta operação exige sessão autenticada no servidor (Missão 02.19). Ação bloqueada em modo fail-closed.'
      );
    }
    const verifiedRole = authCtx.serverVerifiedRole || 'tourist';
    if (verifiedRole === 'tourist') {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'Perfil de turista não possui permissão para acessar o painel administrativo ou operacional.'
      );
    }
    if (!allowedRoles.includes(verifiedRole)) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        `O perfil autenticado "${verifiedRole}" não possui permissão para executar esta operação.`
      );
    }
    if (verifiedRole === 'partner') {
      const allowedList = authCtx.authorizedPartnerIds || [];
      const activePid = authCtx.actorPartnerId || '';
      if (!activePid || !allowedList.includes(activePid)) {
        return createErrorResult(
          'CROSS_TENANT_ACCESS_DENIED',
          'Parceiro autenticado sem vínculo ativo autorizado para esta operação.'
        );
      }
      if (targetPartnerId && targetPartnerId !== activePid) {
        return createErrorResult(
          'CROSS_TENANT_ACCESS_DENIED',
          `Isolamento multi-tenant violado: o parceiro "${activePid}" não pode acessar ou alterar dados do parceiro "${targetPartnerId}".`
        );
      }
      if (state && Array.isArray(state.partners)) {
        const livePartner = state.partners.find((p) => p.id === activePid);
        if (livePartner) {
          if (livePartner.status === 'SUSPENSO' || livePartner.isActive === false) {
            return createErrorResult(
              'UNAUTHORIZED_OPERATION',
              `ACCOUNT_SUSPENDED: O parceiro "${livePartner.name}" encontra-se suspenso ou desativado operacionalmente.`
            );
          }
          if (livePartner.status === 'PENDENTE') {
            return createErrorResult(
              'UNAUTHORIZED_OPERATION',
              `ACCOUNT_PENDING_APPROVAL: O parceiro "${livePartner.name}" aguarda aprovação administrativa.`
            );
          }
        }
      }
      return createSuccessResult({ effectiveRole: 'partner', authorizedPartnerId: activePid });
    }
    return createSuccessResult({ effectiveRole: 'admin', authorizedPartnerId: targetPartnerId || null });
  }

  // Modo isolado / demonstrativo controlado: aplica rigorosamente a matriz de papéis e isolamento de tenant
  if (authCtx.actorRole === 'tourist') {
    return createErrorResult(
      'UNAUTHORIZED_OPERATION',
      'Turistas não têm acesso ao painel administrativo ou de parceiros.'
    );
  }

  if (!allowedRoles.includes(authCtx.actorRole)) {
    return createErrorResult(
      'UNAUTHORIZED_OPERATION',
      `O perfil "${authCtx.actorRole}" não está autorizado a executar esta operação (requer: ${allowedRoles.join(' ou ')}).`
    );
  }

  if (authCtx.actorRole === 'partner') {
    const activePid = (authCtx.actorPartnerId || '').trim();
    if (!activePid || activePid === '__tourist_no_partner__') {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'Identificador de parceiro ausente ou inválido para operação do portal de parceiros.'
      );
    }
    if (targetPartnerId && targetPartnerId !== activePid) {
      return createErrorResult(
        'CROSS_TENANT_ACCESS_DENIED',
        `Isolamento multi-tenant: o parceiro "${activePid}" não tem permissão para visualizar ou alterar recursos do parceiro "${targetPartnerId}".`
      );
    }
    if (state && Array.isArray(state.partners)) {
      const livePartner = state.partners.find((p) => p.id === activePid);
      if (livePartner && (livePartner.status === 'SUSPENSO' || livePartner.isActive === false)) {
        return createErrorResult(
          'UNAUTHORIZED_OPERATION',
          `ACCOUNT_SUSPENDED: O parceiro "${livePartner.name}" encontra-se suspenso ou desativado operacionalmente.`
        );
      }
    }
    return createSuccessResult({ effectiveRole: 'partner', authorizedPartnerId: activePid });
  }

  return createSuccessResult({ effectiveRole: 'admin', authorizedPartnerId: targetPartnerId || null });
}

// ============================================================================
// 3. VALIDADORES DE DOMÍNIO E PENDÊNCIAS CADASTRAIS (SEÇÕES 3.2, 3.3, 3.4 E 6)
// ============================================================================

export function normalizeDigits(value: string): string {
  return String(value || '').replace(/\D+/g, '');
}

export function isValidTimeHHMM(value: string): boolean {
  if (typeof value !== 'string') return false;
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(value.trim());
  return Boolean(m);
}

export function timeHHMMToMinutes(value: string): number {
  if (!isValidTimeHHMM(value)) return -1;
  const [hh, mm] = value.trim().split(':').map(Number);
  return hh * 60 + mm;
}

export function isPartnerEffectivelyActive(partner: OperationalPartnerRecord): boolean {
  return partner.status === 'APROVADO' && partner.isActive !== false;
}

export function isVesselEffectivelyActive(vessel: OperationalVesselRecord): boolean {
  return (
    vessel.isActive !== false &&
    vessel.availabilityStatus !== 'INATIVA' &&
    vessel.availabilityStatus !== 'MANUTENCAO'
  );
}

export function isTourEffectivelyActive(tour: OperationalTourRecord): boolean {
  return tour.status === 'APROVADO' && tour.isActive !== false;
}

export function identifyPartnerPendingIssues(
  partner: OperationalPartnerRecord,
  vessels: readonly OperationalVesselRecord[],
  tours: readonly OperationalTourRecord[]
): string[] {
  const issues: string[] = [];
  const cnpjDigits = normalizeDigits(partner.cnpj);
  const phoneDigits = normalizeDigits(partner.whatsapp);

  if (partner.status === 'PENDENTE') {
    issues.push('Aguardando homologação cadastral pela administração');
  }
  if (partner.status === 'SUSPENSO' || partner.isActive === false) {
    issues.push('Cadastro suspenso ou desativado operacionalmente');
  }
  if (cnpjDigits.length !== 14) {
    issues.push('CNPJ ausente ou com formato incompleto (requer 14 dígitos)');
  }
  if (phoneDigits.length < 10) {
    issues.push('WhatsApp operacional inválido ou incompleto');
  }
  if (!partner.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(partner.email.trim())) {
    issues.push('E-mail corporativo pendente de validação');
  }
  if (!partner.baseMarina || partner.baseMarina.trim().length < 3) {
    issues.push('Marina base de operação não informada');
  }

  const partnerVessels = vessels.filter((v) => v.partnerId === partner.id);
  if (partnerVessels.length === 0) {
    issues.push('Nenhuma embarcação vinculada à frota do parceiro');
  }

  const partnerTours = tours.filter((t) => t.partnerId === partner.id);
  if (partnerTours.length === 0) {
    issues.push('Nenhum passeio cadastrado para este parceiro');
  }

  return issues;
}

export interface CreateOrUpdatePartnerInput {
  name: string;
  legalName: string;
  cnpj: string;
  whatsapp: string;
  email: string;
  baseMarina: string;
  commissionModel?: PartnerCommissionModelUI;
  commissionRate?: number;
  commissionFixed?: number;
  yearsOperating?: number;
  bio?: string;
  avatarImage?: string;
  status?: PartnerStatus;
  isActive?: boolean;
}

export function validatePartnerInput(
  input: Partial<CreateOrUpdatePartnerInput>,
  isPartialUpdate = false
): OperationResult<void> {
  const fieldErrors: Record<string, string> = {};

  if (!isPartialUpdate || input.name !== undefined) {
    if (!input.name || input.name.trim().length < 3) {
      fieldErrors.name = 'Nome fantasia do parceiro deve ter pelo menos 3 caracteres.';
    }
  }

  if (!isPartialUpdate || input.legalName !== undefined) {
    if (!input.legalName || input.legalName.trim().length < 3) {
      fieldErrors.legalName = 'Razão social deve ter pelo menos 3 caracteres.';
    }
  }

  if (!isPartialUpdate || input.cnpj !== undefined) {
    const digits = normalizeDigits(input.cnpj || '');
    if (digits.length !== 14 || /^(\d)\1{13}$/.test(digits)) {
      fieldErrors.cnpj = 'CNPJ inválido. Informe os 14 dígitos numéricos válidos.';
    }
  }

  if (!isPartialUpdate || input.whatsapp !== undefined) {
    const phoneDigits = normalizeDigits(input.whatsapp || '');
    if (phoneDigits.length < 10 || phoneDigits.length > 15) {
      fieldErrors.whatsapp = 'WhatsApp operacional deve conter entre 10 e 15 dígitos.';
    }
  }

  if (!isPartialUpdate || input.email !== undefined) {
    const email = (input.email || '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      fieldErrors.email = 'E-mail de contato inválido.';
    }
  }

  if (!isPartialUpdate || input.baseMarina !== undefined) {
    if (!input.baseMarina || input.baseMarina.trim().length < 3) {
      fieldErrors.baseMarina = 'Marina de base deve ser informada.';
    }
  }

  if (input.commissionRate !== undefined) {
    const rate = Number(input.commissionRate);
    if (!Number.isFinite(rate) || rate < 0 || rate > 50) {
      fieldErrors.commissionRate = 'Taxa de comissão percentual deve estar entre 0% e 50%.';
    }
  }

  if (input.commissionFixed !== undefined) {
    const fixed = Number(input.commissionFixed);
    if (!Number.isFinite(fixed) || fixed < 0 || fixed > 5000) {
      fieldErrors.commissionFixed = 'Comissão fixa deve estar entre R$ 0 e R$ 5.000.';
    }
  }

  if (Object.keys(fieldErrors).length > 0) {
    return createErrorResult(
      'VALIDATION_ERROR',
      Object.values(fieldErrors)[0],
      fieldErrors
    );
  }

  return createSuccessResult(undefined);
}

// ============================================================================
// 4. SERVIÇO DE DISPONIBILIDADE CANÔNICA E GESTÃO DE SAÍDAS (SEÇÃO 3.6)
// ============================================================================

export interface CanonicalDepartureOccupancy {
  departureId: string;
  date: string;
  departureTime: string;
  returnTime: string;
  checkInTime: string;
  departurePoint: DeparturePointType;
  tourId: string;
  tourTitle: string;
  tourType: TourOperationType;
  vesselId: string;
  vesselName: string;
  vesselType: VesselType;
  partnerId: string;
  partnerName: string;
  baseCapacity: number;
  effectiveCapacity: number;
  reservedPassengers: number;
  remainingSeats: number;
  occupancyPercent: number;
  departureStatus: DepartureStatusType;
  blockReason: string;
  isPastDate: boolean;
  isAvailableForNewBookings: boolean;
  activeBookingsCount: number;
}

/**
 * Reutiliza exatamente o contrato de disponibilidade das Missões 01..02.16
 * (sem duplicar uma lógica divergente): respeita bloqueios de agenda,
 * conflito privativo vs compartilhado, capacidade máxima da embarcação e
 * bloqueio de datas passadas em America/Sao_Paulo.
 */
export function computeCanonicalDepartureOccupancy(params: {
  tour: OperationalTourRecord;
  vessel: OperationalVesselRecord | undefined;
  partner: OperationalPartnerRecord | undefined;
  date: string;
  bookings: readonly OperationalBookingRecord[];
  availabilityBlocks: readonly OperationalAvailabilityBlockRecord[];
  currentBrazilDate?: string;
}): CanonicalDepartureOccupancy {
  const { tour, vessel, partner, date, bookings, availabilityBlocks } = params;
  const refToday = params.currentBrazilDate || getBrazilCurrentDateIso();
  const isPastDate = date < refToday;

  const baseCapacity = Math.min(
    Math.max(1, Number(tour.capacity) || 1),
    vessel ? Math.max(1, Number(vessel.capacity) || 1) : Math.max(1, Number(tour.capacity) || 1)
  );
  let effectiveCapacity = baseCapacity;
  let blockedBySchedule = false;
  let blockReason = '';

  const blocksOnDate = availabilityBlocks.filter(
    (b) => b.vesselId === tour.vesselId && b.blockDate === date
  );
  for (const blk of blocksOnDate) {
    if (blk.blockType === 'AJUSTE_CAPACIDADE' && typeof blk.adjustedCapacity === 'number') {
      effectiveCapacity = Math.min(effectiveCapacity, Math.max(1, blk.adjustedCapacity));
    } else {
      blockedBySchedule = true;
      blockReason = `${blk.blockType}: ${blk.reason}`;
      break;
    }
  }

  const activeBookingsOnVesselDate = bookings.filter((b) => {
    const st = normalizeBookingStatus(b.status);
    return (
      b.vesselId === tour.vesselId &&
      b.date === date &&
      ACTIVE_CAPACITY_BOOKING_STATUSES.includes(st)
    );
  });

  const activeBookingsForTour = activeBookingsOnVesselDate.filter((b) => b.tourId === tour.id);
  const reservedPassengers = activeBookingsOnVesselDate.reduce(
    (sum, b) => sum + Math.max(0, Number(b.passengers) || 0),
    0
  );

  const hasPrivateBooking = activeBookingsOnVesselDate.some(
    (b) => b.tourId === tour.id ? tour.tourType === 'Privativo' : b.passengers >= effectiveCapacity
  );

  const partnerActive = partner ? isPartnerEffectivelyActive(partner) : false;
  const vesselActive = vessel ? isVesselEffectivelyActive(vessel) : false;
  const tourActive = isTourEffectivelyActive(tour);

  let departureStatus: DepartureStatusType = 'DISPONIVEL';
  let remainingSeats = Math.max(0, effectiveCapacity - reservedPassengers);

  if (isPastDate) {
    departureStatus = 'ENCERRADA_PASSADA';
    remainingSeats = 0;
    blockReason = blockReason || `BOOKING_DATE_IN_PAST: Saída encerrada (${date} < ${refToday}).`;
  } else if (!partnerActive || !vesselActive || !tourActive) {
    departureStatus = 'INATIVA';
    remainingSeats = 0;
    blockReason = !partnerActive
      ? 'Parceiro inativo ou pendente'
      : !vesselActive
      ? `Embarcação indisponível (${vessel?.availabilityStatus || 'INATIVA'})`
      : `Passeio inativo (${tour.status})`;
  } else if (blockedBySchedule) {
    departureStatus = 'BLOQUEADA_AGENDA';
    remainingSeats = 0;
  } else if (tour.tourType === 'Privativo' && activeBookingsOnVesselDate.length > 0) {
    departureStatus = 'LOTADA';
    remainingSeats = 0;
    blockReason = 'Embarcação já reservada nesta data';
  } else if (hasPrivateBooking || remainingSeats === 0) {
    departureStatus = 'LOTADA';
    remainingSeats = 0;
    blockReason = blockReason || 'Lotação máxima atingida nesta data';
  } else if (reservedPassengers > 0) {
    departureStatus = 'PARCIALMENTE_OCUPADA';
  }

  const occupancyPercent =
    effectiveCapacity > 0
      ? Math.min(100, Math.round((reservedPassengers / effectiveCapacity) * 100))
      : 0;

  return {
    departureId: `dep-${tour.id}-${date}`,
    date,
    departureTime: tour.departureTime || '09:30',
    returnTime: tour.returnTime || '15:00',
    checkInTime: tour.checkInTime || '09:00',
    departurePoint: tour.departurePoint,
    tourId: tour.id,
    tourTitle: tour.title,
    tourType: tour.tourType,
    vesselId: tour.vesselId,
    vesselName: vessel?.name || 'Embarcação não localizada',
    vesselType: vessel?.type || tour.vesselType,
    partnerId: tour.partnerId,
    partnerName: partner?.name || 'Parceiro não localizado',
    baseCapacity,
    effectiveCapacity,
    reservedPassengers,
    remainingSeats,
    occupancyPercent,
    departureStatus,
    blockReason,
    isPastDate,
    isAvailableForNewBookings:
      !isPastDate &&
      departureStatus !== 'LOTADA' &&
      departureStatus !== 'BLOQUEADA_AGENDA' &&
      departureStatus !== 'INATIVA' &&
      remainingSeats > 0,
    activeBookingsCount: activeBookingsForTour.length,
  };
}

export interface DepartureFilterOptions {
  date?: string;
  includeBookingDates?: boolean;
  partnerId?: string;
  tourId?: string;
  vesselId?: string;
  status?: 'TODOS' | DepartureStatusType;
  search?: string;
}

export function listOperationalDepartures(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  filters?: DepartureFilterOptions
): OperationResult<CanonicalDepartureOccupancy[]> {
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    authCtx.actorRole === 'partner' ? filters?.partnerId || authCtx.actorPartnerId : undefined,
    state
  );
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Acesso negado às saídas operacionais.'
    );
  }

  const refToday = state.currentBrazilDate || getBrazilCurrentDateIso();
  const targetPartnerScope =
    authCheck.data.effectiveRole === 'partner'
      ? authCheck.data.authorizedPartnerId
      : filters?.partnerId && filters.partnerId !== 'TODOS'
      ? filters.partnerId
      : null;

  const scopedTours = state.tours.filter((t) => {
    if (targetPartnerScope && t.partnerId !== targetPartnerScope) return false;
    if (filters?.tourId && filters.tourId !== 'TODOS' && t.id !== filters.tourId) return false;
    if (filters?.vesselId && filters.vesselId !== 'TODOS' && t.vesselId !== filters.vesselId) return false;
    return true;
  });

  const dateSet = new Set<string>();
  if (filters?.date && filters.date.trim() !== '') {
    dateSet.add(filters.date.trim());
  } else {
    dateSet.add(refToday);
    dateSet.add(getBrazilFutureDateIso(1, new Date(`${refToday}T12:00:00Z`)));
    dateSet.add(getBrazilFutureDateIso(3, new Date(`${refToday}T12:00:00Z`)));
    if (filters?.includeBookingDates !== false) {
      for (const bk of state.bookings) {
        if (!targetPartnerScope || bk.partnerId === targetPartnerScope) {
          if (bk.date) dateSet.add(bk.date);
        }
      }
      for (const blk of state.availabilityBlocks) {
        if (!targetPartnerScope || blk.partnerId === targetPartnerScope) {
          if (blk.blockDate) dateSet.add(blk.blockDate);
        }
      }
    }
  }

  const sortedDates = Array.from(dateSet).sort();
  const departures: CanonicalDepartureOccupancy[] = [];

  for (const dateStr of sortedDates) {
    for (const tour of scopedTours) {
      const vessel = state.vessels.find((v) => v.id === tour.vesselId);
      const partner = state.partners.find((p) => p.id === tour.partnerId);
      const dep = computeCanonicalDepartureOccupancy({
        tour,
        vessel,
        partner,
        date: dateStr,
        bookings: state.bookings,
        availabilityBlocks: state.availabilityBlocks,
        currentBrazilDate: refToday,
      });

      if (filters?.status && filters.status !== 'TODOS' && dep.departureStatus !== filters.status) {
        continue;
      }

      if (filters?.search && filters.search.trim() !== '') {
        const q = filters.search.trim().toLowerCase();
        const match =
          dep.tourTitle.toLowerCase().includes(q) ||
          dep.vesselName.toLowerCase().includes(q) ||
          dep.partnerName.toLowerCase().includes(q) ||
          dep.departurePoint.toLowerCase().includes(q) ||
          dep.date.includes(q);
        if (!match) continue;
      }

      departures.push(dep);
    }
  }

  departures.sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    if (a.departureTime !== b.departureTime) return a.departureTime.localeCompare(b.departureTime);
    return a.tourTitle.localeCompare(b.tourTitle);
  });

  return createSuccessResult(departures);
}

// ============================================================================
// 5. PAINEL ADMINISTRATIVO — INDICADORES CONSOLIDADOS REAIS (SEÇÃO 3.1)
// ============================================================================

export interface AdminOperationalDashboardMetrics {
  environmentMode: 'CONNECTED_SUPABASE' | 'DEMO_LOCAL' | 'EMPTY_UNCONFIGURED';
  isEmptyState: boolean;
  totalTours: number;
  activeTours: number;
  inactiveTours: number;
  pendingApprovalTours: number;
  totalPartners: number;
  activePartners: number;
  pendingPartners: number;
  suspendedOrInactivePartners: number;
  totalVessels: number;
  activeVessels: number;
  inactiveOrMaintenanceVessels: number;
  bookingsReceived: number;
  bookingsPending: number;
  bookingsConfirmed: number;
  bookingsCancelledOrRejected: number;
  completedToursCount: number;
  disputedBookingsCount: number;
  grossConsolidatedAmount: number;
  commissionConsolidatedAmount: number;
  commissionPendingAmount: number;
  departuresSummary: {
    totalTrackedDepartures: number;
    availableDepartures: number;
    partiallyOccupiedDepartures: number;
    fullDepartures: number;
    blockedDepartures: number;
    pastDepartures: number;
    totalCapacitySeats: number;
    totalReservedSeats: number;
    totalRemainingSeats: number;
    averageOccupancyPercent: number;
  };
  recentActivities: OperationalHistoryEntry[];
}

export function computeAdminDashboardMetrics(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext
): OperationResult<AdminOperationalDashboardMetrics> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin']);
  if (!authCheck.ok) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Somente o perfil Administrador pode consultar os indicadores globais.'
    );
  }

  const totalTours = state.tours.length;
  const activeTours = state.tours.filter((t) => isTourEffectivelyActive(t)).length;
  const inactiveTours = totalTours - activeTours;
  const pendingApprovalTours = state.tours.filter((t) => t.status === 'PENDENTE_APROVACAO').length;

  const totalPartners = state.partners.length;
  const activePartners = state.partners.filter((p) => isPartnerEffectivelyActive(p)).length;
  const pendingPartners = state.partners.filter((p) => p.status === 'PENDENTE').length;
  const suspendedOrInactivePartners = state.partners.filter(
    (p) => p.status === 'SUSPENSO' || p.isActive === false
  ).length;

  const totalVessels = state.vessels.length;
  const activeVessels = state.vessels.filter((v) => isVesselEffectivelyActive(v)).length;
  const inactiveOrMaintenanceVessels = totalVessels - activeVessels;

  const bookingsReceived = state.bookings.length;
  let bookingsPending = 0;
  let bookingsConfirmed = 0;
  let bookingsCancelledOrRejected = 0;
  let completedToursCount = 0;
  let disputedBookingsCount = 0;
  let grossConsolidatedCents = 0;
  let commissionConsolidatedCents = 0;
  let commissionPendingCents = 0;

  const toExactCents = (val: unknown): number => {
    const n = Number(val);
    if (!Number.isFinite(n) || n === 0) return 0;
    const sign = n < 0 ? -1 : 1;
    const absVal = Math.abs(n);
    const rawStr = absVal >= 1e-6 && absVal < 1e20 ? absVal.toString() : absVal.toFixed(12);
    const [intPartRaw, fracPartRaw = ''] = rawStr.split('.');
    const intCents = parseInt(intPartRaw || '0', 10) * 100;
    const paddedFrac = (fracPartRaw + '000').slice(0, 3);
    const firstTwo = parseInt(paddedFrac.slice(0, 2), 10);
    const third = parseInt(paddedFrac.slice(2, 3), 10);
    return sign * (intCents + firstTwo + (third >= 5 ? 1 : 0));
  };

  for (const bk of state.bookings) {
    const st = normalizeBookingStatus(bk.status);
    if (st === 'SOLICITADA' || st === 'AGUARDANDO_CONFIRMACAO') {
      bookingsPending += 1;
      commissionPendingCents += toExactCents(bk.commissionAmount);
    } else if (st === 'CONFIRMADA') {
      bookingsConfirmed += 1;
      commissionPendingCents += toExactCents(bk.commissionAmount);
    } else if (st === 'CANCELADA' || st === 'RECUSADA') {
      bookingsCancelledOrRejected += 1;
    } else if (st === 'PASSEIO_REALIZADO') {
      completedToursCount += 1;
      grossConsolidatedCents += toExactCents(bk.grossAmount);
      commissionConsolidatedCents += toExactCents(bk.commissionAmount);
    } else if (st === 'EM_DISPUTA') {
      disputedBookingsCount += 1;
    }
  }

  const depRes = listOperationalDepartures(state, authCtx);
  const allDepartures = depRes.ok && depRes.data ? depRes.data : [];
  const activeWindowDeps = allDepartures.filter((d) => !d.isPastDate && d.departureStatus !== 'INATIVA');

  const totalCapacitySeats = activeWindowDeps.reduce((acc, d) => acc + d.effectiveCapacity, 0);
  const totalReservedSeats = activeWindowDeps.reduce((acc, d) => acc + d.reservedPassengers, 0);
  const totalRemainingSeats = activeWindowDeps.reduce((acc, d) => acc + d.remainingSeats, 0);
  const averageOccupancyPercent =
    totalCapacitySeats > 0 ? Math.min(100, Math.round((totalReservedSeats / totalCapacitySeats) * 100)) : 0;

  const auditDerivedHistory: OperationalHistoryEntry[] = state.auditLogs.map((log) => ({
    id: log.id,
    timestamp: log.timestamp,
    entityType: 'BOOKING',
    entityId: log.id,
    entityName: log.target,
    partnerId: 'PLATFORM',
    actorRole: log.role,
    actorName: log.actor,
    action: log.action,
    summary: log.details,
  }));

  const recentActivities = [...state.changeHistory, ...auditDerivedHistory].slice(0, 25);

  const isEmptyState =
    totalTours === 0 && totalPartners === 0 && totalVessels === 0 && bookingsReceived === 0;

  const environmentMode: AdminOperationalDashboardMetrics['environmentMode'] = state.isConnectedMode
    ? 'CONNECTED_SUPABASE'
    : state.isDemoEnvironment
    ? 'DEMO_LOCAL'
    : 'EMPTY_UNCONFIGURED';

  return createSuccessResult({
    environmentMode,
    isEmptyState,
    totalTours,
    activeTours,
    inactiveTours,
    pendingApprovalTours,
    totalPartners,
    activePartners,
    pendingPartners,
    suspendedOrInactivePartners,
    totalVessels,
    activeVessels,
    inactiveOrMaintenanceVessels,
    bookingsReceived,
    bookingsPending,
    bookingsConfirmed,
    bookingsCancelledOrRejected,
    completedToursCount,
    disputedBookingsCount,
    grossConsolidatedAmount: grossConsolidatedCents / 100,
    commissionConsolidatedAmount: commissionConsolidatedCents / 100,
    commissionPendingAmount: commissionPendingCents / 100,
    departuresSummary: {
      totalTrackedDepartures: allDepartures.length,
      availableDepartures: allDepartures.filter((d) => d.departureStatus === 'DISPONIVEL').length,
      partiallyOccupiedDepartures: allDepartures.filter((d) => d.departureStatus === 'PARCIALMENTE_OCUPADA').length,
      fullDepartures: allDepartures.filter((d) => d.departureStatus === 'LOTADA').length,
      blockedDepartures: allDepartures.filter((d) => d.departureStatus === 'BLOQUEADA_AGENDA').length,
      pastDepartures: allDepartures.filter((d) => d.isPastDate).length,
      totalCapacitySeats,
      totalReservedSeats,
      totalRemainingSeats,
      averageOccupancyPercent,
    },
    recentActivities,
  });
}

// ============================================================================
// 6. GESTÃO DE PARCEIROS (SEÇÃO 3.2)
// ============================================================================

export interface PartnerDetailedView {
  partner: OperationalPartnerRecord;
  isActive: boolean;
  pendingIssues: string[];
  hasPendingIssues: boolean;
  vesselsCount: number;
  activeVesselsCount: number;
  toursCount: number;
  activeToursCount: number;
  bookingsCount: number;
  history: OperationalHistoryEntry[];
}

export function listPartnersWithOperationalDetails(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  filters?: {
    search?: string;
    status?: 'TODOS' | 'APROVADO' | 'PENDENTE' | 'SUSPENSO' | 'INATIVO' | 'COM_PENDENCIAS';
    targetPartnerId?: string;
  }
): OperationResult<PartnerDetailedView[]> {
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    filters?.targetPartnerId,
    state
  );
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Acesso negado à listagem de parceiros.'
    );
  }

  const effectiveRole = authCheck.data.effectiveRole;
  const scopedPartners =
    effectiveRole === 'partner'
      ? state.partners.filter((p) => p.id === authCheck.data!.authorizedPartnerId)
      : state.partners.filter((p) => !filters?.targetPartnerId || p.id === filters.targetPartnerId);

  const views: PartnerDetailedView[] = [];
  for (const partner of scopedPartners) {
    const pendingIssues = identifyPartnerPendingIssues(partner, state.vessels, state.tours);
    const isActive = isPartnerEffectivelyActive(partner);

    if (filters?.status && filters.status !== 'TODOS') {
      if (filters.status === 'INATIVO') {
        if (partner.isActive !== false && partner.status !== 'SUSPENSO') continue;
      } else if (filters.status === 'COM_PENDENCIAS') {
        if (pendingIssues.length === 0) continue;
      } else if (partner.status !== filters.status) {
        continue;
      }
    }

    if (filters?.search && filters.search.trim() !== '') {
      const q = filters.search.trim().toLowerCase();
      const match =
        partner.name.toLowerCase().includes(q) ||
        partner.legalName.toLowerCase().includes(q) ||
        partner.cnpj.toLowerCase().includes(q) ||
        partner.baseMarina.toLowerCase().includes(q) ||
        partner.email.toLowerCase().includes(q);
      if (!match) continue;
    }

    const partnerVessels = state.vessels.filter((v) => v.partnerId === partner.id);
    const partnerTours = state.tours.filter((t) => t.partnerId === partner.id);
    const partnerBookings = state.bookings.filter((b) => b.partnerId === partner.id);
    const partnerHistory = state.changeHistory.filter(
      (h) => h.partnerId === partner.id || h.entityId === partner.id
    );

    views.push({
      partner: { ...partner, isActive },
      isActive,
      pendingIssues,
      hasPendingIssues: pendingIssues.length > 0,
      vesselsCount: partnerVessels.length,
      activeVesselsCount: partnerVessels.filter((v) => isVesselEffectivelyActive(v)).length,
      toursCount: partnerTours.length,
      activeToursCount: partnerTours.filter((t) => isTourEffectivelyActive(t)).length,
      bookingsCount: partnerBookings.length,
      history: partnerHistory,
    });
  }

  return createSuccessResult(views);
}

export function createPartnerOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  input: CreateOrUpdatePartnerInput
): OperationResult<{ state: OperationalStateSnapshot; partner: OperationalPartnerRecord }> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin']);
  if (!authCheck.ok) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Apenas o Administrador pode cadastrar novos parceiros na plataforma.'
    );
  }

  const val = validatePartnerInput(input, false);
  if (!val.ok) {
    return createErrorResult(
      val.errorCode || 'VALIDATION_ERROR',
      val.errorMessage || 'Dados cadastrais do parceiro inválidos.',
      val.fieldErrors
    );
  }

  const cleanCnpj = normalizeDigits(input.cnpj);
  const duplicate = state.partners.find(
    (p) =>
      normalizeDigits(p.cnpj) === cleanCnpj ||
      p.name.trim().toLowerCase() === input.name.trim().toLowerCase()
  );
  if (duplicate) {
    return createErrorResult(
      'DUPLICATE_ENTITY',
      `Já existe um parceiro cadastrado com o mesmo nome ou CNPJ (${duplicate.name}).`
    );
  }

  const nowIso = new Date().toISOString();
  const slugId = input.name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  const newPartner: OperationalPartnerRecord = {
    id: `part-${slugId || Date.now()}-${state.partners.length + 1}`,
    name: input.name.trim(),
    legalName: input.legalName.trim(),
    cnpj: input.cnpj.trim(),
    whatsapp: normalizeDigits(input.whatsapp),
    email: input.email.trim().toLowerCase(),
    baseMarina: input.baseMarina.trim(),
    status: input.status || 'PENDENTE',
    isActive: input.isActive !== undefined ? input.isActive : true,
    verified: input.status === 'APROVADO',
    rating: 5.0,
    reviewsCount: 0,
    yearsOperating: Math.max(1, Number(input.yearsOperating) || 1),
    commissionModel: input.commissionModel || 'PERCENTAGE',
    commissionRate: Number(input.commissionRate ?? 15),
    commissionFixed: Number(input.commissionFixed ?? 0),
    bio: (input.bio || `Operador náutico credenciado na ${input.baseMarina.trim()}.`).trim(),
    avatarImage: input.avatarImage || '/media/embarcacao-lancha-passa-vinte.jpg',
    updatedAt: nowIso,
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'PARTNER',
    entityId: newPartner.id,
    entityName: newPartner.name,
    partnerId: newPartner.id,
    actorRole: 'admin',
    actorName: authCtx.actorName || 'Admin Master',
    action: 'CREATE_PARTNER',
    summary: `Parceiro "${newPartner.name}" (${newPartner.cnpj}) cadastrado com status ${newPartner.status}.`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    partners: [newPartner, ...state.partners],
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, partner: newPartner });
}

export function updatePartnerOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  partnerId: string,
  patch: Partial<CreateOrUpdatePartnerInput>
): OperationResult<{ state: OperationalStateSnapshot; partner: OperationalPartnerRecord }> {
  const existing = state.partners.find((p) => p.id === partnerId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Parceiro "${partnerId}" não encontrado.`);
  }

  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para editar este parceiro.'
    );
  }

  // Parceiro não pode alterar seu próprio status de aprovação nem regras de comissão da plataforma
  if (authCheck.data.effectiveRole === 'partner') {
    if (
      (patch.status !== undefined && patch.status !== existing.status) ||
      (patch.commissionModel !== undefined && patch.commissionModel !== existing.commissionModel) ||
      (patch.commissionRate !== undefined && patch.commissionRate !== existing.commissionRate) ||
      (patch.commissionFixed !== undefined && patch.commissionFixed !== existing.commissionFixed)
    ) {
      return createErrorResult(
        'UNAUTHORIZED_OPERATION',
        'Apenas o Administrador pode alterar status de aprovação ou modelo/taxas de comissão do parceiro.'
      );
    }
  }

  const val = validatePartnerInput(patch, true);
  if (!val.ok) {
    return createErrorResult(
      val.errorCode || 'VALIDATION_ERROR',
      val.errorMessage || 'Dados de atualização do parceiro inválidos.',
      val.fieldErrors
    );
  }

  if (patch.cnpj !== undefined) {
    const cleanCnpj = normalizeDigits(patch.cnpj);
    const conflict = state.partners.find(
      (p) => p.id !== partnerId && normalizeDigits(p.cnpj) === cleanCnpj
    );
    if (conflict) {
      return createErrorResult(
        'DUPLICATE_ENTITY',
        `O CNPJ informado já está vinculado a outro parceiro (${conflict.name}).`
      );
    }
  }

  const updated: OperationalPartnerRecord = {
    ...existing,
    name: patch.name !== undefined ? patch.name.trim() : existing.name,
    legalName: patch.legalName !== undefined ? patch.legalName.trim() : existing.legalName,
    cnpj: patch.cnpj !== undefined ? patch.cnpj.trim() : existing.cnpj,
    whatsapp: patch.whatsapp !== undefined ? normalizeDigits(patch.whatsapp) : existing.whatsapp,
    email: patch.email !== undefined ? patch.email.trim().toLowerCase() : existing.email,
    baseMarina: patch.baseMarina !== undefined ? patch.baseMarina.trim() : existing.baseMarina,
    bio: patch.bio !== undefined ? patch.bio.trim() : existing.bio,
    yearsOperating:
      patch.yearsOperating !== undefined
        ? Math.max(1, Number(patch.yearsOperating) || 1)
        : existing.yearsOperating,
    commissionModel:
      patch.commissionModel !== undefined ? patch.commissionModel : existing.commissionModel,
    commissionRate:
      patch.commissionRate !== undefined ? Number(patch.commissionRate) : existing.commissionRate,
    commissionFixed:
      patch.commissionFixed !== undefined ? Number(patch.commissionFixed) : existing.commissionFixed,
    status: patch.status !== undefined ? patch.status : existing.status,
    isActive: patch.isActive !== undefined ? patch.isActive : existing.isActive,
    updatedAt: new Date().toISOString(),
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'PARTNER',
    entityId: updated.id,
    entityName: updated.name,
    partnerId: updated.id,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || (authCheck.data.effectiveRole === 'admin' ? 'Admin Master' : updated.name),
    action: 'UPDATE_PARTNER',
    summary: `Dados cadastrais/operacionais de "${updated.name}" atualizados.`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    partners: state.partners.map((p) => (p.id === partnerId ? updated : p)),
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, partner: updated });
}

export function moderatePartnerRegistrationOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  partnerId: string,
  decision: 'APROVAR' | 'REJEITAR' | 'SUSPENDER' | 'ATIVAR' | 'DESATIVAR',
  reason?: string
): OperationResult<{ state: OperationalStateSnapshot; partner: OperationalPartnerRecord }> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin']);
  if (!authCheck.ok) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Somente o Administrador pode aprovar, rejeitar, ativar ou desativar parceiros.'
    );
  }

  const existing = state.partners.find((p) => p.id === partnerId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Parceiro "${partnerId}" não encontrado.`);
  }

  if (
    (decision === 'REJEITAR' || decision === 'SUSPENDER' || decision === 'DESATIVAR') &&
    (!reason || reason.trim().length < 3)
  ) {
    return createErrorResult(
      'VALIDATION_ERROR',
      `É obrigatório informar o motivo (mínimo 3 caracteres) para ${decision.toLowerCase()} o parceiro.`
    );
  }

  let nextStatus: PartnerStatus = existing.status;
  let nextActive: boolean = existing.isActive !== false;
  let nextVerified = existing.verified;

  if (decision === 'APROVAR') {
    nextStatus = 'APROVADO';
    nextActive = true;
    nextVerified = true;
  } else if (decision === 'REJEITAR' || decision === 'SUSPENDER') {
    nextStatus = 'SUSPENSO';
    nextActive = false;
    nextVerified = false;
  } else if (decision === 'ATIVAR') {
    nextStatus = 'APROVADO';
    nextActive = true;
    nextVerified = true;
  } else if (decision === 'DESATIVAR') {
    nextActive = false;
  }

  const updated: OperationalPartnerRecord = {
    ...existing,
    status: nextStatus,
    isActive: nextActive,
    verified: nextVerified,
    rejectionReason: reason ? reason.trim() : existing.rejectionReason,
    updatedAt: new Date().toISOString(),
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'PARTNER',
    entityId: updated.id,
    entityName: updated.name,
    partnerId: updated.id,
    actorRole: 'admin',
    actorName: authCtx.actorName || 'Admin Master',
    action: `PARTNER_${decision}`,
    summary: `Parceiro "${updated.name}" -> ${decision} (status=${updated.status}, ativo=${updated.isActive})${reason ? `: ${reason.trim()}` : ''}.`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    partners: state.partners.map((p) => (p.id === partnerId ? updated : p)),
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, partner: updated });
}

// ============================================================================
// 7. GESTÃO DE EMBARCAÇÕES (SEÇÃO 3.4)
// ============================================================================

export interface CreateOrUpdateVesselInput {
  name: string;
  partnerId: string;
  type: VesselType;
  operationMode?: VesselOperationMode;
  capacity: number;
  lengthFeet: number;
  engineSpec: string;
  baseLocation: string;
  description?: string;
  features?: string[];
  structure?: string[];
  safetyEquipment?: string[];
  heroImage?: string;
  isActive?: boolean;
  availabilityStatus?: VesselOperationalStatus;
}

export function getMaxCommittedPassengersOnVessel(
  vesselId: string,
  bookings: readonly OperationalBookingRecord[]
): { maxPassengers: number; conflictDate: string | null } {
  const byDate: Record<string, number> = {};
  for (const bk of bookings) {
    if (bk.vesselId !== vesselId) continue;
    const st = normalizeBookingStatus(bk.status);
    if (!ACTIVE_CAPACITY_BOOKING_STATUSES.includes(st)) continue;
    byDate[bk.date] = (byDate[bk.date] || 0) + (Number(bk.passengers) || 0);
  }
  let maxPassengers = 0;
  let conflictDate: string | null = null;
  for (const [dt, count] of Object.entries(byDate)) {
    if (count > maxPassengers) {
      maxPassengers = count;
      conflictDate = dt;
    }
  }
  return { maxPassengers, conflictDate };
}

export function createVesselOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  input: CreateOrUpdateVesselInput
): OperationResult<{ state: OperationalStateSnapshot; vessel: OperationalVesselRecord }> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], input.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para cadastrar embarcação para este parceiro.'
    );
  }

  const partner = state.partners.find((p) => p.id === input.partnerId);
  if (!partner) {
    return createErrorResult('NOT_FOUND', `Parceiro proprietário "${input.partnerId}" não encontrado.`);
  }

  if (!input.name || input.name.trim().length < 3) {
    return createErrorResult('VALIDATION_ERROR', 'Nome da embarcação deve ter pelo menos 3 caracteres.');
  }
  const capacity = Number(input.capacity);
  if (!Number.isInteger(capacity) || capacity < 1 || capacity > 250) {
    return createErrorResult('VALIDATION_ERROR', 'Capacidade máxima da embarcação deve ser um inteiro entre 1 e 250 passageiros.');
  }
  const lengthFeet = Number(input.lengthFeet);
  if (!Number.isFinite(lengthFeet) || lengthFeet < 10 || lengthFeet > 200) {
    return createErrorResult('VALIDATION_ERROR', 'Comprimento em pés deve estar entre 10 e 200 pés.');
  }
  if (!input.engineSpec || input.engineSpec.trim().length < 3) {
    return createErrorResult('VALIDATION_ERROR', 'Especificação de motorização obrigatória.');
  }

  const duplicate = state.vessels.find(
    (v) =>
      v.partnerId === input.partnerId &&
      v.name.trim().toLowerCase() === input.name.trim().toLowerCase()
  );
  if (duplicate) {
    return createErrorResult(
      'DUPLICATE_ENTITY',
      `O parceiro "${partner.name}" já possui uma embarcação cadastrada com o nome "${duplicate.name}".`
    );
  }

  const slug = input.name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

  const newVessel: OperationalVesselRecord = {
    id: `ves-${slug || Date.now()}-${state.vessels.length + 1}`,
    slug: `${slug}-${state.vessels.length + 1}`,
    name: input.name.trim(),
    partnerId: partner.id,
    type: input.type,
    operationMode: input.operationMode || 'Ambos',
    capacity,
    lengthFeet,
    engineSpec: input.engineSpec.trim(),
    baseLocation: (input.baseLocation || partner.baseMarina || 'Saco da Ribeira').trim(),
    description:
      (input.description || '').trim() ||
      `Embarcação operada por ${partner.name}, homologada pela Capitania dos Portos para roteiros náuticos em Ubatuba.`,
    features: input.features && input.features.length > 0
      ? input.features
      : ['Toldo de proteção solar', 'Som Bluetooth marinizado', 'Cooler térmico a bordo', 'Escada de popa'],
    structure: input.structure && input.structure.length > 0
      ? input.structure
      : ['Assentos anatômicos', 'Compartimento seco de bagagem', 'Ducha de água doce'],
    safetyEquipment: input.safetyEquipment && input.safetyEquipment.length > 0
      ? input.safetyEquipment
      : ['Coletes salva-vidas homologados Classe II', 'Boia circular com retinida', 'Rádio VHF e GPS'],
    heroImage:
      input.heroImage ||
      (input.type === 'Escuna'
        ? '/media/embarcacao-escuna-anchieta.jpg'
        : '/media/embarcacao-lancha-passa-vinte.jpg'),
    gallery: [
      input.type === 'Escuna'
        ? '/media/embarcacao-escuna-anchieta.jpg'
        : '/media/embarcacao-lancha-passa-vinte.jpg',
    ],
    videoTitle: `Tour a Bordo — ${input.name.trim()}`,
    rating: 5.0,
    isActive: input.isActive !== undefined ? input.isActive : true,
    availabilityStatus: input.availabilityStatus || 'DISPONIVEL',
    updatedAt: new Date().toISOString(),
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'VESSEL',
    entityId: newVessel.id,
    entityName: newVessel.name,
    partnerId: newVessel.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || partner.name,
    action: 'CREATE_VESSEL',
    summary: `Embarcação "${newVessel.name}" (${newVessel.type}, ${newVessel.capacity} vagas) cadastrada para ${partner.name}.`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    vessels: [newVessel, ...state.vessels],
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, vessel: newVessel });
}

export function updateVesselOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  vesselId: string,
  patch: Partial<CreateOrUpdateVesselInput>
): OperationResult<{ state: OperationalStateSnapshot; vessel: OperationalVesselRecord }> {
  const existing = state.vessels.find((v) => v.id === vesselId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Embarcação "${vesselId}" não encontrada.`);
  }

  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], existing.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para alterar esta embarcação.'
    );
  }

  // Proíbe transferir embarcação para outro parceiro sem ser Admin ou quando possui passeios/reservas vinculados
  if (patch.partnerId !== undefined && patch.partnerId !== existing.partnerId) {
    if (authCheck.data.effectiveRole !== 'admin') {
      return createErrorResult(
        'CROSS_TENANT_ACCESS_DENIED',
        'Não é permitido alterar o parceiro proprietário da embarcação.'
      );
    }
    const hasLinkedTours = state.tours.some((t) => t.vesselId === vesselId);
    const hasLinkedBookings = state.bookings.some((b) => b.vesselId === vesselId);
    if (hasLinkedTours || hasLinkedBookings) {
      return createErrorResult(
        'DEPENDENCY_CONFLICT',
        'Não é permitido transferir a titularidade de uma embarcação que já possui passeios ou reservas vinculados.'
      );
    }
  }

  if (patch.name !== undefined && patch.name.trim().length < 3) {
    return createErrorResult('VALIDATION_ERROR', 'Nome da embarcação deve ter pelo menos 3 caracteres.');
  }

  let nextCapacity = existing.capacity;
  if (patch.capacity !== undefined) {
    nextCapacity = Number(patch.capacity);
    if (!Number.isInteger(nextCapacity) || nextCapacity < 1 || nextCapacity > 250) {
      return createErrorResult('VALIDATION_ERROR', 'Capacidade máxima deve ser um inteiro entre 1 e 250.');
    }
    // Regra Seção 3.4: Não permitir que a capacidade de uma embarcação seja reduzida abaixo de ocupações já comprometidas
    const { maxPassengers, conflictDate } = getMaxCommittedPassengersOnVessel(vesselId, state.bookings);
    if (nextCapacity < maxPassengers) {
      return createErrorResult(
        'CAPACITY_CONFLICT',
        `Não é permitido reduzir a capacidade da embarcação para ${nextCapacity} vagas: já existem ${maxPassengers} passageiros comprometidos na data ${conflictDate}.`
      );
    }
  }

  const updated: OperationalVesselRecord = {
    ...existing,
    name: patch.name !== undefined ? patch.name.trim() : existing.name,
    type: patch.type !== undefined ? patch.type : existing.type,
    operationMode: patch.operationMode !== undefined ? patch.operationMode : existing.operationMode,
    capacity: nextCapacity,
    lengthFeet:
      patch.lengthFeet !== undefined ? Math.max(10, Number(patch.lengthFeet) || existing.lengthFeet) : existing.lengthFeet,
    engineSpec: patch.engineSpec !== undefined ? patch.engineSpec.trim() : existing.engineSpec,
    baseLocation: patch.baseLocation !== undefined ? patch.baseLocation.trim() : existing.baseLocation,
    description: patch.description !== undefined ? patch.description.trim() : existing.description,
    isActive: patch.isActive !== undefined ? patch.isActive : existing.isActive,
    availabilityStatus:
      patch.availabilityStatus !== undefined ? patch.availabilityStatus : existing.availabilityStatus,
    updatedAt: new Date().toISOString(),
  };

  // Ajusta capacidade máxima de passeios vinculados caso excedam a nova capacidade da embarcação
  const updatedTours = state.tours.map((t) =>
    t.vesselId === vesselId && t.capacity > nextCapacity ? { ...t, capacity: nextCapacity } : t
  );

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'VESSEL',
    entityId: updated.id,
    entityName: updated.name,
    partnerId: updated.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || updated.partnerId,
    action: 'UPDATE_VESSEL',
    summary: `Embarcação "${updated.name}" atualizada (capacidade=${updated.capacity}, situação=${updated.availabilityStatus || 'DISPONIVEL'}, ativa=${updated.isActive !== false}).`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    vessels: state.vessels.map((v) => (v.id === vesselId ? updated : v)),
    tours: updatedTours,
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, vessel: updated });
}

// ============================================================================
// 8. GESTÃO DE PASSEIOS E EXCLUSÃO SEGURA (SEÇÃO 3.3)
// ============================================================================

export interface CreateOrUpdateTourInput {
  title: string;
  vesselId: string;
  partnerId: string;
  category?: TourCategoryType;
  tourType: TourOperationType;
  pricingModel?: PricingModelType;
  price: number;
  capacity?: number;
  durationHours: number;
  checkInTime: string;
  departureTime: string;
  returnTime: string;
  departurePoint: DeparturePointType;
  itineraryId?: string;
  destinationsVisited?: string[];
  includedItems?: string[];
  importantInfo?: string[];
  cancellationPolicy?: string;
  status?: OperationalTourRecord['status'];
  isActive?: boolean;
  featured?: boolean;
  heroImage?: string;
}

export function validateTourScheduleAndRules(input: {
  checkInTime: string;
  departureTime: string;
  returnTime: string;
  durationHours: number;
  price: number;
  capacity: number;
  vesselCapacity: number;
}): OperationResult<void> {
  if (!isValidTimeHHMM(input.checkInTime) || !isValidTimeHHMM(input.departureTime) || !isValidTimeHHMM(input.returnTime)) {
    return createErrorResult(
      'VALIDATION_ERROR',
      'Horários de check-in, saída e retorno devem estar no formato válido HH:MM (ex: 09:00, 09:30, 15:00).'
    );
  }

  const checkInMin = timeHHMMToMinutes(input.checkInTime);
  const depMin = timeHHMMToMinutes(input.departureTime);
  const retMin = timeHHMMToMinutes(input.returnTime);

  if (checkInMin > depMin) {
    return createErrorResult(
      'VALIDATION_ERROR',
      `Horário de check-in (${input.checkInTime}) não pode ser posterior ao horário de saída (${input.departureTime}).`
    );
  }
  if (depMin >= retMin) {
    return createErrorResult(
      'VALIDATION_ERROR',
      `Horário de retorno (${input.returnTime}) deve ser posterior ao horário de saída (${input.departureTime}).`
    );
  }

  const dur = Number(input.durationHours);
  if (!Number.isFinite(dur) || dur < 0.5 || dur > 24) {
    return createErrorResult('VALIDATION_ERROR', 'Duração do passeio deve estar entre 0.5h e 24h.');
  }

  const price = Number(input.price);
  if (!Number.isFinite(price) || price < 50) {
    return createErrorResult('VALIDATION_ERROR', 'Preço do passeio deve ser de no mínimo R$ 50,00.');
  }

  const cap = Number(input.capacity);
  if (!Number.isInteger(cap) || cap < 1) {
    return createErrorResult('VALIDATION_ERROR', 'Capacidade do passeio deve ser de no mínimo 1 passageiro.');
  }
  if (cap > input.vesselCapacity) {
    return createErrorResult(
      'CAPACITY_CONFLICT',
      `A capacidade do passeio (${cap}) não pode ultrapassar a capacidade máxima da embarcação vinculada (${input.vesselCapacity}).`
    );
  }

  return createSuccessResult(undefined);
}

export function createTourOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  input: CreateOrUpdateTourInput
): OperationResult<{ state: OperationalStateSnapshot; tour: OperationalTourRecord }> {
  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], input.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para cadastrar passeio para este parceiro.'
    );
  }

  if (!input.title || input.title.trim().length < 3) {
    return createErrorResult('VALIDATION_ERROR', 'Título do passeio deve ter pelo menos 3 caracteres.');
  }

  const partner = state.partners.find((p) => p.id === input.partnerId);
  if (!partner) {
    return createErrorResult('NOT_FOUND', `Parceiro responsável "${input.partnerId}" não encontrado.`);
  }

  const vessel = state.vessels.find((v) => v.id === input.vesselId);
  if (!vessel) {
    return createErrorResult('NOT_FOUND', `Embarcação "${input.vesselId}" não encontrada.`);
  }

  // Regra de Integridade Relacional (Seções 3.3 e 6): a embarcação DEVE pertencer ao mesmo parceiro do passeio
  if (vessel.partnerId !== partner.id) {
    return createErrorResult(
      'CROSS_TENANT_ACCESS_DENIED',
      `Violação de vínculo Parceiro-Embarcação: a embarcação "${vessel.name}" pertence a outro parceiro e não pode ser associada a "${partner.name}".`
    );
  }

  const targetCapacity = input.capacity !== undefined ? Number(input.capacity) : vessel.capacity;
  const schedCheck = validateTourScheduleAndRules({
    checkInTime: input.checkInTime || '09:00',
    departureTime: input.departureTime || '09:30',
    returnTime: input.returnTime || '15:00',
    durationHours: input.durationHours ?? 5.5,
    price: input.price,
    capacity: targetCapacity,
    vesselCapacity: vessel.capacity,
  });
  if (!schedCheck.ok) {
    return createErrorResult(
      schedCheck.errorCode || 'VALIDATION_ERROR',
      schedCheck.errorMessage || 'Configuração inválida de horários ou capacidade.'
    );
  }

  const slug = input.title
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

  const initialStatus: OperationalTourRecord['status'] =
    authCheck.data.effectiveRole === 'admin' && input.status
      ? input.status
      : 'PENDENTE_APROVACAO';

  const newTour: OperationalTourRecord = {
    id: `tour-${slug || Date.now()}-${state.tours.length + 1}`,
    slug: `${slug}-${state.tours.length + 1}`,
    title: input.title.trim(),
    vesselId: vessel.id,
    partnerId: partner.id,
    category:
      input.category ||
      (input.tourType === 'Privativo'
        ? 'Passeios privativos'
        : vessel.type === 'Escuna'
        ? 'Passeios de escuna'
        : 'Passeios de lancha'),
    tourType: input.tourType,
    vesselType: vessel.type,
    pricingModel: input.pricingModel || (input.tourType === 'Privativo' ? 'POR_EMBARCACAO' : 'POR_PESSOA'),
    price: Math.round(Number(input.price) * 100) / 100,
    capacity: targetCapacity,
    durationHours: Number(input.durationHours ?? 5.5),
    checkInTime: (input.checkInTime || '09:00').trim(),
    departureTime: (input.departureTime || '09:30').trim(),
    returnTime: (input.returnTime || '15:00').trim(),
    departurePoint: input.departurePoint || 'Praia do Itaguá',
    itineraryId: input.itineraryId || 'itin-ilhas-norte',
    destinationsVisited:
      input.destinationsVisited && input.destinationsVisited.length > 0
        ? input.destinationsVisited
        : ['dest-ilha-couves'],
    swimmingStops: [
      {
        place: 'Parada Principal Homologada',
        duration: '2h00',
        description: 'Parada em águas abrigadas para banho e contemplação.',
      },
    ],
    includedItems:
      input.includedItems && input.includedItems.length > 0
        ? input.includedItems
        : ['Marinheiro habilitado pela Marinha', 'Combustível', 'Coletes e seguro obrigatório'],
    importantInfo:
      input.importantInfo && input.importantInfo.length > 0
        ? input.importantInfo
        : [`Check-in obrigatório às ${(input.checkInTime || '09:00').trim()} em ${input.departurePoint || 'Praia do Itaguá'}.`],
    cancellationPolicy:
      (input.cancellationPolicy || '').trim() ||
      'Cancelamento gratuito até 48h antes do embarque ou reagendamento/reembolso integral em caso de interdição marítima.',
    status: initialStatus,
    isActive: input.isActive !== undefined ? input.isActive : true,
    featured: Boolean(input.featured && authCheck.data.effectiveRole === 'admin'),
    heroImage: input.heroImage || vessel.heroImage,
    gallery: [input.heroImage || vessel.heroImage],
    videoTitle: `Roteiro Oficial — ${input.title.trim()}`,
    rating: 5.0,
    reviewsCount: 0,
    seoKeywords: ['Passeio de barco Ubatuba', input.title.trim(), partner.name],
    updatedAt: new Date().toISOString(),
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'TOUR',
    entityId: newTour.id,
    entityName: newTour.title,
    partnerId: newTour.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || partner.name,
    action: 'CREATE_TOUR',
    summary: `Passeio "${newTour.title}" cadastrado (${newTour.departureTime}-${newTour.returnTime}, R$ ${newTour.price}, cap=${newTour.capacity}, status=${newTour.status}).`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    tours: [newTour, ...state.tours],
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, tour: newTour });
}

export function updateTourOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  tourId: string,
  patch: Partial<CreateOrUpdateTourInput>
): OperationResult<{ state: OperationalStateSnapshot; tour: OperationalTourRecord }> {
  const existing = state.tours.find((t) => t.id === tourId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Passeio "${tourId}" não encontrado.`);
  }

  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], existing.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para editar este passeio.'
    );
  }

  if (patch.partnerId !== undefined && patch.partnerId !== existing.partnerId) {
    return createErrorResult(
      'CROSS_TENANT_ACCESS_DENIED',
      'Não é permitido transferir um passeio existente para outro parceiro.'
    );
  }

  if (authCheck.data.effectiveRole === 'partner' && patch.status === 'APROVADO' && existing.status !== 'APROVADO') {
    return createErrorResult(
      'UNAUTHORIZED_OPERATION',
      'Somente o Administrador pode aprovar e publicar um passeio pendente.'
    );
  }

  const targetVesselId = patch.vesselId !== undefined ? patch.vesselId : existing.vesselId;
  const vessel = state.vessels.find((v) => v.id === targetVesselId);
  if (!vessel) {
    return createErrorResult('NOT_FOUND', `Embarcação "${targetVesselId}" não encontrada.`);
  }
  if (vessel.partnerId !== existing.partnerId) {
    return createErrorResult(
      'CROSS_TENANT_ACCESS_DENIED',
      `A embarcação "${vessel.name}" pertence a outro parceiro e não pode ser vinculada a este passeio.`
    );
  }

  const nextCheckIn = patch.checkInTime !== undefined ? patch.checkInTime : existing.checkInTime;
  const nextDep = patch.departureTime !== undefined ? patch.departureTime : existing.departureTime;
  const nextRet = patch.returnTime !== undefined ? patch.returnTime : existing.returnTime;
  const nextDur = patch.durationHours !== undefined ? Number(patch.durationHours) : existing.durationHours;
  const nextPrice = patch.price !== undefined ? Number(patch.price) : existing.price;
  const nextCap = patch.capacity !== undefined ? Number(patch.capacity) : Math.min(existing.capacity, vessel.capacity);

  const schedCheck = validateTourScheduleAndRules({
    checkInTime: nextCheckIn,
    departureTime: nextDep,
    returnTime: nextRet,
    durationHours: nextDur,
    price: nextPrice,
    capacity: nextCap,
    vesselCapacity: vessel.capacity,
  });
  if (!schedCheck.ok) {
    return createErrorResult(
      schedCheck.errorCode || 'VALIDATION_ERROR',
      schedCheck.errorMessage || 'Dados de horário, preço ou capacidade do passeio inválidos.'
    );
  }

  // Verifica se já existem reservas ativas no passeio que superem a nova capacidade proposta
  const committedByDate: Record<string, number> = {};
  for (const bk of state.bookings) {
    if (bk.tourId !== tourId) continue;
    if (!ACTIVE_CAPACITY_BOOKING_STATUSES.includes(normalizeBookingStatus(bk.status))) continue;
    committedByDate[bk.date] = (committedByDate[bk.date] || 0) + (Number(bk.passengers) || 0);
  }
  for (const [dt, pax] of Object.entries(committedByDate)) {
    if (nextCap < pax) {
      return createErrorResult(
        'CAPACITY_CONFLICT',
        `Não é permitido reduzir a capacidade do passeio para ${nextCap}: já existem ${pax} lugares reservados na saída de ${dt}.`
      );
    }
  }

  const updated: OperationalTourRecord = {
    ...existing,
    title: patch.title !== undefined ? patch.title.trim() : existing.title,
    vesselId: vessel.id,
    vesselType: vessel.type,
    category: patch.category !== undefined ? patch.category : existing.category,
    tourType: patch.tourType !== undefined ? patch.tourType : existing.tourType,
    pricingModel:
      patch.pricingModel !== undefined
        ? patch.pricingModel
        : patch.tourType !== undefined
        ? patch.tourType === 'Privativo'
          ? 'POR_EMBARCACAO'
          : 'POR_PESSOA'
        : existing.pricingModel,
    price: Math.round(nextPrice * 100) / 100,
    capacity: nextCap,
    durationHours: nextDur,
    checkInTime: nextCheckIn.trim(),
    departureTime: nextDep.trim(),
    returnTime: nextRet.trim(),
    departurePoint: patch.departurePoint !== undefined ? patch.departurePoint : existing.departurePoint,
    destinationsVisited:
      patch.destinationsVisited !== undefined ? patch.destinationsVisited : existing.destinationsVisited,
    includedItems: patch.includedItems !== undefined ? patch.includedItems : existing.includedItems,
    importantInfo: patch.importantInfo !== undefined ? patch.importantInfo : existing.importantInfo,
    cancellationPolicy:
      patch.cancellationPolicy !== undefined ? patch.cancellationPolicy.trim() : existing.cancellationPolicy,
    status: patch.status !== undefined ? patch.status : existing.status,
    isActive: patch.isActive !== undefined ? patch.isActive : existing.isActive,
    featured: patch.featured !== undefined ? patch.featured : existing.featured,
    updatedAt: new Date().toISOString(),
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'TOUR',
    entityId: updated.id,
    entityName: updated.title,
    partnerId: updated.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || updated.partnerId,
    action: 'UPDATE_TOUR',
    summary: `Passeio "${updated.title}" atualizado (R$ ${updated.price}, ${updated.departureTime}-${updated.returnTime}, cap=${updated.capacity}, status=${updated.status}, ativo=${updated.isActive !== false}).`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    tours: state.tours.map((t) => (t.id === tourId ? updated : t)),
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, tour: updated });
}

/**
 * Exclusão Segura de Passeio (Seção 3.3 e Seção 6):
 * - Um passeio com reservas vinculadas (ativas ou históricas) NÃO PODE ser excluído fisicamente
 *   para não comprometer o histórico ou a integridade dos registros.
 * - Somente passeios sem nenhuma reserva vinculada podem ser removidos.
 */
export function deleteTourSafelyOperation(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  tourId: string
): OperationResult<{ state: OperationalStateSnapshot; deletedTourId: string }> {
  const existing = state.tours.find((t) => t.id === tourId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Passeio "${tourId}" não encontrado.`);
  }

  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], existing.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para excluir este passeio.'
    );
  }

  const linkedBookings = state.bookings.filter((b) => b.tourId === tourId);
  if (linkedBookings.length > 0) {
    return createErrorResult(
      'DEPENDENCY_CONFLICT',
      `Exclusão bloqueada: o passeio "${existing.title}" possui ${linkedBookings.length} reserva(s) vinculada(s) (${linkedBookings.map((b) => b.code).join(', ')}). Para preservar o histórico e a integridade financeira, utilize a desativação/arquivamento do passeio.`
    );
  }

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'TOUR',
    entityId: existing.id,
    entityName: existing.title,
    partnerId: existing.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || existing.partnerId,
    action: 'DELETE_TOUR_SAFE',
    summary: `Passeio "${existing.title}" excluído com segurança (0 reservas vinculadas).`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    tours: state.tours.filter((t) => t.id !== tourId),
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  return createSuccessResult({ state: nextState, deletedTourId: tourId });
}

// ============================================================================
// 9. CONSULTA E GESTÃO ADMINISTRATIVA DE RESERVAS (SEÇÃO 3.5)
//    - Camada própria de consulta administrativa/operacional (NÃO utiliza a RPC
//      pública lookup_booking_by_tourist_token).
//    - NUNCA expõe lookupToken, lookup_token_hmac, idempotencyKey ou segredos internos.
//    - Respeita as regras de privacidade e transições da Missão 02.16.
// ============================================================================

export interface SanitizedOperationalBookingView {
  id: string;
  code: string;
  tourId: string;
  tourTitle: string;
  vesselId: string;
  vesselName: string;
  partnerId: string;
  partnerName: string;
  customerName: string;
  customerContactMasked: string;
  date: string;
  departureTime: string;
  returnTime: string;
  checkInTime: string;
  departurePoint: string;
  passengers: number;
  channel: BookingChannelType;
  utmSource: string;
  status: BookingStatusType;
  ledgerStatus: LedgerStatusType;
  grossAmount: number;
  commissionRuleUsed: string;
  commissionAmount: number;
  netPartnerAmount: number;
  commissionConsolidated: boolean;
  createdAt: string;
  rejectionReason?: string;
  history: OperationalHistoryEntry[];
}

export interface OperationalBookingFilterOptions {
  code?: string;
  tourId?: string;
  partnerId?: string;
  date?: string;
  status?: 'TODAS' | BookingStatusType;
}

export function maskContactForOperationalView(phone: string, email: string): string {
  const digits = normalizeDigits(phone);
  const maskedPhone =
    digits.length >= 4
      ? `(**) *****-${digits.slice(-4)}`
      : 'Contato sob guarda LGPD';
  if (!email || !email.includes('@')) return maskedPhone;
  const [userPart, domainPart] = email.split('@');
  const maskedEmail = `${userPart.slice(0, 2)}***@${domainPart}`;
  return `${maskedPhone} • ${maskedEmail}`;
}

export function queryOperationalBookings(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  filters?: OperationalBookingFilterOptions
): OperationResult<SanitizedOperationalBookingView[]> {
  const authCheck = authorizeOperationalAction(
    authCtx,
    ['admin', 'partner'],
    authCtx.actorRole === 'partner' ? filters?.partnerId || authCtx.actorPartnerId : undefined,
    state
  );
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Acesso negado à consulta operacional de reservas.'
    );
  }

  const effectiveRole = authCheck.data.effectiveRole;
  const partnerScope =
    effectiveRole === 'partner'
      ? authCheck.data.authorizedPartnerId
      : filters?.partnerId && filters.partnerId !== 'TODOS'
      ? filters.partnerId
      : null;

  const results: SanitizedOperationalBookingView[] = [];

  for (const bk of state.bookings) {
    if (partnerScope && bk.partnerId !== partnerScope) continue;
    if (filters?.tourId && filters.tourId !== 'TODOS' && bk.tourId !== filters.tourId) continue;
    if (filters?.date && filters.date.trim() !== '' && bk.date !== filters.date.trim()) continue;

    const normStatus = normalizeBookingStatus(bk.status);
    if (filters?.status && filters.status !== 'TODAS' && normStatus !== filters.status) continue;

    if (filters?.code && filters.code.trim() !== '') {
      const q = filters.code.trim().toLowerCase();
      const match =
        bk.code.toLowerCase().includes(q) ||
        bk.tourTitle.toLowerCase().includes(q) ||
        bk.partnerName.toLowerCase().includes(q);
      if (!match) continue;
    }

    const tourObj = state.tours.find((t) => t.id === bk.tourId);
    const bkHistory = state.changeHistory.filter(
      (h) => h.entityId === bk.id || h.entityId === bk.code || h.entityName.includes(bk.code)
    );

    // Construção explícita sem lookupToken, sem idempotencyKey e sem hashes HMAC
    results.push({
      id: bk.id,
      code: bk.code,
      tourId: bk.tourId,
      tourTitle: bk.tourTitle,
      vesselId: bk.vesselId,
      vesselName: bk.vesselName,
      partnerId: bk.partnerId,
      partnerName: bk.partnerName,
      customerName: bk.customerName,
      customerContactMasked: maskContactForOperationalView(bk.customerPhone, bk.customerEmail),
      date: bk.date,
      departureTime: tourObj?.departureTime || '09:30',
      returnTime: tourObj?.returnTime || '15:00',
      checkInTime: tourObj?.checkInTime || '09:00',
      departurePoint: tourObj?.departurePoint || 'Praia do Itaguá',
      passengers: bk.passengers,
      channel: bk.channel,
      utmSource: bk.utmSource,
      status: normStatus,
      ledgerStatus: bk.ledgerStatus || deriveLedgerStatusFromBookingStatus(normStatus),
      grossAmount: bk.grossAmount,
      commissionRuleUsed: bk.commissionRuleUsed,
      commissionAmount: bk.commissionAmount,
      netPartnerAmount: bk.netPartnerAmount,
      commissionConsolidated: normStatus === 'PASSEIO_REALIZADO',
      createdAt: bk.createdAt,
      rejectionReason: bk.rejectionReason,
      history: bkHistory,
    });
  }

  return createSuccessResult(results);
}

export function transitionOperationalBookingStatus(
  state: OperationalStateSnapshot,
  authCtx: OperationalAuthContext,
  bookingId: string,
  nextStatus: BookingStatusType,
  reason?: string
): OperationResult<{ state: OperationalStateSnapshot; booking: SanitizedOperationalBookingView }> {
  const existing = state.bookings.find((b) => b.id === bookingId || b.code === bookingId);
  if (!existing) {
    return createErrorResult('NOT_FOUND', `Reserva "${bookingId}" não encontrada.`);
  }

  const authCheck = authorizeOperationalAction(authCtx, ['admin', 'partner'], existing.partnerId, state);
  if (!authCheck.ok || !authCheck.data) {
    return createErrorResult(
      authCheck.errorCode || 'UNAUTHORIZED_OPERATION',
      authCheck.errorMessage || 'Sem permissão para alterar o status desta reserva.'
    );
  }

  const currentStatus = normalizeBookingStatus(existing.status);
  const transitionCheck = validateBookingStatusTransition(
    currentStatus,
    nextStatus,
    authCheck.data.effectiveRole,
    reason
  );
  if (!transitionCheck.valid) {
    return createErrorResult(
      'INVALID_STATUS_TRANSITION',
      transitionCheck.errorMessage || 'Transição de status não permitida pelas regras transacionais.'
    );
  }

  // M02.20-F05: Revalida capacidade disponível da embarcação/saída antes de confirmar reserva (anti-overbooking)
  if (nextStatus === 'CONFIRMADA' && currentStatus !== 'CONFIRMADA') {
    const tourObj = state.tours.find((t) => t.id === existing.tourId);
    const vesselObj = state.vessels.find((v) => v.id === existing.vesselId);
    const partnerObj = state.partners.find((p) => p.id === existing.partnerId);
    if (tourObj) {
      const otherBookings = state.bookings.filter((b) => b.id !== existing.id);
      const occ = computeCanonicalDepartureOccupancy({
        tour: tourObj,
        vessel: vesselObj,
        partner: partnerObj,
        date: existing.date,
        bookings: otherBookings,
        availabilityBlocks: state.availabilityBlocks,
        currentBrazilDate: state.currentBrazilDate,
      });
      if (!occ.isAvailableForNewBookings || existing.passengers > occ.remainingSeats) {
        return createErrorResult(
          'CAPACITY_CONFLICT',
          `Anti-Overbooking: Não há vagas suficientes em ${existing.date} para confirmar ${existing.passengers} passageiros (vagas livres: ${occ.remainingSeats}).`
        );
      }
    }
  }

  const nextLedger = deriveLedgerStatusFromBookingStatus(nextStatus, existing.ledgerStatus);
  const updatedBooking: OperationalBookingRecord = {
    ...existing,
    status: nextStatus,
    ledgerStatus: nextLedger,
    commissionConsolidated: nextStatus === 'PASSEIO_REALIZADO',
    rejectionReason:
      nextStatus === 'RECUSADA' || nextStatus === 'CANCELADA'
        ? (reason || '').trim()
        : existing.rejectionReason,
  };

  const historyEntry: OperationalHistoryEntry = {
    id: `hist-${Date.now()}-${state.changeHistory.length + 1}`,
    timestamp: new Date().toLocaleString('pt-BR'),
    entityType: 'BOOKING',
    entityId: updatedBooking.id,
    entityName: updatedBooking.code,
    partnerId: updatedBooking.partnerId,
    actorRole: authCheck.data.effectiveRole,
    actorName: authCtx.actorName || (authCheck.data.effectiveRole === 'admin' ? 'Admin Master' : updatedBooking.partnerName),
    action: `BOOKING_STATUS_${nextStatus}`,
    summary: `Reserva ${updatedBooking.code} alterada de ${currentStatus} para ${nextStatus} (ledger=${nextLedger})${reason ? ` — Motivo: ${reason.trim()}` : ''}.`,
  };

  const nextState: OperationalStateSnapshot = {
    ...state,
    bookings: state.bookings.map((b) => (b.id === existing.id ? updatedBooking : b)),
    changeHistory: [historyEntry, ...state.changeHistory],
  };

  const viewRes = queryOperationalBookings(nextState, authCtx, { code: updatedBooking.code });
  const sanitized = viewRes.data?.find((b) => b.id === updatedBooking.id);
  if (!sanitized) {
    return createErrorResult('NOT_FOUND', 'Erro ao reconstruir visão sanitizada da reserva.');
  }

  return createSuccessResult({ state: nextState, booking: sanitized });
}

export { isBookingDateValidInBrazil, getBrazilCurrentDateIso, getBrazilFutureDateIso };
