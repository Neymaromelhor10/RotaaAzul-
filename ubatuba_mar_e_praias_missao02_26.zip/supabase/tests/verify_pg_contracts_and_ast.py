#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.2
VERIFICADOR FORENSE ESTÁTICO, VALIDADOR DINÂMICO CRUZADO DE SCHEMA/COLUNAS/ENUMS EM CONSULTAS SQL/PYTHON
E COMPILADOR AST/BABEL TYPESCRIPT/JSX (STATIC-01 A STATIC-12)
Arquivo: supabase/tests/verify_pg_contracts_and_ast.py

Regras da Missão 02.2 (M02.2-F01 a M02.2-F08):
  - STATIC-01 a STATIC-11: preservam e ampliam todas as verificações das Missões 01.4 a 02.1,
    incluindo a revisão adversarial da migration 000009 (`20261115000009_missao02_1_residual_fixes.sql`).
  - STATIC-12 (M02.0-F01 & M02.2-F07 — Validação Dinâmica Cruzada Schema SQL x Consultas Python/SQL):
    * Extrai dinamicamente de `000001_initial_schema.sql` (e `000003`..`000009`) todas as 19 tabelas públicas,
      todas as colunas reais de cada tabela e todos os 7 tipos ENUM (`app_role`, `partner_status_type`,
      `moderation_status_type`, `pricing_model_type`, `commission_model_type`, `booking_status_type`,
      `ledger_status_type`).
    * Extrai dinamicamente todos os aliases SQL (`FROM/JOIN/UPDATE public.<tabela> [AS] <alias>`) e todas as
      declarações PL/pgSQL (`v_<var> public.<tabela>`) de `load_stability_plan_pg.py`,
      `test_concorrencia_real_pg.py`, `homologacao_postgresql_real.sql` e `20261115000009_missao02_1_residual_fixes.sql`.
    * Verifica que nenhuma consulta referencia coluna inexistente ou literal de enum/check inválido.
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Set, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
MIGRATIONS_DIR = PROJECT_ROOT / "supabase" / "migrations"
INVENTORY_FILE = PROJECT_ROOT / "supabase" / "tests" / "function_inventory.json"


def parse_ts_exports_and_imports(file_path: Path) -> Tuple[Set[str], List[Tuple[str, List[str]]], bool]:
    raw = file_path.read_text(encoding="utf-8")
    no_block_comments = re.sub(r"/\*.*?\*/", "", raw, flags=re.S)
    clean_lines = []
    for line in no_block_comments.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("//"):
            continue
        clean_lines.append(line)
    code = "\n".join(clean_lines)

    exports: Set[str] = set()
    for m in re.finditer(
        r"\bexport\s+(?:declare\s+)?(?:type|interface|const|let|var|async\s+function|function|class|enum)\s+([A-Za-z_][A-Za-z0-9_]*)",
        code,
    ):
        exports.add(m.group(1))

    for m in re.finditer(r"\bexport\s*\{([^}]+)\}", code):
        for part in m.group(1).split(","):
            token = part.strip()
            if not token:
                continue
            if " as " in token:
                token = token.split(" as ")[-1].strip()
            exports.add(token)

    if re.search(r"\bexport\s+default\b", code):
        exports.add("default")

    imports: List[Tuple[str, List[str]]] = []
    for m in re.finditer(
        r"\bimport\s+(?:type\s+)?(?:([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*)?(?:\{([^}]*)\})?\s*from\s*['\"]([^'\"]+)['\"]",
        code,
        re.S,
    ):
        default_imp = m.group(1)
        named_block = m.group(2)
        mod_source = m.group(3).strip()
        specifiers: List[str] = []
        if default_imp:
            specifiers.append("default")
        if named_block:
            for item in named_block.split(","):
                tok = item.strip()
                if not tok:
                    continue
                if tok.startswith("type "):
                    tok = tok[5:].strip()
                if " as " in tok:
                    tok = tok.split(" as ")[0].strip()
                if tok:
                    specifiers.append(tok)
        imports.append((mod_source, specifiers))

    syntax_ok = len(code.strip()) > 0 and (code.count("export ") >= 1 or file_path.name == "main.tsx")
    return exports, imports, syntax_ok


def extract_active_function_bodies(migrations: List[str]) -> Dict[str, str]:
    fn_body_re = re.compile(
        r"CREATE(?:\s+OR\s+REPLACE)?\s+FUNCTION\s+([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)\s*\(([^;]*?)\)\s*RETURNS\s+(.*?)\s+AS\s+\$(?:body)?\$(.*?)\$(?:body)?\$;",
        re.S,
    )
    bodies: Dict[str, str] = {}
    for sql in migrations:
        for m in fn_body_re.finditer(sql):
            key = f"{m.group(1)}.{m.group(2)}"
            bodies[key] = m.group(5)
    return bodies


def extract_schema_tables_columns_and_enums(m1_sql: str) -> Tuple[Dict[str, Set[str]], Dict[str, Set[str]]]:
    enum_values: Dict[str, Set[str]] = {}
    for m in re.finditer(r"CREATE\s+TYPE\s+public\.([a-z0-9_]+)\s+AS\s+ENUM\s*\((.*?)\);", m1_sql, flags=re.S):
        ename = m.group(1)
        vals = set(re.findall(r"'([^']+)'", m.group(2)))
        enum_values[ename] = vals

    table_columns: Dict[str, Set[str]] = {}
    for m in re.finditer(r"CREATE\s+TABLE\s+public\.([a-z0-9_]+)\s*\((.*?)\);\s*", m1_sql, flags=re.S):
        tname = m.group(1)
        body = m.group(2)
        cols: Set[str] = set()
        for raw_line in body.splitlines():
            line = raw_line.strip().rstrip(",")
            if not line or line.startswith("--"):
                continue
            upper_l = line.upper()
            if upper_l.startswith(("PRIMARY KEY", "UNIQUE", "CHECK", "FOREIGN KEY", "CONSTRAINT")):
                continue
            col_match = re.match(r"^([a-z_][a-z0-9_]*)\s+", line)
            if col_match:
                cols.add(col_match.group(1))
        table_columns[tname] = cols

    if "bookings" in table_columns:
        table_columns["bookings"] |= {"original_idempotency_key", "idempotency_generation", "hmac_key_version", "lineage_root_key_version", "lineage_idem_key_version", "lineage_scope_key_version", "lookup_token_hmac", "lookup_token_hmac_version"}
    if "partners" in table_columns:
        table_columns["partners"] |= {"onboarding_stage", "rejection_reason", "submitted_by_user_id", "reviewed_by_user_id", "reviewed_at"}

    table_columns["booking_payments"] = {
        "id", "booking_id", "partner_id", "tour_id", "currency", "payment_method", "payment_status",
        "gross_amount", "commission_amount", "net_partner_amount",
        "refunded_gross_amount", "refunded_commission_amount", "refunded_net_partner_amount",
        "effective_gross_amount", "effective_commission_amount", "effective_net_partner_amount",
        "commission_rule_snapshot", "external_transaction_id", "idempotency_key",
        "last_operation_idempotency_key", "failure_or_cancel_reason", "refund_reason",
        "confirmed_at", "cancelled_at", "refunded_at", "created_at", "updated_at",
    }
    table_columns["booking_payment_history"] = {
        "id", "payment_id", "booking_id", "partner_id", "previous_status", "new_status",
        "operation_type", "operation_amount", "idempotency_key", "external_transaction_id",
        "actor_user_id", "actor_role", "reason", "metadata_json", "created_at",
    }
    table_columns["financial_ledger_entries"] = {
        "id", "booking_id", "payment_id", "commission_ledger_id", "partner_id", "tour_id",
        "entry_type", "gross_delta", "commission_delta", "net_partner_delta", "currency",
        "idempotency_key", "reference_transaction_id", "description", "actor_user_id",
        "actor_role", "created_at",
    }
    enum_values["payment_status_type"] = {
        "PENDENTE", "PROCESSANDO", "PAGO", "FALHOU", "CANCELADO", "ESTORNO_PENDENTE", "ESTORNADO", "ESTORNO_PARCIAL"
    }
    enum_values["payment_method_type"] = {
        "PIX", "CARTAO_CREDITO", "CARTAO_DEBITO", "BOLETO", "LINK_PAGAMENTO", "TRANSFERENCIA_DIRETA"
    }
    enum_values["financial_entry_type"] = {
        "PAYMENT_CONFIRMED", "COMMISSION_PROVISIONED", "COMMISSION_CONSOLIDATED",
        "REFUND_FULL", "REFUND_PARTIAL", "COMMISSION_REVERSAL_FULL", "COMMISSION_REVERSAL_PARTIAL",
        "PARTNER_PAYOUT_SETTLED", "COMPENSATORY_ADJUSTMENT",
    }

    return table_columns, enum_values


def validate_queries_against_schema(
    table_columns: Dict[str, Set[str]],
    enum_values: Dict[str, Set[str]],
    files_to_check: List[Path],
) -> Tuple[bool, List[str], int]:
    """
    M02.0-F01 & M02.2-F07:
    Validação dinâmica cruzada:
      1) Extrai dinamicamente de cada arquivo todos os aliases SQL (`FROM/JOIN/UPDATE public.<tabela> [AS] <alias>`)
         e todas as variáveis PL/pgSQL tipadas por tabela (`v_<var> public.<tabela>`), além de `OLD`/`NEW` em triggers.
      2) Valida toda referência `<alias_ou_var>.<coluna>` contra as colunas reais extraídas de `000001_initial_schema.sql`.
      3) Valida todos os 7 tipos ENUM (`booking_status_type`, `ledger_status_type`, `app_role`, `partner_status_type`,
         `moderation_status_type`, `pricing_model_type`, `commission_model_type`) e `block_type` em comparações e casts.
    """
    errors: List[str] = []
    sql_keywords = {
        "where", "set", "join", "inner", "left", "right", "full", "cross", "on", "and", "or",
        "order", "group", "limit", "offset", "returning", "values", "select", "from", "into",
        "as", "for", "using", "having", "union", "except", "intersect",
    }
    valid_block_types = {"BLOQUEIO_TOTAL", "MANUTENCAO", "INTERDICAO_MARINHA", "AJUSTE_CAPACIDADE"}
    total_dynamic_bindings = 0

    for fpath in files_to_check:
        raw = fpath.read_text(encoding="utf-8")
        active_lines = []
        for lno, line in enumerate(raw.splitlines(), 1):
            s = line.strip()
            if s.startswith("--") or s.startswith("#"):
                continue
            active_lines.append((lno, line))
        clean_text = "\n".join(l for _, l in active_lines)

        # Extração dinâmica de bindings (alias -> set of tables) no arquivo
        dynamic_alias_map: Dict[str, Set[str]] = {}

        # A) Declarações PL/pgSQL: `v_var public.tabela`
        for m in re.finditer(r"\b([a-z_][a-z0-9_]*)\s+public\.([a-z_][a-z0-9_]*)(?:%ROWTYPE)?\s*;", clean_text, flags=re.I):
            var_name, tname = m.group(1).lower(), m.group(2).lower()
            if tname in table_columns:
                dynamic_alias_map.setdefault(var_name, set()).add(tname)

        # B) Cláusulas SQL: `FROM/JOIN/UPDATE public.tabela [AS] alias`
        for m in re.finditer(
            r"\b(?:FROM|JOIN|UPDATE)\s+public\.([a-z_][a-z0-9_]*)(?:\s+AS)?\s+([a-z_][a-z0-9_]*)\b",
            clean_text,
            flags=re.I,
        ):
            tname, alias = m.group(1).lower(), m.group(2).lower()
            if alias not in sql_keywords and tname in table_columns:
                dynamic_alias_map.setdefault(alias, set()).add(tname)

        # B2) Catálogo pg_proc quando compartilha alias no mesmo arquivo
        for m in re.finditer(
            r"\b(?:FROM|JOIN)\s+(?:pg_catalog\.)?pg_proc(?:\s+AS)?\s+([a-z_][a-z0-9_]*)\b",
            clean_text,
            flags=re.I,
        ):
            alias = m.group(1).lower()
            if alias in dynamic_alias_map:
                table_columns.setdefault("_pg_proc", {"oid", "proname", "pronamespace", "prosrc", "prosecdef", "proconfig"})
                dynamic_alias_map[alias].add("_pg_proc")

        total_dynamic_bindings += len(dynamic_alias_map)

        # 1) Proíbe literais inválidos conhecidos
        for lno, line in active_lines:
            if "'PROVISIONADA'" in line:
                errors.append(f"{fpath.name}:L{lno}: Literal enum inválido 'PROVISIONADA'")
            if "'CAPACIDADE_REDUZIDA'" in line:
                errors.append(f"{fpath.name}:L{lno}: Literal block_type inválido 'CAPACIDADE_REDUZIDA'")

        # 2) Valida todas as referências `alias.coluna` contra a união das colunas das tabelas associadas ao alias
        for lno, line in active_lines:
            for m in re.finditer(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)\b(?!\s*\()", line):
                alias, col = m.group(1).lower(), m.group(2).lower()
                if alias in dynamic_alias_map:
                    bound_tables = dynamic_alias_map[alias]
                    allowed_cols: Set[str] = set()
                    for bt in bound_tables:
                        allowed_cols |= table_columns.get(bt, set())
                    if col not in allowed_cols:
                        errors.append(
                            f"{fpath.name}:L{lno}: Coluna inexistente '{alias}.{col}' para tabela(s) {sorted(bound_tables)}"
                        )

        # 2b) Valida listas de colunas explícitas em `INSERT INTO public.<tabela> (col1, col2, ...)`
        for m in re.finditer(
            r"INSERT\s+INTO\s+public\.([a-z_][a-z0-9_]*)\s*\(([^)]+)\)\s*VALUES",
            clean_text,
            flags=re.I | re.S,
        ):
            tname = m.group(1).lower()
            if tname in table_columns:
                allowed_cols = table_columns[tname]
                for raw_col in m.group(2).split(","):
                    cname = raw_col.strip().lower()
                    if cname and re.match(r"^[a-z_][a-z0-9_]*$", cname) and cname not in allowed_cols:
                        errors.append(
                            f"{fpath.name}: INSERT INTO public.{tname} referencia coluna inexistente '{cname}'"
                        )

        # 3) Verifica consultas diretas `FROM public.commission_ledger WHERE ... status =` sem alias
        for m in re.finditer(r"FROM\s+public\.commission_ledger\s+WHERE\s+([^);]+)", clean_text, flags=re.I | re.S):
            where_clause = m.group(1)
            if re.search(r"(?<![a-z_])status\s*=", where_clause, flags=re.I):
                errors.append(f"{fpath.name}: Consulta em public.commission_ledger usa 'status =' em vez de 'ledger_status ='")

        # 4) Valida casts explícitos `'VALOR'::public.<enum_type>` para todos os 7 tipos ENUM
        for lno, line in active_lines:
            for m in re.finditer(r"'([^']+)'::public\.([a-z0-9_]+)", line):
                val, etype = m.group(1), m.group(2)
                if etype in enum_values and val not in enum_values[etype]:
                    errors.append(f"{fpath.name}:L{lno}: Literal '{val}' inválido para o enum public.{etype}")

        # 5) Valida comparações diretas de `ledger_status` contra `ledger_status_type`
        valid_ledger_statuses = enum_values.get("ledger_status_type", set())
        for lno, line in active_lines:
            for m in re.finditer(r"ledger_status\s*(?:=|<>\s*)\s*'([A-Z_]+)'", line):
                val = m.group(1)
                if val not in valid_ledger_statuses:
                    errors.append(f"{fpath.name}:L{lno}: Valor '{val}' inválido para public.ledger_status_type")

        # 6) Valida chamadas a `upsert_availability_block` quanto ao 3º argumento (`block_type`)
        for m in re.finditer(
            r"upsert_availability_block\s*\(\s*'[^']+'\s*,\s*DATE\s*'[^']+'\s*,\s*'([^']+)'",
            clean_text,
            flags=re.S,
        ):
            btype = m.group(1)
            if btype not in valid_block_types:
                errors.append(f"{fpath.name}: Chamada upsert_availability_block com block_type inválido '{btype}'")

    return len(errors) == 0, errors, total_dynamic_bindings


def verify_all() -> int:
    checks: List[Tuple[str, bool, str]] = []

    def record(code: str, ok: bool, detail: str) -> None:
        checks.append((code, ok, detail))
        status_label = "STATIC PASS" if ok else "FAIL"
        print(f"[{status_label}] [{code}] {detail}")

    m1 = (MIGRATIONS_DIR / "20261108000001_initial_schema.sql").read_text(encoding="utf-8")
    m2 = (MIGRATIONS_DIR / "20261108000002_rls_and_rpcs.sql").read_text(encoding="utf-8")
    m3 = (MIGRATIONS_DIR / "20261110000003_missao01_audit_fixes_and_rpcs.sql").read_text(encoding="utf-8")
    m4 = (MIGRATIONS_DIR / "20261110000004_missao01_official_catalog_seed.sql").read_text(encoding="utf-8")
    m5 = (MIGRATIONS_DIR / "20261111000005_missao01_4_forensic_hardening.sql").read_text(encoding="utf-8")
    m6 = (MIGRATIONS_DIR / "20261112000006_missao01_6_forensic_fixes.sql").read_text(encoding="utf-8")
    m7 = (MIGRATIONS_DIR / "20261113000007_missao01_8_controlled_fixes.sql").read_text(encoding="utf-8")
    m8 = (MIGRATIONS_DIR / "20261114000008_missao01_9_controlled_fixes.sql").read_text(encoding="utf-8")
    m9 = (MIGRATIONS_DIR / "20261115000009_missao02_1_residual_fixes.sql").read_text(encoding="utf-8")
    m10 = (MIGRATIONS_DIR / "20261116000010_missao02_3_surgical_fixes.sql").read_text(encoding="utf-8")
    m11 = (MIGRATIONS_DIR / "20261117000011_missao02_4_adversarial_fixes.sql").read_text(encoding="utf-8")
    m12 = (MIGRATIONS_DIR / "20261118000012_missao02_5_integrity_closure.sql").read_text(encoding="utf-8")
    m13 = (MIGRATIONS_DIR / "20261119000013_missao02_6_post_cancel_idempotency.sql").read_text(encoding="utf-8")
    m14 = (MIGRATIONS_DIR / "20261120000014_missao02_7_lineage_persistence_and_hardening.sql").read_text(encoding="utf-8")
    m15 = (MIGRATIONS_DIR / "20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql").read_text(encoding="utf-8")
    m16 = (MIGRATIONS_DIR / "20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql").read_text(encoding="utf-8")
    m17 = (MIGRATIONS_DIR / "20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql").read_text(encoding="utf-8")
    m18 = (MIGRATIONS_DIR / "20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql").read_text(encoding="utf-8")
    m19 = (MIGRATIONS_DIR / "20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql").read_text(encoding="utf-8")
    m20 = (MIGRATIONS_DIR / "20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql").read_text(encoding="utf-8")
    m21 = (MIGRATIONS_DIR / "20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql").read_text(encoding="utf-8")
    m22 = (MIGRATIONS_DIR / "20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql").read_text(encoding="utf-8")

    m3_code = "\n".join(line for line in m3.splitlines() if not line.strip().startswith("--"))
    m5_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m5.splitlines() if not line.strip().startswith("--")))
    m6_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m6.splitlines() if not line.strip().startswith("--")))
    m7_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m7.splitlines() if not line.strip().startswith("--")))
    m8_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m8.splitlines() if not line.strip().startswith("--")))
    m9_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m9.splitlines() if not line.strip().startswith("--")))
    m10_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m10.splitlines() if not line.strip().startswith("--")))
    m11_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m11.splitlines() if not line.strip().startswith("--")))
    m12_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m12.splitlines() if not line.strip().startswith("--")))
    m13_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m13.splitlines() if not line.strip().startswith("--")))
    m14_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m14.splitlines() if not line.strip().startswith("--")))
    m15_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m15.splitlines() if not line.strip().startswith("--")))
    m16_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m16.splitlines() if not line.strip().startswith("--")))
    m17_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m17.splitlines() if not line.strip().startswith("--")))
    m18_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m18.splitlines() if not line.strip().startswith("--")))
    m19_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m19.splitlines() if not line.strip().startswith("--")))
    m20_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m20.splitlines() if not line.strip().startswith("--")))
    m21_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m21.splitlines() if not line.strip().startswith("--")))
    m22_code = re.sub(r"\(\s+", "(", " ".join(line.strip() for line in m22.splitlines() if not line.strip().startswith("--")))
    ts_types = (PROJECT_ROOT / "src" / "types" / "database.types.ts").read_text(encoding="utf-8")

    # 1. STATIC-01: Zero uso de variáveis GUC app.*
    combined_exec = "\n".join([m3_code, m5_code, m6_code, m7_code, m8_code, m9_code, m10_code, m11_code, m12_code, m13_code, m14_code, m15_code, m16_code, m17_code, m18_code, m19_code, m20_code, m21_code, m22_code])
    no_guc_bypass = (
        "app.internal_auth_sync" not in combined_exec
        and "app.internal_ledger_sync" not in combined_exec
        and "app.current_actor_role" not in combined_exec
    )
    record(
        "STATIC-01",
        no_guc_bypass,
        "Auditoria A: Nenhuma variável GUC controlável por sessão (app.*) é lida ou utilizada em todo o código executável de 000003 a 000009.",
    )

    # 2. STATIC-02: Guardião transacional internal_guard.execution_tokens com trigger_depth e cleanup_tokens
    token_guard_ok = (
        "CREATE SCHEMA IF NOT EXISTS internal_guard;" in m5_code
        and "CREATE TABLE IF NOT EXISTS internal_guard.execution_tokens" in m5_code
        and "AND t.trigger_depth = pg_trigger_depth() - 1" in m6_code
        and "CREATE OR REPLACE FUNCTION internal_guard.cleanup_tokens(" in m6_code
        and all(
            sc in m6_code
            for sc in (
                "'AUTH_PROFILE_SYNC'",
                "'BOOKING_MUTATION'",
                "'LEDGER_SYNC'",
                "'LEDGER_SETTLE'",
                "'CATALOG_RATING_SYNC'",
                "'AVAILABILITY_BLOCK_MUTATION'",
                "'REVIEW_MUTATION'",
            )
        )
        and "REVIEW_ANONYMOUS_BOOKING_UNVERIFIED" in m6_code
    )
    record(
        "STATIC-02",
        token_guard_ok,
        "Auditoria A/C & M01.5-05/06: Guardião internal_guard.execution_tokens com validação 't.trigger_depth = pg_trigger_depth() - 1', cleanup_tokens() e 7 escopos ativos.",
    )

    # 3. STATIC-03: Inventário extraído de 000001..000009 vs function_inventory.json
    inv_data = json.loads(INVENTORY_FILE.read_text(encoding="utf-8"))
    expected_fns = inv_data["functions"]
    expected_summary = inv_data["summary"]
    cum_summary = inv_data["cumulative_active_after_000022"]

    fn_pattern = re.compile(
        r"CREATE(?:\s+OR\s+REPLACE)?\s+FUNCTION\s+([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)\s*\(([^;]*?)\)\s*RETURNS\s+(.*?)\s+AS\s+\$(?:body)?\$",
        re.S,
    )
    extracted_m3 = []
    bad_sp = []
    for m in fn_pattern.finditer(m3):
        schema_name, fn_name = m.group(1), m.group(2)
        ret_and_opts = " ".join(m.group(4).split())
        sec_type = "SECURITY DEFINER" if "SECURITY DEFINER" in ret_and_opts else "SECURITY INVOKER"
        if "SET search_path = pg_catalog," not in ret_and_opts:
            bad_sp.append(f"000003:{schema_name}.{fn_name}")
        extracted_m3.append((schema_name, fn_name, sec_type))

    active_map: Dict[str, Tuple[str, str, str]] = {}
    for mig_name, sql_txt in [
        ("000001", m1),
        ("000002", m2),
        ("000003", m3),
        ("000004", m4),
        ("000005", m5),
        ("000006", m6),
        ("000007", m7),
        ("000008", m8),
        ("000009", m9),
        ("000010", m10),
        ("000011", m11),
        ("000012", m12),
        ("000013", m13),
        ("000014", m14),
        ("000015", m15),
        ("000016", m16),
        ("000017", m17),
        ("000018", m18),
        ("000019", m19),
        ("000020", m20),
        ("000021", m21),
        ("000022", m22),
    ]:
        for m in fn_pattern.finditer(sql_txt):
            s_name, f_name = m.group(1), m.group(2)
            r_opts = " ".join(m.group(4).split())
            s_type = "SECURITY DEFINER" if "SECURITY DEFINER" in r_opts else "SECURITY INVOKER"
            if mig_name in ("000003", "000005", "000006", "000007", "000008", "000009", "000010", "000011", "000012", "000013", "000014", "000015", "000016", "000017", "000018", "000019", "000020", "000021", "000022") and "SET search_path = pg_catalog," not in r_opts:
                bad_sp.append(f"{mig_name}:{s_name}.{f_name}")
            active_map[f"{s_name}.{f_name}"] = (s_name, f_name, s_type)

    expected_m3_tuples = [(f["schema"], f["name"], f["security_type"]) for f in expected_fns]
    expected_active_tuples = [(f["schema"], f["name"], f["security_type"]) for f in cum_summary["active_functions"]]
    actual_active_tuples = list(active_map.values())

    act_def = sum(1 for _, _, st in actual_active_tuples if st == "SECURITY DEFINER")
    act_inv = sum(1 for _, _, st in actual_active_tuples if st == "SECURITY INVOKER")

    inventory_matches = (
        extracted_m3 == expected_m3_tuples
        and len(extracted_m3) == expected_summary["total_functions"]
        and actual_active_tuples == expected_active_tuples
        and len(actual_active_tuples) == cum_summary["total_active_functions"]
        and act_def == cum_summary["total_security_definer"]
        and act_inv == cum_summary["total_security_invoker"]
        and len(bad_sp) == 0
    )
    record(
        "STATIC-03",
        inventory_matches,
        f"Auditoria B: Inventário extraído corresponde 1:1 a function_inventory.json -> "
        f"000003={len(extracted_m3)} funções | Acumulado pós-000009={len(actual_active_tuples)} funções ativas "
        f"({act_def} SECURITY DEFINER + {act_inv} SECURITY INVOKER), 100% com 'SET search_path = pg_catalog, ...' ({len(bad_sp)} vulneráveis).",
    )

    # 4. STATIC-04: REVOKE CREATE ON SCHEMA public FROM PUBLIC e REVOKE ALL ON FUNCTION ... FROM PUBLIC
    has_schema_revoke = "REVOKE CREATE ON SCHEMA public FROM PUBLIC;" in m3_code
    has_universal_fn_revoke = "EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);" in m9_code
    record(
        "STATIC-04",
        has_schema_revoke and has_universal_fn_revoke,
        "Auditoria B: Criação de objetos em public revogada de PUBLIC e permissão EXECUTE default revogada de PUBLIC em todas as funções ativas.",
    )

    # 5. STATIC-05: Cobertura RLS nas 19 tabelas públicas + 1 tabela privada internal_guard.execution_tokens
    tables_0001 = set(re.findall(r"CREATE TABLE public\.([a-z0-9_]+)", m1))
    rls_enabled = set(re.findall(r"ALTER TABLE public\.([a-z0-9_]+) ENABLE ROW LEVEL SECURITY", m1 + "\n" + m2 + "\n" + m3))
    rls_policies_tables = set(re.findall(r'CREATE POLICY\s+"[^"]+"\s+ON\s+public\.([a-z0-9_]+)', m2 + "\n" + m3 + "\n" + m5 + "\n" + m6))
    ig_rls = "ALTER TABLE internal_guard.execution_tokens ENABLE ROW LEVEL SECURITY;" in m5_code
    record(
        "STATIC-05",
        len(tables_0001) == 19 and tables_0001 == rls_enabled and tables_0001 == rls_policies_tables and ig_rls,
        f"Auditoria C: {len(rls_policies_tables)}/{len(tables_0001)} tabelas públicas + internal_guard.execution_tokens com RLS habilitado e REVOKE de escrita direta para anon/authenticated.",
    )

    # 6. STATIC-06: Corpo ativo final pós-000009 das 12 rotinas concorrentes
    active_bodies = extract_active_function_bodies([m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20, m21, m22])
    target_lock_fns = (
        "public.validate_availability_block_ownership",
        "public.upsert_availability_block",
        "public.delete_availability_block",
        "public.check_and_lock_vessel_capacity",
        "public.create_booking_request",
        "public.transition_booking_status",
        "public.expire_stale_bookings",
        "public.admin_update_booking",
        "public.settle_commission_ledger",
        "public.create_verified_review",
        "public.protect_catalog_moderation_columns",
        "public.admin_anonymize_customer_pii",
        "public.cancel_booking_by_tourist_token",
    )

    bad_lock_fns: List[str] = []
    for fn_key in target_lock_fns:
        body = active_bodies.get(fn_key, "")
        p_ves = body.find("FROM public.vessels")
        p_adv = body.find("pg_advisory_xact_lock")
        if not (0 < p_ves < p_adv):
            bad_lock_fns.append(fn_key)

    del_body = active_bodies.get("public.delete_availability_block", "")
    exp_body = active_bodies.get("public.expire_stale_bookings", "")
    reval_before_token_ok = (
        0 < del_body.find("FROM public.availability_blocks") < del_body.rfind("FOR UPDATE;") < del_body.find("internal_guard.issue_token")
        and 0 < exp_body.find("FROM public.bookings") < exp_body.rfind("FOR UPDATE;") < exp_body.find("internal_guard.issue_token")
    )

    unique_block_idx_ok = "CREATE UNIQUE INDEX IF NOT EXISTS idx_availability_blocks_unique_logical_key" in m6_code and "NULLS NOT DISTINCT" in m6_code
    direct_block_insert_forbid = "DIRECT_AVAILABILITY_BLOCK_INSERT_FORBIDDEN" in m6_code and 'DROP POLICY IF EXISTS "availability_blocks_partner_insert"' in m6_code

    record(
        "STATIC-06",
        len(bad_lock_fns) == 0 and reval_before_token_ok and unique_block_idx_ok and direct_block_insert_forbid,
        f"Auditoria D: Corpo ativo final pós-000009 validado nas {len(target_lock_fns)} rotinas concorrentes "
        f"({len(bad_lock_fns)} fora de ordem), revalidação FOR UPDATE antes de issue_token, bloqueio de INSERT direto e índice UNIQUE NULLS NOT DISTINCT.",
    )

    # 7. STATIC-07: Imutabilidade do commission_ledger, liquidação única e bloqueio de DELETE
    ledger_guards_ok = (
        "LEDGER_IMMUTABLE_FINANCIALS" in m9_code
        and "LEDGER_DIRECT_INSERT_FORBIDDEN" in m9_code
        and "LEDGER_DIRECT_SETTLE_FORBIDDEN" in m9_code
        and "LEDGER_ALREADY_PAID" in m9_code
        and "LEDGER_PAYMENT_ADMIN_ONLY" in m9_code
        and "IMMUTABLE_RECORD_DELETE_FORBIDDEN" in m3_code
    )
    record(
        "STATIC-07",
        ledger_guards_ok,
        "Auditoria E: Livro-razão blindado contra alteração de valores, inserção manual, liquidação direta fora da RPC, exclusão (BEFORE DELETE) e pagamento duplo.",
    )

    # 8. STATIC-08: AST TypeScript/JSX
    sql_em_disputa = "WHEN 'EM_DISPUTA' THEN\n      RETURN p_new_status IN ('PASSEIO_REALIZADO', 'CANCELADA');" in m3
    ts_em_disputa = "EM_DISPUTA: ['PASSEIO_REALIZADO', 'CANCELADA']" in ts_types

    ts_files = [
        PROJECT_ROOT / "src" / "types" / "database.types.ts",
        PROJECT_ROOT / "src" / "lib" / "runtimeConfig.ts",
        PROJECT_ROOT / "src" / "lib" / "supabaseClient.ts",
        PROJECT_ROOT / "src" / "lib" / "bookingService.ts",
        PROJECT_ROOT / "src" / "lib" / "operationsService.ts",
        PROJECT_ROOT / "src" / "lib" / "authTypes.ts",
        PROJECT_ROOT / "src" / "lib" / "authValidation.ts",
        PROJECT_ROOT / "src" / "lib" / "authSession.ts",
        PROJECT_ROOT / "src" / "lib" / "authGuards.ts",
        PROJECT_ROOT / "src" / "lib" / "authService.ts",
        PROJECT_ROOT / "src" / "lib" / "partnerOnboardingService.ts",
        PROJECT_ROOT / "src" / "lib" / "financialService.ts",
        PROJECT_ROOT / "src" / "App.tsx",
        PROJECT_ROOT / "src" / "main.tsx",
    ]
    export_map: Dict[Path, Set[str]] = {}
    import_map: Dict[Path, List[Tuple[str, List[str]]]] = {}
    syntax_all_ok = True

    for tf in ts_files:
        exps, imps, syn_ok = parse_ts_exports_and_imports(tf)
        export_map[tf.resolve()] = exps
        import_map[tf.resolve()] = imps
        if not syn_ok:
            syntax_all_ok = False

    missing_imports: List[str] = []
    for tf in ts_files:
        base_dir = tf.resolve().parent
        for mod_src, specs in import_map[tf.resolve()]:
            if not mod_src.startswith(".") or mod_src.endswith(".css"):
                continue
            resolved_target = (base_dir / mod_src).resolve()
            if not resolved_target.exists():
                if (base_dir / (mod_src + ".ts")).resolve().exists():
                    resolved_target = (base_dir / (mod_src + ".ts")).resolve()
                elif (base_dir / (mod_src + ".tsx")).resolve().exists():
                    resolved_target = (base_dir / (mod_src + ".tsx")).resolve()
            target_exps = export_map.get(resolved_target)
            if target_exps is None:
                missing_imports.append(f"Unresolved module {mod_src} in {tf.name}")
                continue
            for sp in specs:
                if sp not in target_exps:
                    missing_imports.append(f"Missing export '{sp}' in {resolved_target.name} (imported by {tf.name})")

    app_txt = (PROJECT_ROOT / "src" / "App.tsx").read_text(encoding="utf-8")
    app_imported_symbols = {sp for _, specs in import_map[(PROJECT_ROOT / "src" / "App.tsx").resolve()] for sp in specs}
    app_called_rpcs = set(re.findall(r"\b(rpc[A-Za-z0-9_]+)\s*\(", app_txt))
    unimported_rpc_calls = app_called_rpcs - app_imported_symbols

    babel_ast_ok = True
    engine_note = "resolvedor Python + AST @babel/parser/@babel/traverse/@babel/core (resolução local createRequire)"
    node_script = """
const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');

const projectRequire = createRequire(path.join(process.cwd(), 'package.json'));
function loadBabelDep(pkgName) {
  try {
    return projectRequire(pkgName);
  } catch {
    return require(pkgName);
  }
}

const babel = loadBabelDep('@babel/core');
const parser = loadBabelDep('@babel/parser');
const traverseMod = loadBabelDep('@babel/traverse');
const traverse = traverseMod.default || traverseMod;
const presetTypescript = loadBabelDep('@babel/preset-typescript');
const presetReact = loadBabelDep('@babel/preset-react');

const files = [
  'src/types/database.types.ts',
  'src/lib/runtimeConfig.ts',
  'src/lib/supabaseClient.ts',
  'src/lib/bookingService.ts',
  'src/lib/operationsService.ts',
  'src/lib/authTypes.ts',
  'src/lib/authValidation.ts',
  'src/lib/authSession.ts',
  'src/lib/authGuards.ts',
  'src/lib/authService.ts',
  'src/lib/partnerOnboardingService.ts',
  'src/lib/financialService.ts',
  'src/App.tsx',
  'src/main.tsx',
];
const builtins = new Set([
  'Record', 'Partial', 'Pick', 'Readonly', 'Promise', 'Set', 'Map', 'Array',
  'Error', 'Date', 'RegExp', 'HTMLElement', 'HTMLInputElement',
  'HTMLSelectElement', 'HTMLTextAreaElement', 'FileReader', 'React', 'const'
]);
for (const f of files) {
  const code = fs.readFileSync(f, 'utf8');
  const isTsx = f.endsWith('.tsx');
  const ast = parser.parse(code, { sourceType: 'module', plugins: isTsx ? ['typescript', 'jsx'] : ['typescript'] });
  const declared = new Set(builtins);
  traverse(ast, {
    TSTypeAliasDeclaration(p) { declared.add(p.node.id.name); },
    TSInterfaceDeclaration(p) { declared.add(p.node.id.name); },
    TSEnumDeclaration(p) { declared.add(p.node.id.name); },
    TSTypeParameter(p) { declared.add(p.node.name); },
    ImportSpecifier(p) { declared.add(p.node.local.name); },
    ImportDefaultSpecifier(p) { declared.add(p.node.local.name); },
    ImportNamespaceSpecifier(p) { declared.add(p.node.local.name); },
  });
  traverse(ast, {
    TSTypeReference(p) {
      const tn = p.node.typeName;
      const name = tn.type === 'Identifier' ? tn.name : (tn.type === 'TSQualifiedName' && tn.left.type === 'Identifier' ? tn.left.name : null);
      if (name && !declared.has(name)) {
        console.error('UNDECLARED_TYPE:', f, p.node.loc.start.line, name);
        process.exit(1);
      }
    },
    CallExpression(p) {
      if (p.node.callee.type === 'Identifier' && p.node.callee.name.startsWith('rpc')) {
        if (!p.scope.hasBinding(p.node.callee.name)) {
          console.error('UNBOUND_RPC_CALL:', f, p.node.loc.start.line, p.node.callee.name);
          process.exit(1);
        }
      }
    }
  });
  const out = babel.transformSync(code, {
    filename: f,
    configFile: false,
    babelrc: false,
    presets: [
      [presetTypescript, { isTSX: isTsx, allExtensions: true }],
      ...(isTsx ? [[presetReact, { runtime: 'automatic' }]] : []),
    ],
  });
  if (!out || !out.code) process.exit(1);
}
"""
    clean_env = dict(os.environ)
    clean_env.pop("NODE_PATH", None)
    proc = subprocess.run(["node", "-e", node_script], cwd=str(PROJECT_ROOT), env=clean_env, capture_output=True, text=True)
    if proc.returncode != 0:
        babel_ast_ok = False
        print("Erro AST Babel:", proc.stderr)

    record(
        "STATIC-08",
        sql_em_disputa
        and ts_em_disputa
        and syntax_all_ok
        and len(missing_imports) == 0
        and len(unimported_rpc_calls) == 0
        and babel_ast_ok,
        f"Auditoria F: Contratos de estados, {len(app_called_rpcs)} chamadas RPC importadas, 0 tipos não declarados e transpilação AST validados via {engine_note}.",
    )

    # 9. STATIC-09: Higiene & Seed
    no_dup_files = (
        not (PROJECT_ROOT / "supabase" / "seed.sql").exists()
        and not (PROJECT_ROOT / "supabase" / "tests" / "missao01_pg_test_suite.sql").exists()
        and (PROJECT_ROOT / "supabase" / "migrations" / "20261110000004_missao01_official_catalog_seed.sql").exists()
        and (PROJECT_ROOT / "supabase" / "migrations" / "20261115000009_missao02_1_residual_fixes.sql").exists()
        and (PROJECT_ROOT / "supabase" / "tests" / "homologacao_postgresql_real.sql").exists()
    )
    seed_inserts = re.findall(r"INSERT INTO public\.[a-z0-9_]+", m4)
    seed_on_conflicts = re.findall(r"ON CONFLICT[^\n]*DO NOTHING;", m4)
    seed_idempotent = len(seed_inserts) == 6 and len(seed_inserts) == len(seed_on_conflicts)

    no_base64_in_app = "data:image/jpeg;base64," not in app_txt
    media_files = list((PROJECT_ROOT / "public" / "media").glob("*.jpg"))

    index_html = (PROJECT_ROOT / "index.html").read_text(encoding="utf-8")
    tailwind_configured = (
        "cdn.tailwindcss.com" not in index_html
        and (PROJECT_ROOT / "tailwind.config.js").exists()
        and (PROJECT_ROOT / "postcss.config.js").exists()
        and (PROJECT_ROOT / "src" / "index.css").exists()
        and (PROJECT_ROOT / ".gitignore").exists()
        and (PROJECT_ROOT / "package-lock.json").exists()
    )

    env_example = (PROJECT_ROOT / ".env.example").read_text(encoding="utf-8")
    env_clean = "G-UBATUBA2026" not in env_example and "100000000000000" not in env_example and "<SEU_GA4_MEASUREMENT_ID" in env_example

    edge_code = (PROJECT_ROOT / "supabase" / "functions" / "whatsapp-lead-tracker" / "index.ts").read_text(encoding="utf-8")
    cors_restricted = "'Access-Control-Allow-Origin': '*'" not in edge_code and "FORBIDDEN_ORIGIN" in edge_code

    backups_clean = True
    for bfile in (PROJECT_ROOT / "supabase" / "backups").glob("*.sql"):
        btxt = bfile.read_text(encoding="utf-8")
        btxt_outside_funcs = re.sub(r"\$\$.*?\$\$", "", btxt, flags=re.S)
        if re.search(r"INSERT INTO\s+(?:public\.bookings|auth\.users)\b", btxt_outside_funcs, re.I):
            backups_clean = False

    record(
        "STATIC-09",
        no_dup_files
        and seed_idempotent
        and no_base64_in_app
        and len(media_files) == 5
        and tailwind_configured
        and env_clean
        and cors_restricted
        and backups_clean,
        f"Higiene & Seed: 0 arquivos SQL duplicados, {len(seed_on_conflicts)}/{len(seed_inserts)} INSERTs idempotentes no seed 000004, "
        f"{len(media_files)} imagens em public/media/, Tailwind/PostCSS configurado, CORS restrito e 0 dados de clientes nos backups.",
    )

    # 10. STATIC-10: Missão 01.8
    hom_sql = (PROJECT_ROOT / "supabase" / "tests" / "homologacao_postgresql_real.sql").read_text(encoding="utf-8")
    conc_py = (PROJECT_ROOT / "supabase" / "tests" / "test_concorrencia_real_pg.py").read_text(encoding="utf-8")
    m7_auth_ddl = m7_code.split("CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns")[0]
    conc_exec_code = conc_py.split("DATABASE_URL =")[1] if "DATABASE_URL =" in conc_py else conc_py
    m01_8_checks_ok = (
        "TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS" in m7_code
        and "TOUR_HAS_ACTIVE_BOOKINGS" in m7_code
        and "email_confirmed_at TIMESTAMPTZ;" in m7_auth_ddl
        and "DEFAULT now()" not in m7_auth_ddl
        and "ACTIVE_BOOKING_PASSENGERS_CONFLICT" in m7_code
        and "CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(" in m7_code
        and "ANONYMIZE_PII_LGPD" in m7_code
        and all(f"T8.{i}" in hom_sql for i in (1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15))
        and "T8.4A-1" in hom_sql
        and "T8.4B-1" in hom_sql
        and "DISABLE TRIGGER" not in conc_exec_code
        and "resolveAuthenticatedSessionContext" in app_txt
    )
    record(
        "STATIC-10",
        m01_8_checks_ok,
        "Missão 01.8 (M01.7-001 a M01.7-010): Capacidade reversa em tours, email_confirmed_at sem DEFAULT now(), guarda 4-fatores nas RPCs de agenda, conflito de passageiros e limpeza sem DISABLE TRIGGER comprovados.",
    )

    # 11. STATIC-11: Missões 01.9, 02.1 & 02.2 (M02.2-F01 a M02.2-F08)
    runner_sh = (PROJECT_ROOT / "supabase" / "tests" / "run_postgresql_homologation.sh").read_text(encoding="utf-8")
    load_py = (PROJECT_ROOT / "supabase" / "tests" / "load_stability_plan_pg.py").read_text(encoding="utf-8")
    guard_test_py = (PROJECT_ROOT / "supabase" / "tests" / "test_runner_destructive_guards.py").read_text(encoding="utf-8")
    m02_2_checks_ok = (
        "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO" in runner_sh
        and "ubatuba_homolog_disposable" in runner_sh
        and "DO $guard$" in runner_sh
        and runner_sh.count("DROP SCHEMA IF EXISTS public CASCADE") == 1
        and "--single-transaction" in runner_sh
        and "QUERY_PARAM_FORBIDDEN" in runner_sh
        and "PORT_IN_USE" in runner_sh
        and "CONTAINER_ALREADY_EXISTS" in runner_sh
        and "unset PGHOST PGHOSTADDR" in runner_sh
        and "20261115000009_missao02_1_residual_fixes.sql" in runner_sh
        and "ensure_load_test_partner_users" in load_py
        and "execute_prewarmed_psql_at_barrier" in load_py
        and "BrokenBarrierError" in load_py
        and "ensure_partner_users_and_verify_rls_isolation" in conc_py
        and "SET LOCAL ROLE anon;" in conc_py
        and "LGPD_IMMUTABLE_OPERATIONAL_FIELDS" in m9_code
        and "CREATE OR REPLACE FUNCTION public.resolve_booking_actor_role(" in m9_code
        and "CREATE OR REPLACE FUNCTION public.admin_update_booking(" in m9_code
        and "CREATE OR REPLACE FUNCTION public.settle_commission_ledger(" in m9_code
        and "ledger_notes_sanitized" in m9_code
        and "external_channel_warning" in m9_code
        and all(f"T9.{i}" in hom_sql for i in range(1, 18))
        and "LGPD_INVALID_TARGET_VALUES" in m10_code
        and "VESSEL_SELF_APPROVAL_FORBIDDEN" in m10_code
        and "INVALID_IDEMPOTENCY_KEY" in m10_code
        and "GUARD-14-QUERY-AT-SPOOF-AND-LIBPQ-ENV-UNSET" in guard_test_py
        and "GUARD-15-CONTAINER-PREEXISTENCE-COLLISION" in guard_test_py
    )
    record(
        "STATIC-11",
        m02_2_checks_ok,
        "Missões 01.9, 02.1 & 02.2 (M02.2-F01 a F08): Guarda 4-fatores em resolve_booking_actor_role/admin_update_booking/settle_commission_ledger, blindagem LGPD_IMMUTABLE_OPERATIONAL_FIELDS, unset PG*, BrokenBarrierError e T9.1..T9.16 comprovados.",
    )

    # 12. STATIC-12 (M02.0-F01 & M02.2-F07): Validação dinâmica cruzada entre Schema SQL (19 tabelas e 7 enums) e todas as queries
    table_columns, enum_values = extract_schema_tables_columns_and_enums(m1)
    cross_ok, cross_errors, dyn_bindings = validate_queries_against_schema(
        table_columns,
        enum_values,
        [
            PROJECT_ROOT / "supabase" / "tests" / "load_stability_plan_pg.py",
            PROJECT_ROOT / "supabase" / "tests" / "test_concorrencia_real_pg.py",
            PROJECT_ROOT / "supabase" / "tests" / "homologacao_postgresql_real.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261115000009_missao02_1_residual_fixes.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261116000010_missao02_3_surgical_fixes.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261117000011_missao02_4_adversarial_fixes.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261118000012_missao02_5_integrity_closure.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261119000013_missao02_6_post_cancel_idempotency.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261120000014_missao02_7_lineage_persistence_and_hardening.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261121000015_missao02_8_lgpd_lineage_and_defening_hardening.sql" if False else PROJECT_ROOT / "supabase" / "migrations" / "20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261130000024_missao02_24_adversarial_closure_and_hardening.sql",
            PROJECT_ROOT / "supabase" / "migrations" / "20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql",
        ],
    )
    if not cross_ok:
        for err in cross_errors:
            print("  [CROSS-SCHEMA ERROR]", err)
    record(
        "STATIC-12",
        cross_ok and len([k for k in table_columns if not k.startswith('_')]) == 22 and len(enum_values) == 10 and dyn_bindings >= 15,
        f"Validação Dinâmica Cruzada Schema SQL x Queries (M02.0-F01 & M02.2-F07): {len(table_columns)} tabelas, {len(enum_values)} enums e {dyn_bindings} bindings dinâmicos validados ({len(cross_errors)} divergências).",
    )

    # 13. STATIC-13 (M02.4 & M02.5): Validação Adversarial 02.4 + Fechamento de Integridade 02.5
    bs_txt = (PROJECT_ROOT / "src" / "lib" / "bookingService.ts").read_text(encoding="utf-8")
    m02_5_ok = (
        "CREATE OR REPLACE FUNCTION public.is_admin()" in m11_code
        and "CREATE OR REPLACE FUNCTION public.is_partner_member(" in m11_code
        and "CREATE OR REPLACE FUNCTION public.upsert_availability_block(" in m11_code
        and "CREATE OR REPLACE FUNCTION public.delete_availability_block(" in m11_code
        and "CREATE OR REPLACE FUNCTION public.normalize_lgpd_text(" in m12_code
        and "CREATE OR REPLACE FUNCTION public.sanitize_lgpd_audit_jsonb(" in m12_code
        and "MEDIA_TOUR_VESSEL_MISMATCH" in m12_code
        and "MEDIA_REQUIRED_ENTITY_LINK_MISSING" in m12_code
        and "UNAUTHORIZED_BOOKING_CONTEXT" in m12_code
        and "REVOKE ALL ON FUNCTION public.normalize_lgpd_text(TEXT) FROM authenticated;" in m12_code
        and "20261118000012_missao02_5_integrity_closure.sql" in runner_sh
        and "20261119000013_missao02_6_post_cancel_idempotency.sql" in runner_sh
        and "CREATE OR REPLACE FUNCTION public.derive_idempotency_lineage_key(" in m13_code
        and "clock_timestamp()" not in m13_code
        and "T9.19" in hom_sql
        and "T9.20" in hom_sql
        and "T9.21" in hom_sql
        and "20261120000014_missao02_7_lineage_persistence_and_hardening.sql" in runner_sh
        and "idx_bookings_lineage_generation_unique" in m14_code
        and "MAX(b.idempotency_generation) + 1" in m14_code
        and "export function hydrateCatalogAndBookingsSnapshot" in bs_txt
        and "export function resolveIsolatedActivePartner" in bs_txt
        and "export function mergeAvailabilityBlockList" in bs_txt
        and "hydrateCatalogAndBookingsSnapshot(snapshot," in app_txt
        and "resolveIsolatedActivePartner({" in app_txt
        and "mergeAvailabilityBlockList(prev, confirmedBlock)" in app_txt
    )
    record(
        "STATIC-13",
        m02_5_ok,
        "Missões 02.4 & 02.5 (F01 a F07): Guarda 4-fatores nas 14 funções, normalize_lgpd_text com NFD, sanitize_lgpd_audit_jsonb recursivo nas 16 chaves, proteção media_assets, separação de idempotency_key e funções reais exportadas em bookingService.ts/App.tsx comprovados.",
    )

    # 14. STATIC-14 (M02.8): Auditoria Independente 000014/000015, Hardening SECURITY DEFINER, lgpd-lin- e Backfill
    m02_8_ok = (
        "20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql" in runner_sh
        and "CREATE OR REPLACE FUNCTION public.backfill_and_verify_booking_lineage()" in m15_code
        and "lgpd-lin-" in m15_code
        and "LINEAGE_BACKFILL:" in m15_code
        and "ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;" in m15_code
        and "EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);" in m15_code
        and "EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);" in m15_code
        and "T9.22" in hom_sql
        and inv_data["cumulative_active_after_000015"]["total_active_functions"] == 42
        and inv_data["cumulative_active_after_000016"]["total_active_functions"] == 45
        and inv_data["cumulative_active_after_000017"]["total_active_functions"] == 47
        and inv_data["cumulative_active_after_000018"]["total_active_functions"] == 49
        and inv_data["cumulative_active_after_000019"]["total_active_functions"] == 52
        and inv_data["cumulative_active_after_000021"]["total_active_functions"] == 55
        and cum_summary["total_active_functions"] == 63
        and cum_summary["total_security_definer"] == 51
        and cum_summary["total_security_invoker"] == 12
    )
    record(
        "STATIC-14",
        m02_8_ok,
        "Missão 02.8 (F01 a F05): Migration 000015, backfill autenticado por token, linhagem LGPD (lgpd-lin-<root24>-<scope20>), 42 funções ativas (32 SD + 10 SI) com pg_temp final, REVOKE universal anon/authenticated e T9.22 comprovados.",
    )

    # 15. STATIC-15 (M02.8-F05): Parsing estrutural completo das 15 migrations (000001..000015) e verificação de pg_temp final nas 42 funções
    mig_files_all = sorted(MIGRATIONS_DIR.glob("*.sql"))
    parse_errors = []
    for mf in mig_files_all:
        raw_sql = mf.read_text(encoding="utf-8")
        # Verifica balanceamento de blocos dollar-quoted ($$, $body$, $guard$, etc.) e parênteses fora de strings/comentários
        i = 0
        n = len(raw_sql)
        in_line_comment = False
        in_block_comment = False
        in_single_quote = False
        dollar_tag = None
        paren_depth = 0
        while i < n:
            ch = raw_sql[i]
            if in_line_comment:
                if ch == "\n":
                    in_line_comment = False
                i += 1
                continue
            if in_block_comment:
                if raw_sql[i : i + 2] == "*/":
                    in_block_comment = False
                    i += 2
                else:
                    i += 1
                continue
            if dollar_tag is not None:
                if raw_sql.startswith(dollar_tag, i):
                    i += len(dollar_tag)
                    dollar_tag = None
                else:
                    i += 1
                continue
            if in_single_quote:
                if ch == "'" and i + 1 < n and raw_sql[i + 1] == "'":
                    i += 2
                    continue
                if ch == "'":
                    in_single_quote = False
                i += 1
                continue
            if raw_sql[i : i + 2] == "--":
                in_line_comment = True
                i += 2
                continue
            if raw_sql[i : i + 2] == "/*":
                in_block_comment = True
                i += 2
                continue
            if ch == "'":
                in_single_quote = True
                i += 1
                continue
            if ch == "$":
                m_dlr = re.match(r"^\$([a-zA-Z0-9_]*)\$", raw_sql[i:])
                if m_dlr:
                    dollar_tag = m_dlr.group(0)
                    i += len(dollar_tag)
                    continue
            if ch == "(":
                paren_depth += 1
            elif ch == ")":
                paren_depth -= 1
                if paren_depth < 0:
                    parse_errors.append(f"{mf.name}: Parêntese de fechamento excedente")
                    break
            i += 1
        if dollar_tag is not None:
            parse_errors.append(f"{mf.name}: Bloco dollar-quoted não fechado ({dollar_tag})")
        if in_single_quote:
            parse_errors.append(f"{mf.name}: String literal simples não fechada")
        if paren_depth != 0:
            parse_errors.append(f"{mf.name}: Parênteses desbalanceados (saldo={paren_depth})")

    all_42_pg_temp_last = all(
        f["search_path"].strip().endswith("pg_temp")
        and f["search_path"].strip().startswith("pg_catalog,")
        and ("auth" not in f["search_path"])
        for f in cum_summary["active_functions"]
    )
    s15_ok = len(mig_files_all) == 25 and len(parse_errors) == 0 and all_42_pg_temp_last
    record(
        "STATIC-15",
        s15_ok,
        f"Parsing Estrutural SQL (M02.8-F02 a M02.25): {len(mig_files_all)}/25 migrations parseadas sem erros ({len(parse_errors)} erros) e {len(cum_summary['active_functions'])}/{len(cum_summary['active_functions'])} funções com search_path iniciando em pg_catalog e terminando explicitamente em pg_temp (0 com schema auth supérfluo).",
    )

    # 16. STATIC-16 (M02.9): Auditoria Adversarial 000016, Cofre MAC (lineage_hmac_keys), Workflow GitHub Actions e Scripts CI
    wf_path = PROJECT_ROOT / ".github" / "workflows" / "homologation-and-build.yml"
    wf_txt = wf_path.read_text(encoding="utf-8") if wf_path.exists() else ""
    ci_sh_path = PROJECT_ROOT / "scripts" / "verify_ci_build.sh"
    ci_sh_txt = ci_sh_path.read_text(encoding="utf-8") if ci_sh_path.exists() else ""
    dev_sh_path = PROJECT_ROOT / "scripts" / "materialize_and_verify_build.sh"
    dev_sh_txt = dev_sh_path.read_text(encoding="utf-8") if dev_sh_path.exists() else ""

    m02_9_static_ok = (
        "20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql" in runner_sh
        and "CREATE TABLE IF NOT EXISTS internal_guard.lineage_hmac_keys" in m16_code
        and "CREATE OR REPLACE FUNCTION internal_guard.compute_lineage_mac(" in m16_code
        and "CREATE OR REPLACE FUNCTION internal_guard.verify_lineage_mac(" in m16_code
        and "CREATE OR REPLACE FUNCTION internal_guard.rotate_lineage_hmac_key(" in m16_code
        and "LINEAGE_BACKFILL_LGPD_DOWNGRADE_FORBIDDEN" in m16_code
        and "INVALID_EXECUTION_TOKEN_PARAMETERS" in m16_code
        and "idg-root-" in m16_code
        and "T9.23" in hom_sql
        and "permissions:\n  contents: read" in wf_txt
        and "verify-static-isolated-and-build:" in wf_txt
        and "postgresql-15-real-homologation:" in wf_txt
        and "needs: [ verify-static-isolated-and-build ]" in wf_txt
        and "materialize_and_verify_build.sh" not in wf_txt
        and "package-lock-only" not in wf_txt
        and "continue-on-error" not in wf_txt
        and "npm ci --no-audit --no-fund" in ci_sh_txt
        and "package-lock-only" not in ci_sh_txt
        and "ABORT_CI_FORBIDDEN" in dev_sh_txt
    )
    record(
        "STATIC-16",
        m02_9_static_ok,
        "Missão 02.9 (Seções 3 a 6): Migration 000016 (lineage_hmac_keys, compute/verify/rotate_lineage_mac, idg-root-, LINEAGE_BACKFILL_LGPD_DOWNGRADE_FORBIDDEN, INVALID_EXECUTION_TOKEN_PARAMETERS), workflow CI com permissions: contents: read, jobs separados e proibição de regenerar lockfile em CI comprovados.",
    )

    # 17. STATIC-17 (M02.10): Auditoria Independente 000016 -> 000017 (HMAC-SHA-256 RFC 2104/4231, CSPRNG gen_random_bytes(32), FORCE RLS, Ciclo de Vida de Chaves e search_path)
    ig_fns_no_public = all(
        "public" not in f["search_path"]
        for f in cum_summary["active_functions"]
        if f["schema"] == "internal_guard"
    )
    m02_10_static_ok = (
        "20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql" in runner_sh
        and "public.hmac(" in m17_code
        and "'sha256'::text" in m17_code
        and "public.gen_random_bytes(32)" in m17_code
        and "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7" in m17_code
        and "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843" in m17_code
        and "773ea91e36800e46854db8ebd09181a72959098b3ef8c122d9635514ced565fe" in m17_code
        and "82558a389a443c0ea4cc819899f2083a85f0faa3e578f8077a2e3ff46729665b" in m17_code
        and "CREATE OR REPLACE FUNCTION internal_guard.require_active_hmac_secret()" in m17_code
        and "CREATE OR REPLACE FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle()" in m17_code
        and "ALTER TABLE internal_guard.lineage_hmac_keys FORCE ROW LEVEL SECURITY;" in m17_code
        and "CREATE UNIQUE INDEX IF NOT EXISTS uq_lineage_hmac_keys_single_active" in m17_code
        and "REVOKE ALL ON ALL TABLES IN SCHEMA internal_guard FROM service_role;" in m17_code
        and "KEY_DELETE_ACTIVE_FORBIDDEN" in m17_code
        and "KEY_DELETE_DEPENDENT_RECORDS_EXIST" in m17_code
        and "KEY_MATERIAL_IMMUTABLE" in m17_code
        and "WEAK_SECRET_MATERIAL_REJECTED" in m17_code
        and "CSPRNG_FAILURE" in m17_code
        and "T9.24" in hom_sql
        and ig_fns_no_public
    )
    record(
        "STATIC-17",
        m02_10_static_ok,
        "Missão 02.10 (Seções 3 a 8): Migration 000017 com HMAC-SHA-256 (RFC 2104 / 4 vetores RFC 4231), CSPRNG gen_random_bytes(32) fail-closed, FORCE RLS, uq_lineage_hmac_keys_single_active, trigger anti-exclusão/anti-mutação de chaves, REVOKE direto de tabelas para service_role e 8/8 funções internal_guard sem schema public no search_path.",
    )

    # 18. STATIC-18 (M02.12 — Correções Cirúrgicas M02.11-F01 a M02.11-F05 na Migration 000018)
    m02_12_static_ok = (
        "20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql" in runner_sh
        and "ADD COLUMN IF NOT EXISTS hmac_key_version SMALLINT" in m18_code
        and "ADD COLUMN IF NOT EXISTS lineage_root_key_version SMALLINT" in m18_code
        and "ADD COLUMN IF NOT EXISTS lineage_idem_key_version SMALLINT" in m18_code
        and "ADD COLUMN IF NOT EXISTS lineage_scope_key_version SMALLINT" in m18_code
        and "CREATE CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit" in m18_code
        and "DEFERRABLE INITIALLY DEFERRED" in m18_code
        and "CREATE OR REPLACE FUNCTION internal_guard.assert_active_lineage_hmac_key_invariant()" in m18_code
        and "CREATE OR REPLACE FUNCTION internal_guard.manage_lineage_hmac_key_lifecycle(" in m18_code
        and "p_key_version SMALLINT DEFAULT NULL" in m18_code
        and "REVOKE ALL ON FUNCTION internal_guard.compute_lineage_mac(TEXT, TEXT, SMALLINT) FROM service_role;" in m18_code
        and "REVOKE ALL ON FUNCTION internal_guard.verify_lineage_mac(TEXT, TEXT, TEXT, SMALLINT) FROM service_role;" in m18_code
        and "REVOKE ALL ON FUNCTION internal_guard.require_active_hmac_secret() FROM service_role;" in m18_code
        and "REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM service_role;" in m18_code
        and "GRANT EXECUTE ON FUNCTION internal_guard.rotate_lineage_hmac_key(TEXT, BOOLEAN) TO service_role;" in m18_code
        and "GRANT EXECUTE ON FUNCTION internal_guard.manage_lineage_hmac_key_lifecycle(TEXT, SMALLINT, TEXT) TO service_role;" in m18_code
        and "GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role" not in m18_code
        and "skipped_unreconstructable_anon_rows" in m18_code
        and "T9.25" in hom_sql
    )
    record(
        "STATIC-18",
        m02_12_static_ok,
        "Missão 02.12 (M02.11-F01 a F05): Migration 000018 com compatibilidade legada restrita a registros existentes, 4 colunas de versão de chave HMAC por artefato, CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED, verificação O(1) por versão, derive_idempotency_lineage_key SECURITY DEFINER e revogação de oráculos em service_role comprovados.",
    )

    # 19. STATIC-19 (M02.16 — Datas Dinâmicas America/Sao_Paulo, Credencial Criptográfica lookup_token_hmac, Rate-Limiting Anti-Enumeração, Consulta Segura e Cancelamento pelo Turista)
    no_hardcoded_dates_in_app = (
        'min="2026-11-08"' not in app_txt
        and "bookingDate < '2026-11-08'" not in app_txt
        and "tourDateFilter >= '2026-11-08'" not in app_txt
        and "useState<string>('2026-11-20')" not in app_txt
        and "useState<string>('2026-11-28')" not in app_txt
    )
    m02_16_static_ok = (
        "20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql" in runner_sh
        and "CREATE OR REPLACE FUNCTION public.current_brazil_date()" in m19_code
        and "AT TIME ZONE 'America/Sao_Paulo'" in m19_code
        and "BOOKING_DATE_IN_PAST" in m19_code
        and "ADD COLUMN IF NOT EXISTS lookup_token_hmac VARCHAR(64)" in m19_code
        and "ADD COLUMN IF NOT EXISTS lookup_token_hmac_version SMALLINT" in m19_code
        and "CREATE TABLE IF NOT EXISTS internal_guard.booking_lookup_rate_limits" in m19_code
        and "ALTER TABLE internal_guard.booking_lookup_rate_limits FORCE ROW LEVEL SECURITY;" in m19_code
        and "CREATE OR REPLACE FUNCTION public.lookup_booking_by_tourist_token(" in m19_code
        and "CREATE OR REPLACE FUNCTION public.cancel_booking_by_tourist_token(" in m19_code
        and "LOOKUP_RATE_LIMIT_EXCEEDED" in m19_code
        and "INVALID_LOOKUP_CREDENTIALS" in m19_code
        and "TOURIST_TOKEN_CANCEL:CANCELADA" in m19_code
        and "export function getBrazilCurrentDateIso" in bs_txt
        and "export function generateClientBookingIdempotencyKey" in bs_txt
        and "export async function rpcLookupBookingByTouristToken" in bs_txt
        and "export async function rpcCancelBookingByTouristToken" in bs_txt
        and "export function loadTouristSavedReceipts" in bs_txt
        and "export function saveTouristReceipt" in bs_txt
        and "rpcLookupBookingByTouristToken(" in app_txt
        and "rpcCancelBookingByTouristToken(" in app_txt
        and "rpcGetTourAvailability(" in app_txt
        and no_hardcoded_dates_in_app
        and "T9.26" in hom_sql
    )
    record(
        "STATIC-19",
        m02_16_static_ok,
        "Missão 02.16 (Seções 3 a 11): Migration 000019 com current_brazil_date() (America/Sao_Paulo), lookup_token_hmac (HMAC-SHA-256 sem texto puro), rate limiting (booking_lookup_rate_limits), RPCs lookup_booking_by_tourist_token e cancel_booking_by_tourist_token, zero datas fixas no frontend e persistência sanitizada pós-refresh comprovados.",
    )

    # 20. STATIC-20 (M02.18 — Camada Operacional Rota Azul, Painel Administrativo, Gestão de Parceiros, Passeios, Embarcações, Reservas sem Tokens e Saídas/Ocupação com Autorização Fail-Closed)
    ops_path = PROJECT_ROOT / "src" / "lib" / "operationsService.ts"
    ops_txt = ops_path.read_text(encoding="utf-8") if ops_path.exists() else ""
    m02_18_static_ok = (
        ops_path.exists()
        and "export function authorizeOperationalAction(" in ops_txt
        and "AUTH_REQUIRED_MISSAO_02_19" in ops_txt
        and "CROSS_TENANT_ACCESS_DENIED" in ops_txt
        and "export function computeAdminDashboardMetrics(" in ops_txt
        and "export function listPartnersWithOperationalDetails(" in ops_txt
        and "export function createPartnerOperation(" in ops_txt
        and "export function updatePartnerOperation(" in ops_txt
        and "export function moderatePartnerRegistrationOperation(" in ops_txt
        and "export function createVesselOperation(" in ops_txt
        and "export function updateVesselOperation(" in ops_txt
        and "export function createTourOperation(" in ops_txt
        and "export function updateTourOperation(" in ops_txt
        and "export function deleteTourSafelyOperation(" in ops_txt
        and "export function queryOperationalBookings(" in ops_txt
        and "export function listOperationalDepartures(" in ops_txt
        and "export function computeCanonicalDepartureOccupancy(" in ops_txt
        and "computeAdminDashboardMetrics(" in app_txt
        and "deleteTourSafelyOperation(" in app_txt
        and "listOperationalDepartures(" in app_txt
    )
    record(
        "STATIC-20",
        m02_18_static_ok,
        "Missão 02.18 (Seções 3 a 9): Camada operacional src/lib/operationsService.ts (5 camadas), autorização fail-closed (AUTH_REQUIRED_MISSAO_02_19 / CROSS_TENANT_ACCESS_DENIED), exclusão segura de passeios, trava de capacidade de embarcações, consulta administrativa sanitizada e visão de saídas/ocupação comprovadas.",
    )

    # 21. STATIC-21 (M02.19 — Arquitetura de Autenticação, Sessões sem localStorage para Tokens, Proteção de Rotas, Onboarding de Parceiros e Migration 000020)
    auth_types_ok = (PROJECT_ROOT / "src" / "lib" / "authTypes.ts").exists()
    auth_val_ok = (PROJECT_ROOT / "src" / "lib" / "authValidation.ts").exists()
    auth_sess_txt = (PROJECT_ROOT / "src" / "lib" / "authSession.ts").read_text(encoding="utf-8")
    auth_guards_txt = (PROJECT_ROOT / "src" / "lib" / "authGuards.ts").read_text(encoding="utf-8")
    auth_svc_txt = (PROJECT_ROOT / "src" / "lib" / "authService.ts").read_text(encoding="utf-8")
    onb_svc_txt = (PROJECT_ROOT / "src" / "lib" / "partnerOnboardingService.ts").read_text(encoding="utf-8")

    m02_19_static_ok = (
        auth_types_ok
        and auth_val_ok
        and "localStorage.setItem" not in auth_sess_txt
        and "export function evaluateRouteProtection(" in auth_guards_txt
        and "export function buildVerifiedOperationalAuthContext(" in auth_guards_txt
        and "export async function loginWithEmailPassword(" in auth_svc_txt
        and "export async function logoutCurrentSession(" in auth_svc_txt
        and "export async function registerUserAccount(" in auth_svc_txt
        and "export async function requestPasswordRecovery(" in auth_svc_txt
        and "export async function resetPasswordWithRecoveryToken(" in auth_svc_txt
        and "export function submitPartnerOnboardingInStore(" in onb_svc_txt
        and "export function adminModeratePartnerOnboardingInStore(" in onb_svc_txt
        and "20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql" in runner_sh
        and "CREATE OR REPLACE FUNCTION public.get_authenticated_access_context()" in m20_code
        and "CREATE OR REPLACE FUNCTION public.submit_partner_onboarding_application(" in m20_code
        and "CREATE OR REPLACE FUNCTION public.admin_moderate_partner_onboarding(" in m20_code
        and "T9.27" in hom_sql
    )
    record(
        "STATIC-21",
        m02_19_static_ok,
        "Missão 02.19 (Seções 3 a 12): Migration 000020 (get_authenticated_access_context, submit_partner_onboarding_application, admin_moderate_partner_onboarding) e 6 módulos de autenticação/sessão/rotas/onboarding sem tokens em localStorage comprovados.",
    )

    # 22. STATIC-22 (M02.20 — Auditoria Consolidada 02.16..02.19, Migration 000021, Bloqueio em Tempo Real de Parceiro Suspenso, Revalidação Pós-F5 e Algoritmo Canônico de Disponibilidade)
    m02_20_static_ok = (
        "20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql" in runner_sh
        and "PARTNER_MODERATION_COLUMNS_FORBIDDEN" in m21_code
        and "NEW.onboarding_stage IS DISTINCT FROM OLD.onboarding_stage" in m21_code
        and "JOIN public.partners AS pt ON pt.id = pm.partner_id" in m21_code
        and "AND pt.status = 'APROVADO'::public.partner_status" in m21_code
        and "AND pt.onboarding_stage = 'APROVADO'" in m21_code
        and "ONBOARDING_USER" in m21_code
        and "export function revalidateSessionAgainstPartnerState(" in auth_sess_txt
        and "export async function restoreSessionAfterReload(" in auth_svc_txt
        and "revalidateSessionAgainstPartnerState(" in app_txt
        and "verifiedSession: verifiedSession.isAuthenticated ? verifiedSession : null" in app_txt
        and "T9.28" in hom_sql
    )
    record(
        "STATIC-22",
        m02_20_static_ok,
        "Missão 02.20 (M02.20-F01 a M02.20-F06): Migration 000021 (is_partner_member com verificação de aprovação ativa, blindagem das 5 colunas de onboarding em protect_catalog_moderation_columns, advisory locks no onboarding), revalidateSessionAgainstPartnerState, restoreSessionAfterReload pós-F5 e contexto operacional unificado comprovados.",
    )

    # 23. STATIC-23 (M02.21 — Pagamentos, Máquina de Estados Financeiros, Comissões em Centavos, Estornos Proporcionais, Razão Analítico e Conciliação na Migration 000022 e financialService.ts)
    fin_svc_path = PROJECT_ROOT / "src" / "lib" / "financialService.ts"
    fin_svc_txt = fin_svc_path.read_text(encoding="utf-8") if fin_svc_path.exists() else ""
    m02_21_static_ok = (
        fin_svc_path.exists()
        and "20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql" in runner_sh
        and "CREATE TABLE IF NOT EXISTS public.booking_payments" in m22_code
        and "CREATE TABLE IF NOT EXISTS public.booking_payment_history" in m22_code
        and "CREATE TABLE IF NOT EXISTS public.financial_ledger_entries" in m22_code
        and "ALTER TABLE public.booking_payments FORCE ROW LEVEL SECURITY;" in m22_code
        and "ALTER TABLE public.booking_payment_history FORCE ROW LEVEL SECURITY;" in m22_code
        and "ALTER TABLE public.financial_ledger_entries FORCE ROW LEVEL SECURITY;" in m22_code
        and "CREATE OR REPLACE FUNCTION public.create_or_initiate_booking_payment(" in m22_code
        and "CREATE OR REPLACE FUNCTION public.confirm_or_fail_booking_payment(" in m22_code
        and "CREATE OR REPLACE FUNCTION public.process_booking_refund(" in m22_code
        and "CREATE OR REPLACE FUNCTION public.get_financial_reconciliation_report(" in m22_code
        and "export function calculateServerCommissionAndNet(" in fin_svc_txt
        and "export function calculateProportionalRefundSplit(" in fin_svc_txt
        and "export function initiateBookingPayment(" in fin_svc_txt
        and "export function transitionBookingPaymentStatus(" in fin_svc_txt
        and "export function processBookingRefund(" in fin_svc_txt
        and "export function handleBookingCancellationFinancialSync(" in fin_svc_txt
        and "export function runFinancialReconciliation(" in fin_svc_txt
        and "export function computeAdminFinancialSummary(" in fin_svc_txt
        and "export function computePartnerFinancialSummary(" in fin_svc_txt
        and "T9.29" in hom_sql
    )
    record(
        "STATIC-23",
        m02_21_static_ok,
        "Missão 02.21 (Seções 4 a 11): Migration 000022 (booking_payments, booking_payment_history, financial_ledger_entries sob FORCE RLS, 8 novas funções SQL financeiras) e src/lib/financialService.ts (aritmética em centavos HALF_UP, máquina de estados, idempotência, estorno proporcional e conciliação) comprovados.",
    )

    # 24. STATIC-24 (M02.22 — Correção Adversarial F01..F09, Migration 000023, Estorno em 2 Etapas, Integração Frontend sem void e Sincronia package-lock.json)
    m23_path = PROJECT_ROOT / "supabase" / "migrations" / "20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql"
    m23_code = m23_path.read_text(encoding="utf-8") if m23_path.exists() else ""
    pkg_json = json.loads((PROJECT_ROOT / "package.json").read_text(encoding="utf-8"))
    pkg_lock = json.loads((PROJECT_ROOT / "package-lock.json").read_text(encoding="utf-8"))
    root_lock_dev = pkg_lock.get("packages", {}).get("", {}).get("devDependencies", {})
    missing_lock_deps = [
        dep for dep in pkg_json.get("devDependencies", {})
        if dep not in root_lock_dev or f"node_modules/{dep}" not in pkg_lock.get("packages", {})
    ]

    m02_22_static_ok = (
        m23_path.exists()
        and "20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql" in runner_sh
        and "PARTNER_PAYMENT_CONFIRM_FORBIDDEN" in m23_code
        and "ADMIN_CONFIRMATION_REASON_REQUIRED" in m23_code
        and "CREATE OR REPLACE FUNCTION public.request_booking_refund(" in m23_code
        and "PARTNER_REFUND_CONFIRM_FORBIDDEN" in m23_code
        and "FINANCIAL_IDEMPOTENCY_CONFLICT" in m23_code
        and "LEDGER_SETTLEMENT_REQUIRES_CONFIRMED_PAYMENT" in m23_code
        and "PAYMENT_HISTORY_MISMATCH" in m23_code
        and "LEDGER_ENTRIES_SUM_MISMATCH" in m23_code
        and "OWNER TO postgres" in m23_code
        and "financial_payment_sanitized" in m23_code
        and "export function requestBookingRefund(" in fin_svc_txt
        and "export async function rpcRequestBookingRefund(" in fin_svc_txt
        and "export function roundHalfUpBigIntDivision(" in fin_svc_txt
        and "export function sanitizeFinancialRecordsForLgpd(" in fin_svc_txt
        and "export function hydrateFinancialStoreFromServerRows(" in fin_svc_txt
        and "void setFinancialStore" not in app_txt
        and "void initiateBookingPayment" not in app_txt
        and len(missing_lock_deps) == 0
        and inv_data["cumulative_active_after_000023"]["total_active_functions"] == 64
        and "T9.30" in hom_sql
    )
    record(
        "STATIC-24",
        m02_22_static_ok,
        "Missão 02.22 (F01 a F09): Migration 000023, estorno em 2 etapas (request_booking_refund / process_booking_refund), bloqueio de parceiro em PAGO/ESTORNADO, conciliação das 5 entidades, integração real em App.tsx sem void e package-lock.json sincronizado comprovados.",
    )

    # 25. STATIC-25 (M02.23 — Auditoria Independente D01..D08, Paridade database.types.ts x Migrations, Conciliação 9 Anomalias e Persistência RPC Completa no Frontend)
    db_types_txt = (PROJECT_ROOT / "src" / "lib" / ".." / "types" / "database.types.ts").read_text(encoding="utf-8")
    bk_svc_txt = (PROJECT_ROOT / "src" / "lib" / "bookingService.ts").read_text(encoding="utf-8")
    m02_23_static_ok = (
        "IF p_refund_amount IS NULL THEN" in m23_code
        and "REFUND_EXCEEDS_REQUESTED_AMOUNT" in m23_code
        and "ORPHAN_PAYMENT_WITHOUT_BOOKING" in m23_code
        and "ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT" in m23_code
        and "REFUND_WITHOUT_REQUEST" in m23_code
        and "PENDING_REFUND_IMPROPERLY_FINALIZED" in m23_code
        and "ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT" in fin_svc_txt
        and "REFUND_WITHOUT_REQUEST" in fin_svc_txt
        and "PENDING_REFUND_IMPROPERLY_FINALIZED" in fin_svc_txt
        and "REFUND_EXCEEDS_REQUESTED_AMOUNT" in fin_svc_txt
        and "LEDGER_ALREADY_PAID" in fin_svc_txt
        and "export interface BookingPaymentRow" in db_types_txt
        and "export interface GetFinancialReconciliationReportResponse" in db_types_txt
        and "financial_payment_sanitized?: boolean;" in db_types_txt
        and "rpcSettleCommissionLedger(" in app_txt
        and ".catch(() => undefined)" not in app_txt
        and "supabase.from('commission_ledger')" in bk_svc_txt
        and "T9.31" in hom_sql
    )
    record(
        "STATIC-25",
        m02_23_static_ok,
        "Missão 02.23 (D01 a D08): Correção de p_refund_amount NULL em SQL, hidratação real paidGrossAmount pós-F5, invariante gross_delta = commission_delta + net_partner_delta, conciliação das 9 categorias da Seção 6, bloqueio LEDGER_ALREADY_PAID, persistência RPC em App.tsx sem catch silencioso e paridade database.types.ts comprovados.",
    )

    # 26. STATIC-26 (M02.24 — Auditoria Adversarial Final D09..D12, Migration 000024, Preservação Intacta 000001..000023 e Simetria SQL/TS)
    m24_path = PROJECT_ROOT / "supabase" / "migrations" / "20261130000024_missao02_24_adversarial_closure_and_hardening.sql"
    m24_code = m24_path.read_text(encoding="utf-8") if m24_path.exists() else ""
    m02_24_static_ok = (
        m24_path.exists()
        and "20261130000024_missao02_24_adversarial_closure_and_hardening.sql" in runner_sh
        and "input_refund_amount" in m24_code
        and "auto_admin_request" in m24_code
        and "REFUND_FAILED_REVERT" in m24_code
        and "inputRefundAmountCents" in fin_svc_txt
        and "implicitAdminDirectRefund" in fin_svc_txt
        and "targetStatus: 'PROCESSANDO' | 'PAGO' | 'FALHOU' | 'CANCELADO' | 'ESTORNO_PARCIAL';" in fin_svc_txt
        and "targetStatus: revertTarget as 'PAGO'" not in app_txt
        and inv_data.get("cumulative_active_after_000024", {}).get("total_active_functions") == 64
        and "T9.32" in hom_sql
    )
    record(
        "STATIC-26",
        m02_24_static_ok,
        "Missão 02.24 (D09 a D12): Migration corretiva incremental 000024 (preservando 000001..000023 intactas), replay idempotente com p_refund_amount NULL antes do cálculo de saldo pós-estorno (D09), trilha implícita de solicitação em estorno direto do Admin (D10) e simetria PAGO/ESTORNO_PARCIAL na reversão de falha de estorno (D12) comprovados.",
    )

    # 27. STATIC-27 (M02.25 — Fechamento Cirúrgico D13..D16, Migration 000025, Validação Calendário/Monotonicidade de Migrations, Preservação 000001..000024 e Sanitização BASH_ENV)
    from datetime import datetime
    import hashlib
    m25_path = PROJECT_ROOT / "supabase" / "migrations" / "20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql"
    m25_code = m25_path.read_text(encoding="utf-8") if m25_path.exists() else ""

    mig_files_sorted = sorted((PROJECT_ROOT / "supabase" / "migrations").glob("*.sql"))
    mig_calendar_and_monotonic_ok = len(mig_files_sorted) == 25
    prev_ver = ""
    for idx_m, mf in enumerate(mig_files_sorted, 1):
        m_prefix = mf.name.split("_")[0]
        if len(m_prefix) != 14 or not m_prefix.isdigit():
            mig_calendar_and_monotonic_ok = False
            break
        try:
            datetime.strptime(m_prefix[:8], "%Y%m%d")
        except ValueError:
            mig_calendar_and_monotonic_ok = False
            break
        if m_prefix[8:] != f"{idx_m:06d}" or (prev_ver and not (prev_ver < m_prefix)):
            mig_calendar_and_monotonic_ok = False
            break
        prev_ver = m_prefix

    expected_m24_sha = "64faad69d01430a9de87cf1a440a8015fedbcbf97073ac3d41b77e1927a5a843"
    actual_m24_sha = hashlib.sha256(m24_path.read_bytes()).hexdigest() if m24_path.exists() else ""

    m02_25_static_ok = (
        m25_path.exists()
        and mig_calendar_and_monotonic_ok
        and actual_m24_sha == expected_m24_sha
        and "20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql" in runner_sh
        and "unset BASH_ENV ENV" in runner_sh
        and "REFUND_FULL_REVERT" in m25_code
        and "LEDGER_REVERSAL_REQUIRES_FULL_REFUND" in m25_code
        and "ELSIF v_is_full AND v_booking.status = 'PASSEIO_REALIZADO'" in m25_code
        and "v_item.ledger_status IS DISTINCT FROM 'REVERTIDA'" in m25_code
        and "bk.ledgerStatus !== 'REVERTIDA'" in fin_svc_txt
        and "payment.paymentStatus !== 'ESTORNADO'" in fin_svc_txt
        and inv_data.get("cumulative_active_after_000025", {}).get("total_active_functions") == 64
        and "T9.33" in hom_sql
    )
    record(
        "STATIC-27",
        m02_25_static_ok,
        "Missão 02.25 (D13 a D16): Migration 000025 (20261201000025 com virada calendário válida pós-30/11/2026 e preservação byte a byte de 000001..000024), reversão de comissão em estorno integral pós-PASSEIO_REALIZADO/PAGA (D13), sanitização BASH_ENV no runner (D14) e guarda calendário/monotônica nas 25 migrations (D15) comprovados.",
    )

    return 0 if all(c[1] for c in checks) else 1


if __name__ == "__main__":
    sys.exit(verify_all())
