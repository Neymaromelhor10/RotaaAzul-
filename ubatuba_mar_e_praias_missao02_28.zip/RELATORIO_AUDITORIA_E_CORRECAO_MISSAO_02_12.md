# RELATÓRIO TÉCNICO DE AUDITORIA E CORREÇÃO CIRÚRGICA — ARGON 4 — MISSÃO 02.12

- **Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
- **Missão:** 02.12 — Correção Cirúrgica dos Achados Forenses `M02.11-F01` a `M02.11-F05`, Migration Incremental `000018` e Testes de Regressão
- **Base Obrigatória Recebida:** `ubatuba_mar_e_praias_missao02_10_corrigido.zip`
- **Migration Incremental Criada:** `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`

---

## ETAPA ZERO — MATRIZ DE INSPEÇÃO E PLANEJAMENTO PRÉ-IMPLEMENTAÇÃO

| Achado | Causa confirmada | Arquivos afetados | Correção planejada | Risco de regressão |
| :--- | :--- | :--- | :--- | :--- |
| **M02.11-F01** (`P1 — Alto`) | A migration `000017` substituiu o cálculo de `<root24>` (`LINEAGE_ROOT_V1`) e `<gen24>` (`LINEAGE_GEN_V1`) por `HMAC-SHA-256` sem preservar resolução de leitura para registros históricos (`000013`–`000016`) que persistiram `left(md5(k1), 24)` e `left(md5(k1 \|\| ':gen:' \|\| generation), 24)`, além de `backfill_and_verify_booking_lineage` fabricar `lgpd-lin-` sobre placeholders anonimizados em registros `000014` sem material suficiente. | `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`, `supabase/tests/run_isolated_test_suite.py`, `supabase/tests/homologacao_postgresql_real.sql` | 1) Implementar compatibilidade de leitura restrita a registros históricos efetivamente existentes em `public.bookings` (`lineage_root_key_version IS NULL` / `lineage_idem_key_version IS NULL` / `lineage_scope_key_version IS NULL`) e vinculada ao titular, passeio e data; 2) Manter `internal_guard.verify_lineage_mac()` estritamente chaveado (jamais aceitando MD5 sem segredo como MAC autônomo); 3) Garantir que 100% das novas gravações utilizem exclusivamente `HMAC-SHA-256`; 4) Atualizar `backfill_and_verify_booking_lineage()` para migrar registros legados com material suficiente para `HMAC-SHA-256` e preservar intactos registros `000014` totalmente anonimizados sem material de reconstrução. | Baixo — a resolução legada só alcança registros existentes do mesmo titular/passeio/data e todas as novas gravações usam exclusivamente `HMAC-SHA-256`. |
| **M02.11-F02** (`P1 — Alto`) | 1) `enforce_lineage_hmac_key_lifecycle()` verificava `EXISTS (SELECT 1 FROM public.bookings ...)` globalmente sem filtrar por `OLD.key_version`, bloqueando a aposentadoria de versões antigas sem dependentes; 2) Ausência de rastreamento explícito de versão por artefato (`root`, `idem`, `scope`) em `public.bookings`; 3) Ausência de `CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED` impedindo `UPDATE lineage_hmac_keys SET is_current = false` isolado terminar a transação com zero chaves ativas; 4) Ausência de RPC administrativa controlada para aposentadoria e restauração de chave histórica a partir de backup. | `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`, `supabase/tests/function_inventory.json`, `supabase/tests/run_isolated_test_suite.py`, `supabase/tests/homologacao_postgresql_real.sql` | 1) Adicionar `hmac_key_version`, `lineage_root_key_version`, `lineage_idem_key_version` e `lineage_scope_key_version` em `public.bookings` e protegê-las em `enforce_booking_invariants_and_transitions()`; 2) Atualizar `enforce_lineage_hmac_key_lifecycle()` para verificar dependências reais por `OLD.key_version`; 3) Criar `CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit DEFERRABLE INITIALLY DEFERRED` (`assert_active_lineage_hmac_key_invariant()`) e constraint `CHECK (NOT is_current OR is_verify_enabled)`; 4) Criar `internal_guard.manage_lineage_hmac_key_lifecycle()` para aposentadoria (`RETIRE`), reativação (`ENABLE_VERIFY`), restauração de backup (`RESTORE`) e expurgo seguro (`PURGE_RETIRED`). | Baixo — o trigger de constraint é `DEFERRABLE INITIALLY DEFERRED`, permitindo instalação inicial e rotação em múltiplos comandos na mesma transação enquanto bloqueia qualquer commit sem chave ativa. |
| **M02.11-F03** (`P2 — Médio`) | 1) A validação de segredos manuais em `require_active_hmac_secret()` e `rotate_lineage_hmac_key()` checava apenas `COUNT(DISTINCT ch) >= 8` e `^([0-9a-f])\1{15,}`, aceitando padrões periódicos (`repeat('01234567', 8)`) e sufixos repetitivos (`'0123456789abcdef' \|\| repeat('0', 48)`); 2) O Bloco 8 concedia `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role`, expondo `compute_lineage_mac`, `verify_lineage_mac`, `require_active_hmac_secret`, `issue_token`, `consume_token` e `cleanup_tokens` diretamente a `service_role`. | `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`, `supabase/tests/function_inventory.json`, `supabase/tests/run_isolated_test_suite.py`, `supabase/tests/homologacao_postgresql_real.sql` | 1) Endurecer o filtro de segredos manuais e a constraint `chk_lineage_hmac_keys_hex_format` contra repetições de 8+ caracteres em qualquer posição (`([0-9a-f])\1{7,}`), periodicidade (`^([0-9a-f]{1,32})\1+$`), sequências previsíveis e baixa diversidade por janela de 16 caracteres, documentando a limitação teórica de filtros sintáticos; 2) Remover `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role`, revogando `EXECUTE` de todas as primitivas internas para `service_role` e concedendo `EXECUTE` em `internal_guard` exclusivamente para `rotate_lineage_hmac_key` e `manage_lineage_hmac_key_lifecycle`. | Baixo — todos os RPCs públicos e triggers que consomem `internal_guard` são `SECURITY DEFINER` pertencentes a `postgres`. |
| **M02.11-F04** (`P2 — Médio`) | `internal_guard.verify_lineage_mac()` percorria todas as versões habilitadas em `O(K)` mesmo quando a versão do artefato era conhecida, e a documentação não distinguia a ausência de curto-circuito lógico no laço XOR PL/pgSQL da ausência de garantia constant-time em nível de CPU/interpretador. | `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`, `supabase/tests/function_inventory.json`, `supabase/tests/run_isolated_test_suite.py` | 1) Atualizar `internal_guard.verify_lineage_mac(p_purpose, p_payload, p_expected_mac, p_key_version DEFAULT NULL)` para verificação direta `O(1)` quando `p_key_version IS NOT NULL`, mantendo varredura multi-versão apenas quando `p_key_version IS NULL` (registros históricos sem versão explícita); 2) Documentar com precisão técnica o alcance do laço XOR em PL/pgSQL. | Nenhum — `p_key_version DEFAULT NULL` preserva 100% de compatibilidade com chamadas de 3 argumentos e acelera chamadas de 4 argumentos. |
| **M02.11-F05** (`P2 — Médio`) | 1) `public.derive_idempotency_lineage_key(TEXT, INTEGER)` era `SECURITY INVOKER` e dependia de `internal_guard.compute_lineage_mac`, o que quebraria chamadas diretas por `service_role` após revogar `EXECUTE` em `compute_lineage_mac`; 2) O relatório interno da `02.10` registrava o hash do container ZIP anterior ao reempacotamento PKZIP 2.0. | `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`, `supabase/tests/function_inventory.json`, `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_12.md` | 1) Converter `public.derive_idempotency_lineage_key` para `SECURITY DEFINER` (`OWNER TO postgres`, `SET search_path = pg_catalog, public, internal_guard, pg_temp`), com `REVOKE EXECUTE` de `PUBLIC, anon, authenticated`, `GRANT EXECUTE` apenas a `service_role` e guarda de contexto de 4 fatores; 2) Calcular e registrar o SHA-256 definitivo do ZIP final somente após sua geração definitiva. | Nenhum — `anon` e `authenticated` permanecem bloqueados e `create_booking_request` continua operando sem alteração de contrato. |

---

## SEÇÃO A — PROVENIÊNCIA E INTEGRIDADE DAS MIGRATIONS (000001 A 000018)

### A.1. Identificação do Pacote-Base e do Pacote Final

- **Arquivo-Base Recebido (Missão 02.10):** `ubatuba_mar_e_praias_missao02_10_corrigido.zip`
  - **Tamanho:** `1.432.805 bytes`
  - **Quantidade de Arquivos:** `68 arquivos`
  - **Integridade (`zipfile.testzip()`):** `None` (0 erros de CRC/estrutura)
  - **SHA-256 do ZIP-Base:** `ef0af1840de3096c0883c20d278aeabb93cc5619f8d4df072ec6b8a2abd7da8b`
- **Pacote Final Entregue (Missão 02.12):** `ubatuba_mar_e_praias_missao02_12_corrigido.zip`
  - **Quantidade Final de Arquivos:** `70 arquivos` (`68` originais da base `02.10` + migration incremental `000018` + `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_12.md`)
  - **Formato de Empacotamento:** PKZIP 2.0 Universal (`ZIP_DEFLATED`, `create_system=0`, `extract_version=20`)
  - **Nota de Proveniência (Seção 9 Parte B):** Como este arquivo `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_12.md` está incluído dentro do próprio container `ubatuba_mar_e_praias_missao02_12_corrigido.zip`, todos os tamanhos e hashes SHA-256 dos arquivos internos (incluindo as 18 migrations `000001` a `000018` e os 5 arquivos de teste/inventário atualizados) estão cravados abaixo, e o SHA-256 exato do container `ubatuba_mar_e_praias_missao02_12_corrigido.zip` fechado é calculado após o fechamento do arquivo ZIP e registrado na seção de fechamento da cópia externa/entrega.

### A.2. Tabela de Integridade Byte a Byte das Migrations `000001` a `000018`

| # | Arquivo de Migration (`supabase/migrations/`) | Tamanho (Bytes) | SHA-256 | Status |
| :--- | :--- | :---: | :--- | :---: |
| `000001` | `20261108000001_initial_schema.sql` | `17.194` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **INTACTA (BYTE A BYTE)** |
| `000002` | `20261108000002_rls_and_rpcs.sql` | `3.875` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **INTACTA (BYTE A BYTE)** |
| `000003` | `20261110000003_missao01_audit_fixes_and_rpcs.sql` | `120.783` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **INTACTA (BYTE A BYTE)** |
| `000004` | `20261110000004_missao01_official_catalog_seed.sql` | `14.727` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **INTACTA (BYTE A BYTE)** |
| `000005` | `20261111000005_missao01_4_forensic_hardening.sql` | `58.943` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **INTACTA (BYTE A BYTE)** |
| `000006` | `20261112000006_missao01_6_forensic_fixes.sql` | `54.113` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **INTACTA (BYTE A BYTE)** |
| `000007` | `20261113000007_missao01_8_controlled_fixes.sql` | `64.902` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **INTACTA (BYTE A BYTE)** |
| `000008` | `20261114000008_missao01_9_controlled_fixes.sql` | `36.333` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | **INTACTA (BYTE A BYTE)** |
| `000009` | `20261115000009_missao02_1_residual_fixes.sql` | `49.149` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | **INTACTA (BYTE A BYTE)** |
| `000010` | `20261116000010_missao02_3_surgical_fixes.sql` | `106.563` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | **INTACTA (BYTE A BYTE)** |
| `000011` | `20261117000011_missao02_4_adversarial_fixes.sql` | `113.335` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | **INTACTA (BYTE A BYTE)** |
| `000012` | `20261118000012_missao02_5_integrity_closure.sql` | `62.476` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | **INTACTA (BYTE A BYTE)** |
| `000013` | `20261119000013_missao02_6_post_cancel_idempotency.sql` | `25.201` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | **INTACTA (BYTE A BYTE)** |
| `000014` | `20261120000014_missao02_7_lineage_persistence_and_hardening.sql` | `54.907` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | **INTACTA (BYTE A BYTE)** |
| `000015` | `20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql` | `66.466` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | **INTACTA (BYTE A BYTE)** |
| `000016` | `20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql` | `88.970` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | **INTACTA (BYTE A BYTE)** |
| `000017` | `20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql` | `87.957` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | **INTACTA (BYTE A BYTE)** |
| **`000018`** | **`20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`** | **`140.451`** | **`b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda`** | **CRIADA (MISSÃO 02.12)** |

---

## SEÇÃO B — INVENTÁRIO DE ARQUIVOS CRIADOS E ALTERADOS E DESCRIÇÃO DA MIGRATION 000018

### B.1. Arquivos Criados e Alterados (Antes vs. Depois)

| Caminho do Arquivo | Operação | Tamanho Antes | SHA-256 Antes | Tamanho Depois | SHA-256 Depois | Justificativa Técnica |
| :--- | :---: | :---: | :--- | :---: | :--- | :--- |
| `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql` | **CRIADO** | — | — | `140.451 B` | `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda` | Migration incremental `000018` implementando as correções cirúrgicas de `M02.11-F01` a `M02.11-F05`. |
| `supabase/tests/function_inventory.json` | **ALTERADO** | `330.843 B` | `d481de50a46638d0fdfa34cfaf1611cfabc10c0da2a1342b3d14c09681a99ea4` | `346.260 B` | `c70f1d02be85ecb1758666bdf2a052bee1879b9bdc7a0ba194ef7ccc5735baa9` | Adiciona `cumulative_active_after_000018` (`49` funções ativas: `40 SECURITY DEFINER` + `9 SECURITY INVOKER`) e matriz explícita de grants/revokes de `service_role` em `internal_guard`. |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **ALTERADO** | `52.317 B` | `23022cfbfa57f941136520385c5e699273b20265ec11fcd8f6cd1a0e96e85d74` | `55.326 B` | `8a342883242d1655d7f7f05c691522792db3f1c51c179ea4594386188f0a90e2` | Inclui a migration `000018`, as 4 novas colunas de versão em `public.bookings`, o inventário de 49 funções e a verificação `STATIC-18` (18/18 checks). |
| `supabase/tests/run_isolated_test_suite.py` | **ALTERADO** | `273.692 B` | `988d44cb69c7677a0021197a12c5c45ac6a9ec919f8244e8f25bf8424f430ee5` | `322.780 B` | `a2ba86b8862758264f40a9863653e70ec6311cffda9be38fa13b389b52677e71` | Atualiza o motor isolado com os contratos da `000018` e adiciona as suítes `#34`, `#35` e `#36` cobrindo todos os cenários obrigatórios das Seções 5 a 9 (`38/38` testes). |
| `supabase/tests/homologacao_postgresql_real.sql` | **ALTERADO** | `120.191 B` | `81406d80f038d92a893126c7a6eff5a7b94ee3292f8cb70244d0f3da8574f803` | `121.978 B` | `f920a5f7ef4792c1a5430e61f52b11390fb3ee2cd2a318bf57c501189e9349d0` | Adiciona o bloco `T9.25` (`T9.25a` a `T9.25d`) para homologação PostgreSQL 15+ real das correções da Missão 02.12. |
| `supabase/tests/run_postgresql_homologation.sh` | **ALTERADO** | `28.692 B` | `536054f7d0ac571d8b3359d4eda72c18bc1dca09e955a2f5b4b2019e79abc6a9` | `28.951 B` | `ce8f549294d7fce2e5870279de2f09572b7000a5dffb22943cec68f6547ae423` | Inclui `20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql` na aplicação do zero (`PG-01`) e na reaplicação transacional (`PG-02`). |
| `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_12.md` | **CRIADO** | — | — | Registrado no fechamento | Registrado no fechamento | Relatório técnico forense completo da Missão 02.12. |

### B.2. Descrição Completa da Migration `000018`

A migration `supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql` é estruturada em **10 blocos transacionais (`BEGIN ... COMMIT`)**:
1. **Bloco 1 (Auto-Teste Criptográfico):** Verifica a extensão `pgcrypto`, executa os 4 vetores oficiais da IETF RFC 4231 para `HMAC-SHA-256` e valida `public.gen_random_bytes(32)` (256 bits).
2. **Bloco 2 (Rastreamento de Versão por Artefato em `public.bookings`):** Adiciona as 4 colunas `hmac_key_version`, `lineage_root_key_version`, `lineage_idem_key_version` e `lineage_scope_key_version` (`SMALLINT`, `CHECK 1..999 OR NULL`) e o índice `idx_bookings_hmac_key_versions`.
3. **Bloco 3 (Ciclo de Vida e Invariante Transacional em `internal_guard.lineage_hmac_keys`):**
   - Atualiza `chk_lineage_hmac_keys_hex_format` e adiciona `chk_lineage_hmac_keys_current_must_verify` (`CHECK (NOT is_current OR is_verify_enabled)`).
   - Atualiza `internal_guard.enforce_lineage_hmac_key_lifecycle()` para verificar dependências reais em `public.bookings` filtradas por `OLD.key_version` nos 4 campos de versão (com fallback fail-closed para linhas ainda sem versão).
   - Cria `internal_guard.assert_active_lineage_hmac_key_invariant()` e o `CREATE CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit AFTER INSERT OR UPDATE OR DELETE ON internal_guard.lineage_hmac_keys DEFERRABLE INITIALLY DEFERRED`, garantindo que ao final de qualquer transação válida exista exatamente 1 chave ativa e habilitada (`is_current = true AND is_verify_enabled = true`).
4. **Bloco 4 (Primitivas Criptográficas e Gestão de Chaves em `internal_guard`):**
   - Atualiza `require_active_hmac_secret()` e `rotate_lineage_hmac_key()` com filtro estrutural endurecido contra segredos periódicos, repetições consecutivas (`([0-9a-f])\1{7,}`), sequências previsíveis e baixa diversidade por janela de 16 caracteres.
   - Atualiza `verify_lineage_mac(p_purpose, p_payload, p_expected_mac, p_key_version DEFAULT NULL)` para resolução direta `O(1)` quando `p_key_version IS NOT NULL`, mantendo varredura multi-versão apenas quando `p_key_version IS NULL`.
   - Cria `internal_guard.manage_lineage_hmac_key_lifecycle(p_action, p_key_version, p_secret_material)` suportando `'RETIRE'`, `'DISABLE_VERIFY'`, `'ENABLE_VERIFY'`, `'RESTORE'` e `'PURGE_RETIRED'`.
5. **Bloco 5 (`public.derive_idempotency_lineage_key` como `SECURITY DEFINER`):** Converte a função para `SECURITY DEFINER` (`OWNER TO postgres`, `SET search_path = pg_catalog, public, internal_guard, pg_temp`) com validação de contexto de 4 fatores, impedindo chamadas diretas por `anon`/`authenticated` e mantendo funcionamento para `service_role` e fluxos internos sem expor `compute_lineage_mac`.
6. **Bloco 6 (`public.enforce_booking_invariants_and_transitions`):** Protege a imutabilidade das 4 colunas de versão de chave HMAC fora dos fluxos autorizados por token (`LINEAGE_BACKFILL` e `LGPD_ANONYMIZE`).
7. **Bloco 7 (`public.backfill_and_verify_booking_lineage`):** Migra registros históricos (`000013`–`000016`) para `HMAC-SHA-256` quando há material suficiente para validar e reconstruir a linhagem, popula as 4 colunas de versão de chave e preserva sem associação inventada registros `000014` completamente anonimizados sem material de reconstrução (`skipped_unreconstructable_anon_rows`).
8. **Bloco 8 (`public.admin_anonymize_customer_pii`):** Grava novos identificadores de anonimização exclusivamente com `HMAC-SHA-256`, preserva `<root24>` e `lineage_root_key_version` em reservas derivadas `idg-...` para não quebrar clientes que detêm a chave derivada após rotações de chave, e preenche as 4 colunas de versão.
9. **Bloco 9 (`public.create_booking_request`):** Resolve em modo somente-leitura registros históricos (`000013`–`000016`) existentes em `public.bookings` vinculados ao mesmo titular/passeio/data, utiliza verificação `O(1)` por versão nos artefatos versionados e grava todas as novas reservas exclusivamente com `HMAC-SHA-256`.
10. **Bloco 10 (Consolidação de Privilégios Mínimos e Owners):** Define `OWNER TO postgres` em todas as funções `SECURITY DEFINER`, remove `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role`, revoga `EXECUTE` de todas as primitivas internas de `internal_guard` para `PUBLIC, anon, authenticated, service_role` e concede `EXECUTE` a `service_role` em `internal_guard` exclusivamente para `rotate_lineage_hmac_key` e `manage_lineage_hmac_key_lifecycle`.

---

## SEÇÃO C — MATRIZ DE ACHADOS E CORREÇÕES (M02.11-F01 A M02.11-F05)

| Achado | Correção Implementada | Arquivos | Testes Executados | Resultado | Pendência |
| :--- | :--- | :--- | :--- | :---: | :--- |
| **M02.11-F01** (`P1 — Alto`) | Resolução legada restrita a registros históricos existentes (`000013`–`000016`) em `create_booking_request`, migração autenticada para `HMAC-SHA-256` em `backfill_and_verify_booking_lineage`, preservação segura de registros `000014` sem material (`skipped_unreconstructable_anon_rows`) e gravação 100% `HMAC-SHA-256` em novas operações. | `000018`, `run_isolated_test_suite.py`, `homologacao_postgresql_real.sql` | `M02.12-F01-LEGACY-LINEAGE-COMPATIBILITY-12` (12 cenários obrigatórios da Seção 5) + `STATIC-18` | **CORRIGIDO E COMPROVADO** | Homologação em PostgreSQL 15+ real (`T9.25`). |
| **M02.11-F02** (`P1 — Alto`) | 4 colunas de versão por artefato (`hmac_key_version`, `lineage_root_key_version`, `lineage_idem_key_version`, `lineage_scope_key_version`), trigger de dependência granular por `OLD.key_version`, `CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit DEFERRABLE INITIALLY DEFERRED` e RPC `manage_lineage_hmac_key_lifecycle` (`RETIRE`, `ENABLE_VERIFY`, `RESTORE`, `PURGE_RETIRED`). | `000018`, `function_inventory.json`, `run_isolated_test_suite.py`, `homologacao_postgresql_real.sql` | `M02.12-F02-KEY-LIFECYCLE-RECOVERY-12` (12 cenários obrigatórios da Seção 6) + `STATIC-18` | **CORRIGIDO E COMPROVADO** | Disparo real do `CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED` em PostgreSQL 15+. |
| **M02.11-F03** (`P2 — Médio`) | Filtro estrutural endurecido contra segredos periódicos/sequenciais/repetitivos (`repeat('01234567', 8)`, `'0123456789abcdef' \|\| repeat('0', 48)`) + remoção de `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role` e revogação de oráculos/tokens internos para `service_role`. | `000018`, `function_inventory.json`, `run_isolated_test_suite.py`, `homologacao_postgresql_real.sql` | `M02.12-F03-F04-F05-SECRETS-PRIVILEGES-O1-VERIFY` (Partes A e B) + `STATIC-18` | **CORRIGIDO E COMPROVADO** | Verificação de catálogo `has_function_privilege` em PostgreSQL 15+ real (`T9.25`). |
| **M02.11-F04** (`P2 — Médio`) | `internal_guard.verify_lineage_mac(..., p_key_version DEFAULT NULL)` com verificação direta `O(1)` quando `p_key_version IS NOT NULL`, fallback multi-versão para `p_key_version IS NULL` e documentação técnica precisa do laço XOR PL/pgSQL. | `000018`, `function_inventory.json`, `run_isolated_test_suite.py` | `M02.12-F03-F04-F05-SECRETS-PRIVILEGES-O1-VERIFY` (Parte C — 11 cenários da Seção 8) | **CORRIGIDO E COMPROVADO** | Homologação em PostgreSQL 15+ real. |
| **M02.11-F05** (`P2 — Médio`) | Conversão de `public.derive_idempotency_lineage_key` para `SECURITY DEFINER` (`OWNER TO postgres`, `SET search_path = pg_catalog, public, internal_guard, pg_temp`), `REVOKE EXECUTE` de `PUBLIC, anon, authenticated`, `GRANT EXECUTE` apenas a `service_role` + cálculo do hash do ZIP final após sua geração definitiva. | `000018`, `function_inventory.json`, `verify_pg_contracts_and_ast.py`, `run_isolated_test_suite.py` | `M02.12-F03-F04-F05-SECRETS-PRIVILEGES-O1-VERIFY` (Parte B) + `STATIC-03` / `STATIC-15` / `STATIC-18` | **CORRIGIDO E COMPROVADO** | Homologação em PostgreSQL 15+ real (`T9.25d`). |

---

## SEÇÃO D — SEGURANÇA: MATRIZ DE GRANTS, OWNERS, 49 FUNÇÕES ATIVAS, RLS E CICLO DE VIDA DE CHAVES

### D.1. Matriz de Permissões (`GRANT` / `REVOKE`) por Papel Após a Migration `000018`

| Objeto / Escopo | `PUBLIC` | `anon` | `authenticated` | `service_role` | `postgres` (Owner) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| `SCHEMA public` (`CREATE`) | `REVOKE` | `REVOKE` | `REVOKE` | `GRANT` | `OWNER` |
| `SCHEMA internal_guard` (`USAGE`) | `REVOKE` | `REVOKE` | `REVOKE` | `GRANT USAGE` | `OWNER` |
| `TABLE internal_guard.lineage_hmac_keys` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | `OWNER` (`FORCE RLS`) |
| `TABLE internal_guard.execution_tokens` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | `OWNER` (`ENABLE RLS`) |
| `internal_guard.compute_lineage_mac(TEXT, TEXT, SMALLINT)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.verify_lineage_mac(TEXT, TEXT, TEXT, SMALLINT)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.require_active_hmac_secret()` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.issue_token(TEXT, UUID, TEXT)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.consume_token(TEXT, UUID, TEXT)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.cleanup_tokens(TEXT, UUID)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.enforce_lineage_hmac_key_lifecycle()` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.assert_active_lineage_hmac_key_invariant()` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`REVOKE ALL`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.rotate_lineage_hmac_key(TEXT, BOOLEAN)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`GRANT EXECUTE`** | `OWNER` (`SECURITY DEFINER`) |
| `internal_guard.manage_lineage_hmac_key_lifecycle(TEXT, SMALLINT, TEXT)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`GRANT EXECUTE`** | `OWNER` (`SECURITY DEFINER`) |
| `public.derive_idempotency_lineage_key(TEXT, INTEGER)` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`GRANT EXECUTE`** | `OWNER` (`SECURITY DEFINER`) |
| `public.backfill_and_verify_booking_lineage()` | `REVOKE ALL` | `REVOKE ALL` | `REVOKE ALL` | **`GRANT EXECUTE`** | `OWNER` (`SECURITY DEFINER`) |
| `public.create_booking_request(...)` | `REVOKE ALL` | `GRANT EXECUTE` | `GRANT EXECUTE` | `GRANT EXECUTE` | `OWNER` (`SECURITY DEFINER`) |
| `public.get_tour_availability(TEXT, DATE)` | `REVOKE ALL` | `GRANT EXECUTE` | `GRANT EXECUTE` | `GRANT EXECUTE` | `OWNER` (`SECURITY DEFINER`) |
| `public.transition_booking_status(...)`, `create_verified_review(...)`, `admin_update_booking(...)`, `settle_commission_ledger(...)`, `upsert_availability_block(...)`, `delete_availability_block(...)`, `admin_anonymize_customer_pii(...)` | `REVOKE ALL` | `REVOKE ALL` | `GRANT EXECUTE` | `GRANT EXECUTE` | `OWNER` (`SECURITY DEFINER`) |

### D.2. Inventário das 49 Funções Ativas Após a Migration `000018` (`40 SECURITY DEFINER` + `9 SECURITY INVOKER`)

- **Total de Funções Ativas:** `49` (`2` em `auth`, `10` em `internal_guard`, `37` em `public`)
- **`SECURITY DEFINER`:** `40` (100% com `OWNER TO postgres` e `SET search_path` iniciando em `pg_catalog` e terminando em `pg_temp`)
- **`SECURITY INVOKER`:** `9` (100% com `SET search_path` iniciando em `pg_catalog` e terminando em `pg_temp`)
- **Isolamento de `internal_guard`:** 10/10 funções em `internal_guard` utilizam exclusivamente `SET search_path = pg_catalog, internal_guard, pg_temp` (sem `public` e sem `auth`).

### D.3. Procedimentos Operacionais Documentados de Ciclo de Vida, Backup, Restauração e Recuperação de Chaves HMAC (Seção 6)

1. **Rotação Normal de Chave (CSPRNG 256 bits):**
   - Executar como `service_role` ou `postgres`: `SELECT internal_guard.rotate_lineage_hmac_key(NULL, false);`.
   - Gera 32 bytes via `public.gen_random_bytes(32)`, desmarca `is_current` da chave anterior preservando `is_verify_enabled = true`, insere a nova versão como `is_current = true, is_verify_enabled = true` e valida a invariante no commit via `trg_assert_active_lineage_hmac_key_commit`.
2. **Migração/Re-Keying de Linhagens para Nova Versão (Backfill):**
   - Executar `SELECT public.backfill_and_verify_booking_lineage();`.
   - Re-assina com a versão ativa os registros que possuem material suficiente e atualiza `hmac_key_version`, `lineage_root_key_version`, `lineage_idem_key_version` e `lineage_scope_key_version`.
3. **Aposentadoria de Versão Histórica (`RETIRE`):**
   - Quando nenhuma reserva depender mais da versão `v_old`, executar: `SELECT internal_guard.manage_lineage_hmac_key_lifecycle('RETIRE', v_old::smallint, NULL);`.
   - Caso ainda exista qualquer reserva referenciando `v_old` em qualquer uma das 4 colunas de versão, o trigger `trg_protect_lineage_hmac_keys_lifecycle` abortará a operação com `KEY_DISABLE_DEPENDENT_RECORDS_EXIST`.
4. **Backup e Restauração Autorizada de Chave Histórica (`RESTORE`):**
   - Os backups criptografados do cofre `internal_guard.lineage_hmac_keys` devem ser custodiados externamente em KMS/Secret Manager pelo administrador.
   - Em caso de perda acidental ou necessidade de restaurar uma versão histórica `v_hist` para verificar reservas antigas, executar:
     `SELECT internal_guard.manage_lineage_hmac_key_lifecycle('RESTORE', v_hist::smallint, '<hex_64_a_128_do_backup>');`.
   - A função valida o formato/entropia estrutural do segredo, bloqueia conflito de versão (`KEY_VERSION_CONFLICT` se `v_hist` já existir com segredo diferente), bloqueia segredo duplicado em outra versão (`DUPLICATE_SECRET_MATERIAL_REJECTED`) e restaura a linha com `is_current = false, is_verify_enabled = true`.
5. **Limitação Criptográfica Formal (Transparência Operacional):**
   - Se o material secreto de uma versão histórica `v_hist` for perdido permanentemente sem backup E existirem reservas **totalmente anonimizadas** (`lgpd-lin-<root24>-<scope20>`) cujos identificadores foram gerados sob `v_hist` sem terem sido re-assinados por `backfill_and_verify_booking_lineage()` antes da perda, não é matematicamente possível recalcular o HMAC da versão perdida sem a chave secreta. Nessa hipótese, os dados anonimizados permanecem íntegros e protegidos contra exposição de PII, porém a associação criptográfica com o segredo perdido não pode ser reconstruída sem restauração do backup da chave.

---

## SEÇÃO E — TESTES E VALIDAÇÕES EXECUTADOS E LIMITAÇÕES DO AMBIENTE

### E.1. Resumo das Suítes Executadas no Ambiente Isolado

| Categoria de Teste | Ferramenta / Comando Executado | Escopo Validado | Resultado |
| :--- | :--- | :--- | :---: |
| **A. Integridade & Proveniência** | Verificador SHA-256 + `zipfile.testzip()` | Preservação byte a byte das 17 migrations históricas (`000001`–`000017`), presença da `000018` e integridade estrutural do ZIP. | **100% APROVADO** |
| **B. Testes Estáticos, Contratos SQL e AST** | `python3 supabase/tests/verify_pg_contracts_and_ast.py` | `STATIC-01` a `STATIC-18`: inventário de 49 funções (`40 SD + 9 SI`), `search_path`, grants/revokes, RLS/FORCE RLS, bindings dinâmicos de 20 tabelas/7 enums, parsing de 18 migrations e compilação Babel AST TypeScript/JSX. | **`18/18 STATIC PASS` (`exit code 0`)** |
| **C. Guardas Anti-Destrutivas do Runner** | `python3 supabase/tests/test_runner_destructive_guards.py` | `GUARD-00` a `GUARD-15`: bloqueio de hosts externos, nomes de produção, parâmetros de query proibidos, portas ocupadas e reset atômico na mesma sessão. | **`16/16 APROVADOS` (`exit code 0`)** |
| **D. Testes Isolados e de Regressão** | `python3 supabase/tests/run_isolated_test_suite.py` | `38` suítes cobrindo todas as regressões das Missões `01` a `02.10` + 3 novas suítes dedicadas da Missão `02.12` (`M02.12-F01-LEGACY-LINEAGE-COMPATIBILITY-12`, `M02.12-F02-KEY-LIFECYCLE-RECOVERY-12` e `M02.12-F03-F04-F05-SECRETS-PRIVILEGES-O1-VERIFY`). | **`38/38 APROVADOS` (`exit code 0`)** |
| **E. Homologação PostgreSQL 15+ Real** | `bash supabase/tests/run_postgresql_homologation.sh --docker` | Execução real em motor PostgreSQL 15+ (`pgcrypto`, triggers diferidos `DEFERRABLE INITIALLY DEFERRED`, RLS, concorrência e carga). | **PENDENTE (Ambiente sem daemon PostgreSQL/Docker)** |

---

## SEÇÃO F — PENDÊNCIAS PARA HOMOLOGAÇÃO POSTGRESQL 15+ REAL E RECOMENDAÇÕES

1. **O que permanece pendente de execução em PostgreSQL 15+ real:**
   - Execução de `bash supabase/tests/run_postgresql_homologation.sh --docker` em ambiente com Docker e PostgreSQL 15+;
   - Aplicação real das 18 migrations (`000001` a `000018`) e reaplicação atômica (`--single-transaction`) validando os blocos `T8.1` a `T8.15` e `T9.1` a `T9.25` em `supabase/tests/homologacao_postgresql_real.sql`;
   - Verificação real do disparo no `COMMIT` do `CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit DEFERRABLE INITIALLY DEFERRED` e das permissões de catálogo `pg_proc` (`has_function_privilege`) sob `SET LOCAL ROLE service_role`, `SET LOCAL ROLE authenticated` e `SET LOCAL ROLE anon`;
   - Execução das suítes de concorrência real (`test_concorrencia_real_pg.py`) e estabilidade sob carga (`load_stability_plan_pg.py`).
2. **Riscos Residuais:**
   - Nenhum bloqueador lógico ou de segurança identificado no escopo estático e isolado; a validação final depende exclusivamente da execução da bateria de homologação em instância PostgreSQL 15+ real.

---

## SEÇÃO G — CLASSIFICAÇÃO FINAL OBRIGATÓRIA

**APROVADO COM RESSALVAS — SEM BLOQUEADORES NO ESCOPO TESTADO.**
