# RELATÓRIO TÉCNICO E FORENSE — ARGON 4 — MISSÃO 01.9
## CORREÇÃO FORENSE CONTROLADA, HARDENING DO RUNNER POSTGRESQL, IMPLEMENTAÇÃO REAL DE CARGA `L1/L2/L3` E COMPLEMENTAÇÃO LGPD (`M01.9-001` A `M01.9-007`)

- **Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
- **Missão:** 01.9 (Correção controlada sobre o pacote final da Missão 01.8)
- **Data da Execução:** 12/11/2026
- **Veredito Oficial da Missão 01.9:** **`APROVADA PARA HOMOLOGAÇÃO EXTERNA — PENDENTE DE EXECUÇÃO POSTGRESQL REAL`**

---

## SEÇÃO A — RESUMO EXECUTIVO

A **Missão 01.9** executou todas as correções técnicas e de segurança apontadas na auditoria independente sobre o pacote da Missão 01.8 (`M01.9-001` a `M01.9-007`), preservando 100% byte a byte as migrations `000001` a `000007`, o design visual, os contratos de frontend/backend e todas as correções anteriores:

1. **`M01.9-001` — Proteção Crítica do Runner PostgreSQL (`supabase/tests/run_postgresql_homologation.sh` + `supabase/tests/test_runner_destructive_guards.py`):**
   - Implementada proteção multicamada em modo **fail-closed** antes de qualquer `DROP SCHEMA`.
   - **Modo Docker (`--docker`)**: sobe container PostgreSQL 15 temporário isolado com `MISSION_RUN_ID` exclusivo, porta exclusiva, armazenamento em memória `--tmpfs /var/lib/postgresql/data:rw` (sem volumes externos), banco dedicado `ubatuba_homolog_disposable` e `trap` que verifica o label `com.ubatuba.mission_run_id` antes de encerrar/remover o container.
   - **Modo `DATABASE_URL` externa**: exige confirmação explícita `UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB="CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO"`, bloqueia qualquer host remoto/externo (permitindo apenas `127.0.0.1`/`localhost`/`::1`), rejeita bancos padrão (`postgres`, `defaultdb`, `supabase`, `template0`, `template1`) e qualquer nome contendo indicadores de produção (`prod`, `production`, `prd`, `live`, `main`, `master`, `staging_real`), exigindo o padrão estrito `^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$`.
   - **Proteção na mesma conexão e sessão (`DO $guard$`)**: a consulta a `current_database()`, `current_user`, `session_user`, `inet_server_addr()` e `inet_server_port()`, a validação das regras e os comandos `DROP SCHEMA IF EXISTS public CASCADE` e `DROP SCHEMA IF EXISTS internal_guard CASCADE` ocorrem **dentro da mesma invocação, conexão e sessão `psql`**, tornando impossível validar em uma conexão e executar `DROP SCHEMA` em outra.
   - **Suíte automatizada de testes da guarda (`supabase/tests/test_runner_destructive_guards.py`)**: `10/10` cenários aprovados (`PASS`), comprovando bloqueio pré-`DROP` em todos os cenários negativos.

2. **`M01.9-002` — Implementação Real dos Testes de Carga e Estabilidade `L1`, `L2` e `L3` (`supabase/tests/load_stability_plan_pg.py`):**
   - **`L1` (`50` solicitações concorrentes)**: `50` threads sincronizadas por `threading.Barrier(50)` invocando `public.create_booking_request` (`2` passageiros cada para `12` vagas em `tour-lancha-norte-comp`), registrando resultado individual das `50` requisições, classificação (`SUCCESS`, `EXPECTED_CAPACITY_CONFLICT`, `DEADLOCK`, `TIMEOUT`, `UNEXPECTED_FAILURE`), estatísticas `min`/`avg`/`max`/`P95`/`P99`, verificação de ocupação final (`12/12`), paridade com `commission_ledger` e `0` tokens residuais. Rejeita aprovação se todas as requisições falharem por erro de auth/permissão/infraestrutura.
   - **`L2` (`20` operações concorrentes cruzadas)**: `20` threads sincronizadas executando simultaneamente criação de reserva (`6`), confirmação de reserva (`3`), cancelamento de reserva (`3`), alteração de capacidade de passeio (`3`), alteração de capacidade de embarcação (`2`) e criação/remoção de bloqueio de agenda (`3`) sobre a mesma embarcação/passeio/data, validando `0` deadlocks, `0` overbooking, consistência entre `tours`, `vessels` e `bookings` e integridade do `commission_ledger`.
   - **`L3` (Expiração em lote concorrente com novas reservas)**: lote controlado de `6` reservas pendentes expiradas + `4` reservas pendentes válidas dentro da janela SLA distribuídas entre múltiplos passeios e datas, executando `public.expire_stale_bookings()` concorrentemente com `10` novas solicitações de reserva, validando liberação de capacidade das expiradas (`CANCELADA`/`REVERTIDA`), proteção das válidas (`AGUARDANDO_CONFIRMACAO`/`PROVISIONADA`), bloqueio de reativação de reserva expirada e integridade de histórico e livro-razão antes, durante e após.

3. **`M01.9-003` — Correção do Ciclo de Vida do Container (`supabase/tests/run_postgresql_homologation.sh`):**
   - Fluxo unificado em um único comando: sobe container -> aguarda prontidão real -> aplica migrations `000001` a `000008` -> reaplica `000003` a `000008` -> executa `PG-01` a `PG-14`, `T8.1` a `T8.15` e `T9.1` a `T9.14` -> executa concorrência real (`2x`) -> executa `L1`, `L2` e `L3` enquanto o container está ativo -> gera relatórios -> encerra e remove exclusivamente o container da execução atual (com suporte opcional a `--keep-container --run-id <ID>` e `--stop-container --run-id <ID>` verificando propriedade).

4. **`M01.9-004` e `M01.9-005` — Complementação LGPD (`supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` + `T9.1` a `T9.14`):**
   - Criada a migration incremental `000008` (preservando `000007` intacta) que amplia `public.admin_anonymize_customer_pii(UUID, TEXT)`, `public.enforce_booking_invariants_and_transitions()` e `public.validate_verified_review()` para sanitizar `bookings.rejection_or_cancel_reason`, desvincular `bookings.tourist_user_id := NULL`, sanitizar **todos** os registros de `booking_status_history` da reserva, desvincular `reviews.tourist_user_id := NULL`, anonimizar `author_name`/`author_city`, redigir seletivamente `reviews.comment` quando contém dados pessoais (telefone, e-mail, CPF ou nome/contato do titular), e sanitizar `12` chaves sensíveis em `old_data` e `new_data` de `public.audit_logs`, além do Bloco 9 (`T9.1` a `T9.14`) em `homologacao_postgresql_real.sql`.

---

## SEÇÃO B — TABELA DE BACKUP E HASHES SHA-256 (ANTES E DEPOIS)

### B.1. Pacotes ZIP e Snapshots de Backup

| Artefato | Caminho | Tamanho (Bytes) | SHA-256 |
| --- | --- | --- | --- |
| **Pacote de Entrada (`Missão 01.8`)** | `ubatuba_mar_e_praias_missao01_8_corrigido.zip` | `964.362` | `57157922ae9798115f9a64edf1a15c1d873c966818d8ed09be1c6543ff22fbad` |
| **Backup Integral Pré-01.9** | `ubatuba_mar_e_praias_missao01_8_corrigido_BACKUP_PRE_01_9.zip` | `964.362` | `57157922ae9798115f9a64edf1a15c1d873c966818d8ed09be1c6543ff22fbad` |
| **Snapshot Lógico SQL Pré-01.9** | `supabase/backups/backup_logico_pre_missao_01_9.sql` | `335.746` | `e78976aabe91566e0b043e571168d8fe1956fc0de69c5c04f6bbf77e28bf3b10` |

### B.2. Migrations Preservadas (`000001` a `000007`) — 100% Idênticas Antes e Depois

| Migration | Tamanho | SHA-256 Antes (Missão 01.8) | SHA-256 Depois (Missão 01.9) | Status |
| --- | --- | --- | --- | --- |
| `supabase/migrations/20261108000001_initial_schema.sql` | `17.194 B` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **INTACTO** |
| `supabase/migrations/20261108000002_rls_and_rpcs.sql` | `3.875 B` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **INTACTO** |
| `supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql` | `120.783 B` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **INTACTO** |
| `supabase/migrations/20261110000004_missao01_official_catalog_seed.sql` | `14.727 B` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **INTACTO** |
| `supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql` | `58.943 B` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **INTACTO** |
| `supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql` | `54.113 B` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **INTACTO** |
| `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` | `64.902 B` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **INTACTO** |

### B.3. Arquivos Criados ou Modificados na Missão 01.9

| Arquivo | Operação | Tamanho Antes | SHA-256 Antes | Tamanho Depois | SHA-256 Depois |
| --- | --- | --- | --- | --- | --- |
| `supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` | **CRIADO** | — | — | `36.333 B` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` |
| `supabase/backups/backup_logico_pre_missao_01_9.sql` | **CRIADO** | — | — | `335.746 B` | `e78976aabe91566e0b043e571168d8fe1956fc0de69c5c04f6bbf77e28bf3b10` |
| `supabase/tests/test_runner_destructive_guards.py` | **CRIADO** | — | — | `25.106 B` | `5eb44ef45f861d8e8c6a6cb9df3be5e17b09fb700be0c2d5e8061a4dc2e0d413` |
| `supabase/tests/run_postgresql_homologation.sh` | **MODIFICADO** | `6.221 B` | `5ca1f0df54fde536a16887bb5d50d99336340407bee113dcfaf7c4abeb572e32` | `20.712 B` | `72a1fe2d6c6e60ecd8b88dc4932f900583480aa81ce16f2b90f03bf28edc5478` |
| `supabase/tests/load_stability_plan_pg.py` | **MODIFICADO** | `4.027 B` | `f89d07e43296e931476830ca0456ce7afaae62200efbc2010c019f06ec39ba8f` | `43.429 B` | `057d8ee7a56859976c59801dc25493cca7c32d27d0eb092468a5f45e84a8e1a6` |
| `supabase/tests/homologacao_postgresql_real.sql` | **MODIFICADO** | `65.920 B` | `9a867d1a5594d1f492472dde1aa4119c170805400adabf40efe1296727546a49` | `87.546 B` | `52acabff531db4a672ca1874bfc8b618d6c9bd14529f4f245853e04b9758cc39` |
| `supabase/tests/function_inventory.json` | **MODIFICADO** | `65.199 B` | `d60715aeac994221c93846cf70b6c871ee66e7d5562c979e4dbe790423837d14` | `91.706 B` | `6fb82884160a8cccb11eb68b138359278e04baadbfefb2147da68c6f664ab2c7` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **MODIFICADO** | `25.877 B` | `0f5be58a3b168fd599b64137bb958f60121070a79dd0a3778265ab94f980ae0f` | `27.792 B` | `72236f23c1e46fe34cbfb909ddec06b75139b1a4ede07384ba083f8dda197ec5` |
| `supabase/tests/run_isolated_test_suite.py` | **MODIFICADO** | `73.967 B` | `192fb7f89203186e7a85a618c8e856c9a6b5554a063d6b7fc71148bcbaecc883` | `76.137 B` | `80efa8b8a1ee1b42651cd29321969f0a032aba3ff14c16013763ccea2859b03e` |

---

## SEÇÃO C — TABELA DE DISCREPÂNCIAS E CORREÇÕES (`M01.9-001` A `M01.9-007`)

| ID | Severidade | Descrição da Pendência Identificada | Causa Raiz | Correção Implementada na Missão 01.9 | Status |
| --- | --- | --- | --- | --- | --- |
| **`M01.9-001`** | **P0 — Crítica** | Runner `run_postgresql_homologation.sh` executava `DROP SCHEMA IF EXISTS public CASCADE` apenas com `DATABASE_URL` sem confirmação explícita e sem validação do banco conectado na mesma sessão. | Ausência de travas pré-conexão e intrassessão antes do comando destrutivo. | Proteção em múltiplas camadas (pré-conexão + bloco atômico `DO $guard$` na **mesma conexão e sessão `psql`** que executa o `DROP SCHEMA`) e suíte `test_runner_destructive_guards.py` (`10/10 PASS`). | **RESOLVIDO E COMPROVADO** |
| **`M01.9-002`** | **P1 — Alta** | `load_stability_plan_pg.py` executava apenas 20 threads em `L1`, não classificava resultados individuais com `P95`/`P99`, e não implementava `L2` e `L3`. | Implementação parcial do runner de carga na Missão 01.8. | Implementação integral de `L1` (`50` reqs concorrentes + classificação individual + `min`/`avg`/`max`/`P95`/`P99`), `L2` (`20` ops concorrentes cruzadas nas 6 categorias) e `L3` (lote de `6` expiradas + `4` válidas + `expire_stale_bookings()` concorrente com `10` novas reservas). | **RESOLVIDO (RUNTIME PG PENDENTE)** |
| **`M01.9-003`** | **P1 — Alta** | Container PostgreSQL subia e encerrava antes da execução de `load_stability_plan_pg.py`. | `load_stability_plan_pg.py` não estava integrado ao ciclo de vida do container em `run_postgresql_homologation.sh`. | Ciclo unificado em `run_postgresql_homologation.sh` executando `PG-01..PG-14`, `T8.1..T8.15`, `T9.1..T9.14`, concorrência real (`2x`) e carga `L1/L2/L3` antes de encerrar o container (mais opções `--keep-container` / `--stop-container --run-id`). | **RESOLVIDO E COMPROVADO** |
| **`M01.9-004`** | **P1 — Alta** | `admin_anonymize_customer_pii` em `000007` não sanitizava `rejection_or_cancel_reason`, não desvinculava `tourist_user_id`, sanitizava apenas a linha inicial de `booking_status_history`, não redigia comentários de `reviews` com PII e cobria apenas 4 chaves em `audit_logs`. | Cobertura parcial de colunas livres e vínculos de titularidade na versão inicial da RPC LGPD. | Migration incremental `000008` (`20261114000008_missao01_9_controlled_fixes.sql`) cobrindo integralmente `bookings`, todos os registros de `booking_status_history`, `reviews` (incluindo redação seletiva de comentários com PII) e `12` chaves em `audit_logs`. | **RESOLVIDO (RUNTIME PG PENDENTE)** |
| **`M01.9-005`** | **P1 — Alta** | Ausência de bloco dedicado `T9.1` a `T9.14` testando todos os 14 requisitos da RPC `admin_anonymize_customer_pii`. | Cobertura anterior concentrada apenas em `T8.15`. | Adicionado **Bloco 9 (`T9.1` a `T9.14`)** em `supabase/tests/homologacao_postgresql_real.sql`. | **RESOLVIDO (RUNTIME PG PENDENTE)** |
| **`M01.9-006`** | **P2 — Média** | Necessidade de comprovar ausência de regressão sobre todas as correções das Missões 01.4, 01.6 e 01.8. | Evolução incremental com adição da migration `000008`. | Reexecução integral de `verify_pg_contracts_and_ast.py` (`11/11 STATIC PASS`) e `run_isolated_test_suite.py` (`23/23 PASS`). | **RESOLVIDO E COMPROVADO** |
| **`M01.9-007`** | **P2 — Média** | Verificação de dependências e build (`npm ci`, `npx tsc --noEmit`, `npm run build`). | Ambiente sandbox sem acesso externo ao registro `registry.npmjs.org` e sem `node_modules` pré-instalado. | Comandos executados e documentados com código de retorno e causa exata (`EAI_AGAIN registry.npmjs.org`); validação estática AST via `@babel/parser`, `@babel/traverse` e `@babel/core` (`STATIC-08`) aprovada (`PASS`). | **AUDITADO (BUILD COMPLETO PENDENTE DE REDE/NPM)** |

---

## SEÇÃO D — EVIDÊNCIAS DA PROTEÇÃO DO RUNNER POSTGRESQL (`M01.9-001`)

### D.1. Mecanismo de Proteção na Mesma Conexão e Sessão (`psql`)
Em `supabase/tests/run_postgresql_homologation.sh`, a validação prévia no Bash e o reset do schema não ocorrem em conexões separadas. O comando `psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1` abre **uma única sessão**, injeta os parâmetros no contexto da sessão e executa um único bloco atômico `DO $guard$ ... END $guard$;` que:
1. Consulta `current_database()`, `current_user`, `session_user`, `inet_server_addr()` e `inet_server_port()` diretamente no servidor conectado;
2. Verifica em modo **fail-closed**:
   - `confirm_token = 'CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO'`;
   - `current_database() = expected_db`;
   - Exclusão explícita de `'postgres'`, `'defaultdb'`, `'supabase'`, `'template0'`, `'template1'`;
   - Exclusão explícita de qualquer banco que case com `(prod|production|prd|live|main|master|staging_real)`;
   - Conformidade estrita com a regex `^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$` (e igualdade exata com `ubatuba_homolog_disposable` quando `execution_mode = 'docker'`);
   - Validação de `current_user` e `session_user` em `('postgres', 'supabase_admin')`;
   - Validação de `inet_server_addr()` como socket local (`NULL`), loopback (`127.0.0.0/8`, `::1`) ou sub-rede privada do container Docker quando em modo `--docker` (bloqueando túneis/proxies apontando para IPs públicos remotos).
3. Somente após passar por todas as 6 travas na mesma transação/sessão, executa `EXECUTE 'DROP SCHEMA IF EXISTS public CASCADE'` e `EXECUTE 'DROP SCHEMA IF EXISTS internal_guard CASCADE'`.

### D.2. Resultado dos 10 Testes Automatizados (`supabase/tests/test_runner_destructive_guards.py`)

| ID do Teste | Cenário (Seção 3.2) | Resultado | Evidência Comprovada |
| --- | --- | --- | --- |
| `GUARD-00-SAME-SESSION` | Verificação estrutural de sessão única `DO $guard$` | **PASS** | `pos_identificacao=554`, `pos_inet_addr=614 < pos_drop=3980`, `total_drops_no_script=1` |
| `GUARD-01-DOCKER-AUTORIZADO` | Container descartável autorizado (`--docker`) | **PASS** | `ubatuba_homolog_disposable`, `--tmpfs`, label `com.ubatuba.mission_run_id`, `rc=0`, limpeza do próprio container |
| `GUARD-02-HOMOLOG-AUTORIZADO` | Banco local de homologação autorizado (`ubatuba_homolog_ci_01`) | **PASS** | `127.0.0.1` + confirmação explícita aprovados na mesma sessão (`rc=0`) |
| `GUARD-03-HOST-EXTERNO-BLOQUEADO` | Banco externo não autorizado (`db.aphheooljbmldpjeyuim.supabase.co`) | **PASS** | Bloqueado antes de qualquer conexão/DROP (`rc=3`, `drop_executed=False`) |
| `GUARD-04-NOME-PRODUCAO-BLOQUEADO` | Banco com nome de produção (`prod`, `production`, `prd`, `live`, `main`, `master`) | **PASS** | 6/6 variações bloqueadas antes de qualquer DROP (`rc=3`, `drop_executed=False`) |
| `GUARD-05-URL-SEM-ID-CONFIAVEL-BLOQUEADA` | URL padrão/sem identificação confiável (`postgres`, `defaultdb`, `supabase`, vazia) | **PASS** | 4/4 variações bloqueadas antes de qualquer DROP (`rc=3`, `drop_executed=False`) |
| `GUARD-06-FALHA-CONSULTA-ID-BLOQUEADA` | Falha na consulta de identificação ou retorno vazio | **PASS** | Abortado em modo fail-closed antes do DROP (`rc=1`, `drop_executed=False`) |
| `GUARD-07-SEM-CONFIRMACAO-BLOQUEADO` | Execução sem `UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB` | **PASS** | Bloqueado imediatamente antes do DROP (`rc=3`, `drop_executed=False`) |
| `GUARD-08-CONEXAO-NAO-AUTORIZADA-NA-SESSAO-BLOQUEADA` | Divergência de `current_database()`, `inet_server_addr()` público ou `current_user` inválido na sessão | **PASS** | 3/3 subcasos abortados dentro do bloco `DO $guard$` antes do `EXECUTE 'DROP SCHEMA'` (`drop_executed=False`) |
| `GUARD-09-CONTAINER-OWNERSHIP-PROTECTION` | Tentativa de `--stop-container` em container pertencente a outro `run_id` | **PASS** | Recusado por divergência do label `com.ubatuba.mission_run_id` (`rc=3`) |

---

## SEÇÃO E — EVIDÊNCIAS DA IMPLEMENTAÇÃO DE `L1`, `L2` E `L3` (`M01.9-002`)

O arquivo `supabase/tests/load_stability_plan_pg.py` (`43.429 bytes`) implementa integralmente os três cenários com verificação de pré-condições (`verify_safe_disposable_database()`), limpeza exclusiva via RPCs oficiais em blocos `try/finally` (`cleanup_bookings_and_blocks_via_rpcs()`) e geração de relatório JSON estruturado (`supabase/tests/load_stability_report.json`):

| Cenário | Concorrência Real Implementada | Operações Executadas | Critérios Obrigatórios de Aprovação no Script | Status Atual |
| --- | --- | --- | --- | --- |
| **`L1`** | **`50` threads** sincronizadas por `threading.Barrier(50)` | `50` chamadas simultâneas a `public.create_booking_request` (`2` vagas cada) para `tour-lancha-norte-comp` (`12` vagas) na data `2027-02-10`. | Registra resultado individual (`1..50`), classifica cada requisição, calcula `min`/`avg`/`max`/`P95`/`P99`, exige `SUCCESS == 6`, `EXPECTED_CAPACITY_CONFLICT == 44`, `DEADLOCK == 0`, `TIMEOUT == 0`, `UNEXPECTED_FAILURE == 0`, `occupied_seats == 12`, `ledger_provisioned_count == 6` e `residual_tokens == 0`. | **IMPLEMENTADO — RUNTIME PG PENDENTE** |
| **`L2`** | **`20` threads** sincronizadas por `threading.Barrier(20)` | `6` criações de reserva + `3` confirmações + `3` cancelamentos + `3` `UPDATE public.tours SET capacity` + `2` `UPDATE public.vessels SET capacity` + `3` `upsert/delete_availability_block` em `tour-escuna-anchieta` / `ves-escuna-corsario` (`2027-02-15`). | Exige `DEADLOCK == 0`, `TIMEOUT == 0`, `UNEXPECTED_FAILURE == 0`, `SUCCESS > 0`, `occupied_seats <= effective_capacity`, `tour_capacity <= vessel_capacity`, `confirmed_seeds == 3`, `cancelled_seeds == 3`, `ledger_inconsistencies == 0` e `residual_tokens == 0`. | **IMPLEMENTADO — RUNTIME PG PENDENTE** |
| **`L3`** | **`12` threads** concorrentes sobre lote de **`10` reservas pendentes** (`6` expiradas + `4` válidas) | `2` workers executando `public.expire_stale_bookings()` concorrentemente com `10` workers executando `public.create_booking_request` em múltiplos passeios e datas (`2027-02-20` e `2027-02-21`), seguido de tentativa de reativação de reserva expirada. | Exige `expired_cancelled_after == 6`, `expired_ledger_reverted_after == 6`, `expired_history_rows == 6`, `valid_still_protected_after == 4`, `valid_ledger_provisioned_after == 4`, `expired_reactivation_blocked == True`, `DEADLOCK == 0`, `UNEXPECTED_FAILURE == 0` e `residual_tokens == 0`. | **IMPLEMENTADO — RUNTIME PG PENDENTE** |

---

## SEÇÃO F — EVIDÊNCIAS DO CICLO DE VIDA DO CONTAINER (`M01.9-003`)

Em `supabase/tests/run_postgresql_homologation.sh`, o ciclo de vida completo foi unificado em uma única sequência transacional controlada por `trap cleanup_owned_container EXIT`:
1. Sobe container temporário `ubatuba_homolog_pg15_${MISSION_RUN_ID}` com `--tmpfs /var/lib/postgresql/data:rw`, `--label com.ubatuba.mission_run_id=${MISSION_RUN_ID}` e banco `ubatuba_homolog_disposable`.
2. Aguarda prontidão real via loop `SELECT 1;` (até 30s).
3. Executa validação de identidade e reset na mesma sessão `psql` (`Passo 0.1`).
4. Aplica as `8` migrations (`000001` a `000008`) do zero (`Passo 1 — PG-01`).
5. Reaplica as migrations idempotentes (`000003` a `000008`) e valida ausência de duplicação (`Passo 2 — PG-02 & PG-14`).
6. Executa `supabase/tests/homologacao_postgresql_real.sql` incluindo `PG-03..PG-13`, `SEG-01..SEG-07`, `Bloco 8 (T8.1..T8.15)` e `Bloco 9 (T9.1..T9.14)` (`Passo 3`).
7. Executa `supabase/tests/test_concorrencia_real_pg.py` por duas rodadas consecutivas (`Passo 4`).
8. Executa `supabase/tests/load_stability_plan_pg.py` (`L1`, `L2` e `L3`) **enquanto o container ainda está em execução** (`Passo 5`).
9. Ao sair (`EXIT`), `cleanup_owned_container()` inspeciona o label `com.ubatuba.mission_run_id` e encerra/remove exclusivamente o container criado pela execução atual (ou preserva-o quando `--keep-container --run-id <ID>` é informado, permitindo parada manual segura com `--stop-container --run-id <ID>`).

---

## SEÇÃO G — EVIDÊNCIAS DA COMPLEMENTAÇÃO LGPD (`M01.9-004` E `M01.9-005`)

### G.1. Cobertura de Anonimização vs Pseudonimização na Migration `000008`

| Tabela / Objeto | Coluna / Chave | Classificação Técnica | Tratamento Implementado em `20261114000008_missao01_9_controlled_fixes.sql` |
| --- | --- | --- | --- |
| `public.bookings` | `tourist_user_id` | **Desvinculação (Anonimização)** | Definido como `NULL` (autorizado via token `'LGPD_ANONYMIZE:' \|\| status`), impedindo reidentificação por join com `public.profiles`. |
| `public.bookings` | `customer_name` | **Anonimização** | Substituído pela constante `'TITULAR ANONIMIZADO LGPD'`. |
| `public.bookings` | `customer_phone` | **Anonimização** | Substituído pela constante `'(00) 00000-0000'`. |
| `public.bookings` | `customer_email` | **Pseudonimização Contábil** | Substituído por `'anonimizado.' \|\| lower(code) \|\| '@lgpd.invalid'` (preserva unicidade técnica por código contábil sem expor o endereço real). |
| `public.bookings` | `notes` | **Anonimização de Texto Livre** | Substituído por `'[LGPD <protocolo>] Dados pessoais e observações livres sanitizados conforme solicitação.'`. |
| `public.bookings` | `rejection_or_cancel_reason` | **Anonimização de Texto Livre** | Quando não nulo, substituído por `'[LGPD <protocolo>] Motivo de cancelamento/recusa sanitizado conforme solicitação.'`. |
| `public.booking_status_history` | `reason` e `changed_by` (em **todas** as linhas da reserva) | **Anonimização + Preservação de Trilha** | Sanitiza `reason` em **todos** os registros da reserva (`WHERE booking_id = v_target.id`) e define `changed_by = NULL` quando igual ao `tourist_user_id` original, preservando `previous_status`, `new_status`, `created_at` e `changed_by` de parceiro/admin. |
| `public.reviews` | `tourist_user_id`, `author_name`, `author_city`, `comment` | **Anonimização + Redação Seletiva de Comentário** | Define `tourist_user_id = NULL`, `author_name = 'Turista Verificado (LGPD)'`, `author_city = 'Anonimizado'`. Se `comment` contiver e-mail, telefone (`8+` dígitos), CPF ou menção ao nome/e-mail/telefone do titular, substitui pelo texto padrão de supressão LGPD; caso contrário, preserva o comentário opinativo e a nota (`rating`). |
| `public.audit_logs` | `actor_user_id`, `old_data`, `new_data` | **Sanitização In-Place + Registro Auditável** | Sanitiza as `12` chaves (`customer_name`, `customer_phone`, `customer_email`, `notes`, `reason`, `rejection_reason`, `cancel_reason`, `rejection_or_cancel_reason`, `tourist_user_id`, `author_name`, `author_city`, `comment`) em `old_data` e `new_data`, desvincula `actor_user_id` do turista e insere `1` evento `ANONYMIZE_PII_LGPD` com protocolo e responsável sem copiar PII antiga. |

---

## SEÇÃO H — MATRIZ COMPLETA DE TESTES (`ESTÁTICOS`, `ISOLADOS`, `GUARDA DO RUNNER`, `RUNTIME PG`)

| Suíte / Bloco | Escopo | Total de Cenários | Status Atual |
| --- | --- | --- | --- |
| **Verificador Estático e AST (`verify_pg_contracts_and_ast.py`)** | `STATIC-01` a `STATIC-11` (GUC, tokens, inventário de 38 funções pós-`000008`, RLS em 19 tabelas, hierarquia de locks nas 12 rotinas, livro-razão, AST Babel TS/JSX, seed/higiene, Missão 01.8 e Missão 01.9) | `11` | **`11/11 STATIC PASS`** |
| **Suíte de Guarda Destrutiva do Runner (`test_runner_destructive_guards.py`)** | `GUARD-00` a `GUARD-09` (validação na mesma sessão `psql`, container descartável, banco homolog autorizado, bloqueio de host externo, nome de produção, URL sem ID, falha de query, falta de confirmação, divergência na sessão e propriedade do container) | `10` | **`10/10 PASS`** |
| **Suíte Isolada Comportamental (`run_isolated_test_suite.py`)** | `BD-01..BD-06`, `CAD-01..CAD-05`, `RES-01..RES-08`, `INT-01..INT-05`, `M01.8-REG`, `M01.9-REG` | `23` | **`23/23 PASS`** |
| **Suíte SQL de Homologação Real (`homologacao_postgresql_real.sql`)** | `PG-01..PG-14`, `SEG-01..SEG-07`, `Bloco 8 (T8.1..T8.15)` e `Bloco 9 (T9.1..T9.14)` | `50` (`14 PG + 7 SEG + 15 T8 + 14 T9`) | **`PRONTO — PENDENTE DE EXECUÇÃO POSTGRESQL 15+ REAL`** |
| **Suíte de Concorrência Real (`test_concorrencia_real_pg.py`)** | Overbooking compartilhado, charter privativo, redução de capacidade de `vessels`/`tours` concorrente e idempotência concorrente | `4` (executados em `2` rodadas) | **`PRONTO — PENDENTE DE EXECUÇÃO POSTGRESQL 15+ REAL`** |
| **Suíte de Carga e Estabilidade (`load_stability_plan_pg.py`)** | `L1` (`50` reqs concorrentes), `L2` (`20` ops cruzadas) e `L3` (expiração em lote + novas reservas) | `3` | **`PRONTO — PENDENTE DE EXECUÇÃO POSTGRESQL 15+ REAL`** |

---

## SEÇÃO I — RESULTADO DAS VERIFICAÇÕES DE BUILD E TIPAGEM (`M01.9-007`)

| Comando Executado | Ambiente / Rede | Resultado Obtido | Diagnóstico Técnico Preciso |
| --- | --- | --- | --- |
| `npm ci --prefer-offline --no-audit` | Sandbox sem acesso externo DNS/HTTPS (`EAI_AGAIN registry.npmjs.org`) e sem cache npm local | Falha de rede (`npm ERR! code EAI_AGAIN registry.npmjs.org`) | O ambiente de execução atual é isolado da internet e o pacote de entrada não inclui o diretório `node_modules/`. |
| `npx --no-install tsc --noEmit` | Sem `node_modules/.bin/tsc` instalado localmente | Binário `tsc` ausente localmente (`npm ERR! EAI_AGAIN` ao tentar baixar) | O compilador `tsc` depende da instalação prévia de `node_modules` via `npm ci` em máquina com acesso ao registro npm. |
| `npm run build` | Script `tsc && vite build` | `sh: 1: tsc: not found` | Pendente da execução prévia de `npm ci` em ambiente com acesso à internet. |
| `python3 supabase/tests/verify_pg_contracts_and_ast.py` (`STATIC-08`) | Node.js `v18.20.4` + `/usr/share/nodejs` (`@babel/parser`, `@babel/traverse`, `@babel/core`, `@babel/preset-typescript`, `@babel/preset-react`) | **`STATIC PASS` (`rc=0`)** | Todos os `5` módulos TypeScript/TSX (`database.types.ts`, `supabaseClient.ts`, `bookingService.ts`, `App.tsx`, `main.tsx`) foram parseados em AST e transpilados com `0` erros de sintaxe, `0` tipos não declarados e `100%` dos imports/RPCs resolvidos. |

---

## SEÇÃO J — INVENTÁRIO ATUALIZADO DE FUNÇÕES E MIGRATIONS (`000001` A `000008`)

- **Total de Migrations Cronológicas (`000001` a `000008`):** `8` arquivos SQL em `supabase/migrations/`.
- **Total Acumulado de Funções Ativas Pós-`000008` (`function_inventory.json`):** `38` funções ativas (`36` funções próprias do projeto em `public` e `internal_guard` + `2` helpers de infraestrutura em `auth`):
  - **`public` (`33` funções):** `28 SECURITY DEFINER` + `5 SECURITY INVOKER` (`100%` com `SET search_path = pg_catalog, ...`).
  - **`internal_guard` (`3` funções):** `3 SECURITY DEFINER` (`issue_token`, `consume_token`, `cleanup_tokens`, todas com `SET search_path = pg_catalog, internal_guard, pg_temp` e acesso restrito a `service_role`).
  - **`auth` (`2` funções de compatibilidade local):** `auth.uid()` e `auth.jwt()` (`2 SECURITY INVOKER`).
- **Funções atualizadas na Migration `000008` (`20261114000008_missao01_9_controlled_fixes.sql`):**
  1. `public.enforce_booking_invariants_and_transitions()` (`SECURITY DEFINER`, `SET search_path = pg_catalog, public, internal_guard, pg_temp`)
  2. `public.validate_verified_review()` (`SECURITY DEFINER`, `SET search_path = pg_catalog, public, auth, internal_guard, pg_temp`)
  3. `public.admin_anonymize_customer_pii(UUID, TEXT)` (`SECURITY DEFINER`, `SET search_path = pg_catalog, public, internal_guard, pg_temp`)

---

## SEÇÃO K — MATRIZ ATUALIZADA DE LOCKS CONCORRENTES (`STATIC-06`)

Todas as **12 rotinas concorrentes** do sistema respeitam no seu corpo ativo final (pós-`000008`) a hierarquia estrita **Lock #1 (`public.vessels FOR UPDATE`) -> Lock #2 (`pg_advisory_xact_lock(hashtext(vessel_id), hashtext(date))`) -> Lock #3 (`tabela filha FOR UPDATE`) -> Emissão de Token -> Mutação**:

| # | Função (`schema.nome`) | Lock #1 (`vessels FOR UPDATE`) | Lock #2 (`pg_advisory_xact_lock`) | Lock #3 (`Tabela Filha FOR UPDATE`) | Revalidação Antes do Token | Status (`STATIC-06`) |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | `public.validate_availability_block_ownership` | Sim | Sim | `bookings` (leitura sob lock) | Sim | **CONFORME** |
| 2 | `public.upsert_availability_block` | Sim | Sim | `availability_blocks FOR UPDATE` | Sim | **CONFORME** |
| 3 | `public.delete_availability_block` | Sim | Sim | `availability_blocks FOR UPDATE` | Sim | **CONFORME** |
| 4 | `public.check_and_lock_vessel_capacity` | Sim | Sim | `tours` + `bookings` | Sim | **CONFORME** |
| 5 | `public.create_booking_request` | Sim (via `check_and_lock`) | Sim | `bookings` | Sim | **CONFORME** |
| 6 | `public.transition_booking_status` | Sim | Sim | `bookings FOR UPDATE` | Sim | **CONFORME** |
| 7 | `public.expire_stale_bookings` | Sim | Sim | `bookings FOR UPDATE` | Sim | **CONFORME** |
| 8 | `public.admin_update_booking` | Sim | Sim | `bookings FOR UPDATE` | Sim | **CONFORME** |
| 9 | `public.settle_commission_ledger` | Sim | Sim | `bookings FOR UPDATE` + `commission_ledger FOR UPDATE` | Sim | **CONFORME** |
| 10 | `public.create_verified_review` | Sim | Sim | `bookings FOR UPDATE` | Sim | **CONFORME** |
| 11 | `public.protect_catalog_moderation_columns` | Sim | Sim (`epoch 1970-01-01`) | `tours` + `bookings` | Sim | **CONFORME** |
| 12 | `public.admin_anonymize_customer_pii` | Sim | Sim | `bookings FOR UPDATE` + `reviews FOR UPDATE` | Sim | **CONFORME** |

---

## SEÇÃO L — MATRIZ ATUALIZADA DE RLS, GRANTS E ACLS (`STATIC-04` E `STATIC-05`)

- **19/19 tabelas públicas** (`partners`, `profiles`, `partner_members`, `vessels`, `tours`, `tour_schedules`, `availability_blocks`, `commission_rules`, `bookings`, `booking_status_history`, `commission_ledger`, `reviews`, `audit_logs`, `destinations`, `beaches`, `islands`, `trails`, `weather_alerts`, `lead_events`) + **1 tabela interna** (`internal_guard.execution_tokens`) possuem `ENABLE ROW LEVEL SECURITY`.
- **`REVOKE CREATE ON SCHEMA public FROM PUBLIC`** aplicado.
- **`REVOKE ALL ON FUNCTION ... FROM PUBLIC`** aplicado dinamicamente sobre todas as funções de `public` e `internal_guard` ao final de `000006`, `000007` e `000008`.
- **`anon`**: possui `EXECUTE` exclusivamente em `is_admin()`, `is_partner_member(UUID)`, `get_tour_availability(TEXT, DATE)` e `create_booking_request(...)`; `REVOKE ALL` explícito em `admin_anonymize_customer_pii(UUID, TEXT)` e `REVOKE INSERT, UPDATE, DELETE, TRUNCATE` em todas as tabelas de `public`.
- **`authenticated`**: possui `REVOKE INSERT, UPDATE, DELETE, TRUNCATE` nas tabelas sensíveis (`bookings`, `commission_ledger`, `booking_status_history`, `audit_logs`, `availability_blocks`, `reviews`) e `REVOKE DELETE, TRUNCATE` em `profiles`; mutações ocorrem exclusivamente via RPCs autenticadas.

---

## SEÇÃO M — LISTA COMPLETA DO QUE AINDA ESTÁ `PENDING` PARA HOMOLOGAÇÃO REAL

Como este ambiente de execução não possui o daemon Docker nem o binário `psql` / servidor PostgreSQL 15+ instalados nem acesso externo ao registro `registry.npmjs.org`, permanecem expressamente **`PENDING`** de execução em máquina externa de homologação:

1. **Execução runtime da suíte SQL completa no PostgreSQL 15+ (`PG-01` a `PG-14`, `SEG-01` a `SEG-07`, `T8.1` a `T8.15` e `T9.1` a `T9.14`)** via `bash supabase/tests/run_postgresql_homologation.sh --docker`.
2. **Execução runtime das 2 rodadas consecutivas da suíte de concorrência real (`test_concorrencia_real_pg.py`)** contra PostgreSQL 15+.
3. **Execução runtime da suíte de carga e estabilidade (`load_stability_plan_pg.py` — `L1`, `L2` e `L3`)** contra PostgreSQL 15+ e coleta das métricas reais (`min`, `avg`, `max`, `P95`, `P99`) em `supabase/tests/load_stability_report.json`.
4. **Execução de `npm ci`, `npx tsc --noEmit` e `npm run build`** em ambiente com conectividade ao registro npm.

---

## SEÇÃO N — CHECKLIST PASSO A PASSO PARA HOMOLOGAÇÃO REAL NO AMBIENTE COM DOCKER + POSTGRESQL 15+

Em uma máquina com **Docker**, **cliente `psql` (PostgreSQL 15+)**, **Python 3.10+** e **Node.js 18+ / npm** com acesso à internet:

```bash
# Passo 1: Extrair o pacote corrigido da Missão 01.9 e entrar no diretório
unzip ubatuba_mar_e_praias_missao01_9_corrigido.zip -d ubatuba_missao01_9
cd ubatuba_missao01_9

# Passo 2: Executar as suítes estáticas, de guarda do runner e isolada (devem aprovar 10/10, 11/11 e 23/23)
python3 supabase/tests/test_runner_destructive_guards.py
python3 supabase/tests/verify_pg_contracts_and_ast.py
python3 supabase/tests/run_isolated_test_suite.py

# Passo 3: Instalar dependências e validar tipagem e build de produção (M01.9-007)
npm ci
npx tsc --noEmit
npm run build

# Passo 4: Executar a homologação PostgreSQL 15+ completa + Concorrência (2x) + Carga L1/L2/L3
# em container temporário descartável isolado (ciclo de vida unificado M01.9-001/002/003/005)
bash supabase/tests/run_postgresql_homologation.sh --docker

# Passo 5: Inspecionar o relatório JSON gerado pelos cenários de carga L1, L2 e L3
cat supabase/tests/load_stability_report.json
```

Caso deseje executar contra uma instância local descartável já existente na porta `54322` (sem `--docker`):
```bash
export DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog"
export UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB="CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO"
bash supabase/tests/run_postgresql_homologation.sh
```

---

## SEÇÃO O — PROCEDIMENTO DE ROLLBACK

1. **Rollback completo de código e scripts para o estado exato da Missão 01.8:**
   - Restaurar o arquivo de backup integral pré-Missão 01.9 (`ubatuba_mar_e_praias_missao01_8_corrigido_BACKUP_PRE_01_9.zip`, SHA-256 `57157922ae9798115f9a64edf1a15c1d873c966818d8ed09be1c6543ff22fbad`).
2. **Rollback lógico de banco de dados (caso a migration `000008` tenha sido aplicada em ambiente de homologação):**
   - Reaplicar `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` (ou o snapshot consolidado `supabase/backups/backup_logico_pre_missao_01_9.sql`, SHA-256 `e78976aabe91566e0b043e571168d8fe1956fc0de69c5c04f6bbf77e28bf3b10`), que restaura as definições de `enforce_booking_invariants_and_transitions()`, `validate_verified_review()` e `admin_anonymize_customer_pii(UUID, TEXT)` ao estado exato pós-`000007`.

---

## SEÇÃO P — VEREDITO FINAL

**`APROVADA PARA HOMOLOGAÇÃO EXTERNA — PENDENTE DE EXECUÇÃO POSTGRESQL REAL`**
