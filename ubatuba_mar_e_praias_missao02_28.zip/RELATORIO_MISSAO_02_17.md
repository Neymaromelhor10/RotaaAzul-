# RELATÓRIO TÉCNICO — ARGON 4 — MISSÃO 02.17
## FINALIZAÇÃO DA INFRAESTRUTURA, MATERIALIZAÇÃO DO PACKAGE-LOCK E VALIDAÇÃO DE BUILD

- **Projeto**: Ubatuba Mar & Praias — Marketplace de Turismo Náutico (`ubatuba-mar-e-praias-marketplace`)
- **Missão**: `02.17` (Conclusão da Missão A — Infraestrutura)
- **Base Obrigatória Recebida**: `ubatuba_mar_e_praias_missao02_16.zip`
- **SHA-256 da Base `02.16` Recebida**: `a38ffac3b5ceafb4cdfeaf0115c54419e5f9f3bae1bec22ee99eb0948dab227d` (**PASS — Idêntico ao hash informado**)
- **Tamanho / Arquivos da Base `02.16`**: `1.560.837 bytes` / `80 arquivos` (`zipfile.testzip() == None`)
- **Ambiente Executado**: Node.js `v18.20.4`, npm `9.2.0`, Python `3.11.2`
- **Status Geral da Missão (Seção 13)**: **PARCIALMENTE CONCLUÍDA (`PASS` em todas as verificações de integridade, lint, AST/Babel, 19 migrations e 42 suítes de regressão da Missão `02.16`; `BLOCKED` na materialização online do `package-lock.json`, `npm ci`, `npm run typecheck` via `tsc` binário e `npm run build` por bloqueio externo de rede/DNS para `https://registry.npmjs.org` neste container sandbox)**

---

## 1. Resumo Executivo e Quadro de Status (`PASS` / `FAIL` / `BLOCKED` / `NOT RUN`)

Em estrita conformidade com as **Seções 12 e 13**, a tabela abaixo separa de forma explícita e objetiva o que foi executado e aprovado (`PASS`), o que foi reprovado (`FAIL`), o que ficou impedido por bloqueio externo do ambiente sem internet (`BLOCKED`) e o que não pôde ser executado em decorrência desse bloqueio (`NOT RUN`):

| Item / Verificação Obrigatória | Comando / Procedimento | Status | Código de Saída / Evidência Verificável |
| :--- | :--- | :---: | :--- |
| **1. Conferência da Base `02.16` (Seção 2)** | `sha256sum ubatuba_mar_e_praias_missao02_16.zip` + `zipfile.testzip()` | **PASS** | SHA-256 `a38ffac3b5ceafb4cdfeaf0115c54419e5f9f3bae1bec22ee99eb0948dab227d`, `80` arquivos íntegros, cópia original preservada |
| **2. Integridade do `package.json` (Seção 3)** | Auditoria estrutural de `dependencies`, `devDependencies`, `engines` e `scripts` | **PASS** | SHA-256 `cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379` (`4` deps + `14` devDeps compatíveis com Node `18.20.4`) |
| **3. Materialização do `package-lock.json` (Seção 4)** | `bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation` | **BLOCKED** | `exit code 2` (`npm ERR! code EAI_AGAIN / getaddrinfo EAI_AGAIN registry.npmjs.org`); `package-lock.json` original preservado intacto (`ef02719ab...`) |
| **4. Instalação Limpa por `npm ci` (Seção 5)** | `rm -rf node_modules && npm ci --no-audit --no-fund` | **BLOCKED** | `exit code 1` (`npm ERR! request to https://registry.npmjs.org/@babel%2fcore failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org`) |
| **5. Execução do Lint (Seção 6)** | `npm run lint` (`node scripts/run_lint.mjs`) | **PASS** | `exit code 0` (`[LINT PASS] Configurações JSON, devDependencies @babel/*, ausência de /usr/share/nodejs, guarda de segredos VITE_ e proteção anti-demo validados`) |
| **6. Execução do Typecheck (Seção 6)** | `npm run typecheck` (`tsc --noEmit`) | **BLOCKED** | `exit code 127` (`sh: 1: tsc: not found` — binário `node_modules/.bin/tsc` depende da conclusão prévia de `npm ci`) |
| **7. Execução dos Testes Automatizados (Seções 6 e 7)** | `npm test` (`GUARD-00..15` + `STATIC-01..19` + `42/42` Isolated Suites + `7/7` Demo Guard) | **PASS** | `exit code 0` (`16/16` GUARD + `19/19` STATIC/AST + `42/42` suítes isoladas + `7/7` Demo Guard aprovados) |
| **8. Build de Produção (Seção 6)** | `npm run build` (`tsc && vite build`) | **BLOCKED** | `exit code 127` (`sh: 1: tsc: not found` — `tsc` e `vite` dependem da instalação prévia de `node_modules` via `npm ci`) |
| **9. Preservação das 19 Migrations `000001`–`000019` (Seção 8)** | Comparação byte a byte (SHA-256) contra a base `02.16` | **PASS** | `19/19` migrations com hashes SHA-256 `100%` idênticos à base `02.16` (`0` divergências) |
| **10. Auditoria e Correção do Workflow de CI (Seção 9)** | Inspeção e ajuste de `.github/workflows/homologation-and-build.yml` | **PASS** | Node `18.20.4`, executa `npm ci`, `npm run lint`, `npm run typecheck`, `npm test`, `npm run build`, `verify_ci_build.sh` e homologação PG 15 (`000001..000019`) |
| **11. Teste de Reprodutibilidade — 2ª Instalação Limpa (Seção 11)** | Segunda execução de `rm -rf node_modules && npm ci && npm run typecheck && npm run build` | **BLOCKED / NOT RUN** | Impedido pelo mesmo bloqueio de rede (`EAI_AGAIN registry.npmjs.org`) da 1ª execução de `npm ci` |

---

## 2. Verificação de Integridade da Base `02.16` (Seção 2)

1. **Arquivo Recebido**: `ubatuba_mar_e_praias_missao02_16.zip` (`1.560.837 bytes`).
2. **Hash SHA-256 Calculado**: `a38ffac3b5ceafb4cdfeaf0115c54419e5f9f3bae1bec22ee99eb0948dab227d`.
3. **Hash SHA-256 Informado pelo Usuário**: `a38ffac3b5ceafb4cdfeaf0115c54419e5f9f3bae1bec22ee99eb0948dab227d` (**Correspondência Exata Confirmada**).
4. **Integridade do Arquivo ZIP**: `zipfile.testzip()` retornou `None` (`0` entradas corrompidas), contendo `80` arquivos.
5. **Isolamento**: O arquivo original foi copiado para backup imutável (`ubatuba_mar_e_praias_missao02_16_original.zip`), extraído em diretório somente-leitura (`original_02_16/`) e em cópia de trabalho independente (`ubatuba_mar_e_praias_marketplace/`).

---

## 3. Auditoria Inicial das Dependências, Configurações e Scripts (Seção 3)

### 3.1. Inspeção de `package.json`, `package-lock.json`, `.npmrc` e `.nvmrc`
- **Existência de `.npmrc` e `.nvmrc`**: Não existem arquivos `.npmrc` ou `.nvmrc` na base `02.16`; o controle de versão de runtime está declarado diretamente em `package.json` (`"engines": { "node": ">=18.20.0 <21.0.0", "npm": ">=9.0.0" }`).
- **Auditoria do `package.json` (`cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379`)**:
  - **Dependências de produção (`4`)**: `@supabase/supabase-js` (`^2.46.1`), `lucide-react` (`^0.454.0`), `react` (`^18.3.1`), `react-dom` (`^18.3.1`).
  - **Dependências de desenvolvimento (`14`)**: `@babel/core` (`^7.20.12`), `@babel/parser` (`^7.20.15`), `@babel/plugin-transform-modules-commonjs` (`^7.20.11`), `@babel/preset-react` (`^7.18.6`), `@babel/preset-typescript` (`^7.18.6`), `@babel/traverse` (`^7.20.13`), `@types/react` (`^18.3.12`), `@types/react-dom` (`^18.3.1`), `@vitejs/plugin-react` (`^4.3.3`), `autoprefixer` (`^10.4.20`), `postcss` (`^8.4.49`), `tailwindcss` (`^3.4.15`), `typescript` (`^5.6.3`), `vite` (`^5.4.11`).
  - Todas as `18` dependências declaradas são compatíveis com **Node.js `18.20.4`**.
  - Todos os scripts definidos em `package.json` (`dev`, `build`, `typecheck`, `lint`, `test`, `preview`, `test:static`, `test:isolated`, `test:demo-guard`, `test:pg`) apontam para arquivos existentes no repositório.
- **Diagnóstico do `package-lock.json` (`ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013`)**:
  1. **Está completo?**: **Não**. Possui apenas `13` entradas em `packages` (o pacote raiz `""` + `12` pacotes diretos sem subárvore transitiva e sem campos `resolved` e `integrity: "sha512-..."`).
  2. **Todas as dependências declaradas estão representadas?**: **Não**. As `6` dependências `@babel/*` adicionadas ao `package.json` na Missão `02.15.2` (`@babel/core`, `@babel/parser`, `@babel/plugin-transform-modules-commonjs`, `@babel/preset-react`, `@babel/preset-typescript`, `@babel/traverse`) ainda não constam em `packages[""].devDependencies` nem em `packages["node_modules/@babel/*"]` do `package-lock.json`, pois o lockfile aguarda geração real via `npm install --package-lock-only` conectado a `https://registry.npmjs.org`.

### 3.2. Problema Técnico Encontrado nos Scripts Shell (`BASH_ENV`) e Corrigido
Durante a auditoria de execução de `bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation` e `bash scripts/verify_ci_build.sh`, identificou-se que em ambientes Linux onde a variável `BASH_ENV` está configurada apontando para um `.bashrc` que altera o diretório de trabalho (por exemplo, `cd /working_dir`), qualquer invocação não-interativa `bash scripts/...` mudava de diretório antes de abrir o script relativo, falhando com `No such file or directory (exit code 127)`.
- **Correção Aplicada**:
  1. Adicionado `unset BASH_ENV ENV` no topo de `scripts/materialize_and_verify_build.sh` e `scripts/verify_ci_build.sh`.
  2. Em `scripts/materialize_and_verify_build.sh`, a chamada final foi fortalecida para `bash --norc --noprofile "$PROJECT_DIR/scripts/verify_ci_build.sh"`.
  3. Em `.github/workflows/homologation-and-build.yml`, as chamadas de shell foram atualizadas para `env -u BASH_ENV bash --norc --noprofile ...` e o título do job de homologação PostgreSQL 15+ foi atualizado de `000001..000018, T1..T9.23` para `000001..000019, T1..T9.26`.

---

## 4. Materialização do `package-lock.json` e Instalação Limpa `npm ci` (Seções 4, 5 e 11)

### 4.1. Verificação de Conectividade e Execução de `materialize_and_verify_build.sh`
No ambiente atual (Node.js `v18.20.4`, npm `9.2.0`), foi executado:
```bash
env -u BASH_ENV bash --norc --noprofile scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation
```
**Resultado Real Registrado (`BLOCKED`, `exit code 2`)**:
```text
=== 1. Verificando pré-requisitos do ambiente e conectividade com https://registry.npmjs.org ===
v18.20.4
9.2.0
Python 3.11.2
npm notice PING https://registry.npmjs.org/
npm ERR! code EAI_AGAIN
npm ERR! syscall getaddrinfo
npm ERR! errno EAI_AGAIN
npm ERR! request to https://registry.npmjs.org/-/ping?write=true failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org
[REGISTRY_UNREACHABLE] O registry oficial https://registry.npmjs.org está inacessível neste ambiente.
Interrompendo a materialização sem alterar package.json ou package-lock.json.
```
Também foi verificado se existia cache local do npm (`~/.npm/_cacache`) ou pacotes `vite`/`typescript`/`react`/`@supabase/supabase-js` pré-instalados no sistema de arquivos local para resolução offline, constatando-se ausência total desses pacotes no container sandbox. Em estrito cumprimento às regras da **Seção 4** (*"Não criar manualmente um lockfile incompleto. Não remover dependências para fazer o comando passar."*), o `package-lock.json` original (`ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013`) foi preservado intacto.

### 4.2. Execução de `npm ci` (Seção 5) e 2ª Instalação Limpa (Seção 11)
Foi executado individualmente:
```bash
rm -rf node_modules && npm ci --no-audit --no-fund
```
**Resultado Real Registrado (`BLOCKED`, `exit code 1`)**:
```text
npm ERR! code EAI_AGAIN
npm ERR! syscall getaddrinfo
npm ERR! errno EAI_AGAIN
npm ERR! request to https://registry.npmjs.org/@babel%2fcore failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org
```
Consequentemente, a 1ª e a 2ª instalações limpas via `npm ci` encontram-se **BLOCKED** exclusivamente pela ausência de conectividade de saída para `https://registry.npmjs.org` neste ambiente isolado.

---

## 5. Validação Individual do Projeto (Seção 6)

Os quatro comandos obrigatórios da **Seção 6** foram executados individualmente:

1. **`npm run lint`** -> **PASS (`exit code 0`)**:
   ```text
   > ubatuba-mar-e-praias-marketplace@2.0.0 lint
   > node scripts/run_lint.mjs

   [LINT INFO] node_modules/.bin/tsc ausente neste ambiente; verificação estrutural/segurança executada.
   [LINT PASS] Configurações JSON, devDependencies @babel/*, ausência de /usr/share/nodejs, guarda de segredos VITE_ e proteção anti-demo validados.
   ```
2. **`npm run typecheck`** -> **BLOCKED (`exit code 127`)**:
   ```text
   > ubatuba-mar-e-praias-marketplace@2.0.0 typecheck
   > tsc --noEmit

   sh: 1: tsc: not found
   ```
   *(Observação: A transpilação sintática e checagem de contratos AST/TypeScript via `@babel/parser`, `@babel/preset-typescript` e `@babel/preset-react` em `STATIC-08` e `INT-05` passou com `0` erros, porém conforme a Seção 12 não substituímos a execução real de `tsc --noEmit` por verificação estática).*
3. **`npm test`** -> **PASS (`exit code 0`)**:
   - `test_runner_destructive_guards.py`: **16/16 APROVADOS** (`GUARD-00` a `GUARD-15`).
   - `verify_pg_contracts_and_ast.py`: **19/19 APROVADOS** (`STATIC-01` a `STATIC-19`).
   - `run_isolated_test_suite.py`: **42/42 APROVADOS** (incluindo todas as suítes da Missão `02.16`).
   - `test_runtime_demo_guard.mjs`: **7/7 APROVADOS**.
4. **`npm run build`** -> **BLOCKED (`exit code 127`)**:
   ```text
   > ubatuba-mar-e-praias-marketplace@2.0.0 build
   > tsc && vite build

   sh: 1: tsc: not found
   ```

---

## 6. Testes de Regressão da Missão `02.16` (Seção 7)

Todos os quatro comandos de regressão da **Seção 7** foram executados individualmente e aprovados com `exit code 0`:

| Suíte / Funcionalidade da Missão `02.16` Verificada | Evidência Obtida | Status |
| :--- | :--- | :---: |
| `python3 supabase/tests/test_runner_destructive_guards.py` | `16/16` guardas (`GUARD-00` a `GUARD-15`) aprovados | **PASS** |
| `python3 supabase/tests/verify_pg_contracts_and_ast.py` | `19/19` checks (`STATIC-01` a `STATIC-19`), `52` funções SQL, `13` rotinas de lock, `118` bindings SQL x TS | **PASS** |
| **Datas dinâmicas em `America/Sao_Paulo` e Disponibilidade por RPC** | `M02.16-AVAILABILITY-DYNAMIC-DATES-05`: `5/5` cenários aprovados (`current_brazil_date()=2026-11-17`, horários `09:00`/`09:30`/`15:00`, bloqueio de manutenção, lotação `10/10`, conflito privativo e `BOOKING_DATE_IN_PAST`) | **PASS** |
| **Criação de reserva e Idempotência** | `M02.16-BOOKING-AND-IDEMPOTENCY-09`: `9/9` cenários aprovados (`SITE_DIRECT`, `WHATSAPP`, `5/5` bloqueios de entrada inválida, replay idempotente com mesmo `lookup_token` e re-reserva `g0001` pós-cancelamento) | **PASS** |
| **Recuperação pós-`F5`, Consulta por `Código + Chave`, Rate-Limit e Zero PII** | `M02.16-PUBLIC-LOOKUP-RATE-LIMIT-AND-ZERO-PII-07`: `7/7` verificações aprovadas (`lookup_token` nunca salvo em texto puro no DB, `0` campos de PII/comissão expostos, erro uniforme `INVALID_LOOKUP_CREDENTIALS`, bloqueio após `5` falhas com `LOOKUP_RATE_LIMIT_EXCEEDED` e persistência pós-`F5` validada em Node.js) | **PASS** |
| **Cancelamento seguro, Liberação de vagas e Reversão de comissão** | `M02.16-SECURE-TOURIST-CANCELLATION-04`: `4/4` cenários aprovados (bloqueio sem credencial, liberação imediata de `6` vagas + comissão `REVERTIDA`, replay idempotente e bloqueio de `PASSEIO_REALIZADO`) | **PASS** |
| **Bloqueio de modo demonstrativo em produção (`test_runtime_demo_guard.mjs`)** | `7/7` cenários positivos, negativos e estruturais aprovados | **PASS** |

---

## 7. Preservação do Banco e das 19 Migrations (`000001` a `000019`) (Seção 8)

Todas as `19` migrations existentes foram comparadas via SHA-256 contra a base `02.16`. Nenhuma migration foi alterada, renumerada, removida ou adicionada:

| # | Arquivo de Migration (`supabase/migrations/`) | SHA-256 na Base `02.16` | SHA-256 na Entrega `02.17` | Status |
| :---: | :--- | :--- | :--- | :---: |
| `01` | `20261108000001_initial_schema.sql` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **PASS (IDÊNTICO)** |
| `02` | `20261108000002_rls_and_rpcs.sql` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **PASS (IDÊNTICO)** |
| `03` | `20261110000003_missao01_audit_fixes_and_rpcs.sql` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **PASS (IDÊNTICO)** |
| `04` | `20261110000004_missao01_official_catalog_seed.sql` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **PASS (IDÊNTICO)** |
| `05` | `20261111000005_missao01_4_forensic_hardening.sql` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **PASS (IDÊNTICO)** |
| `06` | `20261112000006_missao01_6_forensic_fixes.sql` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **PASS (IDÊNTICO)** |
| `07` | `20261113000007_missao01_8_controlled_fixes.sql` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **PASS (IDÊNTICO)** |
| `08` | `20261114000008_missao01_9_controlled_fixes.sql` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | **PASS (IDÊNTICO)** |
| `09` | `20261115000009_missao02_1_residual_fixes.sql` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | **PASS (IDÊNTICO)** |
| `10` | `20261116000010_missao02_3_surgical_fixes.sql` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | **PASS (IDÊNTICO)** |
| `11` | `20261117000011_missao02_4_adversarial_fixes.sql` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | **PASS (IDÊNTICO)** |
| `12` | `20261118000012_missao02_5_integrity_closure.sql` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | **PASS (IDÊNTICO)** |
| `13` | `20261119000013_missao02_6_post_cancel_idempotency.sql` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | **PASS (IDÊNTICO)** |
| `14` | `20261120000014_missao02_7_lineage_persistence_and_hardening.sql` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | **PASS (IDÊNTICO)** |
| `15` | `20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | **PASS (IDÊNTICO)** |
| `16` | `20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | **PASS (IDÊNTICO)** |
| `17` | `20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | **PASS (IDÊNTICO)** |
| `18` | `20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql` | `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda` | `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda` | **PASS (IDÊNTICO)** |
| `19` | `20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql` | `0e41c7a657b89e1dc852f077ca02f05d299132ea84a7f02227050fda85614d76` | `0e41c7a657b89e1dc852f077ca02f05d299132ea84a7f02227050fda85614d76` | **PASS (IDÊNTICO)** |

---

## 8. Lista de Arquivos Modificados e Hashes SHA-256 (Seção 12)

| Arquivo | Ação e Justificativa Técnica | SHA-256 |
| :--- | :--- | :--- |
| `scripts/materialize_and_verify_build.sh` | **Modificado** — Adicionado `unset BASH_ENV ENV` e invocação `bash --norc --noprofile "$PROJECT_DIR/scripts/verify_ci_build.sh"` para impedir que `BASH_ENV` altere o diretório de trabalho em subshells não-interativos. | `2e4309265e1566a9ce14da5af4786d78d092346f0044d3ac1b018687162661bb` |
| `scripts/verify_ci_build.sh` | **Modificado** — Adicionado `unset BASH_ENV ENV` no início do script para garantir execução determinística em qualquer ambiente Linux/CI. | `092dafb4cada3e21aef9981a2041b5924ac7a38c4e27e828b76acf57bd4a0e19` |
| `.github/workflows/homologation-and-build.yml` | **Modificado** — Atualizado rótulo da etapa PostgreSQL 15+ para `Migrations 000001..000019, T1..T9.26` e adicionada invocação `env -u BASH_ENV bash --norc --noprofile`. | `edfd50d1e08e4a975b56002f96a226b75434310ea563eb7c2eb4a71d749cf076` |
| `package.json` | **Preservado Intacto** | `cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379` |
| `package-lock.json` | **Preservado Intacto** (aguardando materialização em ambiente com acesso a `https://registry.npmjs.org`) | `ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013` |
| `ubatuba_mar_e_praias_missao02_17.zip` | **Pacote Final Entregue** (`80` arquivos, PKZIP 2.0 universal `create_system=0`) | `(ver SHA256SUMS.txt / cabeçalho do relatório externo)` |

---

## 9. Pendências Remanescentes e Procedimento de Desbloqueio em Ambiente com Rede (Seções 12 e 13)

- **Única Pendência Remanescente (`BLOCKED` por ausência de rede no sandbox)**:
  - A geração online do `package-lock.json` completo (`npm install --package-lock-only --registry=https://registry.npmjs.org`) e a subsequente execução de `npm ci`, `npm run typecheck` (`tsc --noEmit`) e `npm run build` (`tsc && vite build`).
- **Comando Único para Concluir no GitHub Codespaces / Máquina Local com Acesso à Internet**:
  ```bash
  bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation
  ```
  Esse comando realiza automaticamente o ping ao registry, cria backup com rollback do `package-lock.json`, gera o `package-lock.json` completo com `sha512` para toda a árvore transitiva (incluindo `@babel/*`), executa `rm -rf node_modules && npm ci`, valida a resolução local do Babel, roda `npm run lint`, `npm test`, `npm run typecheck`, `npm run build` e audita os artefatos finais em `dist/`.
