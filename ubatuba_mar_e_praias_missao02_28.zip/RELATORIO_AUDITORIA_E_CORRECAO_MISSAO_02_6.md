# ARGON 4 — MISSÃO 02.6 — RELATÓRIO TÉCNICO DE IDEMPOTÊNCIA PÓS-CANCELAMENTO, BUILD REPRODUTÍVEL E FECHAMENTO PRÉ-HOMOLOGAÇÃO
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
**Base Recebida (Missão 02.5):** `ubatuba_mar_e_praias_missao02_5_corrigido.zip` (`1.307.346 bytes` | SHA-256 `090668b53ee680c0df82f3bba14a7c6c4f54693ff7ad8b70f97a4227c34d1da0` | `zipfile.testzip() = None`)
**Backup Integral Pré-02.6:** `ubatuba_mar_e_praias_missao02_5_corrigido_BACKUP_PRE_02_6.zip` (`1.307.346 bytes` | SHA-256 `090668b53ee680c0df82f3bba14a7c6c4f54693ff7ad8b70f97a4227c34d1da0`)
**Status da Homologação PostgreSQL 15+ Real e Build com `node_modules`:** **PENDENTE DE AMBIENTE EXTERNO** (não executada homologação PostgreSQL real nem declarado build aprovado sem `npm ci && npm run build`).

---

## 1. F01 & F02 — ANÁLISE E CORREÇÃO DA IDEMPOTÊNCIA APÓS CANCELAMENTO E EXPIRAÇÃO (`000013`)

### 1.1. Reprodução da Falha na Migration `000012` (Antes da Correção)
Na migration `000012` (linhas `695–701`), quando uma reserva anterior `B1` criada com a chave original `k1` estava `CANCELADA`, `RECUSADA` ou expirada (`expires_at <= now()`), `public.create_booking_request()` substituía `v_computed_idem_key` por um hash aleatório não determinístico:
```sql
IF EXISTS (SELECT 1 FROM public.bookings b WHERE lower(b.idempotency_key) = v_computed_idem_key) THEN
  v_computed_idem_key := left(
    md5(v_computed_idem_key || ':' || clock_timestamp()::text)
    || md5(gen_random_uuid()::text),
    64
  );
END IF;
```
**Problema reproduzido no cenário de 6 etapas:**
1. Etapa 1: Reserva `B1` criada com `idempotency_key = k1`.
2. Etapa 2: `B1` é cancelada ou expirada.
3. Etapa 3 & 4: Nova requisição com `k1` cria `B2`, mas `B2.idempotency_key` recebia um hash aleatório (`clock_timestamp()` + `gen_random_uuid()`) sem qualquer relação determinística ou pesquisável com `k1`.
4. Etapa 5 & 6 (Timeout na resposta da Etapa 4 e reenvio de `k1`): A busca por chave (`lower(b.idempotency_key) = v_computed_idem_key`) casava apenas com `B1` (cancelada), e não com `B2` (ativa), perdendo o vínculo de chave entre `k1` e `B2`.

### 1.2. Estratégia de Linhagem Determinística Implementada na Migration `000013`
Criada a migration incremental `supabase/migrations/20261119000013_missao02_6_post_cancel_idempotency.sql` (preservando `000001` a `000012` byte a byte):
1. **Função Pura Determinística `public.derive_idempotency_lineage_key(p_root_key TEXT, p_generation INTEGER)`**:
   - Para `p_generation = 0` (1ª reserva da chave `k1`): retorna a própria chave raiz canônica `k1`.
   - Para `p_generation = g >= 1` (após `g` cancelamentos/expirações na linhagem de `k1`): retorna exatamente a chave determinística de 59 caracteres:
     `'idg-' || left(md5(k1), 24) || '-g' || lpad(g::text, 4, '0') || '-' || left(md5(k1 || ':gen:' || g::text), 24)`
   - Zero uso de `clock_timestamp()` ou `gen_random_uuid()`.
   - Todas as gerações derivadas de `k1` compartilham o prefixo persistente `v_lineage_prefix := 'idg-' || left(md5(k1), 24) || '-g'`.
2. **Resolução Transacional em `public.create_booking_request()`**:
   - Adquire lock exclusivo em `public.vessels` (`FOR UPDATE`) e `pg_advisory_xact_lock(hashtext(vessel_id), hashtext(booking_date))`.
   - Trava (`FOR UPDATE`) e verifica todas as linhas da linhagem (`lower(b.idempotency_key) = v_root_idem_key OR lower(b.idempotency_key) LIKE v_lineage_prefix || '%'`). Se qualquer geração pertencer a outro titular, outro passeio ou outra data, aborta com `IDEMPOTENCY_KEY_CONFLICT` (`23505`).
   - Busca na linhagem de `k1` (ordenada por `CASE WHEN active THEN 0 ELSE 1 END ASC`) se já existe reserva ativa (`B2` criada na Etapa 4). Se existir, retorna imediatamente `B2` com `idempotent_replay = true`, `'idempotency_key', B2.idempotency_key` e `'original_idempotency_key', k1`, sem criar outra reserva e sem consumir vagas duas vezes.
   - Somente se todas as reservas existentes na linhagem de `k1` estiverem inativas (canceladas/recusadas/expiradas), conta `v_inactive_lineage_count` e gera deterministicamente a chave da próxima geração `derive_idempotency_lineage_key(v_root_idem_key, v_inactive_lineage_count)`.

---

## 2. F03 — DIAGNÓSTICO DE BUILD (`npm ci` E `npm run build`) E INSTRUÇÕES REPRODUTÍVEIS

1. **Verificação Estrutural e de Tipagem:**
   - Versões instaladas no container sandbox: `node v18.20.4`, `npm 9.2.0`.
   - `package.json` e `package-lock.json` conferidos: todas as 12 dependências diretas (`@supabase/supabase-js@2.46.1`, `lucide-react@0.454.0`, `react@18.3.1`, `react-dom@18.3.1`, `@types/react@18.3.12`, `@types/react-dom@18.3.1`, `@vitejs/plugin-react@4.3.3`, `autoprefixer@10.4.20`, `postcss@8.4.49`, `tailwindcss@3.4.15`, `typescript@5.6.3`, `vite@5.4.11`) são compatíveis entre si.
   - **Correção preventiva de tipagem estrita (`tsconfig.json` `"strict": true`) aplicada em `src/lib/bookingService.ts`**: ajustados os retornos de `type`, `operationMode`, `tourType`, `vesselType`, `pricingModel` e `status` em `hydrateCatalogAndBookingsSnapshot` para preservar os tipos literais genéricos (`TVessel['type']`, `TTour['tourType']`, etc.) em vez de `string`, evitando erro `TS2322` durante `tsc && vite build`.
2. **Limitação Real do Ambiente Sandbox:**
   - O container sandbox opera sem acesso de rede externa e sem cache local de tarballs npm em `/home/spark/.npm` (`npm ci --offline` retorna `npm ERR! code ENOTCACHED: request to https://registry.npmjs.org/vite/-/vite-5.4.11.tgz failed`). Por esse motivo, **o build de produção com `npm ci` e `npm run build` permanece PENDENTE** de execução em máquina/CI com acesso ao registro npm.
3. **Instruções Reprodutíveis para Execução do Build em Ambiente Externo (Local/CI):**
   ```bash
   cd ubatuba_mar_e_praias_marketplace
   node -v   # Requer Node.js >= 18.18+ ou 20 LTS
   npm -v    # Requer npm >= 9+
   # Caso o lockfile precise expandir a árvore transitiva completa na 1ª execução com rede:
   npm ci || (npm install --package-lock-only && npm ci)
   npm run typecheck
   npm run build
   ```

---

## 3. TABELA DE ARQUIVOS MODIFICADOS E HASHES SHA-256 (64 CARACTERES HEXADECIMAIS)

| Arquivo | Status em 02.6 | Tamanho (Bytes) | SHA-256 Calculado Diretamente do Arquivo |
| :--- | :--- | ---: | :--- |
| `supabase/migrations/20261119000013_missao02_6_post_cancel_idempotency.sql` | **NOVO (02.6)** | `25201` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` |
| `src/lib/bookingService.ts` | **ATUALIZADO (02.6)** | `33172` | `7de3cd95acb4fbd83140166e537b72daf5798d1f5073a5e552de582142d3cf0c` |
| `supabase/tests/run_postgresql_homologation.sh` | **ATUALIZADO (02.6)** | `27766` | `1e27fc31bcfccc26ecc0bd1a5864602a8352bffd6f996a78b15502c3706e0d9b` |
| `supabase/tests/function_inventory.json` | **ATUALIZADO (02.6)** | `228161` | `5b7182021d9aa94b04212e704b9ec718106efc6ec5bf8bf4eb356a99fe1b3ba5` |
| `supabase/tests/homologacao_postgresql_real.sql` | **ATUALIZADO (02.6)** | `110668` | `068e45d41721bb411b047e1d32a9d5045518beaf66e162e118f413fbfebae2c1` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **ATUALIZADO (02.6)** | `40148` | `661677e62ee8e4a77afc3060a2331cfc261bfceda5df9921a804ef32ee137a01` |
| `supabase/tests/run_isolated_test_suite.py` | **ATUALIZADO (02.6)** | `162804` | `68141da7c7f22833374fb9360ea404c382127285a84b72a0a071ff4fd5885563` |
