# ARGON 4 — MISSÃO 02.4 — RELATÓRIO DE VALIDAÇÃO ADVERSARIAL, CORREÇÃO DE RISCOS RESIDUAIS E TESTES DE REGRESSÃO
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
**Base Obrigatória Recebida:** `ubatuba_mar_e_praias_missao02_3_corrigido.zip` (`1.226.843 bytes` | SHA-256 `33b9011769c535eb2ece4758c9265883d5d8a89c801229ae3436ae20dd282631`)
**Pacote Corrigido Entregue:** `ubatuba_mar_e_praias_missao02_4_corrigido.zip` (raiz única `ubatuba_mar_e_praias_marketplace/`)
**Status da Homologação PostgreSQL 15+ Real:** **PENDENTE** (adiada conforme regra obrigatória da Missão 02.4; binários `docker` e `psql` ausentes no container de execução local).

---

## 1. VERIFICAÇÃO DE PROVENIÊNCIA, BACKUP E PRESERVAÇÃO DE MIGRATIONS (`000001` A `000010`)

1. **Pacote de Entrada Verificado:** `ubatuba_mar_e_praias_missao02_3_corrigido.zip` (`1.226.843 bytes`, `63` entradas no arquivo ZIP sendo `51` arquivos e `12` diretórios sob `ubatuba_mar_e_praias_marketplace/`, SHA-256 `33b9011769c535eb2ece4758c9265883d5d8a89c801229ae3436ae20dd282631`).
2. **Backup Integral Pré-Missão 02.4:** Criado e verificado em `ubatuba_mar_e_praias_missao02_3_corrigido_BACKUP_PRE_02_4.zip` (`1.226.843 bytes`, SHA-256 `33b9011769c535eb2ece4758c9265883d5d8a89c801229ae3436ae20dd282631`).
3. **Preservação Byte a Byte das Migrations Históricas (`000001` a `000010`):**
   - `20261108000001_initial_schema.sql`: `17.194 B` | SHA-256 `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` (INTACTA)
   - `20261108000002_rls_and_rpcs.sql`: `3.875 B` | SHA-256 `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` (INTACTA)
   - `20261110000003_missao01_audit_fixes_and_rpcs.sql`: `120.783 B` | SHA-256 `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` (INTACTA)
   - `20261110000004_missao01_official_catalog_seed.sql`: `14.727 B` | SHA-256 `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` (INTACTA)
   - `20261111000005_missao01_4_forensic_hardening.sql`: `58.943 B` | SHA-256 `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` (INTACTA)
   - `20261112000006_missao01_6_forensic_fixes.sql`: `54.113 B` | SHA-256 `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` (INTACTA)
   - `20261113000007_missao01_8_controlled_fixes.sql`: `64.902 B` | SHA-256 `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` (INTACTA)
   - `20261114000008_missao01_9_controlled_fixes.sql`: `36.333 B` | SHA-256 `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` (INTACTA)
   - `20261115000009_missao02_1_residual_fixes.sql`: `49.149 B` | SHA-256 `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` (INTACTA)
   - `20261116000010_missao02_3_surgical_fixes.sql`: `106.563 B` | SHA-256 `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` (INTACTA)

---

## 2. ACHADOS ADVERSARIAIS IDENTIFICADOS E CORRIGIDOS (`M02.4-F01` A `M02.4-F05`)

| Código | Frente | Severidade | Causa Raiz Identificada na Base 02.3 | Correção Cirúrgica Implementada na Missão 02.4 |
| :--- | :--- | :--- | :--- | :--- |
| **`M02.4-F01`** | **Frente A** (Autorização SQL e `SECURITY DEFINER`) | **P1 (Alta)** | 1) Em `000010`, o ramo `v_db_role IN ('none', 'postgres')` incluía `session_user = 'authenticator'`, permitindo que uma conexão do pool PostgREST sem `SET LOCAL ROLE` fosse tratada como contexto administrativo se `v_uid IS NULL`;<br>2) `COALESCE(current_setting('request.jwt.claim.role', true), v_jwt->>'role')` não bloqueava conflito explícito quando ambos estavam definidos com valores divergentes (ex.: `claim.role = 'authenticated'` mas `claims->>'role' = 'anon'` ou `claims->>'sub' <> uid`);<br>3) `is_admin()`, `is_partner_member(UUID)`, `upsert_availability_block()` e `delete_availability_block()` ainda estavam na versão `000007`/`000008` sem validação de `session_user` e sem checagem de conflito GUC vs JSON. | Na migration `000011`, removido `'authenticator'` da exceção `v_db_role IN ('none', 'postgres')` (restrita a `session_user IN ('postgres', 'supabase_admin')`), adicionado bloqueio de divergência entre `v_claim_role` e `v_json_role` e entre `v_uid::text` e `v_json_sub`, e aplicada a guarda unificada de 4 fatores às **14 funções** (`is_admin`, `is_partner_member`, `resolve_booking_actor_role`, `admin_update_booking`, `settle_commission_ledger`, `protect_profile_privileged_columns`, `expire_stale_bookings`, `validate_availability_block_ownership`, `upsert_availability_block`, `delete_availability_block`, `protect_catalog_moderation_columns`, `validate_verified_review`, `create_verified_review`, `admin_anonymize_customer_pii`). |
| **`M02.4-F02`** | **Frente B** (LGPD e Anonimização) | **P1 (Alta)** | 1) Em `000010` (`L963`), `position(lower(v_old_name) in lower(v_review.comment)) > 0` não usava fronteira de palavra, gerando falso positivo para nomes curtos de 3 letras como `'Ana'` em comentário contendo `'banana'`;<br>2) `'costa'` estava em stop-list incondicional, gerando falso negativo quando o cliente `'Rosa Costa'` assinava `'Obrigado, Costa, pelo atendimento!'`;<br>3) Faltava normalização de acentos (`'Joao Silva'` vs `'João Silva'`), sanitização de chaves genéricas (`email`, `phone`, `full_name`, `name`, `actor_name`) em `audit_logs` e trava de imutabilidade para `reviews.is_published`/`created_at` sob token `REVIEW_MUTATION`. | Criada `public.normalize_lgpd_text(TEXT)` em `000011`; substituído `position(...)` por regex com fronteira de palavra no texto normalizado; reduzido o limiar de tokens para `>= 3` letras com remoção contextual apenas de expressões geográficas compostas (`'costa norte'`, `'costa sul'`, `'costa verde'`, `'pela costa'`, `'base marina'`, etc.) antes do teste; sanitizadas todas as 11 chaves sensíveis em `audit_logs` e bloqueada mutação de `is_published`/`created_at` em `validate_verified_review()`. |
| **`M02.4-F03`** | **Frente C** (Moderação e Isolamento Multitenant) | **P1 (Alta)** | Em `000010`, `protect_catalog_moderation_columns()` validava `is_authorized` em `media_assets`, mas não verificava se `NEW.vessel_id` ou `NEW.tour_id` pertenciam ao mesmo `NEW.partner_id`, nem impedia alteração de `is_provisional`, `uploaded_by` ou `reviews_count` por não-admin. | Em `000011`, adicionada validação cruzada `MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN` garantindo que `vessel_id` e `tour_id` em `public.media_assets` pertençam estritamente a `NEW.partner_id`, exigido vínculo ativo `is_partner_member(NEW.partner_id)` e bloqueada alteração de `is_provisional`, `uploaded_by`, `created_at` e `reviews_count` por não-admin. |
| **`M02.4-F04`** | **Frente D** (Idempotência de Reservas) | **P1 (Alta)** | Em `000010`, `p_idempotency_key` não era normalizada para `lower(...)` nem limpa de caracteres de controle antes da verificação de `'lgpd-%'`, e uma mesma chave explícita reutilizada em outro passeio/data ou por outro titular contra reserva cancelada/expirada não lançava `IDEMPOTENCY_KEY_CONFLICT`. | Em `000011`, `p_idempotency_key` é normalizada via `lower(regexp_replace(..., '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$', '', 'g'))`, validada contra `^lgpd-`, comprimento `8..64` e formato `^[a-z0-9._:-]+$`, e verificada quanto à correspondência exata de titular, `tour_id` e `booking_date`. |
| **`M02.4-F05`** | **Frente E** (Frontend, Hidratação e Mocks) | **P1 (Alta)** | Em `src/App.tsx`, `if (snapshot.toursRows.length > 0)` retinha estado antigo quando um snapshot vinha vazio (`[]`), `snapshot.error` não limpava `partners`/`destinations`/`vessels`/`tours`/`availabilityBlocks`/`reviews`, faltava resolução relacional de `tourTitle`/`vesselName`/`partnerName`/`verifiedBookingCode` a partir dos IDs hidratados, `activePartner` podia cair em `partners[0]` de outro parceiro, e `handleAddAvailabilityBlock` não propagava `customCapacityOverride` em `AJUSTE_CAPACIDADE`. | Atualizado `src/App.tsx` (sem alterar layout ou identidade visual) para limpar todas as coleções em erro/snapshot vazio, resolver nomes e códigos relacionalmente por `Map`, isolar `activePartner` por `authorizedPartnerIds`, propagar `customCapacityOverride` em `AJUSTE_CAPACIDADE` e validar os 10 cenários da Frente E com mocks controlados em Node.js. |

---

## 3. TABELA DE HASHES SHA-256 E TAMANHOS DOS ARQUIVOS ALTERADOS/CRIADOS

| Arquivo | Status | Tamanho (Bytes) | SHA-256 |
| :--- | :--- | ---: | :--- |
| `supabase/migrations/20261117000011_missao02_4_adversarial_fixes.sql` | **NOVO** | `113335` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` |
| `src/App.tsx` | **ATUALIZADO** | `326687` | `bf60401ddb7264b01027242ff70e5835ff79c587b5e4c093a774f9830d87c3d7` |
| `supabase/tests/run_postgresql_homologation.sh` | **ATUALIZADO** | `27376` | `7e52bbf53ce31f414eb1c2d7a47f1235e4dc5e224a480a8e1438319909b1bd70` |
| `supabase/tests/function_inventory.json` | **ATUALIZADO** | `171956` | `c4ef1893bbfad061e4e4c0b292ee3d94396a6ccbe9cc68f6f2efaef9a8b62dc5` |
| `supabase/tests/homologacao_postgresql_real.sql` | **ATUALIZADO** | `105285` | `b3402b378e25a03ffc94ce1f782b5da77a0223ee53510fa9bcf27e0764b0a92f` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **ATUALIZADO** | `37764` | `be3454187ab307a056082aeaeba425ce6cc57e86e26c2294c2ae7d9ba98b7f8e` |
| `supabase/tests/run_isolated_test_suite.py` | **ATUALIZADO** | `131066` | `96ae8ea0d29da2dc4771a917dda7d3cb07b38f42224e7a419a1c9fa0c7c0aabc` |
