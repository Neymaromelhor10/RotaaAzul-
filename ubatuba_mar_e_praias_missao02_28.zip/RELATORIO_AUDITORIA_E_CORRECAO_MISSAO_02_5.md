# ARGON 4 — MISSÃO 02.5 — AUDITORIA DE INTEGRIDADE, PROVA DE CORREÇÃO E FECHAMENTO DE PENDÊNCIAS
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
**Base Recebida (Missão 02.4):** `ubatuba_mar_e_praias_missao02_4_corrigido.zip` (`1.283.065 bytes` | SHA-256 `2029c65b7fce2e173a6c65b3152006c47949f67af77cdbda7c6a6ad2ee277aee` | `zipfile.testzip() = None`)
**Backup Integral Pré-02.5:** `ubatuba_mar_e_praias_missao02_4_corrigido_BACKUP_PRE_02_5.zip` (`1.283.065 bytes` | SHA-256 `2029c65b7fce2e173a6c65b3152006c47949f67af77cdbda7c6a6ad2ee277aee`)
**Status de Homologação PostgreSQL 15+ Real e Produção:** **PENDENTE** (não declarada homologação concluída nem prontidão para produção; `docker`, `psql` e acesso de rede para `npm ci` ausentes no sandbox).

---

## 1. F01 — CORREÇÃO E REVALIDAÇÃO DIRETA DOS HASHES SHA-256 (64 CARACTERES HEXADECIMAIS)

No relatório da Missão 02.4, o texto exibiu uma string truncada de 57 caracteres (`7e52bbf53ce31f414eb1c2d7a47f1235e4dc5e224a438319909b1bd70`) ao lado do SHA-256 de 64 caracteres (`7e52bbf53ce31f414eb1c2d7a47f1235e4dc5e224a480a8e1438319909b1bd70`) para `supabase/tests/run_postgresql_homologation.sh` (`27.376 bytes` na base 02.4).
Na Missão 02.5, todos os hashes abaixo foram **recalculados diretamente dos bytes em disco** via `hashlib.sha256()` com verificação automática `len(digest) == 64`:

| Arquivo | Status em 02.5 | Tamanho (Bytes) | SHA-256 Recalculado Diretamente do Arquivo (64 hex chars) |
| :--- | :--- | ---: | :--- |
| `supabase/migrations/20261108000001_initial_schema.sql` | Preservado | `17194` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` |
| `supabase/migrations/20261108000002_rls_and_rpcs.sql` | Preservado | `3875` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` |
| `supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql` | Preservado | `120783` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` |
| `supabase/migrations/20261110000004_missao01_official_catalog_seed.sql` | Preservado | `14727` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` |
| `supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql` | Preservado | `58943` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` |
| `supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql` | Preservado | `54113` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` |
| `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` | Preservado | `64902` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` |
| `supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` | Preservado | `36333` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` |
| `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` | Preservado | `49149` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` |
| `supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql` | Preservado | `106563` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` |
| `supabase/migrations/20261117000011_missao02_4_adversarial_fixes.sql` | Preservado | `113335` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` |
| `supabase/migrations/20261118000012_missao02_5_integrity_closure.sql` | **NOVO (02.5)** | `62476` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` |
| `src/lib/bookingService.ts` | **ATUALIZADO (02.5)** | `33055` | `f781db1df52e7beba76eb87567e7ceadea2c3ecb99e3deea8a2e7d730db7e296` |
| `src/App.tsx` | **ATUALIZADO (02.5)** | `315906` | `a33a12af1496ec70d009edebc4b2b45096c6341129a58133290b156804d95538` |
| `supabase/tests/run_postgresql_homologation.sh` | **ATUALIZADO (02.5)** | `27565` | `1e94899e9d574e18c22a73080c55486e00a8c5af471eec99446fc7a44ec1a550` |
| `supabase/tests/function_inventory.json` | **ATUALIZADO (02.5)** | `199757` | `a66b388bdbad967d72d27864c2eb4241da8963bf898c2932f6360db28645e1bb` |
| `supabase/tests/homologacao_postgresql_real.sql` | **ATUALIZADO (02.5)** | `106963` | `22642835dcc04068fc6975b4e6766bc9efba7ed80c5b989a615f744bf42511a7` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **ATUALIZADO (02.5)** | `39494` | `d2c31c6084974c457e1d90620b1c29ca84e364d231af8ae69c5ad06b1cc70589` |
| `supabase/tests/run_isolated_test_suite.py` | **ATUALIZADO (02.5)** | `145985` | `138e113c25b45d66e552a0d65063cbf88018e6d7631a343eb25d9f947a571150` |
| `supabase/tests/test_runner_destructive_guards.py` | Preservado | `33417` | `3937c95469ee5ee1ec09e1770005a6581a7f4f79d46ecefc76602344bc2fd572` |
| `supabase/tests/test_concorrencia_real_pg.py` | Preservado | `18696` | `57b0ebde9886ba7d643e0d38e70674d7346447ee941a57b2376a37070fa39a58` |
| `supabase/tests/load_stability_plan_pg.py` | Preservado | `49091` | `cd0b522a8b5851c9f42a931a43c6ab205fb749b28d6dadb4fad1473bfc906ec7` |

---

## 2. JUSTIFICATIVA TÉCNICA E PROVA DE REPRODUÇÃO PARA A MIGRATION INCREMENTAL `000012`

Conforme a Seção 9 da Missão 02.5, as migrations `000001` a `000011` foram preservadas byte a byte. A criação da migration incremental `supabase/migrations/20261118000012_missao02_5_integrity_closure.sql` foi exigida por **3 falhas concretas reproduzidas no banco**:

1. **`M02.5-SQL-01` (F03 — `normalize_lgpd_text` com diacríticos combinantes NFD, match de nome completo em `v_norm_comment` bruto, JSONB recursivo das 16 chaves em `audit_logs` e privilégio `EXECUTE` de `normalize_lgpd_text`)**:
   - **Reprodução:** Em `000011` (`L46–63`), `normalize_lgpd_text('Jo' || U&'a\0303' || 'o')` aplicava `translate(...)` (apenas sobre caracteres precompostos NFC) seguido de `regexp_replace(..., '[^a-z0-9]+', ' ', 'g')`, que substituía o diacrítico combinante Unicode `U+0303` por um espaço, gerando `'joa o'` em vez de `'joao'`. Além disso, em `000011` (`L2119`), o match do nome completo testava `v_norm_comment` bruto em vez de `v_norm_comment_geo_stripped`; em `L2172–2229`, `audit_logs` só sanitizava chaves no 1º nível (`?`) e condicionava `changed_by` a `v_old_tourist_uid IS NOT NULL`; e em `L2729`, concedia `GRANT EXECUTE ON FUNCTION public.normalize_lgpd_text(TEXT) TO authenticated`.
   - **Correção em `000012`:** Aplica `normalize(..., NFC)` + remoção de `[̀-ͯ]+` antes do `translate(...)` (sem depender de extensões externas); usa `v_norm_comment_geo_stripped` no match de nome completo e tokens; cria `public.sanitize_lgpd_audit_jsonb(...)` recursiva para objetos e arrays JSONB cobrindo todas as 16 chaves em `old_data` e `new_data`; e revoga `EXECUTE` de `anon` e `authenticated` sobre `normalize_lgpd_text` e `sanitize_lgpd_audit_jsonb`.
2. **`M02.5-SQL-02` (F04 — Validação `MEDIA_TOUR_VESSEL_MISMATCH`, `MEDIA_REQUIRED_ENTITY_LINK_MISSING` e titularidade de `OLD.partner_id` em `protect_catalog_moderation_columns`)**:
   - **Reprodução:** Em `000011` (`L1320–1342`), `protect_catalog_moderation_columns()` validava `vessel_id` e `tour_id` separadamente contra `NEW.partner_id`, mas permitia vincular em `media_assets` um `tour_id` e um `vessel_id` incompatíveis entre si ou remover o vínculo obrigatório da categoria (`vessel_id = NULL` em `category = 'Embarcação'`).
   - **Correção em `000012`:** Valida os valores finais de `NEW` para vínculo obrigatório da categoria (`MEDIA_REQUIRED_ENTITY_LINK_MISSING`), compatibilidade `v_media_tour_vessel = NEW.vessel_id` (`MEDIA_TOUR_VESSEL_MISMATCH`) e exige `public.is_partner_member(OLD.partner_id)` em `UPDATE` por não-admin.
3. **`M02.5-SQL-03` (F05 & F02 — Sombra de `idempotency_key` por `OR ... LIMIT 1` e guarda de 4 fatores para `v_uid` em `create_booking_request`)**:
   - **Reprodução:** Em `000011` (`L2462–2485`), a consulta combinava `lower(b.idempotency_key) = v_computed_idem_key OR (b.tour_id = v_tour.id AND b.booking_date = p_booking_date AND phone = v_phone_digits)` ordenada por `active ASC LIMIT 1`. Se o Titular A tivesse uma reserva cancelada/expirada com `idempotency_key = 'k1'` (`CASE = 1`) e o Titular B (com reserva ativa no mesmo passeio/data, `CASE = 0`) enviasse `p_idempotency_key = 'k1'`, o `LIMIT 1` retornava a reserva ativa do Titular B em vez de bloquear com `IDEMPOTENCY_KEY_CONFLICT`.
   - **Correção em `000012`:** Separa a verificação de colisão de `idempotency_key` (`v_key_match`) antes da busca por `(tour_id, booking_date, phone)` e aplica a guarda de 4 fatores na resolução de `v_uid`.
