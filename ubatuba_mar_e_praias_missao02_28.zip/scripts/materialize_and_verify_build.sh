#!/usr/bin/env -S env -u BASH_ENV -u ENV bash
# ==============================================================================
# UBATUBA MAR & PRAIAS — MISSÃO 02.15.3 (SEÇÕES 5, 6, 8 E 9)
# Utilitário EXCLUSIVO de Desenvolvedor Local / Codespaces para Materialização
# Segura do package-lock.json a partir de https://registry.npmjs.org,
# com backup verificado, rollback automático e validação completa via verify_ci_build.sh.
# ==============================================================================
set -euo pipefail
unset BASH_ENV ENV

if [[ "${CI:-}" == "true" || "${GITHUB_ACTIONS:-}" == "true" ]]; then
  echo "[ABORT_CI_FORBIDDEN] Proibido regenerar package-lock.json durante execução de CI/GitHub Actions!" >&2
  echo "Utilize scripts/verify_ci_build.sh no pipeline de CI." >&2
  exit 1
fi

if [[ "${1:-}" != "--allow-local-lockfile-generation" ]]; then
  echo "[ABORT_MISSING_FLAG] Este script regenera o package-lock.json localmente e NÃO deve ser usado como script de build padrão." >&2
  echo "Para materializar o lockfile uma única vez em máquina local/Codespaces com rede e depois versioná-lo no Git, execute:" >&2
  echo "  bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation" >&2
  exit 1
fi

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

echo "=== 1. Verificando pré-requisitos do ambiente e conectividade com https://registry.npmjs.org ==="
node --version
npm --version
python3 --version
if ! npm ping --registry=https://registry.npmjs.org --fetch-retries=1 --fetch-timeout=5000; then
  echo "[REGISTRY_UNREACHABLE] O registry oficial https://registry.npmjs.org está inacessível neste ambiente." >&2
  echo "Interrompendo a materialização sem alterar package.json ou package-lock.json." >&2
  exit 2
fi

PKG_SHA_BEFORE="$(sha256sum package.json | awk '{print $1}')"
BACKUP_LOCK=".package-lock.json.pre_materialize.bak"

echo "=== 2. Criando e validando backup do package-lock.json original (Seção 5.1 a 5.3) ==="
if [[ -f package-lock.json ]]; then
  ORIG_LOCK_SHA="$(sha256sum package-lock.json | awk '{print $1}')"
  echo "SHA-256 package-lock.json (original): $ORIG_LOCK_SHA"
  cp -f package-lock.json "$BACKUP_LOCK"
  BACKUP_LOCK_SHA="$(sha256sum "$BACKUP_LOCK" | awk '{print $1}')"
  if [[ ! -s "$BACKUP_LOCK" || "$ORIG_LOCK_SHA" != "$BACKUP_LOCK_SHA" ]]; then
    echo "[ABORT_BACKUP_FAILED] Falha ao validar backup do package-lock.json!" >&2
    exit 1
  fi
  echo "[PASS] Backup validado: $BACKUP_LOCK (SHA-256: $BACKUP_LOCK_SHA)"
fi

restore_backup_on_error() {
  local rc=$?
  if [[ $rc -ne 0 && -f "$BACKUP_LOCK" ]]; then
    mv -f "$BACKUP_LOCK" package-lock.json
    echo "[ROLLBACK] package-lock.json original restaurado após falha (exit=$rc)." >&2
  else
    rm -f "$BACKUP_LOCK"
  fi
  exit $rc
}
trap restore_backup_on_error EXIT

echo "=== 3. Removendo lockfile incompleto e node_modules prévio para resolução limpa ==="
rm -rf node_modules package-lock.json

echo "=== 4. Gerando novo package-lock.json via npm real e https://registry.npmjs.org (Seção 5.4) ==="
npm install --package-lock-only --registry=https://registry.npmjs.org --no-audit --no-fund

PKG_SHA_AFTER="$(sha256sum package.json | awk '{print $1}')"
if [[ "$PKG_SHA_BEFORE" != "$PKG_SHA_AFTER" ]]; then
  echo "[ABORT] package.json foi modificado inesperadamente ($PKG_SHA_BEFORE != $PKG_SHA_AFTER)!" >&2
  exit 1
fi

NEW_LOCK_SHA="$(sha256sum package-lock.json | awk '{print $1}')"
echo "SHA-256 package-lock.json (novo):     $NEW_LOCK_SHA"

rm -f "$BACKUP_LOCK"
trap - EXIT

echo "=== 5. Executando homologação completa de instalação limpa (npm ci), testes, typecheck e build ==="
bash --norc --noprofile "$PROJECT_DIR/scripts/verify_ci_build.sh"
