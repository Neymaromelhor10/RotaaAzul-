import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const errors = [];

function checkJson(relPath) {
  const full = path.join(root, relPath);
  if (!fs.existsSync(full)) {
    errors.push(`Arquivo obrigatório ausente: ${relPath}`);
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(full, 'utf8'));
  } catch (err) {
    errors.push(`JSON inválido em ${relPath}: ${err.message}`);
    return null;
  }
}

const pkg = checkJson('package.json');
checkJson('package-lock.json');
checkJson('tsconfig.json');
const vercel = checkJson('vercel.json');

const requiredBabelDevDeps = [
  '@babel/core',
  '@babel/parser',
  '@babel/plugin-transform-modules-commonjs',
  '@babel/preset-react',
  '@babel/preset-typescript',
  '@babel/traverse',
];

if (pkg) {
  if (!pkg.engines || !pkg.engines.node) {
    errors.push('package.json deve declarar engines.node compatível.');
  }
  for (const reqScript of ['build', 'typecheck', 'lint', 'test']) {
    if (!pkg.scripts || !pkg.scripts[reqScript]) {
      errors.push(`package.json deve declarar script "${reqScript}".`);
    }
  }
  for (const babelPkg of requiredBabelDevDeps) {
    if (!pkg.devDependencies || !pkg.devDependencies[babelPkg]) {
      errors.push(`package.json deve declarar "${babelPkg}" em devDependencies para reprodutibilidade AST/Babel.`);
    }
  }
}

if (vercel) {
  if (!Array.isArray(vercel.rewrites) || vercel.rewrites.length === 0) {
    errors.push('vercel.json deve configurar rewrites para fallback de rotas SPA.');
  }
}

// Verify that test suites do not hardcode /usr/share/nodejs or global NODE_PATH
for (const testRel of [
  'supabase/tests/verify_pg_contracts_and_ast.py',
  'supabase/tests/run_isolated_test_suite.py',
]) {
  const full = path.join(root, testRel);
  if (fs.existsSync(full)) {
    const content = fs.readFileSync(full, 'utf8');
    if (content.includes('/usr/share/nodejs')) {
      errors.push(`${testRel} contém caminho absoluto proibido /usr/share/nodejs.`);
    }
  }
}

// Check for forbidden VITE_ secret exposure across src/, index.html, .env.example
const scanFiles = [
  'index.html',
  '.env.example',
  'src/main.tsx',
  'src/App.tsx',
  'src/lib/runtimeConfig.ts',
  'src/lib/supabaseClient.ts',
  'src/lib/bookingService.ts',
  'src/lib/operationsService.ts',
  'src/lib/financialService.ts',
  'src/lib/authTypes.ts',
  'src/lib/authValidation.ts',
  'src/lib/authSession.ts',
  'src/lib/authGuards.ts',
  'src/lib/authService.ts',
  'src/lib/partnerOnboardingService.ts',
  'src/types/database.types.ts',
];

const forbiddenViteSecrets = [
  /VITE_SUPABASE_SERVICE_ROLE/i,
  /VITE_.*SECRET/i,
  /VITE_.*PASSWORD/i,
  /VITE_DATABASE_URL/i,
];

for (const rel of scanFiles) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) {
    errors.push(`Arquivo ausente para lint: ${rel}`);
    continue;
  }
  const content = fs.readFileSync(full, 'utf8');
  for (const pattern of forbiddenViteSecrets) {
    if (pattern.test(content)) {
      errors.push(`Possível exposição de segredo com prefixo VITE_ em ${rel}: ${pattern}`);
    }
  }
}

// Check that App.tsx does not initialize state directly with INITIAL_* without canUseDemoData
const appContent = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');
if (!appContent.includes('runtimeGuard.isConfigurationUnavailable')) {
  errors.push('src/App.tsx não verifica runtimeGuard.isConfigurationUnavailable.');
}
if (!appContent.includes('const canUseDemoData =')) {
  errors.push('src/App.tsx não define a guarda canUseDemoData.');
}

// Run tsc --noEmit when local TypeScript binary is installed (after npm ci)
const localTsc = path.join(root, 'node_modules', '.bin', 'tsc');
if (fs.existsSync(localTsc)) {
  try {
    execFileSync(localTsc, ['--noEmit'], { stdio: 'inherit' });
  } catch {
    errors.push('Falha na verificação TypeScript (tsc --noEmit).');
  }
} else {
  console.log('[LINT INFO] node_modules/.bin/tsc ausente neste ambiente; verificação estrutural/segurança executada.');
}

if (errors.length > 0) {
  for (const e of errors) {
    console.error(`[LINT FAIL] ${e}`);
  }
  process.exit(1);
}

console.log('[LINT PASS] Configurações JSON, devDependencies @babel/*, ausência de /usr/share/nodejs, guarda de segredos VITE_ e proteção anti-demo validados.');
