#!/usr/bin/env -S env -u BASH_ENV -u ENV bash
# ==============================================================================
# UBATUBA MAR & PRAIAS — MISSÃO 02.15.3 (SEÇÕES 5, 6, 7, 8 E 9)
# Script de Homologação Reprodutível de CI (PROÍBE regenerar package-lock.json!)
# ==============================================================================
set -euo pipefail
unset BASH_ENV ENV

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

echo "=== 1. Verificando versões de Node.js, npm e Python ==="
node --version
npm --version
python3 --version

PKG_SHA_BEFORE="$(sha256sum package.json | awk '{print $1}')"
LOCK_SHA_BEFORE="$(sha256sum package-lock.json | awk '{print $1}')"
echo "SHA-256 package.json (antes):      $PKG_SHA_BEFORE"
echo "SHA-256 package-lock.json (antes): $LOCK_SHA_BEFORE"

echo "=== 2. Validando estrutura JSON, lockfileVersion, dependências diretas, árvore transitiva e sha512 (Seção 5.5 a 5.9) ==="
node -e '
const fs = require("fs");
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const lock = JSON.parse(fs.readFileSync("package-lock.json", "utf8"));
if (lock.lockfileVersion !== 3) {
  console.error("[LOCKFILE_ERROR] lockfileVersion deve ser 3 (encontrado: " + lock.lockfileVersion + ")");
  process.exit(2);
}
const lockPackages = lock.packages || {};
const lockKeys = Object.keys(lockPackages).filter((k) => k !== "");
const directDeps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
const missingDirect = Object.keys(directDeps).filter((d) => !lockPackages["node_modules/" + d]);
const missingIntegrity = lockKeys.filter((k) => !lockPackages[k].integrity || !String(lockPackages[k].integrity).startsWith("sha512-"));
if (lockKeys.length < 50 || missingDirect.length > 0 || missingIntegrity.length > 0) {
  console.error("[LOCKFILE_INCOMPLETE] package-lock.json versionado possui " + lockKeys.length + " pacotes, " + missingDirect.length + " dependências diretas ausentes (" + missingDirect.join(", ") + ") e " + missingIntegrity.length + " pacotes sem sha512 integrity.");
  console.error("Execute uma única vez em ambiente com rede (Codespaces): bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation e faça commit do package-lock.json.");
  process.exit(3);
}
console.log("[PASS] Lockfile versionado íntegro:", lockKeys.length, "pacotes,", Object.keys(directDeps).length, "dependências diretas presentes e 100% com sha512 integrity.");
'

echo "=== 3. Executando instalação limpa obrigatória (rm -rf node_modules && npm ci --no-audit --no-fund) (Seção 6) ==="
rm -rf node_modules
npm ci --no-audit --no-fund

if [[ ! -d node_modules ]]; then
  echo "[ABORT] Diretório node_modules não foi criado após npm ci!" >&2
  exit 1
fi

PKG_SHA_AFTER="$(sha256sum package.json | awk '{print $1}')"
LOCK_SHA_AFTER="$(sha256sum package-lock.json | awk '{print $1}')"

if [[ "$PKG_SHA_BEFORE" != "$PKG_SHA_AFTER" || "$LOCK_SHA_BEFORE" != "$LOCK_SHA_AFTER" ]]; then
  echo "[ABORT] package.json ou package-lock.json foi alterado durante npm ci!" >&2
  exit 1
fi

echo "=== 4. Comprovando resolução local dos 6 módulos Babel sem NODE_PATH e sem /usr/share/nodejs (Seção 6) ==="
env -u NODE_PATH node -e '
const path = require("path");
const { createRequire } = require("module");
const projectRequire = createRequire(path.join(process.cwd(), "package.json"));
const expectedPrefix = path.join(process.cwd(), "node_modules") + path.sep;
for (const modName of [
  "@babel/core",
  "@babel/parser",
  "@babel/traverse",
  "@babel/preset-typescript",
  "@babel/preset-react",
  "@babel/plugin-transform-modules-commonjs"
]) {
  const resolved = projectRequire.resolve(modName);
  if (!resolved.startsWith(expectedPrefix) || resolved.includes("/usr/share/nodejs")) {
    console.error("[BABEL_RESOLUTION_FAIL]", modName, "resolvido fora de node_modules local:", resolved);
    process.exit(1);
  }
  console.log("[PASS] Resolução local comprovada:", modName, "->", path.relative(process.cwd(), resolved));
}
'

echo "=== 5. Executando testes obrigatórios (Seção 7) ==="
npm run lint
python3 supabase/tests/test_runner_destructive_guards.py
python3 supabase/tests/verify_pg_contracts_and_ast.py
python3 supabase/tests/run_isolated_test_suite.py
node scripts/test_runtime_demo_guard.mjs
npm test

echo "=== 6. Executando TypeScript typecheck e Build de Produção (Seção 8) ==="
rm -rf dist
npm run typecheck
npx --no-install tsc --noEmit
npm run build

echo "=== 7. Auditando artefatos gerados em dist/ (Seção 8) ==="
node -e '
const fs = require("fs");
const path = require("path");
const distDir = path.join(process.cwd(), "dist");
if (!fs.existsSync(path.join(distDir, "index.html")) || !fs.existsSync(path.join(distDir, "assets"))) {
  console.error("[DIST_FAIL] dist/index.html ou dist/assets ausente após npm run build!");
  process.exit(1);
}
const assetFiles = fs.readdirSync(path.join(distDir, "assets"));
if (assetFiles.length === 0) {
  console.error("[DIST_FAIL] Nenhum bundle gerado em dist/assets!");
  process.exit(1);
}
for (const f of assetFiles) {
  const full = path.join(distDir, "assets", f);
  if (!fs.statSync(full).isFile()) continue;
  const content = fs.readFileSync(full, "utf8");
  if (/SUPABASE_SERVICE_ROLE_KEY|VITE_SUPABASE_SERVICE_ROLE/i.test(content)) {
    console.error("[DIST_SECRET_LEAK] Referência a chave privada detectada em", f);
    process.exit(1);
  }
}
console.log("[PASS] Artefatos dist/ validados:", assetFiles.length, "arquivos em dist/assets/ sem exposição de segredos.");
'

echo "=== [SUCESSO] Homologação completa de instalação limpa (npm ci), Babel local, testes, typecheck e build concluída! ==="
