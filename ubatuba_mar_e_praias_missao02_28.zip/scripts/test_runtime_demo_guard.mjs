import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const runtimeTsPath = path.join(root, 'src/lib/runtimeConfig.ts');
const tsSource = fs.readFileSync(runtimeTsPath, 'utf8');

// Transpile runtimeConfig.ts cleanly for Node.js execution without requiring external packages
const jsSource = tsSource
  .replace(/export interface\s+\w+\s*\{[\s\S]*?\n\}/g, '')
  .replace(/export function\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*:\s*[^{]+/g, (_, name, args) => {
    const cleanArgs = args.replace(/\??:\s*[^,)]+/g, '').replace(/\?/g, '');
    return `function ${name}(${cleanArgs})`;
  })
  .replace(/function\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*:\s*[^{]+/g, (_, name, args) => {
    const cleanArgs = args.replace(/\??:\s*[^,)]+/g, '').replace(/\?/g, '');
    return `function ${name}(${cleanArgs})`;
  })
  .replace(/\bas\s+unknown\s+as\s+\{[^}]+\}/g, '')
  .replace(/import\.meta/g, '({ env: {} })')
  + '\nmodule.exports = { evaluateRuntimeGuard, readViteRuntimeEnv };\n';

const mod = { exports: {} };
vm.runInNewContext(jsSource, { module: mod, exports: mod.exports, URL });
const { evaluateRuntimeGuard } = mod.exports;

// 1. NEGATIVE TEST: Production without Supabase env vars MUST block demo and mark unavailable
{
  const res = evaluateRuntimeGuard({
    PROD: true,
    MODE: 'production',
    VITE_APP_ENV: 'production',
    VITE_SUPABASE_URL: '',
    VITE_SUPABASE_ANON_KEY: '',
  });
  assert.equal(res.isProductionRuntime, true);
  assert.equal(res.isSupabaseConfigured, false);
  assert.equal(res.isDemoModeAllowed, false);
  assert.equal(res.isConfigurationUnavailable, true);
  assert.equal(res.runtimeBlockReason, 'MISSING_SUPABASE_CONFIG_IN_PRODUCTION');
}

// 2. NEGATIVE TEST: Production with explicit VITE_ENABLE_DEMO_MODE=true MUST fail closed
{
  const res = evaluateRuntimeGuard({
    PROD: true,
    MODE: 'production',
    VITE_APP_ENV: 'production',
    VITE_ENABLE_DEMO_MODE: 'true',
    VITE_SUPABASE_URL: 'https://example.supabase.co',
    VITE_SUPABASE_ANON_KEY: 'anon-key-valid',
  });
  assert.equal(res.isProductionRuntime, true);
  assert.equal(res.isDemoModeRequested, true);
  assert.equal(res.isDemoBlockedInProduction, true);
  assert.equal(res.isDemoModeAllowed, false);
  assert.equal(res.isConfigurationUnavailable, true);
  assert.equal(res.runtimeBlockReason, 'DEMO_MODE_FORBIDDEN_IN_PRODUCTION');
}

// 3. NEGATIVE TEST: Production with placeholder <...> values MUST be rejected
{
  const res = evaluateRuntimeGuard({
    PROD: true,
    MODE: 'production',
    VITE_SUPABASE_URL: '<SUA_SUPABASE_PROJECT_URL_EX_HTTPS_XYZ_SUPABASE_CO>',
    VITE_SUPABASE_ANON_KEY: '<SUA_SUPABASE_ANON_PUBLIC_KEY>',
  });
  assert.equal(res.isSupabaseConfigured, false);
  assert.equal(res.isDemoModeAllowed, false);
  assert.equal(res.isConfigurationUnavailable, true);
  assert.equal(res.runtimeBlockReason, 'MISSING_SUPABASE_CONFIG_IN_PRODUCTION');
}

// 4. NEGATIVE TEST: Development with VITE_ENABLE_DEMO_MODE=false and no Supabase MUST block demo
{
  const res = evaluateRuntimeGuard({
    PROD: false,
    MODE: 'development',
    VITE_APP_ENV: 'development',
    VITE_ENABLE_DEMO_MODE: 'false',
    VITE_SUPABASE_URL: '',
    VITE_SUPABASE_ANON_KEY: '',
  });
  assert.equal(res.isProductionRuntime, false);
  assert.equal(res.isSupabaseConfigured, false);
  assert.equal(res.isDemoModeAllowed, false);
  assert.equal(res.isConfigurationUnavailable, true);
}

// 5. POSITIVE TEST: Production with valid Supabase config and demo disabled
{
  const res = evaluateRuntimeGuard({
    PROD: true,
    MODE: 'production',
    VITE_APP_ENV: 'production',
    VITE_ENABLE_DEMO_MODE: 'false',
    VITE_SUPABASE_URL: 'https://projref.supabase.co',
    VITE_SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test',
  });
  assert.equal(res.isProductionRuntime, true);
  assert.equal(res.isSupabaseConfigured, true);
  assert.equal(res.isDemoModeAllowed, false);
  assert.equal(res.isDemoBlockedInProduction, false);
  assert.equal(res.isConfigurationUnavailable, false);
  assert.equal(res.runtimeBlockReason, 'NONE');
}

// 6. POSITIVE TEST: Local development fallback preserved when Supabase is absent and demo not disabled
{
  const res = evaluateRuntimeGuard({
    PROD: false,
    MODE: 'development',
    VITE_APP_ENV: 'development',
    VITE_SUPABASE_URL: '',
    VITE_SUPABASE_ANON_KEY: '',
  });
  assert.equal(res.isProductionRuntime, false);
  assert.equal(res.isSupabaseConfigured, false);
  assert.equal(res.isDemoModeAllowed, true);
  assert.equal(res.isConfigurationUnavailable, false);
}

// 7. STRUCTURAL INTEGRATION CHECK: App.tsx & supabaseClient.ts wire runtimeGuard fail-closed
{
  const appTsx = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');
  const clientTs = fs.readFileSync(path.join(root, 'src/lib/supabaseClient.ts'), 'utf8');
  assert.ok(clientTs.includes('evaluateRuntimeGuard'), 'supabaseClient.ts must use evaluateRuntimeGuard');
  assert.ok(appTsx.includes('if (runtimeGuard.isConfigurationUnavailable)'), 'App.tsx must render unavailable state');
  assert.ok(!appTsx.includes('isSupabaseConfigured ? [] : loadPersisted'), 'App.tsx must gate demo persistence on canUseDemoData');
  assert.ok(appTsx.includes('canUseDemoData ? INITIAL_ITINERARIES : []'), 'itineraries must be gated by canUseDemoData');
}

console.log('[TEST PASS] 7/7 cenários positivos, negativos e estruturais de bloqueio de demo em produção aprovados.');
