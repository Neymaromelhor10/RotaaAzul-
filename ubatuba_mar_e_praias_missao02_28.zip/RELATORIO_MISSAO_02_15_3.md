# ARGON 4 — MISSÃO 02.15.3 — RELATÓRIO TÉCNICO DE MATERIALIZAÇÃO DO PACKAGE-LOCK, INSTALAÇÃO LIMPA, TYPECHECK E BUILD DE PRODUÇÃO

**Veredito Oficial (Seção 14)**: **`PARCIALMENTE CONCLUÍDA`** *(Scripts de materialização e homologação endurecidos com todas as garantias das Seções 5, 6, 8 e 9, e 100% dos testes executáveis aprovados com `EXIT_CODE=0`; materialização do `package-lock.json`, `npm ci`, `typecheck` e `build` permanecem pendentes exclusivamente por bloqueio de saída de rede para `https://registry.npmjs.org` neste container).*

---

## 1. IDENTIFICAÇÃO E INTEGRIDADE DA BASE (`02.15.2` -> `02.15.3`)

| Item | Valor Verificado |
| :--- | :--- |
| **Base Recebida (`02.15.2`)** | `ubatuba_mar_e_praias_missao02_15_2.zip` (`1.503.688 bytes`, `77 arquivos`) |
| **SHA-256 Esperado e Confirmado (`02.15.2`)** | `ffb98e901b86282144b75d139482834e51361ed01e7ed1e1fda0b239baf2d8a2` |
| **Pacote Entregue (`02.15.3`)** | `ubatuba_mar_e_praias_missao02_15_3.zip` |
| **SHA-256 do ZIP Entregue (`02.15.3`)** | `__ZIP_SHA256__` |
| **SHA-256 do `package.json`** | `cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379` |
| **SHA-256 do `package-lock.json`** | `ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013` |
| **Quantidade de Migrations Confirmadas** | `18 migrations` (`000001` a `000018`, 100% preservadas byte a byte) |

---

## 2. PRÉ-REQUISITOS DO AMBIENTE E CONECTIVIDADE (SEÇÃO 3)

Resultados reais obtidos no container Linux:
- **`node --version`**: `v18.20.4`
- **`npm --version`**: `9.2.0`
- **`python3 --version`**: `Python 3.11.2`
- **`npm ping --registry=https://registry.npmjs.org`**:
  ```text
  npm notice PING https://registry.npmjs.org/
  npm ERR! code EAI_AGAIN
  npm ERR! syscall getaddrinfo
  npm ERR! errno EAI_AGAIN
  npm ERR! request to https://registry.npmjs.org/-/ping?write=true failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org
  NPM_PING_EXIT=1
  ```
- **Cumprimento Estrito da Seção 3**: Como o registry oficial `https://registry.npmjs.org` está inacessível a partir deste container sem internet externa, nenhum lockfile ou hash `sha512` foi fabricado ou inventado, nenhum `npm ci` foi simulado e o build não foi declarado aprovado sem execução real.

---

## 3. AUDITORIA DO `package.json` E LISTA DE ARQUIVOS MODIFICADOS (SEÇÕES 4 E 13.6)

- **`package.json` (`cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379`)**: Revisado e preservado sem alterações; contém as 4 dependências de produção (`@supabase/supabase-js`, `lucide-react`, `react`, `react-dom`), as 14 dependências de desenvolvimento (incluindo os 6 pacotes `@babel/*`: `@babel/core`, `@babel/parser`, `@babel/plugin-transform-modules-commonjs`, `@babel/preset-react`, `@babel/preset-typescript`, `@babel/traverse`), `engines` (`node >=18.20.0 <21.0.0`, `npm >=9.0.0`) e todos os scripts (`dev`, `build`, `typecheck`, `lint`, `test`, `preview`, `test:static`, `test:isolated`, `test:demo-guard`, `test:pg`).
- **`src/App.tsx`, `src/lib/bookingService.ts`, `src/lib/runtimeConfig.ts` e `src/lib/supabaseClient.ts`**: **100% preservados byte a byte**.
- **Arquivos modificados em `02.15.3`** (exclusivamente para incorporar todas as validações automatizadas exigidas nas Seções 5, 6, 8 e 9):

| Arquivo Modificado | SHA-256 Antes (`02.15.2`) | SHA-256 Depois (`02.15.3`) |
| :--- | :--- | :--- |
| `scripts/materialize_and_verify_build.sh` | `5e780f3ca0abd60cf7f7a98ec9f11b65debd26bd7dbedb8bd65a379625d90d77` | `a6da3c48071c39aa8f14ad2441aa7243231b836793ba8fd4e29b9e760610d4b4` |
| `scripts/verify_ci_build.sh` | `23ed63398a3cd4f9bcea93572272da0a86de9be9ac57f261b52ae953406a2862` | `361311ea73258ad7fcfd809f37a20c468c9a24a6748efc5ba32ad29f92bc32e3` |

---

## 4. HASHES SHA-256 DAS 18 MIGRATIONS ANTES E DEPOIS (SEÇÕES 11 E 13.7)

| # | Migration SQL (`supabase/migrations/`) | SHA-256 Antes (`02.15.2`) | SHA-256 Depois (`02.15.3`) | Status |
| :---: | :--- | :--- | :--- | :---: |
| 01 | `20261108000001_initial_schema.sql` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **IDÊNTICO** |
| 02 | `20261108000002_rls_and_rpcs.sql` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **IDÊNTICO** |
| 03 | `20261110000003_missao01_audit_fixes_and_rpcs.sql` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **IDÊNTICO** |
| 04 | `20261110000004_missao01_official_catalog_seed.sql` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **IDÊNTICO** |
| 05 | `20261111000005_missao01_4_forensic_hardening.sql` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **IDÊNTICO** |
| 06 | `20261112000006_missao01_6_forensic_fixes.sql` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **IDÊNTICO** |
| 07 | `20261113000007_missao01_8_controlled_fixes.sql` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **IDÊNTICO** |
| 08 | `20261114000008_missao01_9_controlled_fixes.sql` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | **IDÊNTICO** |
| 09 | `20261115000009_missao02_1_residual_fixes.sql` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | **IDÊNTICO** |
| 10 | `20261116000010_missao02_3_surgical_fixes.sql` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | **IDÊNTICO** |
| 11 | `20261117000011_missao02_4_adversarial_fixes.sql` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | **IDÊNTICO** |
| 12 | `20261118000012_missao02_5_integrity_closure.sql` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | **IDÊNTICO** |
| 13 | `20261119000013_missao02_6_post_cancel_idempotency.sql` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | **IDÊNTICO** |
| 14 | `20261120000014_missao02_7_lineage_persistence_and_hardening.sql` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | **IDÊNTICO** |
| 15 | `20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | **IDÊNTICO** |
| 16 | `20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | **IDÊNTICO** |
| 17 | `20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | **IDÊNTICO** |
| 18 | `20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql` | `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda` | `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda` | **IDÊNTICO** |

---

## 5. SAÍDA INTEGRAL E RESULTADOS DOS COMANDOS EXECUTADOS (SEÇÕES 7, 8, 9 E 13.8 A 13.13)

### 5.1. `npm run lint` (`EXIT_CODE=0` — **APROVADO**)
```text
> ubatuba-mar-e-praias-marketplace@2.0.0 lint
> node scripts/run_lint.mjs

[LINT INFO] node_modules/.bin/tsc ausente neste ambiente; verificação estrutural/segurança executada.
[LINT PASS] Configurações JSON, devDependencies @babel/*, ausência de /usr/share/nodejs, guarda de segredos VITE_ e proteção anti-demo validados.
```

### 5.2. `python3 supabase/tests/test_runner_destructive_guards.py` (`EXIT_CODE=0` — **APROVADO**)
```text
[PASS] [GUARD-00-SAME-SESSION-AND-ATOMIC-REAPPLY] Bloco atômico único DO $guard$ na mesma sessão psql, unset PG* e reaplicação --single-transaction verificados (pos_id=554, pos_inet=614 < pos_drop=3874, total_drops=1).
[PASS] [GUARD-01-DOCKER-AUTORIZADO] Container descartável autorizado validou identidade, executou reset na mesma sessão e limpou container ao final (rc=0).
[PASS] [GUARD-02-HOMOLOG-AUTORIZADO] Banco local 'ubatuba_homolog_ci_01' com confirmação explícita aprovado na mesma sessão (rc=0).
[PASS] [GUARD-03-HOST-EXTERNO-BLOQUEADO] Banco externo (db.aphheooljbmldpjeyuim.supabase.co) bloqueado ANTES de qualquer invocação psql (rc=3).
[PASS] [GUARD-04-NOME-PRODUCAO-BLOQUEADO] Todos os 6 nomes com indicadores de produção foram bloqueados ANTES do psql.
[PASS] [GUARD-05-URL-SEM-ID-CONFIAVEL-BLOQUEADA] Todas as 4 URLs padrão/sem identificação confiável foram bloqueadas ANTES do psql.
[PASS] [GUARD-06-FALHA-CONSULTA-ID-BLOQUEADA] Falha na consulta de identificação e retorno vazio abortaram em modo fail-closed ANTES do DROP (rc6a=1, rc6b=1).
[PASS] [GUARD-07-SEM-CONFIRMACAO-BLOQUEADO] Execução sem UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB bloqueada imediatamente ANTES do psql (rc=3).
[PASS] [GUARD-08-CONEXAO-NAO-AUTORIZADA-NA-SESSAO-BLOQUEADA] Divergência de current_database(), inet_server_addr() remoto e current_user inválido abortaram dentro do bloco atômico DO $guard$ ANTES do DROP.
[PASS] [GUARD-09-CONTAINER-OWNERSHIP-PROTECTION] Proteção de propriedade impediu encerrar container pertencente a outro run_id (rc=3).
[PASS] [GUARD-10-PASSWORD-AT-AND-QUERY-PARAMS] Senha com '@' suportada (rc=0) e todos os 8 parâmetros de redirecionamento (?host=, ?hostaddr=, ?dbname=, ?user=, ?service=, etc.) bloqueados ANTES do psql.
[PASS] [GUARD-11-MALFORMED-AND-AMBIGUOUS-URLS] Todas as 5 URLs ambíguas/malformadas foram rejeitadas ANTES de invocar o psql.
[PASS] [GUARD-12-EXIT-CODE-PRESERVATION-AND-CLEANUP] Cleanup do container executou em falha subsequente e preservou exatamente o código de saída original (rc=42).
[PASS] [GUARD-13-PORT-COLLISION-DETECTION] Colisão na porta local 55499 detectada e bloqueada com PORT_IN_USE antes do docker run (rc=3).
[PASS] [GUARD-14-QUERY-AT-SPOOF-AND-LIBPQ-ENV-UNSET] Spoofing de host via '@' na query string, '%', '#' e params fora da whitelist bloqueados ANTES do psql; variáveis PGHOST/PGDATABASE/PGSERVICE neutralizadas.
[PASS] [GUARD-15-CONTAINER-PREEXISTENCE-COLLISION] Container preexistente com mesmo nome detectado e bloqueado com CONTAINER_ALREADY_EXISTS antes do docker run (rc=3).
==============================================================================
RESULTADO DA SUÍTE DE GUARDA DO RUNNER (GUARD-00 A GUARD-15): 16/16 APROVADOS
==============================================================================
```

### 5.3. `python3 supabase/tests/verify_pg_contracts_and_ast.py` (`EXIT_CODE=0` — **APROVADO**)
```text
[STATIC PASS] [STATIC-01] Auditoria A: Nenhuma variável GUC controlável por sessão (app.*) é lida ou utilizada em todo o código executável de 000003 a 000009.
[STATIC PASS] [STATIC-02] Auditoria A/C & M01.5-05/06: Guardião internal_guard.execution_tokens com validação 't.trigger_depth = pg_trigger_depth() - 1', cleanup_tokens() e 7 escopos ativos.
[STATIC PASS] [STATIC-03] Auditoria B: Inventário extraído corresponde 1:1 a function_inventory.json -> 000003=31 funções | Acumulado pós-000009=49 funções ativas (40 SECURITY DEFINER + 9 SECURITY INVOKER), 100% com 'SET search_path = pg_catalog, ...' (0 vulneráveis).
[STATIC PASS] [STATIC-04] Auditoria B: Criação de objetos em public revogada de PUBLIC e permissão EXECUTE default revogada de PUBLIC em todas as funções ativas.
[STATIC PASS] [STATIC-05] Auditoria C: 19/19 tabelas públicas + internal_guard.execution_tokens com RLS habilitado e REVOKE de escrita direta para anon/authenticated.
[STATIC PASS] [STATIC-06] Auditoria D: Corpo ativo final pós-000009 validado nas 12 rotinas concorrentes (0 fora de ordem), revalidação FOR UPDATE antes de issue_token, bloqueio de INSERT direto e índice UNIQUE NULLS NOT DISTINCT.
[STATIC PASS] [STATIC-07] Auditoria E: Livro-razão blindado contra alteração de valores, inserção manual, liquidação direta fora da RPC, exclusão (BEFORE DELETE) e pagamento duplo.
[STATIC PASS] [STATIC-08] Auditoria F: Contratos de estados, 5 chamadas RPC importadas, 0 tipos não declarados e transpilação AST validados via resolvedor Python + AST @babel/parser/@babel/traverse/@babel/core (resolução local createRequire).
[STATIC PASS] [STATIC-09] Higiene & Seed: 0 arquivos SQL duplicados, 6/6 INSERTs idempotentes no seed 000004, 5 imagens em public/media/, Tailwind/PostCSS configurado, CORS restrito e 0 dados de clientes nos backups.
[STATIC PASS] [STATIC-10] Missão 01.8 (M01.7-001 a M01.7-010): Capacidade reversa em tours, email_confirmed_at sem DEFAULT now(), guarda 4-fatores nas RPCs de agenda, conflito de passageiros e limpeza sem DISABLE TRIGGER comprovados.
[STATIC PASS] [STATIC-11] Missões 01.9, 02.1 & 02.2 (M02.2-F01 a F08): Guarda 4-fatores em resolve_booking_actor_role/admin_update_booking/settle_commission_ledger, blindagem LGPD_IMMUTABLE_OPERATIONAL_FIELDS, unset PG*, BrokenBarrierError e T9.1..T9.16 comprovados.
[STATIC PASS] [STATIC-12] Validação Dinâmica Cruzada Schema SQL x Queries (M02.0-F01 & M02.2-F07): 20 tabelas, 7 enums e 108 bindings dinâmicos validados (0 divergências).
[STATIC PASS] [STATIC-13] Missões 02.4 & 02.5 (F01 a F07): Guarda 4-fatores nas 14 funções, normalize_lgpd_text com NFD, sanitize_lgpd_audit_jsonb recursivo nas 16 chaves, proteção media_assets, separação de idempotency_key e funções reais exportadas em bookingService.ts/App.tsx comprovados.
[STATIC PASS] [STATIC-14] Missão 02.8 (F01 a F05): Migration 000015, backfill autenticado por token, linhagem LGPD (lgpd-lin-<root24>-<scope20>), 42 funções ativas (32 SD + 10 SI) com pg_temp final, REVOKE universal anon/authenticated e T9.22 comprovados.
[STATIC PASS] [STATIC-15] Parsing Estrutural SQL (M02.8-F02 a M02.12): 18/18 migrations parseadas sem erros (0 erros) e 49/49 funções com search_path iniciando em pg_catalog e terminando explicitamente em pg_temp (0 com schema auth supérfluo).
[STATIC PASS] [STATIC-16] Missão 02.9 (Seções 3 a 6): Migration 000016 (lineage_hmac_keys, compute/verify/rotate_lineage_mac, idg-root-, LINEAGE_BACKFILL_LGPD_DOWNGRADE_FORBIDDEN, INVALID_EXECUTION_TOKEN_PARAMETERS), workflow CI com permissions: contents: read, jobs separados e proibição de regenerar lockfile em CI comprovados.
[STATIC PASS] [STATIC-17] Missão 02.10 (Seções 3 a 8): Migration 000017 com HMAC-SHA-256 (RFC 2104 / 4 vetores RFC 4231), CSPRNG gen_random_bytes(32) fail-closed, FORCE RLS, uq_lineage_hmac_keys_single_active, trigger anti-exclusão/anti-mutação de chaves, REVOKE direto de tabelas para service_role e 8/8 funções internal_guard sem schema public no search_path.
[STATIC PASS] [STATIC-18] Missão 02.12 (M02.11-F01 a F05): Migration 000018 com compatibilidade legada restrita a registros existentes, 4 colunas de versão de chave HMAC por artefato, CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED, verificação O(1) por versão, derive_idempotency_lineage_key SECURITY DEFINER e revogação de oráculos em service_role comprovados.
```

### 5.4. `python3 supabase/tests/run_isolated_test_suite.py` (`EXIT_CODE=0` — **APROVADO**)
```text
[STATIC PASS] [BANCO DE DADOS] BD-01: Aplicação das migrations do zero — 9 migrations (000001, 000002, 000003, 000004, 000005, 000006, 000007, 000008, 000009) verificadas e schema inicializado do zero sem erros.
[SIMULAÇÃO SQLITE PASS] [BANCO DE DADOS] BD-02: Aplicação das migrations sobre estrutura existente (Idempotência) — Reaplicação idempotente concluída sem duplicação (3 parceiros, 4 passeios).
[SIMULAÇÃO SQLITE PASS] [BANCO DE DADOS] BD-03: Integridade de chaves estrangeiras e vínculo Parceiro-Embarcação — Trigger/FK impediu criação de passeio vinculando embarcação pertencente a outro parceiro.
[SIMULAÇÃO SQLITE PASS] [BANCO DE DADOS] BD-04: Validação de constraints (vessel_type Catamarã e soma financeira exata) — Constraint permitiu 'Catamarã / Flexboat' em tours (MP-004) e bloqueou reserva com gross != commission + net (MP-009).
[SIMULAÇÃO SQLITE PASS] [BANCO DE DADOS] BD-05: Execução de todas as RPCs utilizadas — Todas as 7 RPCs presentes e testadas (Cálculo 4 pax = R$ 960.0, bloqueio 25/11 detectado).
[STATIC PASS] [BANCO DE DADOS] BD-06: Testes de permissões de RPCs e RLS — Permissões GRANT/REVOKE (incluindo loop pg_proc e revogação de escrita direta para anon/authenticated) validadas.
[SIMULAÇÃO SQLITE PASS] [CADASTRO] CAD-01 & CAD-03: Cadastro válido + Criação automática de perfil com sanitização de role — Perfil criado automaticamente em public.profiles (id=723831de..., role='tourist' sanitizado de 'admin').
[SIMULAÇÃO SQLITE PASS] [CADASTRO] CAD-02: Cadastro duplicado bloqueado sem duplicar perfil — Tentativa de cadastro duplicado bloqueada e contagem de perfis permaneceu exatamente 1.
[SIMULAÇÃO SQLITE PASS] [CADASTRO] CAD-04: Falha durante criação de perfil realiza rollback atômico — Rollback confirmado: auth_users órfãos = 0, profiles órfãos = 0.
[SIMULAÇÃO SQLITE PASS] [CADASTRO] CAD-05: Consistência 1:1 entre Auth e profiles e proteção de role — Consistência 1:1 verificada (1 auth_users == 1 profiles) e escalada de privilégio bloqueada.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-01: Criação de reserva válida via RPC create_booking_request — Reserva UBT-7540 criada com status SOLICITADA, bruto R$ 1.440,00, comissão R$ 216,00.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-02: Rejeição de reservas com dados inválidos — 4/4 reservas inválidas rejeitadas com erro de validação no servidor.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-07: Repetição da mesma solicitação (Idempotência) — Replay idempotente detectado (mesmo ID 3548d93c...), vagas ocupadas permaneceram em 6/10.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-06: Duas solicitações simultâneas para a última vaga + Conflito Privativo/Compartilhado (MP-015) — Exatamente 1 reserva concorrente aprovada (UBT-7425) e 1 bloqueada; ocupação final = 10/10 vagas sem overbooking; charter privativo conflitante bloqueado.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-04: Bloqueio de transições de status proibidas e não autorizadas (MP-014) — 3/3 transições ilegais bloqueadas (SOLICITADA->PASSEIO_REALIZADO direto, turista confirmando vaga e parceiro alheio).
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-03: Alteração de status permitida e consolidação de comissão — Fluxo SOLICITADA -> CONFIRMADA -> PASSEIO_REALIZADO concluído (3 registros em booking_status_history, ledger_status='CONFIRMADA').
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-05: Cancelamento de reserva, reversão de comissão e liberação de vagas — Cancelamento reverteu livro-razão para REVERTIDA e liberou as 10 vagas (ocupadas: 10 -> 0).
[SIMULAÇÃO SQLITE PASS] [RESERVAS] RES-08: Rollback transacional completo após falha — Falha pós-insert acionou ROLLBACK atômico; total de reservas permaneceu em 3.
[STATIC PASS] [INTEGRAÇÃO] INT-01: Paridade exata entre estados TypeScript e estados SQL (MP-011) — 7 estados SQL == 7 estados TypeScript (SOLICITADA, AGUARDANDO_CONFIRMACAO, CONFIRMADA, RECUSADA, CANCELADA, PASSEIO_REALIZADO, EM_DISPUTA); 0 ocorrências de estados divergentes legados em src/App.tsx.
[STATIC PASS] [INTEGRAÇÃO] INT-02, INT-03 & INT-04: Assinaturas, parâmetros/retornos das RPCs e ausência de chamadas inexistentes (MP-002) — RPCs chamadas pelo frontend/Edge Functions (['admin_anonymize_customer_pii', 'admin_update_booking', 'create_booking_request', 'create_verified_review', 'delete_availability_block', 'get_tour_availability', 'is_admin', 'settle_commission_ledger', 'transition_booking_status', 'upsert_availability_block']) estão 100% implementadas nas migrations (0 ausentes).
[STATIC PASS] [INTEGRAÇÃO] INT-05: Verificação estática de módulos TypeScript + JSX — Todos os 5 módulos TypeScript/React verificados sem erros de import/export ou sintaxe (Resolvedor estático Python TS/JSX).
[STATIC PASS] [INTEGRAÇÃO] M01.8-REG: Verificação de contratos da Missão 01.8 (M01.7-001 a M01.7-010) — Contratos de capacidade reversa em tours, email_confirmed_at, 4-fatores em agenda, conflito de passageiros, RPC LGPD e suíte T8.1..T8.15 validados.
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M01.9-REG: Verificação de contratos e travas da Missão 01.9 (M01.9-001 a M01.9-006 e T9.1..T9.14) — Travas fail-closed na mesma sessão psql (10/10), carga L1(50)/L2(20)/L3, complemento LGPD em 000008 e suíte T9.1..T9.14 validados.
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.1-LGPD-ISOLATED: Simulação comportamental SQLite dos 9 cenários LGPD (Seção 3.4) e guarda de 4 fatores (M02.2-F01/F02/F07) — 9/9 cenários LGPD executados no banco SQLite (1ª/2ª execução, com/sem ledger, confirmada/cancelada, histórico, review com token de nome e audit_logs) + guarda 4-fatores aprovados.
[STATIC PASS] [INTEGRAÇÃO] M02.1-REG: Verificação cruzada de schema/enums (STATIC-12) e guardas do runner (GUARD-00 a GUARD-13 — M02.0-F01 a F10) — 14/14 guardas do runner (incluindo senha com @, bloqueio de ?host=/porta ocupada e preservação de exit_code) e 12/12 verificações estáticas/schema aprovadas.
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.5-SQL-PROOFS: Provas Comportamentais de F02 (10/10 guardas), F03 (10/10 casos LGPD + 16 chaves JSONB recursivas), F04 (11/11 media_assets) e F05 (matriz 6/6 + anti-sombra) — F02=10/10 | F03=10/10 casos + 16 chaves aninhadas | F04=11/11 | F05=6/6 (incluindo anti-sombra pós-cancelamento).
[STATIC PASS] [INTEGRAÇÃO] M02.5-F06-REAL-FRONTEND: Testes comportamentais em Node.js importando funções reais de src/lib/bookingService.ts e validando AST de src/App.tsx (10/10 cenários) — 10/10 cenários executados sobre as funções reais exportadas por src/lib/bookingService.ts (hydrateCatalogAndBookingsSnapshot, resolveIsolatedActivePartner, mergeAvailabilityBlockList, resolveAuthenticatedSessionContext, fetchAuthorizedCatalogAndBookings).
[SIMULAÇÃO SQLITE PASS] [RESERVAS] M02.6-IDEMPOTENCY-LINEAGE: Idempotência pós-cancelamento e pós-expiração com linhagem determinística (Etapas 1..6, 2x/3x sequenciais, timeout pós-commit e 2 threads concorrentes) — Linhagem determinística comprovada: B1(k1-operacao-ubatuba-2027-01) -> cancel -> B2(idg-6b5293931b318309...) -> 3 retries (replay=True, id=UBT-7456) -> expire -> B3(g0002) -> cancel -> 2 threads concorrentes criaram apenas B4(g0003) com 3/10 vagas ocupadas.
[SIMULAÇÃO SQLITE PASS] [RESERVAS] M02.7-ADVERSARIAL-14-SCENARIOS: Execução integral dos 14 cenários adversariais da Missão 02.7 (F01 a F04) + proteção de linhagem e lacuna LGPD — 14/14 cenários adversariais aprovados (incluindo preservação de original_idempotency_key em idg-, MAX(generation)+1 após anonimização LGPD, isolamento k1 vs k2 com 5 vagas ocupadas e trigger de imutabilidade).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.8-LGPD-LINEAGE-12-SCENARIOS: Execução integral dos 12 cenários de Linhagem + LGPD da Missão 02.8 (F01 a F03) — 12/12 cenários de linhagem + anonimização LGPD aprovados (B1/B2/mais recente anonimizadas, reenvio k1 e idg- pós-LGPD, bloqueio de outro titular pós-LGPD, gerações não contíguas, backfill autenticado e imutabilidade).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.9-ADVERSARIAL-LINEAGE-LGPD-14: Execução dos 14 cenários adversariais de Linhagem + MAC 256 bits + Rotação de Segredo (Seções 3.1, 3.2 e 3.3) — 14/14 cenários aprovados (MAC 256-bit anti-enumeração, rotação de chave v1->v2, retry idg- com 100% da linhagem anonimizada via idg-root-, anti-reset de geração e concorrência).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.9-BACKFILL-12: Auditoria e execução dos 12 cenários adversariais de backfill_and_verify_booking_lineage (Seção 3.4) — 12/12 cenários de backfill aprovados (idempotência 2x, rollback em interrupção, chave vazia/ausente, raiz já anonimizada -> idg-root-, preservação LGPD e bloqueio anon/authenticated/partner).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LGPD] M02.9-TOKENS-10: Auditoria e execução dos 10 cenários adversariais de tokens internos e triggers (Seção 3.5) — 10/10 cenários de tokens aprovados (token inexistente/inválido/outra tx/outra op/outro registro, uso único sem reuso, validação trigger_depth, bloqueio de chamada direta e rollback atômico).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/CRIPTOGRAFIA] M02.10-CRYPTO-RFC4231-AND-HMAC-SHA256: Validação dos 4 vetores oficiais RFC 4231, HMAC-SHA-256 real, separação de domínio e remoção de fallback MD5 sem chave — 4/4 vetores RFC 4231 idênticos, HMAC-SHA-256 (v2) exato, 5 domínios isolados, fallback MD5 sem chave bloqueado e validação estrita de formato/comprimento aprovada.
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/CRIPTOGRAFIA] M02.10-KEY-LIFECYCLE-PRIVILEGES-AND-REGRESSION-18: Execução dos 18 cenários adversariais de Gestão de Chaves, CSPRNG, Rotação, Privilégios e search_path (Seções 4 a 7) — 18/18 cenários aprovados (MAC válido/adulterado/segredo incorreto/versão inexistente, rotação multi-versão sem reset, rollback, CSPRNG fail-closed, anti-DELETE de chaves e bloqueio anon/authenticated).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/LINHAGEM] M02.12-F01-LEGACY-LINEAGE-COMPATIBILITY-12: Compatibilidade restrita com linhagens legadas 000013..000016, migração via backfill e gravação exclusiva em HMAC-SHA-256 (Seção 5) — 12/12 cenários obrigatórios aprovados (000013/000014/000015/000016, reenvio k1 e idg- histórico antes/pós-backfill, preservação segura de registro 000014 sem material, bloqueio de outro titular/MD5 arbitrário e novas gravações 100% HMAC-SHA-256).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/CHAVES] M02.12-F02-KEY-LIFECYCLE-RECOVERY-12: Ciclo de vida por versão, aposentadoria granular, bloqueio de zero chaves ativas e restauração de backup (Seção 6) — 12/12 cenários aprovados (rotação v1->v2->v3, aposentadoria RETIRE de versão sem dependentes, bloqueio com dependentes, invariante de chave ativa no commit, rollback e RESTORE de backup).
[SIMULAÇÃO SQLITE PASS] [SEGURANÇA/PRIVILÉGIOS] M02.12-F03-F04-F05-SECRETS-PRIVILEGES-O1-VERIFY: Filtro de segredos periódicos/sequenciais, privilégios mínimos de service_role, verificação O(1) por versão e derive_idempotency_lineage_key SECURITY DEFINER (Seções 7, 8 e 9) — Segredos periódicos/repetitivos/sequenciais rejeitados, oráculos internos e tokens revogados de service_role, verificação O(1) por p_key_version exata e derive_idempotency_lineage_key validada.

==============================================================================
RESUMO FINAL DA SUÍTE DE TESTES: 38/38 TESTES APROVADOS
==============================================================================
```

### 5.5. `node scripts/test_runtime_demo_guard.mjs` (`EXIT_CODE=0` — **APROVADO**)
```text
[TEST PASS] 7/7 cenários positivos, negativos e estruturais de bloqueio de demo em produção aprovados.
```

### 5.6. `npm test` (`EXIT_CODE=0` — **APROVADO**)
Executou sequencialmente `test_runner_destructive_guards.py` (`16/16`), `verify_pg_contracts_and_ast.py` (`18/18`), `run_isolated_test_suite.py` (`38/38`) e `test_runtime_demo_guard.mjs` (`7/7`), concluindo com código de saída `0`.

### 5.7. `bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation` (`EXIT_CODE=2` — **BLOQUEADO POR REDE OFFLINE**)
```text
=== 1. Verificando pré-requisitos do ambiente e conectividade com https://registry.npmjs.org ===
v18.20.4
9.2.0
Python 3.11.2

npm notice PING https://registry.npmjs.org/
npm ERR! code EAI_AGAIN
npm ERR! syscall getaddrinfo
npm ERR! errno EAI_AGAIN
npm ERR! request to https://registry.npmjs.org/-/ping?write=true failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org

npm ERR! A complete log of this run can be found in:
npm ERR!     /home/spark/.npm/_logs/2026-11-17T02_25_19_136Z-debug-0.log
[REGISTRY_UNREACHABLE] O registry oficial https://registry.npmjs.org está inacessível neste ambiente.
Interrompendo a materialização sem alterar package.json ou package-lock.json.
```

### 5.8. `npm ci`, `npm run typecheck` (`EXIT_CODE=127`), `npm run build` (`EXIT_CODE=127`) e `bash scripts/verify_ci_build.sh` (`EXIT_CODE=3`)
- **`npm ci`**: **NÃO EXECUTADO** neste container offline (aguarda materialização do `package-lock.json` via `https://registry.npmjs.org`).
- **`npm run typecheck`**:
  ```text
  > ubatuba-mar-e-praias-marketplace@2.0.0 typecheck
> tsc --noEmit


sh: 1: tsc: not found
  ```
- **`npm run build`**:
  ```text
  > ubatuba-mar-e-praias-marketplace@2.0.0 build
> tsc && vite build


sh: 1: tsc: not found
  ```
- **`bash scripts/verify_ci_build.sh`**:
  ```text
  === 1. Verificando versões de Node.js, npm e Python ===
v18.20.4
9.2.0
Python 3.11.2
SHA-256 package.json (antes):      cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379
SHA-256 package-lock.json (antes): ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013
=== 2. Validando estrutura JSON, lockfileVersion, dependências diretas, árvore transitiva e sha512 (Seção 5.5 a 5.9) ===

[LOCKFILE_INCOMPLETE] package-lock.json versionado possui 12 pacotes, 6 dependências diretas ausentes (@babel/core, @babel/parser, @babel/plugin-transform-modules-commonjs, @babel/preset-react, @babel/preset-typescript, @babel/traverse) e 12 pacotes sem sha512 integrity.
Execute uma única vez em ambiente com rede (Codespaces): bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation e faça commit do package-lock.json.
  ```

---

## 6. LISTA DE PENDÊNCIAS AINDA EXISTENTES E INSTRUÇÕES PARA CODESPACES (SEÇÕES 3 E 13.14)

1. **Única Pendência de Infraestrutura (Requer Rede Externa)**:
   - Executar no terminal do **GitHub Codespaces** (com acesso a `https://registry.npmjs.org`):
     ```bash
     bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation
     ```
   - O script atualizado executará automaticamente todas as verificações das Seções 5, 6, 7, 8 e 9:
     1. Criará e validará o backup `.package-lock.json.pre_materialize.bak` com o SHA-256 original;
     2. Gerará o `package-lock.json` completo a partir de `https://registry.npmjs.org`;
     3. Validará estrutura JSON, `lockfileVersion: 3`, presença de todas as 18 dependências diretas, árvore transitiva (`>= 50` pacotes) e `sha512` em 100% dos pacotes;
     4. Executará `rm -rf node_modules && npm ci --no-audit --no-fund`;
     5. Comprovará a resolução local dos 6 módulos `@babel/*` dentro de `./node_modules/@babel/*` com `NODE_PATH` removido e sem `/usr/share/nodejs`;
     6. Executará `npm run lint`, as 4 suítes de `npm test`, `npm run typecheck` (`tsc --noEmit`), `npm run build` e auditará `dist/` contra exposição de segredos.
2. **Pendências Funcionais das Próximas Missões (Fora do Escopo da Missão 02.15.3)**:
   - Missões B a G (data dinâmica e consulta pública por código para turista anônimo, telas de Login/Cadastro/Logout e persistência de Parceiro/Admin no Supabase, alinhamento do fluxo WhatsApp, cadastro de parceiros comerciais reais, SEO técnico e homologação PostgreSQL 15+ real com Docker).
