# ARGON 4 — RELATÓRIO DE AUDITORIA ADVERSARIAL INDEPENDENTE E CORREÇÃO CIRÚRGICA — MISSÃO 02.7
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)  
**Base auditada:** `ubatuba_mar_e_praias_missao02_6_corrigido.zip` (`1.323.253 bytes` | SHA-256: `a9ec40101edc39f0051dff027c1e44285b7aa7c278441d5ebf4056afdf29b860`)  
**Backup pré-missão:** `/working_dir/c_1db526fd712e6ebe/work/backups_missao_02_7/ubatuba_mar_e_praias_missao02_6_corrigido_BACKUP_PRE_02_7.zip` (`1.323.253 bytes` | SHA-256: `a9ec40101edc39f0051dff027c1e44285b7aa7c278441d5ebf4056afdf29b860`)  
**Migration incremental criada:** `supabase/migrations/20261120000014_missao02_7_lineage_persistence_and_hardening.sql` (`54.907 bytes` | SHA-256: `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4`)

---

## 1. VERIFICAÇÃO DE PROVENIÊNCIA E PRESERVAÇÃO DE MIGRATIONS HISTÓRICAS (`000001` A `000013`)

Todas as 13 migrations históricas (`000001` a `000013`), os 5 arquivos TypeScript/React de `src/` e os arquivos `package.json` / `package-lock.json` foram preservados byte a byte:

| Arquivo | Tamanho (bytes) | SHA-256 (64 caracteres hexadecimais) | Status |
| :--- | :---: | :--- | :---: |
| `supabase/migrations/20261108000001_initial_schema.sql` | `17.194` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | Preservado |
| `supabase/migrations/20261108000002_rls_and_rpcs.sql` | `3.875` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | Preservado |
| `supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql` | `120.783` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | Preservado |
| `supabase/migrations/20261110000004_missao01_official_catalog_seed.sql` | `14.727` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | Preservado |
| `supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql` | `58.943` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | Preservado |
| `supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql` | `54.113` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | Preservado |
| `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` | `64.902` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | Preservado |
| `supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` | `36.333` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | Preservado |
| `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` | `49.149` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | Preservado |
| `supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql` | `106.563` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | Preservado |
| `supabase/migrations/20261117000011_missao02_4_adversarial_fixes.sql` | `113.335` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | Preservado |
| `supabase/migrations/20261118000012_missao02_5_integrity_closure.sql` | `62.476` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | Preservado |
| `supabase/migrations/20261119000013_missao02_6_post_cancel_idempotency.sql` | `25.201` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | Preservado |
| `supabase/migrations/20261120000014_missao02_7_lineage_persistence_and_hardening.sql` | `54.907` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | **Nova (02.7)** |
| `supabase/tests/run_postgresql_homologation.sh` | `27.987` | `99e46a6350199c3814bab90075fada95528fa7a13993fd784b11c7c41cc818be` | Atualizado (02.7) |
| `supabase/tests/function_inventory.json` | `256.620` | `c6941edde70fcbbe57671ed92d5c8bc3d865ddf0fd503abcddb69b66c73b6619` | Atualizado (02.7) |
| `supabase/tests/homologacao_postgresql_real.sql` | `113.015` | `3a9868d19d357c2ccd4594c200e1082f1150fa0c26f5f607a586d37c97cdc59c` | Atualizado (02.7) |
| `supabase/tests/verify_pg_contracts_and_ast.py` | `40.946` | `793091a500cc944c201eb7f1a1a461266d9b3c17557aa1fa5b502e858d4e3c97` | Atualizado (02.7) |
| `supabase/tests/run_isolated_test_suite.py` | `186.444` | `b50059e248ab7587520e5d9bae0e1574b1084268d77f1f0e02c60ce84d2249f5` | Atualizado (02.7) |

---

## 2. ACHADOS TÉCNICOS ADVERSARIAIS REPRODUZIDOS E CORRIGIDOS (`M02.7-F01` A `M02.7-F05`)

1. **`M02.7-F01` (Severidade Alta — F01/F02): Ausência de persistência física de `original_idempotency_key` e perda/bifurcação de linhagem ao receber chave derivada `idg-...`**
   - **Causa-raiz na `000013` (`L207–215` e `L325`)**: A tabela `public.bookings` armazenava apenas `idempotency_key`. Quando o cliente reenviava a chave derivada `idg-<hash24>-g0001-<hash24>`, a função atribuía `v_root_idem_key := v_clean_idem_input` (a própria chave derivada), retornava `'original_idempotency_key': 'idg-...'` em vez de `'k1'`, não verificava criptograficamente o sufixo `-<hash24>` contra `derive_idempotency_lineage_key(original, gen)`, e se `B2` estivesse cancelada/expirada, não localizava `B1` (`idempotency_key = k1`) e derivava outra linhagem sobre `md5('idg-...')`.
   - **Correção em `000014`**: Adicionadas as colunas persistentes `original_idempotency_key VARCHAR(64) NOT NULL` e `idempotency_generation INTEGER NOT NULL DEFAULT 0` em `public.bookings`, com `UNIQUE (original_idempotency_key, idempotency_generation)`, backfill determinístico e restauração de `v_root_idem_key := lower(btrim(v_derived_row.original_idempotency_key))` após validar `derive_idempotency_lineage_key(v_derived_row.original_idempotency_key, v_derived_row.idempotency_generation) = v_clean_idem_input`.

2. **`M02.7-F02` (Severidade Alta — F01/F02): Uso de `COUNT(*)` (`v_inactive_lineage_count`) gerava colisão `UNIQUE(idempotency_key)` se uma geração histórica fosse anonimizada via LGPD**
   - **Causa-raiz na `000013` (`L343–349`)**: Se `B1` (geração `0`, `idempotency_key = k1`) fosse anonimizada por `admin_anonymize_customer_pii` (`idempotency_key = 'lgpd-...'`) enquanto `B2` (geração `1`, `idg-...-g0001-...`) estivesse cancelada, `COUNT(*)` sobre `idempotency_key = k1 OR idempotency_key LIKE 'idg-...'` retornava `1` em vez de `2` e tentava recriar `idg-...-g0001-...`, falhando em `UNIQUE(idempotency_key)`.
   - **Correção em `000014`**: Substituído `COUNT(*)` por `COALESCE(MAX(b.idempotency_generation) + 1, 0)::integer` sobre `original_idempotency_key = v_root_idem_key OR idempotency_key = v_root_idem_key OR idempotency_key LIKE v_lineage_prefix || '%'`.

3. **`M02.7-F03` (Severidade Alta — F01/F02/F03): Compartilhamento indevido de identidade entre duas reservas legítimas distintas com chaves explícitas diferentes (`k1` vs `k2` — Cenário 14)**
   - **Causa-raiz na `000013` (`L250–271`)**: A busca de reserva existente avaliava `OR (b.tour_id = v_tour.id AND b.booking_date = p_booking_date AND phone = v_phone_digits)` mesmo quando o cliente enviava uma chave de idempotência explícita distinta (`k2 != k1`), fazendo `k2` retornar replay de `B1` (`k1`) em vez de criar uma segunda reserva legítima.
   - **Correção em `000014`**: O fallback natural por `(tour_id, booking_date, phone_digits)` foi estritamente condicionado a `NOT v_has_explicit_key` (apenas quando `p_idempotency_key` não é informada).

4. **`M02.7-F04` (Severidade Média-Alta — F03): Proteção de imutabilidade de `original_idempotency_key` e `idempotency_generation` no trigger `enforce_booking_invariants_and_transitions` e pseudonimização LGPD**
   - **Correção em `000014`**: `enforce_booking_invariants_and_transitions()` agora bloqueia qualquer mutação de `original_idempotency_key` ou `idempotency_generation` em `UPDATE` (`BOOKING_IMMUTABLE_LINEAGE_VIOLATION`), permitindo apenas que `admin_anonymize_customer_pii` (sob token `LGPD_ANONYMIZE`) pseudonimize `original_idempotency_key := v_anon_idem_key` preservando `idempotency_generation` intacto.

5. **`M02.7-F05` (Severidade Média — F04): Alinhamento 1:1 do motor isolado SQLite (`run_isolated_test_suite.py`) com a migration `000014`**
   - **Correção**: `IsolatedSupabaseEngine` foi atualizado com as colunas `original_idempotency_key`, `idempotency_generation`, constraint `UNIQUE (original_idempotency_key, idempotency_generation)`, trigger `trg_protect_booking_lineage_columns` e a suíte `M02.7-ADVERSARIAL-14-SCENARIOS` cobrindo os 14 cenários adversariais da Seção 3.

---

## 3. TABELA DE RESULTADOS DOS 14 CENÁRIOS ADVERSARIAIS (`F02`)

| # | Cenário | Entrada | Estado Anterior | Resultado Esperado | Resultado Observado | Status |
| :-: | :--- | :--- | :--- | :--- | :--- | :-: |
| **1** | Criar `B1` (`k1`), cancelar `B1`, criar `B2` (`k1`), perder resposta e repetir `k1` | `k1 = 'k1-adv-missao02-7-2027'`, `pax = 2` | `B1` (`gen=0`, `CANCELADA`), `B2` (`gen=1`, `AGUARDANDO_CONFIRMACAO`) | Retornar `B2` com `idempotent_replay=true`, `original_idempotency_key=k1`, `gen=1` | Retornou `B2` (`replay=true`, `orig=k1`, `gen=1`), `2` vagas ocupadas | **PASS** |
| **2** | Repetir enviando diretamente a chave derivada de `B2` (`idg-...-g0001-...`) | `p_idempotency_key = B2.idempotency_key` (`idg-...-g0001-...`) | `B2` ativa (`gen=1`, `orig=k1`) | Retornar `B2` com `idempotent_replay=true` e preservar `original_idempotency_key=k1` | Retornou `B2` (`replay=true`, `orig=k1`, `gen=1`) sem sobrescrever `orig` com `idg-...` | **PASS** |
| **3** | Anonimizar `B1` via LGPD, cancelar `B2` e repetir `k1` (próxima geração) | `k1 = 'k1-adv-missao02-7-2027'` | `B1` (`gen=0`, anonimizada `lgpd-...`), `B2` (`gen=1`, `CANCELADA`) | Criar `B3` com `gen=2` (`-g0002-`) via `MAX(generation)+1` sem colidir em `-g0001-` | Criou `B3` (`replay=false`, `gen=2`, `idg-...-g0002-...`, `orig=k1`) | **PASS** |
| **4** | Expirar `B3` e repetir o fluxo (incluindo envio de `B2.idempotency_key` inativa) | `p_idempotency_key = B2.idempotency_key` seguido de retry com `k1` | `B2` (`CANCELADA`), `B3` (`is_expired=1`) | Criar `B4` na mesma linhagem (`gen=3`, `orig=k1`) sem bifurcar e retornar `B4` no retry | Criou `B4` (`gen=3`, `orig=k1`) e retornou `B4` (`replay=true`) no retry com `k1` | **PASS** |
| **5** | Duas chamadas simultâneas com a chave original `k1` (após cancelar `B4`) | 2 threads em barreira enviando `k1` | `B1..B4` inativas (`max gen = 3`) | Exatamente 1 thread cria `B5` (`gen=4`, `replay=false`) e 1 thread recebe `B5` (`replay=true`) | 1 `replay=false` + 1 `replay=true`, mesmo `booking_id` (`B5`, `gen=4`), `2` vagas ocupadas | **PASS** |
| **6** | Duas chamadas simultâneas com a chave derivada `idg-...` | 2 threads em barreira enviando `B5.idempotency_key` (`idg-...-g0004-...`) | `B5` ativa (`gen=4`) | Ambas retornam `B5` com `idempotent_replay=true` e `original_idempotency_key=k1` | Ambas retornaram `B5` (`replay=true`, `orig=k1`, `gen=4`), `0` duplicatas | **PASS** |
| **7** | Falha simulada antes do commit (rollback atômico) | `k1` com `p_simulate_failure_after_insert=true` após cancelar `B5`, seguido de `k1` normal | `B1..B5` inativas (`max gen = 4`) | Rollback desfaz inserção sem queimar `gen=5`; chamada seguinte cria `B6` com `gen=5` | Rollback confirmado; chamada seguinte criou `B6` com `gen=5` (`idg-...-g0005-...`) | **PASS** |
| **8** | Timeout simulado após o commit | Retries pós-commit com `k1` e com `B6.idempotency_key` | `B6` ativa (`gen=5`) | Ambos os retries retornam `B6` (`replay=true`) mantendo `2` vagas ocupadas | Ambos retornaram `B6` (`replay=true`), `occupied_seats = 2` | **PASS** |
| **9** | Reuso da chave original `k1` por outro titular | `k1` com telefone/e-mail de outro titular | `B6` ativa pertencente ao Titular 1 | Bloquear com `IDEMPOTENCY_KEY_CONFLICT` | Bloqueado com `IDEMPOTENCY_KEY_CONFLICT` | **PASS** |
| **10** | Reuso da chave derivada `idg-...` por outro titular | `B6.idempotency_key` com telefone/e-mail de outro titular | `B6` ativa pertencente ao Titular 1 | Bloquear com `IDEMPOTENCY_KEY_CONFLICT` | Bloqueado com `IDEMPOTENCY_KEY_CONFLICT` | **PASS** |
| **11** | Chave derivada de outra linhagem ou com hash final adulterado | `derive_idempotency_lineage_key('outra', 1)` e `B6.idempotency_key` adulterada | `B6` ativa | Bloquear ambas com `INVALID_IDEMPOTENCY_KEY` | Ambas bloqueadas com `INVALID_IDEMPOTENCY_KEY` | **PASS** |
| **12** | Alteração de passageiros (`5 != 2`) ou de passeio em retry com `k1` | `k1` com `passengers=5` e `k1` com outro `tour_id` | `B6` ativa (`passengers=2`) | Bloquear com `ACTIVE_BOOKING_PASSENGERS_CONFLICT` e `IDEMPOTENCY_KEY_CONFLICT` | Bloqueados sem modificar `B6` nem o livro-razão | **PASS** |
| **13** | Colisão entre chave manual do usuário e prefixo reservado `idg-` | `p_idempotency_key = 'idg-chave-manual-do-usuario-01'` | Qualquer | Bloquear com `INVALID_IDEMPOTENCY_KEY` | Bloqueado com `INVALID_IDEMPOTENCY_KEY` | **PASS** |
| **14** | Duas reservas legítimas distintas do mesmo titular no mesmo passeio/data (`k1` vs `k2`) | `p_idempotency_key = 'k2-adv-segunda-reserva-legitima'`, `pax = 3` | `B6` ativa (`k1`, `pax = 2`) | Criar segunda reserva independente (`replay=false`, `orig=k2`, `gen=0`), somando `5` vagas | Criou segunda reserva independente (`replay=false`, `orig=k2`, `gen=0`, `occupied_seats = 5`) | **PASS** |

---

## 4. DIAGNÓSTICO REPRODUTÍVEL DO BUILD (`F05`)

- **Ambiente inspecionado:** `Node.js v18.20.4`, `npm 9.2.0`.
- **Arquivos preservados sem alteração:**
  - `package.json`: `1.134 bytes` | SHA-256 `2123a5bb3795dcdaab1f633e8d76b8702080f2b197cc055b35d8a4bc117e87ae`
  - `package-lock.json`: `2.827 bytes` | SHA-256 `ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013`
- **Resultado no ambiente sandbox isolado (sem internet):**
  - `npm ci --offline --ignore-scripts`: falha com `npm ERR! code ENOTCACHED (request to https://registry.npmjs.org/vite/-/vite-5.4.11.tgz failed: cache mode is 'only-if-cached' but no cached response is available)`.
  - `npm run build`: falha com `sh: 1: tsc: not found` (ausência de `node_modules/` local no sandbox sem rede).
  - **Diagnóstico adicional do `package-lock.json`:** o arquivo `package-lock.json` (`91 linhas`, `lockfileVersion: 3`) declara as 12 dependências diretas em paridade de versão com o `package.json`, porém não contém as sub-árvores transitivas (`rollup`, `esbuild`, `@supabase/postgrest-js`, etc.) nem os hashes `"integrity"`. Em ambiente conectado (CI/Codespaces), deve-se executar `npm install --package-lock-only` uma única vez para materializar a árvore transitiva completa do lockfile antes de executar `npm ci && npm run build`.
  - **Status oficial do build de produção (`F05`):** **`PENDENTE_AMBIENTE_COM_REDE_E_NPM`** (não declarado aprovado sem execução real de `npm ci` e `npm run build`, em cumprimento estrito à diretriz da Missão 02.7).
