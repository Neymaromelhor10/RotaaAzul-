# ARGON 4 — MISSÃO 02.3 — RELATÓRIO DE AUDITORIA INDEPENDENTE DE SEGUNDA ORDEM, ANÁLISE DE REGRESSÃO E CORREÇÃO CIRÚRGICA

- **Projeto**: Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
- **Missão**: ARGON 4 — Missão 02.3 (Auditoria Independente de Segunda Ordem, Análise de Regressão e Correção Cirúrgica)
- **Data da Execução**: 2026-11-13
- **Status Geral**: **AUDITORIA DE SEGUNDA ORDEM E CORREÇÕES CIRÚRGICAS CONCLUÍDAS (`16/16` GUARDAS DO RUNNER PASS, `12/12` STATIC/SCHEMA PASS, `25/25` ISOLATED/SQLITE PASS) — PRONTO PARA HOMOLOGAÇÃO POSTGRESQL 15+ REAL (NÃO DECLARADO HOMOLOGADO OU PRONTO PARA PRODUÇÃO NESTE AMBIENTE)**

---

## 1. IDENTIFICAÇÃO E SHA-256 DA BASE (REGRA DE PROVENIÊNCIA)

Antes de qualquer análise ou alteração, o pacote base `ubatuba_mar_e_praias_missao02_2_corrigido.zip` foi validado e copiado integralmente para backup:

| Artefato | Caminho / Arquivo | Tamanho (Bytes) | Estrutura Interna | SHA-256 |
| --- | --- | --- | --- | --- |
| **Pacote Base Recebido (Missão 02.2)** | `ubatuba_mar_e_praias_missao02_2_corrigido.zip` | `1.196.088` | `61` entradas (`49` arquivos + `12` diretórios sob `ubatuba_mar_e_praias_marketplace/`) | `bfa8f0cbfccae9f10f94f8d63c1c09f8fb12206bbd2139bf7cefb349e900990c` |
| **Backup Integral Pré-Missão 02.3** | `ubatuba_mar_e_praias_missao02_2_corrigido_BACKUP_PRE_02_3.zip` | `1.196.088` | `61` entradas (`49` arquivos + `12` diretórios sob `ubatuba_mar_e_praias_marketplace/`) | `bfa8f0cbfccae9f10f94f8d63c1c09f8fb12206bbd2139bf7cefb349e900990c` |

O hash SHA-256 do pacote recebido correspondeu **exatamente** ao hash declarado `bfa8f0cbfccae9f10f94f8d63c1c09f8fb12206bbd2139bf7cefb349e900990c`.

---

## 2. MATRIZ DE TODOS OS ACHADOS DE SEGUNDA ORDEM (SEVERIDADE P0–P3)

| ID | Severidade | Área Auditada | Arquivo e Linhas Afetadas | Evidência Técnica do Problema | Correção Cirúrgica Aplicada | Teste que Comprova a Correção | Status Final |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **`M02.3-F01`** | **P1 (Alta)** | Seções 2 e 3 (Autorização / `SECURITY DEFINER` / 4-Fatores) | `000005` (`L109–114`), `000006` (`L142–147`, `L486–490`), `000007` (`L275–287`, `L510–522`), `000008` (`L38–50`), `000009` (`L48`, `L125`, `L245`, `L692`) | 1) `protect_profile_privileged_columns()` (`000005`), `validate_availability_block_ownership()` (`000006`) e `expire_stale_bookings()` (`000006`) aceitavam `v_db_role = 'none'` sem exigir `session_user IN ('postgres', 'supabase_admin', 'service_role')` e sem rejeitar `(v_db_role = 'authenticated' AND v_jwt_role = 'service_role')`. 2) Quando `v_uid IS NOT NULL AND v_jwt_role = 'authenticated'` e `v_db_role IN ('none', 'postgres')`, as rotinas não exigiam `session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator')`. | Redefinidas `resolve_booking_actor_role`, `admin_update_booking`, `settle_commission_ledger`, `protect_profile_privileged_columns`, `expire_stale_bookings`, `validate_availability_block_ownership`, `protect_catalog_moderation_columns`, `validate_verified_review`, `create_verified_review` e `admin_anonymize_customer_pii` na migration incremental `000010` com a guarda completa de 4 fatores em ambos os ramos (`v_uid IS NOT NULL` e `v_uid IS NULL`). | `T9.17a` em `homologacao_postgresql_real.sql`, `STATIC-03`/`STATIC-11` em `verify_pg_contracts_and_ast.py` e `M02.1-LGPD-ISOLATED`. | **CORRIGIDO** |
| **`M02.3-F02`** | **P1 (Alta)** | Seção 2 (Tokens `BOOKING_MUTATION` e `LEDGER_SYNC` na Anonimização LGPD) | `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` (`L430–445` e `L588–595`) | Em `enforce_booking_invariants_and_transitions()`, o ramo `v_lgpd_anonymize` bloqueava campos operacionais e financeiros, mas não validava que `NEW.customer_name`, `NEW.customer_phone`, `NEW.customer_email`, `NEW.notes` e `NEW.rejection_or_cancel_reason` recebessem exclusivamente as constantes/prefixos canônicos LGPD. Em `enforce_commission_ledger_integrity()`, o ramo `LGPD_ANONYMIZE` não exigia `(NEW.adjustment_notes IS NULL OR NEW.adjustment_notes LIKE '[LGPD %')` nem `(NEW.updated_by IS NOT DISTINCT FROM OLD.updated_by OR NEW.updated_by IS NULL)`. | Adicionada trava `LGPD_INVALID_TARGET_VALUES` em `enforce_booking_invariants_and_transitions()` e restrição estrita de `adjustment_notes`/`updated_by` em `enforce_commission_ledger_integrity()` na migration `000010` (além de validar `author_name = 'Turista Verificado (LGPD)'` e `author_city = 'Anonimizado'` sob token `REVIEW_MUTATION` em `validate_verified_review()`). | `T9.17b` em `homologacao_postgresql_real.sql` e `STATIC-11` em `verify_pg_contracts_and_ast.py`. | **CORRIGIDO** |
| **`M02.3-F03`** | **P1 (Alta)** | Seção 2 (Falsos Positivos em `reviews.comment` e PII Residual em `audit_logs`) | `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` (`L883–895` e `L924–965`) | `position(v_name_token in lower(v_review.comment)) > 0` buscava substrings sem fronteira de palavra: um titular chamado `"Rosa Costa"` gerava falso positivo no comentário `"Viagem maravilhosa pela costa norte de Ubatuba!"` (`"rosa"` dentro de `"maravilhosa"` e `"costa"` em `"costa norte"`). Além disso, `audit_logs` não limpava as chaves alternativas `reviewer_name`, `reviewer_city` e `changed_by`. | Em `000010`, `admin_anonymize_customer_pii` passou a tokenizar por `[^a-záàâãéêíóôõúç]+`, filtrar stop-words náuticas/geográficas de Ubatuba e exigir regex com **fronteira de palavra** `(^|[^a-záàâãéêíóôõúç0-9])token($|[^a-záàâãéêíóôõúç0-9])`, além de sanitizar `reviewer_name`, `reviewer_city` e `changed_by` em `audit_logs`. | Simulação SQLite em `run_isolated_test_suite.py` (`out_rosa["review_comment_redacted"] is False` para `"Rosa Costa"` em `"Viagem maravilhosa pela costa norte"`, mantendo redação `True` para `"Marina"` isolado). | **CORRIGIDO** |
| **`M02.3-F04`** | **P1 (Alta)** | Seção 3 (RLS, Autorização e Isolamento Multitenant em `vessels` e `media_assets`) | `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` (`L549–568`) | Em `protect_catalog_moderation_columns()`, no `INSERT` de `public.vessels`, a condição `NEW.status NOT IN ('PENDENTE_APROVACAO', 'APROVADO')` permitia que um parceiro inserisse uma embarcação já com `status = 'APROVADO'`, e no `UPDATE` permitia mudar `PENDENTE_APROVACAO` para `APROVADO`. Além disso, `trg_protect_media_moderation` em `public.media_assets` disparava apenas `BEFORE INSERT` (sem `OR UPDATE`). | Em `000010`, `protect_catalog_moderation_columns()` exige `NEW.status = 'PENDENTE_APROVACAO'` no `INSERT` de `vessels` por não-admin (`VESSEL_SELF_APPROVAL_FORBIDDEN`), proíbe não-admin de transitar `vessels.status` ou `tours.status` para `'APROVADO'` ou reativar `'SUSPENSO'`, e recria `trg_protect_media_moderation` como `BEFORE INSERT OR UPDATE ON public.media_assets`. | `T9.17c` em `homologacao_postgresql_real.sql` e `STATIC-11` em `verify_pg_contracts_and_ast.py`. | **CORRIGIDO** |
| **`M02.3-F05`** | **P2 (Média)** | Seções 2 e 4 (Colisão de `idempotency_key` com Prefixo Reservado `'lgpd-'`) | `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` (`L477–485`) | `public.create_booking_request()` permitia que um chamador externo informasse `p_idempotency_key` iniciada com `'lgpd-'`, podendo colidir deliberadamente com o namespace `'lgpd-<uuid>-<md5>'` das reservas anonimizadas. | Em `000010`, `create_booking_request()` rejeita qualquer `p_idempotency_key` iniciada por `'lgpd-'` (`lower(v_clean_idem_input) LIKE 'lgpd-%'`) com `INVALID_IDEMPOTENCY_KEY` (SQLSTATE `23514`). | `T9.17d` em `homologacao_postgresql_real.sql` e `STATIC-11` em `verify_pg_contracts_and_ast.py`. | **CORRIGIDO** |
| **`M02.3-F06`** | **P1 (Alta)** | Seção 7 (Auditoria do Frontend e Contratos em `src/App.tsx`) | `src/App.tsx` (`L1704–1717` e `L2559–2565`) | Em `hydrateFromServer()`, quando `isSupabaseConfigured === true` e `snapshot.error === null`, os arrays retornados por `fetchAuthorizedCatalogAndBookings(sessionCtx)` (`partnersRows`, `destinationsRows`, `vesselsRows`, `toursRows`, `availabilityBlocksRows`, `reviewsRows`, `bookingsRows`, `auditLogsRows`) não eram passados para `setPartners`, `setDestinations`, `setVessels`, `setTours`, `setAvailabilityBlocks`, `setReviews`, `setBookings` e `setAuditLogs`, deixando o estado vazio em modo conectado. Além disso, `handleAddAvailabilityBlock` não mapeava `custom_capacity_override` para `adjustedCapacity`. | Adicionado em `src/App.tsx` o mapeamento completo dos arrays de `snapshot` em `hydrateFromServer()` (preservando 100% do design visual) e o mapeamento de `custom_capacity_override` em `handleAddAvailabilityBlock`. | `STATIC-08` (`verify_pg_contracts_and_ast.py`) e `INT-05` (`run_isolated_test_suite.py`). | **CORRIGIDO** |

---

## 3. AUDITORIA DE RLS, AUTORIZAÇÃO, CONCORRÊNCIA, RUNNER E MIGRATIONS

1. **RLS e Isolamento Multitenant (19 Tabelas Públicas + 1 Tabela Privada `internal_guard.execution_tokens`, 41 Políticas RLS, 38 Funções)**:
   - Todas as 19 tabelas públicas e `internal_guard.execution_tokens` possuem `ROW LEVEL SECURITY` habilitado.
   - `anon` e `authenticated` não possuem privilégio de escrita direta (`INSERT`, `UPDATE`, `DELETE`, `TRUNCATE`) em `bookings`, `commission_ledger`, `booking_status_history`, `audit_logs`, `availability_blocks`, `reviews` nem em `internal_guard.execution_tokens`.
   - Isolamento estrito entre `KAI MARES` (`11111111-1111-4111-8111-111111111101`) e `ROTA DO MAR` (`11111111-1111-4111-8111-111111111103`) garantido simultaneamente por políticas RLS (`public.is_partner_member(partner_id)`) e pelas travas internas das RPCs (`resolve_booking_actor_role`, `upsert_availability_block`, `delete_availability_block`, `validate_tour_vessel_ownership`).
   - Todas as 38 funções ativas possuem `SET search_path = pg_catalog, ...` explícito (`0` funções vulneráveis a `search_path` hijacking) e `REVOKE ALL ON FUNCTION ... FROM PUBLIC`.
2. **Concorrência e Integridade Financeira (Hierarquia Global de Locks e `L1`/`L2`/`L3`)**:
   - Todas as 12 rotinas concorrentes obedecem à hierarquia global anti-deadlock: **Lock #1**: `SELECT ... FROM public.vessels WHERE id = ... FOR UPDATE` -> **Lock #2**: `pg_advisory_xact_lock(hashtext(vessel_id::text), hashtext(booking_date::text))` (em ordem cronológica `ASC` quando múltiplas datas são afetadas) -> **Lock #3**: `SELECT ... FROM public.bookings / availability_blocks / commission_ledger FOR UPDATE`.
   - Os valores contábeis (`gross_amount`, `commission_amount`, `net_partner_amount`, `rule_snapshot_json`) são imutáveis após a criação da reserva, e `settle_commission_ledger` impede liquidação duplicada (`LEDGER_ALREADY_PAID`) ou liquidação fora do estado `PASSEIO_REALIZADO` / `CONFIRMADA`.
3. **Runner de Homologação (`run_postgresql_homologation.sh`)**:
   - Higieniza todas as 23 variáveis `PG*` da `libpq` (`unset PGHOST PGHOSTADDR PGPORT PGDATABASE PGUSER PGPASSWORD PGSERVICE PGSERVICEFILE PGPASSFILE PGOPTIONS PGSSLMODE PGREQUIRESSL PGKRBSRVNAME PGTARGETSESSIONATTRS PGAPPNAME PGCLIENTENCODING PGCONNECT_TIMEOUT PGGSSLIB PGSSLKEY PGSSLCERT PGSSLROOTCERT PGSSLCRL PGCHANNELBINDING`).
   - Separa `URL_AUTHORITY` no primeiro `/` antes de extrair `${URL_AUTHORITY##*@}`, bloqueia `%`, `#`, espaços e caracteres de controle, aplica whitelist estrita de query string, verifica porta livre (`PORT_IN_USE`) e container preexistente (`CONTAINER_ALREADY_EXISTS`), executa o `DROP SCHEMA` dentro do bloco atômico `DO $guard$` na mesma sessão `psql` e reaplica `000003` a `000010` com `psql --single-transaction`.

---

## 4. TESTES OFFLINE EXECUTADOS E TESTES NÃO EXECUTADOS

### 4.1. Testes Offline Executados com Sucesso neste Ambiente
| Comando Executado | Escopo Real Verificado | Exit Code | Resultado |
| --- | --- | --- | --- |
| `python3 supabase/tests/test_runner_destructive_guards.py` | Executa o script `run_postgresql_homologation.sh` contra shims instrumentados cobrindo `GUARD-00` a `GUARD-15` (sessão única `DO $guard$`, `--single-transaction`, senhas com `@`, spoofing de `@` na query string, `%` encoding, `unset PG*`, colisão de porta, container preexistente, propriedade de container e preservação de `exit_code`). | `0` | **`16/16 APROVADOS`** |
| `python3 supabase/tests/verify_pg_contracts_and_ast.py` | Executa `STATIC-01` a `STATIC-12` sobre as 10 migrations (`000001` a `000010`), validando ausência de GUC `app.*`, tokens `internal_guard`, inventário de 38 funções, RLS nas 19 tabelas, ordem de locks nas 12 rotinas concorrentes, transpilação AST Babel dos 5 arquivos TS/TSX e validação dinâmica cruzada de 19 tabelas, 7 enums e 32 bindings SQL/PLpgSQL. | `0` | **`12/12 STATIC PASS`** |
| `python3 supabase/tests/run_isolated_test_suite.py` | Executa os 25 testes isolados (`BD-01..06`, `CAD-01..05`, `RES-01..08`, `INT-01..05`, `M01.8-REG`, `M01.9-REG`, `M02.1-LGPD-ISOLATED` com os 9 cenários LGPD em SQLite + teste anti-falso-positivo `"Rosa Costa"` + guarda 4-fatores, e `M02.1-REG`). | `0` | **`25/25 TESTES APROVADOS`** |

### 4.2. Testes Não Executados neste Ambiente e Motivo (Limitações Explícitas)
- **Homologação em Instância PostgreSQL 15+ Real (`run_postgresql_homologation.sh --docker`, `homologacao_postgresql_real.sql`, `test_concorrencia_real_pg.py`, `load_stability_plan_pg.py`)**: **NÃO EXECUTADA NESTA MISSÃO**, tanto por diretriz expressa da Missão 02.3 quanto pela ausência de `docker` e `psql` no container sandbox. A simulação SQLite e a análise estática/AST **não substituem** a execução real no motor PostgreSQL 15+.
- **Build Completo de Produção Vite/Rollup (`npm ci && npm run build`)**: **NÃO EXECUTADO NESTA MISSÃO** porque o sandbox opera sem acesso à internet externa e sem `node_modules` local pré-instalado.

---

## 5. RELAÇÃO EXATA DOS ARQUIVOS ALTERADOS E HASHES SHA-256

### 5.1. Hashes SHA-256 das 10 Migrations (`000001` a `000009` Intactas + `000010` Nova)
| Migration | Tamanho (Bytes) | SHA-256 Antes da Missão 02.3 | SHA-256 Depois da Missão 02.3 | Status |
| --- | --- | --- | --- | --- |
| `supabase/migrations/20261108000001_initial_schema.sql` | `17.194` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261108000002_rls_and_rpcs.sql` | `3.875` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql` | `120.783` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261110000004_missao01_official_catalog_seed.sql` | `14.727` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql` | `58.943` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql` | `54.113` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` | `64.902` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` | `36.333` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` | `49.149` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | **PRESERVADA (INTACTA)** |
| `supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql` | `106.563` | *(N/A — criada na Missão 02.3)* | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | **NOVA MIGRATION INCREMENTAL** |

### 5.2. Relação Exata dos Arquivos Criados ou Alterados na Missão 02.3 (Antes vs Depois)
| Arquivo | Tamanho Antes -> Depois (Bytes) | SHA-256 Antes (Missão 02.2) | SHA-256 Depois (Missão 02.3) |
| --- | --- | --- | --- |
| `supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql` | *(novo)* -> `106.563` | *(novo)* | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` |
| `src/App.tsx` | `313.961` -> `321.850` | `52f7d1d9a33c7b1f82bf49c63d3e575483b173800286985b64bb07eb2765979e` | `4f54e7a45707a1f573525b5020f103bafe22402e83713aa6ccaa348f788fbbfa` |
| `supabase/tests/run_postgresql_homologation.sh` | `26.890` -> `27.187` | `80531189698bea6dfbcc098b90705bb2fb1b95c777555657e6c70361b50d1f66` | `20d5186045c3890f8332e858d840d1cf39c3caf2cdff73aa22a1aced12012019` |
| `supabase/tests/function_inventory.json` | `118.348` -> `144.904` | `ff03b924f2e71e45cc0cd5dd3d5796d13189c18036641d0a548d29b8b1a64bd1` | `9f458f73983adf8064697b685fd3e8cefd34031a9e0ab9e81eaf5bfe33a0a329` |
| `supabase/tests/homologacao_postgresql_real.sql` | `96.515` -> `101.251` | `550c7801b73d2db8bed1ea847d70aeea5c4577eb9ee7640a0c69b5b68965badf` | `22ce4133e0353e53352a2f6c96c5a16478da301fb019fe96897af08dabd47ce9` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | `35.538` -> `36.082` | `d41a9a44c7f3f39a74a72b388e2920f2365471b9042bd52410c2b0c3e8910b71` | `731f5c3020f2dc279478cf66d55fe0f13fef2b4cd9f4672309d79c4ca0c8bbf8` |
| `supabase/tests/run_isolated_test_suite.py` | `98.711` -> `101.090` | `3d8c3a603993550d065cfd7777422b4f38b7a78b87963d72ae818cfb5c208fc7` | `a6e6dcd8d79a089e73cf7e757c87dd23a372a1e6f699e3894777b066ca8dc35b` |
| `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_3.md` | *(novo)* | *(novo)* | *(registrado no fechamento do pacote)* |

---

## 6. LISTA DE PENDÊNCIAS EXCLUSIVAS DE POSTGRESQL 15+ REAL E AMBIENTE COM INTERNET

1. **Execução da Homologação Completa em PostgreSQL 15+ Real / Docker Descartável**:
   - Comando: `bash supabase/tests/run_postgresql_homologation.sh --docker`
   - Verifica a aplicação real de `000001` a `000010`, a reaplicação atômica `--single-transaction` de `000003` a `000010`, todos os blocos `PG-01..PG-12`, `T8.1..T8.15`, `T9.1..T9.17`, os 4 cenários de concorrência real sob RLS (`test_concorrencia_real_pg.py`) e as baterias de carga `L1`/`L2`/`L3` (`load_stability_plan_pg.py`).
2. **Geração de Lockfile Completo e Build de Produção Frontend em Ambiente com Internet**:
   - Comando: `npm install --package-lock-only && npm ci && npm run build`
