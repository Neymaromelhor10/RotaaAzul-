// ============================================================================
// CONTRATO UNIFICADO DE TIPOS E ESTADOS (FRONTEND <-> SUPABASE POSTGRESQL)
// Projeto: Ubatuba Mar & Praias — Missão 01 a 02.22 (MP-002, MP-011, MP-012, MP-014, MP-015, M01.7-007, M01.7-009, M02.2-F08, M02.16, M02.21, M02.22)
// ============================================================================

export type AppRole = 'tourist' | 'partner' | 'admin';

export type PartnerStatus = 'PENDENTE' | 'APROVADO' | 'SUSPENSO';

export type ModerationStatus =
  | 'RASCUNHO'
  | 'PENDENTE_APROVACAO'
  | 'APROVADO'
  | 'REPROVADO'
  | 'SUSPENSO';

export type PricingModelType = 'POR_PESSOA' | 'POR_EMBARCACAO';

export type CommissionModelType =
  | 'PERCENTAGE'
  | 'FIXED_PER_PASSENGER'
  | 'FIXED_PER_BOOKING'
  | 'HYBRID_PERCENT_PLUS_FIXED';

// Alias retrocompatível para o seletor resumido do Painel Admin no Frontend
export type PartnerCommissionModelUI =
  | CommissionModelType
  | 'FIXED_AMOUNT'
  | 'CUSTOM_OVERRIDE';

// Contrato Único de Estados de Reserva (MP-011) — Idêntico ao ENUM SQL public.booking_status_type
export type BookingStatusType =
  | 'SOLICITADA'
  | 'AGUARDANDO_CONFIRMACAO'
  | 'CONFIRMADA'
  | 'RECUSADA'
  | 'CANCELADA'
  | 'PASSEIO_REALIZADO'
  | 'EM_DISPUTA';

export const BOOKING_STATUS_VALUES: readonly BookingStatusType[] = [
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
  'RECUSADA',
  'CANCELADA',
  'PASSEIO_REALIZADO',
  'EM_DISPUTA',
] as const;

export const BOOKING_STATUS_LABELS: Record<BookingStatusType, string> = {
  SOLICITADA: 'SOLICITADA',
  AGUARDANDO_CONFIRMACAO: 'AGUARDANDO_CONFIRMACAO',
  CONFIRMADA: 'CONFIRMADA',
  RECUSADA: 'RECUSADA',
  CANCELADA: 'CANCELADA',
  PASSEIO_REALIZADO: 'PASSEIO_REALIZADO',
  EM_DISPUTA: 'EM_DISPUTA',
};

// Estados que ocupam/reservam capacidade ativa na embarcação/passeio (MP-015)
export const ACTIVE_CAPACITY_BOOKING_STATUSES: readonly BookingStatusType[] = [
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
  'PASSEIO_REALIZADO',
  'EM_DISPUTA',
] as const;

// Estados que indicam reserva pendente de realização financeira
export const PENDING_FINANCIAL_BOOKING_STATUSES: readonly BookingStatusType[] = [
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
] as const;

export type LedgerStatusType =
  | 'PREVISTA'
  | 'CONFIRMADA'
  | 'PAGA'
  | 'REVERTIDA'
  | 'EM_DISPUTA';

export const LEDGER_STATUS_VALUES: readonly LedgerStatusType[] = [
  'PREVISTA',
  'CONFIRMADA',
  'PAGA',
  'REVERTIDA',
  'EM_DISPUTA',
] as const;

export type BookingChannelType = 'WHATSAPP' | 'SITE_DIRECT';

export type VesselType = 'Lancha' | 'Escuna' | 'Catamarã / Flexboat';

export type TourOperationType = 'Privativo' | 'Compartilhado';

export type VesselOperationMode = 'Privativo' | 'Compartilhado' | 'Ambos';

export type AvailabilityBlockType =
  | 'BLOQUEIO_TOTAL'
  | 'MANUTENCAO'
  | 'INTERDICAO_MARINHA'
  | 'AJUSTE_CAPACIDADE';

// ============================================================================
// MATRIZ OFICIAL DE TRANSIÇÕES DE STATUS E AUTORIZAÇÃO POR PAPEL (MP-014)
// ============================================================================

export const ALLOWED_STATUS_TRANSITIONS: Record<
  BookingStatusType,
  readonly BookingStatusType[]
> = {
  SOLICITADA: [
    'AGUARDANDO_CONFIRMACAO',
    'CONFIRMADA',
    'RECUSADA',
    'CANCELADA',
  ],
  AGUARDANDO_CONFIRMACAO: ['CONFIRMADA', 'RECUSADA', 'CANCELADA'],
  CONFIRMADA: ['PASSEIO_REALIZADO', 'CANCELADA', 'EM_DISPUTA'],
  PASSEIO_REALIZADO: ['EM_DISPUTA'],
  EM_DISPUTA: ['PASSEIO_REALIZADO', 'CANCELADA'],
  RECUSADA: [],
  CANCELADA: [],
};

export const ROLE_ALLOWED_TARGET_STATUSES: Record<
  AppRole,
  Record<BookingStatusType, readonly BookingStatusType[]>
> = {
  tourist: {
    SOLICITADA: ['CANCELADA'],
    AGUARDANDO_CONFIRMACAO: ['CANCELADA'],
    CONFIRMADA: ['CANCELADA', 'EM_DISPUTA'],
    PASSEIO_REALIZADO: ['EM_DISPUTA'],
    EM_DISPUTA: [],
    RECUSADA: [],
    CANCELADA: [],
  },
  partner: {
    SOLICITADA: [
      'AGUARDANDO_CONFIRMACAO',
      'CONFIRMADA',
      'RECUSADA',
      'CANCELADA',
    ],
    AGUARDANDO_CONFIRMACAO: ['CONFIRMADA', 'RECUSADA', 'CANCELADA'],
    CONFIRMADA: ['PASSEIO_REALIZADO', 'CANCELADA', 'EM_DISPUTA'],
    PASSEIO_REALIZADO: ['EM_DISPUTA'],
    EM_DISPUTA: [],
    RECUSADA: [],
    CANCELADA: [],
  },
  admin: {
    SOLICITADA: [
      'AGUARDANDO_CONFIRMACAO',
      'CONFIRMADA',
      'RECUSADA',
      'CANCELADA',
    ],
    AGUARDANDO_CONFIRMACAO: ['CONFIRMADA', 'RECUSADA', 'CANCELADA'],
    CONFIRMADA: ['PASSEIO_REALIZADO', 'CANCELADA', 'EM_DISPUTA'],
    PASSEIO_REALIZADO: ['EM_DISPUTA'],
    EM_DISPUTA: ['PASSEIO_REALIZADO', 'CANCELADA'],
    RECUSADA: [],
    CANCELADA: [],
  },
};

export function isValidBookingStatus(value: unknown): value is BookingStatusType {
  return (
    typeof value === 'string' &&
    (BOOKING_STATUS_VALUES as readonly string[]).includes(value)
  );
}

/**
 * Converte estados legados (caso existam em localStorage de versões anteriores)
 * para o contrato único MP-011, rejeitando qualquer estado desconhecido.
 */
export function normalizeBookingStatus(rawStatus: string): BookingStatusType {
  if (isValidBookingStatus(rawStatus)) {
    return rawStatus;
  }
  const legacyMap: Record<string, BookingStatusType> = {
    SOLICITACAO_WHATSAPP: 'SOLICITADA',
    AGUARDANDO_CONFIRMACAO_PARCEIRO: 'AGUARDANDO_CONFIRMACAO',
    CONFIRMADA_PELO_PARCEIRO: 'CONFIRMADA',
  };
  const mapped = legacyMap[rawStatus];
  if (mapped) {
    return mapped;
  }
  throw new Error(`INVALID_BOOKING_STATUS: Estado de reserva inválido "${rawStatus}".`);
}

export function validateBookingStatusTransition(
  currentStatus: BookingStatusType,
  nextStatus: BookingStatusType,
  actorRole: AppRole,
  reason?: string
): { valid: boolean; errorCode?: string; errorMessage?: string; reason?: string } {
  if (!isValidBookingStatus(currentStatus) || !isValidBookingStatus(nextStatus)) {
    const msg = `Estado inválido na transição (${String(currentStatus)} -> ${String(nextStatus)}).`;
    return {
      valid: false,
      errorCode: 'INVALID_BOOKING_STATUS',
      errorMessage: msg,
      reason: msg,
    };
  }

  if (currentStatus === nextStatus) {
    const msg = `A reserva já se encontra no estado ${currentStatus}.`;
    return {
      valid: false,
      errorCode: 'NOOP_STATUS_TRANSITION',
      errorMessage: msg,
      reason: msg,
    };
  }

  const allowedTargets = ALLOWED_STATUS_TRANSITIONS[currentStatus] || [];
  if (!allowedTargets.includes(nextStatus)) {
    const msg = `Transição de status não permitida: ${currentStatus} -> ${nextStatus}.`;
    return {
      valid: false,
      errorCode: 'INVALID_STATUS_TRANSITION',
      errorMessage: msg,
      reason: msg,
    };
  }

  const roleTargets = ROLE_ALLOWED_TARGET_STATUSES[actorRole]?.[currentStatus] || [];
  if (!roleTargets.includes(nextStatus)) {
    const msg = `O perfil "${actorRole}" não possui permissão para executar a transição ${currentStatus} -> ${nextStatus}.`;
    return {
      valid: false,
      errorCode: 'UNAUTHORIZED_STATUS_TRANSITION',
      errorMessage: msg,
      reason: msg,
    };
  }

  if (
    (nextStatus === 'RECUSADA' || nextStatus === 'CANCELADA') &&
    (!reason || reason.trim().length < 3)
  ) {
    const msg = `É obrigatório informar uma justificativa (mínimo 3 caracteres) para ${nextStatus}.`;
    return {
      valid: false,
      errorCode: 'REASON_REQUIRED',
      errorMessage: msg,
      reason: msg,
    };
  }

  return { valid: true };
}

export function deriveLedgerStatusFromBookingStatus(
  bookingStatus: BookingStatusType,
  currentLedgerStatus?: LedgerStatusType
): LedgerStatusType {
  if (bookingStatus === 'PASSEIO_REALIZADO') {
    return currentLedgerStatus === 'PAGA' ? 'PAGA' : 'CONFIRMADA';
  }
  if (bookingStatus === 'CANCELADA' || bookingStatus === 'RECUSADA') {
    return 'REVERTIDA';
  }
  if (bookingStatus === 'EM_DISPUTA') {
    return 'EM_DISPUTA';
  }
  return 'PREVISTA';
}

// ============================================================================
// ASSINATURAS DE RPCS SUPABASE (MP-002 & M01.7-007 / M01.7-009 / M02.2-F08 / M02.16 / M02.21 / M02.22)
// ============================================================================

export interface CreateBookingRequestParams {
  p_tour_id: string;
  p_booking_date: string;
  p_passengers: number;
  p_channel: BookingChannelType;
  p_customer_name: string;
  p_customer_phone: string;
  p_customer_email: string;
  p_utm_source?: string | null;
  p_utm_medium?: string | null;
  p_utm_campaign?: string | null;
  p_notes?: string | null;
  p_idempotency_key?: string | null;
}

export interface CreateBookingRequestResponse {
  id: string;
  booking_id?: string;
  code: string;
  booking_code?: string;
  lookup_token?: string;
  idempotency_key: string;
  original_idempotency_key?: string;
  idempotency_generation?: number;
  hmac_key_version?: number;
  idempotent_replay: boolean;
  status: BookingStatusType;
  ledger_status: LedgerStatusType;
  tour_id: string;
  tour_title: string;
  departure_time?: string;
  return_time?: string;
  check_in_time?: string;
  departure_point?: string;
  vessel_id: string;
  vessel_name: string;
  partner_id: string;
  partner_name: string;
  partner_whatsapp: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  booking_date: string;
  passengers: number;
  channel: BookingChannelType;
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
  pricing_model_snapshot: PricingModelType;
  unit_price_snapshot: number;
  gross_amount: number;
  commission_model_snapshot: CommissionModelType;
  commission_rate_snapshot: number;
  commission_fixed_snapshot: number;
  commission_rule_label: string;
  commission_amount: number;
  net_partner_amount: number;
  commission_consolidated: boolean;
  notes: string | null;
  expires_at: string | null;
  created_at: string;
}

export interface TransitionBookingStatusParams {
  p_booking_id: string;
  p_new_status: BookingStatusType;
  p_reason?: string | null;
}

export interface TransitionBookingStatusResponse {
  id: string;
  code: string;
  previous_status: BookingStatusType;
  status: BookingStatusType;
  ledger_status: LedgerStatusType;
  commission_consolidated: boolean;
  rejection_or_cancel_reason: string | null;
  confirmed_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  updated_at: string;
}

export interface GetTourAvailabilityParams {
  p_tour_id: string;
  p_booking_date: string;
}

export interface GetTourAvailabilityResponse {
  tour_id: string;
  vessel_id: string;
  booking_date: string;
  current_brazil_date?: string;
  departure_time?: string;
  return_time?: string;
  check_in_time?: string;
  departure_point?: string;
  blocked: boolean;
  block_reason: string;
  effective_capacity: number;
  occupied_seats: number;
  remaining_seats: number;
}

export interface TouristBookingLookupParams {
  p_booking_code: string;
  p_lookup_token: string;
}

export interface TouristBookingLookupResponse {
  ok: boolean;
  error_code?: string;
  message?: string;
  locked_until?: string | null;
  booking_code?: string;
  status?: BookingStatusType;
  booking_date?: string;
  passengers?: number;
  pricing_model?: PricingModelType;
  unit_price?: number;
  gross_amount?: number;
  channel?: BookingChannelType;
  tour_slug?: string;
  tour_title?: string;
  departure_time?: string;
  return_time?: string;
  check_in_time?: string;
  departure_point?: string;
  cancellation_policy?: string;
  vessel_name?: string;
  partner_name?: string;
  partner_whatsapp?: string;
  partner_base_marina?: string;
  rejection_or_cancel_reason?: string | null;
  expires_at?: string | null;
  confirmed_at?: string | null;
  completed_at?: string | null;
  cancelled_at?: string | null;
  created_at?: string;
}

export interface CancelBookingByTouristTokenParams {
  p_booking_code: string;
  p_lookup_token: string;
  p_reason?: string | null;
}

export interface CancelBookingByTouristTokenResponse {
  ok: boolean;
  idempotent_replay?: boolean;
  error_code?: string;
  message?: string;
  locked_until?: string | null;
  booking_code?: string;
  previous_status?: BookingStatusType;
  status?: BookingStatusType;
  ledger_status?: LedgerStatusType;
  cancelled_at?: string | null;
  rejection_or_cancel_reason?: string | null;
}

export interface TouristSavedReceipt {
  bookingCode: string;
  lookupToken: string;
  tourTitle: string;
  bookingDate: string;
  createdAt: string;
}

export interface AdminUpdateBookingParams {
  p_booking_id: string;
  p_new_booking_date?: string | null;
  p_new_passengers?: number | null;
  p_new_status?: BookingStatusType | null;
  p_reason?: string | null;
}

export interface SettleCommissionLedgerParams {
  p_booking_id: string;
  p_adjustment_notes?: string | null;
}

export interface UpsertAvailabilityBlockParams {
  p_vessel_id: string;
  p_block_date: string;
  p_block_type: AvailabilityBlockType;
  p_reason?: string | null;
  p_custom_capacity_override?: number | null;
  p_tour_id?: string | null;
}

export interface UpsertAvailabilityBlockResponse {
  id: string;
  partner_id: string;
  vessel_id: string;
  tour_id: string | null;
  block_date: string;
  block_type: AvailabilityBlockType;
  custom_capacity_override: number | null;
  reason: string | null;
  created_by: string | null;
  created_at: string;
}

export interface DeleteAvailabilityBlockParams {
  p_block_id: string;
}

export interface DeleteAvailabilityBlockResponse {
  deleted: boolean;
  id: string;
  vessel_id: string;
  block_date: string;
}

export interface AdminAnonymizeCustomerPiiParams {
  p_booking_id: string;
  p_lgpd_protocol: string;
}

export interface AdminAnonymizeCustomerPiiResponse {
  anonymized: boolean;
  idempotent_replay: boolean;
  booking_id: string;
  booking_code: string;
  lgpd_protocol: string;
  performed_by?: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string;
  idempotency_key?: string;
  tourist_user_id?: string | null;
  history_rows_sanitized?: number;
  audit_rows_sanitized?: number;
  ledger_notes_sanitized?: boolean;
  financial_payment_sanitized?: boolean;
  financial_history_rows_sanitized?: number;
  financial_entries_rows_sanitized?: number;
  payment_rows_sanitized?: number;
  payment_history_rows_sanitized?: number;
  financial_ledger_rows_sanitized?: number;
  review_author_anonymized?: boolean;
  review_comment_redacted?: boolean;
  financials_preserved: boolean;
  gross_amount: number;
  commission_amount: number;
  net_partner_amount: number;
  external_channel_warning?: string | null;
}

export interface AuthenticatedSessionContext {
  isConnectedMode: boolean;
  userId: string | null;
  email: string | null;
  effectiveRole: AppRole;
  authorizedPartnerIds: string[];
  isActiveProfile: boolean;
  error: string | null;
}

// ============================================================================
// CONTRATO DE PAGAMENTOS, COMISSÕES, ESTORNOS E CONCILIAÇÃO (MISSÕES 02.21 E 02.22)
// Paridade 1:1 com Migrations 000022 e 000023 (payment_status_type, payment_method_type, financial_entry_type)
// ============================================================================

export type PaymentStatusType =
  | 'PENDENTE'
  | 'PROCESSANDO'
  | 'PAGO'
  | 'FALHOU'
  | 'CANCELADO'
  | 'ESTORNO_PENDENTE'
  | 'ESTORNADO'
  | 'ESTORNO_PARCIAL';

export const PAYMENT_STATUS_VALUES: readonly PaymentStatusType[] = [
  'PENDENTE',
  'PROCESSANDO',
  'PAGO',
  'FALHOU',
  'CANCELADO',
  'ESTORNO_PENDENTE',
  'ESTORNADO',
  'ESTORNO_PARCIAL',
] as const;

export type PaymentMethodType =
  | 'PIX'
  | 'CARTAO_CREDITO'
  | 'CARTAO_DEBITO'
  | 'BOLETO'
  | 'LINK_PAGAMENTO'
  | 'TRANSFERENCIA_DIRETA';

export const PAYMENT_METHOD_VALUES: readonly PaymentMethodType[] = [
  'PIX',
  'CARTAO_CREDITO',
  'CARTAO_DEBITO',
  'BOLETO',
  'LINK_PAGAMENTO',
  'TRANSFERENCIA_DIRETA',
] as const;

export type FinancialEntryType =
  | 'PAYMENT_CONFIRMED'
  | 'COMMISSION_PROVISIONED'
  | 'COMMISSION_CONSOLIDATED'
  | 'REFUND_FULL'
  | 'REFUND_PARTIAL'
  | 'COMMISSION_REVERSAL_FULL'
  | 'COMMISSION_REVERSAL_PARTIAL'
  | 'PARTNER_PAYOUT_SETTLED'
  | 'COMPENSATORY_ADJUSTMENT';

export const ALLOWED_PAYMENT_STATUS_TRANSITIONS: Record<
  PaymentStatusType,
  readonly PaymentStatusType[]
> = {
  PENDENTE: ['PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO'],
  PROCESSANDO: ['PAGO', 'FALHOU', 'CANCELADO'],
  FALHOU: ['PROCESSANDO', 'CANCELADO'],
  PAGO: ['ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL'],
  ESTORNO_PENDENTE: ['ESTORNADO', 'ESTORNO_PARCIAL', 'PAGO'],
  ESTORNO_PARCIAL: ['ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL'],
  CANCELADO: [],
  ESTORNADO: [],
};

export interface BookingPaymentRow {
  id: string;
  booking_id: string;
  partner_id: string;
  tour_id: string;
  currency: 'BRL';
  payment_method: PaymentMethodType;
  payment_status: PaymentStatusType;
  gross_amount: number;
  commission_amount: number;
  net_partner_amount: number;
  refunded_gross_amount: number;
  refunded_commission_amount: number;
  refunded_net_partner_amount: number;
  effective_gross_amount: number;
  effective_commission_amount: number;
  effective_net_partner_amount: number;
  commission_rule_snapshot: Record<string, unknown>;
  external_transaction_id: string | null;
  idempotency_key: string;
  last_operation_idempotency_key: string | null;
  failure_or_cancel_reason: string | null;
  refund_reason: string | null;
  confirmed_at: string | null;
  cancelled_at: string | null;
  refunded_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BookingPaymentHistoryRow {
  id: string;
  payment_id: string;
  booking_id: string;
  partner_id: string;
  previous_status: PaymentStatusType | null;
  new_status: PaymentStatusType;
  operation_type: string;
  operation_amount: number;
  idempotency_key: string;
  external_transaction_id: string | null;
  actor_user_id: string | null;
  actor_role: AppRole | null;
  reason: string | null;
  metadata_json: Record<string, unknown>;
  created_at: string;
}

export interface FinancialLedgerEntryRow {
  id: string;
  booking_id: string;
  payment_id: string | null;
  commission_ledger_id: string | null;
  partner_id: string;
  tour_id: string;
  entry_type: FinancialEntryType;
  gross_delta: number;
  commission_delta: number;
  net_partner_delta: number;
  currency: 'BRL';
  idempotency_key: string;
  reference_transaction_id: string | null;
  description: string;
  actor_user_id: string | null;
  actor_role: AppRole | null;
  created_at: string;
}

export interface CommissionLedgerRow {
  id: string;
  booking_id: string;
  partner_id: string;
  tour_id: string;
  ledger_status: LedgerStatusType;
  gross_amount: number;
  commission_amount: number;
  net_partner_amount: number;
  rule_snapshot_json: Record<string, unknown>;
  consolidated_at: string | null;
  paid_at: string | null;
  reversed_at: string | null;
  adjustment_notes: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateOrInitiateBookingPaymentParams {
  p_booking_id: string;
  p_payment_method: PaymentMethodType;
  p_idempotency_key: string;
  p_client_gross_amount?: number | null;
  p_external_transaction_id?: string | null;
}

export interface CreateOrInitiateBookingPaymentResponse {
  ok: boolean;
  idempotent_replay: boolean;
  payment_id: string;
  booking_id: string;
  partner_id: string;
  payment_status: PaymentStatusType;
  payment_method: PaymentMethodType;
  currency: 'BRL';
  gross_amount: number;
  commission_amount: number;
  net_partner_amount: number;
  effective_gross_amount: number;
  effective_commission_amount: number;
  effective_net_partner_amount: number;
  idempotency_key: string;
}

export interface ConfirmOrFailBookingPaymentParams {
  p_booking_id: string;
  p_target_status: PaymentStatusType;
  p_idempotency_key: string;
  p_external_transaction_id?: string | null;
  p_client_gross_amount?: number | null;
  p_reason?: string | null;
}

export interface ConfirmOrFailBookingPaymentResponse {
  ok: boolean;
  idempotent_replay: boolean;
  payment_id: string;
  booking_id: string;
  previous_status: PaymentStatusType;
  payment_status: PaymentStatusType;
  confirmation_origin?: 'GATEWAY_WEBHOOK' | 'MANUAL_ADMIN' | null;
  gross_amount: number;
  commission_amount: number;
  net_partner_amount: number;
  effective_gross_amount: number;
  effective_commission_amount: number;
  effective_net_partner_amount: number;
  confirmed_at: string | null;
}

export interface RequestBookingRefundParams {
  p_booking_id: string;
  p_refund_amount: number | null;
  p_idempotency_key: string;
  p_reason: string;
}

export interface RequestBookingRefundResponse {
  ok: boolean;
  idempotent_replay: boolean;
  payment_id: string;
  booking_id: string;
  booking_code?: string;
  previous_status: PaymentStatusType;
  previous_payment_status?: PaymentStatusType;
  payment_status: PaymentStatusType;
  requested_refund_amount: number;
  refunded_gross_amount: number;
  refunded_commission_amount?: number;
  refunded_net_partner_amount?: number;
  effective_gross_amount: number;
  effective_commission_amount: number;
  effective_net_partner_amount: number;
  gross_amount?: number;
  already_refunded_amount?: number;
  reason?: string;
}

export interface ProcessBookingRefundParams {
  p_booking_id: string;
  p_refund_amount: number | null;
  p_idempotency_key: string;
  p_reason: string;
  p_mark_booking_cancelled?: boolean;
}

export interface ProcessBookingRefundResponse {
  ok: boolean;
  idempotent_replay: boolean;
  payment_id: string;
  booking_id: string;
  previous_status?: PaymentStatusType;
  payment_status: PaymentStatusType;
  refund_gross_delta?: number;
  refund_commission_delta?: number;
  refund_net_delta?: number;
  refunded_gross_amount: number;
  refunded_commission_amount: number;
  refunded_net_partner_amount: number;
  effective_gross_amount: number;
  effective_commission_amount: number;
  effective_net_partner_amount: number;
}

export interface GetFinancialReconciliationReportParams {
  p_partner_id?: string | null;
}

export interface GetFinancialReconciliationReportResponse {
  ok: boolean;
  scope_partner_id: string | null;
  total_gross_received: number;
  total_commissions: number;
  total_net_partner: number;
  total_refunded: number;
  pending_payments_count: number;
  pending_refunds_count: number;
  confirmed_payments_count: number;
  refunded_payments_count: number;
  orphan_payments_count?: number;
  orphan_history_count?: number;
  discrepancies_count: number;
  discrepancies: Record<string, unknown>[];
}

export function isValidPaymentStatus(value: unknown): value is PaymentStatusType {
  return (
    typeof value === 'string' &&
    (PAYMENT_STATUS_VALUES as readonly string[]).includes(value)
  );
}

export function isValidPaymentStatusTransition(
  currentStatus: PaymentStatusType,
  nextStatus: PaymentStatusType
): boolean {
  if (!isValidPaymentStatus(currentStatus) || !isValidPaymentStatus(nextStatus)) {
    return false;
  }
  const allowed = ALLOWED_PAYMENT_STATUS_TRANSITIONS[currentStatus] || [];
  return allowed.includes(nextStatus);
}
