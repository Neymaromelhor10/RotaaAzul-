// ============================================================================
// CONTRATOS E TIPOS DE AUTENTICAÇÃO, SESSÃO, CONTROLE DE ACESSO E ONBOARDING
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Missão 02.19 (Seções 3 a 12)
// ============================================================================

import { AppRole, PartnerStatus } from '../types/database.types';

export type AccountStateType =
  | 'UNAUTHENTICATED'
  | 'AUTHENTICATED_ACTIVE'
  | 'SESSION_EXPIRED'
  | 'ACCOUNT_DISABLED'
  | 'PARTNER_PENDING_APPROVAL'
  | 'PARTNER_REJECTED'
  | 'PARTNER_SUSPENDED'
  | 'UNAUTHORIZED_ACCESS';

export type PartnerOnboardingStage =
  | 'PENDENTE'
  | 'EM_ANALISE'
  | 'APROVADO'
  | 'REJEITADO'
  | 'SUSPENSO';

export const PARTNER_ONBOARDING_STAGES: readonly PartnerOnboardingStage[] = [
  'PENDENTE',
  'EM_ANALISE',
  'APROVADO',
  'REJEITADO',
  'SUSPENSO',
] as const;

export type ProtectedRouteKey =
  | 'public-marketplace'
  | 'auth-login'
  | 'auth-register'
  | 'auth-recovery'
  | 'auth-reset-password'
  | 'partner-onboarding'
  | 'partner-portal'
  | 'partner-tours'
  | 'partner-vessels'
  | 'partner-bookings'
  | 'partner-departures'
  | 'admin-portal'
  | 'admin-partners'
  | 'admin-tours'
  | 'admin-vessels'
  | 'admin-bookings'
  | 'admin-departures';

export type AuthErrorCode =
  | 'INVALID_CREDENTIALS'
  | 'VALIDATION_ERROR'
  | 'SESSION_EXPIRED'
  | 'UNAUTHENTICATED'
  | 'NETWORK_ERROR'
  | 'ACCOUNT_DISABLED'
  | 'ACCOUNT_PENDING_APPROVAL'
  | 'ACCOUNT_SUSPENDED'
  | 'UNAUTHORIZED_ROUTE'
  | 'PRIVILEGE_ESCALATION_BLOCKED'
  | 'CROSS_TENANT_FORBIDDEN'
  | 'DUPLICATE_REGISTRATION'
  | 'RECOVERY_TOKEN_INVALID_OR_EXPIRED'
  | 'PROVIDER_NOT_CONFIGURED';

export interface AuthResult<T> {
  ok: boolean;
  data?: T;
  errorCode?: AuthErrorCode;
  errorMessage?: string;
  fieldErrors?: Record<string, string>;
}

export interface VerifiedServerSessionContext {
  isAuthenticated: boolean;
  accountState: AccountStateType;
  userId: string | null;
  email: string | null;
  fullName: string | null;
  serverRole: AppRole;
  isActiveProfile: boolean;
  primaryPartnerId: string | null;
  authorizedPartnerIds: string[];
  partnerStatus: PartnerStatus | null;
  partnerOnboardingStage: PartnerOnboardingStage | null;
  partnerRejectionReason: string | null;
  sessionExpiresAt: number | null;
  sessionTokenVerified: boolean;
  errorCode?: AuthErrorCode;
  errorMessage?: string;
}

export interface LoginCredentialsInput {
  email: string;
  password: string;
}

export interface UserRegistrationInput {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  acceptedTerms: boolean;
  phone?: string;
  city?: string;
  rawClientRoleAttempt?: unknown;
  rawClientPartnerIdAttempt?: unknown;
}

export interface PasswordRecoveryRequestInput {
  email: string;
}

export interface PasswordResetInput {
  recoveryToken: string;
  newPassword: string;
  confirmNewPassword: string;
}

export interface PartnerOnboardingApplicationInput {
  companyName: string;
  legalName: string;
  cnpj: string;
  whatsapp: string;
  businessEmail: string;
  baseMarina: string;
  yearsOperating?: number;
  bio?: string;
  rawClientPartnerIdAttempt?: unknown;
  rawClientStatusAttempt?: unknown;
}

export interface PartnerOnboardingRecord {
  partnerId: string;
  slug: string;
  companyName: string;
  legalName: string;
  cnpj: string;
  whatsapp: string;
  businessEmail: string;
  baseMarina: string;
  yearsOperating: number;
  bio: string;
  status: PartnerStatus;
  onboardingStage: PartnerOnboardingStage;
  verified: boolean;
  submittedByUserId: string;
  reviewedByUserId: string | null;
  reviewedAt: string | null;
  rejectionReason: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface RouteProtectionDecision {
  allowed: boolean;
  route: ProtectedRouteKey;
  redirectTo: ProtectedRouteKey | null;
  accountState: AccountStateType;
  reasonCode?: AuthErrorCode;
  message?: string;
}
