// ============================================================================
// PROTEÇÃO DE ROTAS E INTEGRAÇÃO COM AUTORIZAÇÃO OPERACIONAL (MISSÃO 02.19)
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Seções 7, 9, 11 e 12
// ============================================================================

import {
  ProtectedRouteKey,
  RouteProtectionDecision,
  VerifiedServerSessionContext,
} from './authTypes';
import { isSessionExpired } from './authSession';
import { OperationalAuthContext } from './operationsService';

const PUBLIC_ROUTES: readonly ProtectedRouteKey[] = [
  'public-marketplace',
  'auth-login',
  'auth-register',
  'auth-recovery',
  'auth-reset-password',
] as const;

const ADMIN_ROUTES: readonly ProtectedRouteKey[] = [
  'admin-portal',
  'admin-partners',
  'admin-tours',
  'admin-vessels',
  'admin-bookings',
  'admin-departures',
] as const;

const PARTNER_OPERATIONAL_ROUTES: readonly ProtectedRouteKey[] = [
  'partner-portal',
  'partner-tours',
  'partner-vessels',
  'partner-bookings',
  'partner-departures',
] as const;

export function isPublicRoute(route: ProtectedRouteKey): boolean {
  return PUBLIC_ROUTES.includes(route);
}

/**
 * Avalia o acesso a qualquer rota ou módulo operacional (Seção 11):
 * - Sem sessão: redireciona para 'auth-login'.
 * - Sessão expirada ou inválida: bloqueia e redireciona para 'auth-login'.
 * - Conta desativada: bloqueia operações protegidas.
 * - Conta pendente de aprovação (PENDENTE / EM_ANALISE): libera somente a tela de onboarding e acompanhamento ('partner-onboarding').
 * - Conta suspensa ou rejeitada: bloqueia operações protegidas (permitindo apenas visualizar o status em 'partner-onboarding').
 * - Turista: bloqueia painéis administrativos e de parceiros.
 * - Parceiro: limita estritamente aos próprios recursos (bloqueia acesso cruzado a outro partnerId).
 * - Administrador: libera conforme permissões verificadas no servidor.
 */
export function evaluateRouteProtection(
  route: ProtectedRouteKey,
  sessionCtx: VerifiedServerSessionContext | null | undefined,
  requestedPartnerId?: string | null,
  nowEpochMs: number = Date.now()
): RouteProtectionDecision {
  if (isPublicRoute(route)) {
    return {
      allowed: true,
      route,
      redirectTo: null,
      accountState: sessionCtx?.accountState || 'UNAUTHENTICATED',
    };
  }

  if (!sessionCtx) {
    return {
      allowed: false,
      route,
      redirectTo: 'auth-login',
      accountState: 'UNAUTHENTICATED',
      reasonCode: 'UNAUTHENTICATED',
      message: 'Autenticação necessária para acessar esta área restrita.',
    };
  }

  if (isSessionExpired(sessionCtx, nowEpochMs)) {
    return {
      allowed: false,
      route,
      redirectTo: 'auth-login',
      accountState: 'SESSION_EXPIRED',
      reasonCode: 'SESSION_EXPIRED',
      message: 'Sua sessão expirou. Faça login novamente para continuar.',
    };
  }

  if (!sessionCtx.isAuthenticated || !sessionCtx.sessionTokenVerified || !sessionCtx.userId) {
    return {
      allowed: false,
      route,
      redirectTo: 'auth-login',
      accountState: 'UNAUTHENTICATED',
      reasonCode: 'UNAUTHENTICATED',
      message: 'Você precisa entrar na sua conta para acessar esta área.',
    };
  }

  if (!sessionCtx.isActiveProfile || sessionCtx.accountState === 'ACCOUNT_DISABLED') {
    return {
      allowed: false,
      route,
      redirectTo: 'auth-login',
      accountState: 'ACCOUNT_DISABLED',
      reasonCode: 'ACCOUNT_DISABLED',
      message: 'Sua conta está desativada. Entre em contato com o suporte administrativo.',
    };
  }

  // Tela de onboarding e acompanhamento de parceiro
  if (route === 'partner-onboarding') {
    return {
      allowed: true,
      route,
      redirectTo: null,
      accountState: sessionCtx.accountState,
    };
  }

  // Conta de parceiro pendente de aprovação: redireciona exclusivamente para a tela de onboarding/acompanhamento
  if (
    sessionCtx.accountState === 'PARTNER_PENDING_APPROVAL' ||
    sessionCtx.partnerOnboardingStage === 'PENDENTE' ||
    sessionCtx.partnerOnboardingStage === 'EM_ANALISE'
  ) {
    return {
      allowed: false,
      route,
      redirectTo: 'partner-onboarding',
      accountState: 'PARTNER_PENDING_APPROVAL',
      reasonCode: 'ACCOUNT_PENDING_APPROVAL',
      message:
        'Seu cadastro de parceiro está pendente de análise e aprovação administrativa. Acompanhe o status na área de Onboarding.',
    };
  }

  // Conta suspensa ou rejeitada: bloqueia todas as rotas operacionais protegidas
  if (
    sessionCtx.accountState === 'PARTNER_SUSPENDED' ||
    sessionCtx.accountState === 'PARTNER_REJECTED' ||
    sessionCtx.partnerOnboardingStage === 'SUSPENSO' ||
    sessionCtx.partnerOnboardingStage === 'REJEITADO' ||
    sessionCtx.partnerStatus === 'SUSPENSO'
  ) {
    return {
      allowed: false,
      route,
      redirectTo: 'partner-onboarding',
      accountState: sessionCtx.accountState,
      reasonCode: 'ACCOUNT_SUSPENDED',
      message:
        'O acesso operacional deste parceiro encontra-se suspenso ou reprovado pela administração.',
    };
  }

  // Rotas do Painel Administrativo
  if (ADMIN_ROUTES.includes(route)) {
    if (sessionCtx.serverRole !== 'admin') {
      return {
        allowed: false,
        route,
        redirectTo:
          sessionCtx.serverRole === 'partner' ? 'partner-portal' : 'public-marketplace',
        accountState: 'UNAUTHORIZED_ACCESS',
        reasonCode: 'UNAUTHORIZED_ROUTE',
        message: 'Acesso negado: apenas administradores têm permissão para acessar o Painel Administrativo.',
      };
    }
    return {
      allowed: true,
      route,
      redirectTo: null,
      accountState: 'AUTHENTICATED_ACTIVE',
    };
  }

  // Rotas do Painel do Parceiro
  if (PARTNER_OPERATIONAL_ROUTES.includes(route)) {
    if (sessionCtx.serverRole === 'admin') {
      return {
        allowed: true,
        route,
        redirectTo: null,
        accountState: 'AUTHENTICATED_ACTIVE',
      };
    }

    if (sessionCtx.serverRole !== 'partner') {
      return {
        allowed: false,
        route,
        redirectTo: 'public-marketplace',
        accountState: 'UNAUTHORIZED_ACCESS',
        reasonCode: 'UNAUTHORIZED_ROUTE',
        message: 'Acesso negado: perfil de turista não possui acesso ao Painel do Parceiro.',
      };
    }

    if (
      !sessionCtx.primaryPartnerId ||
      !sessionCtx.authorizedPartnerIds.includes(sessionCtx.primaryPartnerId) ||
      sessionCtx.partnerStatus !== 'APROVADO' ||
      sessionCtx.partnerOnboardingStage !== 'APROVADO'
    ) {
      return {
        allowed: false,
        route,
        redirectTo: 'partner-onboarding',
        accountState: 'PARTNER_PENDING_APPROVAL',
        reasonCode: 'ACCOUNT_PENDING_APPROVAL',
        message: 'Parceiro sem vínculo homologado ativo. Conclua ou aguarde a aprovação do onboarding.',
      };
    }

    if (
      requestedPartnerId &&
      requestedPartnerId.trim() !== '' &&
      requestedPartnerId !== sessionCtx.primaryPartnerId
    ) {
      return {
        allowed: false,
        route,
        redirectTo: 'partner-portal',
        accountState: 'UNAUTHORIZED_ACCESS',
        reasonCode: 'CROSS_TENANT_FORBIDDEN',
        message: `Isolamento multiempresa: você não tem permissão para acessar recursos do parceiro "${requestedPartnerId}".`,
      };
    }

    return {
      allowed: true,
      route,
      redirectTo: null,
      accountState: 'AUTHENTICATED_ACTIVE',
    };
  }

  return {
    allowed: false,
    route,
    redirectTo: 'auth-login',
    accountState: 'UNAUTHORIZED_ACCESS',
    reasonCode: 'UNAUTHORIZED_ROUTE',
    message: 'Rota não autorizada.',
  };
}

/**
 * Constrói o OperationalAuthContext consumido por `operationsService.ts`
 * a partir da sessão verificada pelo servidor (Seção 9):
 * - O `actorPartnerId` é determinado EXCLUSIVAMENTE pelo servidor (`sessionCtx.primaryPartnerId`),
 *   jamais aceitando cegamente um `partnerId` arbitrário enviado pelo frontend.
 */
export function buildVerifiedOperationalAuthContext(
  sessionCtx: VerifiedServerSessionContext | null | undefined,
  nowEpochMs: number = Date.now()
): OperationalAuthContext {
  if (!sessionCtx || isSessionExpired(sessionCtx, nowEpochMs)) {
    return {
      actorRole: 'tourist',
      actorId: '',
      actorName: 'Não Autenticado',
      actorPartnerId: null,
      authorizedPartnerIds: [],
      isConnectedMode: true,
      serverVerifiedRole: 'tourist',
      hasServerVerifiedSession: false,
      verifiedSession: sessionCtx || undefined,
    };
  }

  const isActiveAndApproved =
    sessionCtx.isAuthenticated &&
    sessionCtx.sessionTokenVerified &&
    sessionCtx.isActiveProfile &&
    sessionCtx.accountState === 'AUTHENTICATED_ACTIVE';

  const effectiveRole = isActiveAndApproved ? sessionCtx.serverRole : 'tourist';

  return {
    actorRole: effectiveRole,
    actorId: isActiveAndApproved && sessionCtx.userId ? sessionCtx.userId : '',
    actorName: sessionCtx.fullName || sessionCtx.email || 'Usuário Autenticado',
    actorPartnerId:
      effectiveRole === 'partner' ? sessionCtx.primaryPartnerId : null,
    authorizedPartnerIds: isActiveAndApproved ? [...sessionCtx.authorizedPartnerIds] : [],
    isConnectedMode: true,
    serverVerifiedRole: effectiveRole,
    hasServerVerifiedSession: isActiveAndApproved,
    verifiedSession: sessionCtx,
  };
}
