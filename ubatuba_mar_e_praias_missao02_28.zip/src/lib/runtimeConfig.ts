export interface RuntimeEnvInput {
  VITE_SUPABASE_URL?: string;
  VITE_SUPABASE_ANON_KEY?: string;
  VITE_APP_ENV?: string;
  VITE_ENABLE_DEMO_MODE?: string;
  PROD?: boolean;
  MODE?: string;
}

export interface RuntimeGuardState {
  isProductionRuntime: boolean;
  isSupabaseConfigured: boolean;
  isDemoModeRequested: boolean;
  isDemoModeAllowed: boolean;
  isDemoBlockedInProduction: boolean;
  isConfigurationUnavailable: boolean;
  runtimeBlockReason:
    | 'NONE'
    | 'MISSING_SUPABASE_CONFIG_IN_PRODUCTION'
    | 'DEMO_MODE_FORBIDDEN_IN_PRODUCTION';
  supabaseUrl: string;
  supabaseAnonKey: string;
}

function normalizeEnvValue(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  return raw.trim();
}

function isPlaceholderValue(value: string): boolean {
  if (!value) return true;
  return value.includes('<') || value.includes('>');
}

function isValidHttpUrl(value: string): boolean {
  if (!value || isPlaceholderValue(value)) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

export function readViteRuntimeEnv(): RuntimeEnvInput {
  const metaEnv = ((import.meta as unknown as { env?: Record<string, unknown> })?.env) || {};
  return {
    VITE_SUPABASE_URL: typeof metaEnv.VITE_SUPABASE_URL === 'string' ? metaEnv.VITE_SUPABASE_URL : '',
    VITE_SUPABASE_ANON_KEY: typeof metaEnv.VITE_SUPABASE_ANON_KEY === 'string' ? metaEnv.VITE_SUPABASE_ANON_KEY : '',
    VITE_APP_ENV: typeof metaEnv.VITE_APP_ENV === 'string' ? metaEnv.VITE_APP_ENV : '',
    VITE_ENABLE_DEMO_MODE: typeof metaEnv.VITE_ENABLE_DEMO_MODE === 'string' ? metaEnv.VITE_ENABLE_DEMO_MODE : '',
    PROD: Boolean(metaEnv.PROD),
    MODE: typeof metaEnv.MODE === 'string' ? metaEnv.MODE : '',
  };
}

export function evaluateRuntimeGuard(envInput?: RuntimeEnvInput): RuntimeGuardState {
  const env = envInput ?? readViteRuntimeEnv();
  const appEnv = normalizeEnvValue(env.VITE_APP_ENV).toLowerCase();
  const mode = normalizeEnvValue(env.MODE).toLowerCase();
  const demoFlag = normalizeEnvValue(env.VITE_ENABLE_DEMO_MODE).toLowerCase();

  const isProductionRuntime =
    Boolean(env.PROD) || mode === 'production' || appEnv === 'production';

  const supabaseUrl = normalizeEnvValue(env.VITE_SUPABASE_URL);
  const supabaseAnonKey = normalizeEnvValue(env.VITE_SUPABASE_ANON_KEY);

  const isSupabaseConfigured =
    isValidHttpUrl(supabaseUrl) &&
    Boolean(supabaseAnonKey) &&
    !isPlaceholderValue(supabaseAnonKey);

  const isDemoModeRequested = demoFlag === 'true';

  if (isProductionRuntime) {
    if (isDemoModeRequested) {
      return {
        isProductionRuntime: true,
        isSupabaseConfigured,
        isDemoModeRequested: true,
        isDemoModeAllowed: false,
        isDemoBlockedInProduction: true,
        isConfigurationUnavailable: true,
        runtimeBlockReason: 'DEMO_MODE_FORBIDDEN_IN_PRODUCTION',
        supabaseUrl: isSupabaseConfigured ? supabaseUrl : '',
        supabaseAnonKey: isSupabaseConfigured ? supabaseAnonKey : '',
      };
    }

    if (!isSupabaseConfigured) {
      return {
        isProductionRuntime: true,
        isSupabaseConfigured: false,
        isDemoModeRequested: false,
        isDemoModeAllowed: false,
        isDemoBlockedInProduction: false,
        isConfigurationUnavailable: true,
        runtimeBlockReason: 'MISSING_SUPABASE_CONFIG_IN_PRODUCTION',
        supabaseUrl: '',
        supabaseAnonKey: '',
      };
    }

    return {
      isProductionRuntime: true,
      isSupabaseConfigured: true,
      isDemoModeRequested: false,
      isDemoModeAllowed: false,
      isDemoBlockedInProduction: false,
      isConfigurationUnavailable: false,
      runtimeBlockReason: 'NONE',
      supabaseUrl,
      supabaseAnonKey,
    };
  }

  // Non-production (development / local preview): demo fallback is allowed only if explicitly enabled
  // or if Supabase is not configured and VITE_ENABLE_DEMO_MODE is not explicitly 'false'.
  const isDemoModeAllowed =
    !isSupabaseConfigured && demoFlag !== 'false';

  return {
    isProductionRuntime: false,
    isSupabaseConfigured,
    isDemoModeRequested,
    isDemoModeAllowed,
    isDemoBlockedInProduction: false,
    isConfigurationUnavailable: !isSupabaseConfigured && !isDemoModeAllowed,
    runtimeBlockReason: 'NONE',
    supabaseUrl: isSupabaseConfigured ? supabaseUrl : '',
    supabaseAnonKey: isSupabaseConfigured ? supabaseAnonKey : '',
  };
}
