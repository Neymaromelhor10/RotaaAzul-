// ============================================================================
// SERVIÇO DE ONBOARDING DE PARCEIROS E ASSOCIAÇÃO SEGURA USUÁRIO <-> PARCEIRO
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Missão 02.19 (Seções 8, 9 e 12)
// ============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient';
import { PartnerStatus } from '../types/database.types';
import {
  AuthResult,
  PartnerOnboardingApplicationInput,
  PartnerOnboardingRecord,
  PartnerOnboardingStage,
  VerifiedServerSessionContext,
} from './authTypes';
import { validatePartnerOnboardingInput } from './authValidation';
import { isSessionExpired } from './authSession';
import { OperationalStateSnapshot } from './operationsService';

export interface PartnerUserLinkRecord {
  partnerId: string;
  userId: string;
  memberRole: 'owner' | 'manager' | 'operator';
  isActive: boolean;
  createdAt: string;
}

export interface OnboardingStateStore {
  applications: PartnerOnboardingRecord[];
  memberLinks: PartnerUserLinkRecord[];
}

/**
 * Executa a submissão de onboarding de um novo parceiro (Etapas 3, 4 e 5 da Seção 8):
 * - Exige usuário autenticado com sessão válida verificada no servidor.
 * - Rejeita se o usuário já possui vínculo com qualquer parceiro (impede criar vínculos cruzados ou múltiplos).
 * - Rejeita tentativa de enviar `partnerId` arbitrário ou `status = 'APROVADO'`.
 * - Atribui `partnerId` gerado no backend, registra como `status = 'PENDENTE'` e `onboardingStage = 'PENDENTE'`,
 *   e cria a associação segura usuário-parceiro.
 */
export function submitPartnerOnboardingInStore(
  store: OnboardingStateStore,
  operationalState: OperationalStateSnapshot,
  sessionCtx: VerifiedServerSessionContext | null | undefined,
  input: PartnerOnboardingApplicationInput,
  nowEpochMs: number = Date.now()
): AuthResult<{
  store: OnboardingStateStore;
  operationalState: OperationalStateSnapshot;
  onboarding: PartnerOnboardingRecord;
  updatedSession: VerifiedServerSessionContext;
}> {
  if (!sessionCtx || !sessionCtx.isAuthenticated || !sessionCtx.sessionTokenVerified || !sessionCtx.userId) {
    return {
      ok: false,
      errorCode: 'UNAUTHENTICATED',
      errorMessage: 'É obrigatório estar autenticado para enviar os dados de credenciamento de parceiro.',
    };
  }

  if (isSessionExpired(sessionCtx, nowEpochMs)) {
    return {
      ok: false,
      errorCode: 'SESSION_EXPIRED',
      errorMessage: 'Sua sessão expirou. Faça login novamente antes de enviar os dados da empresa.',
    };
  }

  if (!sessionCtx.isActiveProfile || sessionCtx.accountState === 'ACCOUNT_DISABLED') {
    return {
      ok: false,
      errorCode: 'ACCOUNT_DISABLED',
      errorMessage: 'Conta desativada não pode registrar novo parceiro.',
    };
  }

  const val = validatePartnerOnboardingInput(input);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }

  // Impede que um usuário já vinculado a um parceiro crie vínculo com outro parceiro
  const existingLink = store.memberLinks.find((m) => m.userId === sessionCtx.userId);
  if (existingLink || sessionCtx.primaryPartnerId) {
    return {
      ok: false,
      errorCode: 'CROSS_TENANT_FORBIDDEN',
      errorMessage:
        'Este usuário já possui vínculo com um parceiro registrado e não pode criar associação com outro parceiro.',
    };
  }

  // Verifica duplicidade de CNPJ ou nome fantasia
  const duplicateInOperational = operationalState.partners.find(
    (p) =>
      p.cnpj.replace(/\D+/g, '') === val.data!.cnpjDigits ||
      p.name.trim().toLowerCase() === val.data!.companyName.toLowerCase()
  );
  const duplicateInOnboarding = store.applications.find(
    (a) =>
      a.cnpj.replace(/\D+/g, '') === val.data!.cnpjDigits ||
      a.companyName.trim().toLowerCase() === val.data!.companyName.toLowerCase()
  );
  if (duplicateInOperational || duplicateInOnboarding) {
    return {
      ok: false,
      errorCode: 'DUPLICATE_REGISTRATION',
      errorMessage: 'Já existe uma empresa cadastrada ou em análise com este CNPJ ou nome fantasia.',
    };
  }

  const slugBase = val.data.companyName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  const seq = store.applications.length + operationalState.partners.length + 1;
  const generatedPartnerId = `part-onb-${slugBase || 'operador'}-${seq}`;
  const nowIso = new Date(nowEpochMs).toISOString();

  const onboardingRec: PartnerOnboardingRecord = {
    partnerId: generatedPartnerId,
    slug: `${slugBase || 'operador'}-${seq}`,
    companyName: val.data.companyName,
    legalName: val.data.legalName,
    cnpj: val.data.cnpj,
    whatsapp: val.data.whatsappDigits,
    businessEmail: val.data.businessEmail,
    baseMarina: val.data.baseMarina,
    yearsOperating: val.data.yearsOperating,
    bio: val.data.bio,
    status: 'PENDENTE',
    onboardingStage: 'PENDENTE',
    verified: false,
    submittedByUserId: sessionCtx.userId,
    reviewedByUserId: null,
    reviewedAt: null,
    rejectionReason: null,
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  const newLink: PartnerUserLinkRecord = {
    partnerId: generatedPartnerId,
    userId: sessionCtx.userId,
    memberRole: 'owner',
    isActive: true,
    createdAt: nowIso,
  };

  const nextOperationalPartner = {
    id: generatedPartnerId,
    name: onboardingRec.companyName,
    legalName: onboardingRec.legalName,
    cnpj: onboardingRec.cnpj,
    whatsapp: onboardingRec.whatsapp,
    email: onboardingRec.businessEmail,
    baseMarina: onboardingRec.baseMarina,
    status: 'PENDENTE' as PartnerStatus,
    isActive: true,
    verified: false,
    rating: 5.0,
    reviewsCount: 0,
    yearsOperating: onboardingRec.yearsOperating,
    commissionModel: 'PERCENTAGE' as const,
    commissionRate: 15,
    commissionFixed: 0,
    bio: onboardingRec.bio,
    avatarImage: '/media/embarcacao-lancha-passa-vinte.jpg',
    updatedAt: nowIso,
  };

  const updatedSession: VerifiedServerSessionContext = {
    ...sessionCtx,
    serverRole: 'partner',
    accountState: 'PARTNER_PENDING_APPROVAL',
    primaryPartnerId: generatedPartnerId,
    authorizedPartnerIds: [],
    partnerStatus: 'PENDENTE',
    partnerOnboardingStage: 'PENDENTE',
    partnerRejectionReason: null,
  };

  return {
    ok: true,
    data: {
      store: {
        applications: [onboardingRec, ...store.applications],
        memberLinks: [newLink, ...store.memberLinks],
      },
      operationalState: {
        ...operationalState,
        partners: [nextOperationalPartner, ...operationalState.partners],
      },
      onboarding: onboardingRec,
      updatedSession,
    },
  };
}

/**
 * Deliberação administrativa do onboarding de parceiros (Etapas 6, 7 e 8 da Seção 8):
 * - EXCLUSIVA para administradores autenticados e verificados no servidor (`serverRole === 'admin'`).
 * - Bloqueia qualquer tentativa do próprio parceiro de aprovar seu cadastro (`PRIVILEGE_ESCALATION_BLOCKED`).
 * - Suporta as transições para `EM_ANALISE`, `APROVADO`, `REJEITADO` e `SUSPENSO`.
 * - Libera o painel do parceiro (`accountState = 'AUTHENTICATED_ACTIVE'`) somente quando `decision === 'APROVAR'`.
 */
export function adminModeratePartnerOnboardingInStore(
  store: OnboardingStateStore,
  operationalState: OperationalStateSnapshot,
  actorSession: VerifiedServerSessionContext | null | undefined,
  partnerId: string,
  decision: 'EM_ANALISE' | 'APROVAR' | 'REJEITAR' | 'SUSPENDER',
  reason?: string,
  nowEpochMs: number = Date.now()
): AuthResult<{
  store: OnboardingStateStore;
  operationalState: OperationalStateSnapshot;
  onboarding: PartnerOnboardingRecord;
}> {
  if (!actorSession || !actorSession.isAuthenticated || !actorSession.sessionTokenVerified) {
    return {
      ok: false,
      errorCode: 'UNAUTHENTICATED',
      errorMessage: 'Sessão administrativa autenticada obrigatória para deliberar sobre onboarding.',
    };
  }

  if (actorSession.serverRole !== 'admin') {
    return {
      ok: false,
      errorCode: 'PRIVILEGE_ESCALATION_BLOCKED',
      errorMessage:
        'Operação bloqueada: somente o Administrador pode aprovar, colocar em análise, rejeitar ou suspender o onboarding de parceiros.',
    };
  }

  const existing = store.applications.find((a) => a.partnerId === partnerId);
  if (!existing) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: `Solicitação de onboarding do parceiro "${partnerId}" não encontrada.`,
    };
  }

  const cleanReason = typeof reason === 'string' ? reason.trim() : '';
  if ((decision === 'REJEITAR' || decision === 'SUSPENDER') && cleanReason.length < 3) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: `Informe o motivo (mínimo 3 caracteres) para ${decision.toLowerCase()} o cadastro do parceiro.`,
    };
  }

  let nextStatus: PartnerStatus = 'PENDENTE';
  let nextStage: PartnerOnboardingStage = 'PENDENTE';
  let nextVerified = false;
  let nextActive = true;

  if (decision === 'EM_ANALISE') {
    nextStatus = 'PENDENTE';
    nextStage = 'EM_ANALISE';
    nextVerified = false;
  } else if (decision === 'APROVAR') {
    nextStatus = 'APROVADO';
    nextStage = 'APROVADO';
    nextVerified = true;
    nextActive = true;
  } else if (decision === 'REJEITAR') {
    nextStatus = 'SUSPENSO';
    nextStage = 'REJEITADO';
    nextVerified = false;
    nextActive = false;
  } else if (decision === 'SUSPENDER') {
    nextStatus = 'SUSPENSO';
    nextStage = 'SUSPENSO';
    nextVerified = false;
    nextActive = false;
  }

  const nowIso = new Date(nowEpochMs).toISOString();
  const updatedOnboarding: PartnerOnboardingRecord = {
    ...existing,
    status: nextStatus,
    onboardingStage: nextStage,
    verified: nextVerified,
    reviewedByUserId: actorSession.userId,
    reviewedAt: nowIso,
    rejectionReason:
      decision === 'REJEITAR' || decision === 'SUSPENDER' ? cleanReason : null,
    updatedAt: nowIso,
  };

  const nextOperationalPartners = operationalState.partners.map((p) =>
    p.id === partnerId
      ? {
          ...p,
          status: nextStatus,
          isActive: nextActive,
          verified: nextVerified,
          rejectionReason: updatedOnboarding.rejectionReason || undefined,
          updatedAt: nowIso,
        }
      : p
  );

  return {
    ok: true,
    data: {
      store: {
        ...store,
        applications: store.applications.map((a) =>
          a.partnerId === partnerId ? updatedOnboarding : a
        ),
      },
      operationalState: {
        ...operationalState,
        partners: nextOperationalPartners,
      },
      onboarding: updatedOnboarding,
    },
  };
}

/**
 * Wrapper RPC para submissão de onboarding no Supabase PostgreSQL (`public.submit_partner_onboarding_application`).
 */
export async function rpcSubmitPartnerOnboardingApplication(
  input: PartnerOnboardingApplicationInput
): Promise<AuthResult<Record<string, unknown>>> {
  const val = validatePartnerOnboardingInput(input);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }

  if (!isSupabaseConfigured || !supabase) {
    return {
      ok: false,
      errorCode: 'PROVIDER_NOT_CONFIGURED',
      errorMessage: 'Supabase não configurado neste ambiente.',
    };
  }

  try {
    const { data, error } = await supabase.rpc('submit_partner_onboarding_application', {
      p_company_name: val.data.companyName,
      p_legal_name: val.data.legalName,
      p_cnpj: val.data.cnpj,
      p_whatsapp: val.data.whatsappDigits,
      p_business_email: val.data.businessEmail,
      p_base_marina: val.data.baseMarina,
      p_years_operating: val.data.yearsOperating,
      p_bio: val.data.bio,
    });

    if (error || !data) {
      return {
        ok: false,
        errorCode: 'VALIDATION_ERROR',
        errorMessage: error?.message || 'Erro ao registrar solicitação de onboarding no servidor.',
      };
    }

    return {
      ok: true,
      data: data as Record<string, unknown>,
    };
  } catch {
    return {
      ok: false,
      errorCode: 'NETWORK_ERROR',
      errorMessage: 'Falha de comunicação ao enviar solicitação de onboarding.',
    };
  }
}

/**
 * Wrapper RPC para deliberação administrativa de onboarding no Supabase PostgreSQL (`public.admin_moderate_partner_onboarding`).
 */
export async function rpcAdminModeratePartnerOnboarding(params: {
  partnerId: string;
  decision: 'EM_ANALISE' | 'APROVAR' | 'REJEITAR' | 'SUSPENDER' | 'REATIVAR';
  reason?: string;
}): Promise<AuthResult<Record<string, unknown>>> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      ok: false,
      errorCode: 'PROVIDER_NOT_CONFIGURED',
      errorMessage: 'Supabase não configurado neste ambiente.',
    };
  }

  try {
    const { data, error } = await supabase.rpc('admin_moderate_partner_onboarding', {
      p_partner_id: params.partnerId,
      p_decision: params.decision,
      p_reason: params.reason || null,
    });

    if (error || !data) {
      return {
        ok: false,
        errorCode: 'UNAUTHORIZED_ROUTE',
        errorMessage: error?.message || 'Deliberação de onboarding recusada pelo servidor.',
      };
    }

    return {
      ok: true,
      data: data as Record<string, unknown>,
    };
  } catch {
    return {
      ok: false,
      errorCode: 'NETWORK_ERROR',
      errorMessage: 'Falha de rede ao moderar onboarding do parceiro.',
    };
  }
}
