import { createClient } from '@supabase/supabase-js';
import { evaluateRuntimeGuard } from './runtimeConfig';

export const runtimeGuard = evaluateRuntimeGuard();
export const isSupabaseConfigured = runtimeGuard.isSupabaseConfigured;

export const supabase =
  runtimeGuard.isSupabaseConfigured && !runtimeGuard.isConfigurationUnavailable
    ? createClient(runtimeGuard.supabaseUrl, runtimeGuard.supabaseAnonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
      })
    : null;
