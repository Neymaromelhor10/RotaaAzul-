// ============================================================================
// SERVIÇO DE AUTENTICAÇÃO (LOGIN, LOGOUT, CADASTRO, RECUPERAÇÃO E SESSÃO)
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Missões 02.19 & 02.20 (Seção 5.2)
// ============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient';
import { AppRole, PartnerStatus } from '../types/database.types';
import {
  AuthResult,
  LoginCredentialsInput,
  PartnerOnboardingStage,
  PasswordRecoveryRequestInput,
  PasswordResetInput,
  UserRegistrationInput,
  VerifiedServerSessionContext,
} from './authTypes';
import {
  UNIFORM_LOGIN_FAILURE_MESSAGE,
  UNIFORM_RECOVERY_CONFIRMATION_MESSAGE,
  normalizeEmailInput,
  validateLoginInput,
  validatePasswordRecoveryEmail,
  validatePasswordResetPayload,
  validateRegistrationInput,
} from './authValidation';
import {
  VerifiedAuthSessionStore,
  createUnauthenticatedSessionContext,
  evaluateSessionAccountState,
  revalidateSessionAgainstPartnerState,
} from './authSession';

export interface AuthProviderAdapter {
  signInWithPassword(
    email: string,
    password: string
  ): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>>;
  signOut(sessionToken?: string | null): Promise<AuthResult<void>>;
  signUpUser(input: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
  }): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>>;
  requestPasswordRecovery(email: string): Promise<AuthResult<{ message: string; recoveryTokenForTestOnly?: string }>>;
  resetPasswordWithToken(
    recoveryToken: string,
    newPassword: string
  ): Promise<AuthResult<{ message: string }>>;
  verifySessionToken(
    sessionToken?: string | null
  ): Promise<AuthResult<VerifiedServerSessionContext>>;
}

/**
 * Adaptador oficial para Supabase Auth + RPC `public.get_authenticated_access_context()` (Migrations 000020 & 000021).
 * Não armazena senhas em tabelas públicas e delega toda a criptografia/verificação ao provedor.
 */
export class SupabaseAuthProviderAdapter implements AuthProviderAdapter {
  public async fetchServerAccessContext(): Promise<VerifiedServerSessionContext> {
    if (!isSupabaseConfigured || !supabase) {
      return createUnauthenticatedSessionContext(
        'UNAUTHENTICATED',
        'PROVIDER_NOT_CONFIGURED',
        'Provedor Supabase Auth ainda não configurado neste ambiente.'
      );
    }

    try {
      const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
      if (sessionErr || !sessionData?.session?.user) {
        return createUnauthenticatedSessionContext('UNAUTHENTICATED');
      }

      const expiresAtSec = sessionData.session.expires_at;
      const expiresAtMs = expiresAtSec ? expiresAtSec * 1000 : Date.now() + 3600_000;
      if (expiresAtMs <= Date.now()) {
        return createUnauthenticatedSessionContext(
          'SESSION_EXPIRED',
          'SESSION_EXPIRED',
          'Sessão expirada.'
        );
      }

      const { data: ctxData, error: rpcErr } = await supabase.rpc(
        'get_authenticated_access_context'
      );
      if (rpcErr || !ctxData || typeof ctxData !== 'object') {
        return createUnauthenticatedSessionContext(
          'UNAUTHENTICATED',
          'NETWORK_ERROR',
          rpcErr?.message || 'Falha ao consultar contexto de autorização no servidor.'
        );
      }

      const raw = ctxData as Record<string, unknown>;
      const isAuth = Boolean(raw.authenticated);
      const isActiveProfile = Boolean(raw.is_active_profile);
      const roleStr = String(raw.effective_role || 'tourist');
      const serverRole: AppRole =
        roleStr === 'admin' || roleStr === 'partner' ? roleStr : 'tourist';
      const partnerStatusRaw = raw.partner_status ? String(raw.partner_status) : null;
      const partnerStatus: PartnerStatus | null =
        partnerStatusRaw === 'APROVADO' ||
        partnerStatusRaw === 'PENDENTE' ||
        partnerStatusRaw === 'SUSPENSO'
          ? partnerStatusRaw
          : null;
      const stageRaw = raw.partner_onboarding_stage
        ? String(raw.partner_onboarding_stage)
        : null;
      const partnerOnboardingStage: PartnerOnboardingStage | null =
        stageRaw === 'PENDENTE' ||
        stageRaw === 'EM_ANALISE' ||
        stageRaw === 'APROVADO' ||
        stageRaw === 'REJEITADO' ||
        stageRaw === 'SUSPENSO'
          ? stageRaw
          : null;
      const primaryPartnerId = raw.primary_partner_id ? String(raw.primary_partner_id) : null;
      const authorizedPartnerIds = Array.isArray(raw.authorized_partner_ids)
        ? raw.authorized_partner_ids.map(String)
        : [];

      const accountState = evaluateSessionAccountState({
        isAuthenticated: isAuth,
        sessionTokenVerified: isAuth,
        isActiveProfile,
        serverRole,
        partnerStatus,
        partnerOnboardingStage,
        hasPartnerLink: Boolean(primaryPartnerId),
      });

      return {
        isAuthenticated: isAuth,
        accountState,
        userId: raw.user_id ? String(raw.user_id) : sessionData.session.user.id,
        email: raw.email ? String(raw.email) : sessionData.session.user.email || null,
        fullName: raw.full_name ? String(raw.full_name) : null,
        serverRole,
        isActiveProfile,
        primaryPartnerId,
        authorizedPartnerIds,
        partnerStatus,
        partnerOnboardingStage,
        partnerRejectionReason: raw.partner_rejection_reason
          ? String(raw.partner_rejection_reason)
          : null,
        sessionExpiresAt: expiresAtMs,
        sessionTokenVerified: isAuth,
      };
    } catch {
      return createUnauthenticatedSessionContext(
        'UNAUTHENTICATED',
        'NETWORK_ERROR',
        'Falha de comunicação com o servidor de autenticação.'
      );
    }
  }

  public async signInWithPassword(
    email: string,
    password: string
  ): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>> {
    if (!isSupabaseConfigured || !supabase) {
      return {
        ok: false,
        errorCode: 'PROVIDER_NOT_CONFIGURED',
        errorMessage: 'Serviço Supabase Auth não configurado neste ambiente.',
      };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error || !data?.session) {
        return {
          ok: false,
          errorCode: 'INVALID_CREDENTIALS',
          errorMessage: UNIFORM_LOGIN_FAILURE_MESSAGE,
        };
      }

      const session = await this.fetchServerAccessContext();
      if (session.accountState === 'ACCOUNT_DISABLED') {
        await supabase.auth.signOut();
        return {
          ok: false,
          errorCode: 'ACCOUNT_DISABLED',
          errorMessage: 'Esta conta encontra-se desativada.',
        };
      }

      return {
        ok: true,
        data: {
          session,
          sessionToken: data.session.access_token,
        },
      };
    } catch {
      return {
        ok: false,
        errorCode: 'NETWORK_ERROR',
        errorMessage: 'Não foi possível conectar ao servidor de autenticação. Tente novamente.',
      };
    }
  }

  public async signOut(): Promise<AuthResult<void>> {
    if (!isSupabaseConfigured || !supabase) {
      return { ok: true };
    }
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        return {
          ok: false,
          errorCode: 'NETWORK_ERROR',
          errorMessage: 'Erro ao encerrar sessão no provedor.',
        };
      }
      return { ok: true };
    } catch {
      return {
        ok: false,
        errorCode: 'NETWORK_ERROR',
        errorMessage: 'Falha de rede durante o encerramento da sessão.',
      };
    }
  }

  public async signUpUser(input: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
  }): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>> {
    if (!isSupabaseConfigured || !supabase) {
      return {
        ok: false,
        errorCode: 'PROVIDER_NOT_CONFIGURED',
        errorMessage: 'Serviço Supabase Auth não configurado neste ambiente.',
      };
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email: input.email,
        password: input.password,
        options: {
          // Nunca envia system_role ou partner_id nos metadados de cliente
          data: {
            full_name: input.fullName,
            phone: input.phone || null,
            city: input.city || null,
          },
        },
      });

      if (error || !data?.user) {
        return {
          ok: false,
          errorCode: 'DUPLICATE_REGISTRATION',
          errorMessage: 'Não foi possível concluir o cadastro com os dados informados.',
        };
      }

      const session = await this.fetchServerAccessContext();
      return {
        ok: true,
        data: {
          session,
          sessionToken: data.session?.access_token || '',
        },
      };
    } catch {
      return {
        ok: false,
        errorCode: 'NETWORK_ERROR',
        errorMessage: 'Falha de rede ao registrar usuário.',
      };
    }
  }

  public async requestPasswordRecovery(
    email: string
  ): Promise<AuthResult<{ message: string }>> {
    if (!isSupabaseConfigured || !supabase) {
      return {
        ok: false,
        errorCode: 'PROVIDER_NOT_CONFIGURED',
        errorMessage: 'Serviço Supabase Auth não configurado neste ambiente.',
      };
    }

    try {
      await supabase.auth.resetPasswordForEmail(email);
      // Sempre retorna mensagem uniforme anti-enumeração
      return {
        ok: true,
        data: { message: UNIFORM_RECOVERY_CONFIRMATION_MESSAGE },
      };
    } catch {
      return {
        ok: false,
        errorCode: 'NETWORK_ERROR',
        errorMessage: 'Falha de rede ao solicitar recuperação de senha.',
      };
    }
  }

  public async resetPasswordWithToken(
    _recoveryToken: string,
    newPassword: string
  ): Promise<AuthResult<{ message: string }>> {
    if (!isSupabaseConfigured || !supabase) {
      return {
        ok: false,
        errorCode: 'PROVIDER_NOT_CONFIGURED',
        errorMessage: 'Serviço Supabase Auth não configurado neste ambiente.',
      };
    }

    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) {
        return {
          ok: false,
          errorCode: 'RECOVERY_TOKEN_INVALID_OR_EXPIRED',
          errorMessage: 'O link de redefinição de senha é inválido ou expirou.',
        };
      }
      return {
        ok: true,
        data: { message: 'Sua senha foi redefinida com sucesso.' },
      };
    } catch {
      return {
        ok: false,
        errorCode: 'NETWORK_ERROR',
        errorMessage: 'Falha de rede ao redefinir a senha.',
      };
    }
  }

  public async verifySessionToken(): Promise<AuthResult<VerifiedServerSessionContext>> {
    const ctx = await this.fetchServerAccessContext();
    if (!ctx.isAuthenticated) {
      return {
        ok: false,
        errorCode: ctx.errorCode || 'UNAUTHENTICATED',
        errorMessage: ctx.errorMessage || 'Sessão não autenticada.',
        data: ctx,
      };
    }
    return { ok: true, data: ctx };
  }
}

// ============================================================================
// FUNÇÕES DE ALTO NÍVEL DO SERVIÇO DE AUTENTICAÇÃO (SEÇÕES 4, 5 E 6)
// ============================================================================

export async function loginWithEmailPassword(
  adapter: AuthProviderAdapter,
  input: LoginCredentialsInput
): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>> {
  const val = validateLoginInput(input);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }
  return adapter.signInWithPassword(val.data.email, input.password);
}

export async function logoutCurrentSession(
  adapter: AuthProviderAdapter,
  sessionToken?: string | null
): Promise<AuthResult<void>> {
  return adapter.signOut(sessionToken);
}

export async function registerUserAccount(
  adapter: AuthProviderAdapter,
  input: UserRegistrationInput
): Promise<AuthResult<{ session: VerifiedServerSessionContext; sessionToken: string }>> {
  const val = validateRegistrationInput(input);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }
  return adapter.signUpUser({
    fullName: val.data.fullName,
    email: val.data.email,
    password: input.password,
    phone: input.phone,
    city: input.city,
  });
}

export async function requestPasswordRecovery(
  adapter: AuthProviderAdapter,
  input: PasswordRecoveryRequestInput
): Promise<AuthResult<{ message: string; recoveryTokenForTestOnly?: string }>> {
  const val = validatePasswordRecoveryEmail(input?.email);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }
  return adapter.requestPasswordRecovery(normalizeEmailInput(val.data.email));
}

export async function resetPasswordWithRecoveryToken(
  adapter: AuthProviderAdapter,
  input: PasswordResetInput
): Promise<AuthResult<{ message: string }>> {
  const val = validatePasswordResetPayload(input);
  if (!val.ok || !val.data) {
    return {
      ok: false,
      errorCode: val.errorCode || 'VALIDATION_ERROR',
      errorMessage: val.errorMessage,
      fieldErrors: val.fieldErrors,
    };
  }
  return adapter.resetPasswordWithToken(val.data.cleanToken, input.newPassword);
}

export async function restoreAndVerifySession(
  adapter: AuthProviderAdapter,
  sessionToken?: string | null
): Promise<AuthResult<VerifiedServerSessionContext>> {
  return adapter.verifySessionToken(sessionToken);
}

/**
 * Restauração de sessão pós-F5 (Missão 02.20 — Seção 5.2 / M02.20-F03):
 * - Nunca confia em estado de role/partnerId persistido localmente pelo cliente.
 * - Revalida o token opaco no provedor de backend (`verifySessionToken`) e, em seguida,
 *   cruza o resultado com o estado vivo de parceiros (`revalidateSessionAgainstPartnerState`)
 *   para bloquear imediatamente sessões expiradas, encerradas ou cujo parceiro tenha sido suspenso.
 */
export async function restoreSessionAfterReload(
  adapter: AuthProviderAdapter,
  sessionStore: VerifiedAuthSessionStore,
  sessionToken?: string | null,
  livePartners?: readonly {
    id: string;
    status: PartnerStatus;
    isActive?: boolean;
    rejectionReason?: string;
  }[]
): Promise<AuthResult<VerifiedServerSessionContext>> {
  if (!sessionToken || sessionToken.trim() === '') {
    const unauth = sessionStore.clearSession();
    return {
      ok: false,
      errorCode: 'UNAUTHENTICATED',
      errorMessage: 'Nenhuma sessão autenticada ativa para restaurar.',
      data: unauth,
    };
  }

  const verifiedRes = await adapter.verifySessionToken(sessionToken);
  if (!verifiedRes.ok || !verifiedRes.data || !verifiedRes.data.isAuthenticated) {
    if (verifiedRes.errorCode === 'SESSION_EXPIRED') {
      const exp = sessionStore.markSessionExpired(verifiedRes.errorMessage);
      return {
        ok: false,
        errorCode: 'SESSION_EXPIRED',
        errorMessage: exp.errorMessage || 'Sessão expirada.',
        data: exp,
      };
    }
    const cleared = sessionStore.clearSession();
    return {
      ok: false,
      errorCode: verifiedRes.errorCode || 'UNAUTHENTICATED',
      errorMessage: verifiedRes.errorMessage || 'Sessão inválida ou encerrada.',
      data: cleared,
    };
  }

  const revalidated = livePartners
    ? revalidateSessionAgainstPartnerState(verifiedRes.data, livePartners)
    : verifiedRes.data;

  sessionStore.setVerifiedSession(revalidated, sessionToken);
  return {
    ok: true,
    data: revalidated,
  };
}
