// ============================================================================
// VALIDADORES DE CREDENCIAIS, CADASTRO, RECUPERAÇÃO DE SENHA E ANTI-ENUMERAÇÃO
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Missão 02.19 (Seções 4, 5, 6 e 12)
// ============================================================================

import {
  AuthResult,
  LoginCredentialsInput,
  PartnerOnboardingApplicationInput,
  PasswordResetInput,
  UserRegistrationInput,
} from './authTypes';

export const UNIFORM_LOGIN_FAILURE_MESSAGE =
  'Credenciais inválidas. Verifique seu e-mail e senha.';

export const UNIFORM_RECOVERY_CONFIRMATION_MESSAGE =
  'Se o endereço de e-mail informado estiver vinculado a uma conta, você receberá as instruções para redefinir sua senha.';

export function normalizeEmailInput(email: unknown): string {
  if (typeof email !== 'string') return '';
  return email.trim().toLowerCase();
}

export function isValidEmailAddress(email: unknown): boolean {
  const clean = normalizeEmailInput(email);
  if (!clean || clean.length < 5 || clean.length > 254) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(clean);
}

export function isStrongPassword(password: unknown): {
  valid: boolean;
  reason?: string;
} {
  if (typeof password !== 'string') {
    return { valid: false, reason: 'A senha é obrigatória.' };
  }
  if (password.length < 8) {
    return { valid: false, reason: 'A senha deve conter no mínimo 8 caracteres.' };
  }
  if (password.length > 128) {
    return { valid: false, reason: 'A senha excede o tamanho máximo permitido (128 caracteres).' };
  }
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    return {
      valid: false,
      reason: 'A senha deve conter pelo menos uma letra e um número.',
    };
  }
  return { valid: true };
}

export function validateLoginInput(
  input: LoginCredentialsInput
): AuthResult<{ email: string }> {
  const fieldErrors: Record<string, string> = {};
  const cleanEmail = normalizeEmailInput(input?.email);

  if (!isValidEmailAddress(cleanEmail)) {
    fieldErrors.email = 'Informe um endereço de e-mail válido.';
  }
  if (!input?.password || typeof input.password !== 'string' || input.password.length < 1) {
    fieldErrors.password = 'Informe sua senha de acesso.';
  }

  if (Object.keys(fieldErrors).length > 0) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: Object.values(fieldErrors)[0],
      fieldErrors,
    };
  }

  return {
    ok: true,
    data: { email: cleanEmail },
  };
}

/**
 * Valida cadastro de novos usuários (Seção 5):
 * - Exige nome completo, e-mail válido, senha forte, confirmação idêntica e aceite dos termos.
 * - Bloqueia qualquer tentativa do navegador de atribuir privilégio administrativo
 *   (`role = 'admin'`, `system_role = 'admin'`) ou `partnerId` arbitrário.
 */
export function validateRegistrationInput(
  input: UserRegistrationInput
): AuthResult<{
  fullName: string;
  email: string;
  sanitizedRole: 'tourist';
}> {
  if (
    input?.rawClientRoleAttempt !== undefined &&
    input.rawClientRoleAttempt !== null &&
    String(input.rawClientRoleAttempt).toLowerCase() !== 'tourist'
  ) {
    return {
      ok: false,
      errorCode: 'PRIVILEGE_ESCALATION_BLOCKED',
      errorMessage:
        'Tentativa de elevação de privilégio bloqueada: o cadastro público não pode atribuir perfil administrativo ou de parceiro pelo navegador.',
    };
  }

  if (
    input?.rawClientPartnerIdAttempt !== undefined &&
    input.rawClientPartnerIdAttempt !== null &&
    String(input.rawClientPartnerIdAttempt).trim() !== ''
  ) {
    return {
      ok: false,
      errorCode: 'PRIVILEGE_ESCALATION_BLOCKED',
      errorMessage:
        'Tentativa de associação arbitrária bloqueada: o cadastro público não aceita partnerId enviado pelo cliente.',
    };
  }

  const fieldErrors: Record<string, string> = {};
  const cleanName = typeof input?.fullName === 'string' ? input.fullName.trim() : '';
  const cleanEmail = normalizeEmailInput(input?.email);

  if (cleanName.length < 3) {
    fieldErrors.fullName = 'Informe seu nome completo (mínimo de 3 caracteres).';
  }
  if (!isValidEmailAddress(cleanEmail)) {
    fieldErrors.email = 'Informe um endereço de e-mail válido.';
  }

  const pwdCheck = isStrongPassword(input?.password);
  if (!pwdCheck.valid) {
    fieldErrors.password = pwdCheck.reason || 'Senha inválida.';
  }

  if (input?.password !== input?.confirmPassword) {
    fieldErrors.confirmPassword = 'A confirmação de senha não coincide com a senha informada.';
  }

  if (input?.acceptedTerms !== true) {
    fieldErrors.acceptedTerms =
      'É obrigatório aceitar os termos de uso e a política de privacidade para criar a conta.';
  }

  if (Object.keys(fieldErrors).length > 0) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: Object.values(fieldErrors)[0],
      fieldErrors,
    };
  }

  return {
    ok: true,
    data: {
      fullName: cleanName,
      email: cleanEmail,
      sanitizedRole: 'tourist',
    },
  };
}

export function validatePasswordRecoveryEmail(
  email: unknown
): AuthResult<{ email: string; publicNotice: string }> {
  const cleanEmail = normalizeEmailInput(email);
  if (!isValidEmailAddress(cleanEmail)) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: 'Informe um endereço de e-mail em formato válido.',
      fieldErrors: { email: 'Formato de e-mail inválido.' },
    };
  }
  return {
    ok: true,
    data: {
      email: cleanEmail,
      publicNotice: UNIFORM_RECOVERY_CONFIRMATION_MESSAGE,
    },
  };
}

export function validatePasswordResetPayload(
  input: PasswordResetInput
): AuthResult<{ cleanToken: string }> {
  const token = typeof input?.recoveryToken === 'string' ? input.recoveryToken.trim() : '';
  if (!token || token.length < 12) {
    return {
      ok: false,
      errorCode: 'RECOVERY_TOKEN_INVALID_OR_EXPIRED',
      errorMessage: 'O link ou código de recuperação de senha é inválido ou expirou.',
    };
  }

  const pwdCheck = isStrongPassword(input?.newPassword);
  if (!pwdCheck.valid) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: pwdCheck.reason || 'A nova senha não atende aos requisitos mínimos de segurança.',
      fieldErrors: { newPassword: pwdCheck.reason || 'Nova senha inválida.' },
    };
  }

  if (input.newPassword !== input.confirmNewPassword) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: 'A confirmação da nova senha não coincide.',
      fieldErrors: { confirmNewPassword: 'As senhas não coincidem.' },
    };
  }

  return {
    ok: true,
    data: { cleanToken: token },
  };
}

export function validatePartnerOnboardingInput(
  input: PartnerOnboardingApplicationInput
): AuthResult<{
  companyName: string;
  legalName: string;
  cnpj: string;
  cnpjDigits: string;
  whatsappDigits: string;
  businessEmail: string;
  baseMarina: string;
  yearsOperating: number;
  bio: string;
}> {
  if (
    input?.rawClientPartnerIdAttempt !== undefined &&
    input.rawClientPartnerIdAttempt !== null &&
    String(input.rawClientPartnerIdAttempt).trim() !== ''
  ) {
    return {
      ok: false,
      errorCode: 'PRIVILEGE_ESCALATION_BLOCKED',
      errorMessage:
        'Segurança: o onboarding de parceiros não permite que o cliente atribua um partnerId arbitrário.',
    };
  }

  if (
    input?.rawClientStatusAttempt !== undefined &&
    input.rawClientStatusAttempt !== null &&
    String(input.rawClientStatusAttempt).toUpperCase() === 'APROVADO'
  ) {
    return {
      ok: false,
      errorCode: 'PRIVILEGE_ESCALATION_BLOCKED',
      errorMessage: 'Segurança: o parceiro não pode autoaprovar o próprio cadastro de onboarding.',
    };
  }

  const fieldErrors: Record<string, string> = {};
  const companyName = typeof input?.companyName === 'string' ? input.companyName.trim() : '';
  const legalName = typeof input?.legalName === 'string' ? input.legalName.trim() : '';
  const cnpj = typeof input?.cnpj === 'string' ? input.cnpj.trim() : '';
  const cnpjDigits = cnpj.replace(/\D+/g, '');
  const whatsappDigits = String(input?.whatsapp || '').replace(/\D+/g, '');
  const businessEmail = normalizeEmailInput(input?.businessEmail);
  const baseMarina = typeof input?.baseMarina === 'string' ? input.baseMarina.trim() : '';

  if (companyName.length < 3) {
    fieldErrors.companyName = 'O nome fantasia da empresa deve conter ao menos 3 caracteres.';
  }
  if (legalName.length < 3) {
    fieldErrors.legalName = 'A razão social deve conter ao menos 3 caracteres.';
  }
  if (cnpjDigits.length !== 14 || /^(\d)\1{13}$/.test(cnpjDigits)) {
    fieldErrors.cnpj = 'O CNPJ deve conter 14 dígitos numéricos válidos.';
  }
  if (whatsappDigits.length < 10 || whatsappDigits.length > 15) {
    fieldErrors.whatsapp = 'Informe um WhatsApp operacional válido (10 a 15 dígitos).';
  }
  if (!isValidEmailAddress(businessEmail)) {
    fieldErrors.businessEmail = 'Informe um e-mail corporativo válido.';
  }
  if (baseMarina.length < 3) {
    fieldErrors.baseMarina = 'Informe a marina ou base náutica de operação.';
  }

  if (Object.keys(fieldErrors).length > 0) {
    return {
      ok: false,
      errorCode: 'VALIDATION_ERROR',
      errorMessage: Object.values(fieldErrors)[0],
      fieldErrors,
    };
  }

  const normalizedWhatsapp =
    whatsappDigits.length === 10 || whatsappDigits.length === 11
      ? `55${whatsappDigits}`
      : whatsappDigits;

  return {
    ok: true,
    data: {
      companyName,
      legalName,
      cnpj,
      cnpjDigits,
      whatsappDigits: normalizedWhatsapp,
      businessEmail,
      baseMarina,
      yearsOperating: Math.max(1, Number(input.yearsOperating) || 1),
      bio:
        typeof input.bio === 'string' && input.bio.trim().length > 0
          ? input.bio.trim()
          : `Operador náutico em processo de credenciamento na ${baseMarina}.`,
    },
  };
}
