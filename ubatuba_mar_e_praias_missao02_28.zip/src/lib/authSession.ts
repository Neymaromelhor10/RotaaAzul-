// ============================================================================
// GERENCIAMENTO DE SESSÃO VERIFICADA PELO SERVIDOR (SEM CONFIANÇA EM JSON LOCAL)
// Projeto: Ubatuba Mar & Praias (Rota Azul) — Missões 02.19 & 02.20 (Seção 5.2)
// ============================================================================
// Arquitetura de Persistência e Restauração Pós-F5 (M02.20-F03):
//   1. PROIBIDO confiar em objetos JSON salvos em localStorage contendo `role`,
//      `partnerId` ou flags booleanas (`isAuthenticated: true`) como fonte de
//      verdade de autorização no navegador.
//   2. Em produção (Supabase Auth), o provedor gerencia o handle/cookie de
//      transporte e, a cada inicialização ou F5 (`restoreSessionAfterReload`),
//      o cliente consulta obrigatoriamente o servidor via RPC
//      `public.get_authenticated_access_context()` para reconstruir
//      `VerifiedServerSessionContext` em memória (`VerifiedAuthSessionStore`).
//   3. Se o token expirou, foi revogado no logout ou o parceiro foi suspenso
//      pela administração (`revalidateSessionAgainstPartnerState`), a sessão em
//      memória é imediatamente invalidada/atualizada em modo fail-closed.
// ============================================================================

import { AppRole, PartnerStatus } from '../types/database.types';
import {
  AccountStateType,
  AuthErrorCode,
  PartnerOnboardingStage,
  VerifiedServerSessionContext,
} from './authTypes';

export function createUnauthenticatedSessionContext(
  accountState: AccountStateType = 'UNAUTHENTICATED',
  errorCode?: AuthErrorCode,
  errorMessage?: string
): VerifiedServerSessionContext {
  return {
    isAuthenticated: false,
    accountState,
    userId: null,
    email: null,
    fullName: null,
    serverRole: 'tourist',
    isActiveProfile: false,
    primaryPartnerId: null,
    authorizedPartnerIds: [],
    partnerStatus: null,
    partnerOnboardingStage: null,
    partnerRejectionReason: null,
    sessionExpiresAt: null,
    sessionTokenVerified: false,
    errorCode,
    errorMessage,
  };
}

export function isSessionExpired(
  sessionCtx: VerifiedServerSessionContext | null | undefined,
  nowEpochMs: number = Date.now()
): boolean {
  if (!sessionCtx || !sessionCtx.isAuthenticated) return false;
  if (sessionCtx.accountState === 'SESSION_EXPIRED') return true;
  if (typeof sessionCtx.sessionExpiresAt === 'number' && sessionCtx.sessionExpiresAt <= nowEpochMs) {
    return true;
  }
  return false;
}

export function evaluateSessionAccountState(params: {
  isAuthenticated: boolean;
  sessionTokenVerified: boolean;
  isExpired?: boolean;
  isActiveProfile?: boolean;
  serverRole?: AppRole;
  partnerStatus?: PartnerStatus | null;
  partnerOnboardingStage?: PartnerOnboardingStage | null;
  hasPartnerLink?: boolean;
}): AccountStateType {
  if (params.isExpired) {
    return 'SESSION_EXPIRED';
  }
  if (!params.isAuthenticated || !params.sessionTokenVerified) {
    return 'UNAUTHENTICATED';
  }
  if (params.isActiveProfile === false) {
    return 'ACCOUNT_DISABLED';
  }
  if (params.serverRole === 'admin') {
    return 'AUTHENTICATED_ACTIVE';
  }

  // Se o usuário possui vínculo ou solicitação de parceiro, avalia o estágio do onboarding
  if (params.hasPartnerLink || params.serverRole === 'partner') {
    const stage = params.partnerOnboardingStage;
    const status = params.partnerStatus;
    if (stage === 'REJEITADO') {
      return 'PARTNER_REJECTED';
    }
    if (stage === 'SUSPENSO' || status === 'SUSPENSO') {
      return 'PARTNER_SUSPENDED';
    }
    if (
      !params.hasPartnerLink ||
      stage === 'PENDENTE' ||
      stage === 'EM_ANALISE' ||
      status === 'PENDENTE'
    ) {
      return 'PARTNER_PENDING_APPROVAL';
    }
    if (stage === 'APROVADO' && status === 'APROVADO') {
      return 'AUTHENTICATED_ACTIVE';
    }
    return 'PARTNER_PENDING_APPROVAL';
  }

  return 'AUTHENTICATED_ACTIVE';
}

/**
 * Revalida uma sessão em memória contra o estado operacional vivo de parceiros (M02.20-F02 / M02.20-F03).
 * Garante que se um parceiro for suspenso, desativado ou colocado em análise após o login,
 * sua sessão reflita imediatamente o novo estado e perca o acesso operacional sem esperar novo login.
 */
export function revalidateSessionAgainstPartnerState(
  sessionCtx: VerifiedServerSessionContext,
  partners: readonly {
    id: string;
    status: PartnerStatus;
    isActive?: boolean;
    rejectionReason?: string;
  }[],
  nowEpochMs: number = Date.now()
): VerifiedServerSessionContext {
  if (isSessionExpired(sessionCtx, nowEpochMs)) {
    return createUnauthenticatedSessionContext(
      'SESSION_EXPIRED',
      'SESSION_EXPIRED',
      'Sua sessão expirou por segurança. Faça login novamente para continuar.'
    );
  }
  if (!sessionCtx.isAuthenticated || !sessionCtx.primaryPartnerId) {
    return {
      ...sessionCtx,
      authorizedPartnerIds: [...sessionCtx.authorizedPartnerIds],
    };
  }

  const livePartner = partners.find((p) => p.id === sessionCtx.primaryPartnerId);
  if (!livePartner) {
    return {
      ...sessionCtx,
      authorizedPartnerIds: [...sessionCtx.authorizedPartnerIds],
    };
  }

  const isSuspendedOrInactive =
    livePartner.status === 'SUSPENSO' || livePartner.isActive === false;
  const nextPartnerStatus: PartnerStatus = isSuspendedOrInactive
    ? 'SUSPENSO'
    : livePartner.status;
  const nextStage: PartnerOnboardingStage = isSuspendedOrInactive
    ? sessionCtx.partnerOnboardingStage === 'REJEITADO'
      ? 'REJEITADO'
      : 'SUSPENSO'
    : livePartner.status === 'APROVADO'
    ? 'APROVADO'
    : sessionCtx.partnerOnboardingStage === 'EM_ANALISE'
    ? 'EM_ANALISE'
    : 'PENDENTE';

  const nextAccountState = evaluateSessionAccountState({
    isAuthenticated: sessionCtx.isAuthenticated,
    sessionTokenVerified: sessionCtx.sessionTokenVerified,
    isActiveProfile: sessionCtx.isActiveProfile,
    serverRole: sessionCtx.serverRole,
    partnerStatus: nextPartnerStatus,
    partnerOnboardingStage: nextStage,
    hasPartnerLink: true,
  });

  return {
    ...sessionCtx,
    accountState: nextAccountState,
    partnerStatus: nextPartnerStatus,
    partnerOnboardingStage: nextStage,
    partnerRejectionReason:
      livePartner.rejectionReason ?? sessionCtx.partnerRejectionReason ?? null,
    authorizedPartnerIds:
      nextPartnerStatus === 'APROVADO' && nextStage === 'APROVADO'
        ? [livePartner.id]
        : [],
  };
}

/**
 * Gerenciador em memória de sessão verificada pelo servidor.
 * Regra Seção 3 & 12 (Missão 02.19) e Seção 5.2 (Missão 02.20):
 *   - NUNCA armazena objetos de identidade/role ou senhas em localStorage como mecanismo de autenticação.
 *   - NUNCA registra tokens ou credenciais em console/logs.
 */
export class VerifiedAuthSessionStore {
  private currentSession: VerifiedServerSessionContext = createUnauthenticatedSessionContext();
  private activeSessionToken: string | null = null;
  private listeners: Array<(ctx: VerifiedServerSessionContext) => void> = [];

  public getSession(nowEpochMs: number = Date.now()): VerifiedServerSessionContext {
    if (isSessionExpired(this.currentSession, nowEpochMs)) {
      this.activeSessionToken = null;
      this.currentSession = createUnauthenticatedSessionContext(
        'SESSION_EXPIRED',
        'SESSION_EXPIRED',
        'Sua sessão expirou por segurança. Faça login novamente para continuar.'
      );
    }
    return {
      ...this.currentSession,
      authorizedPartnerIds: [...this.currentSession.authorizedPartnerIds],
    };
  }

  public getActiveSessionToken(nowEpochMs: number = Date.now()): string | null {
    if (isSessionExpired(this.currentSession, nowEpochMs)) {
      this.activeSessionToken = null;
      return null;
    }
    return this.activeSessionToken;
  }

  public setVerifiedSession(
    sessionCtx: VerifiedServerSessionContext,
    serverToken: string | null
  ): VerifiedServerSessionContext {
    this.activeSessionToken = sessionCtx.isAuthenticated ? serverToken : null;
    this.currentSession = {
      ...sessionCtx,
      authorizedPartnerIds: [...sessionCtx.authorizedPartnerIds],
    };
    this.notify();
    return this.getSession();
  }

  public syncWithPartnerOperationalState(
    partners: Array<{
      id: string;
      status: PartnerStatus;
      isActive?: boolean;
      rejectionReason?: string;
    }>,
    nowEpochMs: number = Date.now()
  ): VerifiedServerSessionContext {
    this.currentSession = revalidateSessionAgainstPartnerState(
      this.currentSession,
      partners,
      nowEpochMs
    );
    if (!this.currentSession.isAuthenticated) {
      this.activeSessionToken = null;
    }
    this.notify();
    return this.getSession(nowEpochMs);
  }

  public markSessionExpired(message?: string): VerifiedServerSessionContext {
    this.activeSessionToken = null;
    this.currentSession = createUnauthenticatedSessionContext(
      'SESSION_EXPIRED',
      'SESSION_EXPIRED',
      message || 'Sua sessão expirou. Autentique-se novamente.'
    );
    this.notify();
    return this.getSession();
  }

  public clearSession(): VerifiedServerSessionContext {
    this.activeSessionToken = null;
    this.currentSession = createUnauthenticatedSessionContext('UNAUTHENTICATED');
    this.notify();
    return this.getSession();
  }

  public subscribe(listener: (ctx: VerifiedServerSessionContext) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    const snap = this.getSession();
    for (const l of this.listeners) {
      l(snap);
    }
  }
}
