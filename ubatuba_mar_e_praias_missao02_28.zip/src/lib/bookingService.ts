// ============================================================================
// CAMADA DE SERVIÇO E INTEGRAÇÃO DE CONTRATOS (FRONTEND <-> SUPABASE RPCS & AUTH)
// Projeto: Ubatuba Mar & Praias — Missão 01.8 a 02.16 (M01.7-007, M01.7-009 & M02.16)
// ============================================================================
import { supabase, isSupabaseConfigured } from './supabaseClient';
import {
  AdminAnonymizeCustomerPiiParams,
  AdminAnonymizeCustomerPiiResponse,
  AppRole,
  AuthenticatedSessionContext,
  AvailabilityBlockType,
  BookingStatusType,
  CancelBookingByTouristTokenParams,
  CancelBookingByTouristTokenResponse,
  CreateBookingRequestParams,
  CreateBookingRequestResponse,
  DeleteAvailabilityBlockParams,
  DeleteAvailabilityBlockResponse,
  GetTourAvailabilityResponse,
  TouristBookingLookupParams,
  TouristBookingLookupResponse,
  TouristSavedReceipt,
  TransitionBookingStatusParams,
  TransitionBookingStatusResponse,
  UpsertAvailabilityBlockParams,
  UpsertAvailabilityBlockResponse,
  isValidBookingStatus,
} from '../types/database.types';

// ============================================================================
// UTILITÁRIOS DE DATA DINÂMICA (FUSO DE BRASÍLIA America/Sao_Paulo) E
// CREDENCIAIS/IDEMPOTÊNCIA DE RESERVA (MISSÃO 02.16 — SEÇÕES 4, 5, 6 E 7)
// ============================================================================

export const TOURIST_RECEIPTS_STORAGE_KEY = 'ubatuba_tourist_receipts_v1';

/**
 * Retorna a data civil atual no fuso horário de Brasília (`America/Sao_Paulo`, UTC-3)
 * no formato ISO `YYYY-MM-DD`, eliminando qualquer dependência de datas literais fixas.
 */
export function getBrazilCurrentDateIso(referenceDate?: Date): string {
  const target = referenceDate instanceof Date ? referenceDate : new Date();
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(target);
    const year = parts.find((p) => p.type === 'year')?.value;
    const month = parts.find((p) => p.type === 'month')?.value;
    const day = parts.find((p) => p.type === 'day')?.value;
    if (year && month && day) {
      return `${year}-${month}-${day}`;
    }
  } catch {
    // Fallback determinístico UTC-3 caso Intl timeZone não esteja disponível
  }
  const brTime = new Date(target.getTime() - 3 * 60 * 60 * 1000);
  return brTime.toISOString().slice(0, 10);
}

/**
 * Retorna uma data futura em relação à data atual de Brasília (`YYYY-MM-DD`).
 */
export function getBrazilFutureDateIso(daysAhead: number, referenceDate?: Date): string {
  const baseIso = getBrazilCurrentDateIso(referenceDate);
  const [y, m, d] = baseIso.split('-').map((n) => Number(n));
  const utcDate = new Date(Date.UTC(y, (m || 1) - 1, (d || 1) + Math.max(0, Math.floor(daysAhead))));
  return utcDate.toISOString().slice(0, 10);
}

/**
 * Valida se uma string `YYYY-MM-DD` é válida e não está no passado no fuso de Brasília.
 */
export function isBookingDateValidInBrazil(bookingDate: string, referenceDate?: Date): boolean {
  const clean = String(bookingDate || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    return false;
  }
  const todayBr = getBrazilCurrentDateIso(referenceDate);
  return clean >= todayBr;
}

function deterministicHexHash32(payload: string): string {
  const seeds = [0x811c9dc5, 0x9e3779b9, 0x85ebca6b, 0xc2b2ae35];
  for (let i = 0; i < payload.length; i++) {
    const code = payload.charCodeAt(i);
    for (let s = 0; s < 4; s++) {
      let h = seeds[s] ^ (code + s * 31 + i * 17);
      h = Math.imul(h, 0x01000193);
      h ^= h >>> 13;
      seeds[s] = h >>> 0;
    }
  }
  return seeds.map((n) => (n >>> 0).toString(16).padStart(8, '0')).join('');
}

/**
 * Gera uma chave de idempotência determinística de cliente (8..64 chars `[a-z0-9._:-]`)
 * para proteger o envio da reserva contra duplo clique, reenvio ou falha temporária de rede.
 */
export function generateClientBookingIdempotencyKey(input: {
  tourId: string;
  bookingDate: string;
  passengers: number;
  channel: string;
  customerPhone: string;
  customerEmail: string;
}): string {
  const cleanTour = String(input.tourId || '').trim().toLowerCase();
  const cleanDate = String(input.bookingDate || '').trim();
  const cleanPax = Math.max(1, Math.floor(Number(input.passengers) || 1));
  const cleanChannel = String(input.channel || 'SITE_DIRECT').trim().toUpperCase();
  const phoneDigits = String(input.customerPhone || '').replace(/\D/g, '');
  const cleanEmail = String(input.customerEmail || '').trim().toLowerCase();
  const fingerprint = `${cleanTour}|${cleanDate}|${cleanPax}|${cleanChannel}|${phoneDigits}|${cleanEmail}`;
  return `ubk-${cleanDate.replace(/[^0-9]/g, '')}-${deterministicHexHash32(fingerprint)}`;
}

/**
 * Emite um token de consulta local (`ubtk-<32 hex>`) exclusivamente quando operando
 * em modo demonstrativo offline autorizado (`!isSupabaseConfigured`).
 */
export function deriveLocalDemoLookupToken(bookingId: string, bookingCode: string): string {
  const cleanId = String(bookingId || '').trim().toLowerCase();
  const cleanCode = String(bookingCode || '').trim().toUpperCase();
  return `ubtk-${deterministicHexHash32(`DEMO_LOOKUP_V1:${cleanId}:${cleanCode}`)}`;
}

/**
 * Carrega os comprovantes sanitizados de reserva do turista salvos no navegador.
 * Nunca armazena nome, telefone, CPF ou e-mail em `localStorage`.
 */
export function loadTouristSavedReceipts(): TouristSavedReceipt[] {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return [];
    }
    const raw = window.localStorage.getItem(TOURIST_RECEIPTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item: unknown): item is Record<string, unknown> =>
          typeof item === 'object' &&
          item !== null &&
          typeof (item as Record<string, unknown>).bookingCode === 'string' &&
          typeof (item as Record<string, unknown>).lookupToken === 'string'
      )
      .map((item) => ({
        bookingCode: String(item.bookingCode).trim().toUpperCase(),
        lookupToken: String(item.lookupToken).trim().toLowerCase(),
        tourTitle: String(item.tourTitle || 'Passeio Náutico'),
        bookingDate: String(item.bookingDate || ''),
        createdAt: String(item.createdAt || ''),
      }))
      .filter(
        (r) =>
          /^UBT-[A-Z0-9]{4,8}$/.test(r.bookingCode) &&
          /^ubtk-[0-9a-f]{32}$/.test(r.lookupToken)
      );
  } catch {
    return [];
  }
}

/**
 * Salva um comprovante sanitizado (apenas código + lookupToken + título + data)
 * no navegador para recuperação automática após F5 ou reabertura do navegador.
 */
export function saveTouristReceipt(receipt: TouristSavedReceipt): TouristSavedReceipt[] {
  const cleanReceipt: TouristSavedReceipt = {
    bookingCode: String(receipt.bookingCode || '').trim().toUpperCase(),
    lookupToken: String(receipt.lookupToken || '').trim().toLowerCase(),
    tourTitle: String(receipt.tourTitle || 'Passeio Náutico').trim(),
    bookingDate: String(receipt.bookingDate || '').trim(),
    createdAt: String(receipt.createdAt || new Date().toISOString()).trim(),
  };
  const existing = loadTouristSavedReceipts();
  if (
    !/^UBT-[A-Z0-9]{4,8}$/.test(cleanReceipt.bookingCode) ||
    !/^ubtk-[0-9a-f]{32}$/.test(cleanReceipt.lookupToken)
  ) {
    return existing;
  }
  const updated = [
    cleanReceipt,
    ...existing.filter((r) => r.bookingCode !== cleanReceipt.bookingCode),
  ].slice(0, 25);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(TOURIST_RECEIPTS_STORAGE_KEY, JSON.stringify(updated));
    }
  } catch {
    // Fallback seguro em ambientes restritos
  }
  return updated;
}

export function removeTouristReceipt(bookingCode: string): TouristSavedReceipt[] {
  const cleanCode = String(bookingCode || '').trim().toUpperCase();
  const updated = loadTouristSavedReceipts().filter((r) => r.bookingCode !== cleanCode);
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(TOURIST_RECEIPTS_STORAGE_KEY, JSON.stringify(updated));
    }
  } catch {
    // Fallback seguro
  }
  return updated;
}

/**
 * Executa a RPC `create_booking_request` no Supabase quando configurado.
 * Retorna `null` apenas quando o cliente Supabase não está configurado no `.env`,
 * permitindo que a aplicação utilize o motor transacional local com o mesmo contrato.
 */
export async function callCreateBookingRequestRpc(
  params: CreateBookingRequestParams
): Promise<{ data: CreateBookingRequestResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('create_booking_request', {
    p_tour_id: params.p_tour_id,
    p_booking_date: params.p_booking_date,
    p_passengers: params.p_passengers,
    p_channel: params.p_channel,
    p_customer_name: params.p_customer_name,
    p_customer_phone: params.p_customer_phone,
    p_customer_email: params.p_customer_email,
    p_utm_source: params.p_utm_source ?? 'direct_organic',
    p_utm_medium: params.p_utm_medium ?? null,
    p_utm_campaign: params.p_utm_campaign ?? 'marketplace_ubatuba_2026',
    p_notes: params.p_notes ?? null,
    p_idempotency_key: params.p_idempotency_key ?? null,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as CreateBookingRequestResponse;
  if (!typed || !isValidBookingStatus(typed.status)) {
    return {
      data: null,
      error: 'CONTRACT_ERROR: Status retornado pela RPC create_booking_request é inválido.',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

/**
 * Executa a RPC `transition_booking_status` no Supabase quando configurado.
 */
export async function callTransitionBookingStatusRpc(
  params: TransitionBookingStatusParams
): Promise<{ data: TransitionBookingStatusResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('transition_booking_status', {
    p_booking_id: params.p_booking_id,
    p_new_status: params.p_new_status,
    p_reason: params.p_reason ?? null,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as TransitionBookingStatusResponse;
  if (!typed || !isValidBookingStatus(typed.status)) {
    return {
      data: null,
      error: 'CONTRACT_ERROR: Status retornado pela RPC transition_booking_status é inválido.',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

/**
 * Consulta a disponibilidade real via RPC `get_tour_availability` quando o Supabase está ativo.
 */
export async function callGetTourAvailabilityRpc(
  tourId: string,
  bookingDate: string
): Promise<{ data: GetTourAvailabilityResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('get_tour_availability', {
    p_tour_id: tourId,
    p_booking_date: bookingDate,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  return {
    data: data as GetTourAvailabilityResponse,
    error: null,
    executedOnServer: true,
  };
}

/**
 * Consulta pública segura de reserva pelo turista via `lookup_booking_by_tourist_token` (Missão 02.16 — Seção 7).
 * Exige código da reserva (`UBT-XXXX`) + credencial de alta entropia (`ubtk-...`), sem expor PII.
 */
export async function callLookupBookingByTouristTokenRpc(
  params: TouristBookingLookupParams
): Promise<{ data: TouristBookingLookupResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('lookup_booking_by_tourist_token', {
    p_booking_code: params.p_booking_code,
    p_lookup_token: params.p_lookup_token,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as TouristBookingLookupResponse | null;
  if (!typed || typeof typed.ok !== 'boolean') {
    return {
      data: null,
      error: 'CONTRACT_ERROR: Retorno inválido da RPC lookup_booking_by_tourist_token.',
      executedOnServer: true,
    };
  }

  if (!typed.ok) {
    return {
      data: typed,
      error: typed.message || typed.error_code || 'INVALID_LOOKUP_CREDENTIALS',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

/**
 * Cancela reserva pelo turista autenticado via credencial criptográfica (`cancel_booking_by_tourist_token` — Missão 02.16 Seção 8).
 */
export async function callCancelBookingByTouristTokenRpc(
  params: CancelBookingByTouristTokenParams
): Promise<{ data: CancelBookingByTouristTokenResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('cancel_booking_by_tourist_token', {
    p_booking_code: params.p_booking_code,
    p_lookup_token: params.p_lookup_token,
    p_reason: params.p_reason ?? null,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as CancelBookingByTouristTokenResponse | null;
  if (!typed || typeof typed.ok !== 'boolean') {
    return {
      data: null,
      error: 'CONTRACT_ERROR: Retorno inválido da RPC cancel_booking_by_tourist_token.',
      executedOnServer: true,
    };
  }

  if (!typed.ok) {
    return {
      data: typed,
      error: typed.message || typed.error_code || 'CANCEL_BOOKING_FAILED',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

/**
 * Publica avaliação verificada via RPC `create_verified_review` quando o Supabase está ativo.
 */
export async function callCreateVerifiedReviewRpc(params: {
  p_booking_id: string;
  p_rating: number;
  p_comment: string;
  p_author_name?: string;
  p_author_city?: string;
}): Promise<{ data: Record<string, unknown> | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('create_verified_review', {
    p_booking_id: params.p_booking_id,
    p_rating: params.p_rating,
    p_comment: params.p_comment,
    p_author_name: params.p_author_name ?? null,
    p_author_city: params.p_author_city ?? null,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  return {
    data: data as Record<string, unknown>,
    error: null,
    executedOnServer: true,
  };
}

/**
 * Wrappers de conveniência com parâmetros camelCase para integração direta com os handlers de UI (src/App.tsx)
 */
export async function rpcCreateBookingRequest(input: {
  tourId: string;
  bookingDate: string;
  passengers: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  channel: 'WHATSAPP' | 'SITE_DIRECT';
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  notes?: string;
  idempotencyKey?: string;
}) {
  return callCreateBookingRequestRpc({
    p_tour_id: input.tourId,
    p_booking_date: input.bookingDate,
    p_passengers: input.passengers,
    p_channel: input.channel,
    p_customer_name: input.customerName,
    p_customer_phone: input.customerPhone,
    p_customer_email: input.customerEmail,
    p_utm_source: input.utmSource ?? 'direct_organic',
    p_utm_medium: input.utmMedium ?? null,
    p_utm_campaign: input.utmCampaign ?? 'marketplace_ubatuba_2026',
    p_notes: input.notes ?? null,
    p_idempotency_key: input.idempotencyKey ?? null,
  });
}

export async function rpcTransitionBookingStatus(
  bookingId: string,
  newStatus: BookingStatusType,
  reason?: string
) {
  return callTransitionBookingStatusRpc({
    p_booking_id: bookingId,
    p_new_status: newStatus,
    p_reason: reason ?? null,
  });
}

export async function rpcGetTourAvailability(tourId: string, bookingDate: string) {
  return callGetTourAvailabilityRpc(tourId, bookingDate);
}

export async function rpcLookupBookingByTouristToken(bookingCode: string, lookupToken: string) {
  return callLookupBookingByTouristTokenRpc({
    p_booking_code: bookingCode,
    p_lookup_token: lookupToken,
  });
}

export async function rpcCancelBookingByTouristToken(
  bookingCode: string,
  lookupToken: string,
  reason?: string
) {
  return callCancelBookingByTouristTokenRpc({
    p_booking_code: bookingCode,
    p_lookup_token: lookupToken,
    p_reason: reason ?? null,
  });
}

export async function rpcCreateVerifiedReview(input: {
  bookingId: string;
  rating: number;
  comment: string;
  reviewerName?: string;
  reviewerCity?: string;
}) {
  return callCreateVerifiedReviewRpc({
    p_booking_id: input.bookingId,
    p_rating: input.rating,
    p_comment: input.comment,
    p_author_name: input.reviewerName,
    p_author_city: input.reviewerCity,
  });
}

export async function rpcAdminUpdateBooking(input: {
  bookingId: string;
  newBookingDate?: string | null;
  newPassengers?: number | null;
  newStatus?: BookingStatusType | null;
  reason?: string | null;
}) {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }
  const { data, error } = await supabase.rpc('admin_update_booking', {
    p_booking_id: input.bookingId,
    p_new_booking_date: input.newBookingDate ?? null,
    p_new_passengers: input.newPassengers ?? null,
    p_new_status: input.newStatus ?? null,
    p_reason: input.reason ?? null,
  });
  return { data, error: error ? error.message : null, executedOnServer: true };
}

export async function rpcSettleCommissionLedger(bookingId: string, adjustmentNotes?: string) {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }
  const { data, error } = await supabase.rpc('settle_commission_ledger', {
    p_booking_id: bookingId,
    p_adjustment_notes: adjustmentNotes ?? null,
  });
  return { data, error: error ? error.message : null, executedOnServer: true };
}

export interface UpsertAvailabilityBlockPayload {
  vesselId: string;
  blockDate: string;
  blockType: AvailabilityBlockType;
  reason?: string | null;
  customCapacityOverride?: number | null;
  tourId?: string | null;
}

export async function callUpsertAvailabilityBlockRpc(
  params: UpsertAvailabilityBlockParams
): Promise<{ data: UpsertAvailabilityBlockResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('upsert_availability_block', {
    p_vessel_id: params.p_vessel_id,
    p_block_date: params.p_block_date,
    p_block_type: params.p_block_type,
    p_reason: params.p_reason ?? null,
    p_custom_capacity_override: params.p_custom_capacity_override ?? null,
    p_tour_id: params.p_tour_id ?? null,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as UpsertAvailabilityBlockResponse | null;
  if (!typed || !typed.id) {
    return {
      data: null,
      error: 'CONTRACT_ERROR: Retorno inválido da RPC upsert_availability_block.',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

export async function callDeleteAvailabilityBlockRpc(
  params: DeleteAvailabilityBlockParams
): Promise<{ data: DeleteAvailabilityBlockResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('delete_availability_block', {
    p_block_id: params.p_block_id,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as DeleteAvailabilityBlockResponse | null;
  if (!typed || typed.deleted !== true) {
    return {
      data: null,
      error: 'CONTRACT_ERROR: A RPC delete_availability_block não confirmou a exclusão do bloqueio.',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

export async function rpcUpsertAvailabilityBlock(payload: UpsertAvailabilityBlockPayload) {
  return callUpsertAvailabilityBlockRpc({
    p_vessel_id: payload.vesselId,
    p_block_date: payload.blockDate,
    p_block_type: payload.blockType,
    p_reason: payload.reason ?? null,
    p_custom_capacity_override: payload.customCapacityOverride ?? null,
    p_tour_id: payload.tourId ?? null,
  });
}

export async function rpcDeleteAvailabilityBlock(blockId: string) {
  return callDeleteAvailabilityBlockRpc({
    p_block_id: blockId,
  });
}

/**
 * Executa a RPC administrativa `admin_anonymize_customer_pii` (M01.7-009 — LGPD).
 */
export async function callAdminAnonymizeCustomerPiiRpc(
  params: AdminAnonymizeCustomerPiiParams
): Promise<{ data: AdminAnonymizeCustomerPiiResponse | null; error: string | null; executedOnServer: boolean }> {
  if (!isSupabaseConfigured || !supabase) {
    return { data: null, error: null, executedOnServer: false };
  }

  const { data, error } = await supabase.rpc('admin_anonymize_customer_pii', {
    p_booking_id: params.p_booking_id,
    p_lgpd_protocol: params.p_lgpd_protocol,
  });

  if (error) {
    return { data: null, error: error.message, executedOnServer: true };
  }

  const typed = data as AdminAnonymizeCustomerPiiResponse | null;
  if (!typed || typed.anonymized !== true) {
    return {
      data: null,
      error: 'CONTRACT_ERROR: A RPC admin_anonymize_customer_pii não confirmou a anonimização.',
      executedOnServer: true,
    };
  }

  return { data: typed, error: null, executedOnServer: true };
}

export async function rpcAdminAnonymizeCustomerPii(bookingId: string, lgpdProtocol: string) {
  return callAdminAnonymizeCustomerPiiRpc({
    p_booking_id: bookingId,
    p_lgpd_protocol: lgpdProtocol,
  });
}

/**
 * Resolve o perfil autenticado real a partir de `supabase.auth.getSession()` + `public.profiles` + `public.partner_members` (M01.7-007).
 * Garante que o seletor `roleMode` na UI nunca conceda privilégios não validados pelo banco quando conectado.
 */
export async function resolveAuthenticatedSessionContext(): Promise<AuthenticatedSessionContext> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      isConnectedMode: false,
      userId: null,
      email: null,
      effectiveRole: 'tourist',
      authorizedPartnerIds: [],
      isActiveProfile: true,
      error: null,
    };
  }

  const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
  if (sessionErr) {
    return {
      isConnectedMode: true,
      userId: null,
      email: null,
      effectiveRole: 'tourist',
      authorizedPartnerIds: [],
      isActiveProfile: false,
      error: sessionErr.message,
    };
  }

  const user = sessionData?.session?.user ?? null;
  if (!user || !user.id) {
    return {
      isConnectedMode: true,
      userId: null,
      email: null,
      effectiveRole: 'tourist',
      authorizedPartnerIds: [],
      isActiveProfile: false,
      error: null,
    };
  }

  const [profileRes, adminRpcRes, membershipsRes] = await Promise.all([
    supabase
      .from('profiles')
      .select('id, email, system_role, is_active')
      .eq('id', user.id)
      .maybeSingle(),
    supabase.rpc('is_admin'),
    supabase
      .from('partner_members')
      .select('partner_id, is_active')
      .eq('user_id', user.id)
      .eq('is_active', true),
  ]);

  if (profileRes.error) {
    return {
      isConnectedMode: true,
      userId: user.id,
      email: user.email ?? null,
      effectiveRole: 'tourist',
      authorizedPartnerIds: [],
      isActiveProfile: false,
      error: profileRes.error.message,
    };
  }

  const profileRow = profileRes.data as {
    id: string;
    email: string;
    system_role: AppRole;
    is_active: boolean;
  } | null;

  const isActive = profileRow?.is_active === true;
  const authorizedPartnerIds = Array.isArray(membershipsRes.data)
    ? membershipsRes.data
        .map((row: Record<string, unknown>) => (typeof row.partner_id === 'string' ? row.partner_id : ''))
        .filter((id: string) => id.length > 0)
    : [];

  let effectiveRole: AppRole = 'tourist';
  if (isActive && adminRpcRes.data === true && profileRow?.system_role === 'admin') {
    effectiveRole = 'admin';
  } else if (isActive && authorizedPartnerIds.length > 0) {
    effectiveRole = 'partner';
  }

  return {
    isConnectedMode: true,
    userId: user.id,
    email: profileRow?.email ?? user.email ?? null,
    effectiveRole,
    authorizedPartnerIds,
    isActiveProfile: isActive,
    error: null,
  };
}

/**
 * Busca os dados autorizados do catálogo e reservas no Supabase sem mascarar falhas de servidor com dados fictícios (M01.7-007).
 */
export async function fetchAuthorizedCatalogAndBookings(sessionCtx: AuthenticatedSessionContext): Promise<{
  error: string | null;
  partnersRows: Record<string, unknown>[];
  destinationsRows: Record<string, unknown>[];
  vesselsRows: Record<string, unknown>[];
  toursRows: Record<string, unknown>[];
  reviewsRows: Record<string, unknown>[];
  availabilityBlocksRows: Record<string, unknown>[];
  bookingsRows: Record<string, unknown>[];
  auditLogsRows: Record<string, unknown>[];
  bookingPaymentsRows: Record<string, unknown>[];
  bookingPaymentHistoryRows: Record<string, unknown>[];
  financialLedgerEntriesRows: Record<string, unknown>[];
}> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      error: null,
      partnersRows: [],
      destinationsRows: [],
      vesselsRows: [],
      toursRows: [],
      reviewsRows: [],
      availabilityBlocksRows: [],
      bookingsRows: [],
      auditLogsRows: [],
      bookingPaymentsRows: [],
      bookingPaymentHistoryRows: [],
      financialLedgerEntriesRows: [],
    };
  }

  const [
    partnersRes,
    destinationsRes,
    vesselsRes,
    toursRes,
    reviewsRes,
    blocksRes,
  ] = await Promise.all([
    supabase.from('partners').select('*').order('name', { ascending: true }),
    supabase.from('destinations').select('*').order('name', { ascending: true }),
    supabase.from('vessels').select('*').order('name', { ascending: true }),
    supabase.from('tours').select('*').order('title', { ascending: true }),
    supabase.from('reviews').select('*').order('created_at', { ascending: false }),
    supabase.from('availability_blocks').select('*').order('block_date', { ascending: true }),
  ]);

  const firstCatalogError =
    partnersRes.error ||
    destinationsRes.error ||
    vesselsRes.error ||
    toursRes.error ||
    reviewsRes.error ||
    blocksRes.error;

  if (firstCatalogError) {
    return {
      error: firstCatalogError.message,
      partnersRows: [],
      destinationsRows: [],
      vesselsRows: [],
      toursRows: [],
      reviewsRows: [],
      availabilityBlocksRows: [],
      bookingsRows: [],
      auditLogsRows: [],
      bookingPaymentsRows: [],
      bookingPaymentHistoryRows: [],
      financialLedgerEntriesRows: [],
    };
  }

  let bookingsRows: Record<string, unknown>[] = [];
  let auditLogsRows: Record<string, unknown>[] = [];
  let bookingPaymentsRows: Record<string, unknown>[] = [];
  let bookingPaymentHistoryRows: Record<string, unknown>[] = [];
  let financialLedgerEntriesRows: Record<string, unknown>[] = [];

  if (sessionCtx.userId && sessionCtx.isActiveProfile) {
    const bookingsQuery = supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });

    const bookingsRes = await bookingsQuery;
    if (bookingsRes.error) {
      return {
        error: bookingsRes.error.message,
        partnersRows: (partnersRes.data as Record<string, unknown>[]) ?? [],
        destinationsRows: (destinationsRes.data as Record<string, unknown>[]) ?? [],
        vesselsRows: (vesselsRes.data as Record<string, unknown>[]) ?? [],
        toursRows: (toursRes.data as Record<string, unknown>[]) ?? [],
        reviewsRows: (reviewsRes.data as Record<string, unknown>[]) ?? [],
        availabilityBlocksRows: (blocksRes.data as Record<string, unknown>[]) ?? [],
        bookingsRows: [],
        auditLogsRows: [],
        bookingPaymentsRows: [],
        bookingPaymentHistoryRows: [],
        financialLedgerEntriesRows: [],
      };
    }
    bookingsRows = (bookingsRes.data as Record<string, unknown>[]) ?? [];

    const [paymentsRes, paymentHistRes, finLedgerRes, commLedgerRes] = await Promise.all([
      supabase.from('booking_payments').select('*').order('created_at', { ascending: false }),
      supabase.from('booking_payment_history').select('*').order('created_at', { ascending: false }),
      supabase.from('financial_ledger_entries').select('*').order('created_at', { ascending: false }),
      supabase.from('commission_ledger').select('*').order('created_at', { ascending: false }),
    ]);

    if (!paymentsRes.error && Array.isArray(paymentsRes.data)) {
      bookingPaymentsRows = paymentsRes.data as Record<string, unknown>[];
    }
    if (!paymentHistRes.error && Array.isArray(paymentHistRes.data)) {
      bookingPaymentHistoryRows = paymentHistRes.data as Record<string, unknown>[];
    }
    if (!finLedgerRes.error && Array.isArray(finLedgerRes.data)) {
      financialLedgerEntriesRows = finLedgerRes.data as Record<string, unknown>[];
    }
    if (!commLedgerRes.error && Array.isArray(commLedgerRes.data)) {
      const ledgerByBookingId = new Map<string, string>();
      for (const clRow of commLedgerRes.data as Record<string, unknown>[]) {
        if (clRow.booking_id && clRow.ledger_status) {
          ledgerByBookingId.set(String(clRow.booking_id), String(clRow.ledger_status));
        }
      }
      bookingsRows = bookingsRows.map((bkRow) => {
        const mappedLedger = ledgerByBookingId.get(String(bkRow.id || ''));
        return mappedLedger ? { ...bkRow, ledger_status: mappedLedger } : bkRow;
      });
    }

    if (sessionCtx.effectiveRole === 'admin') {
      const auditRes = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (!auditRes.error && Array.isArray(auditRes.data)) {
        auditLogsRows = auditRes.data as Record<string, unknown>[];
      }
    }
  }

  return {
    error: null,
    partnersRows: (partnersRes.data as Record<string, unknown>[]) ?? [],
    destinationsRows: (destinationsRes.data as Record<string, unknown>[]) ?? [],
    vesselsRows: (vesselsRes.data as Record<string, unknown>[]) ?? [],
    toursRows: (toursRes.data as Record<string, unknown>[]) ?? [],
    reviewsRows: (reviewsRes.data as Record<string, unknown>[]) ?? [],
    availabilityBlocksRows: (blocksRes.data as Record<string, unknown>[]) ?? [],
    bookingsRows,
    auditLogsRows,
    bookingPaymentsRows,
    bookingPaymentHistoryRows,
    financialLedgerEntriesRows,
  };
}

// ============================================================================
// FUNÇÕES REAIS DE HIDRATAÇÃO DETERMINÍSTICA, RESOLUÇÃO RELACIONAL E ISOLAMENTO
// MULTITENANT DO FRONTEND (M02.4-F05 & M02.5-F06)
// ============================================================================
export interface CatalogHydrationDefaults<TPartner, TDestination, TVessel, TTour> {
  initialPartners: TPartner[];
  initialDestinations: TDestination[];
  initialVessels: TVessel[];
  initialTours: TTour[];
  normalizeBookingStatus: (rawStatus: string) => BookingStatusType;
  deriveLedgerStatusFromBookingStatus: (status: BookingStatusType, currentLedgerStatus?: 'PREVISTA' | 'CONFIRMADA' | 'PAGA' | 'REVERTIDA' | 'EM_DISPUTA') => 'PREVISTA' | 'CONFIRMADA' | 'PAGA' | 'REVERTIDA' | 'EM_DISPUTA';
}

export function hydrateCatalogAndBookingsSnapshot<
  TPartner extends {
    id: string;
    name: string;
    legalName: string;
    cnpj: string;
    whatsapp: string;
    email: string;
    baseMarina: string;
    status: 'APROVADO' | 'PENDENTE' | 'SUSPENSO';
    verified: boolean;
    rating: number;
    reviewsCount: number;
  },
  TDestination extends {
    id: string;
    slug: string;
    name: string;
    shortDescription: string;
    fullDescription: string;
    heroImage: string;
    rating: number;
    reviewsCount: number;
    featured: boolean;
  },
  TVessel extends {
    id: string;
    slug: string;
    name: string;
    partnerId: string;
    type: string;
    operationMode: string;
    capacity: number;
    lengthFeet: number;
    heroImage: string;
    rating: number;
  },
  TTour extends {
    id: string;
    slug: string;
    title: string;
    vesselId: string;
    partnerId: string;
    tourType: string;
    vesselType: string;
    pricingModel: string;
    price: number;
    capacity: number;
    status: 'APROVADO' | 'PENDENTE_APROVACAO';
    featured: boolean;
    heroImage: string;
    rating: number;
    reviewsCount: number;
  }
>(
  snapshot: {
    error: string | null;
    partnersRows: Record<string, unknown>[];
    destinationsRows: Record<string, unknown>[];
    vesselsRows: Record<string, unknown>[];
    toursRows: Record<string, unknown>[];
    reviewsRows: Record<string, unknown>[];
    availabilityBlocksRows: Record<string, unknown>[];
    bookingsRows: Record<string, unknown>[];
    auditLogsRows: Record<string, unknown>[];
    bookingPaymentsRows?: Record<string, unknown>[];
    bookingPaymentHistoryRows?: Record<string, unknown>[];
    financialLedgerEntriesRows?: Record<string, unknown>[];
  },
  defaults: CatalogHydrationDefaults<TPartner, TDestination, TVessel, TTour>
) {
  if (snapshot.error) {
    return {
      hasError: true,
      error: snapshot.error,
      partners: [] as TPartner[],
      destinations: [] as TDestination[],
      vessels: [] as TVessel[],
      tours: [] as TTour[],
      availabilityBlocks: [],
      reviews: [],
      bookings: [],
      auditLogs: [],
      bookingPaymentsRows: [] as Record<string, unknown>[],
      bookingPaymentHistoryRows: [] as Record<string, unknown>[],
      financialLedgerEntriesRows: [] as Record<string, unknown>[],
    };
  }

  const hydratedPartners: TPartner[] = snapshot.partnersRows.map((row) => {
    const base =
      defaults.initialPartners.find((p) => p.id === row.id || p.name === row.name) || defaults.initialPartners[0];
    return {
      ...base,
      id: String(row.id || base.id),
      name: String(row.name || base.name),
      legalName: String(row.legal_name || base.legalName),
      cnpj: String(row.cnpj || base.cnpj),
      whatsapp: String(row.whatsapp || base.whatsapp),
      email: String(row.email || base.email),
      baseMarina: String(row.base_marina || base.baseMarina),
      status: ((row.status as TPartner['status']) || base.status),
      verified: Boolean(row.verified ?? base.verified),
      rating: Number.isFinite(Number(row.rating_avg)) ? Number(row.rating_avg) : base.rating,
      reviewsCount: Number.isFinite(Number(row.reviews_count)) ? Number(row.reviews_count) : base.reviewsCount,
    };
  });

  const hydratedDestinations: TDestination[] = snapshot.destinationsRows.map((row) => {
    const base =
      defaults.initialDestinations.find((d) => d.slug === row.slug || d.id === row.id) || defaults.initialDestinations[0];
    return {
      ...base,
      id: String(row.id || base.id),
      slug: String(row.slug || base.slug),
      name: String(row.name || base.name),
      shortDescription: String(row.short_description || base.shortDescription),
      fullDescription: String(row.full_description || base.fullDescription),
      heroImage: String(row.hero_image_url || base.heroImage),
      rating: Number.isFinite(Number(row.rating_avg)) ? Number(row.rating_avg) : base.rating,
      reviewsCount: Number.isFinite(Number(row.reviews_count)) ? Number(row.reviews_count) : base.reviewsCount,
      featured: Boolean(row.featured ?? base.featured),
    };
  });

  const hydratedVessels: TVessel[] = snapshot.vesselsRows.map((row) => {
    const base =
      defaults.initialVessels.find((v) => v.slug === row.slug || v.id === row.id) || defaults.initialVessels[0];
    return {
      ...base,
      id: String(row.id || base.id),
      slug: String(row.slug || base.slug),
      name: String(row.name || base.name),
      partnerId: String(row.partner_id || base.partnerId),
      type: ((row.vessel_type as TVessel['type']) || base.type),
      operationMode: ((row.operation_mode as TVessel['operationMode']) || base.operationMode),
      capacity: Number.isFinite(Number(row.capacity)) ? Number(row.capacity) : base.capacity,
      lengthFeet: Number.isFinite(Number(row.length_feet)) ? Number(row.length_feet) : base.lengthFeet,
      heroImage: String(row.hero_image_url || base.heroImage),
      rating: Number.isFinite(Number(row.rating_avg)) ? Number(row.rating_avg) : base.rating,
    };
  });

  const hydratedTours: TTour[] = snapshot.toursRows.map((row) => {
    const base =
      defaults.initialTours.find((t) => t.slug === row.slug || t.id === row.id) || defaults.initialTours[0];
    return {
      ...base,
      id: String(row.id || base.id),
      slug: String(row.slug || base.slug),
      title: String(row.title || base.title),
      vesselId: String(row.vessel_id || base.vesselId),
      partnerId: String(row.partner_id || base.partnerId),
      tourType: ((row.tour_type as TTour['tourType']) || base.tourType),
      vesselType: ((row.vessel_type as TTour['vesselType']) || base.vesselType),
      pricingModel: ((row.pricing_model as TTour['pricingModel']) || base.pricingModel),
      price: Number.isFinite(Number(row.price)) ? Number(row.price) : base.price,
      capacity: Number.isFinite(Number(row.capacity)) ? Number(row.capacity) : base.capacity,
      status: ((row.status === 'APROVADO' ? 'APROVADO' : 'PENDENTE_APROVACAO') as TTour['status']),
      featured: Boolean(row.featured ?? base.featured),
      heroImage: String(row.hero_image_url || base.heroImage),
      rating: Number.isFinite(Number(row.rating_avg)) ? Number(row.rating_avg) : base.rating,
      reviewsCount: Number.isFinite(Number(row.reviews_count)) ? Number(row.reviews_count) : base.reviewsCount,
    };
  });

  const partnerById = new Map<string, TPartner>(hydratedPartners.map((p) => [p.id, p]));
  const vesselById = new Map<string, TVessel>(hydratedVessels.map((v) => [v.id, v]));
  const tourById = new Map<string, TTour>(hydratedTours.map((t) => [t.id, t]));
  const bookingCodeById = new Map<string, string>(
    snapshot.bookingsRows
      .filter((r) => r.id != null && r.code != null)
      .map((r) => [String(r.id), String(r.code)])
  );

  const availabilityBlocks = snapshot.availabilityBlocksRows.map((row) => {
    const vId = String(row.vessel_id || '');
    const resolvedVesselName =
      String(row.vessel_name || '') ||
      vesselById.get(vId)?.name ||
      defaults.initialVessels.find((v) => v.id === vId || v.slug === vId)?.name ||
      '';
    const rawOverride = row.custom_capacity_override;
    const parsedOverride =
      rawOverride != null && rawOverride !== '' && Number.isFinite(Number(rawOverride))
        ? Math.max(1, Number(rawOverride))
        : undefined;
    return {
      id: String(row.id || ''),
      partnerId: String(row.partner_id || vesselById.get(vId)?.partnerId || ''),
      vesselId: vId,
      vesselName: resolvedVesselName,
      blockDate: String(row.block_date || ''),
      blockType: ((row.block_type as AvailabilityBlockType) || 'MANUTENCAO'),
      adjustedCapacity: parsedOverride,
      reason: String(row.reason || 'Bloqueio operacional'),
    };
  });

  const reviews = snapshot.reviewsRows.map((row) => {
    const tId = String(row.tour_id || '');
    const bId = String(row.booking_id || '');
    const resolvedTourTitle =
      String(row.tour_title || '') ||
      tourById.get(tId)?.title ||
      defaults.initialTours.find((t) => t.id === tId || t.slug === tId)?.title ||
      '';
    const resolvedBookingCode =
      String(row.verified_booking_code || '') ||
      bookingCodeById.get(bId) ||
      '';
    return {
      id: String(row.id || ''),
      tourId: tId,
      tourTitle: resolvedTourTitle,
      partnerId: String(row.partner_id || tourById.get(tId)?.partnerId || ''),
      author: String(row.author_name || 'Visitante Verificado'),
      city: String(row.author_city || 'Ubatuba, SP'),
      rating: Number.isFinite(Number(row.rating)) ? Math.min(5, Math.max(1, Number(row.rating))) : 5,
      date: String(row.created_at || '').slice(0, 10),
      comment: String(row.comment || ''),
      verifiedBookingCode: resolvedBookingCode,
    };
  });

  const bookings = snapshot.bookingsRows.map((row) => {
    const normStatus = defaults.normalizeBookingStatus(String(row.status || 'SOLICITADA'));
    const tId = String(row.tour_id || '');
    const vId = String(row.vessel_id || tourById.get(tId)?.vesselId || '');
    const pId = String(row.partner_id || tourById.get(tId)?.partnerId || '');
    const resolvedTourTitle =
      String(row.tour_title || '') ||
      tourById.get(tId)?.title ||
      defaults.initialTours.find((t) => t.id === tId || t.slug === tId)?.title ||
      '';
    const resolvedVesselName =
      String(row.vessel_name || '') ||
      vesselById.get(vId)?.name ||
      defaults.initialVessels.find((v) => v.id === vId || v.slug === vId)?.name ||
      '';
    const resolvedPartnerName =
      String(row.partner_name || '') ||
      partnerById.get(pId)?.name ||
      defaults.initialPartners.find((p) => p.id === pId)?.name ||
      '';
    return {
      id: String(row.id || ''),
      code: String(row.code || ''),
      tourId: tId,
      tourTitle: resolvedTourTitle,
      vesselId: vId,
      vesselName: resolvedVesselName,
      partnerId: pId,
      partnerName: resolvedPartnerName,
      customerName: String(row.customer_name || ''),
      customerPhone: String(row.customer_phone || ''),
      customerEmail: String(row.customer_email || ''),
      date: String(row.booking_date || ''),
      passengers: Number.isFinite(Number(row.passengers)) ? Math.max(1, Number(row.passengers)) : 1,
      channel: (row.channel === 'WHATSAPP' ? 'WHATSAPP' : 'SITE_DIRECT') as 'WHATSAPP' | 'SITE_DIRECT',
      utmSource: String(row.utm_source || 'direct_organic'),
      utmCampaign: String(row.utm_campaign || 'marketplace_ubatuba_2026'),
      status: normStatus,
      ledgerStatus: defaults.deriveLedgerStatusFromBookingStatus(
        normStatus,
        row.ledger_status === 'PAGA' ||
          (snapshot.financialLedgerEntriesRows ?? []).some(
            (e) =>
              String(e.booking_id || e.bookingId || '') === String(row.id || '') &&
              String(e.entry_type || e.entryType || '') === 'PARTNER_PAYOUT_SETTLED'
          )
          ? 'PAGA'
          : undefined
      ),
      grossAmount: Number.isFinite(Number(row.gross_amount)) ? Number(row.gross_amount) : 0,
      commissionRuleUsed: String(row.commission_rule_label || ''),
      commissionAmount: Number.isFinite(Number(row.commission_amount)) ? Number(row.commission_amount) : 0,
      netPartnerAmount: Number.isFinite(Number(row.net_partner_amount)) ? Number(row.net_partner_amount) : 0,
      commissionConsolidated: normStatus === 'PASSEIO_REALIZADO',
      createdAt: String(row.created_at || '').slice(0, 10),
      notes: row.notes != null ? String(row.notes) : undefined,
      rejectionReason: row.rejection_or_cancel_reason != null ? String(row.rejection_or_cancel_reason) : undefined,
    };
  });

  const auditLogs = snapshot.auditLogsRows.map((row) => ({
    id: String(row.id || ''),
    timestamp: String(row.created_at || ''),
    actor: String(row.actor_user_id || 'Sistema'),
    role: ((row.actor_role as AppRole) || 'admin'),
    action: String(row.action || ''),
    target: String(row.record_id || ''),
    details: JSON.stringify(row.new_data || {}),
  }));

  return {
    hasError: false,
    error: null,
    partners: hydratedPartners,
    destinations: hydratedDestinations,
    vessels: hydratedVessels,
    tours: hydratedTours,
    availabilityBlocks,
    reviews,
    bookings,
    auditLogs,
    bookingPaymentsRows: snapshot.bookingPaymentsRows ?? [],
    bookingPaymentHistoryRows: snapshot.bookingPaymentHistoryRows ?? [],
    financialLedgerEntriesRows: snapshot.financialLedgerEntriesRows ?? [],
  };
}

export function resolveIsolatedActivePartner<
  TPartner extends { id: string; name: string; status: 'APROVADO' | 'PENDENTE' | 'SUSPENSO' }
>(params: {
  isConnectedMode: boolean;
  serverVerifiedRole: AppRole;
  authorizedPartnerIds: string[];
  activePartnerId: string;
  partners: TPartner[];
  fallbackPartner: TPartner;
}): TPartner {
  const { isConnectedMode, serverVerifiedRole, authorizedPartnerIds, activePartnerId, partners, fallbackPartner } = params;
  if (isConnectedMode) {
    if (serverVerifiedRole === 'partner') {
      if (authorizedPartnerIds.length > 0) {
        const allowedId = authorizedPartnerIds.includes(activePartnerId) ? activePartnerId : authorizedPartnerIds[0];
        return (
          partners.find((p) => p.id === allowedId) || {
            ...fallbackPartner,
            id: allowedId,
            name: 'Parceiro Autenticado',
            status: 'PENDENTE',
          }
        );
      }
      return {
        ...fallbackPartner,
        id: '__unauthorized_partner__',
        name: 'Sem Vínculo de Parceiro',
        status: 'SUSPENSO',
      };
    }
    if (serverVerifiedRole === 'tourist') {
      return {
        ...fallbackPartner,
        id: '__tourist_no_partner__',
        name: 'Visitante',
        status: 'PENDENTE',
      };
    }
  }
  return partners.find((p) => p.id === activePartnerId) || partners[0] || fallbackPartner;
}

export function mergeAvailabilityBlockList<
  TBlock extends { id: string; vesselId: string; blockDate: string }
>(existingBlocks: TBlock[], confirmedBlock: TBlock): TBlock[] {
  return [
    confirmedBlock,
    ...existingBlocks.filter(
      (b) =>
        b.id !== confirmedBlock.id &&
        !(b.vesselId === confirmedBlock.vesselId && b.blockDate === confirmedBlock.blockDate)
    ),
  ];
}
