import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  BookingStatusType,
  LedgerStatusType,
  AvailabilityBlockType,
  VesselType,
  PaymentMethodType,
  PaymentStatusType,
  GetTourAvailabilityResponse,
  TouristBookingLookupResponse,
  TouristSavedReceipt,
  ACTIVE_CAPACITY_BOOKING_STATUSES,
  normalizeBookingStatus,
  validateBookingStatusTransition,
  deriveLedgerStatusFromBookingStatus
} from './types/database.types';
import {
  rpcCreateBookingRequest,
  rpcTransitionBookingStatus,
  rpcGetTourAvailability,
  rpcLookupBookingByTouristToken,
  rpcCancelBookingByTouristToken,
  rpcCreateVerifiedReview,
  rpcUpsertAvailabilityBlock,
  rpcDeleteAvailabilityBlock,
  getBrazilCurrentDateIso,
  getBrazilFutureDateIso,
  isBookingDateValidInBrazil,
  generateClientBookingIdempotencyKey,
  deriveLocalDemoLookupToken,
  loadTouristSavedReceipts,
  saveTouristReceipt,
  removeTouristReceipt,
  resolveAuthenticatedSessionContext,
  fetchAuthorizedCatalogAndBookings,
  hydrateCatalogAndBookingsSnapshot,
  resolveIsolatedActivePartner,
  mergeAvailabilityBlockList,
  rpcSettleCommissionLedger
} from './lib/bookingService';
import { supabase, isSupabaseConfigured, runtimeGuard } from './lib/supabaseClient';
import {
  OperationalAuthContext,
  OperationalHistoryEntry,
  OperationalStateSnapshot,
  VesselOperationalStatus,
  DepartureStatusType,
  computeAdminDashboardMetrics,
  listPartnersWithOperationalDetails,
  createPartnerOperation,
  updatePartnerOperation,
  moderatePartnerRegistrationOperation,
  createVesselOperation,
  updateVesselOperation,
  createTourOperation,
  updateTourOperation,
  deleteTourSafelyOperation,
  queryOperationalBookings,
  transitionOperationalBookingStatus,
  listOperationalDepartures,
  computeCanonicalDepartureOccupancy,
  isPartnerEffectivelyActive,
  isVesselEffectivelyActive,
  isTourEffectivelyActive
} from './lib/operationsService';
import {
  AccountStateType,
  PartnerOnboardingStage,
  ProtectedRouteKey,
  VerifiedServerSessionContext
} from './lib/authTypes';
import {
  UNIFORM_LOGIN_FAILURE_MESSAGE,
  UNIFORM_RECOVERY_CONFIRMATION_MESSAGE,
  validateLoginInput,
  validateRegistrationInput,
  validatePasswordRecoveryEmail,
  validatePasswordResetPayload
} from './lib/authValidation';
import {
  createUnauthenticatedSessionContext,
  evaluateSessionAccountState,
  revalidateSessionAgainstPartnerState
} from './lib/authSession';
import {
  evaluateRouteProtection,
  buildVerifiedOperationalAuthContext
} from './lib/authGuards';
import {
  SupabaseAuthProviderAdapter,
  loginWithEmailPassword,
  logoutCurrentSession,
  registerUserAccount,
  requestPasswordRecovery,
  resetPasswordWithRecoveryToken,
  restoreAndVerifySession
} from './lib/authService';
import {
  OnboardingStateStore,
  submitPartnerOnboardingInStore,
  adminModeratePartnerOnboardingInStore,
  rpcSubmitPartnerOnboardingApplication,
  rpcAdminModeratePartnerOnboarding
} from './lib/partnerOnboardingService';
import {
  FinancialStoreSnapshot,
  createEmptyFinancialStore,
  roundCurrencyExact,
  sumCurrencyExact,
  calculateServerCommissionAndNet,
  initiateBookingPayment,
  transitionBookingPaymentStatus,
  requestBookingRefund,
  processBookingRefund,
  revertFailedPendingRefund,
  handleBookingCancellationFinancialSync,
  settleBookingCommissionInStore,
  runFinancialReconciliation,
  computeAdminFinancialSummary,
  computePartnerFinancialSummary,
  hydrateFinancialStoreFromServerRows,
  seedInitialDemoFinancialStore,
  rpcCreateOrInitiateBookingPayment,
  rpcConfirmOrFailBookingPayment,
  rpcRequestBookingRefund,
  rpcProcessBookingRefund,
  rpcGetFinancialReconciliationReport
} from './lib/financialService';
import {
  Compass, Anchor, Ship, MapPin, Calendar, Users, Search, Star, Shield,
  CheckCircle2, Clock, Sparkles, Filter, ArrowRight, Play, Image as ImageIcon,
  Video, Upload, Trash2, Edit3, Plus, Eye, MessageCircle, DollarSign,
  TrendingUp, Award, AlertCircle, ChevronRight, ChevronLeft, X, Check,
  SlidersHorizontal, Navigation, Waves, Mountain, Trees, Sun, Info,
  Lock, Unlock, Settings, FileText, Share2, ExternalLink, RefreshCw,
  BarChart3, Layers, Globe, Code2, Copy, CheckSquare, Percent, UserCheck,
  Phone, Mail, HelpCircle, Heart, Camera, Film, Map as MapIcon
} from 'lucide-react';

// ============================================================================
// TIPOS E ARQUITETURA DE DADOS (MODELAGEM SUPABASE / POSTGRESQL)
// ============================================================================

type RoleMode = 'tourist' | 'partner' | 'admin';

type DestinationCategory = 'Praias' | 'Ilhas' | 'Cachoeiras' | 'Trilhas e Aventuras';

interface MediaAsset {
  id: string;
  title: string;
  type: 'photo' | 'video';
  url: string;
  videoPreviewDuration?: string;
  category: 'Destino' | 'Embarcação' | 'Passeio' | 'Experiência';
  linkedEntityId: string;
  linkedEntityName: string;
  partnerId: string | 'PLATFORM';
  partnerName: string;
  authorized: boolean;
  isProvisional: boolean;
  createdAt: string;
}

interface Destination {
  id: string;
  slug: string;
  name: string;
  category: DestinationCategory;
  region: 'Norte' | 'Centro' | 'Sul' | 'Sertão / Serra do Mar';
  shortDescription: string;
  fullDescription: string;
  coordinates: { lat: number; lng: number; mapX: number; mapY: number };
  howToGetThere: string;
  accessType: 'Barco / Lancha' | 'Trilha' | 'Acesso Asfaltado / Carro' | 'Barco ou Trilha';
  characteristics: string[];
  infrastructure: string;
  visitorTips: string[];
  environmentalRules: string[];
  heroImage: string;
  gallery: string[];
  videoTitle: string;
  videoDuration: string;
  rating: number;
  reviewsCount: number;
  featured: boolean;
  seoTitle: string;
  seoDescription: string;
  sourceUrl: string;
}

interface Partner {
  id: string;
  name: string;
  legalName: string;
  cnpj: string;
  whatsapp: string;
  email: string;
  baseMarina: string;
  status: 'APROVADO' | 'PENDENTE' | 'SUSPENSO';
  isActive?: boolean;
  rejectionReason?: string;
  updatedAt?: string;
  verified: boolean;
  rating: number;
  reviewsCount: number;
  yearsOperating: number;
  commissionModel: 'PERCENTAGE' | 'FIXED_AMOUNT' | 'CUSTOM_OVERRIDE';
  commissionRate: number; // % se PERCENTAGE
  commissionFixed: number; // R$ se FIXED_AMOUNT
  bio: string;
  avatarImage: string;
}

interface Vessel {
  id: string;
  slug: string;
  name: string;
  partnerId: string;
  type: 'Lancha' | 'Escuna' | 'Catamarã / Flexboat';
  operationMode: 'Privativo' | 'Compartilhado' | 'Ambos';
  capacity: number;
  lengthFeet: number;
  engineSpec: string;
  baseLocation: string;
  description: string;
  features: string[];
  structure: string[];
  safetyEquipment: string[];
  heroImage: string;
  gallery: string[];
  videoTitle: string;
  rating: number;
  isActive?: boolean;
  availabilityStatus?: VesselOperationalStatus;
  updatedAt?: string;
}

interface Tour {
  id: string;
  slug: string;
  title: string;
  vesselId: string;
  partnerId: string;
  category:
    | 'Passeios de lancha'
    | 'Passeios de escuna'
    | 'Passeios compartilhados'
    | 'Passeios privativos'
    | 'Passeios para famílias'
    | 'Passeios para grupos'
    | 'Experiências personalizadas';
  tourType: 'Privativo' | 'Compartilhado';
  vesselType: VesselType;
  pricingModel: 'POR_PESSOA' | 'POR_EMBARCACAO';
  price: number;
  capacity: number;
  durationHours: number;
  departureTime: string;
  returnTime: string;
  checkInTime: string;
  departurePoint: 'Saco da Ribeira' | 'Praia do Itaguá' | 'Praia de Picinguaba' | 'Praia da Enseada';
  itineraryId: string;
  destinationsVisited: string[]; // IDs de destinos
  swimmingStops: { place: string; duration: string; description: string }[];
  includedItems: string[];
  importantInfo: string[];
  cancellationPolicy: string;
  customCommissionPercent?: number;
  customCommissionFixed?: number;
  status: 'APROVADO' | 'PENDENTE_APROVACAO' | 'REPROVADO' | 'SUSPENSO' | 'RASCUNHO';
  isActive?: boolean;
  updatedAt?: string;
  featured: boolean;
  heroImage: string;
  gallery: string[];
  videoTitle: string;
  rating: number;
  reviewsCount: number;
  seoKeywords: string[];
}

interface Itinerary {
  id: string;
  slug: string;
  title: string;
  region: 'Costa Norte' | 'Costa Sul & Ilha Anchieta' | 'Sete Praias & Bonete' | 'Baía Central & Pôr do Sol';
  estimatedDuration: string;
  navigationLevel: 'Águas Abrigadas (Calmo)' | 'Costeira Moderada' | 'Travessia Oceânica Leve';
  description: string;
  destinationsIds: string[];
  stopsCount: number;
  stopsDetails: string[];
  confirmedVesselIds: string[]; // Somente embarcações homologadas pelo parceiro
  navigationNotes: string;
  heroImage: string;
  videoTitle: string;
}

interface BookingRequest {
  id: string;
  code: string;
  tourId: string;
  tourTitle: string;
  vesselId: string;
  vesselName: string;
  partnerId: string;
  partnerName: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  date: string;
  passengers: number;
  channel: 'WHATSAPP' | 'SITE_DIRECT';
  utmSource: string;
  utmCampaign: string;
  status: BookingStatusType;
  ledgerStatus?: LedgerStatusType;
  grossAmount: number;
  commissionRuleUsed: string;
  commissionAmount: number;
  netPartnerAmount: number;
  commissionConsolidated: boolean; // SOMENTE true quando status === 'PASSEIO_REALIZADO'
  createdAt: string;
  lookupToken?: string;
  idempotencyKey?: string;
  notes?: string;
  rejectionReason?: string;
}

interface AvailabilityBlock {
  id: string;
  partnerId: string;
  vesselId: string;
  vesselName: string;
  blockDate: string;
  blockType: AvailabilityBlockType;
  adjustedCapacity?: number;
  reason: string;
}

interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  role: RoleMode;
  action: string;
  target: string;
  details: string;
}

interface ReviewItem {
  id: string;
  tourId: string;
  tourTitle: string;
  partnerId: string;
  author: string;
  city: string;
  rating: number;
  date: string;
  comment: string;
  verifiedBookingCode: string;
}

// ============================================================================
// IMAGENS LOCAIS GERADAS (INLINE BASE64 PELO PIPELINE)
// ============================================================================

const IMG_HERO = '/media/ubatuba-hero.jpg';
const IMG_COUVES = '/media/ilha-das-couves.jpg';
const IMG_LANCHA = '/media/lancha-oceano-azul.jpg';
const IMG_ESCUNA = '/media/escuna-rainha-anchieta.jpg';
const IMG_CACHOEIRA = '/media/cachoeira-prumirim.jpg';

// ============================================================================
// BANCO DE DADOS INICIAL (GROUNDED EM FATOS REAIS DE UBATUBA/SP)
// ============================================================================

const INITIAL_PARTNERS: Partner[] = [
  {
    id: 'part-kaimares',
    name: 'Kaimares Náutica & Charter',
    legalName: 'Kaimares Turismo Náutico Ubatuba Ltda',
    cnpj: '34.819.201/0001-48',
    whatsapp: '5512997766789',
    email: 'reservas@kaimaresnautica.com.br',
    baseMarina: 'Avenida Leovigildo Dias Vieira, Itaguá & Saco da Ribeira',
    status: 'APROVADO',
    verified: true,
    rating: 4.9,
    reviewsCount: 354,
    yearsOperating: 9,
    commissionModel: 'PERCENTAGE',
    commissionRate: 15,
    commissionFixed: 0,
    bio: 'Especialistas em lanchas privativas e roteiros compartilhados para a Ilha das Couves, Ilha do Prumirim e Ilha Anchieta com marinheiros habilitados pela Capitania dos Portos.',
    avatarImage: IMG_LANCHA
  },
  {
    id: 'part-rotadomar',
    name: 'Rota do Mar Lanchas',
    legalName: 'Rota do Mar Operadora Náutica Ltda',
    cnpj: '29.402.118/0001-90',
    whatsapp: '5512991766084',
    email: 'contato@rotadomarubatuba.com.br',
    baseMarina: 'Marina Saco da Ribeira & Píer do Itaguá',
    status: 'APROVADO',
    verified: true,
    rating: 5.0,
    reviewsCount: 418,
    yearsOperating: 12,
    commissionModel: 'CUSTOM_OVERRIDE',
    commissionRate: 12,
    commissionFixed: 150,
    bio: 'Frota própria de lanchas cabinadas e open deck de 28 a 38 pés, oferecendo experiências privativas sob medida no litoral norte e sul de Ubatuba.',
    avatarImage: IMG_HERO
  },
  {
    id: 'part-escunascaicara',
    name: 'Escunas Tradicionais Caiçara',
    legalName: 'Navegação Turística Ilha Anchieta & Norte S/A',
    cnpj: '18.920.554/0001-12',
    whatsapp: '5512991847933',
    email: 'embarque@escunascaicara.com.br',
    baseMarina: 'Píer do Saco da Ribeira e Praia do Itaguá',
    status: 'APROVADO',
    verified: true,
    rating: 4.8,
    reviewsCount: 358,
    yearsOperating: 16,
    commissionModel: 'FIXED_AMOUNT',
    commissionRate: 0,
    commissionFixed: 25,
    bio: 'Operadora tradicional de escunas temáticas e familiares com paradas homologadas no Parque Estadual da Ilha Anchieta, Praia das Sete Fontes e Ilha do Prumirim.',
    avatarImage: IMG_ESCUNA
  },
  {
    id: 'part-nativaeco',
    name: 'Nativa Ecotrilhas & Expedições',
    legalName: 'Nativa Ecoturismo e Monitoria Ambiental Ltda',
    cnpj: '41.209.882/0001-05',
    whatsapp: '5512996460990',
    email: 'trilhas@nativaecotrilhas.com.br',
    baseMarina: 'Sertão da Quina / Núcleo Picinguaba',
    status: 'PENDENTE',
    verified: true,
    rating: 4.9,
    reviewsCount: 192,
    yearsOperating: 7,
    commissionModel: 'PERCENTAGE',
    commissionRate: 18,
    commissionFixed: 0,
    bio: 'Monitores ambientais credenciados pelo Parque Estadual da Serra do Mar para a Trilha da Cachoeira da Água Branca, Sete Praias e Sete Fontes.',
    avatarImage: IMG_CACHOEIRA
  }
];

const INITIAL_DESTINATIONS: Destination[] = [
  // 12 PRAIAS OBRIGATÓRIAS
  {
    id: 'dest-cedro',
    slug: 'praia-do-cedro',
    name: 'Praia do Cedro (Cedrinho & Cedro do Sul)',
    category: 'Praias',
    region: 'Centro',
    shortDescription: 'Mar verde-esmeralda, águas calmas e extrema transparência para mergulho livre.',
    fullDescription: 'Considerada uma das praias de águas mais transparentes de Ubatuba, a Praia do Cedro (conhecida no centro como Cedrinho, próxima ao Farol da Ponta Grossa, além do Cedro do Sul na Trilha das Sete Praias) encanta pelas piscinas naturais formadas entre rochas graníticas e Mata Atlântica intocada.',
    coordinates: { lat: -23.4581, lng: -45.0244, mapX: 62, mapY: 54 },
    howToGetThere: 'Acesso marítimo por lanchas partindo do Itaguá ou Saco da Ribeira, ou por trilha curta (no Cedrinho, após a Praia do Tenório/Vermelha do Centro) e pela Trilha das Sete Praias (no Cedro do Sul, a 40 min do Bonete).',
    accessType: 'Barco ou Trilha',
    characteristics: ['Águas cristalinas esverdeadas', 'Piscinas naturais entre pedras', 'Excelente para snorkeling', 'Faixa de areia clara e preservada'],
    infrastructure: 'Preservada / Rústica. No Cedro do Sul não há quiosques fixos; no Cedrinho há apoio sazonal simples.',
    visitorTips: ['Leve máscara de snorkel e sapatilha aquática para caminhar perto das pedras.', 'Prefira chegar pela manhã em dias de sol para ver o tom esmeralda intenso.'],
    environmentalRules: ['Recolha todo o seu lixo.', 'Evite pisar nos organismos marinhos fixados nos costões rochosos.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_HERO, IMG_LANCHA],
    videoTitle: 'Mergulho Livre nas Águas Esmeraldas da Praia do Cedro',
    videoDuration: '02:15',
    rating: 4.9,
    reviewsCount: 412,
    featured: true,
    seoTitle: 'Praia do Cedro em Ubatuba: Como Chegar, Passeios de Lancha e Dicas',
    seoDescription: 'Guia completo da Praia do Cedro em Ubatuba/SP. Descubra como chegar de lancha ou trilha, condições do mar para mergulho e passeios.',
    sourceUrl: 'https://turismo.ubatuba.sp.gov.br/praias/praia-do-cedro/'
  },
  {
    id: 'dest-sete-fontes',
    slug: 'praia-das-sete-fontes',
    name: 'Praia das Sete Fontes',
    category: 'Praias',
    region: 'Sul',
    shortDescription: 'Enseada isolada no sul de Ubatuba, acessível por passeios de escuna, lancha ou trilha a partir do Saco da Ribeira.',
    fullDescription: 'Localizada na península sul de Ubatuba, a Praia das Sete Fontes é um refúgio cercado por densa Mata Atlântica, sem acesso para veículos automotores. No canto esquerdo, uma trilha leva até o mirante e à histórica Gruta do Pirata.',
    coordinates: { lat: -23.5285, lng: -45.1142, mapX: 28, mapY: 82 },
    howToGetThere: 'Pelo mar em passeios de escuna ou lancha saindo do Saco da Ribeira (15 a 25 minutos), ou pela Trilha das Sete Fontes (aprox. 2h de caminhada saindo da Praia da Ribeira, passando pela Praia do Flamengo).',
    accessType: 'Barco ou Trilha',
    characteristics: ['Sem acesso de carros', 'Acesso à Gruta do Pirata', 'Mar calmo em boa parte da enseada', 'Cercada por Mata Atlântica nativa'],
    infrastructure: 'Quiosques caiçaras rústicos que atendem os visitantes das escunas e lanchas (recomenda-se levar dinheiro em espécie).',
    visitorTips: ['Experimente o peixe fresco nos ranchos caiçaras locais.', 'Combine a visita com parada no Aquário Natural da Ilha Anchieta.'],
    environmentalRules: ['Proibido acampar na faixa de areia.', 'Respeite a comunidade tradicional local.'],
    heroImage: IMG_ESCUNA,
    gallery: [IMG_ESCUNA, IMG_HERO, IMG_COUVES],
    videoTitle: 'Navegação até a Praia das Sete Fontes e Gruta do Pirata',
    videoDuration: '03:10',
    rating: 4.9,
    reviewsCount: 389,
    featured: true,
    seoTitle: 'Praia das Sete Fontes em Ubatuba: Passeios de Escuna, Lancha e Trilha',
    seoDescription: 'Conheça a Praia das Sete Fontes em Ubatuba. Veja horários de escunas e lanchas saindo do Saco da Ribeira e informações da trilha.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praia-das-sete-fontes-230-6312-l.html'
  },
  {
    id: 'dest-bonete',
    slug: 'praia-do-bonete',
    name: 'Praia do Bonete & Bonete Grande',
    category: 'Praias',
    region: 'Sul',
    shortDescription: 'Joias da Trilha das Sete Praias com vila caiçara tradicional e visual selvagem.',
    fullDescription: 'Situadas no percurso da famosa Trilha das Sete Praias (entre a Lagoinha e a Fortaleza), a Praia do Bonete e a Praia Grande do Bonete preservam a autêntica cultura caiçara de Ubatuba, com águas límpidas, árvores na orla e paradas frequentes de lanchas da região sul.',
    coordinates: { lat: -23.5312, lng: -45.1695, mapX: 22, mapY: 86 },
    howToGetThere: 'Por mar a partir das marinas do Saco da Ribeira ou Praia da Lagoinha, ou caminhando pela Trilha das Sete Praias (acesso plano a moderado nos primeiros trechos a partir da Lagoinha).',
    accessType: 'Barco ou Trilha',
    characteristics: ['Cultura caiçara viva', 'Integrante da Trilha das 7 Praias', 'Águas claras e sombra natural de chapéus-de-sol'],
    infrastructure: 'Pequenos quiosques familiares caiçaras na Praia Grande do Bonete.',
    visitorTips: ['Ideal para combinar trilha na ida e retorno de barco/lancha até a Lagoinha ou Saco da Ribeira.'],
    environmentalRules: ['Não deixe resíduos plásticos nas trilhas costeiras.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_COUVES],
    videoTitle: 'Costão Sul: Praia do Bonete e Trilha das 7 Praias vista do Mar',
    videoDuration: '02:40',
    rating: 4.8,
    reviewsCount: 275,
    featured: false,
    seoTitle: 'Praia do Bonete em Ubatuba: Trilha das 7 Praias e Passeios de Barco',
    seoDescription: 'Tudo sobre a Praia do Bonete em Ubatuba/SP: acesso pela Trilha das Sete Praias e passeios náuticos.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praias-de-ubatuba.html'
  },
  {
    id: 'dest-fortaleza',
    slug: 'praia-da-fortaleza',
    name: 'Praia da Fortaleza',
    category: 'Praias',
    region: 'Sul',
    shortDescription: 'Enseada de águas tranquilas e piscina natural entre rochas no extremo direito.',
    fullDescription: 'Localizada no sul de Ubatuba, a Praia da Fortaleza é um dos pontos de início ou fim da Trilha das Sete Praias. Seu canto direito abriga uma piscina natural muito procurada por famílias e praticantes de flutuação com snorkel.',
    coordinates: { lat: -23.5320, lng: -45.1580, mapX: 25, mapY: 85 },
    howToGetThere: 'Acesso asfaltado pela entrada da Praia Dura (km 68 da rodovia BR-101), percorrendo 7 km de via secundária, ou por lancha saindo do Saco da Ribeira.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Piscina natural no canto direito', 'Mar calmo na enseada', 'Ponto da Trilha das Sete Praias'],
    infrastructure: 'Quiosques e estacionamento próximo à orla (vagas disputadas na alta temporada).',
    visitorTips: ['Chegue cedo se for de carro ou opte por passeio de lancha para fundear com conforto na enseada.'],
    environmentalRules: ['Proibido som automotivo ou caixas de som na faixa de areia.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_LANCHA],
    videoTitle: 'Piscina Natural da Praia da Fortaleza em Ubatuba',
    videoDuration: '01:55',
    rating: 4.8,
    reviewsCount: 330,
    featured: false,
    seoTitle: 'Praia da Fortaleza Ubatuba: Como Chegar e Piscina Natural',
    seoDescription: 'Saiba como visitar a Praia da Fortaleza em Ubatuba por terra ou lancha.',
    sourceUrl: 'https://turismo.ubatuba.sp.gov.br/praias/praia-da-fortaleza/'
  },
  {
    id: 'dest-sununga',
    slug: 'praia-da-sununga',
    name: 'Praia da Sununga',
    category: 'Praias',
    region: 'Sul',
    shortDescription: 'Famosa mundialmente pelo skimboard e pela Gruta que Chora.',
    fullDescription: 'Vizinha às praias do Lázaro e Domingas Dias, a Praia da Sununga abriga a famosa Gruta que Chora e possui ondas de rebentação forte na areia, sendo considerada um dos principais picos mundiais para a prática de skimboard.',
    coordinates: { lat: -23.5045, lng: -45.1310, mapX: 33, mapY: 75 },
    howToGetThere: 'Acesso fácil a pé pelo canto esquerdo da Praia do Lázaro (km 64 da BR-101).',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Abriga a Gruta que Chora', 'Capital do Skimboard', 'Mar de tombo forte (impróprio para crianças pequenas nadarem)'],
    infrastructure: 'Quiosques na orla e ampla rede hoteleira no bairro do Lázaro.',
    visitorTips: ['Mar forte com correnteza: ideal para contemplação, fotos na Gruta que Chora e assistir às manobras de skimboard.'],
    environmentalRules: ['Preserve as paredes rochosas da Gruta que Chora; não faça inscrições nas pedras.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_ESCUNA],
    videoTitle: 'Gruta que Chora e Ondas na Praia da Sununga',
    videoDuration: '01:45',
    rating: 4.7,
    reviewsCount: 295,
    featured: false,
    seoTitle: 'Praia da Sununga e Gruta que Chora em Ubatuba',
    seoDescription: 'Conheça a Praia da Sununga, a Gruta que Chora e as dicas de segurança no mar no sul de Ubatuba.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praias-de-ubatuba.html'
  },
  {
    id: 'dest-domingas-dias',
    slug: 'praia-domingas-dias',
    name: 'Praia Domingas Dias',
    category: 'Praias',
    region: 'Sul',
    shortDescription: 'Águas tranquilas e cristalinas em uma enseada exclusiva ao lado da Praia do Lázaro.',
    fullDescription: 'Uma das praias mais charmosas e calmas da região sul, a Praia Domingas Dias possui mar sem ondas, águas transparentes e vista privilegiada para o Pico do Corcovado. É ponto constante de fundeio de lanchas que partem do Saco da Ribeira.',
    coordinates: { lat: -23.5022, lng: -45.1425, mapX: 35, mapY: 74 },
    howToGetThere: 'Acesso por condomínio a partir da Praia do Lázaro (controle de estacionamento) ou pelo mar em poucos minutos a partir do Saco da Ribeira.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Mar estilo piscina', 'Excelente para crianças e Stand Up Paddle', 'Sem quiosques na areia (ambiente silencioso)'],
    infrastructure: 'Não possui quiosques ou comércio na faixa de areia, garantindo tranquilidade.',
    visitorTips: ['Leve água e lanches próprios ou visite a bordo de uma lancha com serviço de bordo.'],
    environmentalRules: ['Proibido comércio ambulante irregular e caixas de som.'],
    heroImage: IMG_LANCHA,
    gallery: [IMG_LANCHA, IMG_COUVES],
    videoTitle: 'Fundeio de Lancha na Enseada de Domingas Dias',
    videoDuration: '02:05',
    rating: 4.9,
    reviewsCount: 510,
    featured: true,
    seoTitle: 'Praia Domingas Dias em Ubatuba: Mar Calmo e Passeios de Lancha',
    seoDescription: 'Descubra a Praia Domingas Dias em Ubatuba, ideal para famílias, crianças e passeios de lancha.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praias-de-ubatuba.html'
  },
  {
    id: 'dest-portugues',
    slug: 'praia-do-portugues',
    name: 'Praia do Português (Prainha do Félix)',
    category: 'Praias',
    region: 'Norte',
    shortDescription: 'Pequeno refúgio escondido entre rochas ao lado direito da Praia do Félix.',
    fullDescription: 'Escondida a poucos metros do canto direito da Praia do Félix, a Praia do Português (também chamada de Prainha do Félix) tem cerca de 50 metros de areia branca e águas esverdeadas super calmas, formando um cenário digno de cartão-postal.',
    coordinates: { lat: -23.3865, lng: -44.9682, mapX: 74, mapY: 34 },
    howToGetThere: 'Pelo canto direito da Praia do Félix (km 34 da BR-101), atravessando uma curta trilha pelas pedras ou contornando pela água na maré baixa.',
    accessType: 'Barco ou Trilha',
    characteristics: ['Acesso dependente da maré pela água ou trilha curta pelas pedras', 'Piscina natural cristalina', 'Pequena extensão de areia'],
    infrastructure: 'Sem infraestrutura própria; utiliza-se o apoio da vizinha Praia do Félix.',
    visitorTips: ['Verifique a tábua de marés antes de atravessar caminhando pela água a partir do Félix.'],
    environmentalRules: ['Atenção redobrada nas pedras escorregadias na travessia.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_HERO],
    videoTitle: 'Como Chegar na Secreta Praia do Português (Prainha do Félix)',
    videoDuration: '01:50',
    rating: 4.9,
    reviewsCount: 342,
    featured: true,
    seoTitle: 'Praia do Português (Prainha do Félix) em Ubatuba: Como Acessar',
    seoDescription: 'Saiba como acessar a Praia do Português ao lado da Praia do Félix no norte de Ubatuba.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praia-do-portugues-prainha-do-felix-230-6325-l.html'
  },
  {
    id: 'dest-prumirim',
    slug: 'praia-do-prumirim',
    name: 'Praia do Prumirim',
    category: 'Praias',
    region: 'Norte',
    shortDescription: 'Ampla faixa de areia dourada, encontro do rio com o mar e vista para a Ilha do Prumirim.',
    fullDescription: 'Localizada a 18 km ao norte do Centro, a Praia do Prumirim combina ondas fortes no centro da praia com uma lagoa de água doce tranquila no canto direito (foz do Rio Prumirim) e ponto de partida de barcos para a Ilha do Prumirim.',
    coordinates: { lat: -23.3792, lng: -44.9598, mapX: 77, mapY: 31 },
    howToGetThere: 'Entrada pelo km 30 da rodovia Rio-Santos (BR-101), através do condomínio do Prumirim, ou em roteiros de lancha e escuna Norte.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Foz de rio de água doce no canto direito', 'Ponto de travessia de 5 min para a Ilha do Prumirim', 'Quiosques pé na areia de alto padrão'],
    infrastructure: 'Excelente infraestrutura gastronômica com restaurantes e quiosques estruturados.',
    visitorTips: ['Combine o dia no Trio Prumirim: Praia do Prumirim, Ilha do Prumirim e Cachoeira do Prumirim.'],
    environmentalRules: ['Estacione apenas nos locais demarcados pelo condomínio e Zona Azul municipal.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_COUVES, IMG_CACHOEIRA],
    videoTitle: 'Trio Prumirim: Praia, Rio de Água Doce e Travessia para a Ilha',
    videoDuration: '02:50',
    rating: 4.9,
    reviewsCount: 468,
    featured: true,
    seoTitle: 'Praia do Prumirim em Ubatuba: Guia Completo, Ilha e Cachoeira',
    seoDescription: 'Conheça a Praia do Prumirim no norte de Ubatuba: foz do rio, quiosques e travessia de barco para a Ilha do Prumirim.',
    sourceUrl: 'https://reservas.caminhosdastrilhas.tur.br/blog/trio-prumirim-ubatuba-sp'
  },
  {
    id: 'dest-itamambuca',
    slug: 'praia-de-itamambuca',
    name: 'Praia de Itamambuca',
    category: 'Praias',
    region: 'Norte',
    shortDescription: 'Santuário mundial do surf, reserva ecológica e encontro do Rio Itamambuca com o mar.',
    fullDescription: 'Reconhecida internacionalmente pelos campeonatos de surf e pela reserva ecológica de restinga e Mata Atlântica, Itamambuca oferece uma extensa faixa de areia, ondas constantes e o belo encontro do Rio Itamambuca no canto direito.',
    coordinates: { lat: -23.4015, lng: -45.0010, mapX: 69, mapY: 41 },
    howToGetThere: 'Acesso pelo km 36 da rodovia BR-101 (Rio-Santos), a cerca de 12 km ao norte do Centro de Ubatuba.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Palco de etapas internacionais de surf', 'Encontro do Rio Itamambuca com o mar', 'Vila charmosa com gastronomia e pousadas'],
    infrastructure: 'Completa no bairro e pousadas; faixa de areia preservada com barracas regulamentadas.',
    visitorTips: ['Para famílias com crianças pequenas, prefira o banho na foz rasa do Rio Itamambuca no canto direito, pois o mar aberto tem correnteza forte.'],
    environmentalRules: ['Área de proteção ambiental rigorosa: proibido trânsito de veículos na areia.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_CACHOEIRA],
    videoTitle: 'Surf, Natureza e Encontro do Rio na Praia de Itamambuca',
    videoDuration: '02:20',
    rating: 4.9,
    reviewsCount: 520,
    featured: false,
    seoTitle: 'Praia de Itamambuca Ubatuba: Surf, Rio Itamambuca e Dicas',
    seoDescription: 'Visite a Praia de Itamambuca em Ubatuba: ondas para surf, encontro do rio com o mar e natureza preservada.',
    sourceUrl: 'https://www.grupodicas.com/melhores-praias-de-ubatuba/'
  },
  {
    id: 'dest-felix',
    slug: 'praia-do-felix',
    name: 'Praia do Félix',
    category: 'Praias',
    region: 'Norte',
    shortDescription: 'Sombra natural de abricós-da-praia, canto direito calmo para famílias e esquerdo para surf.',
    fullDescription: 'Situada a 17 km ao norte do centro (km 34 da BR-101), a Praia do Félix agrada a todos os perfis: seu canto direito possui águas calmas como uma piscina natural com sombra das árvores na orla, enquanto o canto esquerdo oferece boas ondas para surf.',
    coordinates: { lat: -23.3880, lng: -44.9710, mapX: 73, mapY: 36 },
    howToGetThere: 'Acesso pavimentado por dentro de condomínio no km 34 da BR-101 ou parada em roteiros de lancha do Litoral Norte.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Duas personalidades: mar calmo na direita e ondas na esquerda', 'Sombra natural na orla', 'Vizinha à Praia do Português e Praia das Conchas'],
    infrastructure: 'Quiosques tradicionais sob as árvores, base de salva-vidas e estacionamento.',
    visitorTips: ['Caminhe até o canto direito para acessar a trilha curta rumo à Praia do Português.'],
    environmentalRules: ['Respeite as áreas de preservação de restinga junto às árvores.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_LANCHA],
    videoTitle: 'Praia do Félix: Piscina Natural no Canto Direito e Sombra na Orla',
    videoDuration: '02:10',
    rating: 4.9,
    reviewsCount: 490,
    featured: true,
    seoTitle: 'Praia do Félix em Ubatuba: Canto Calmo, Infraestrutura e Como Chegar',
    seoDescription: 'Guia completo da Praia do Félix em Ubatuba/SP: onde ficar na praia, estacionamento e passeios de barco.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praia-do-portugues-prainha-do-felix-230-6325-l.html'
  },
  {
    id: 'dest-almada',
    slug: 'praia-da-almada',
    name: 'Praia da Almada & Praia do Engenho',
    category: 'Praias',
    region: 'Norte',
    shortDescription: 'Vila caiçara gastronômica de águas super tranquilas e ponto de saída para ilhas do norte.',
    fullDescription: 'Localizada no norte de Ubatuba (acesso pelo km 13 da BR-101), a Praia da Almada forma uma baía abrigada ao lado da Praia do Engenho, famosa pelos restaurantes de frutos do mar pé na areia e pelo mar sereno ideal para famílias e embarque náutico.',
    coordinates: { lat: -23.3560, lng: -44.8890, mapX: 86, mapY: 20 },
    howToGetThere: 'Acesso asfaltado secundário a partir do km 13 da BR-101 ou por lanchas no roteiro Norte.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['Mar extremamente calmo', 'Polo gastronômico caiçara', 'Ligada à Praia do Engenho por passarela entre pedras'],
    infrastructure: 'Ampla oferta de restaurantes e quiosques tradicionais de pescadores.',
    visitorTips: ['Excelente parada de almoço nos roteiros de lancha privativa que visitam a Ilha das Couves e Ilha dos Porcos.'],
    environmentalRules: ['Observe o limite das áreas de atracação de barcos de pesca local.'],
    heroImage: IMG_ESCUNA,
    gallery: [IMG_ESCUNA, IMG_COUVES],
    videoTitle: 'Vila Caiçara e Gastronomia na Praia da Almada',
    videoDuration: '02:00',
    rating: 4.8,
    reviewsCount: 315,
    featured: false,
    seoTitle: 'Praia da Almada em Ubatuba: Restaurantes, Mar Calmo e Passeios',
    seoDescription: 'Descubra a Praia da Almada e Praia do Engenho no norte de Ubatuba.',
    sourceUrl: 'https://www.melhoresdestinos.com.br/praias-de-ubatuba.html'
  },
  {
    id: 'dest-fazenda',
    slug: 'praia-da-fazenda',
    name: 'Praia da Fazenda (Núcleo Picinguaba)',
    category: 'Praias',
    region: 'Norte',
    shortDescription: '3,5 km de praia intocada dentro do Parque Estadual da Serra do Mar.',
    fullDescription: 'Situada no km 11 da rodovia BR-101 e sede do Centro de Visitantes do Parque Estadual da Serra do Mar (Núcleo Picinguaba), a Praia da Fazenda é um santuário ecológico sem construções comerciais na orla, com areia compacta que espelha o céu e as montanhas da Serra do Mar.',
    coordinates: { lat: -23.3620, lng: -44.8510, mapX: 91, mapY: 16 },
    howToGetThere: 'Acesso direto no km 11 da rodovia Rio-Santos (BR-101), próximo à divisa norte de Ubatuba.',
    accessType: 'Acesso Asfaltado / Carro',
    characteristics: ['3,5 km de orla 100% preservada', 'Sede do Núcleo Picinguaba do Parque Estadual', 'Areia firme e espelhada'],
    infrastructure: 'Centro de Visitantes do Parque Estadual com banheiros e informações; não há quiosques nem comércio na praia.',
    visitorTips: ['Leve água e lanche; aproveite para conhecer as trilhas ecológicas guiadas do Núcleo Picinguaba.'],
    environmentalRules: ['Unidade de Conservação Integral: proibido animais domésticos, churrasco, som e coleta de espécies.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_CACHOEIRA],
    videoTitle: 'Natureza Intocada na Praia da Fazenda — Parque Estadual da Serra do Mar',
    videoDuration: '02:35',
    rating: 4.9,
    reviewsCount: 378,
    featured: false,
    seoTitle: 'Praia da Fazenda Ubatuba: Parque Estadual da Serra do Mar',
    seoDescription: 'Visite a Praia da Fazenda no Núcleo Picinguaba em Ubatuba: regras de visitação, trilhas e dicas.',
    sourceUrl: 'https://guiadeareasprotegidas.sp.gov.br/trilha/trilha-da-cachoeira-da-agua-branca/'
  },

  // 5 ILHAS OBRIGATÓRIAS
  {
    id: 'dest-ilha-anchieta',
    slug: 'ilha-anchieta',
    name: 'Ilha Anchieta (Parque Estadual)',
    category: 'Ilhas',
    region: 'Sul',
    shortDescription: 'Sete praias paradisíacas, Piscina Natural do Engenho, tartarugas marinhas e ruínas históricas.',
    fullDescription: 'Segunda maior ilha do litoral norte paulista, o Parque Estadual da Ilha Anchieta reúne história (ruínas do antigo presídio desativado em 1955), trilhas ecológicas e praias de águas transparentes como a Praia do Presídio, Praia do Sapateiro, Praia das Palmas, Praia do Engenho (famosa pelo aquário natural repleto de peixes e tartarugas) e Praia do Sul.',
    coordinates: { lat: -23.5410, lng: -45.0680, mapX: 42, mapY: 88 },
    howToGetThere: 'Exclusivamente pelo mar, em passeios de escuna ou lancha partindo principalmente do Saco da Ribeira (travessia de 20 a 35 minutos) ou do Itaguá.',
    accessType: 'Barco / Lancha',
    characteristics: ['7 praias insulares preservadas', 'Aquário Natural na Praia do Engenho', 'Ruínas históricas e museu', 'Observação frequente de tartarugas marinhas'],
    infrastructure: 'Sede administrativa do Parque Estadual na Praia do Presídio com banheiros, auditório e trilhas sinalizadas (não há restaurantes comerciais na ilha).',
    visitorTips: ['A taxa ambiental de visitação do Parque Estadual custa R$ 14 por pessoa (verifique isenções oficiais).', 'Leve seu próprio lanche e água, pois não há venda de alimentos na ilha.'],
    environmentalRules: ['Proibido alimentar animais silvestres (quatis, macacos e peixes).', 'Trilha da Praia do Sul exige agendamento com monitor credenciado.'],
    heroImage: IMG_ESCUNA,
    gallery: [IMG_ESCUNA, IMG_LANCHA, IMG_COUVES],
    videoTitle: 'Tour Completo pela Ilha Anchieta: Ruínas, Praia das Palmas e Aquário Natural',
    videoDuration: '03:45',
    rating: 5.0,
    reviewsCount: 845,
    featured: true,
    seoTitle: 'Ilha Anchieta em Ubatuba: Passeios de Escuna, Lancha, Preços e Dicas',
    seoDescription: 'Como visitar a Ilha Anchieta em Ubatuba/SP: horários de escunas e lanchas do Saco da Ribeira, ingresso do Parque Estadual e praias.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praias-de-ubatuba.html'
  },
  {
    id: 'dest-ilha-couves',
    slug: 'ilha-das-couves',
    name: 'Ilha das Couves',
    category: 'Ilhas',
    region: 'Norte',
    shortDescription: 'O caribe de Ubatuba: duas praias de águas verde-esmeralda com visibilidade extraordinária.',
    fullDescription: 'Cartão-postal número um do norte de Ubatuba, a Ilha das Couves possui duas praias deslumbrantes — a Praia Menor (de Fora / Terra) e a Praia Maior (de Dentro / Prainha), conectadas por uma trilha curta de 5 minutos. Suas águas cristalinas permitem observar cardumes coloridos a olho nu.',
    coordinates: { lat: -23.4210, lng: -44.8550, mapX: 90, mapY: 26 },
    howToGetThere: 'Embarcações credenciadas partindo da Praia de Picinguaba (15 minutos de travessia) ou passeios de lancha e escuna do Roteiro Norte saindo do Itaguá e Prumirim.',
    accessType: 'Barco / Lancha',
    characteristics: ['Duas praias de águas verde-esmeralda', 'Visibilidade subaquática perfeita para snorkel', 'Controle de capacidade diária em turnos de visitação'],
    infrastructure: 'Sem infraestrutura comercial fixa na ilha; é necessário levar água e lanche próprios.',
    visitorTips: ['Utilize protetor solar biodegradável/mineral para proteger a vida marinha.', 'Leve saquinho para retornar com todo o seu lixo ao continente.'],
    environmentalRules: ['Proibido garrafas de vidro, caixas de som de qualquer porte, churrasco e animais de estimação.', 'Desembarque regulamentado por turnos oficiais de visitação.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_LANCHA, IMG_HERO],
    videoTitle: 'Ilha das Couves vista de Drone e Mergulho nas Duas Praias',
    videoDuration: '03:20',
    rating: 5.0,
    reviewsCount: 960,
    featured: true,
    seoTitle: 'Ilha das Couves em Ubatuba: Como Ir, Passeios de Lancha e Regras 2026',
    seoDescription: 'Guia atualizado da Ilha das Couves em Ubatuba: saídas de Picinguaba e Itaguá, regras ambientais, preços e reserva de lancha.',
    sourceUrl: 'https://kaimaresturismo.com.br/blog/ilhas-ubatuba/'
  },
  {
    id: 'dest-ilha-prumirim',
    slug: 'ilha-do-prumirim',
    name: 'Ilha do Prumirim',
    category: 'Ilhas',
    region: 'Norte',
    shortDescription: 'Areia branquinha e piscina natural a apenas 5 minutos de barco da Praia do Prumirim.',
    fullDescription: 'Situada em frente à Praia do Prumirim, a Ilha do Prumirim destaca-se pela enseada voltada para o continente com mar super calmo, águas transparentes e vista panorâmica da Serra do Mar coberta pela Mata Atlântica.',
    coordinates: { lat: -23.3845, lng: -44.9460, mapX: 80, mapY: 33 },
    howToGetThere: 'Travessia rápida de 5 minutos a partir da Praia do Prumirim ou parada obrigatória nos passeios de escuna e lancha do Roteiro Ilhas Norte saindo do Itaguá.',
    accessType: 'Barco / Lancha',
    characteristics: ['Travessia curta e abrigada', 'Excelente para flutuação com crianças', 'Visual paradisíaco das pedras no canto esquerdo'],
    infrastructure: 'Estrutura rústica sazonal; recomenda-se levar água, lanche e dinheiro em espécie.',
    visitorTips: ['Excelente ponto para fotos subaquáticas próximo ao costão rochoso esquerdo.'],
    environmentalRules: ['Não suba nas pedras mais altas em dias de mar agitado na face externa da ilha.'],
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_ESCUNA],
    videoTitle: 'Ilha do Prumirim: Águas Transparentes no Roteiro Norte',
    videoDuration: '02:15',
    rating: 4.9,
    reviewsCount: 615,
    featured: true,
    seoTitle: 'Ilha do Prumirim em Ubatuba: Passeios de Escuna, Lancha e Travessia',
    seoDescription: 'Saiba como visitar a Ilha do Prumirim em Ubatuba: travessia da Praia do Prumirim e roteiros de escuna e lancha.',
    sourceUrl: 'https://www.passeiosdeescuna.com.br/ilhas-norte/'
  },
  {
    id: 'dest-ilha-porcos',
    slug: 'ilha-dos-porcos',
    name: 'Ilha dos Porcos (Ilha dos Porcos Pequena)',
    category: 'Ilhas',
    region: 'Norte',
    shortDescription: 'Praia calma em frente à Almada, muito visitada em roteiros náuticos do norte.',
    fullDescription: 'Localizada próxima à Praia da Almada e à Ilha da Selinha (conhecida como a menor praia do Brasil), a Ilha dos Porcos possui uma charmosa faixa de areia de águas tranquilas, sendo parada clássica para mergulho e contemplação nos roteiros de lancha e escuna do norte.',
    coordinates: { lat: -23.3680, lng: -44.8950, mapX: 85, mapY: 23 },
    howToGetThere: 'Por lancha ou escuna no Roteiro Norte (partindo do Itaguá, Prumirim ou Almada).',
    accessType: 'Barco / Lancha',
    characteristics: ['Águas abrigadas em frente à baía da Almada', 'Próxima à Ilha da Selinha', 'Excelente parada de banho e fotos'],
    infrastructure: 'Propriedade insular sem comércio público; parada dedicada ao banho de mar e faixa de areia.',
    visitorTips: ['Observe na navegação a vizinha Ilha da Selinha, famosa pela minúscula faixa de areia.'],
    environmentalRules: ['Permaneça apenas na faixa de areia e área de banho permitida.'],
    heroImage: IMG_LANCHA,
    gallery: [IMG_LANCHA, IMG_COUVES],
    videoTitle: 'Fundeio na Ilha dos Porcos e Passagem pela Ilha da Selinha',
    videoDuration: '02:05',
    rating: 4.8,
    reviewsCount: 280,
    featured: false,
    seoTitle: 'Ilha dos Porcos em Ubatuba: Roteiro Ilhas Norte de Lancha e Escuna',
    seoDescription: 'Conheça a Ilha dos Porcos no litoral norte de Ubatuba em passeios de lancha e escuna.',
    sourceUrl: 'https://www.passeiosdeescuna.com.br/ilhas-norte/'
  },
  {
    id: 'dest-ilha-rapada',
    slug: 'ilha-da-rapada',
    name: 'Ilha da Rapada (e Ilha Rachada)',
    category: 'Ilhas',
    region: 'Norte',
    shortDescription: 'Formações rochosas imponentes e ponto consagrado de mergulho contemplativo.',
    fullDescription: 'Situada na rota costeira norte de Ubatuba, a Ilha da Rapada (junto à famosa formação da Ilha Rachada) impressiona pelos costões rochosos, rica biodiversidade marinha de costão e visual dramático em meio ao oceano.',
    coordinates: { lat: -23.4310, lng: -44.9080, mapX: 83, mapY: 38 },
    howToGetThere: 'Passagem panorâmica e ponto de mergulho em passeios de lancha privativa saindo do Itaguá.',
    accessType: 'Barco / Lancha',
    characteristics: ['Costão rochoso sem praia de desembarque', 'Rica vida marinha subaquática', 'Cenário fotográfico impressionante'],
    infrastructure: 'Formação insular natural sem desembarque em areia (contemplação e mergulho embarcado quando o mar permite).',
    visitorTips: ['Confirme com o comandante da lancha as condições de maré e ondulação no dia do passeio.'],
    environmentalRules: ['Mergulho apenas com colete ou flutuador sob orientação do marinheiro.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_LANCHA],
    videoTitle: 'Navegação Costeira pela Ilha da Rapada e Ilha Rachada',
    videoDuration: '01:50',
    rating: 4.8,
    reviewsCount: 195,
    featured: false,
    seoTitle: 'Ilha da Rapada em Ubatuba: Mergulho e Passeios Náuticos',
    seoDescription: 'Descubra a Ilha da Rapada na costa norte de Ubatuba em roteiros de lancha.',
    sourceUrl: 'https://kaimaresturismo.com.br/blog/ilhas-ubatuba/'
  },

  // 3 CACHOEIRAS OBRIGATÓRIAS
  {
    id: 'dest-cachoeira-prumirim',
    slug: 'cachoeira-do-prumirim',
    name: 'Cachoeira do Prumirim',
    category: 'Cachoeiras',
    region: 'Norte',
    shortDescription: 'Poços naturais de água cristalina e escorregador natural na rocha ao lado da BR-101.',
    fullDescription: 'Localizada no km 30 da rodovia Rio-Santos (BR-101), a poucos minutos da Praia do Prumirim, a Cachoeira do Prumirim possui três quedas principais com poços largos de águas verdes e transparentes, cercados pela Mata Atlântica.',
    coordinates: { lat: -23.3710, lng: -44.9690, mapX: 76, mapY: 28 },
    howToGetThere: 'Acesso fácil no km 30 da rodovia BR-101, seguido de trilha curta (cerca de 5 a 15 minutos conforme o poço escolhido).',
    accessType: 'Trilha',
    characteristics: ['Trilha curta e acessível (aprox. 2 km ida e volta no circuito completo)', 'Poços naturais para banho', 'Próxima à Praia e Ilha do Prumirim'],
    infrastructure: 'Acesso natural em área de mata; não há restaurantes no poço.',
    visitorTips: ['Use calçado aderente para caminhar nas trilhas úmidas.', 'Nunca visite cachoeiras da Serra do Mar sob chuva forte devido ao risco de cabeça d’água.'],
    environmentalRules: ['Proibido deixar lixo, fazer fogueiras ou usar sabonete/shampoo nos poços.'],
    heroImage: IMG_CACHOEIRA,
    gallery: [IMG_CACHOEIRA, IMG_HERO],
    videoTitle: 'Poços Cristalinos da Cachoeira do Prumirim em Ubatuba',
    videoDuration: '02:25',
    rating: 4.8,
    reviewsCount: 410,
    featured: true,
    seoTitle: 'Cachoeira do Prumirim em Ubatuba: Como Chegar, Trilha e Dicas',
    seoDescription: 'Tudo sobre a Cachoeira do Prumirim no km 30 da BR-101 em Ubatuba: acesso, poços para banho e segurança.',
    sourceUrl: 'https://reservas.caminhosdastrilhas.tur.br/blog/trio-prumirim-ubatuba-sp'
  },
  {
    id: 'dest-cachoeira-renata',
    slug: 'cachoeira-da-renata',
    name: 'Cachoeira da Renata (e Poço Verde)',
    category: 'Cachoeiras',
    region: 'Sertão / Serra do Mar',
    shortDescription: 'Águas límpidas que descem da Serra do Mar no Sertão da Quina, região sul de Ubatuba.',
    fullDescription: 'Localizada no bairro Sertão da Quina (acesso pela região da Maranduba, sul de Ubatuba), a Cachoeira da Renata recebe as águas puras que descem da Serra do Mar, formando poços refrescantes como o Poço da Renata, Poço do Chafariz e Poço Verde.',
    coordinates: { lat: -23.5390, lng: -45.2490, mapX: 16, mapY: 79 },
    howToGetThere: 'Acesso terrestre a partir da Praia da Maranduba seguindo para o interior do bairro Sertão da Quina (Rua Benedito Antônio Elói).',
    accessType: 'Trilha',
    characteristics: ['Águas cristalinas da Serra do Mar', 'Ponto de partida para poços superiores do Rio Água Branca', 'Ambiente de floresta preservada'],
    infrastructure: 'Apoio simples no início do acesso no Sertão da Quina.',
    visitorTips: ['Leve repelente biodegradável e calçado fechado para trilha.'],
    environmentalRules: ['Evite visitação em dias chuvosos na cabeceira da serra.'],
    heroImage: IMG_CACHOEIRA,
    gallery: [IMG_CACHOEIRA, IMG_COUVES],
    videoTitle: 'Cachoeira da Renata e Poço Verde no Sertão da Quina',
    videoDuration: '02:30',
    rating: 4.7,
    reviewsCount: 265,
    featured: false,
    seoTitle: 'Cachoeira da Renata no Sertão da Quina em Ubatuba',
    seoDescription: 'Saiba como visitar a Cachoeira da Renata no Sertão da Quina (Maranduba), Ubatuba/SP.',
    sourceUrl: 'https://www.curiosidadesdeubatuba.com.br/cachoeira-da-renata/'
  },
  {
    id: 'dest-cachoeira-agua-branca',
    slug: 'cachoeira-da-agua-branca',
    name: 'Cachoeira da Água Branca',
    category: 'Cachoeiras',
    region: 'Sertão / Serra do Mar',
    shortDescription: 'A maior cachoeira do Estado de São Paulo (~200m de queda) em trilha de alta aventura.',
    fullDescription: 'Situada dentro do Parque Estadual da Serra do Mar (Núcleo Picinguaba, com acesso pelo Sertão da Quina / Maranduba), a Cachoeira da Água Branca possui quase 200 metros de queda livre em meio à Floresta Ombrófila Densa. É um patrimônio ambiental e histórico de Ubatuba.',
    coordinates: { lat: -23.5180, lng: -45.2620, mapX: 14, mapY: 72 },
    howToGetThere: 'Trilha de nível difícil saindo do Sertão da Quina (cerca de 10 km ida e volta, 500m de altimetria acumulada, duração de 6 a 8 horas). Exige agendamento e monitor ambiental credenciado.',
    accessType: 'Trilha',
    characteristics: ['Maior queda d’água do Estado de SP (~200m)', 'Trilha de nível difícil (10 km total)', 'Limite de 75 visitantes por dia pelo Parque Estadual'],
    infrastructure: 'Trilha selvagem de Unidade de Conservação; sem infraestrutura comercial no percurso.',
    visitorTips: ['Monitoria ambiental credenciada é obrigatória segundo o Guia de Áreas Protegidas de SP.', 'Exige excelente preparo físico, bota de trilha amaciada e 2L de água por pessoa.'],
    environmentalRules: ['Monitoria obrigatória e agendamento prévio junto ao Parque Estadual da Serra do Mar.', 'Horário de entrada na trilha restrito das 08h00 às 14h00.'],
    heroImage: IMG_CACHOEIRA,
    gallery: [IMG_CACHOEIRA, IMG_HERO],
    videoTitle: 'Expedição à Cachoeira da Água Branca (200m de Queda)',
    videoDuration: '04:10',
    rating: 5.0,
    reviewsCount: 198,
    featured: true,
    seoTitle: 'Cachoeira da Água Branca Ubatuba: Trilha, Agendamento e Guia',
    seoDescription: 'Expedição para a Cachoeira da Água Branca em Ubatuba, a maior de SP: regras do Parque Estadual, distância e monitoria.',
    sourceUrl: 'https://guiadeareasprotegidas.sp.gov.br/trilha/trilha-da-cachoeira-da-agua-branca/'
  },

  // TRILHAS E AVENTURAS
  {
    id: 'dest-trilha-sete-praias',
    slug: 'trilha-das-sete-praias',
    name: 'Trilha das Sete Praias (Lagoinha à Fortaleza)',
    category: 'Trilhas e Aventuras',
    region: 'Sul',
    shortDescription: 'O trekking costeiro mais famoso de Ubatuba passando por praias desertas e mirantes.',
    fullDescription: 'Com cerca de 10 km de extensão total ligando a Praia da Lagoinha à Praia da Fortaleza, a Trilha das Sete Praias atravessa as praias do Oeste, Perez, Bonete, Grande do Bonete, Deserto, Prainha do Deserto e Cedro do Sul, oferecendo visuais espetaculares do mar verde-esmeralda.',
    coordinates: { lat: -23.5295, lng: -45.1750, mapX: 20, mapY: 84 },
    howToGetThere: 'Início pelo canto esquerdo da Praia da Lagoinha (km 72 da BR-101) ou pelo canto direito da Praia da Fortaleza.',
    accessType: 'Barco ou Trilha',
    characteristics: ['Passa por 7 praias preservadas', 'Possibilidade de retorno de barco/lancha no Bonete ou Cedro', 'Mirantes naturais para fotos panorâmicas'],
    infrastructure: 'Quiosques caiçaras na Praia Grande do Bonete e apoio nas pontas (Lagoinha e Fortaleza).',
    visitorTips: ['Contrate um guia local ou combine o resgate de lancha na Praia do Cedro do Sul ou Bonete para curtir as praias com mais tempo.'],
    environmentalRules: ['Mantenha-se na trilha principal demarcada para evitar erosão nos costões.'],
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_COUVES, IMG_CACHOEIRA],
    videoTitle: 'Trilha das Sete Praias Completa: Mirantes e Resgate de Lancha',
    videoDuration: '03:55',
    rating: 4.9,
    reviewsCount: 612,
    featured: true,
    seoTitle: 'Trilha das 7 Praias em Ubatuba: Mapa, Praias, Dificuldade e Barco',
    seoDescription: 'Guia passo a passo da Trilha das Sete Praias em Ubatuba: quais são as 7 praias, tempo de caminhada e retorno de barco.',
    sourceUrl: 'https://guia.melhoresdestinos.com.br/praias-de-ubatuba.html'
  }
];

const INITIAL_VESSELS: Vessel[] = [
  {
    id: 'ves-phantom-340',
    slug: 'lancha-oceano-azul-34-pes',
    name: 'Lancha Oceano Azul 340 (34 Pés)',
    partnerId: 'part-kaimares',
    type: 'Lancha',
    operationMode: 'Ambos',
    capacity: 12,
    lengthFeet: 34,
    engineSpec: '2x Mercury 250HP 4 Tempos',
    baseLocation: 'Píer do Itaguá & Saco da Ribeira',
    description: 'Lancha rápida e confortável com solário de proa acolchoado, plataforma de popa estendida com escada submersível, churrasqueira inox, som Bluetooth marinizado e banheiro fechado.',
    features: ['Solário de proa duplo', 'Som Bluetooth Premium', 'Churrasqueira a bordo', 'Toldo retrátil amplo', 'Ducha de água doce'],
    structure: ['Cabine de apoio com banheiro elétrico', 'Cooler térmico de 120L', 'Plataforma de popa revestida em EVA náutico'],
    safetyEquipment: ['Coletes salva-vidas homologados Marinha do Brasil (adulto e infantil)', 'Bote de apoio / Flutuadores espaguete', 'Rádio VHF e GPS Sonar Garmin', 'Seguro DPEM vigente'],
    heroImage: IMG_LANCHA,
    gallery: [IMG_LANCHA, IMG_HERO, IMG_COUVES],
    videoTitle: 'Tour a Bordo da Lancha Oceano Azul 340 em Navegação',
    rating: 4.9
  },
  {
    id: 'ves-focker-280',
    slug: 'lancha-brisa-do-norte-28-pes',
    name: 'Lancha Brisa do Norte 280 (28 Pés)',
    partnerId: 'part-rotadomar',
    type: 'Lancha',
    operationMode: 'Privativo',
    capacity: 9,
    lengthFeet: 28,
    engineSpec: 'Mercruiser 300HP V8',
    baseLocation: 'Marina Saco da Ribeira',
    description: 'Embarcação ágil e exclusiva dedicada a passeios privativos para casais, famílias e pequenos grupos. Ideal para fundear próximo às praias da Ilha Anchieta, Sete Fontes e Domingas Dias.',
    features: ['Exclusiva para Charter Privativo', 'Kit Snorkel e Máscaras a bordo', 'Prancha de Stand Up Paddle inclusa', 'Churrasqueira e tábua de corte'],
    structure: ['Toalete reservado', 'Mesa de centro em teca', '2 caixas térmicas integradas'],
    safetyEquipment: ['Coletes homologados Classe II e III', 'Boia circular com retinida', 'Rádio VHF e Rastreador Satelital'],
    heroImage: IMG_LANCHA,
    gallery: [IMG_LANCHA, IMG_COUVES],
    videoTitle: 'Experiência Privativa na Lancha Brisa do Norte 28 Pés',
    rating: 5.0
  },
  {
    id: 'ves-escuna-corsario',
    slug: 'escuna-rainha-de-anchieta',
    name: 'Escuna Tradicional Rainha de Anchieta',
    partnerId: 'part-escunascaicara',
    type: 'Escuna',
    operationMode: 'Compartilhado',
    capacity: 65,
    lengthFeet: 62,
    engineSpec: 'Scania Marítimo 320HP Diesel',
    baseLocation: 'Saco da Ribeira & Praia do Itaguá',
    description: 'Escuna clássica de madeira naval certificada, com amplo convés sombreado, bar de bordo, dois banheiros, escorregador aquático para banho nas paradas e bote motorizado de apoio para desembarque.',
    features: ['Amplo convés coberto e solário', 'Bar de bordo (porções e bebidas)', 'Bote de apoio motorizado para desembarque na areia', 'Guia credenciado a bordo'],
    structure: ['2 Banheiros (Masculino e Feminino)', 'Bancos anatômicos com encosto', 'Escadas laterais duplas para mergulho'],
    safetyEquipment: ['Balsas salva-vidas rígidas', '75 Coletes homologados pela Capitania dos Portos', 'Tripulação completa com Mestre Arrais e Marinheiros de Convés'],
    heroImage: IMG_ESCUNA,
    gallery: [IMG_ESCUNA, IMG_HERO],
    videoTitle: 'Navegação na Escuna Rainha de Anchieta pela Baía de Ubatuba',
    rating: 4.8
  },
  {
    id: 'ves-flexboat-nativa',
    slug: 'flexboat-expedicao-picinguaba-couves',
    name: 'Flexboat Nativa Eco 26 Pés (Apoio Costeiro & Ilhas)',
    partnerId: 'part-nativaeco',
    type: 'Catamarã / Flexboat',
    operationMode: 'Ambos',
    capacity: 14,
    lengthFeet: 26,
    engineSpec: 'Yamaha 200HP 4 Tempos Ecológico',
    baseLocation: 'Praia de Picinguaba & Sertão da Quina',
    description: 'Embarcação semirrígida de alta estabilidade homologada para travessias rápidas em Picinguaba, Ilha das Couves e resgate costeiro na Trilha das Sete Praias.',
    features: ['Casco semirrígido insubmersível', 'Escada de popa para mergulhadores', 'Toldo de proteção UV', 'Equipamento completo de flutuação'],
    structure: ['Bancos náuticos anti-impacto', 'Compartimento estanque para mochilas e câmeras', 'Caixa térmica 90L'],
    safetyEquipment: ['16 Coletes salva-vidas homologados Classe II', 'Rádio VHF Marítimo e GPS', 'Kit primeiros socorros de trilha e mar'],
    heroImage: IMG_CACHOEIRA,
    gallery: [IMG_CACHOEIRA, IMG_COUVES, IMG_HERO],
    videoTitle: 'Travessia Ecológica Picinguaba — Ilha das Couves no Flexboat Nativa',
    rating: 4.9
  }
];

const INITIAL_ITINERARIES: Itinerary[] = [
  {
    id: 'itin-ilhas-norte',
    slug: 'roteiro-ilhas-do-norte-couves-prumirim',
    title: 'Roteiro Ilhas do Norte: Couves, Prumirim e Porcos',
    region: 'Costa Norte',
    estimatedDuration: '5h30 a 6h30',
    navigationLevel: 'Costeira Moderada',
    description: 'O roteiro mais desejado pelas águas verde-esmeralda do norte de Ubatuba, combinando paradas de mergulho com snorkel na Ilha das Couves, Ilha do Prumirim, Ilha dos Porcos e passagem panorâmica pela Ilha da Selinha (menor praia do Brasil) e Ilha da Rapada.',
    destinationsIds: ['dest-ilha-couves', 'dest-ilha-prumirim', 'dest-ilha-porcos', 'dest-ilha-rapada', 'dest-almada'],
    stopsCount: 3,
    stopsDetails: [
      'Parada 1: Ilha das Couves (1h30 para mergulho com snorkel nas águas cristalinas)',
      'Parada 2: Ilha dos Porcos / Vista da Ilha da Selinha (1h para banho e fotos)',
      'Parada 3: Ilha do Prumirim ou Praia da Almada (1h30 para banho e almoço opcional)'
    ],
    confirmedVesselIds: ['ves-phantom-340', 'ves-escuna-corsario'],
    navigationNotes: 'Saídas confirmadas da Praia do Itaguá (check-in 09h00). O percurso e o tempo de permanência em cada ilha estão sujeitos às condições meteorológicas, vento e regras de turno da Ilha das Couves.',
    heroImage: IMG_COUVES,
    videoTitle: 'Mapa Animado e Imagens Aéreas do Roteiro Ilhas do Norte'
  },
  {
    id: 'itin-sul-anchieta',
    slug: 'roteiro-ilha-anchieta-sete-fontes',
    title: 'Roteiro Sul Clássico: Ilha Anchieta & Praia das Sete Fontes',
    region: 'Costa Sul & Ilha Anchieta',
    estimatedDuration: '5h00 a 6h00',
    navigationLevel: 'Águas Abrigadas (Calmo)',
    description: 'Navegação por águas abrigadas saindo do Saco da Ribeira rumo ao Parque Estadual da Ilha Anchieta (Praia do Presídio, Praia das Palmas e Aquário Natural na Praia do Engenho) e parada gastronômica na Praia das Sete Fontes.',
    destinationsIds: ['dest-ilha-anchieta', 'dest-sete-fontes', 'dest-domingas-dias'],
    stopsCount: 3,
    stopsDetails: [
      'Parada 1: Praia do Engenho / Aquário Natural na Ilha Anchieta (flutuação com peixes e tartarugas)',
      'Parada 2: Praia do Presídio ou Praia das Palmas na Ilha Anchieta (desembarque para conhecer as ruínas e trilhas curtas)',
      'Parada 3: Praia das Sete Fontes (parada para banho e almoço nos quiosques caiçaras)'
    ],
    confirmedVesselIds: ['ves-phantom-340', 'ves-focker-280', 'ves-escuna-corsario'],
    navigationNotes: 'Excelente opção para famílias e pessoas sensíveis ao balanço do mar, pois navega na baía abrigada do Saco da Ribeira e face norte da Ilha Anchieta. Taxa do Parque Estadual (R$ 14/pessoa) aplicável no desembarque na Ilha Anchieta.',
    heroImage: IMG_ESCUNA,
    videoTitle: 'Roteiro Ilha Anchieta e Sete Fontes: Navegação em Águas Abrigadas'
  },
  {
    id: 'itin-costa-sul-7-praias',
    slug: 'roteiro-sete-praias-bonete-cedro-sul',
    title: 'Roteiro Costa Sul Selvagem: Sete Praias, Bonete e Cedro do Sul',
    region: 'Sete Praias & Bonete',
    estimatedDuration: '5h00 a 6h00',
    navigationLevel: 'Águas Abrigadas (Calmo)',
    description: 'Explore pelo mar todas as enseadas desertas da Trilha das Sete Praias sem esforço físico: fundeio na Praia do Cedro do Sul, Praia do Deserto, Praia Grande do Bonete, Praia da Fortaleza e Domingas Dias.',
    destinationsIds: ['dest-cedro', 'dest-bonete', 'dest-fortaleza', 'dest-domingas-dias', 'dest-trilha-sete-praias'],
    stopsCount: 4,
    stopsDetails: [
      'Parada 1: Piscina Natural da Praia da Fortaleza (mergulho livre)',
      'Parada 2: Praia do Cedro do Sul & Praia do Deserto (águas verde-esmeralda)',
      'Parada 3: Praia Grande do Bonete (parada em vila caiçara)',
      'Parada 4: Enseada de Domingas Dias no retorno ao Saco da Ribeira'
    ],
    confirmedVesselIds: ['ves-focker-280', 'ves-phantom-340'],
    navigationNotes: 'Roteiro operado exclusivamente por lanchas homologadas pelos parceiros do Saco da Ribeira, sujeito à confirmação prévia do comandante conforme ondulação de sul.',
    heroImage: IMG_LANCHA,
    videoTitle: 'Roteiro Costa Sul: As 7 Praias Desertas Vistas de Lancha'
  }
];

const INITIAL_TOURS: Tour[] = [
  {
    id: 'tour-lancha-norte-comp',
    slug: 'passeio-lancha-ilha-das-couves-prumirim-porcos',
    title: 'Expedição Ilhas Norte de Lancha: Ilha das Couves, Prumirim e Porcos',
    vesselId: 'ves-phantom-340',
    partnerId: 'part-kaimares',
    category: 'Passeios de lancha',
    tourType: 'Compartilhado',
    vesselType: 'Lancha',
    pricingModel: 'POR_PESSOA',
    price: 240,
    capacity: 12,
    durationHours: 5.5,
    checkInTime: '09:00',
    departureTime: '09:30',
    returnTime: '15:00',
    departurePoint: 'Praia do Itaguá',
    itineraryId: 'itin-ilhas-norte',
    destinationsVisited: ['dest-ilha-couves', 'dest-ilha-prumirim', 'dest-ilha-porcos', 'dest-cedro'],
    swimmingStops: [
      { place: 'Ilha das Couves', duration: '1h30', description: 'Mergulho em águas cristalinas com máscaras de snorkel fornecidas a bordo.' },
      { place: 'Ilha dos Porcos & Passagem na Selinha', duration: '1h00', description: 'Banho em enseada tranquila e fotos na menor praia do Brasil.' },
      { place: 'Ilha do Prumirim', duration: '1h30', description: 'Parada na faixa de areia branca e águas calmas em frente à Serra do Mar.' }
    ],
    includedItems: [
      'Marinheiro habilitado pela Capitania dos Portos',
      'Combustível para todo o roteiro',
      'Máscara de mergulho (snorkel) e flutuadores (espaguetes)',
      'Cooler com gelo e água mineral a bordo',
      'Seguro obrigatório de passageiros'
    ],
    importantInfo: [
      'Embarque na Avenida Leovigildo Dias Vieira (Praia do Itaguá).',
      'Na Ilha das Couves não há quiosques comerciais; leve seu lanche e bebida (proibido garrafas de vidro e caixas de som).',
      'Solicitações de reserva passam pela confirmação final de disponibilidade e condições marítimas do parceiro.'
    ],
    cancellationPolicy: 'Reembolso integral ou remarcação sem custos em caso de interdição marítima/mau tempo determinado pela Marinha ou cancelamento com até 48h de antecedência.',
    status: 'APROVADO',
    featured: true,
    heroImage: IMG_COUVES,
    gallery: [IMG_COUVES, IMG_LANCHA, IMG_HERO],
    videoTitle: 'Passeio de Lancha para Ilha das Couves e Ilha do Prumirim',
    rating: 4.9,
    reviewsCount: 214,
    seoKeywords: ['Passeios de lancha em Ubatuba', 'Ilha das Couves lancha', 'Passeio de barco em Ubatuba']
  },
  {
    id: 'tour-lancha-privativa-sul',
    slug: 'lancha-privativa-ilha-anchieta-sete-praias',
    title: 'Charter Lancha Privativa (Até 9 Pessoas): Ilha Anchieta, Sete Fontes & Domingas Dias',
    vesselId: 'ves-focker-280',
    partnerId: 'part-rotadomar',
    category: 'Passeios privativos',
    tourType: 'Privativo',
    vesselType: 'Lancha',
    pricingModel: 'POR_EMBARCACAO',
    price: 1850,
    capacity: 9,
    durationHours: 6,
    checkInTime: '09:30',
    departureTime: '10:00',
    returnTime: '16:00',
    departurePoint: 'Saco da Ribeira',
    itineraryId: 'itin-sul-anchieta',
    destinationsVisited: ['dest-ilha-anchieta', 'dest-sete-fontes', 'dest-domingas-dias', 'dest-cedro', 'dest-bonete'],
    swimmingStops: [
      { place: 'Praia do Engenho (Aquário Natural da Ilha Anchieta)', duration: '1h30', description: 'Fundeio próximo às tartarugas marinhas e uso de Stand Up Paddle.' },
      { place: 'Praia das Palmas ou Presídio (Ilha Anchieta)', duration: '1h30', description: 'Tempo livre na faixa de areia e preparo de churrasco a bordo.' },
      { place: 'Praia das Sete Fontes e Domingas Dias', duration: '2h00', description: 'Parada para almoço caiçara ou banho em águas calmas.' }
    ],
    includedItems: [
      'Lancha exclusiva para o seu grupo (até 9 passageiros)',
      'Comandante particular e combustível incluso',
      'Churrasqueira inox pronta para uso (traga os itens de sua preferência)',
      '1 Prancha de Stand Up Paddle + Máscaras de Snorkel',
      'Som Bluetooth, ducha de água doce e cooler térmico'
    ],
    importantInfo: [
      'Saída de marina estruturada no Saco da Ribeira com estacionamento terceirizado ao lado.',
      'Horário flexível entre 09h00 e 17h00 mediante alinhamento com o parceiro.',
      'Caso deseje desembarcar na Praia do Presídio (Ilha Anchieta), há taxa ambiental de R$ 14/pessoa.'
    ],
    cancellationPolicy: 'Remarcação garantida em caso de chuva contínua ou vento forte. Cancelamento gratuito até 72h antes do embarque.',
    status: 'APROVADO',
    featured: true,
    heroImage: IMG_LANCHA,
    gallery: [IMG_LANCHA, IMG_HERO, IMG_COUVES],
    videoTitle: 'Dia Completo em Lancha Privativa pela Ilha Anchieta e Sete Fontes',
    rating: 5.0,
    reviewsCount: 168,
    seoKeywords: ['Aluguel de lancha em Ubatuba', 'Passeio privativo lancha Ubatuba', 'Lancha Saco da Ribeira']
  },
  {
    id: 'tour-escuna-anchieta',
    slug: 'passeio-escuna-ilha-anchieta-sete-fontes',
    title: 'Passeio Tradicional de Escuna: Ilha Anchieta & Praia das Sete Fontes',
    vesselId: 'ves-escuna-corsario',
    partnerId: 'part-escunascaicara',
    category: 'Passeios de escuna',
    tourType: 'Compartilhado',
    vesselType: 'Escuna',
    pricingModel: 'POR_PESSOA',
    price: 110,
    capacity: 65,
    durationHours: 5.5,
    checkInTime: '09:30',
    departureTime: '10:00',
    returnTime: '15:30',
    departurePoint: 'Saco da Ribeira',
    itineraryId: 'itin-sul-anchieta',
    destinationsVisited: ['dest-ilha-anchieta', 'dest-sete-fontes'],
    swimmingStops: [
      { place: 'Parque Estadual da Ilha Anchieta', duration: '2h00', description: 'Desembarque no píer da Praia do Presídio, caminhada leve até a Praia do Engenho (Aquário Natural) e visita histórica.' },
      { place: 'Praia das Sete Fontes', duration: '1h45', description: 'Desembarque com bote de apoio para almoço nos quiosques caiçaras e trilha opcional até a Gruta do Pirata.' }
    ],
    includedItems: [
      'Navegação em escuna homologada com guia a bordo',
      'Bote motorizado de apoio para desembarque seco na praia',
      'Flutuadores (espaguetes) para banho ao redor da escuna',
      'Seguro náutico individual'
    ],
    importantInfo: [
      'Ingresso do Parque Estadual da Ilha Anchieta (R$ 14,00 por pessoa) cobrado à parte pela administração do Parque.',
      'Excelente custo-benefício para famílias, casais e excursões.'
    ],
    cancellationPolicy: 'Cancelamento sem custos até 24h antes da saída ou reembolso integral em caso de cancelamento pela Capitania dos Portos.',
    status: 'APROVADO',
    featured: true,
    heroImage: IMG_ESCUNA,
    gallery: [IMG_ESCUNA, IMG_HERO],
    videoTitle: 'Passeio de Escuna para Ilha Anchieta e Praia das Sete Fontes',
    rating: 4.8,
    reviewsCount: 312,
    seoKeywords: ['Passeios de escuna em Ubatuba', 'Escuna Ilha Anchieta', 'Passeios de barco em Ubatuba']
  },
  {
    id: 'tour-familia-prumirim',
    slug: 'passeio-familia-trio-prumirim-felix-portugues',
    title: 'Experiência Família: Ilha do Prumirim, Praia do Félix & Praia do Português',
    vesselId: 'ves-phantom-340',
    partnerId: 'part-kaimares',
    category: 'Passeios para famílias',
    tourType: 'Privativo',
    vesselType: 'Lancha',
    pricingModel: 'POR_EMBARCACAO',
    price: 2100,
    capacity: 12,
    durationHours: 6,
    checkInTime: '09:00',
    departureTime: '09:30',
    returnTime: '15:30',
    departurePoint: 'Praia do Itaguá',
    itineraryId: 'itin-ilhas-norte',
    destinationsVisited: ['dest-prumirim', 'dest-ilha-prumirim', 'dest-felix', 'dest-portugues', 'dest-cedro'],
    swimmingStops: [
      { place: 'Praia do Cedro (Cedrinho)', duration: '1h15', description: 'Primeira parada em águas calmas e cristalinas logo na saída da baía.' },
      { place: 'Canto Direito da Praia do Félix & Praia do Português', duration: '1h45', description: 'Mar estilo piscina, perfeito para crianças e idosos.' },
      { place: 'Ilha do Prumirim & Foz do Rio Prumirim', duration: '2h00', description: 'Banho de mar e água doce com estrutura de quiosques na Praia do Prumirim.' }
    ],
    includedItems: [
      'Lancha privativa de 34 pés para até 12 pessoas da mesma família',
      'Coletes infantis homologados de diversos tamanhos',
      'Tapete flutuante náutico gigante para crianças',
      'Marinheiro experiente, combustível, gelo e água mineral'
    ],
    importantInfo: [
      'Roteiro desenhado especificamente para priorizar enseadas abrigadas e com apoio de quiosques.',
      'Confirmação direta pelo parceiro após envio da solicitação.'
    ],
    cancellationPolicy: 'Flexibilidade total de reagendamento em caso de tempo instável ou cancelamento gratuito até 48h antes.',
    status: 'APROVADO',
    featured: false,
    heroImage: IMG_HERO,
    gallery: [IMG_HERO, IMG_COUVES, IMG_LANCHA],
    videoTitle: 'Roteiro Família em Águas Calmas: Prumirim, Félix e Cedro',
    rating: 5.0,
    reviewsCount: 94,
    seoKeywords: ['Passeio de barco para família Ubatuba', 'Praias calmas para crianças Ubatuba']
  }
];

const INITIAL_MEDIA_ASSETS: MediaAsset[] = [
  {
    id: 'med-1',
    title: 'Vista Aérea Baía de Ubatuba — Lancha e Escuna',
    type: 'photo',
    url: IMG_HERO,
    category: 'Destino',
    linkedEntityId: 'dest-cedro',
    linkedEntityName: 'Baía de Ubatuba & Praia do Cedro',
    partnerId: 'PLATFORM',
    partnerName: 'Acervo Oficial Plataforma (Substituível)',
    authorized: true,
    isProvisional: true,
    createdAt: '2026-10-15'
  },
  {
    id: 'med-2',
    title: 'Águas Cristalinas da Ilha das Couves',
    type: 'photo',
    url: IMG_COUVES,
    category: 'Destino',
    linkedEntityId: 'dest-ilha-couves',
    linkedEntityName: 'Ilha das Couves',
    partnerId: 'part-kaimares',
    partnerName: 'Kaimares Náutica & Charter',
    authorized: true,
    isProvisional: true,
    createdAt: '2026-10-18'
  },
  {
    id: 'med-3',
    title: 'Lancha Oceano Azul 340 em Navegação',
    type: 'video',
    url: IMG_LANCHA,
    videoPreviewDuration: '02:15',
    category: 'Embarcação',
    linkedEntityId: 'ves-phantom-340',
    linkedEntityName: 'Lancha Oceano Azul 340',
    partnerId: 'part-kaimares',
    partnerName: 'Kaimares Náutica & Charter',
    authorized: true,
    isProvisional: true,
    createdAt: '2026-10-20'
  },
  {
    id: 'med-4',
    title: 'Escuna Rainha de Anchieta — Enseada das Palmas',
    type: 'video',
    url: IMG_ESCUNA,
    videoPreviewDuration: '03:10',
    category: 'Embarcação',
    linkedEntityId: 'ves-escuna-corsario',
    linkedEntityName: 'Escuna Rainha de Anchieta',
    partnerId: 'part-escunascaicara',
    partnerName: 'Escunas Tradicionais Caiçara',
    authorized: true,
    isProvisional: true,
    createdAt: '2026-10-22'
  },
  {
    id: 'med-5',
    title: 'Poço Esmeralda da Cachoeira do Prumirim',
    type: 'photo',
    url: IMG_CACHOEIRA,
    category: 'Destino',
    linkedEntityId: 'dest-cachoeira-prumirim',
    linkedEntityName: 'Cachoeira do Prumirim',
    partnerId: 'PLATFORM',
    partnerName: 'Acervo Oficial Plataforma (Substituível)',
    authorized: true,
    isProvisional: true,
    createdAt: '2026-10-25'
  }
];

const INITIAL_BOOKINGS: BookingRequest[] = [
  {
    id: 'bk-101',
    code: 'UBT-8492',
    tourId: 'tour-lancha-norte-comp',
    tourTitle: 'Expedição Ilhas Norte de Lancha: Ilha das Couves, Prumirim e Porcos',
    vesselId: 'ves-phantom-340',
    vesselName: 'Lancha Oceano Azul 340 (34 Pés)',
    partnerId: 'part-kaimares',
    partnerName: 'Kaimares Náutica & Charter',
    customerName: 'Mariana Vasconcelos',
    customerPhone: '(11) 99812-4401',
    customerEmail: 'mariana.v@email.com.br',
    date: '2026-11-02',
    passengers: 4,
    channel: 'SITE_DIRECT',
    utmSource: 'instagram_ads',
    utmCampaign: 'verao_ilha_das_couves_2026',
    status: 'PASSEIO_REALIZADO',
    ledgerStatus: 'CONFIRMADA',
    grossAmount: 960,
    commissionRuleUsed: 'Percentual Padrão Parceiro (15%)',
    commissionAmount: 144,
    netPartnerAmount: 816,
    commissionConsolidated: true,
    createdAt: '2026-10-29 14:22'
  },
  {
    id: 'bk-102',
    code: 'UBT-9104',
    tourId: 'tour-lancha-privativa-sul',
    tourTitle: 'Charter Lancha Privativa (Até 9 Pessoas): Ilha Anchieta, Sete Fontes & Domingas Dias',
    vesselId: 'ves-focker-280',
    vesselName: 'Lancha Brisa do Norte 280 (28 Pés)',
    partnerId: 'part-rotadomar',
    partnerName: 'Rota do Mar Lanchas',
    customerName: 'Ricardo Albuquerque',
    customerPhone: '(12) 99741-8890',
    customerEmail: 'ricardo.alb@empresa.com.br',
    date: '2026-11-05',
    passengers: 8,
    channel: 'WHATSAPP',
    utmSource: 'google_search',
    utmCampaign: 'aluguel_lancha_ubatuba',
    status: 'PASSEIO_REALIZADO',
    ledgerStatus: 'CONFIRMADA',
    grossAmount: 1850,
    commissionRuleUsed: 'Regra Personalizada (12% + Taxa R$ 150)',
    commissionAmount: 372,
    netPartnerAmount: 1478,
    commissionConsolidated: true,
    createdAt: '2026-11-01 09:40'
  },
  {
    id: 'bk-103',
    code: 'UBT-9350',
    tourId: 'tour-escuna-anchieta',
    tourTitle: 'Passeio Tradicional de Escuna: Ilha Anchieta & Praia das Sete Fontes',
    vesselId: 'ves-escuna-corsario',
    vesselName: 'Escuna Tradicional Rainha de Anchieta',
    partnerId: 'part-escunascaicara',
    partnerName: 'Escunas Tradicionais Caiçara',
    customerName: 'Fernanda & Família Oliveira',
    customerPhone: '(19) 99123-7765',
    customerEmail: 'fe.oliveira@email.com',
    date: '2026-11-14',
    passengers: 5,
    channel: 'SITE_DIRECT',
    utmSource: 'facebook_ads',
    utmCampaign: 'familia_ilha_anchieta',
    status: 'AGUARDANDO_CONFIRMACAO',
    ledgerStatus: 'PREVISTA',
    grossAmount: 550,
    commissionRuleUsed: 'Comissão Fixa por Passageiro (R$ 25/pax)',
    commissionAmount: 125,
    netPartnerAmount: 425,
    commissionConsolidated: false,
    createdAt: '2026-11-06 18:15',
    notes: 'Solicitação enviada pelo site; aguardando confirmação de vagas pela operadora da escuna.'
  }
];

const INITIAL_REVIEWS: ReviewItem[] = [
  {
    id: 'rev-1',
    tourId: 'tour-lancha-norte-comp',
    tourTitle: 'Expedição Ilhas Norte de Lancha: Ilha das Couves, Prumirim e Porcos',
    partnerId: 'part-kaimares',
    author: 'Mariana Vasconcelos',
    city: 'São Paulo, SP',
    rating: 5,
    date: '03 Nov 2026',
    comment: 'Água absurdamente cristalina na Ilha das Couves e na Ilha do Prumirim! O marinheiro da Kaimares foi super atencioso, forneceu máscaras de mergulho novas e respeitou todas as normas de segurança.',
    verifiedBookingCode: 'UBT-8492'
  },
  {
    id: 'rev-2',
    tourId: 'tour-lancha-privativa-sul',
    tourTitle: 'Charter Lancha Privativa (Até 9 Pessoas): Ilha Anchieta, Sete Fontes & Domingas Dias',
    partnerId: 'part-rotadomar',
    author: 'Ricardo Albuquerque',
    city: 'São José dos Campos, SP',
    rating: 5,
    date: '06 Nov 2026',
    comment: 'Fechamos a lancha Brisa do Norte para 8 pessoas saindo do Saco da Ribeira. Vimos tartarugas no Aquário Natural da Ilha Anchieta e fizemos churrasco na enseada de Domingas Dias. Plataforma nota 10!',
    verifiedBookingCode: 'UBT-9104'
  },
  {
    id: 'rev-3',
    tourId: 'tour-escuna-anchieta',
    tourTitle: 'Passeio Tradicional de Escuna: Ilha Anchieta & Praia das Sete Fontes',
    partnerId: 'part-escunascaicara',
    author: 'Carlos Eduardo Mendes',
    city: 'Campinas, SP',
    rating: 5,
    date: '28 Out 2026',
    comment: 'Ótimo passeio para ir com crianças e avós. O bote de apoio deixa direto na areia das Sete Fontes e o guia explica toda a história das ruínas da Ilha Anchieta.',
    verifiedBookingCode: 'UBT-7921'
  }
];

// ============================================================================
// FUNÇÃO DE CÁLCULO BACKEND DE COMISSÃO (IDEMPOTENTE)
// ============================================================================

function roundCurrency(value: number): number {
  return roundCurrencyExact(value);
}

function calculateCommissionBackend(
  tour: Tour,
  partner: Partner,
  passengers: number
): { gross: number; commission: number; net: number; ruleLabel: string } {
  const res = calculateServerCommissionAndNet({
    tour,
    partner,
    passengers,
  });
  return {
    gross: res.grossAmount,
    commission: res.commissionAmount,
    net: res.netPartnerAmount,
    ruleLabel: res.ruleSnapshot.commissionRuleLabel,
  };
}

const STORAGE_PREFIX = 'ubatuba_mp_v2_';

function loadPersisted<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(STORAGE_PREFIX + key);
    if (!raw) return fallback;
    return JSON.parse(raw) ?? fallback;
  } catch {
    return fallback;
  }
}

function savePersisted<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch {
    // Safe fallback inside restricted iframes
  }
}

const INITIAL_AVAILABILITY_BLOCKS: AvailabilityBlock[] = [
  {
    id: 'blk-1',
    partnerId: 'part-kaimares',
    vesselId: 'ves-phantom-340',
    vesselName: 'Lancha Oceano Azul 340 (34 Pés)',
    blockDate: '2026-11-25',
    blockType: 'MANUTENCAO',
    reason: 'Revisão preventiva programada dos motores Mercury 250HP'
  }
];

const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-1',
    timestamp: '08/11/2026 08:30',
    actor: 'Sistema / Seed Inicial',
    role: 'admin',
    action: 'INIT_LEDGER',
    target: 'UBT-8492 & UBT-9104',
    details: 'Consolidação inicial de 2 passeios realizados (GMV R$ 2.810,00 | Comissões R$ 516,00)'
  }
];

// ============================================================================
// COMPONENTE PRINCIPAL DO MARKETPLACE
// ============================================================================

export default function App() {
  // Navegação principal e estado de visualização detalhada
  const [activeTab, setActiveTab] = useState<
    'home' | 'guide' | 'tours' | 'vessels' | 'itineraries' | 'gallery' | 'partner-portal' | 'admin-portal' | 'architecture-seo'
  >('home');

  const [roleMode, setRoleMode] = useState<RoleMode>('tourist');
  const [activePartnerId, setActivePartnerId] = useState<string>('part-kaimares');

  // Estados de Páginas Individuais (Modais/Views dedicadas)
  const [selectedDestinationId, setSelectedDestinationId] = useState<string | null>(null);
  const [selectedTourId, setSelectedTourId] = useState<string | null>(null);
  const [selectedVesselId, setSelectedVesselId] = useState<string | null>(null);
  const [lightboxMedia, setLightboxMedia] = useState<{
    title: string;
    url: string;
    type: 'photo' | 'video';
    subtitle?: string;
    galleryList?: { title: string; url: string; type: 'photo' | 'video'; subtitle?: string }[];
    currentIndex?: number;
  } | null>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(true);
  const [videoProgress, setVideoProgress] = useState<number>(35);

  // Modal de Consulta Segura de Reservas pelo Turista (Missão 02.16 — Seções 7 e 8)
  const currentBrazilDate = useMemo(() => getBrazilCurrentDateIso(), []);
  const [touristTrackerOpen, setTouristTrackerOpen] = useState<boolean>(false);
  const [trackerSearchCode, setTrackerSearchCode] = useState<string>('');
  const [savedTouristReceipts, setSavedTouristReceipts] = useState<TouristSavedReceipt[]>(() =>
    loadTouristSavedReceipts()
  );
  const [lookupCodeInput, setLookupCodeInput] = useState<string>('');
  const [lookupTokenInput, setLookupTokenInput] = useState<string>('');
  const [lookupLoading, setLookupLoading] = useState<boolean>(false);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [verifiedTouristBookings, setVerifiedTouristBookings] = useState<
    Record<string, TouristBookingLookupResponse>
  >({});
  const [cancellingBookingCode, setCancellingBookingCode] = useState<string | null>(null);
  const localLookupAttemptsRef = useRef<
    Record<string, { fails: number; windowStart: number; lockedUntil: number }>
  >({});
  const [reviewBookingId, setReviewBookingId] = useState<string | null>(null);
  const [newReviewAuthor, setNewReviewAuthor] = useState<string>('');
  const [newReviewCity, setNewReviewCity] = useState<string>('São Paulo, SP');
  const [newReviewRating, setNewReviewRating] = useState<number>(5);
  const [newReviewComment, setNewReviewComment] = useState<string>('');

  // Estados de Sessão Autenticada e Hidratação Remota (M01.7-007)
  // Quando isSupabaseConfigured === true, os dados são carregados do servidor sob RLS e a sessão Auth governa o perfil;
  // o modo de demonstração local (INITIAL_* / localStorage) opera exclusivamente quando !isSupabaseConfigured.
  const [remoteLoading, setRemoteLoading] = useState<boolean>(isSupabaseConfigured);
  const [remoteSyncError, setRemoteSyncError] = useState<string | null>(null);
  const [authenticatedUserId, setAuthenticatedUserId] = useState<string | null>(null);
  const [authenticatedEmail, setAuthenticatedEmail] = useState<string | null>(null);
  const [serverVerifiedRole, setServerVerifiedRole] = useState<RoleMode>('tourist');
  const [authorizedPartnerIds, setAuthorizedPartnerIds] = useState<string[]>([]);

  const canUseDemoData =
    runtimeGuard.isDemoModeAllowed &&
    !isSupabaseConfigured &&
    !runtimeGuard.isConfigurationUnavailable;

  const [partners, setPartners] = useState<Partner[]>(() =>
    canUseDemoData ? loadPersisted('partners', INITIAL_PARTNERS) : []
  );
  const [destinations, setDestinations] = useState<Destination[]>(() =>
    canUseDemoData ? loadPersisted('destinations', INITIAL_DESTINATIONS) : []
  );
  const [vessels, setVessels] = useState<Vessel[]>(() =>
    canUseDemoData ? loadPersisted('vessels', INITIAL_VESSELS) : []
  );
  const [tours, setTours] = useState<Tour[]>(() =>
    canUseDemoData ? loadPersisted('tours', INITIAL_TOURS) : []
  );
  const [itineraries] = useState<Itinerary[]>(() =>
    canUseDemoData ? INITIAL_ITINERARIES : []
  );
  const [mediaAssets, setMediaAssets] = useState<MediaAsset[]>(() =>
    canUseDemoData ? loadPersisted('mediaAssets', INITIAL_MEDIA_ASSETS) : []
  );
  const [bookings, setBookings] = useState<BookingRequest[]>(() =>
    canUseDemoData
      ? loadPersisted('bookings', INITIAL_BOOKINGS).map((bk) => {
          const normalizedStatus = normalizeBookingStatus(bk.status);
          return {
            ...bk,
            status: normalizedStatus,
            lookupToken: bk.lookupToken || deriveLocalDemoLookupToken(bk.id, bk.code),
            ledgerStatus: bk.ledgerStatus || deriveLedgerStatusFromBookingStatus(normalizedStatus),
            commissionConsolidated: normalizedStatus === 'PASSEIO_REALIZADO'
          };
        })
      : []
  );
  const bookingSubmissionLockRef = useRef<boolean>(false);
  const [reviews, setReviews] = useState<ReviewItem[]>(() =>
    canUseDemoData ? loadPersisted('reviews', INITIAL_REVIEWS) : []
  );
  const [availabilityBlocks, setAvailabilityBlocks] = useState<AvailabilityBlock[]>(() =>
    canUseDemoData ? loadPersisted('availabilityBlocks', INITIAL_AVAILABILITY_BLOCKS) : []
  );
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() =>
    canUseDemoData ? loadPersisted('auditLogs', INITIAL_AUDIT_LOGS) : []
  );
  const [changeHistory, setChangeHistory] = useState<OperationalHistoryEntry[]>(() =>
    canUseDemoData ? loadPersisted('changeHistory', []) : []
  );
  const [financialStore, setFinancialStore] = useState<FinancialStoreSnapshot>(() =>
    canUseDemoData
      ? loadPersisted('financialStore', seedInitialDemoFinancialStore(INITIAL_BOOKINGS))
      : createEmptyFinancialStore()
  );

  // Persiste em localStorage SOMENTE em desenvolvimento quando demo está explicitamente autorizado
  useEffect(() => { if (canUseDemoData) savePersisted('partners', partners); }, [canUseDemoData, partners]);
  useEffect(() => { if (canUseDemoData) savePersisted('destinations', destinations); }, [canUseDemoData, destinations]);
  useEffect(() => { if (canUseDemoData) savePersisted('vessels', vessels); }, [canUseDemoData, vessels]);
  useEffect(() => { if (canUseDemoData) savePersisted('tours', tours); }, [canUseDemoData, tours]);
  useEffect(() => { if (canUseDemoData) savePersisted('mediaAssets', mediaAssets); }, [canUseDemoData, mediaAssets]);
  useEffect(() => { if (canUseDemoData) savePersisted('bookings', bookings); }, [canUseDemoData, bookings]);
  useEffect(() => { if (canUseDemoData) savePersisted('reviews', reviews); }, [canUseDemoData, reviews]);
  useEffect(() => { if (canUseDemoData) savePersisted('availabilityBlocks', availabilityBlocks); }, [canUseDemoData, availabilityBlocks]);
  useEffect(() => { if (canUseDemoData) savePersisted('auditLogs', auditLogs); }, [canUseDemoData, auditLogs]);
  useEffect(() => { if (canUseDemoData) savePersisted('changeHistory', changeHistory); }, [canUseDemoData, changeHistory]);
  useEffect(() => { if (canUseDemoData) savePersisted('financialStore', financialStore); }, [canUseDemoData, financialStore]);

  // Hidratação remota autorizada e sincronização de sessão com supabase.auth.getSession() + onAuthStateChange (M01.7-007)
  useEffect(() => {
    if (!isSupabaseConfigured || !supabase || runtimeGuard.isConfigurationUnavailable) return;
    let isMounted = true;

    const clearPrivateSessionState = () => {
      setAuthenticatedUserId(null);
      setAuthenticatedEmail(null);
      setServerVerifiedRole('tourist');
      setAuthorizedPartnerIds([]);
      setActivePartnerId('');
      setRoleMode('tourist');
      setBookings([]);
      setAuditLogs([]);
      setActiveTab((prev) => (prev === 'partner-portal' || prev === 'admin-portal' ? 'home' : prev));
    };

    const hydrateFromServer = async () => {
      setRemoteLoading(true);
      setRemoteSyncError(null);

      const sessionCtx = await resolveAuthenticatedSessionContext();
      if (!isMounted) return;

      if (sessionCtx.error) {
        clearPrivateSessionState();
        setPartners([]);
        setDestinations([]);
        setVessels([]);
        setTours([]);
        setAvailabilityBlocks([]);
        setReviews([]);
        setRemoteSyncError(sessionCtx.error);
        setRemoteLoading(false);
        return;
      }

      if (!sessionCtx.userId || !sessionCtx.isActiveProfile) {
        setAuthenticatedUserId(sessionCtx.userId);
        setAuthenticatedEmail(sessionCtx.email);
        setServerVerifiedRole('tourist');
        setAuthorizedPartnerIds([]);
        setActivePartnerId('');
        setRoleMode('tourist');
        setBookings([]);
        setAuditLogs([]);
        setActiveTab((prev) => (prev === 'partner-portal' || prev === 'admin-portal' ? 'home' : prev));
      } else {
        setAuthenticatedUserId(sessionCtx.userId);
        setAuthenticatedEmail(sessionCtx.email);
        setServerVerifiedRole(sessionCtx.effectiveRole);
        setAuthorizedPartnerIds(sessionCtx.authorizedPartnerIds);
        setRoleMode(sessionCtx.effectiveRole);
        if (sessionCtx.authorizedPartnerIds.length > 0) {
          setActivePartnerId((prev) =>
            sessionCtx.authorizedPartnerIds.includes(prev) ? prev : sessionCtx.authorizedPartnerIds[0]
          );
        } else {
          setActivePartnerId('');
        }
      }

      const snapshot = await fetchAuthorizedCatalogAndBookings(sessionCtx);
      if (!isMounted) return;

      const hydrated = hydrateCatalogAndBookingsSnapshot(snapshot, {
        initialPartners: INITIAL_PARTNERS,
        initialDestinations: INITIAL_DESTINATIONS,
        initialVessels: INITIAL_VESSELS,
        initialTours: INITIAL_TOURS,
        normalizeBookingStatus,
        deriveLedgerStatusFromBookingStatus,
      });

      if (hydrated.hasError) {
        setRemoteSyncError(hydrated.error);
        setPartners([]);
        setDestinations([]);
        setVessels([]);
        setTours([]);
        setAvailabilityBlocks([]);
        setReviews([]);
        setBookings([]);
        setAuditLogs([]);
        setRemoteLoading(false);
        return;
      }

      setPartners(hydrated.partners);
      setDestinations(hydrated.destinations);
      setVessels(hydrated.vessels);
      setTours(hydrated.tours);
      setAvailabilityBlocks(hydrated.availabilityBlocks);
      setReviews(hydrated.reviews);
      setBookings(hydrated.bookings);
      setAuditLogs(hydrated.auditLogs);
      setFinancialStore(
        hydrateFinancialStoreFromServerRows({
          paymentRows: hydrated.bookingPaymentsRows,
          paymentHistoryRows: hydrated.bookingPaymentHistoryRows,
          financialLedgerRows: hydrated.financialLedgerEntriesRows,
          bookings: hydrated.bookings,
        })
      );
      if (sessionCtx.effectiveRole === 'admin' || sessionCtx.effectiveRole === 'partner') {
        const scopePartnerId =
          sessionCtx.effectiveRole === 'partner'
            ? sessionCtx.authorizedPartnerIds[0] || null
            : null;
        const reconRes = await rpcGetFinancialReconciliationReport(scopePartnerId);
        if (reconRes.executedOnServer && reconRes.error && isMounted) {
          setRemoteSyncError(reconRes.error);
        }
      }

      setRemoteLoading(false);
    };

    hydrateFromServer();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;
      if (event === 'SIGNED_OUT' || !session?.user?.id) {
        clearPrivateSessionState();
        hydrateFromServer();
        return;
      }
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
        // Ao trocar de usuário, limpa imediatamente dados privados anteriores antes de recarregar
        setBookings([]);
        setAuditLogs([]);
        hydrateFromServer();
      }
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!lightboxMedia || lightboxMedia.type !== 'video' || !isVideoPlaying) return;
    const timer = setInterval(() => {
      setVideoProgress((prev) => (prev >= 100 ? 0 : prev + 2));
    }, 500);
    return () => clearInterval(timer);
  }, [lightboxMedia, isVideoPlaying]);

  const appendAuditLog = (action: string, target: string, details: string, actorOverride?: string) => {
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleString('pt-BR'),
      actor: actorOverride || (roleMode === 'admin' ? 'Admin Master' : roleMode === 'partner' ? activePartner.name : 'Turista'),
      role: roleMode,
      action,
      target,
      details
    };
    setAuditLogs((prev) => [entry, ...prev.slice(0, 99)]);
  };

  // Navegação segura que SEMPRE limpa views de detalhe (Corrige BUG-03) e impede escalada via roleMode em modo conectado (M01.7-007)
  const navigateToTab = (
    tab: 'home' | 'guide' | 'tours' | 'vessels' | 'itineraries' | 'gallery' | 'partner-portal' | 'admin-portal' | 'architecture-seo',
    newRole?: RoleMode
  ) => {
    setSelectedDestinationId(null);
    setSelectedTourId(null);
    setSelectedVesselId(null);

    if (isSupabaseConfigured || verifiedSession.isAuthenticated) {
      const targetProtectedRoute: ProtectedRouteKey =
        tab === 'admin-portal'
          ? 'admin-portal'
          : tab === 'partner-portal'
          ? 'partner-portal'
          : 'public-marketplace';

      if (targetProtectedRoute !== 'public-marketplace') {
        const decision = evaluateRouteProtection(targetProtectedRoute, verifiedSession, activePartnerId);
        if (!decision.allowed) {
          if (decision.redirectTo === 'partner-onboarding') {
            setAuthViewMode('onboarding');
            setAuthModalOpen(true);
            setAuthFeedback({
              type: 'info',
              message: decision.message || 'Acompanhe o status do seu onboarding de parceiro.',
            });
          } else if (decision.redirectTo === 'auth-login') {
            setAuthViewMode('login');
            setAuthModalOpen(true);
            setAuthFeedback({
              type: 'error',
              message: decision.message || 'Faça login para acessar esta área restrita.',
            });
          }
          setActiveTab('home');
          return;
        }
      }

      if (isSupabaseConfigured) {
        if (tab === 'admin-portal' || newRole === 'admin') {
          if (serverVerifiedRole !== 'admin') {
            setRoleMode(serverVerifiedRole);
            setActiveTab('home');
            return;
          }
        }
        if (tab === 'partner-portal' || newRole === 'partner') {
          if (serverVerifiedRole !== 'partner' && serverVerifiedRole !== 'admin') {
            setRoleMode(serverVerifiedRole);
            setActiveTab('home');
            return;
          }
        }
        setRoleMode(newRole && (newRole === 'tourist' || newRole === serverVerifiedRole || serverVerifiedRole === 'admin') ? newRole : serverVerifiedRole);
        setActiveTab(tab);
        return;
      }
    }

    if (newRole) setRoleMode(newRole);
    setActiveTab(tab);
  };

  // Toast / Notificação in-page
  const [toast, setToast] = useState<{ title: string; message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setToast({ title, message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.title === title ? null : prev));
    }, 5500);
  };

  // Busca da Hero e Filtros do Guia Turístico
  const [heroSearchQuery, setHeroSearchQuery] = useState('');
  const [heroSearchScope, setHeroSearchScope] = useState<
    'ALL' | 'Passeios de lancha' | 'Passeios de escuna' | 'Praias' | 'Ilhas' | 'Cachoeiras' | 'Experiências turísticas'
  >('ALL');
  const [heroRegionSelect, setHeroRegionSelect] = useState<string>('ALL');

  const [guideCategoryFilter, setGuideCategoryFilter] = useState<'TODAS' | DestinationCategory>('TODAS');
  const [guideRegionFilter, setGuideRegionFilter] = useState<'TODAS' | 'Norte' | 'Centro' | 'Sul' | 'Sertão / Serra do Mar'>('TODAS');
  const [guideSearch, setGuideSearch] = useState('');

  // Filtros e Ordenação do Marketplace de Passeios
  const [tourCategoryFilter, setTourCategoryFilter] = useState<string>('TODAS');
  const [tourVesselTypeFilter, setTourVesselTypeFilter] = useState<'TODOS' | VesselType>('TODOS');
  const [tourTypeFilter, setTourTypeFilter] = useState<'TODOS' | 'Privativo' | 'Compartilhado'>('TODOS');
  const [tourMaxPrice, setTourMaxPrice] = useState<number>(2500);
  const [tourMinCapacity, setTourMinCapacity] = useState<number>(1);
  const [tourDestinationFilter, setTourDestinationFilter] = useState<string>('TODOS');
  const [tourDateFilter, setTourDateFilter] = useState<string>('');
  const [tourSearch, setTourSearch] = useState<string>('');
  const [tourSortBy, setTourSortBy] = useState<'DESTAQUES' | 'MENOR_PRECO' | 'MAIOR_PRECO' | 'AVALIACAO' | 'CAPACIDADE'>('DESTAQUES');

  // Comparador de Roteiros
  const [compareItineraryIds, setCompareItineraryIds] = useState<string[]>(['itin-ilhas-norte', 'itin-sul-anchieta']);

  // Filtro da Galeria Dinâmica
  const [galleryCategoryFilter, setGalleryCategoryFilter] = useState<'TODOS' | 'Destino' | 'Embarcação' | 'Passeio' | 'Experiência'>('TODOS');
  const [galleryPartnerFilter, setGalleryPartnerFilter] = useState<string>('TODOS');

  // Modal de Reserva Híbrida (Opção 1 WhatsApp / Opção 2 Site) com Datas Dinâmicas (Missão 02.16)
  const [bookingModalTour, setBookingModalTour] = useState<Tour | null>(null);
  const [bookingChannel, setBookingChannel] = useState<'WHATSAPP' | 'SITE_DIRECT'>('WHATSAPP');
  const [bookingDate, setBookingDate] = useState<string>(() => getBrazilFutureDateIso(3));
  const [bookingPassengers, setBookingPassengers] = useState<number>(4);
  const [bookingName, setBookingName] = useState<string>('');
  const [bookingPhone, setBookingPhone] = useState<string>('');
  const [bookingEmail, setBookingEmail] = useState<string>('');
  const [bookingUtmSource, setBookingUtmSource] = useState<string>('instagram_ads');
  const [lastCreatedBooking, setLastCreatedBooking] = useState<BookingRequest | null>(null);
  const [isSubmittingBooking, setIsSubmittingBooking] = useState<boolean>(false);
  const [liveModalAvailability, setLiveModalAvailability] = useState<GetTourAvailabilityResponse | null>(null);
  const [loadingModalAvailability, setLoadingModalAvailability] = useState<boolean>(false);

  // Formulários de Cadastro no Painel do Parceiro e Admin
  const [newTourTitle, setNewTourTitle] = useState('');
  const [newTourPrice, setNewTourPrice] = useState(280);
  const [newTourType, setNewTourType] = useState<'Privativo' | 'Compartilhado'>('Compartilhado');
  const [newTourDeparture, setNewTourDeparture] = useState<'Saco da Ribeira' | 'Praia do Itaguá' | 'Praia de Picinguaba' | 'Praia da Enseada'>('Praia do Itaguá');
  const [newTourVesselId, setNewTourVesselId] = useState<string>('');
  const [newTourDestinationId, setNewTourDestinationId] = useState<string>('dest-ilha-couves');

  // Formulário de Nova Embarcação do Parceiro
  const [newVesselName, setNewVesselName] = useState('');
  const [newVesselType, setNewVesselType] = useState<'Lancha' | 'Escuna' | 'Catamarã / Flexboat'>('Lancha');
  const [newVesselCapacity, setNewVesselCapacity] = useState<number>(10);
  const [newVesselFeet, setNewVesselFeet] = useState<number>(30);
  const [newVesselEngine, setNewVesselEngine] = useState<string>('Mercury 250HP 4T');

  // Formulário de Bloqueio de Agenda do Parceiro
  const [blockVesselId, setBlockVesselId] = useState<string>('');
  const [blockDateInput, setBlockDateInput] = useState<string>(() => getBrazilFutureDateIso(7));
  const [blockTypeInput, setBlockTypeInput] = useState<AvailabilityBlockType>('MANUTENCAO');
  const [blockReasonInput, setBlockReasonInput] = useState<string>('');

  // Formulários e Estados Operacionais (Missão 02.18 — Seções 3.1 a 3.6)
  const [adminModuleTab, setAdminModuleTab] = useState<
    'overview' | 'partners' | 'tours' | 'vessels' | 'bookings' | 'departures' | 'financial'
  >('overview');
  const [partnerModuleTab, setPartnerModuleTab] = useState<
    'bookings' | 'tours' | 'vessels' | 'departures' | 'financial' | 'profile'
  >('bookings');

  // Gestão de Parceiros (3.2)
  const [newPartnerName, setNewPartnerName] = useState('');
  const [newPartnerLegalName, setNewPartnerLegalName] = useState('');
  const [newPartnerCnpj, setNewPartnerCnpj] = useState('');
  const [newPartnerWhatsapp, setNewPartnerWhatsapp] = useState('5512997001122');
  const [newPartnerEmail, setNewPartnerEmail] = useState('');
  const [newPartnerMarina, setNewPartnerMarina] = useState('Saco da Ribeira');
  const [newPartnerBio, setNewPartnerBio] = useState('');
  const [partnerSearchQuery, setPartnerSearchQuery] = useState('');
  const [partnerStatusFilter, setPartnerStatusFilter] = useState<
    'TODOS' | 'APROVADO' | 'PENDENTE' | 'SUSPENSO' | 'INATIVO' | 'COM_PENDENCIAS'
  >('TODOS');
  const [inspectingPartnerId, setInspectingPartnerId] = useState<string | null>(null);
  const [editingPartnerId, setEditingPartnerId] = useState<string | null>(null);
  const [editPartnerPhone, setEditPartnerPhone] = useState('');
  const [editPartnerEmail, setEditPartnerEmail] = useState('');
  const [editPartnerMarina, setEditPartnerMarina] = useState('');
  const [editPartnerBio, setEditPartnerBio] = useState('');

  // Gestão de Passeios (3.3)
  const [newTourDurationHours, setNewTourDurationHours] = useState<number>(5.5);
  const [newTourCheckInTime, setNewTourCheckInTime] = useState<string>('09:00');
  const [newTourDepartureTime, setNewTourDepartureTime] = useState<string>('09:30');
  const [newTourReturnTime, setNewTourReturnTime] = useState<string>('15:00');
  const [newTourCapacityInput, setNewTourCapacityInput] = useState<number>(10);
  const [newTourRulesInput, setNewTourRulesInput] = useState<string>(
    'Check-in obrigatório 30 min antes do embarque. Uso de colete salva-vidas conforme orientação do comandante.'
  );
  const [newTourPartnerSelect, setNewTourPartnerSelect] = useState<string>('part-kaimares');
  const [adminTourSearch, setAdminTourSearch] = useState('');
  const [adminTourStatusFilter, setAdminTourStatusFilter] = useState<string>('TODOS');
  const [adminTourPartnerFilter, setAdminTourPartnerFilter] = useState<string>('TODOS');
  const [confirmDeleteTourId, setConfirmDeleteTourId] = useState<string | null>(null);
  const [inspectingTourId, setInspectingTourId] = useState<string | null>(null);

  // Gestão de Embarcações (3.4)
  const [newVesselPartnerSelect, setNewVesselPartnerSelect] = useState<string>('part-kaimares');
  const [newVesselOperationMode, setNewVesselOperationMode] = useState<'Privativo' | 'Compartilhado' | 'Ambos'>('Ambos');
  const [adminVesselSearch, setAdminVesselSearch] = useState('');
  const [adminVesselPartnerFilter, setAdminVesselPartnerFilter] = useState<string>('TODOS');
  const [adminVesselStatusFilter, setAdminVesselStatusFilter] = useState<string>('TODOS');

  // Gestão Administrativa de Reservas (3.5)
  const [adminBookingFilter, setAdminBookingFilter] = useState<string>('TODAS');
  const [adminBookingSearchCode, setAdminBookingSearchCode] = useState<string>('');
  const [adminBookingPartnerFilter, setAdminBookingPartnerFilter] = useState<string>('TODOS');
  const [adminBookingTourFilter, setAdminBookingTourFilter] = useState<string>('TODOS');
  const [adminBookingDateFilter, setAdminBookingDateFilter] = useState<string>('');
  const [inspectingBookingCode, setInspectingBookingCode] = useState<string | null>(null);

  // Gestão de Saídas e Ocupação (3.6)
  const [departureDateSelect, setDepartureDateSelect] = useState<string>('');
  const [departureStatusSelect, setDepartureStatusSelect] = useState<'TODOS' | DepartureStatusType>('TODOS');
  const [departurePartnerSelect, setDeparturePartnerSelect] = useState<string>('TODOS');
  const [departureSearchQuery, setDepartureSearchQuery] = useState<string>('');

  // Estados de Autenticação, Sessão, Recuperação de Senha e Onboarding de Parceiros (Missão 02.19)
  const supabaseAuthAdapter = useMemo(() => new SupabaseAuthProviderAdapter(), []);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authViewMode, setAuthViewMode] = useState<
    'login' | 'register' | 'recovery' | 'reset-password' | 'onboarding'
  >('login');
  const [authLoading, setAuthLoading] = useState<boolean>(false);
  const [authFeedback, setAuthFeedback] = useState<{
    type: 'error' | 'success' | 'info';
    message: string;
  } | null>(null);
  const [verifiedSession, setVerifiedSession] = useState<VerifiedServerSessionContext>(() =>
    createUnauthenticatedSessionContext('UNAUTHENTICATED')
  );
  const [loginEmailInput, setLoginEmailInput] = useState<string>('');
  const [loginPasswordInput, setLoginPasswordInput] = useState<string>('');
  const [regFullNameInput, setRegFullNameInput] = useState<string>('');
  const [regEmailInput, setRegEmailInput] = useState<string>('');
  const [regPasswordInput, setRegPasswordInput] = useState<string>('');
  const [regConfirmPasswordInput, setRegConfirmPasswordInput] = useState<string>('');
  const [regAcceptedTerms, setRegAcceptedTerms] = useState<boolean>(false);
  const [recoveryEmailInput, setRecoveryEmailInput] = useState<string>('');
  const [resetTokenInput, setResetTokenInput] = useState<string>('');
  const [resetNewPasswordInput, setResetNewPasswordInput] = useState<string>('');
  const [resetConfirmPasswordInput, setResetConfirmPasswordInput] = useState<string>('');
  const [onboardingStore, setOnboardingStore] = useState<OnboardingStateStore>({
    applications: [],
    memberLinks: [],
  });
  const [onbCompanyName, setOnbCompanyName] = useState<string>('');
  const [onbLegalName, setOnbLegalName] = useState<string>('');
  const [onbCnpj, setOnbCnpj] = useState<string>('');
  const [onbWhatsapp, setOnbWhatsapp] = useState<string>('');
  const [onbBusinessEmail, setOnbBusinessEmail] = useState<string>('');
  const [onbBaseMarina, setOnbBaseMarina] = useState<string>('Saco da Ribeira');
  const [onbYearsOperating, setOnbYearsOperating] = useState<number>(2);
  const [onbBio, setOnbBio] = useState<string>('');

  // Formulário de Substituição/Upload de Mídia Real no Admin/Parceiro
  const [newMediaTitle, setNewMediaTitle] = useState('');
  const [newMediaType, setNewMediaType] = useState<'photo' | 'video'>('photo');
  const [newMediaCategory, setNewMediaCategory] = useState<'Destino' | 'Embarcação' | 'Passeio' | 'Experiência'>('Destino');
  const [newMediaTargetId, setNewMediaTargetId] = useState('dest-ilha-couves');
  const [newMediaPresetUrl, setNewMediaPresetUrl] = useState(IMG_COUVES);
  const [newMediaCustomUrl, setNewMediaCustomUrl] = useState('');
  const [newMediaReplaceHero, setNewMediaReplaceHero] = useState<boolean>(false);

  // Seleções derivadas
  const selectedDestination = useMemo(
    () => destinations.find((d) => d.id === selectedDestinationId) || null,
    [destinations, selectedDestinationId]
  );

  const selectedTour = useMemo(
    () => tours.find((t) => t.id === selectedTourId) || null,
    [tours, selectedTourId]
  );

  const selectedVessel = useMemo(
    () => vessels.find((v) => v.id === selectedVesselId) || null,
    [vessels, selectedVesselId]
  );

  const activePartner = useMemo(
    () =>
      resolveIsolatedActivePartner({
        isConnectedMode: isSupabaseConfigured,
        serverVerifiedRole,
        authorizedPartnerIds,
        activePartnerId,
        partners,
        fallbackPartner: canUseDemoData
          ? INITIAL_PARTNERS[0]
          : {
              id: '',
              name: '',
              legalName: '',
              cnpj: '',
              whatsapp: '',
              email: '',
              baseMarina: '',
              status: 'SUSPENSO',
              verified: false,
              rating: 0,
              reviewsCount: 0,
              yearsOperating: 0,
              commissionModel: 'PERCENTAGE',
              commissionRate: 0,
              commissionFixed: 0,
              bio: '',
              avatarImage: '',
            },
      }),
    [partners, activePartnerId, serverVerifiedRole, authorizedPartnerIds]
  );

  const openBookingModalForTour = (tour: Tour) => {
    setBookingModalTour(tour);
    setLastCreatedBooking(null);
    setIsSubmittingBooking(false);
    bookingSubmissionLockRef.current = false;
    if (tourDateFilter && isBookingDateValidInBrazil(tourDateFilter)) {
      setBookingDate(tourDateFilter);
    } else if (!isBookingDateValidInBrazil(bookingDate)) {
      setBookingDate(getBrazilFutureDateIso(3));
    }
    setBookingPassengers((prev) => Math.min(Math.max(1, prev), tour.capacity));
  };

  // Consulta disponibilidade real no servidor via RPC get_tour_availability quando conectado ao Supabase (Seção 4)
  useEffect(() => {
    if (!bookingModalTour || !bookingDate) {
      setLiveModalAvailability(null);
      setLoadingModalAvailability(false);
      return;
    }
    if (!isSupabaseConfigured) {
      setLiveModalAvailability(null);
      setLoadingModalAvailability(false);
      return;
    }
    let cancelled = false;
    setLoadingModalAvailability(true);
    rpcGetTourAvailability(bookingModalTour.id, bookingDate)
      .then((res) => {
        if (cancelled) return;
        if (res.executedOnServer && res.data) {
          setLiveModalAvailability(res.data);
        } else {
          setLiveModalAvailability(null);
        }
        setLoadingModalAvailability(false);
      })
      .catch(() => {
        if (!cancelled) {
          setLiveModalAvailability(null);
          setLoadingModalAvailability(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [bookingModalTour, bookingDate]);

  const buildSanitizedLocalLookupPayload = (bk: BookingRequest): TouristBookingLookupResponse => {
    const tourObj = tours.find((t) => t.id === bk.tourId);
    const vesselObj = vessels.find((v) => v.id === bk.vesselId);
    const partnerObj = partners.find((p) => p.id === bk.partnerId);
    return {
      ok: true,
      booking_code: bk.code,
      status: normalizeBookingStatus(bk.status),
      booking_date: bk.date,
      passengers: bk.passengers,
      pricing_model: tourObj?.pricingModel || 'POR_PESSOA',
      unit_price: tourObj?.price || bk.grossAmount,
      gross_amount: bk.grossAmount,
      channel: bk.channel,
      tour_slug: tourObj?.slug || bk.tourId,
      tour_title: bk.tourTitle,
      departure_time: tourObj?.departureTime || '09:30',
      return_time: tourObj?.returnTime || '15:00',
      check_in_time: tourObj?.checkInTime || '09:00',
      departure_point: tourObj?.departurePoint || 'Praia do Itaguá',
      cancellation_policy:
        tourObj?.cancellationPolicy ||
        'Cancelamento gratuito até 48h antes do embarque ou em caso de interdição marítima.',
      vessel_name: vesselObj?.name || bk.vesselName,
      partner_name: partnerObj?.name || bk.partnerName,
      partner_whatsapp: partnerObj?.whatsapp || '',
      partner_base_marina: partnerObj?.baseMarina || '',
      rejection_or_cancel_reason: bk.rejectionReason || null,
      created_at: bk.createdAt,
    };
  };

  // Hidrata automaticamente os comprovantes salvos do turista (pós-F5 ou reabertura do navegador — Seção 7)
  useEffect(() => {
    if (savedTouristReceipts.length === 0) return;
    let cancelled = false;

    if (isSupabaseConfigured) {
      Promise.all(
        savedTouristReceipts.map(async (r) => {
          const res = await rpcLookupBookingByTouristToken(r.bookingCode, r.lookupToken);
          return { code: r.bookingCode, res };
        })
      )
        .then((items) => {
          if (cancelled) return;
          setVerifiedTouristBookings((prev) => {
            const next = { ...prev };
            for (const item of items) {
              if (item.res.executedOnServer && item.res.data && item.res.data.ok) {
                next[item.code] = item.res.data;
              }
            }
            return next;
          });
        })
        .catch(() => {
          // Mantém estado anterior em caso de oscilação de rede
        });
      return () => {
        cancelled = true;
      };
    }

    setVerifiedTouristBookings((prev) => {
      const next = { ...prev };
      for (const r of savedTouristReceipts) {
        const match = bookings.find((b) => {
          const expectedToken = b.lookupToken || deriveLocalDemoLookupToken(b.id, b.code);
          return (
            b.code.toUpperCase() === r.bookingCode.toUpperCase() &&
            expectedToken.toLowerCase() === r.lookupToken.toLowerCase() &&
            b.customerName !== 'TITULAR ANONIMIZADO LGPD'
          );
        });
        if (match) {
          next[r.bookingCode] = buildSanitizedLocalLookupPayload(match);
        }
      }
      return next;
    });

    return () => {
      cancelled = true;
    };
  }, [savedTouristReceipts, bookings, tours, vessels, partners, touristTrackerOpen]);

  // M02.20-F05: Algoritmo canônico unificado de ocupação/disponibilidade entre Marketplace Público e Operação (computeCanonicalDepartureOccupancy)
  const getTourAvailabilityForDate = (tour: Tour, dateStr: string, excludeBookingId?: string) => {
    if (!dateStr) return { blocked: false, remainingSeats: tour.capacity, blockReason: '' };
    const vesselObj = vessels.find((v) => v.id === tour.vesselId);
    const partnerObj = partners.find((p) => p.id === tour.partnerId);
    const relevantBookings = excludeBookingId
      ? bookings.filter((b) => b.id !== excludeBookingId)
      : bookings;
    const canonicalOcc = computeCanonicalDepartureOccupancy({
      tour,
      vessel: vesselObj,
      partner: partnerObj,
      date: dateStr,
      bookings: relevantBookings,
      availabilityBlocks,
      currentBrazilDate,
    });
    return {
      blocked: !canonicalOcc.isAvailableForNewBookings,
      remainingSeats: canonicalOcc.remainingSeats,
      blockReason: canonicalOcc.blockReason,
    };
  };

  // Filtragem do Guia Turístico
  const filteredDestinations = useMemo(() => {
    return destinations.filter((d) => {
      if (guideCategoryFilter !== 'TODAS' && d.category !== guideCategoryFilter) return false;
      if (guideRegionFilter !== 'TODAS' && d.region !== guideRegionFilter) return false;
      if (guideSearch.trim() !== '') {
        const q = guideSearch.toLowerCase();
        const match =
          d.name.toLowerCase().includes(q) ||
          d.shortDescription.toLowerCase().includes(q) ||
          d.region.toLowerCase().includes(q) ||
          d.category.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [destinations, guideCategoryFilter, guideRegionFilter, guideSearch]);

  // Filtragem do Marketplace de Passeios (Corrige BUG-05 e BUG-06)
  const filteredTours = useMemo(() => {
    const list = tours.filter((t) => {
      const partner = partners.find((p) => p.id === t.partnerId);
      const vessel = vessels.find((v) => v.id === t.vesselId);
      if (!isTourEffectivelyActive(t)) return false;
      if (partner && !isPartnerEffectivelyActive(partner)) return false;
      if (vessel && !isVesselEffectivelyActive(vessel)) return false;

      if (tourCategoryFilter !== 'TODAS') {
        if (tourCategoryFilter === 'Passeios compartilhados') {
          if (t.tourType !== 'Compartilhado' && t.category !== 'Passeios compartilhados') return false;
        } else if (tourCategoryFilter === 'Passeios privativos') {
          if (t.tourType !== 'Privativo' && t.category !== 'Passeios privativos') return false;
        } else if (tourCategoryFilter === 'Passeios para grupos') {
          if (t.capacity < 10 && t.category !== 'Passeios para grupos') return false;
        } else if (t.category !== tourCategoryFilter) {
          return false;
        }
      }

      if (tourVesselTypeFilter !== 'TODOS' && t.vesselType !== tourVesselTypeFilter) return false;
      if (tourTypeFilter !== 'TODOS' && t.tourType !== tourTypeFilter) return false;
      if (t.price > tourMaxPrice) return false;
      if (t.capacity < tourMinCapacity) return false;
      if (tourDestinationFilter !== 'TODOS' && !t.destinationsVisited.includes(tourDestinationFilter)) return false;

      if (tourDateFilter) {
        const avail = getTourAvailabilityForDate(t, tourDateFilter);
        if (avail.blocked || avail.remainingSeats < tourMinCapacity) return false;
      }

      if (tourSearch.trim() !== '') {
        const q = tourSearch.toLowerCase();
        const partnerName = partner?.name.toLowerCase() || '';
        const match =
          t.title.toLowerCase().includes(q) ||
          t.departurePoint.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          partnerName.includes(q);
        if (!match) return false;
      }

      return true;
    });

    return [...list].sort((a, b) => {
      if (tourSortBy === 'MENOR_PRECO') return a.price - b.price;
      if (tourSortBy === 'MAIOR_PRECO') return b.price - a.price;
      if (tourSortBy === 'AVALIACAO') return b.rating - a.rating;
      if (tourSortBy === 'CAPACIDADE') return b.capacity - a.capacity;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [
    tours,
    partners,
    tourCategoryFilter,
    tourVesselTypeFilter,
    tourTypeFilter,
    tourMaxPrice,
    tourMinCapacity,
    tourDestinationFilter,
    tourDateFilter,
    tourSearch,
    tourSortBy,
    availabilityBlocks,
    bookings
  ]);

  // Métricas Financeiras e de Comissões (Consolidadas vs Pendentes)
  const financialMetrics = useMemo(() => {
    const consolidatedBookings = bookings.filter((b) => b.status === 'PASSEIO_REALIZADO' && b.commissionConsolidated);
    const pendingBookings = bookings.filter((b) => {
      const st = normalizeBookingStatus(b.status);
      return st === 'AGUARDANDO_CONFIRMACAO' || st === 'CONFIRMADA' || st === 'SOLICITADA';
    });

    const totalGrossConsolidated = sumCurrencyExact(consolidatedBookings.map((b) => b.grossAmount));
    const totalCommissionConsolidated = sumCurrencyExact(consolidatedBookings.map((b) => b.commissionAmount));
    const totalCommissionPending = sumCurrencyExact(pendingBookings.map((b) => b.commissionAmount));

    return {
      totalGrossConsolidated,
      totalCommissionConsolidated,
      totalCommissionPending,
      consolidatedCount: consolidatedBookings.length,
      pendingCount: pendingBookings.length
    };
  }, [bookings]);

  // Ação de Busca na Hero
  const handleHeroSearch = () => {
    if (heroSearchScope === 'Praias' || heroSearchScope === 'Ilhas' || heroSearchScope === 'Cachoeiras') {
      setGuideCategoryFilter(heroSearchScope);
      setGuideSearch(heroSearchQuery);
      navigateToTab('guide');
      return;
    }
    if (heroSearchScope === 'Passeios de lancha') {
      setTourCategoryFilter('TODAS');
      setTourVesselTypeFilter('Lancha');
      setTourSearch(heroSearchQuery);
      navigateToTab('tours');
      return;
    }
    if (heroSearchScope === 'Passeios de escuna') {
      setTourCategoryFilter('TODAS');
      setTourVesselTypeFilter('Escuna');
      setTourSearch(heroSearchQuery);
      navigateToTab('tours');
      return;
    }
    if (heroSearchScope === 'Experiências turísticas') {
      setTourCategoryFilter('TODAS');
      setTourVesselTypeFilter('TODOS');
      setTourSearch(heroSearchQuery);
      navigateToTab('tours');
      return;
    }
    if (heroSearchQuery.trim() !== '') {
      const q = heroSearchQuery.toLowerCase();
      const matchesTour = tours.some((t) => t.title.toLowerCase().includes(q) || t.vesselType.toLowerCase().includes(q));
      if (matchesTour) {
        setTourSearch(heroSearchQuery);
        navigateToTab('tours');
      } else {
        setGuideSearch(heroSearchQuery);
        navigateToTab('guide');
      }
    } else {
      navigateToTab('tours');
    }
  };

  // Submissão de Reserva Híbrida (WhatsApp ou Site Direct)
  const handleCreateBookingRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingModalTour) return;

    const cleanName = bookingName.trim();
    const cleanPhone = bookingPhone.trim();
    const cleanEmail = bookingEmail.trim();
    const phoneDigits = cleanPhone.replace(/\D/g, '');

    if (cleanName.length < 3) {
      showToast('Nome Inválido', 'Informe seu nome completo (mínimo 3 caracteres).', 'warning');
      return;
    }
    if (phoneDigits.length < 10) {
      showToast('WhatsApp Inválido', 'Informe um número válido com DDD (mínimo 10 dígitos).', 'warning');
      return;
    }
    if (!cleanEmail.includes('@')) {
      showToast('E-mail Inválido', 'Informe um endereço de e-mail válido.', 'warning');
      return;
    }
    if (!bookingDate || !isBookingDateValidInBrazil(bookingDate)) {
      showToast(
        'Data Inválida',
        `Selecione uma data igual ou posterior à data atual em Brasília (${currentBrazilDate}).`,
        'warning'
      );
      return;
    }

    const effectiveAvail =
      isSupabaseConfigured && liveModalAvailability && liveModalAvailability.booking_date === bookingDate
        ? {
            blocked: liveModalAvailability.blocked,
            remainingSeats: liveModalAvailability.remaining_seats,
            blockReason: liveModalAvailability.block_reason,
          }
        : getTourAvailabilityForDate(bookingModalTour, bookingDate);

    if (effectiveAvail.blocked) {
      showToast('Data Indisponível', `Não é possível reservar nesta data: ${effectiveAvail.blockReason}.`, 'warning');
      return;
    }
    if (bookingPassengers < 1 || bookingPassengers > effectiveAvail.remainingSeats) {
      showToast(
        'Capacidade Excedida',
        `Solicitação de ${bookingPassengers} passageiros excede as ${effectiveAvail.remainingSeats} vagas disponíveis nesta data.`,
        'warning'
      );
      return;
    }

    if (bookingSubmissionLockRef.current || isSubmittingBooking) {
      showToast('Processando Solicitação', 'Aguarde a conclusão da solicitação em andamento.', 'info');
      return;
    }

    const clientIdempotencyKey = generateClientBookingIdempotencyKey({
      tourId: bookingModalTour.id,
      bookingDate,
      passengers: bookingPassengers,
      channel: bookingChannel,
      customerPhone: cleanPhone,
      customerEmail: cleanEmail,
    });

    if (!isSupabaseConfigured) {
      const duplicate = bookings.find(
        (b) =>
          b.tourId === bookingModalTour.id &&
          b.date === bookingDate &&
          b.customerPhone.replace(/\D/g, '') === phoneDigits &&
          b.status !== 'CANCELADA' &&
          b.status !== 'RECUSADA'
      );
      if (duplicate) {
        if (duplicate.passengers !== bookingPassengers) {
          showToast(
            'Conflito de Passageiros em Reserva Ativa',
            `ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe a solicitação ativa ${duplicate.code} para esta data com ${duplicate.passengers} passageiros.`,
            'warning'
          );
          return;
        }
        const replayToken = duplicate.lookupToken || deriveLocalDemoLookupToken(duplicate.id, duplicate.code);
        const duplicateWithToken = { ...duplicate, lookupToken: replayToken };
        const updatedReceipts = saveTouristReceipt({
          bookingCode: duplicateWithToken.code,
          lookupToken: replayToken,
          tourTitle: duplicateWithToken.tourTitle,
          bookingDate: duplicateWithToken.date,
          createdAt: duplicateWithToken.createdAt,
        });
        setSavedTouristReceipts(updatedReceipts);
        setLastCreatedBooking(duplicateWithToken);
        showToast(
          `Solicitação Já Existente (${duplicateWithToken.code})`,
          'Encontramos sua solicitação ativa para este mesmo passeio e data (replay idempotente).',
          'info'
        );
        return;
      }
    }

    const partner = partners.find((p) => p.id === bookingModalTour.partnerId) || partners[0];
    const vessel = vessels.find((v) => v.id === bookingModalTour.vesselId) || vessels[0];

    const calc = calculateCommissionBackend(bookingModalTour, partner, bookingPassengers);
    let uniqueCode = `UBT-${Math.floor(1000 + Math.random() * 9000)}`;
    while (bookings.some((b) => b.code === uniqueCode)) {
      uniqueCode = `UBT-${Math.floor(1000 + Math.random() * 9000)}`;
    }

    const nowFormatted = new Date().toLocaleString('pt-BR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });

    bookingSubmissionLockRef.current = true;
    setIsSubmittingBooking(true);

    const initialCanonicalStatus: BookingStatusType =
      bookingChannel === 'WHATSAPP' ? 'SOLICITADA' : 'AGUARDANDO_CONFIRMACAO';

    const newBookingId = `bk-${Date.now()}`;
    const demoLookupToken = deriveLocalDemoLookupToken(newBookingId, uniqueCode);

    const newBooking: BookingRequest = {
      id: newBookingId,
      code: uniqueCode,
      lookupToken: demoLookupToken,
      idempotencyKey: clientIdempotencyKey,
      tourId: bookingModalTour.id,
      tourTitle: bookingModalTour.title,
      vesselId: vessel.id,
      vesselName: vessel.name,
      partnerId: partner.id,
      partnerName: partner.name,
      customerName: cleanName,
      customerPhone: cleanPhone,
      customerEmail: cleanEmail,
      date: bookingDate,
      passengers: bookingPassengers,
      channel: bookingChannel,
      utmSource: bookingUtmSource,
      utmCampaign: 'marketplace_ubatuba_2026',
      status: initialCanonicalStatus,
      ledgerStatus: 'PREVISTA',
      grossAmount: calc.gross,
      commissionRuleUsed: calc.ruleLabel,
      commissionAmount: calc.commission,
      netPartnerAmount: calc.net,
      commissionConsolidated: false,
      createdAt: nowFormatted,
      notes:
        bookingChannel === 'WHATSAPP'
          ? `Lead rastreado enviado ao WhatsApp oficial de ${partner.name} (${partner.whatsapp}).`
          : 'Solicitação registrada no site; aguardando confirmação de disponibilidade pelo parceiro.'
    };

    const finalizeCreateBooking = (confirmedBooking: BookingRequest, isReplay = false) => {
      const nextBookingsList = [
        confirmedBooking,
        ...bookings.filter((b) => b.id !== confirmedBooking.id && b.code !== confirmedBooking.code),
      ];
      setBookings(nextBookingsList);
      const defaultMethod: PaymentMethodType =
        confirmedBooking.channel === 'WHATSAPP' ? 'PIX' : 'CARTAO_CREDITO';
      const initPayRes = initiateBookingPayment(
        { ...operationalState, bookings: nextBookingsList },
        financialStore,
        { ...currentAuthContext, actorRole: 'admin' },
        {
          bookingId: confirmedBooking.id,
          paymentMethod: defaultMethod,
          idempotencyKey: `init-pay-${confirmedBooking.id}`,
          externalPaymentReference: `ref-${confirmedBooking.code.toLowerCase()}`,
        }
      );
      if (initPayRes.ok && initPayRes.data) {
        setFinancialStore(initPayRes.data.financialStore);
      }
      bookingSubmissionLockRef.current = false;
      setIsSubmittingBooking(false);
      setLastCreatedBooking(confirmedBooking);

      if (confirmedBooking.lookupToken) {
        const updatedReceipts = saveTouristReceipt({
          bookingCode: confirmedBooking.code,
          lookupToken: confirmedBooking.lookupToken,
          tourTitle: confirmedBooking.tourTitle,
          bookingDate: confirmedBooking.date,
          createdAt: confirmedBooking.createdAt,
        });
        setSavedTouristReceipts(updatedReceipts);
        setLookupCodeInput(confirmedBooking.code);
        setLookupTokenInput(confirmedBooking.lookupToken);
      }

      appendAuditLog(
        isReplay ? 'IDEMPOTENT_BOOKING_REPLAY' : 'CREATE_BOOKING',
        confirmedBooking.code,
        `Solicitação (${bookingChannel}) p/ ${bookingModalTour.title} em ${bookingDate} (${bookingPassengers} pax | Bruto R$ ${confirmedBooking.grossAmount})`,
        cleanName
      );

      if (isReplay) {
        showToast(
          `Solicitação ${confirmedBooking.code} Recuperada (Idempotente)`,
          'Sua solicitação ativa já estava registrada no servidor sem duplicação.',
          'info'
        );
      } else if (bookingChannel === 'WHATSAPP') {
        showToast(
          `Solicitação ${confirmedBooking.code} Registrada!`,
          `Parceiro ${partner.name} identificado. Guarde sua Chave de Consulta Segura (${confirmedBooking.lookupToken}).`,
          'success'
        );
      } else {
        showToast(
          `Solicitação ${confirmedBooking.code} Enviada ao Parceiro!`,
          `Status: ${confirmedBooking.status}. Guarde sua Chave de Consulta Segura (${confirmedBooking.lookupToken}).`,
          'info'
        );
      }
    };

    if (isSupabaseConfigured) {
      rpcCreateBookingRequest({
        tourId: bookingModalTour.id,
        bookingDate,
        passengers: bookingPassengers,
        customerName: cleanName,
        customerPhone: cleanPhone,
        customerEmail: cleanEmail,
        channel: bookingChannel,
        utmSource: bookingUtmSource,
        utmCampaign: 'marketplace_ubatuba_2026',
        notes: newBooking.notes,
        idempotencyKey: clientIdempotencyKey
      }).then((rpcRes) => {
        if (!rpcRes.executedOnServer || rpcRes.error || !rpcRes.data) {
          bookingSubmissionLockRef.current = false;
          setIsSubmittingBooking(false);
          showToast(
            'Reserva Não Confirmada pelo Servidor',
            rpcRes.error || 'O servidor não confirmou a persistência da reserva.',
            'warning'
          );
          return;
        }
        const serverLookupToken =
          rpcRes.data.lookup_token ||
          deriveLocalDemoLookupToken(rpcRes.data.id || newBooking.id, rpcRes.data.code || newBooking.code);
        finalizeCreateBooking(
          {
            ...newBooking,
            id: rpcRes.data.id || newBooking.id,
            code: rpcRes.data.code || newBooking.code,
            lookupToken: serverLookupToken,
            idempotencyKey: rpcRes.data.idempotency_key || clientIdempotencyKey,
            tourTitle: rpcRes.data.tour_title || newBooking.tourTitle,
            vesselName: rpcRes.data.vessel_name || newBooking.vesselName,
            partnerName: rpcRes.data.partner_name || newBooking.partnerName,
            status: rpcRes.data.status,
            ledgerStatus: rpcRes.data.ledger_status || 'PREVISTA',
            grossAmount: Number(rpcRes.data.gross_amount ?? newBooking.grossAmount),
            commissionAmount: Number(rpcRes.data.commission_amount ?? newBooking.commissionAmount),
            netPartnerAmount: Number(rpcRes.data.net_partner_amount ?? newBooking.netPartnerAmount),
            commissionRuleUsed: rpcRes.data.commission_rule_label || newBooking.commissionRuleUsed,
            commissionConsolidated: Boolean(rpcRes.data.commission_consolidated),
          },
          Boolean(rpcRes.data.idempotent_replay)
        );
      }).catch((err: unknown) => {
        bookingSubmissionLockRef.current = false;
        setIsSubmittingBooking(false);
        showToast('Erro de Comunicação ao Criar Reserva', err instanceof Error ? err.message : String(err), 'warning');
      });
      return;
    }

    finalizeCreateBooking(newBooking, false);
  };

  // Atualizar Status da Reserva (Painel do Parceiro, Admin ou Turista) — Validação estrita MP-011 / MP-014 / MP-015
  const handleUpdateBookingStatus = (
    bookingId: string,
    newStatus: BookingRequest['status'],
    reason?: string,
    ledgerOverride?: BookingRequest['ledgerStatus']
  ) => {
    const targetBooking = bookings.find((b) => b.id === bookingId);
    if (!targetBooking) return;

    const currentCanonical = normalizeBookingStatus(targetBooking.status);
    const targetCanonical = normalizeBookingStatus(newStatus);

    const effectiveReason = reason || ((targetCanonical === 'RECUSADA' || targetCanonical === 'CANCELADA') ? `Alterado para ${targetCanonical} pelo perfil ${roleMode}` : undefined);
    const transitionCheck = validateBookingStatusTransition(currentCanonical, targetCanonical, roleMode, effectiveReason);
    if (!transitionCheck.valid) {
      showToast('Transição de Status Bloqueada', transitionCheck.errorMessage || transitionCheck.reason || 'Transição não permitida.', 'warning');
      return;
    }

    if (roleMode === 'partner' && targetBooking.partnerId !== activePartner.id) {
      showToast('Acesso Negado (RLS)', 'Um parceiro somente pode alterar reservas vinculadas à sua própria operação.', 'warning');
      return;
    }

    if (targetCanonical === 'CONFIRMADA') {
      const tourObj = tours.find((t) => t.id === targetBooking.tourId);
      if (tourObj) {
        const avail = getTourAvailabilityForDate(tourObj, targetBooking.date, targetBooking.id);
        if (avail.blocked || avail.remainingSeats < targetBooking.passengers) {
          showToast(
            'Bloqueio Anti-Overbooking!',
            `Não há vagas suficientes em ${targetBooking.date} para confirmar ${targetBooking.passengers} passageiros.`,
            'warning'
          );
          return;
        }
      }
    }

    const applyStatusTransitionState = (
      confirmedStatus: BookingStatusType,
      confirmedLedger?: LedgerStatusType
    ) => {
      const nextBookingsList = bookings.map((b) => {
        if (b.id !== bookingId) return b;
        const isCompleted = confirmedStatus === 'PASSEIO_REALIZADO';
        const nextLedgerStatus: BookingRequest['ledgerStatus'] =
          confirmedLedger || ledgerOverride || deriveLedgerStatusFromBookingStatus(confirmedStatus, b.ledgerStatus);

        return {
          ...b,
          status: confirmedStatus,
          ledgerStatus: nextLedgerStatus,
          commissionConsolidated: isCompleted,
          rejectionReason: effectiveReason || b.rejectionReason
        };
      });
      setBookings(nextBookingsList);

      if (confirmedStatus === 'CANCELADA' || confirmedStatus === 'RECUSADA') {
        const cancelSyncRes = handleBookingCancellationFinancialSync(
          { ...operationalState, bookings: nextBookingsList },
          financialStore,
          currentAuthContext,
          bookingId,
          effectiveReason || `Reserva ${confirmedStatus.toLowerCase()} pelo perfil ${roleMode}`
        );
        if (cancelSyncRes.ok && cancelSyncRes.data) {
          setFinancialStore(cancelSyncRes.data.financialStore);
        }
      }

      appendAuditLog(
        'STATUS_TRANSITION',
        targetBooking.code,
        `Status alterado de ${targetBooking.status} para ${confirmedStatus}${effectiveReason ? ` (Motivo: ${effectiveReason})` : ''}`
      );

      if (confirmedStatus === 'PASSEIO_REALIZADO') {
        showToast(
          'Passeio Realizado & Comissão Consolidada!',
          `Reserva ${targetBooking.code}: comissão de R$ ${targetBooking.commissionAmount} consolidada no livro-razão.`,
          'success'
        );
      } else if (confirmedStatus === 'RECUSADA' || confirmedStatus === 'CANCELADA') {
        showToast(
          `Solicitação ${confirmedStatus === 'RECUSADA' ? 'Recusada' : 'Cancelada'}`,
          `Reserva ${targetBooking.code}: comissão revertida (R$ 0,00 cobrados) e vagas liberadas.`,
          'warning'
        );
      } else {
        showToast('Status da Solicitação Atualizado', `Reserva ${targetBooking.code}: novo status ${confirmedStatus}.`, 'info');
      }
    };

    if (isSupabaseConfigured) {
      rpcTransitionBookingStatus(bookingId, targetCanonical, effectiveReason)
        .then((rpcRes) => {
          if (rpcRes.executedOnServer && rpcRes.error) {
            showToast('Transição Rejeitada pelo Servidor', rpcRes.error, 'warning');
            return;
          }
          if (rpcRes.executedOnServer && rpcRes.data) {
            applyStatusTransitionState(rpcRes.data.status, rpcRes.data.ledger_status);
            return;
          }
          applyStatusTransitionState(targetCanonical);
        })
        .catch((err: unknown) => {
          showToast('Erro de Comunicação na Transição', err instanceof Error ? err.message : String(err), 'warning');
        });
      return;
    }

    applyStatusTransitionState(targetCanonical);
  };

  // Consulta pública segura da reserva pelo turista usando Código + Chave de Consulta (Missão 02.16 — Seção 7)
  const handleTouristLookupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = lookupCodeInput.trim().toUpperCase();
    const cleanToken = lookupTokenInput.trim().toLowerCase();
    setLookupError(null);

    if (!/^UBT-[A-Z0-9]{4,8}$/.test(cleanCode) || !/^ubtk-[0-9a-f]{32}$/.test(cleanToken)) {
      setLookupError('Código de reserva ou credencial de consulta inválidos.');
      return;
    }

    setLookupLoading(true);
    try {
      if (isSupabaseConfigured) {
        const res = await rpcLookupBookingByTouristToken(cleanCode, cleanToken);
        setLookupLoading(false);
        if (!res.executedOnServer || res.error || !res.data || !res.data.ok) {
          setLookupError(res.error || 'Código de reserva ou credencial de consulta inválidos.');
          return;
        }
        const payload = res.data;
        setVerifiedTouristBookings((prev) => ({
          ...prev,
          [cleanCode]: payload,
        }));
        const updatedReceipts = saveTouristReceipt({
          bookingCode: cleanCode,
          lookupToken: cleanToken,
          tourTitle: payload.tour_title || 'Passeio Náutico',
          bookingDate: payload.booking_date || '',
          createdAt: payload.created_at || new Date().toISOString(),
        });
        setSavedTouristReceipts(updatedReceipts);
        showToast('Reserva Localizada com Segurança', `Reserva ${cleanCode} autenticada com sucesso.`, 'success');
        return;
      }

      // Modo demonstrativo local com a mesma política de rate limit (5 falhas em 15 min) e erro uniforme
      const nowMs = Date.now();
      const rlEntry = localLookupAttemptsRef.current[cleanCode];
      if (rlEntry && rlEntry.lockedUntil > nowMs) {
        setLookupLoading(false);
        setLookupError('Limite de tentativas excedido para este código. Aguarde 15 minutos antes de tentar novamente.');
        return;
      }

      const targetBk = bookings.find((b) => b.code.toUpperCase() === cleanCode);
      const expectedTok = targetBk
        ? (targetBk.lookupToken || deriveLocalDemoLookupToken(targetBk.id, targetBk.code)).toLowerCase()
        : '';

      if (!targetBk || targetBk.customerName === 'TITULAR ANONIMIZADO LGPD' || expectedTok !== cleanToken) {
        const prevFails =
          rlEntry && nowMs - rlEntry.windowStart < 15 * 60 * 1000 ? rlEntry.fails + 1 : 1;
        localLookupAttemptsRef.current[cleanCode] = {
          fails: prevFails,
          windowStart: prevFails === 1 ? nowMs : rlEntry.windowStart,
          lockedUntil: prevFails >= 5 ? nowMs + 15 * 60 * 1000 : 0,
        };
        setLookupLoading(false);
        setLookupError('Código de reserva ou credencial de consulta inválidos.');
        return;
      }

      delete localLookupAttemptsRef.current[cleanCode];
      const sanitizedPayload = buildSanitizedLocalLookupPayload(targetBk);
      setVerifiedTouristBookings((prev) => ({
        ...prev,
        [cleanCode]: sanitizedPayload,
      }));
      const updatedReceipts = saveTouristReceipt({
        bookingCode: cleanCode,
        lookupToken: cleanToken,
        tourTitle: targetBk.tourTitle,
        bookingDate: targetBk.date,
        createdAt: targetBk.createdAt,
      });
      setSavedTouristReceipts(updatedReceipts);
      setLookupLoading(false);
      showToast('Reserva Localizada com Segurança', `Reserva ${cleanCode} autenticada com sucesso.`, 'success');
    } catch (err: unknown) {
      setLookupLoading(false);
      setLookupError(err instanceof Error ? err.message : 'Erro ao consultar reserva.');
    }
  };

  // Cancelamento autenticado por credencial do turista (Missão 02.16 — Seção 8)
  const handleTouristCancelByToken = async (bookingCode: string, explicitToken?: string) => {
    const cleanCode = bookingCode.trim().toUpperCase();
    const savedRec = savedTouristReceipts.find((r) => r.bookingCode.toUpperCase() === cleanCode);
    const localBk = bookings.find((b) => b.code.toUpperCase() === cleanCode);
    const cleanToken = (
      explicitToken ||
      savedRec?.lookupToken ||
      (localBk ? localBk.lookupToken || deriveLocalDemoLookupToken(localBk.id, localBk.code) : '')
    )
      .trim()
      .toLowerCase();

    if (!cleanToken) {
      showToast(
        'Credencial Necessária',
        'Informe a Chave de Consulta Segura (ubtk-...) da reserva para cancelar.',
        'warning'
      );
      return;
    }

    if (cancellingBookingCode === cleanCode) return;
    setCancellingBookingCode(cleanCode);

    try {
      if (isSupabaseConfigured) {
        const res = await rpcCancelBookingByTouristToken(
          cleanCode,
          cleanToken,
          'Cancelado pelo turista via credencial de consulta segura'
        );
        setCancellingBookingCode(null);
        if (!res.executedOnServer || res.error || !res.data || !res.data.ok) {
          showToast(
            'Cancelamento Não Realizado',
            res.error || 'Não foi possível cancelar esta reserva.',
            'warning'
          );
          return;
        }
        setVerifiedTouristBookings((prev) => {
          const existing = prev[cleanCode];
          if (!existing) return prev;
          return {
            ...prev,
            [cleanCode]: {
              ...existing,
              status: 'CANCELADA',
              rejection_or_cancel_reason:
                res.data?.rejection_or_cancel_reason || 'Cancelado pelo turista via credencial de consulta segura',
            },
          };
        });
        const nextBookingsAfterTouristCancel = bookings.map((b) =>
          b.code.toUpperCase() === cleanCode
            ? {
                ...b,
                status: 'CANCELADA' as const,
                ledgerStatus: 'REVERTIDA' as const,
                commissionConsolidated: false,
                rejectionReason: 'Cancelado pelo turista via credencial de consulta segura',
              }
            : b
        );
        setBookings(nextBookingsAfterTouristCancel);
        if (localBk) {
          const cancelFinSync = handleBookingCancellationFinancialSync(
            { ...operationalState, bookings: nextBookingsAfterTouristCancel },
            financialStore,
            currentAuthContext,
            localBk.id,
            'Cancelado pelo turista via credencial de consulta segura'
          );
          if (cancelFinSync.ok && cancelFinSync.data) {
            setFinancialStore(cancelFinSync.data.financialStore);
          }
        }
        showToast(
          res.data.idempotent_replay ? `Reserva ${cleanCode} Já Cancelada` : `Reserva ${cleanCode} Cancelada`,
          'Vagas liberadas na embarcação e comissão revertida com sucesso.',
          'info'
        );
        return;
      }

      setCancellingBookingCode(null);
      if (!localBk) {
        showToast('Reserva Não Encontrada', 'Código de reserva ou credencial inválidos.', 'warning');
        return;
      }
      if (localBk.status === 'CANCELADA') {
        showToast(`Reserva ${cleanCode} Já Cancelada`, 'Esta reserva já se encontra cancelada (operação idempotente).', 'info');
        return;
      }
      if (!['SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA'].includes(localBk.status)) {
        showToast(
          'Cancelamento Não Permitido',
          `A reserva ${cleanCode} está em ${localBk.status} e não pode ser cancelada publicamente.`,
          'warning'
        );
        return;
      }
      handleUpdateBookingStatus(localBk.id, 'CANCELADA', 'Cancelado pelo turista via credencial de consulta');
      setVerifiedTouristBookings((prev) => {
        const existing = prev[cleanCode];
        if (!existing) return prev;
        return {
          ...prev,
          [cleanCode]: {
            ...existing,
            status: 'CANCELADA',
            rejection_or_cancel_reason: 'Cancelado pelo turista via credencial de consulta',
          },
        };
      });
    } catch (err: unknown) {
      setCancellingBookingCode(null);
      showToast('Erro ao Cancelar Reserva', err instanceof Error ? err.message : String(err), 'warning');
    }
  };

  // Alternar comparação de roteiros
  const toggleCompareItinerary = (id: string) => {
    setCompareItineraryIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const operationalState = useMemo<OperationalStateSnapshot>(
    () => ({
      partners,
      vessels,
      tours,
      bookings,
      availabilityBlocks,
      auditLogs,
      changeHistory,
      isConnectedMode: isSupabaseConfigured,
      isDemoEnvironment: canUseDemoData,
      currentBrazilDate,
    }),
    [
      partners,
      vessels,
      tours,
      bookings,
      availabilityBlocks,
      auditLogs,
      changeHistory,
      canUseDemoData,
      currentBrazilDate,
    ]
  );

  const currentAuthContext = useMemo<OperationalAuthContext>(
    () => ({
      actorRole: roleMode,
      actorId:
        verifiedSession.userId ||
        authenticatedUserId ||
        (roleMode === 'admin' ? 'local-admin' : roleMode === 'partner' ? activePartner.id : 'local-tourist'),
      actorName:
        verifiedSession.fullName ||
        (roleMode === 'admin' ? 'Admin Master Rota Azul' : roleMode === 'partner' ? activePartner.name : 'Visitante'),
      actorPartnerId:
        roleMode === 'partner'
          ? verifiedSession.primaryPartnerId || activePartner.id
          : null,
      authorizedPartnerIds:
        verifiedSession.isAuthenticated && verifiedSession.authorizedPartnerIds.length > 0
          ? verifiedSession.authorizedPartnerIds
          : authorizedPartnerIds,
      isConnectedMode: isSupabaseConfigured,
      serverVerifiedRole: verifiedSession.isAuthenticated ? verifiedSession.serverRole : serverVerifiedRole,
      hasServerVerifiedSession: Boolean(authenticatedUserId || verifiedSession.isAuthenticated),
      verifiedSession: verifiedSession.isAuthenticated ? verifiedSession : null,
    }),
    [roleMode, authenticatedUserId, activePartner, authorizedPartnerIds, serverVerifiedRole, verifiedSession]
  );

  const applyOperationalStateSnapshot = (nextSnap: OperationalStateSnapshot) => {
    setPartners(nextSnap.partners);
    setVessels(nextSnap.vessels);
    setTours(nextSnap.tours);
    setBookings(nextSnap.bookings);
    setChangeHistory(nextSnap.changeHistory);
  };

  const adminDashboardMetrics = useMemo(() => {
    const adminCtx: OperationalAuthContext = {
      ...currentAuthContext,
      actorRole: 'admin',
      serverVerifiedRole: isSupabaseConfigured ? serverVerifiedRole : 'admin',
      hasServerVerifiedSession: isSupabaseConfigured ? Boolean(authenticatedUserId) : true,
    };
    const res = computeAdminDashboardMetrics(operationalState, adminCtx);
    return res.data || null;
  }, [operationalState, currentAuthContext, authenticatedUserId, serverVerifiedRole]);

  const handleAuthLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFeedback(null);
    const val = validateLoginInput({ email: loginEmailInput, password: loginPasswordInput });
    if (!val.ok || !val.data) {
      setAuthFeedback({ type: 'error', message: val.errorMessage || UNIFORM_LOGIN_FAILURE_MESSAGE });
      return;
    }
    setAuthLoading(true);
    try {
      if (isSupabaseConfigured) {
        const res = await loginWithEmailPassword(supabaseAuthAdapter, {
          email: val.data.email,
          password: loginPasswordInput,
        });
        setAuthLoading(false);
        if (!res.ok || !res.data) {
          setAuthFeedback({ type: 'error', message: res.errorMessage || UNIFORM_LOGIN_FAILURE_MESSAGE });
          return;
        }
        setVerifiedSession(res.data.session);
        setAuthenticatedUserId(res.data.session.userId);
        setAuthenticatedEmail(res.data.session.email);
        setServerVerifiedRole(res.data.session.serverRole);
        setAuthorizedPartnerIds(res.data.session.authorizedPartnerIds);
        setRoleMode(res.data.session.serverRole);
        if (res.data.session.primaryPartnerId) {
          setActivePartnerId(res.data.session.primaryPartnerId);
        }
        setLoginPasswordInput('');
        setAuthFeedback({ type: 'success', message: 'Sessão autenticada e verificada pelo servidor.' });
        return;
      }

      const cleanEmail = val.data.email;
      const matchedPartner = partners.find((p) => p.email.toLowerCase() === cleanEmail);
      const isAdminDemo = cleanEmail === 'admin@rotaazul.com.br';
      const resolvedRole: RoleMode = isAdminDemo ? 'admin' : matchedPartner ? 'partner' : 'tourist';
      const resolvedPartnerStage: PartnerOnboardingStage | null = matchedPartner
        ? matchedPartner.status === 'APROVADO'
          ? 'APROVADO'
          : matchedPartner.status === 'PENDENTE'
          ? 'PENDENTE'
          : 'SUSPENSO'
        : null;
      const nextAccState: AccountStateType = evaluateSessionAccountState({
        isAuthenticated: true,
        sessionTokenVerified: true,
        isActiveProfile: true,
        serverRole: resolvedRole,
        partnerStatus: matchedPartner?.status || null,
        partnerOnboardingStage: resolvedPartnerStage,
        hasPartnerLink: Boolean(matchedPartner),
      });
      const nextSession: VerifiedServerSessionContext = {
        isAuthenticated: true,
        accountState: nextAccState,
        userId: `usr-${Date.now()}`,
        email: cleanEmail,
        fullName: isAdminDemo ? 'Admin Rota Azul' : matchedPartner ? matchedPartner.name : cleanEmail.split('@')[0],
        serverRole: resolvedRole,
        isActiveProfile: true,
        primaryPartnerId: matchedPartner ? matchedPartner.id : null,
        authorizedPartnerIds: matchedPartner && matchedPartner.status === 'APROVADO' ? [matchedPartner.id] : [],
        partnerStatus: matchedPartner?.status || null,
        partnerOnboardingStage: resolvedPartnerStage,
        partnerRejectionReason: matchedPartner?.rejectionReason || null,
        sessionExpiresAt: Date.now() + 3600_000,
        sessionTokenVerified: true,
      };
      setVerifiedSession(nextSession);
      setRoleMode(resolvedRole);
      if (matchedPartner) setActivePartnerId(matchedPartner.id);
      setLoginPasswordInput('');
      setAuthLoading(false);
      setAuthFeedback({
        type: 'success',
        message: `Autenticado como ${nextSession.fullName} (${nextSession.serverRole} • ${nextSession.accountState}).`,
      });
    } catch {
      setAuthLoading(false);
      setAuthFeedback({ type: 'error', message: 'Falha de rede durante a autenticação.' });
    }
  };

  const handleAuthLogout = async () => {
    setAuthLoading(true);
    await logoutCurrentSession(supabaseAuthAdapter);
    setVerifiedSession(createUnauthenticatedSessionContext('UNAUTHENTICATED'));
    setAuthenticatedUserId(null);
    setAuthenticatedEmail(null);
    setServerVerifiedRole('tourist');
    setAuthorizedPartnerIds([]);
    setRoleMode('tourist');
    setActiveTab((prev) => (prev === 'admin-portal' || prev === 'partner-portal' ? 'home' : prev));
    setAuthLoading(false);
    setAuthFeedback({ type: 'info', message: 'Sessão encerrada com segurança.' });
  };

  const handleAuthRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFeedback(null);
    const val = validateRegistrationInput({
      fullName: regFullNameInput,
      email: regEmailInput,
      password: regPasswordInput,
      confirmPassword: regConfirmPasswordInput,
      acceptedTerms: regAcceptedTerms,
    });
    if (!val.ok || !val.data) {
      setAuthFeedback({ type: 'error', message: val.errorMessage || 'Dados de cadastro inválidos.' });
      return;
    }
    setAuthLoading(true);
    if (isSupabaseConfigured) {
      const res = await registerUserAccount(supabaseAuthAdapter, {
        fullName: val.data.fullName,
        email: val.data.email,
        password: regPasswordInput,
        confirmPassword: regConfirmPasswordInput,
        acceptedTerms: regAcceptedTerms,
      });
      setAuthLoading(false);
      if (!res.ok || !res.data) {
        setAuthFeedback({ type: 'error', message: res.errorMessage || 'Não foi possível concluir o cadastro.' });
        return;
      }
      setVerifiedSession(res.data.session);
      setRegPasswordInput('');
      setRegConfirmPasswordInput('');
      setAuthFeedback({ type: 'success', message: 'Cadastro concluído com perfil inicial tourist.' });
      return;
    }

    const nextSession: VerifiedServerSessionContext = {
      isAuthenticated: true,
      accountState: 'AUTHENTICATED_ACTIVE',
      userId: `usr-reg-${Date.now()}`,
      email: val.data.email,
      fullName: val.data.fullName,
      serverRole: 'tourist',
      isActiveProfile: true,
      primaryPartnerId: null,
      authorizedPartnerIds: [],
      partnerStatus: null,
      partnerOnboardingStage: null,
      partnerRejectionReason: null,
      sessionExpiresAt: Date.now() + 3600_000,
      sessionTokenVerified: true,
    };
    setVerifiedSession(nextSession);
    setRoleMode('tourist');
    setRegPasswordInput('');
    setRegConfirmPasswordInput('');
    setAuthLoading(false);
    setAuthFeedback({
      type: 'success',
      message: 'Conta criada com sucesso (perfil: tourist). Para credenciar uma empresa náutica, acesse a aba Onboarding de Parceiro.',
    });
  };

  const handleAuthRecoverySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFeedback(null);
    const val = validatePasswordRecoveryEmail(recoveryEmailInput);
    if (!val.ok || !val.data) {
      setAuthFeedback({ type: 'error', message: val.errorMessage || 'Informe um e-mail válido.' });
      return;
    }
    if (isSupabaseConfigured) {
      await requestPasswordRecovery(supabaseAuthAdapter, { email: val.data.email });
    }
    setAuthFeedback({ type: 'info', message: UNIFORM_RECOVERY_CONFIRMATION_MESSAGE });
  };

  const handleAuthResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFeedback(null);
    const val = validatePasswordResetPayload({
      recoveryToken: resetTokenInput,
      newPassword: resetNewPasswordInput,
      confirmNewPassword: resetConfirmPasswordInput,
    });
    if (!val.ok) {
      setAuthFeedback({ type: 'error', message: val.errorMessage || 'Dados de redefinição inválidos.' });
      return;
    }
    if (isSupabaseConfigured) {
      const res = await resetPasswordWithRecoveryToken(supabaseAuthAdapter, {
        recoveryToken: resetTokenInput,
        newPassword: resetNewPasswordInput,
        confirmNewPassword: resetConfirmPasswordInput,
      });
      if (!res.ok) {
        setAuthFeedback({ type: 'error', message: res.errorMessage || 'Token inválido ou expirado.' });
        return;
      }
    }
    setResetTokenInput('');
    setResetNewPasswordInput('');
    setResetConfirmPasswordInput('');
    setAuthFeedback({ type: 'success', message: 'Senha redefinida com sucesso. Faça login com sua nova credencial.' });
  };

  const handlePartnerOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthFeedback(null);
    if (isSupabaseConfigured) {
      const rpcRes = await rpcSubmitPartnerOnboardingApplication({
        companyName: onbCompanyName,
        legalName: onbLegalName,
        cnpj: onbCnpj,
        whatsapp: onbWhatsapp,
        businessEmail: onbBusinessEmail,
        baseMarina: onbBaseMarina,
        yearsOperating: onbYearsOperating,
        bio: onbBio,
      });
      if (!rpcRes.ok) {
        setAuthFeedback({ type: 'error', message: rpcRes.errorMessage || 'Falha no envio do onboarding.' });
        return;
      }
      const refreshed = await restoreAndVerifySession(supabaseAuthAdapter);
      if (refreshed.data) setVerifiedSession(refreshed.data);
      setAuthFeedback({ type: 'success', message: 'Solicitação de onboarding enviada como PENDENTE para análise administrativa.' });
      return;
    }

    const res = submitPartnerOnboardingInStore(
      onboardingStore,
      operationalState,
      verifiedSession,
      {
        companyName: onbCompanyName,
        legalName: onbLegalName,
        cnpj: onbCnpj,
        whatsapp: onbWhatsapp,
        businessEmail: onbBusinessEmail,
        baseMarina: onbBaseMarina,
        yearsOperating: onbYearsOperating,
        bio: onbBio,
      }
    );
    if (!res.ok || !res.data) {
      setAuthFeedback({ type: 'error', message: res.errorMessage || 'Verifique os dados da empresa.' });
      return;
    }
    setOnboardingStore(res.data.store);
    applyOperationalStateSnapshot(res.data.operationalState);
    setVerifiedSession(res.data.updatedSession);
    appendAuditLog('ONBOARDING_SUBMIT', res.data.onboarding.companyName, `Parceiro registrado como PENDENTE (${res.data.onboarding.partnerId})`);
    setAuthFeedback({
      type: 'success',
      message: `Empresa "${res.data.onboarding.companyName}" registrada como PENDENTE. O painel será liberado após aprovação administrativa.`,
    });
  };

  const handleAdminModerateOnboardingAction = async (
    partnerId: string,
    decision: 'EM_ANALISE' | 'APROVAR' | 'REJEITAR' | 'SUSPENDER',
    reason?: string
  ) => {
    if (isSupabaseConfigured) {
      const rpcRes = await rpcAdminModeratePartnerOnboarding({ partnerId, decision, reason });
      if (!rpcRes.ok) {
        showToast('Deliberação Recusada', rpcRes.errorMessage || 'Sem permissão administrativa.', 'warning');
        return;
      }
      showToast('Onboarding Atualizado no Servidor', `Decisão ${decision} aplicada.`, 'success');
      return;
    }

    const adminVerifiedSession: VerifiedServerSessionContext =
      verifiedSession.isAuthenticated && verifiedSession.serverRole === 'admin'
        ? verifiedSession
        : {
            isAuthenticated: true,
            accountState: 'AUTHENTICATED_ACTIVE',
            userId: 'admin-local-1',
            email: 'admin@rotaazul.com.br',
            fullName: 'Admin Master',
            serverRole: 'admin',
            isActiveProfile: true,
            primaryPartnerId: null,
            authorizedPartnerIds: partners.map((p) => p.id),
            partnerStatus: 'APROVADO',
            partnerOnboardingStage: 'APROVADO',
            partnerRejectionReason: null,
            sessionExpiresAt: Date.now() + 3600_000,
            sessionTokenVerified: true,
          };

    const res = adminModeratePartnerOnboardingInStore(
      onboardingStore,
      operationalState,
      adminVerifiedSession,
      partnerId,
      decision,
      reason || 'Deliberação de onboarding pela administração Rota Azul'
    );
    if (!res.ok || !res.data) {
      showToast('Falha na Deliberação de Onboarding', res.errorMessage || 'Verifique os dados.', 'warning');
      return;
    }
    setOnboardingStore(res.data.store);
    applyOperationalStateSnapshot(res.data.operationalState);
    if (verifiedSession.primaryPartnerId === partnerId) {
      setVerifiedSession((prev) => ({
        ...prev,
        partnerStatus: res.data!.onboarding.status,
        partnerOnboardingStage: res.data!.onboarding.onboardingStage,
        partnerRejectionReason: res.data!.onboarding.rejectionReason,
        authorizedPartnerIds: decision === 'APROVAR' ? [partnerId] : [],
        accountState:
          decision === 'APROVAR'
            ? 'AUTHENTICATED_ACTIVE'
            : decision === 'EM_ANALISE'
            ? 'PARTNER_PENDING_APPROVAL'
            : decision === 'REJEITAR'
            ? 'PARTNER_REJECTED'
            : 'PARTNER_SUSPENDED',
      }));
    }
    showToast('Onboarding Deliberado!', `Parceiro ${res.data.onboarding.companyName}: ${decision}.`, 'success');
  };

  const verifiedOperationalContext = useMemo(
    () => buildVerifiedOperationalAuthContext(verifiedSession),
    [verifiedSession]
  );
  const adminFinancialSummary = useMemo(() => {
    const adminCtx: OperationalAuthContext = {
      ...currentAuthContext,
      actorRole: 'admin',
      serverVerifiedRole: isSupabaseConfigured ? serverVerifiedRole : 'admin',
      hasServerVerifiedSession: isSupabaseConfigured ? Boolean(authenticatedUserId) : true,
    };
    const res = computeAdminFinancialSummary(operationalState, financialStore, adminCtx);
    return res.data || null;
  }, [operationalState, financialStore, currentAuthContext, authenticatedUserId, serverVerifiedRole]);

  const activePartnerFinancialSummary = useMemo(() => {
    if (!activePartner.id) return null;
    const partnerCtx: OperationalAuthContext = {
      ...currentAuthContext,
      actorRole: roleMode === 'tourist' ? 'partner' : roleMode,
      actorPartnerId: activePartner.id,
      authorizedPartnerIds:
        authorizedPartnerIds.length > 0 ? authorizedPartnerIds : [activePartner.id],
    };
    const res = computePartnerFinancialSummary(
      operationalState,
      financialStore,
      partnerCtx,
      activePartner.id
    );
    return res.data || null;
  }, [operationalState, financialStore, currentAuthContext, activePartner, roleMode, authorizedPartnerIds]);

  const financialReconciliationReport = useMemo(() => {
    const adminCtx: OperationalAuthContext = {
      ...currentAuthContext,
      actorRole: 'admin',
      serverVerifiedRole: isSupabaseConfigured ? serverVerifiedRole : 'admin',
      hasServerVerifiedSession: isSupabaseConfigured ? Boolean(authenticatedUserId) : true,
    };
    const res = runFinancialReconciliation(operationalState, financialStore, adminCtx, null);
    return res.data || null;
  }, [operationalState, financialStore, currentAuthContext, authenticatedUserId, serverVerifiedRole]);

  const handleInitiateBookingPayment = async (
    bookingId: string,
    paymentMethod: PaymentMethodType = 'PIX'
  ) => {
    const idempKey = `pay-init-${bookingId}-${paymentMethod.toLowerCase()}`;
    if (isSupabaseConfigured) {
      const rpcRes = await rpcCreateOrInitiateBookingPayment({
        bookingId,
        paymentMethod,
        idempotencyKey: idempKey,
        externalPaymentReference: `ref-${bookingId}`,
      });
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Falha ao Iniciar Pagamento', rpcRes.error, 'warning');
        return;
      }
    }
    const res = initiateBookingPayment(operationalState, financialStore, currentAuthContext, {
      bookingId,
      paymentMethod,
      idempotencyKey: idempKey,
      externalPaymentReference: `ref-${bookingId}`,
    });
    if (!res.ok || !res.data) {
      showToast('Operação Financeira Recusada', res.errorMessage || 'Verifique os dados da reserva.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      res.data.idempotentReplay ? 'Pagamento Já Iniciado (Idempotente)' : 'Pagamento Iniciado!',
      `Reserva ${res.data.payment.bookingCode}: ${res.data.payment.paymentMethod} (${res.data.payment.paymentStatus}).`,
      'info'
    );
  };

  const handleTransitionBookingPayment = async (
    bookingId: string,
    targetStatus: 'PROCESSANDO' | 'PAGO' | 'FALHOU' | 'CANCELADO',
    reason?: string
  ) => {
    const effectiveReason =
      reason ||
      (targetStatus === 'PAGO'
        ? 'Conciliação administrativa verificada pelo operador financeiro'
        : `Transição financeira para ${targetStatus}`);
    const txId = targetStatus === 'PAGO' ? `tx-adm-${bookingId}-${Date.now().toString().slice(-6)}` : null;
    const idempKey = `pay-tr-${bookingId}-${targetStatus.toLowerCase()}-${Date.now()}`;

    if (isSupabaseConfigured) {
      const rpcRes = await rpcConfirmOrFailBookingPayment({
        bookingId,
        targetStatus,
        idempotencyKey: idempKey,
        externalTransactionId: txId,
        reason: effectiveReason,
        markBookingCancelled: targetStatus === 'CANCELADO',
        confirmationOrigin: 'MANUAL_ADMIN',
      });
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Transição Financeira Bloqueada pelo Servidor', rpcRes.error, 'warning');
        return;
      }
    }

    const res = transitionBookingPaymentStatus(operationalState, financialStore, currentAuthContext, {
      bookingId,
      targetStatus,
      idempotencyKey: idempKey,
      externalTransactionId: txId,
      reason: effectiveReason,
      markBookingCancelled: targetStatus === 'CANCELADO',
      confirmationOrigin: 'MANUAL_ADMIN',
    });
    if (!res.ok || !res.data) {
      showToast('Transição Financeira Bloqueada', res.errorMessage || 'Permissão insuficiente ou transição inválida.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      `Pagamento: ${res.data.payment.paymentStatus}`,
      `Reserva ${res.data.booking.code} atualizada com sucesso.`,
      res.data.payment.paymentStatus === 'PAGO' ? 'success' : 'info'
    );
  };

  const handleRequestBookingRefund = async (
    bookingId: string,
    reason: string,
    requestedRefundAmount?: number
  ) => {
    const idempKey = `ref-req-${bookingId}-${requestedRefundAmount ?? 'full'}`;
    if (isSupabaseConfigured) {
      const rpcRes = await rpcRequestBookingRefund({
        bookingId,
        reason,
        idempotencyKey: idempKey,
        requestedRefundAmount: requestedRefundAmount ?? null,
      });
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Solicitação de Estorno Recusada', rpcRes.error, 'warning');
        return;
      }
    }
    const res = requestBookingRefund(operationalState, financialStore, currentAuthContext, {
      bookingId,
      reason,
      idempotencyKey: idempKey,
      requestedRefundAmount: requestedRefundAmount ?? null,
    });
    if (!res.ok || !res.data) {
      showToast('Solicitação de Estorno Recusada', res.errorMessage || 'Não foi possível registrar o pedido de estorno.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      'Estorno Solicitado (ESTORNO_PENDENTE)',
      `Reserva ${res.data.payment.bookingCode}: R$ ${res.data.requestedRefundAmount.toFixed(2)} aguardando confirmação administrativa.`,
      'info'
    );
  };

  const handleConfirmBookingRefund = async (
    bookingId: string,
    reason: string,
    refundAmount?: number
  ) => {
    const idempKey = `ref-proc-${bookingId}-${refundAmount ?? 'full'}-${Date.now()}`;
    if (isSupabaseConfigured) {
      const rpcRes = await rpcProcessBookingRefund({
        bookingId,
        refundAmount: refundAmount ?? null,
        reason,
        idempotencyKey: idempKey,
        markBookingCancelled: refundAmount === undefined,
      });
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Confirmação de Estorno Bloqueada', rpcRes.error, 'warning');
        return;
      }
    }
    const res = processBookingRefund(operationalState, financialStore, currentAuthContext, {
      bookingId,
      refundAmount: refundAmount ?? null,
      reason,
      idempotencyKey: idempKey,
      markBookingCancelled: refundAmount === undefined,
    });
    if (!res.ok || !res.data) {
      showToast('Confirmação de Estorno Bloqueada', res.errorMessage || 'Somente o Administrador pode confirmar estornos.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      `Estorno Confirmado (${res.data.payment.paymentStatus})`,
      `Reserva ${res.data.booking.code}: estornado R$ ${res.data.refundedNowAmount.toFixed(2)} | Comissão revertida: R$ ${res.data.reversedCommissionNowAmount.toFixed(2)}.`,
      'success'
    );
  };

  const handleRevertFailedBookingRefund = async (bookingId: string, reason: string) => {
    const idempKey = `ref-fail-rev-${bookingId}-${Date.now()}`;
    if (isSupabaseConfigured) {
      const currentPay = financialStore.payments.find((p) => p.bookingId === bookingId);
      const revertTarget: 'PAGO' | 'ESTORNO_PARCIAL' =
        currentPay && currentPay.refundedGrossAmount > 0 ? 'ESTORNO_PARCIAL' : 'PAGO';
      const rpcRes = await rpcConfirmOrFailBookingPayment({
        bookingId,
        targetStatus: revertTarget,
        idempotencyKey: idempKey,
        reason,
        confirmationOrigin: 'MANUAL_ADMIN',
      });
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Falha ao Restaurar Pagamento no Servidor', rpcRes.error, 'warning');
        return;
      }
    }
    const res = revertFailedPendingRefund(operationalState, financialStore, currentAuthContext, {
      bookingId,
      idempotencyKey: idempKey,
      reason,
    });
    if (!res.ok || !res.data) {
      showToast('Falha ao Restaurar Pagamento', res.errorMessage || 'Permissão insuficiente.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      `Estorno Revertido -> ${res.data.payment.paymentStatus}`,
      `Pagamento da reserva ${res.data.booking.code} restaurado após falha no gateway.`,
      'info'
    );
  };

  const handleSettleBookingCommission = async (bookingId: string) => {
    const notes = 'Repasse líquido e comissão liquidados pelo Admin Master';
    if (isSupabaseConfigured) {
      const rpcRes = await rpcSettleCommissionLedger(bookingId, notes);
      if (rpcRes.executedOnServer && rpcRes.error) {
        showToast('Liquidação Bloqueada pelo Servidor', rpcRes.error, 'warning');
        return;
      }
    }
    const res = settleBookingCommissionInStore(operationalState, financialStore, currentAuthContext, {
      bookingId,
      adjustmentNotes: notes,
    });
    if (!res.ok || !res.data) {
      showToast('Liquidação Bloqueada', res.errorMessage || 'Exige passeio realizado e pagamento confirmado.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.operationalState);
    setFinancialStore(res.data.financialStore);
    showToast(
      'Comissão e Repasse Liquidados (PAGA)',
      `Reserva ${res.data.booking.code} marcada como PAGA no livro-razão.`,
      'success'
    );
  };

  const handleAdminCreatePartner = (e: React.FormEvent) => {
    e.preventDefault();
    const res = createPartnerOperation(operationalState, currentAuthContext, {
      name: newPartnerName,
      legalName: newPartnerLegalName || `${newPartnerName.trim()} Turismo Náutico LTDA`,
      cnpj: newPartnerCnpj,
      whatsapp: newPartnerWhatsapp,
      email: newPartnerEmail || `contato@${newPartnerName.trim().toLowerCase().replace(/[^a-z0-9]/g, '') || 'parceiro'}.com.br`,
      baseMarina: newPartnerMarina,
      bio: newPartnerBio,
      status: 'PENDENTE',
      isActive: true,
    });
    if (!res.ok || !res.data) {
      showToast('Erro ao Cadastrar Parceiro', res.errorMessage || 'Verifique os campos obrigatórios.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    appendAuditLog('CREATE_PARTNER', res.data.partner.name, `Parceiro cadastrado com CNPJ ${res.data.partner.cnpj} (${res.data.partner.status})`);
    setNewPartnerName('');
    setNewPartnerLegalName('');
    setNewPartnerCnpj('');
    setNewPartnerEmail('');
    setNewPartnerBio('');
    showToast('Parceiro Cadastrado!', `${res.data.partner.name} registrado para homologação.`, 'success');
  };

  const handleModeratePartner = (
    partnerId: string,
    decision: 'APROVAR' | 'REJEITAR' | 'SUSPENDER' | 'ATIVAR' | 'DESATIVAR',
    reason?: string
  ) => {
    const res = moderatePartnerRegistrationOperation(
      operationalState,
      currentAuthContext,
      partnerId,
      decision,
      reason || 'Deliberação operacional da administração Rota Azul'
    );
    if (!res.ok || !res.data) {
      showToast('Operação Não Autorizada', res.errorMessage || 'Falha na moderação do parceiro.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    if (verifiedSession.isAuthenticated && verifiedSession.primaryPartnerId === partnerId) {
      setVerifiedSession((prev) => revalidateSessionAgainstPartnerState(prev, res.data!.state.partners));
    }
    appendAuditLog(`PARTNER_${decision}`, res.data.partner.name, `Status=${res.data.partner.status}, Ativo=${res.data.partner.isActive}`);
    showToast('Situação do Parceiro Atualizada', `${res.data.partner.name}: ${decision}.`, 'info');
  };

  const handleSavePartnerEdit = (partnerId: string) => {
    const res = updatePartnerOperation(operationalState, currentAuthContext, partnerId, {
      whatsapp: editPartnerPhone || undefined,
      email: editPartnerEmail || undefined,
      baseMarina: editPartnerMarina || undefined,
      bio: editPartnerBio || undefined,
    });
    if (!res.ok || !res.data) {
      showToast('Falha ao Atualizar Parceiro', res.errorMessage || 'Verifique os dados informados.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    setEditingPartnerId(null);
    appendAuditLog('UPDATE_PARTNER', res.data.partner.name, 'Dados operacionais atualizados');
    showToast('Parceiro Atualizado!', `Informações de ${res.data.partner.name} salvas.`, 'success');
  };

  const handleOperationalUpdateVessel = (
    vesselId: string,
    patch: { capacity?: number; isActive?: boolean; availabilityStatus?: VesselOperationalStatus; operationMode?: 'Privativo' | 'Compartilhado' | 'Ambos' }
  ) => {
    const res = updateVesselOperation(operationalState, currentAuthContext, vesselId, patch);
    if (!res.ok || !res.data) {
      showToast('Alteração de Embarcação Bloqueada', res.errorMessage || 'Verifique a capacidade comprometida.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    appendAuditLog('UPDATE_VESSEL', res.data.vessel.name, `Capacidade=${res.data.vessel.capacity}, Status=${res.data.vessel.availabilityStatus || 'DISPONIVEL'}`);
    showToast('Embarcação Atualizada', `${res.data.vessel.name} atualizada com sucesso.`, 'info');
  };

  const handleOperationalUpdateTour = (
    tourId: string,
    patch: {
      price?: number;
      capacity?: number;
      durationHours?: number;
      checkInTime?: string;
      departureTime?: string;
      returnTime?: string;
      status?: Tour['status'];
      isActive?: boolean;
    }
  ) => {
    const res = updateTourOperation(operationalState, currentAuthContext, tourId, patch);
    if (!res.ok || !res.data) {
      showToast('Alteração de Passeio Bloqueada', res.errorMessage || 'Dados inválidos ou sem permissão.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    appendAuditLog('UPDATE_TOUR', res.data.tour.title, `Status=${res.data.tour.status}, Ativo=${res.data.tour.isActive !== false}, R$ ${res.data.tour.price}`);
    showToast('Passeio Atualizado', `${res.data.tour.title} atualizado.`, 'info');
  };

  const handleOperationalSafeDeleteTour = (tourId: string) => {
    const res = deleteTourSafelyOperation(operationalState, currentAuthContext, tourId);
    if (!res.ok || !res.data) {
      setConfirmDeleteTourId(null);
      showToast('Exclusão Bloqueada por Integridade', res.errorMessage || 'Passeio possui reservas vinculadas.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    setConfirmDeleteTourId(null);
    appendAuditLog('DELETE_TOUR_SAFE', tourId, 'Passeio sem reservas excluído com segurança');
    showToast('Passeio Excluído', 'O passeio sem vínculos históricos foi removido.', 'info');
  };

  const handlePartnerCreateVessel = (e: React.FormEvent) => {
    e.preventDefault();
    const targetOwnerId = roleMode === 'admin' ? (newVesselPartnerSelect || activePartner.id) : activePartner.id;
    const ownerPartner = partners.find((p) => p.id === targetOwnerId) || activePartner;
    const res = createVesselOperation(operationalState, currentAuthContext, {
      name: newVesselName,
      partnerId: ownerPartner.id,
      type: newVesselType,
      operationMode: newVesselOperationMode,
      capacity: Number(newVesselCapacity) || 10,
      lengthFeet: Number(newVesselFeet) || 28,
      engineSpec: newVesselEngine.trim() || 'Motorização Marítima Homologada',
      baseLocation: ownerPartner.baseMarina || 'Saco da Ribeira',
      heroImage: newVesselType === 'Escuna' ? IMG_ESCUNA : IMG_LANCHA,
    });
    if (!res.ok || !res.data) {
      showToast('Erro no Cadastro da Embarcação', res.errorMessage || 'Verifique os campos obrigatórios.', 'warning');
      return;
    }
    applyOperationalStateSnapshot(res.data.state);
    setNewTourVesselId(res.data.vessel.id);
    setNewVesselName('');
    appendAuditLog('CREATE_VESSEL', res.data.vessel.name, `Nova embarcação cadastrada para ${ownerPartner.name}`);
    showToast('Embarcação Cadastrada!', `${res.data.vessel.name} adicionada à frota de ${ownerPartner.name}.`, 'success');
  };

  // Adicionar novo passeio pelo Parceiro ou Admin via camada operacional validada (Seção 3.3)
  const handlePartnerCreateTour = (e: React.FormEvent) => {
    e.preventDefault();
    const targetOwnerId = roleMode === 'admin' ? (newTourPartnerSelect || activePartner.id) : activePartner.id;
    const ownerPartner = partners.find((p) => p.id === targetOwnerId) || activePartner;
    const partnerVesselsList = vessels.filter((v) => v.partnerId === ownerPartner.id);
    if (partnerVesselsList.length === 0) {
      showToast(
        'Cadastre uma Embarcação Primeiro',
        `O parceiro "${ownerPartner.name}" precisa possuir pelo menos uma embarcação própria antes de cadastrar passeios.`,
        'warning'
      );
      return;
    }

    const partnerVessel =
      partnerVesselsList.find((v) => v.id === newTourVesselId) || partnerVesselsList[0];
    const targetDest = destinations.find((d) => d.id === newTourDestinationId) || destinations[0];

    const res = createTourOperation(operationalState, currentAuthContext, {
      title: newTourTitle,
      vesselId: partnerVessel.id,
      partnerId: ownerPartner.id,
      tourType: newTourType,
      price: Number(newTourPrice) || 250,
      capacity: Math.min(Number(newTourCapacityInput) || partnerVessel.capacity, partnerVessel.capacity),
      durationHours: Number(newTourDurationHours) || 5.5,
      checkInTime: newTourCheckInTime || '09:00',
      departureTime: newTourDepartureTime || '09:30',
      returnTime: newTourReturnTime || '15:00',
      departurePoint: newTourDeparture,
      itineraryId: targetDest?.region === 'Sul' ? 'itin-sul-anchieta' : 'itin-ilhas-norte',
      destinationsVisited: targetDest ? [targetDest.id] : ['dest-ilha-couves'],
      importantInfo: [newTourRulesInput.trim() || `Embarque em ${newTourDeparture}.`],
      status: roleMode === 'admin' ? 'APROVADO' : 'PENDENTE_APROVACAO',
      heroImage: partnerVessel.heroImage,
    });

    if (!res.ok || !res.data) {
      showToast('Erro ao Cadastrar Passeio', res.errorMessage || 'Verifique os horários, preço e capacidade.', 'warning');
      return;
    }

    applyOperationalStateSnapshot(res.data.state);
    setNewTourTitle('');
    appendAuditLog('CREATE_TOUR', res.data.tour.title, `Passeio criado para ${ownerPartner.name} na embarcação ${partnerVessel.name}`);
    showToast(
      roleMode === 'admin' ? 'Passeio Publicado no Catálogo!' : 'Passeio Enviado para Aprovação!',
      `Vinculado à embarcação "${partnerVessel.name}" (${res.data.tour.departureTime}–${res.data.tour.returnTime}).`,
      'success'
    );
  };

  const handleAddAvailabilityBlock = (e: React.FormEvent) => {
    e.preventDefault();
    const partnerVesselsList = vessels.filter((v) => v.partnerId === activePartner.id);
    const targetVessel = partnerVesselsList.find((v) => v.id === blockVesselId) || partnerVesselsList[0];
    if (!targetVessel || !blockDateInput) return;

    const defaultAdjustedCapacity =
      blockTypeInput === 'AJUSTE_CAPACIDADE'
        ? Math.max(1, Math.min(targetVessel.capacity, Math.floor(targetVessel.capacity * 0.75)))
        : undefined;

    const newBlock: AvailabilityBlock = {
      id: `blk-${Date.now()}`,
      partnerId: activePartner.id,
      vesselId: targetVessel.id,
      vesselName: targetVessel.name,
      blockDate: blockDateInput,
      blockType: blockTypeInput,
      adjustedCapacity: defaultAdjustedCapacity,
      reason: blockReasonInput.trim() || 'Bloqueio operacional agendado pelo parceiro'
    };

    const applyBlockState = (confirmedBlock: AvailabilityBlock) => {
      setAvailabilityBlocks((prev) => mergeAvailabilityBlockList(prev, confirmedBlock));
      setBlockReasonInput('');
      appendAuditLog('BLOCK_DATE', `${targetVessel.name} (${blockDateInput})`, `${blockTypeInput}: ${confirmedBlock.reason}`);
      showToast('Data Bloqueada na Agenda!', `${targetVessel.name} bloqueada para ${blockDateInput}.`, 'info');
    };

    if (isSupabaseConfigured) {
      rpcUpsertAvailabilityBlock({
        vesselId: targetVessel.id,
        blockDate: blockDateInput,
        blockType: blockTypeInput,
        reason: newBlock.reason,
        customCapacityOverride: newBlock.adjustedCapacity ?? null,
      })
        .then((rpcRes) => {
          if (rpcRes.executedOnServer && rpcRes.error) {
            showToast('Bloqueio Rejeitado pelo Servidor', rpcRes.error, 'warning');
            return;
          }
          if (rpcRes.executedOnServer && rpcRes.data) {
            applyBlockState({
              ...newBlock,
              id: rpcRes.data.id || newBlock.id,
              blockDate: rpcRes.data.block_date || newBlock.blockDate,
              blockType: rpcRes.data.block_type || newBlock.blockType,
              adjustedCapacity:
                rpcRes.data.custom_capacity_override != null
                  ? Number(rpcRes.data.custom_capacity_override)
                  : newBlock.adjustedCapacity,
              reason: rpcRes.data.reason || newBlock.reason,
            });
            return;
          }
          applyBlockState(newBlock);
        })
        .catch((err: unknown) => {
          showToast('Erro ao Sincronizar Bloqueio', err instanceof Error ? err.message : String(err), 'warning');
        });
      return;
    }

    applyBlockState(newBlock);
  };

  const handleRemoveAvailabilityBlock = (blockId: string) => {
    const targetBlock = availabilityBlocks.find((b) => b.id === blockId);
    if (!targetBlock) return;

    const finalizeRemoveBlock = () => {
      setAvailabilityBlocks((prev) => prev.filter((b) => b.id !== blockId));
      appendAuditLog('UNBLOCK_DATE', `${targetBlock.vesselName} (${targetBlock.blockDate})`, `Bloqueio removido (${targetBlock.blockType})`);
      showToast('Bloqueio Removido da Agenda', `${targetBlock.vesselName} liberada em ${targetBlock.blockDate}.`, 'info');
    };

    if (isSupabaseConfigured) {
      rpcDeleteAvailabilityBlock(blockId)
        .then((rpcRes) => {
          if (rpcRes.executedOnServer && rpcRes.error) {
            showToast('Remoção de Bloqueio Rejeitada', rpcRes.error, 'warning');
            return;
          }
          finalizeRemoveBlock();
        })
        .catch((err: unknown) => {
          showToast('Erro ao Remover Bloqueio', err instanceof Error ? err.message : String(err), 'warning');
        });
      return;
    }

    finalizeRemoveBlock();
  };

  const handleMediaFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setNewMediaCustomUrl(reader.result);
        showToast('Arquivo Carregado!', `Mídia "${file.name}" pronta para publicação.`, 'info');
      }
    };
    reader.readAsDataURL(file);
  };

  // Adicionar ou substituir mídia no Gerenciador Dinâmico
  const handleAddMediaAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMediaTitle.trim()) return;

    const finalUrl = newMediaCustomUrl.trim() || newMediaPresetUrl;
    let entityName = 'Ubatuba';

    if (newMediaCategory === 'Destino') {
      const dest = destinations.find((d) => d.id === newMediaTargetId);
      entityName = dest ? dest.name : 'Destino Ubatuba';
      if (newMediaReplaceHero && dest) {
        setDestinations((prev) =>
          prev.map((d) => (d.id === dest.id ? { ...d, heroImage: finalUrl, gallery: [finalUrl, ...d.gallery] } : d))
        );
      }
    } else if (newMediaCategory === 'Embarcação') {
      const ves = vessels.find((v) => v.id === newMediaTargetId) || vessels[0];
      entityName = ves ? ves.name : 'Embarcação';
      if (newMediaReplaceHero && ves) {
        setVessels((prev) =>
          prev.map((v) => (v.id === ves.id ? { ...v, heroImage: finalUrl, gallery: [finalUrl, ...v.gallery] } : v))
        );
      }
    } else {
      const tr = tours.find((t) => t.id === newMediaTargetId) || tours[0];
      entityName = tr ? tr.title : 'Passeio Náutico';
      if (newMediaReplaceHero && tr) {
        setTours((prev) =>
          prev.map((t) => (t.id === tr.id ? { ...t, heroImage: finalUrl, gallery: [finalUrl, ...t.gallery] } : t))
        );
      }
    }

    const created: MediaAsset = {
      id: `med-${Date.now()}`,
      title: newMediaTitle.trim(),
      type: newMediaType,
      url: finalUrl,
      videoPreviewDuration: newMediaType === 'video' ? '02:30' : undefined,
      category: newMediaCategory,
      linkedEntityId: newMediaTargetId,
      linkedEntityName: entityName,
      partnerId: roleMode === 'admin' ? 'PLATFORM' : activePartner.id,
      partnerName: roleMode === 'admin' ? 'Acervo Oficial Ubatuba' : activePartner.name,
      authorized: true,
      isProvisional: false,
      createdAt: new Date().toISOString().slice(0, 10)
    };

    setMediaAssets((prev) => [created, ...prev]);
    setNewMediaTitle('');
    setNewMediaCustomUrl('');
    appendAuditLog('UPLOAD_MEDIA', created.title, `Mídia (${created.category}) vinculada a ${entityName}`);
    showToast(
      'Mídia Cadastrada com Controle de Propriedade!',
      `Vinculada a "${created.linkedEntityName}" sob titularidade de ${created.partnerName}.`,
      'success'
    );
  };

  const handleCreateVerifiedReview = (e: React.FormEvent) => {
    e.preventDefault();
    const bk = bookings.find((b) => b.id === reviewBookingId);
    if (!bk || normalizeBookingStatus(bk.status) !== 'PASSEIO_REALIZADO') return;
    if (!newReviewComment.trim()) return;
    if (reviews.some((r) => r.verifiedBookingCode === bk.code)) {
      showToast('Avaliação Já Registrada', `A reserva ${bk.code} já possui uma avaliação verificada publicada.`, 'warning');
      return;
    }
    const createdRev: ReviewItem = {
      id: `rev-${Date.now()}`,
      tourId: bk.tourId,
      tourTitle: bk.tourTitle,
      partnerId: bk.partnerId,
      author: newReviewAuthor.trim() || bk.customerName,
      city: newReviewCity.trim() || 'Visitante Verificado',
      rating: newReviewRating,
      date: new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }),
      comment: newReviewComment.trim(),
      verifiedBookingCode: bk.code
    };

    const finalizeReviewState = (revItem: ReviewItem) => {
      setReviews((prev) => [revItem, ...prev]);
      setReviewBookingId(null);
      setNewReviewComment('');
      appendAuditLog('CREATE_REVIEW', bk.code, `Avaliação ${newReviewRating} estrelas enviada por ${revItem.author}`);
      showToast('Avaliação Verificada Publicada!', `Obrigado! Seu depoimento com código ${bk.code} já está na vitrine.`, 'success');
    };

    if (isSupabaseConfigured) {
      rpcCreateVerifiedReview({
        bookingId: bk.id,
        rating: newReviewRating,
        comment: newReviewComment.trim(),
        reviewerName: createdRev.author,
        reviewerCity: createdRev.city
      })
        .then((rpcRes) => {
          if (rpcRes.executedOnServer && rpcRes.error) {
            showToast('Avaliação Não Autorizada pelo Servidor', rpcRes.error, 'warning');
            return;
          }
          if (rpcRes.executedOnServer && rpcRes.data && typeof rpcRes.data.id === 'string') {
            finalizeReviewState({ ...createdRev, id: rpcRes.data.id });
            return;
          }
          finalizeReviewState(createdRev);
        })
        .catch((err: unknown) => {
          showToast('Erro ao Publicar Avaliação', err instanceof Error ? err.message : String(err), 'warning');
        });
      return;
    }

    finalizeReviewState(createdRev);
  };

  const handleResetDatabase = () => {
    if (!canUseDemoData) {
      showToast('Ação Bloqueada', 'Restauração de dados demonstrativos é proibida neste ambiente.', 'warning');
      return;
    }
    setPartners(INITIAL_PARTNERS);
    setDestinations(INITIAL_DESTINATIONS);
    setVessels(INITIAL_VESSELS);
    setTours(INITIAL_TOURS);
    setMediaAssets(INITIAL_MEDIA_ASSETS);
    setBookings(INITIAL_BOOKINGS);
    setReviews(INITIAL_REVIEWS);
    setAvailabilityBlocks(INITIAL_AVAILABILITY_BLOCKS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setFinancialStore(seedInitialDemoFinancialStore(INITIAL_BOOKINGS));
    showToast('Banco Restaurado!', 'Todos os dados voltaram ao estado original de fábrica.', 'info');
  };

  if (runtimeGuard.isConfigurationUnavailable) {
    return (
      <div className="min-h-screen bg-[#061829] text-slate-100 flex items-center justify-center p-6">
        <div className="max-w-lg w-full rounded-3xl bg-slate-900/90 border border-cyan-500/30 p-8 shadow-2xl text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
            <Shield className="w-7 h-7" />
          </div>
          <h1 className="text-xl font-extrabold tracking-tight text-white">
            Serviço Temporariamente Indisponível
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            O ambiente está operando com proteção comercial ativa e aguarda a configuração válida do serviço de dados para exibir reservas, parceiros e disponibilidade real.
          </p>
          <p className="text-xs text-slate-400">
            Nenhum dado demonstrativo ou fictício é exibido neste modo.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FBF8F3] text-slate-900 font-sans selection:bg-cyan-500 selection:text-white">
      {/* TOAST DE FEEDBACK EM TEMPO REAL */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-md bg-slate-900 text-white px-5 py-4 rounded-2xl shadow-2xl border border-cyan-500/40 flex items-start gap-3 transition-all duration-200">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 shrink-0 mt-0.5">
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <Info className="w-5 h-5" />}
          </div>
          <div className="flex-1 text-sm">
            <p className="font-bold text-white">{toast.title}</p>
            <p className="text-slate-300 mt-0.5 leading-relaxed">{toast.message}</p>
          </div>
          <button
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-white p-1"
            aria-label="Fechar notificação"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* BARRA SUPERIOR DE AMBIENTE SAAS (SIMULADOR DE PERFIS / RLS MULTI-TENANT) */}
      <div className="bg-[#061829] text-slate-200 text-xs border-b border-cyan-900/40 px-4 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
              <Sparkles className="w-3.5 h-3.5" /> Marketplace Multi-Parceiros Ubatuba/SP
            </span>
            <span className="hidden md:inline text-slate-400">
              Conectando turistas a proprietários de lanchas, escunas e operadores credenciados
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-400 font-medium">
              {isSupabaseConfigured
                ? `Sessão Conectada (${authenticatedEmail || 'Visitante'} — ${serverVerifiedRole})`
                : 'Modo Demonstração Local (Offline):'}
            </span>
            {remoteLoading && (
              <span className="px-2 py-0.5 rounded bg-cyan-900/60 text-cyan-200">Sincronizando Supabase...</span>
            )}
            {remoteSyncError && (
              <span className="px-2 py-0.5 rounded bg-rose-900/70 text-rose-200">Erro Servidor: {remoteSyncError}</span>
            )}
            <button
              onClick={() => {
                navigateToTab('home', 'tourist');
              }}
              className={`px-2.5 py-1 rounded-lg font-medium transition ${
                roleMode === 'tourist' && activeTab !== 'architecture-seo'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Turista / Visitante
            </button>
            <button
              onClick={() => {
                navigateToTab('partner-portal', 'partner');
              }}
              className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                roleMode === 'partner' && activeTab === 'partner-portal'
                  ? 'bg-emerald-400 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Anchor className="w-3 h-3" /> Painel do Parceiro
            </button>
            <button
              onClick={() => {
                navigateToTab('admin-portal', 'admin');
              }}
              className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                roleMode === 'admin' && activeTab === 'admin-portal'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Shield className="w-3 h-3" /> Admin Master
            </button>
            <button
              onClick={() => navigateToTab('architecture-seo')}
              className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                activeTab === 'architecture-seo'
                  ? 'bg-sky-400 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Code2 className="w-3 h-3" /> Supabase SQL & SEO
            </button>
          </div>
        </div>
      </div>

      {/* HEADER PRINCIPAL DE NAVEGAÇÃO */}
      <header className="sticky top-0 z-40 bg-[#0A2540]/95 backdrop-blur-md text-white border-b border-white/10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Logo */}
          <button
            onClick={() => {
              setSelectedDestinationId(null);
              setSelectedTourId(null);
              setSelectedVesselId(null);
              setActiveTab('home');
            }}
            className="flex items-center gap-3 text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-600 flex items-center justify-center shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <Compass className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight text-white">UBATUBA</span>
                <span className="font-extrabold text-lg tracking-tight text-cyan-400">MAR & PRAIAS</span>
              </div>
              <p className="text-[11px] text-cyan-200/80 uppercase tracking-widest font-medium">
                Marketplace Náutico & Guia Oficial
              </p>
            </div>
          </button>

          {/* Menu Principal */}
          <nav className="flex flex-wrap items-center gap-1 sm:gap-2 text-sm">
            {[
              { id: 'home', label: 'Início', icon: Compass },
              { id: 'guide', label: `Guia de Ubatuba (${destinations.length})`, icon: MapPin },
              { id: 'tours', label: 'Passeios & Reservas', icon: Ship },
              { id: 'vessels', label: 'Lanchas & Escunas', icon: Anchor },
              { id: 'itineraries', label: 'Roteiros & Mapa', icon: Navigation },
              { id: 'gallery', label: 'Galeria & Vídeos', icon: Camera }
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedDestinationId(null);
                    setSelectedTourId(null);
                    setSelectedVesselId(null);
                    setActiveTab(item.id as typeof activeTab);
                  }}
                  className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                      : 'text-slate-200 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Botões Rápidos de Consulta de Reserva e Nova Reserva */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAuthModalOpen(true)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-400/40 text-amber-300 text-xs font-extrabold flex items-center gap-1.5 transition"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>
                {verifiedSession.isAuthenticated
                  ? `Conta: ${verifiedSession.accountState}`
                  : 'Acesso / Onboarding'}
              </span>
            </button>
            <button
              onClick={() => setTouristTrackerOpen(true)}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-cyan-300 font-bold text-xs border border-cyan-400/30 transition flex items-center gap-1.5"
            >
              <CheckSquare className="w-4 h-4" />
              <span>
                Minhas Reservas ({Math.max(savedTouristReceipts.length, Object.keys(verifiedTouristBookings).length)})
              </span>
            </button>
            <button
              onClick={() => openBookingModalForTour(tours.find((t) => t.status === 'APROVADO') || tours[0])}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-300 hover:to-teal-300 text-slate-950 font-bold text-sm shadow-md transition transform active:scale-95 flex items-center gap-1.5"
            >
              <Calendar className="w-4 h-4" />
              <span>Reservar Passeio</span>
            </button>
          </div>
        </div>
      </header>

      {/* ========================================================================
          PÁGINA 1: HOME — PÁGINA INICIAL EXTREMAMENTE VISUAL (12 SEÇÕES + HERO)
         ======================================================================== */}
      {activeTab === 'home' && !selectedDestination && !selectedTour && !selectedVessel && (
        <div>
          {/* HERO PRINCIPAL PANORÂMICO */}
          <section className="relative overflow-hidden bg-[#0A2540] text-white">
            <div className="absolute inset-0">
              <img
                src={IMG_HERO}
                alt="Vista aérea panorâmica do mar verde-esmeralda de Ubatuba com lancha e escuna"
                className="w-full h-full object-cover opacity-55 scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A2540] via-[#0A2540]/65 to-[#0A2540]/40" />
            </div>

            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-16 md:pt-20 md:pb-24">
              <div className="max-w-3xl">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-cyan-400/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-5">
                  <Waves className="w-4 h-4" /> Plataforma Oficial de Conexão Náutica • Litoral Norte SP
                </div>

                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight text-white drop-shadow-sm">
                  Ubatuba é ainda mais incrível vista do mar.
                </h1>

                <p className="mt-4 text-lg sm:text-xl text-slate-200 leading-relaxed max-w-2xl">
                  Descubra praias paradisíacas, ilhas, cachoeiras e experiências inesquecíveis. Compare lanchas privativas, escunas tradicionais e roteiros verificados direto com operadores locais.
                </p>

                {/* Botões Principais da Hero */}
                <div className="mt-7 flex flex-wrap items-center gap-3.5">
                  <button
                    onClick={() => setActiveTab('tours')}
                    className="px-6 py-3.5 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-base shadow-xl shadow-cyan-500/25 transition flex items-center gap-2"
                  >
                    <Ship className="w-5 h-5" />
                    <span>Explorar passeios</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setActiveTab('guide')}
                    className="px-6 py-3.5 rounded-2xl bg-white/15 hover:bg-white/25 backdrop-blur-md text-white font-bold text-base border border-white/25 transition flex items-center gap-2"
                  >
                    <MapPin className="w-5 h-5 text-cyan-300" />
                    <span>Conhecer Ubatuba</span>
                  </button>

                  <button
                    onClick={() =>
                      setLightboxMedia({
                        title: 'Vídeo Panorâmico 4K: Ubatuba Vista do Mar',
                        url: IMG_HERO,
                        type: 'video',
                        subtitle: 'Ilha das Couves, Ilha Anchieta, Sete Praias e Cachoeiras da Serra do Mar'
                      })
                    }
                    className="px-4 py-3.5 rounded-2xl bg-slate-900/70 hover:bg-slate-900 text-cyan-300 font-semibold text-sm border border-cyan-500/30 transition flex items-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-cyan-400 text-cyan-400" />
                    <span>Assistir Vídeo (02:45)</span>
                  </button>
                </div>
              </div>

              {/* BARRA DE PESQUISA MULTICATEGORIA */}
              <div className="mt-10 bg-white text-slate-900 p-3 sm:p-4 rounded-3xl shadow-2xl border border-slate-200/80 max-w-5xl">
                <div className="flex flex-wrap items-center gap-1.5 pb-3 mb-3 border-b border-slate-100">
                  {(
                    [
                      'ALL',
                      'Passeios de lancha',
                      'Passeios de escuna',
                      'Praias',
                      'Ilhas',
                      'Cachoeiras',
                      'Experiências turísticas'
                    ] as const
                  ).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setHeroSearchScope(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        heroSearchScope === cat
                          ? 'bg-[#0A2540] text-cyan-300 shadow-sm'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {cat === 'ALL' ? 'Tudo em Ubatuba' : cat}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
                  <div className="md:col-span-5 flex items-center gap-3 bg-slate-50 px-4 py-3 rounded-2xl border border-slate-200">
                    <Search className="w-5 h-5 text-cyan-600 shrink-0" />
                    <div className="w-full">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Destino, Praia, Ilha ou Embarcação
                      </label>
                      <input
                        type="text"
                        value={heroSearchQuery}
                        onChange={(e) => setHeroSearchQuery(e.target.value)}
                        placeholder="Ex: Ilha das Couves, Cedro, Lancha Privativa..."
                        className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-3 flex items-center gap-3 bg-slate-50 px-4 py-3 rounded-2xl border border-slate-200">
                    <Anchor className="w-5 h-5 text-cyan-600 shrink-0" />
                    <div className="w-full">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Ponto de Embarque / Região
                      </label>
                      <select
                        value={heroRegionSelect}
                        onChange={(e) => {
                          const val = e.target.value;
                          setHeroRegionSelect(val);
                          setGuideRegionFilter(val === 'ALL' ? 'TODAS' : (val as any));
                        }}
                        className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none"
                      >
                        <option value="ALL">Saco da Ribeira, Itaguá ou Norte</option>
                        <option value="Norte">Norte (Itaguá / Picinguaba / Prumirim)</option>
                        <option value="Sul">Sul (Saco da Ribeira / Anchieta)</option>
                        <option value="Centro">Centro (Cedrinho / Itaguá)</option>
                      </select>
                    </div>
                  </div>

                  <div className="md:col-span-2 flex items-center gap-3 bg-slate-50 px-4 py-3 rounded-2xl border border-slate-200">
                    <Users className="w-5 h-5 text-cyan-600 shrink-0" />
                    <div className="w-full">
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Passageiros
                      </label>
                      <select
                        value={tourMinCapacity}
                        onChange={(e) => setTourMinCapacity(Number(e.target.value))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none"
                      >
                        <option value={1}>1 a 4 pessoas</option>
                        <option value={6}>6+ pessoas</option>
                        <option value={10}>Grupo 10+ pessoas</option>
                      </select>
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <button
                      onClick={handleHeroSearch}
                      className="w-full py-4 px-4 rounded-2xl bg-[#0A2540] hover:bg-slate-800 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2"
                    >
                      <Search className="w-4 h-4 text-cyan-400" />
                      <span>Buscar</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <main className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-16">
            {/* SEÇÃO 1: DESTINOS MAIS PROCURADOS */}
            <section>
              <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                    1 • Destinos Mais Procurados em Ubatuba
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                    Ícones Naturais que Todo Visitante Precisa Conhecer
                  </h2>
                </div>
                <button
                  onClick={() => setActiveTab('guide')}
                  className="text-sm font-bold text-cyan-700 hover:text-cyan-900 flex items-center gap-1"
                >
                  <span>Ver todos os {destinations.length} destinos do guia</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {destinations
                  .filter((d) => d.featured)
                  .slice(0, 4)
                  .map((dest) => (
                    <div
                      key={dest.id}
                      onClick={() => setSelectedDestinationId(dest.id)}
                      className="group cursor-pointer bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-slate-200/80 transition-all duration-200 flex flex-col"
                    >
                      <div className="relative h-52 overflow-hidden">
                        <img
                          src={dest.heroImage}
                          alt={dest.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-sm text-cyan-300 text-xs font-bold">
                          {dest.category} • {dest.region}
                        </div>
                        <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-lg bg-white/95 text-slate-900 text-xs font-bold flex items-center gap-1 shadow">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>{dest.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <div className="p-5 flex-1 flex flex-col justify-between">
                        <div>
                          <h3 className="font-extrabold text-lg text-slate-900 group-hover:text-cyan-700 transition">
                            {dest.name}
                          </h3>
                          <p className="text-sm text-slate-600 mt-1.5 line-clamp-2">{dest.shortDescription}</p>
                        </div>
                        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-cyan-700">
                          <span>Acesso: {dest.accessType}</span>
                          <span className="flex items-center gap-1">
                            Explorar <ArrowRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </section>

            {/* SEÇÃO 2, 3 E 4: PASSEIOS DE LANCHA, ESCUNA E EXPERIÊNCIAS PRIVATIVAS */}
            <section className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/80">
              <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                    2, 3 & 4 • Lanchas, Escunas e Experiências Privativas
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                    Escolha Sua Experiência no Mar de Ubatuba
                  </h2>
                  <p className="text-sm text-slate-600 mt-1">
                    Passeios operados por parceiros verificados com reserva via WhatsApp rastreado ou solicitação direta.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      setTourCategoryFilter('TODAS');
                      setTourTypeFilter('TODOS');
                      setTourVesselTypeFilter('Lancha');
                      navigateToTab('tours');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-cyan-50 text-slate-800 text-xs font-bold transition"
                  >
                    Ver Passeios de Lancha
                  </button>
                  <button
                    onClick={() => {
                      setTourCategoryFilter('TODAS');
                      setTourTypeFilter('TODOS');
                      setTourVesselTypeFilter('Escuna');
                      navigateToTab('tours');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-cyan-50 text-slate-800 text-xs font-bold transition"
                  >
                    Ver Passeios de Escuna
                  </button>
                  <button
                    onClick={() => {
                      setTourCategoryFilter('TODAS');
                      setTourVesselTypeFilter('TODOS');
                      setTourTypeFilter('Privativo');
                      navigateToTab('tours');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#0A2540] text-cyan-300 text-xs font-bold transition"
                  >
                    Experiências Privativas
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tours
                  .filter((t) => t.status === 'APROVADO')
                  .map((tour) => {
                    const partner = partners.find((p) => p.id === tour.partnerId);
                    const vessel = vessels.find((v) => v.id === tour.vesselId);
                    return (
                      <div
                        key={tour.id}
                        className="rounded-2xl border border-slate-200 overflow-hidden hover:border-cyan-500/60 hover:shadow-lg transition-all flex flex-col sm:flex-row bg-[#FBF8F3]/50"
                      >
                        <div className="sm:w-56 h-52 sm:h-auto relative shrink-0">
                          <img src={tour.heroImage} alt={tour.title} className="w-full h-full object-cover" />
                          <span
                            className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase ${
                              tour.tourType === 'Privativo'
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-cyan-500 text-slate-950'
                            }`}
                          >
                            {tour.tourType} • {tour.vesselType}
                          </span>
                        </div>
                        <div className="p-5 flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                              <span className="font-semibold text-cyan-800 flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> {partner?.name}
                              </span>
                              <span className="flex items-center gap-1 font-bold text-slate-800">
                                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {tour.rating.toFixed(1)} ({tour.reviewsCount})
                              </span>
                            </div>

                            <h3
                              onClick={() => setSelectedTourId(tour.id)}
                              className="font-extrabold text-base sm:text-lg text-slate-900 mt-1.5 hover:text-cyan-700 cursor-pointer"
                            >
                              {tour.title}
                            </h3>

                            <div className="mt-2.5 flex flex-wrap gap-2 text-xs text-slate-600">
                              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200">
                                Embarque: <strong>{tour.departurePoint}</strong>
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200">
                                Duração: <strong>{tour.durationHours}h</strong>
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-white border border-slate-200">
                                Até <strong>{tour.capacity} pax</strong> ({vessel?.name})
                              </span>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between gap-2">
                            <div>
                              <span className="text-[11px] text-slate-500 block">
                                {tour.pricingModel === 'POR_PESSOA' ? 'Valor por passageiro' : 'Valor lancha fechada'}
                              </span>
                              <span className="text-xl font-extrabold text-[#0A2540]">
                                R$ {tour.price.toLocaleString('pt-BR')}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setSelectedTourId(tour.id)}
                                className="px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700"
                              >
                                Detalhes
                              </button>
                              <button
                                onClick={() => openBookingModalForTour(tour)}
                                className="px-3.5 py-2 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-bold transition"
                              >
                                Solicitar Reserva
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </section>

            {/* SEÇÕES 5, 6 E 7: PRAIAS PARADISÍACAS, ILHAS DE UBATUBA E CACHOEIRAS & TRILHAS */}
            <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 5. Praias Paradisíacas */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-700">5 • 12 Praias no Guia</span>
                    <Sun className="w-5 h-5 text-amber-500" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-900 mt-1">Praias Paradisíacas</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    De enseadas calmas como Domingas Dias e Cedro ao surf de Itamambuca.
                  </p>
                  <div className="mt-4 space-y-2">
                    {destinations
                      .filter((d) => d.category === 'Praias')
                      .slice(0, 6)
                      .map((p) => (
                        <button
                          key={p.id}
                          onClick={() => setSelectedDestinationId(p.id)}
                          className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 border border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-800"
                        >
                          <span>{p.name}</span>
                          <span className="text-cyan-700 font-bold">{p.region} →</span>
                        </button>
                      ))}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setGuideCategoryFilter('Praias');
                    setActiveTab('guide');
                  }}
                  className="mt-5 w-full py-2.5 rounded-xl bg-slate-100 hover:bg-cyan-50 text-xs font-bold text-slate-900"
                >
                  Explorar todas as 12 Praias
                </button>
              </div>

              {/* 6. Ilhas de Ubatuba */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-700">6 • Arquipélago</span>
                    <Anchor className="w-5 h-5 text-cyan-600" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-900 mt-1">Ilhas de Ubatuba</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Águas cristalinas para flutuação na Ilha das Couves, Anchieta, Prumirim, Porcos e Rapada.
                  </p>
                  <div className="mt-4 space-y-2">
                    {destinations
                      .filter((d) => d.category === 'Ilhas')
                      .map((ilha) => (
                        <button
                          key={ilha.id}
                          onClick={() => setSelectedDestinationId(ilha.id)}
                          className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 border border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-800"
                        >
                          <span>{ilha.name}</span>
                          <span className="text-cyan-700 font-bold">Ver Ilha →</span>
                        </button>
                      ))}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setGuideCategoryFilter('Ilhas');
                    setActiveTab('guide');
                  }}
                  className="mt-5 w-full py-2.5 rounded-xl bg-slate-100 hover:bg-cyan-50 text-xs font-bold text-slate-900"
                >
                  Explorar Guia das 5 Ilhas
                </button>
              </div>

              {/* 7. Cachoeiras e Trilhas */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                      7 • Mata Atlântica
                    </span>
                    <Trees className="w-5 h-5 text-emerald-600" />
                  </div>
                  <h3 className="text-xl font-extrabold text-slate-900 mt-1">Cachoeiras e Trilhas</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Poços cristalinos no Prumirim, Sertão da Quina e a Cachoeira da Água Branca (~200m).
                  </p>
                  <div className="mt-4 space-y-2">
                    {destinations
                      .filter((d) => d.category === 'Cachoeiras' || d.category === 'Trilhas e Aventuras')
                      .map((c) => (
                        <button
                          key={c.id}
                          onClick={() => setSelectedDestinationId(c.id)}
                          className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 border border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-800"
                        >
                          <span>{c.name}</span>
                          <span className="text-emerald-700 font-bold">{c.category} →</span>
                        </button>
                      ))}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setGuideCategoryFilter('Cachoeiras');
                    setActiveTab('guide');
                  }}
                  className="mt-5 w-full py-2.5 rounded-xl bg-slate-100 hover:bg-emerald-50 text-xs font-bold text-slate-900"
                >
                  Explorar Cachoeiras & Trilhas
                </button>
              </div>
            </section>

            {/* SEÇÃO 8 E 9: ROTEIROS TURÍSTICOS E GALERIA DE VÍDEOS */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-7 bg-[#0A2540] text-white rounded-3xl p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                    8 • Roteiros Náuticos Homologados
                  </span>
                  <h2 className="text-2xl font-extrabold mt-1">Compare Roteiros Norte e Sul</h2>
                  <p className="text-sm text-slate-300 mt-1">
                    Roteiros estruturados com tempo estimado de parada, condições de navegação e embarcações confirmadas pelos parceiros.
                  </p>

                  <div className="mt-5 space-y-3">
                    {itineraries.map((it) => (
                      <div
                        key={it.id}
                        className="p-4 rounded-2xl bg-white/10 border border-white/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <span className="text-[11px] font-bold text-cyan-300 uppercase">{it.region}</span>
                          <h4 className="font-bold text-base text-white">{it.title}</h4>
                          <p className="text-xs text-slate-300 mt-0.5">
                            {it.estimatedDuration} • {it.stopsCount} paradas • {it.navigationLevel}
                          </p>
                        </div>
                        <button
                          onClick={() => setActiveTab('itineraries')}
                          className="px-3.5 py-2 rounded-xl bg-cyan-400 text-slate-950 font-bold text-xs shrink-0"
                        >
                          Comparar Roteiro
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 9. Galeria de Vídeos Integrados */}
              <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                    9 • Galeria Dinâmica de Vídeos & Fotos
                  </span>
                  <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Vídeos em Destaque</h2>
                  <p className="text-xs text-slate-600 mt-1">
                    Estrutura pronta para substituição imediata pelas suas gravações reais de drones, praias e lanchas.
                  </p>

                  <div className="mt-4 space-y-3">
                    {[
                      {
                        title: 'Drone 4K: Ilha das Couves e Prumirim',
                        duration: '03:20',
                        img: IMG_COUVES,
                        sub: 'Roteiro Norte • Kaimares Náutica'
                      },
                      {
                        title: 'Ilha Anchieta & Aquário Natural',
                        duration: '03:45',
                        img: IMG_ESCUNA,
                        sub: 'Roteiro Sul • Escunas Caiçara'
                      },
                      {
                        title: 'Cachoeira da Água Branca (200m)',
                        duration: '04:10',
                        img: IMG_CACHOEIRA,
                        sub: 'Parque Estadual da Serra do Mar'
                      }
                    ].map((vid, idx) => (
                      <div
                        key={idx}
                        onClick={() =>
                          setLightboxMedia({
                            title: vid.title,
                            url: vid.img,
                            type: 'video',
                            subtitle: vid.sub
                          })
                        }
                        className="group cursor-pointer p-2.5 rounded-2xl border border-slate-200 hover:border-cyan-500 flex items-center gap-3.5 transition"
                      >
                        <div className="w-24 h-16 rounded-xl overflow-hidden relative shrink-0">
                          <img src={vid.img} alt={vid.title} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
                            <Play className="w-5 h-5 fill-white text-white group-hover:scale-110 transition-transform" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm text-slate-900 truncate">{vid.title}</p>
                          <p className="text-xs text-slate-500">{vid.sub}</p>
                          <span className="inline-block mt-1 text-[11px] font-bold text-cyan-700">
                            Reproduzir ({vid.duration})
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('gallery')}
                  className="mt-5 w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold"
                >
                  Abrir Galeria Completa & Gerenciador de Mídia
                </button>
              </div>
            </section>

            {/* SEÇÃO 10 E 11: PARCEIROS EM DESTAQUE E AVALIAÇÕES VERIFICADAS */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* 10. Parceiros em Destaque */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                  10 • Operadores Credenciados
                </span>
                <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Parceiros Náuticos em Destaque</h2>
                <p className="text-xs text-slate-600 mt-1">
                  Múltiplos operadores independentes com embarcações registradas na Marinha do Brasil.
                </p>

                <div className="mt-5 space-y-3">
                  {partners
                    .filter((p) => p.status === 'APROVADO')
                    .map((p) => (
                      <div
                        key={p.id}
                        className="p-4 rounded-2xl bg-[#FBF8F3] border border-slate-200/80 flex items-start justify-between gap-4"
                      >
                        <div className="flex items-start gap-3">
                          <img
                            src={p.avatarImage}
                            alt={p.name}
                            className="w-12 h-12 rounded-2xl object-cover shrink-0 border border-cyan-500/30"
                          />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-extrabold text-sm text-slate-900">{p.name}</h4>
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                Verificado
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">{p.baseMarina}</p>
                            <p className="text-xs text-slate-700 mt-1 line-clamp-2">{p.bio}</p>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="inline-flex items-center gap-1 text-xs font-extrabold text-slate-900">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span>{p.rating.toFixed(1)}</span>
                          </div>
                          <p className="text-[11px] text-slate-500">{p.reviewsCount} avaliações</p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* 11. Avaliações Verificadas */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                  11 • Avaliações Verificadas por Reserva
                </span>
                <h2 className="text-2xl font-extrabold text-slate-900 mt-1">O Que Dizem os Turistas</h2>
                <p className="text-xs text-slate-600 mt-1">
                  Depoimentos vinculados a códigos reais de passeios realizados na plataforma.
                </p>

                <div className="mt-5 space-y-3">
                  {reviews.map((rev) => (
                    <div key={rev.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="font-extrabold text-sm text-slate-900">{rev.author}</span>
                          <span className="text-xs text-slate-500 ml-2">({rev.city})</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-md bg-cyan-50 text-cyan-800 text-[11px] font-bold border border-cyan-200">
                          Reserva {rev.verifiedBookingCode}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 mt-2 italic leading-relaxed">"{rev.comment}"</p>
                      <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                        <span className="font-semibold text-slate-700">{rev.tourTitle}</span>
                        <span>{rev.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* SEÇÃO 12: CHAMADA PARA RESERVAR OU TORNAR-SE PARCEIRO */}
            <section className="rounded-3xl bg-gradient-to-r from-[#0A2540] via-[#0E3A5F] to-[#0891B2] text-white p-8 sm:p-12 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="max-w-2xl">
                <span className="text-xs font-bold uppercase tracking-widest text-cyan-300">
                  12 • Reserve com Segurança ou Cadastre Sua Embarcação
                </span>
                <h2 className="text-2xl sm:text-4xl font-extrabold mt-2 leading-tight">
                  Pronto para navegar pelas águas mais cristalinas de Ubatuba?
                </h2>
                <p className="text-slate-200 mt-3 text-sm sm:text-base">
                  Solicite disponibilidade direto no WhatsApp oficial do operador com código rastreado ou envie seu pedido pelo site sem taxas ocultas para o turista.
                </p>
              </div>
              <div className="flex flex-wrap gap-3 shrink-0">
                <button
                  onClick={() => setActiveTab('tours')}
                  className="px-6 py-4 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-sm shadow-lg transition"
                >
                  Explorar Catálogo de Passeios
                </button>
                <button
                  onClick={() => {
                    setRoleMode('partner');
                    setActiveTab('partner-portal');
                  }}
                  className="px-6 py-4 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-bold text-sm border border-white/30 transition"
                >
                  Sou Proprietário de Lancha / Escuna
                </button>
              </div>
            </section>
          </main>
        </div>
      )}

      {/* ========================================================================
          PÁGINA 2: GUIA TURÍSTICO VISUAL DE UBATUBA (PRAIAS, ILHAS, CACHOEIRAS, TRILHAS)
         ======================================================================== */}
      {activeTab === 'guide' && !selectedDestination && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <div className="bg-[#0A2540] text-white rounded-3xl p-6 sm:p-10 mb-8 relative overflow-hidden">
            <div className="max-w-3xl relative z-10">
              <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                Guia Turístico Oficial & Georreferenciado
              </span>
              <h1 className="text-3xl sm:text-4xl font-extrabold mt-1">
                Guia de Praias, Ilhas, Cachoeiras e Trilhas de Ubatuba
              </h1>
              <p className="text-slate-300 text-sm sm:text-base mt-2">
                Informações reais sobre localização, condições de acesso, infraestrutura, regras ambientais do Parque Estadual e passeios náuticos relacionados.
              </p>
            </div>
          </div>

          {/* Filtros do Guia */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl shadow-sm border border-slate-200 mb-8 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              {(['TODAS', 'Praias', 'Ilhas', 'Cachoeiras', 'Trilhas e Aventuras'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setGuideCategoryFilter(cat)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                    guideCategoryFilter === cat
                      ? 'bg-[#0A2540] text-cyan-300 shadow'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'TODAS' ? `Todos os Destinos (${destinations.length})` : cat}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <select
                value={guideRegionFilter}
                onChange={(e) => setGuideRegionFilter(e.target.value as any)}
                className="px-3 py-2 rounded-xl bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200"
              >
                <option value="TODAS">Todas as Regiões</option>
                <option value="Norte">Região Norte</option>
                <option value="Centro">Região Central</option>
                <option value="Sul">Região Sul</option>
                <option value="Sertão / Serra do Mar">Sertão / Serra do Mar</option>
              </select>

              <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200">
                <Search className="w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={guideSearch}
                  onChange={(e) => setGuideSearch(e.target.value)}
                  placeholder="Filtrar destino..."
                  className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Grid Completo de Destinos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDestinations.map((dest) => (
              <div
                key={dest.id}
                onClick={() => setSelectedDestinationId(dest.id)}
                className="group cursor-pointer bg-white rounded-3xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl transition-all flex flex-col"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={dest.heroImage}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    <span className="px-2.5 py-1 rounded-full bg-slate-900/85 text-cyan-300 text-[11px] font-bold">
                      {dest.category}
                    </span>
                    <span className="px-2.5 py-1 rounded-full bg-white/90 text-slate-900 text-[11px] font-bold">
                      {dest.region}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                    <span className="px-2.5 py-1 rounded-lg bg-slate-900/75 backdrop-blur-sm flex items-center gap-1 font-semibold">
                      <Video className="w-3.5 h-3.5 text-cyan-400" /> Vídeo ({dest.videoDuration})
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-white text-slate-900 font-bold flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {dest.rating.toFixed(1)}
                    </span>
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-extrabold text-lg text-slate-900 group-hover:text-cyan-700 transition">
                      {dest.name}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{dest.shortDescription}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {dest.characteristics.slice(0, 2).map((ch, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                        >
                          {ch}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-cyan-700">
                    <span>Acesso: {dest.accessType}</span>
                    <span className="flex items-center gap-1">
                      Abrir Página Completa <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA INDIVIDUAL DE DESTINO (PRAIA, ILHA, CACHOEIRA OU TRILHA)
         ======================================================================== */}
      {selectedDestination && (activeTab === 'home' || activeTab === 'guide') && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={() => setSelectedDestinationId(null)}
              className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1.5 shadow-sm"
            >
              <ChevronLeft className="w-4 h-4" /> Voltar para o Guia de Ubatuba
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const idx = destinations.findIndex((d) => d.id === selectedDestination.id);
                  const prev = destinations[(idx - 1 + destinations.length) % destinations.length];
                  setSelectedDestinationId(prev.id);
                }}
                className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> Destino Anterior
              </button>
              <button
                onClick={() => {
                  const idx = destinations.findIndex((d) => d.id === selectedDestination.id);
                  const next = destinations[(idx + 1) % destinations.length];
                  setSelectedDestinationId(next.id);
                }}
                className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1"
              >
                Próximo Destino <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-md">
            <div className="grid grid-cols-1 lg:grid-cols-12">
              <div className="lg:col-span-7 relative min-h-[320px] sm:min-h-[420px]">
                <img
                  src={selectedDestination.heroImage}
                  alt={selectedDestination.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full bg-cyan-500 text-slate-950 text-xs font-extrabold">
                      {selectedDestination.category}
                    </span>
                    <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold">
                      Região {selectedDestination.region}
                    </span>
                    <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-amber-300 text-xs font-bold flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-300" /> {selectedDestination.rating.toFixed(1)} ({selectedDestination.reviewsCount} avaliações)
                    </span>
                  </div>
                  <h1 className="text-2xl sm:text-4xl font-extrabold">{selectedDestination.name}</h1>
                </div>
              </div>

              {/* Player de Vídeo e Mapa Geográfico Real */}
              <div className="lg:col-span-5 bg-[#0A2540] text-white p-6 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                    Vídeo Integrado & Coordenadas Reais
                  </span>
                  <div
                    onClick={() =>
                      setLightboxMedia({
                        title: selectedDestination.videoTitle,
                        url: selectedDestination.heroImage,
                        type: 'video',
                        subtitle: `${selectedDestination.name} • Duração ${selectedDestination.videoDuration}`
                      })
                    }
                    className="mt-3 p-4 rounded-2xl bg-white/10 hover:bg-white/15 border border-cyan-400/30 cursor-pointer flex items-center justify-between gap-3 transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-cyan-400 text-slate-950 flex items-center justify-center shrink-0">
                        <Play className="w-5 h-5 fill-slate-950" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">{selectedDestination.videoTitle}</p>
                        <p className="text-xs text-cyan-200">Clique para reproduzir vídeo em tela ampliada ({selectedDestination.videoDuration})</p>
                      </div>
                    </div>
                  </div>

                  {/* Mapa Costeiro de Localização Georreferenciada */}
                  <div className="mt-5 p-4 rounded-2xl bg-slate-900/90 border border-white/10">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-bold text-cyan-300 flex items-center gap-1">
                        <MapIcon className="w-3.5 h-3.5" /> Mapa Geográfico • Ubatuba/SP
                      </span>
                      <span className="text-slate-400 font-mono text-[11px]">
                        Lat {selectedDestination.coordinates.lat.toFixed(4)}° | Lng {selectedDestination.coordinates.lng.toFixed(4)}°
                      </span>
                    </div>
                    <div className="relative h-36 rounded-xl bg-[#071c30] border border-cyan-900/50 overflow-hidden">
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        {/* Traçado estilizado da costa de Ubatuba (Sul -> Norte) */}
                        <path
                          d="M 10,95 Q 25,85 35,72 T 60,52 T 78,32 T 94,12 L 0,0 L 0,100 Z"
                          fill="#133829"
                          stroke="#10b981"
                          strokeWidth="0.8"
                        />
                        <circle
                          cx={selectedDestination.coordinates.mapX}
                          cy={selectedDestination.coordinates.mapY}
                          r="4.5"
                          fill="#22d3ee"
                        />
                        <circle
                          cx={selectedDestination.coordinates.mapX}
                          cy={selectedDestination.coordinates.mapY}
                          r="9"
                          fill="none"
                          stroke="#22d3ee"
                          strokeWidth="1"
                          opacity="0.6"
                        />
                      </svg>
                      <div className="absolute bottom-2 left-2 right-2 flex justify-between text-[10px] text-slate-300 bg-slate-950/75 px-2 py-1 rounded">
                        <span>Sul (Maranduba / Anchieta)</span>
                        <span className="text-cyan-300 font-bold">Ponto Selecionado</span>
                        <span>Norte (Picinguaba)</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                  <span className="text-slate-300">Modalidade de Acesso:</span>
                  <span className="font-bold text-cyan-300">{selectedDestination.accessType}</span>
                </div>
              </div>
            </div>

            {/* Informações Completas do Destino */}
            <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-8 space-y-6">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Sobre {selectedDestination.name}</h2>
                  <p className="text-slate-700 mt-2 leading-relaxed text-sm sm:text-base">
                    {selectedDestination.fullDescription}
                  </p>
                </div>

                {/* Galeria de Fotos do Destino */}
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 mb-2.5 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-cyan-700" /> Galeria de Fotos ({selectedDestination.gallery.length} imagens)
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {selectedDestination.gallery.map((imgUrl, idx) => (
                      <div
                        key={idx}
                        onClick={() =>
                          setLightboxMedia({
                            title: `${selectedDestination.name} — Foto ${idx + 1}`,
                            url: imgUrl,
                            type: 'photo',
                            subtitle: `${selectedDestination.category} • Região ${selectedDestination.region}`,
                            galleryList: selectedDestination.gallery.map((u, i) => ({
                              title: `${selectedDestination.name} — Foto ${i + 1}`,
                              url: u,
                              type: 'photo' as const,
                              subtitle: selectedDestination.name
                            })),
                            currentIndex: idx
                          })
                        }
                        className="h-24 sm:h-32 rounded-2xl overflow-hidden border border-slate-200 cursor-pointer group relative"
                      >
                        <img src={imgUrl} alt={`${selectedDestination.name} ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition" />
                        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                          <Eye className="w-5 h-5 text-white" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                      <Navigation className="w-4 h-4 text-cyan-700" /> Como Chegar & Acesso
                    </h3>
                    <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                      {selectedDestination.howToGetThere}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-cyan-700" /> Infraestrutura Local
                    </h3>
                    <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                      {selectedDestination.infrastructure}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-cyan-50/60 border border-cyan-200">
                    <h3 className="font-extrabold text-sm text-slate-900">Dicas para Visitantes</h3>
                    <ul className="mt-2 space-y-1.5 text-xs text-slate-700">
                      {selectedDestination.visitorTips.map((tip, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-700 shrink-0 mt-0.5" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
                    <h3 className="font-extrabold text-sm text-slate-900">Regras Ambientais & Preservação</h3>
                    <ul className="mt-2 space-y-1.5 text-xs text-slate-700">
                      {selectedDestination.environmentalRules.map((rule, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                          <span>{rule}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Passeios Relacionados a Este Destino (Corrige BUG-07) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="p-5 rounded-3xl bg-[#FBF8F3] border border-slate-200">
                  <h3 className="font-extrabold text-base text-slate-900">
                    Passeios que Visitam ou Partem na Região ({selectedDestination.region})
                  </h3>
                  <div className="mt-4 space-y-3">
                    {(() => {
                      const direct = tours.filter(
                        (t) => t.status === 'APROVADO' && t.destinationsVisited.includes(selectedDestination.id)
                      );
                      const list =
                        direct.length > 0
                          ? direct
                          : tours.filter((t) => {
                              if (t.status !== 'APROVADO') return false;
                              return selectedDestination.region === 'Norte'
                                ? t.departurePoint === 'Praia do Itaguá' || t.departurePoint === 'Praia de Picinguaba'
                                : t.departurePoint === 'Saco da Ribeira';
                            });
                      return list.slice(0, 3).map((t) => (
                        <div key={t.id} className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
                          <span className="text-[10px] font-bold uppercase text-cyan-700">
                            {t.tourType} • {t.vesselType} • {t.departurePoint}
                          </span>
                          <h4 className="font-bold text-sm text-slate-900 mt-0.5">{t.title}</h4>
                          <div className="mt-2 flex items-center justify-between">
                            <span className="font-extrabold text-sm text-[#0A2540]">
                              R$ {t.price.toLocaleString('pt-BR')}
                            </span>
                            <button
                              onClick={() => {
                                setSelectedDestinationId(null);
                                setSelectedTourId(t.id);
                                setActiveTab('tours');
                              }}
                              className="px-3 py-1.5 rounded-xl bg-[#0A2540] text-white text-xs font-bold"
                            >
                              Ver Passeio
                            </button>
                          </div>
                        </div>
                      ));
                    })()}
                  </div>
                  {selectedDestination.sourceUrl && (
                    <a
                      href={selectedDestination.sourceUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs font-bold text-cyan-700 hover:underline"
                    >
                      <span>Fonte Oficial do Destino</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA 3: MARKETPLACE DE PASSEIOS (CATÁLOGO E FILTROS FUNCIONAIS)
         ======================================================================== */}
      {activeTab === 'tours' && !selectedTour && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <div className="mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
              Catálogo Oficial de Experiências Náuticas
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-1">
              Marketplace de Passeios em Ubatuba
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Filtre por tipo de embarcação, faixa de preço, capacidade, duração, data e destinos visitados.
            </p>
          </div>

          {/* Barra de Filtros Funcionais */}
          <div className="bg-white p-5 rounded-3xl shadow-sm border border-slate-200 mb-8 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex flex-wrap gap-2">
                {[
                  'TODAS',
                  'Passeios de lancha',
                  'Passeios de escuna',
                  'Passeios compartilhados',
                  'Passeios privativos',
                  'Passeios para famílias',
                  'Passeios para grupos'
                ].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setTourCategoryFilter(cat)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
                      tourCategoryFilter === cat
                        ? 'bg-[#0A2540] text-cyan-300'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {cat === 'TODAS' ? 'Todas as Categorias' : cat}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                  <Search className="w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    value={tourSearch}
                    onChange={(e) => setTourSearch(e.target.value)}
                    placeholder="Buscar passeio ou marina..."
                    className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-none"
                  />
                </div>
                <select
                  value={tourSortBy}
                  onChange={(e) => setTourSortBy(e.target.value as any)}
                  className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700"
                >
                  <option value="DESTAQUES">Ordenar: Destaques</option>
                  <option value="MENOR_PRECO">Menor Preço</option>
                  <option value="MAIOR_PRECO">Maior Preço</option>
                  <option value="AVALIACAO">Melhor Avaliação</option>
                  <option value="CAPACIDADE">Maior Capacidade</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Tipo de Embarcação</label>
                <select
                  value={tourVesselTypeFilter}
                  onChange={(e) => setTourVesselTypeFilter(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                >
                  <option value="TODOS">Lanchas e Escunas</option>
                  <option value="Lancha">Somente Lanchas</option>
                  <option value="Escuna">Somente Escunas</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Modalidade do Passeio</label>
                <select
                  value={tourTypeFilter}
                  onChange={(e) => setTourTypeFilter(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                >
                  <option value="TODOS">Privativos e Compartilhados</option>
                  <option value="Privativo">Somente Privativo (Barco Fechado)</option>
                  <option value="Compartilhado">Somente Compartilhado (Por Pessoa)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  Preço Máximo: R$ {tourMaxPrice}
                </label>
                <input
                  type="range"
                  min={100}
                  max={2500}
                  step={50}
                  value={tourMaxPrice}
                  onChange={(e) => setTourMaxPrice(Number(e.target.value))}
                  className="w-full accent-cyan-600 mt-1.5"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Capacidade Mínima</label>
                <select
                  value={tourMinCapacity}
                  onChange={(e) => setTourMinCapacity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                >
                  <option value={1}>Qualquer capacidade</option>
                  <option value={6}>Mínimo 6 passageiros</option>
                  <option value={10}>Mínimo 10 passageiros</option>
                  <option value={30}>Grupos Grandes (30+ pax)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Destino Visitado</label>
                <select
                  value={tourDestinationFilter}
                  onChange={(e) => setTourDestinationFilter(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                >
                  <option value="TODOS">Qualquer Destino ({destinations.length})</option>
                  {destinations.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Data Desejada</label>
                <div className="flex gap-1">
                  <input
                    type="date"
                    min={currentBrazilDate}
                    value={tourDateFilter}
                    onChange={(e) => setTourDateFilter(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                  />
                  {tourDateFilter && (
                    <button
                      onClick={() => setTourDateFilter('')}
                      className="px-2 rounded-xl bg-slate-200 text-xs font-bold"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Lista de Passeios Filtrados */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTours.map((tour) => {
              const partner = partners.find((p) => p.id === tour.partnerId);
              const vessel = vessels.find((v) => v.id === tour.vesselId);
              return (
                <div
                  key={tour.id}
                  className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition flex flex-col"
                >
                  <div className="relative h-60">
                    <img src={tour.heroImage} alt={tour.title} className="w-full h-full object-cover" />
                    <div className="absolute top-3 left-3 flex gap-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                          tour.tourType === 'Privativo'
                            ? 'bg-amber-400 text-slate-950'
                            : 'bg-cyan-400 text-slate-950'
                        }`}
                      >
                        {tour.tourType}
                      </span>
                      <span className="px-3 py-1 rounded-full bg-slate-900/80 text-white text-xs font-bold">
                        {tour.vesselType}
                      </span>
                    </div>
                    <div className="absolute bottom-3 left-3 px-3 py-1 rounded-lg bg-slate-950/75 text-white text-xs font-semibold">
                      Embarque: {tour.departurePoint} • Saída {tour.departureTime}
                    </div>
                  </div>

                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span className="font-bold text-cyan-800">Operador: {partner?.name}</span>
                        <span className="font-bold text-slate-800 flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {tour.rating.toFixed(1)} ({tour.reviewsCount})
                        </span>
                      </div>

                      <h3
                        onClick={() => setSelectedTourId(tour.id)}
                        className="font-extrabold text-xl text-slate-900 mt-1.5 hover:text-cyan-700 cursor-pointer"
                      >
                        {tour.title}
                      </h3>

                      <p className="text-xs text-slate-600 mt-2">
                        Embarcação: <strong>{vessel?.name}</strong> • Capacidade: <strong>Até {tour.capacity} pessoas</strong> • Duração: <strong>{tour.durationHours}h</strong>
                      </p>

                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {tour.swimmingStops.map((st, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-1 rounded-lg bg-cyan-50 text-cyan-900 text-[11px] font-semibold border border-cyan-100"
                          >
                            Parada: {st.place} ({st.duration})
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-xs text-slate-500 block">
                          {tour.pricingModel === 'POR_PESSOA' ? 'Por pessoa' : 'Lancha privativa fechada'}
                        </span>
                        <span className="text-2xl font-extrabold text-[#0A2540]">
                          R$ {tour.price.toLocaleString('pt-BR')}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedTourId(tour.id)}
                          className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-800"
                        >
                          Ver Roteiro Completo
                        </button>
                        <button
                          onClick={() => openBookingModalForTour(tour)}
                          className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-extrabold shadow-sm"
                        >
                          Reservar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA INDIVIDUAL DE PASSEIO (TODOS OS 18 ATRIBUTOS EXIGIDOS)
         ======================================================================== */}
      {selectedTour && (activeTab === 'home' || activeTab === 'tours') && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <button
            onClick={() => setSelectedTourId(null)}
            className="mb-5 px-4 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1.5"
          >
            <ChevronLeft className="w-4 h-4" /> Voltar para o Catálogo de Passeios
          </button>

          {(() => {
            const partner = partners.find((p) => p.id === selectedTour.partnerId) || partners[0];
            const vessel = vessels.find((v) => v.id === selectedTour.vesselId) || vessels[0];
            return (
              <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-md">
                <div className="grid grid-cols-1 lg:grid-cols-12">
                  <div className="lg:col-span-8 relative min-h-[340px]">
                    <img src={selectedTour.heroImage} alt={selectedTour.title} className="w-full h-full object-cover" />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="px-3.5 py-1.5 rounded-full bg-cyan-400 text-slate-950 text-xs font-extrabold">
                        {selectedTour.category}
                      </span>
                      <span className="px-3.5 py-1.5 rounded-full bg-slate-950/80 text-white text-xs font-bold">
                        {selectedTour.tourType}
                      </span>
                    </div>
                  </div>
                  <div className="lg:col-span-4 bg-[#0A2540] text-white p-6 sm:p-8 flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                        Parceiro Responsável Homologado
                      </span>
                      <h2 className="text-xl font-extrabold mt-1">{partner.name}</h2>
                      <p className="text-xs text-slate-300 mt-1">
                        Embarcação: <strong>{vessel.name}</strong> ({vessel.lengthFeet} pés)
                      </p>

                      <div className="mt-5 p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-300">Ponto de Embarque:</span>
                          <span className="font-bold text-cyan-300">{selectedTour.departurePoint}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-300">Check-in / Saída / Retorno:</span>
                          <span className="font-bold">
                            {selectedTour.checkInTime} / {selectedTour.departureTime} / {selectedTour.returnTime}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-300">Capacidade Máxima:</span>
                          <span className="font-bold">{selectedTour.capacity} passageiros</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-300">Duração Estimada:</span>
                          <span className="font-bold">{selectedTour.durationHours} horas</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-white/15">
                      <span className="text-xs text-cyan-200 block">
                        {selectedTour.pricingModel === 'POR_PESSOA' ? 'Valor por passageiro' : 'Valor lancha privativa'}
                      </span>
                      <div className="text-3xl font-extrabold text-white mt-0.5">
                        R$ {selectedTour.price.toLocaleString('pt-BR')}
                      </div>

                      <button
                        onClick={() => openBookingModalForTour(selectedTour)}
                        className="mt-4 w-full py-3.5 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-sm shadow-lg transition"
                      >
                        Solicitar Reserva (WhatsApp ou Site)
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
                  <div className="lg:col-span-8 space-y-6">
                    <div>
                      <h1 className="text-2xl font-extrabold text-slate-900">{selectedTour.title}</h1>
                      <p className="text-xs text-slate-500 mt-1">
                        Operado por {partner.legalName} (CNPJ {partner.cnpj}) • WhatsApp Oficial: {partner.whatsapp}
                      </p>
                    </div>

                    {/* Galeria de Fotos e Vídeo do Passeio */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-extrabold text-sm text-slate-900">
                          Galeria do Passeio ({selectedTour.gallery.length} fotos)
                        </h3>
                        <button
                          onClick={() =>
                            setLightboxMedia({
                              title: selectedTour.videoTitle,
                              url: selectedTour.heroImage,
                              type: 'video',
                              subtitle: `${selectedTour.title} • ${partner.name}`
                            })
                          }
                          className="text-xs font-bold text-cyan-700 hover:underline flex items-center gap-1"
                        >
                          <Play className="w-3.5 h-3.5" /> Assistir Vídeo do Passeio
                        </button>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        {selectedTour.gallery.map((img, idx) => (
                          <div
                            key={idx}
                            onClick={() =>
                              setLightboxMedia({
                                title: `${selectedTour.title} — Foto ${idx + 1}`,
                                url: img,
                                type: 'photo',
                                subtitle: partner.name,
                                galleryList: selectedTour.gallery.map((u, i) => ({
                                  title: `${selectedTour.title} — Foto ${i + 1}`,
                                  url: u,
                                  type: 'photo' as const,
                                  subtitle: partner.name
                                })),
                                currentIndex: idx
                              })
                            }
                            className="h-24 sm:h-32 rounded-2xl overflow-hidden border border-slate-200 cursor-pointer"
                          >
                            <img src={img} alt="" className="w-full h-full object-cover hover:scale-105 transition" />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-extrabold text-base text-slate-900 mb-3">
                        Roteiro & Paradas para Banho e Flutuação
                      </h3>
                      <div className="space-y-3">
                        {selectedTour.swimmingStops.map((stop, idx) => (
                          <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                            <div className="flex items-center justify-between">
                              <span className="font-extrabold text-sm text-slate-900">
                                Parada {idx + 1}: {stop.place}
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full bg-cyan-100 text-cyan-900 text-xs font-bold">
                                Tempo estimado: {stop.duration}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 mt-1.5">{stop.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
                        <h4 className="font-extrabold text-sm text-slate-900">Itens Inclusos no Passeio</h4>
                        <ul className="mt-2 space-y-1.5 text-xs text-slate-700">
                          {selectedTour.includedItems.map((it, idx) => (
                            <li key={idx} className="flex items-start gap-1.5">
                              <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                              <span>{it}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200">
                        <h4 className="font-extrabold text-sm text-slate-900">
                          Informações Importantes & Política de Cancelamento
                        </h4>
                        <ul className="mt-2 space-y-1.5 text-xs text-slate-700">
                          {selectedTour.importantInfo.map((info, idx) => (
                            <li key={idx} className="flex items-start gap-1.5">
                              <Info className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                              <span>{info}</span>
                            </li>
                          ))}
                        </ul>
                        <p className="mt-3 pt-2 border-t border-amber-200/80 text-[11px] text-slate-600">
                          <strong>Política de Cancelamento:</strong> {selectedTour.cancellationPolicy}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="lg:col-span-4 space-y-4">
                    <div className="p-5 rounded-3xl bg-[#FBF8F3] border border-slate-200">
                      <h3 className="font-extrabold text-sm text-slate-900">Embarcação Vinculada</h3>
                      <p className="text-base font-extrabold text-cyan-800 mt-1">{vessel.name}</p>
                      <p className="text-xs text-slate-600 mt-1">{vessel.description}</p>
                      <button
                        onClick={() => {
                          setSelectedTourId(null);
                          setSelectedVesselId(vessel.id);
                          setActiveTab('vessels');
                        }}
                        className="mt-3 w-full py-2 rounded-xl bg-white border border-slate-300 text-xs font-bold text-slate-800 hover:bg-slate-100"
                      >
                        Abrir Página Individual da Embarcação
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </main>
      )}

      {/* ========================================================================
          PÁGINA INDIVIDUAL DE EMBARCAÇÃO (CORRIGE BUG-08)
         ======================================================================== */}
      {selectedVessel && (activeTab === 'home' || activeTab === 'vessels') && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <button
            onClick={() => setSelectedVesselId(null)}
            className="mb-5 px-4 py-2 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1.5"
          >
            <ChevronLeft className="w-4 h-4" /> Voltar para a Frota de Lanchas e Escunas
          </button>

          {(() => {
            const partner = partners.find((p) => p.id === selectedVessel.partnerId) || partners[0];
            const vesselTours = tours.filter((t) => t.vesselId === selectedVessel.id && t.status === 'APROVADO');
            return (
              <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-md">
                <div className="grid grid-cols-1 lg:grid-cols-12">
                  <div className="lg:col-span-7 relative min-h-[320px]">
                    <img src={selectedVessel.heroImage} alt={selectedVessel.name} className="w-full h-full object-cover" />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="px-3.5 py-1.5 rounded-full bg-[#0A2540] text-cyan-300 text-xs font-extrabold">
                        {selectedVessel.type} • {selectedVessel.lengthFeet} Pés
                      </span>
                      <span className="px-3.5 py-1.5 rounded-full bg-amber-400 text-slate-950 text-xs font-extrabold">
                        Operação: {selectedVessel.operationMode}
                      </span>
                    </div>
                  </div>

                  <div className="lg:col-span-5 bg-[#0A2540] text-white p-6 sm:p-8 flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                        Ficha Técnica Oficial da Embarcação
                      </span>
                      <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">{selectedVessel.name}</h1>
                      <p className="text-xs text-slate-300 mt-1">
                        Operador: <strong>{partner.name}</strong> ({selectedVessel.baseLocation})
                      </p>
                      <div className="mt-5 p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-300">Capacidade Homologada:</span>
                          <span className="font-bold text-cyan-300">{selectedVessel.capacity} passageiros</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-300">Comprimento:</span>
                          <span className="font-bold">{selectedVessel.lengthFeet} pés</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-300">Motorização:</span>
                          <span className="font-bold">{selectedVessel.engineSpec}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        setLightboxMedia({
                          title: selectedVessel.videoTitle,
                          url: selectedVessel.heroImage,
                          type: 'video',
                          subtitle: `${selectedVessel.name} • ${partner.name}`
                        })
                      }
                      className="mt-6 w-full py-3.5 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2"
                    >
                      <Play className="w-4 h-4 fill-slate-950" /> Reproduzir Vídeo da Embarcação
                    </button>
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  <p className="text-sm text-slate-700 leading-relaxed">{selectedVessel.description}</p>

                  <div className="grid grid-cols-3 gap-3">
                    {selectedVessel.gallery.map((img, i) => (
                      <div
                        key={i}
                        onClick={() =>
                          setLightboxMedia({
                            title: `${selectedVessel.name} — Foto ${i + 1}`,
                            url: img,
                            type: 'photo',
                            subtitle: partner.name
                          })
                        }
                        className="h-28 rounded-2xl overflow-hidden border border-slate-200 cursor-pointer"
                      >
                        <img src={img} alt="" className="w-full h-full object-cover hover:scale-105 transition" />
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                      <h4 className="text-xs font-extrabold text-slate-900">Conforto a Bordo</h4>
                      <ul className="mt-2 space-y-1 text-xs text-slate-600">
                        {selectedVessel.features.map((f, i) => <li key={i}>• {f}</li>)}
                      </ul>
                    </div>
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                      <h4 className="text-xs font-extrabold text-slate-900">Estrutura Interna</h4>
                      <ul className="mt-2 space-y-1 text-xs text-slate-600">
                        {selectedVessel.structure.map((st, i) => <li key={i}>• {st}</li>)}
                      </ul>
                    </div>
                    <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
                      <h4 className="text-xs font-extrabold text-slate-900">Equipamentos de Segurança</h4>
                      <ul className="mt-2 space-y-1 text-xs text-slate-700">
                        {selectedVessel.safetyEquipment.map((se, i) => <li key={i}>✓ {se}</li>)}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-200">
                    <h3 className="font-extrabold text-base text-slate-900 mb-3">
                      Passeios Realizados por Esta Embarcação ({vesselTours.length})
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {vesselTours.map((vt) => (
                        <div key={vt.id} className="p-4 rounded-2xl bg-[#FBF8F3] border border-slate-200 flex items-center justify-between gap-4">
                          <div>
                            <span className="text-[10px] font-bold uppercase text-cyan-700">{vt.tourType} • {vt.departurePoint}</span>
                            <h4 className="font-bold text-sm text-slate-900">{vt.title}</h4>
                            <p className="text-sm font-extrabold text-[#0A2540] mt-1">R$ {vt.price.toLocaleString('pt-BR')}</p>
                          </div>
                          <button
                            onClick={() => openBookingModalForTour(vt)}
                            className="px-3.5 py-2 rounded-xl bg-[#0A2540] text-white text-xs font-bold shrink-0"
                          >
                            Reservar
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </main>
      )}

      {/* ========================================================================
          PÁGINA 4: PÁGINAS DE LANCHAS E ESCUNAS (FROTA DOS PARCEIROS)
         ======================================================================== */}
      {activeTab === 'vessels' && !selectedVessel && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <div className="mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
              Frota Homologada na Capitania dos Portos
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-1">
              Lanchas Privativas e Escunas Tradicionais em Ubatuba
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Cada embarcação possui identidade visual, especificações de segurança e separação clara entre operação privativa e compartilhada.
            </p>
          </div>

          <div className="space-y-8">
            {vessels.map((vessel) => {
              const partner = partners.find((p) => p.id === vessel.partnerId);
              const vesselTours = tours.filter((t) => t.vesselId === vessel.id && t.status === 'APROVADO');
              return (
                <div
                  key={vessel.id}
                  className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm grid grid-cols-1 lg:grid-cols-12"
                >
                  <div className="lg:col-span-5 relative min-h-[280px]">
                    <img src={vessel.heroImage} alt={vessel.name} className="w-full h-full object-cover" />
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="px-3 py-1 rounded-full bg-[#0A2540] text-cyan-300 text-xs font-extrabold">
                        {vessel.type} • {vessel.lengthFeet} Pés
                      </span>
                      <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-extrabold">
                        Operação: {vessel.operationMode}
                      </span>
                    </div>
                  </div>

                  <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-bold text-cyan-700">
                          Proprietário / Operador: {partner?.name} ({vessel.baseLocation})
                        </span>
                        <span className="text-xs font-bold bg-slate-100 px-3 py-1 rounded-full">
                          Capacidade Homologada: {vessel.capacity} passageiros
                        </span>
                      </div>

                      <h2
                        onClick={() => setSelectedVesselId(vessel.id)}
                        className="text-2xl font-extrabold text-slate-900 mt-1.5 hover:text-cyan-700 cursor-pointer"
                      >
                        {vessel.name}
                      </h2>
                      <p className="text-xs text-slate-600 mt-2 leading-relaxed">{vessel.description}</p>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                          <h4 className="text-xs font-extrabold text-slate-900">Conforto a Bordo</h4>
                          <ul className="mt-1.5 space-y-1 text-xs text-slate-600">
                            {vessel.features.map((f, i) => (
                              <li key={i}>• {f}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                          <h4 className="text-xs font-extrabold text-slate-900">Estrutura Interna</h4>
                          <ul className="mt-1.5 space-y-1 text-xs text-slate-600">
                            {vessel.structure.map((st, i) => (
                              <li key={i}>• {st}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                          <h4 className="text-xs font-extrabold text-slate-900">Segurança & Motor</h4>
                          <p className="text-[11px] font-semibold text-cyan-800 mt-1">{vessel.engineSpec}</p>
                          <ul className="mt-1 space-y-1 text-xs text-slate-600">
                            {vessel.safetyEquipment.slice(0, 3).map((se, i) => (
                              <li key={i}>• {se}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap gap-2">
                        {vesselTours.map((vt) => (
                          <button
                            key={vt.id}
                            onClick={() => {
                              setSelectedTourId(vt.id);
                              setActiveTab('tours');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-900 text-xs font-bold border border-cyan-200"
                          >
                            {vt.tourType}: {vt.title.slice(0, 38)}... (R$ {vt.price})
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={() =>
                          setLightboxMedia({
                            title: vessel.videoTitle,
                            url: vessel.heroImage,
                            type: 'video',
                            subtitle: `${vessel.name} • ${partner?.name}`
                          })
                        }
                        className="px-4 py-2 rounded-xl bg-[#0A2540] text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        <Play className="w-3.5 h-3.5 text-cyan-400" /> Vídeo da Embarcação
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA 5: ROTEIROS TURÍSTICOS E COMPARADOR LADO A LADO
         ======================================================================== */}
      {activeTab === 'itineraries' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-10">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
              Planejamento Náutico & Comparador de Roteiros
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-1">
              Roteiros Turísticos de Ubatuba
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Compare tempo estimado, paradas de banho, condições de navegação e embarcações que confirmaram realizar cada percurso.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {itineraries.map((itin) => {
              const isSelectedForCompare = compareItineraryIds.includes(itin.id);
              const confirmedVessels = vessels.filter((v) => itin.confirmedVesselIds.includes(v.id));
              return (
                <div
                  key={itin.id}
                  className={`rounded-3xl overflow-hidden border transition-all flex flex-col bg-white ${
                    isSelectedForCompare ? 'border-cyan-500 ring-2 ring-cyan-500/20 shadow-lg' : 'border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="relative h-48">
                    <img src={itin.heroImage} alt={itin.title} className="w-full h-full object-cover" />
                    <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-900/85 text-cyan-300 text-xs font-bold">
                      {itin.region}
                    </span>
                  </div>

                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-900">{itin.title}</h3>
                      <p className="text-xs text-slate-600 mt-2 leading-relaxed">{itin.description}</p>

                      <div className="mt-4 space-y-1.5">
                        <p className="text-xs font-bold text-slate-800">Paradas Programadas:</p>
                        {itin.stopsDetails.map((st, i) => (
                          <p key={i} className="text-xs text-slate-600">
                            • {st}
                          </p>
                        ))}
                      </div>

                      <div className="mt-4 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                        <p className="font-bold text-slate-800">
                          Embarcações Confirmadas pelos Parceiros ({confirmedVessels.length}):
                        </p>
                        <div className="mt-1.5 flex flex-wrap gap-1">
                          {confirmedVessels.map((cv) => (
                            <span
                              key={cv.id}
                              className="px-2 py-0.5 rounded bg-cyan-50 text-cyan-900 font-semibold text-[11px]"
                            >
                              {cv.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600">{itin.estimatedDuration}</span>
                      <button
                        onClick={() => toggleCompareItinerary(itin.id)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                          isSelectedForCompare
                            ? 'bg-cyan-500 text-slate-950'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {isSelectedForCompare ? '✓ Na Tabela de Comparação' : '+ Comparar Roteiro'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Tabela Comparativa de Roteiros */}
          {compareItineraryIds.length > 0 && (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm overflow-x-auto">
              <h2 className="text-xl font-extrabold text-slate-900 mb-4">
                Comparativo Direto de Roteiros Selecionados ({compareItineraryIds.length})
              </h2>
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-3 pr-4">Atributo</th>
                    {itineraries
                      .filter((i) => compareItineraryIds.includes(i.id))
                      .map((i) => (
                        <th key={i.id} className="py-3 px-4 font-extrabold text-slate-900">
                          {i.title}
                        </th>
                      ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="py-3 pr-4 font-bold text-slate-700">Região Geográfica</td>
                    {itineraries
                      .filter((i) => compareItineraryIds.includes(i.id))
                      .map((i) => (
                        <td key={i.id} className="py-3 px-4 text-cyan-800 font-semibold">
                          {i.region}
                        </td>
                      ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-bold text-slate-700">Tempo Estimado</td>
                    {itineraries
                      .filter((i) => compareItineraryIds.includes(i.id))
                      .map((i) => (
                        <td key={i.id} className="py-3 px-4">
                          {i.estimatedDuration}
                        </td>
                      ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-bold text-slate-700">Condição de Navegação</td>
                    {itineraries
                      .filter((i) => compareItineraryIds.includes(i.id))
                      .map((i) => (
                        <td key={i.id} className="py-3 px-4 font-medium">
                          {i.navigationLevel}
                        </td>
                      ))}
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 font-bold text-slate-700">Observações Operacionais</td>
                    {itineraries
                      .filter((i) => compareItineraryIds.includes(i.id))
                      .map((i) => (
                        <td key={i.id} className="py-3 px-4 text-xs text-slate-600">
                          {i.navigationNotes}
                        </td>
                      ))}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </main>
      )}

      {/* ========================================================================
          PÁGINA 6: GALERIA DINÂMICA DE FOTOS E VÍDEOS (COM CONTROLE DE PROPRIEDADE)
         ======================================================================== */}
      {activeTab === 'gallery' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
          <div className="bg-[#0A2540] text-white rounded-3xl p-6 sm:p-8 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                Arquitetura de Mídia Preparada para Substituição (Supabase Storage)
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
                Galeria Dinâmica de Fotos e Vídeos de Ubatuba
              </h1>
              <p className="text-sm text-slate-300 mt-1 max-w-2xl">
                Álbuns separados por destino, embarcação e parceiro. Mídias de diferentes parceiros nunca são misturadas sem controle estrito de propriedade (`partner_id` + flag de autorização).
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {(['TODOS', 'Destino', 'Embarcação'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setGalleryCategoryFilter(cat)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold ${
                    galleryCategoryFilter === cat
                      ? 'bg-cyan-400 text-slate-950'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  {cat === 'TODOS' ? 'Todos os Álbuns' : `Álbuns por ${cat}`}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro por Titularidade / Parceiro */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
              <Shield className="w-4 h-4 text-cyan-700" />
              <span>Filtrar por Propriedade / Autorização de Mídia:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setGalleryPartnerFilter('TODOS')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                  galleryPartnerFilter === 'TODOS' ? 'bg-[#0A2540] text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                Acervo Completo Autorizado
              </button>
              <button
                onClick={() => setGalleryPartnerFilter('PLATFORM')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                  galleryPartnerFilter === 'PLATFORM' ? 'bg-[#0A2540] text-white' : 'bg-slate-100 text-slate-700'
                }`}
              >
                Acervo Oficial Plataforma
              </button>
              {partners
                .filter((p) => p.status === 'APROVADO')
                .map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setGalleryPartnerFilter(p.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                      galleryPartnerFilter === p.id ? 'bg-[#0A2540] text-white' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {p.name}
                  </button>
                ))}
            </div>
          </div>

          {/* Grid de Mídias com Lightbox e Player Integrado */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {mediaAssets
              .filter((m) => {
                if (galleryCategoryFilter !== 'TODOS' && m.category !== galleryCategoryFilter) return false;
                if (galleryPartnerFilter !== 'TODOS' && m.partnerId !== galleryPartnerFilter) return false;
                return true;
              })
              .map((asset) => (
                <div
                  key={asset.id}
                  className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition flex flex-col"
                >
                  <div
                    onClick={() =>
                      setLightboxMedia({
                        title: asset.title,
                        url: asset.url,
                        type: asset.type,
                        subtitle: `${asset.linkedEntityName} • Titular: ${asset.partnerName}`
                      })
                    }
                    className="relative h-56 cursor-pointer group overflow-hidden"
                  >
                    <img
                      src={asset.url}
                      alt={asset.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3 flex gap-1.5">
                      <span className="px-2.5 py-1 rounded-full bg-slate-950/80 text-cyan-300 text-[11px] font-bold uppercase">
                        {asset.type === 'video' ? `Vídeo (${asset.videoPreviewDuration})` : 'Fotografia HD'}
                      </span>
                      {asset.isProvisional && (
                        <span className="px-2.5 py-1 rounded-full bg-amber-400/95 text-slate-950 text-[10px] font-extrabold">
                          Slot Pronto p/ Mídia Real
                        </span>
                      )}
                    </div>
                    <div className="absolute inset-0 bg-slate-950/25 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
                      <div className="px-4 py-2 rounded-xl bg-white text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg">
                        {asset.type === 'video' ? <Play className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        <span>Ampliar em Tela Cheia</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-cyan-700 uppercase">
                        Álbum: {asset.linkedEntityName}
                      </span>
                      <h3 className="font-extrabold text-base text-slate-900 mt-1">{asset.title}</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Propriedade: <strong>{asset.partnerName}</strong>
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Uso Autorizado
                      </span>
                      <button
                        onClick={() =>
                          setLightboxMedia({
                            title: asset.title,
                            url: asset.url,
                            type: asset.type,
                            subtitle: `${asset.linkedEntityName} • Titular: ${asset.partnerName}`
                          })
                        }
                        className="font-bold text-slate-800 hover:text-cyan-700"
                      >
                        Abrir Mídia →
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>

          {/* Formulário Rápido de Upload / Substituição de Mídias Reais */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Upload className="w-5 h-5 text-cyan-600" /> Enviar ou Substituir Fotos e Vídeos Reais no Acervo
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Simule o upload de uma nova fotografia ou vídeo real vinculado a uma praia, ilha ou embarcação com controle de titularidade.
            </p>
            <form onSubmit={handleAddMediaAsset} className="mt-4 grid grid-cols-1 sm:grid-cols-5 gap-3">
              <input
                type="text"
                value={newMediaTitle}
                onChange={(e) => setNewMediaTitle(e.target.value)}
                placeholder="Título da foto ou vídeo real..."
                className="sm:col-span-2 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                required
              />
              <select
                value={newMediaType}
                onChange={(e) => setNewMediaType(e.target.value as any)}
                className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
              >
                <option value="photo">Fotografia (Alta Resolução)</option>
                <option value="video">Vídeo c/ Player Integrado</option>
              </select>
              <select
                value={newMediaTargetId}
                onChange={(e) => setNewMediaTargetId(e.target.value)}
                className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
              >
                {destinations.map((d) => (
                  <option key={d.id} value={d.id}>
                    Destino: {d.name}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold transition"
              >
                Publicar no Álbum
              </button>
            </form>
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA 7: PAINEL DOS PARCEIROS (ISOLAMENTO MULTI-TENANT — MISSÃO 02.18)
         ======================================================================== */}
      {activeTab === 'partner-portal' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
          <div className="bg-[#0A2540] text-white rounded-3xl p-6 sm:p-8 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-bold mb-2">
                <Lock className="w-3.5 h-3.5" /> Rota Azul • Operação Isolada do Parceiro (`partner_id = {activePartner.id || 'N/A'}`)
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold">
                Painel Operacional do Parceiro: {activePartner.name || 'Nenhum Parceiro Autorizado'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Visualize e gerencie exclusivamente seus próprios passeios, embarcações, reservas, ocupação de saídas e dados operacionais.
              </p>
            </div>

            {!isSupabaseConfigured && (
              <div>
                <label className="block text-[11px] font-bold uppercase text-cyan-300 mb-1">
                  Alternar Parceiro Ativo (Ambiente Demonstrativo):
                </label>
                <select
                  value={activePartnerId}
                  onChange={(e) => setActivePartnerId(e.target.value)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 text-white border border-cyan-500/40 text-xs font-bold"
                >
                  {partners.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.status})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {(() => {
            const partnerAuthCtx: OperationalAuthContext = {
              ...currentAuthContext,
              actorRole: 'partner',
              actorPartnerId: activePartner.id,
            };
            const partnerBookingsRes = queryOperationalBookings(operationalState, partnerAuthCtx, {
              partnerId: activePartner.id,
            });
            const partnerBookings = partnerBookingsRes.data || [];
            const partnerVessels = vessels.filter((v) => v.partnerId === activePartner.id);
            const partnerTours = tours.filter((t) => t.partnerId === activePartner.id);
            const partnerDeparturesRes = listOperationalDepartures(operationalState, partnerAuthCtx, {
              partnerId: activePartner.id,
              date: departureDateSelect || undefined,
              status: departureStatusSelect,
            });
            const partnerDepartures = partnerDeparturesRes.data || [];
            const partnerNetConsolidated = sumCurrencyExact(
              partnerBookings
                .filter((b) => b.status === 'PASSEIO_REALIZADO')
                .map((b) => b.netPartnerAmount)
            );

            return (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500 font-bold">Minhas Embarcações</span>
                    <p className="text-2xl font-extrabold text-slate-900 mt-1">{partnerVessels.length}</p>
                    <span className="text-[11px] text-slate-500">
                      {partnerVessels.filter((v) => isVesselEffectivelyActive(v)).length} disponíveis
                    </span>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500 font-bold">Meus Passeios</span>
                    <p className="text-2xl font-extrabold text-slate-900 mt-1">{partnerTours.length}</p>
                    <span className="text-[11px] text-slate-500">
                      {partnerTours.filter((t) => isTourEffectivelyActive(t)).length} ativos no catálogo
                    </span>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500 font-bold">Minhas Reservas</span>
                    <p className="text-2xl font-extrabold text-cyan-700 mt-1">{partnerBookings.length}</p>
                    <span className="text-[11px] text-slate-500">
                      {partnerBookings.filter((b) => b.status === 'CONFIRMADA').length} confirmadas
                    </span>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border border-slate-200">
                    <span className="text-xs text-slate-500 font-bold">Saídas Monitoradas</span>
                    <p className="text-2xl font-extrabold text-indigo-700 mt-1">{partnerDepartures.length}</p>
                    <span className="text-[11px] text-slate-500">Controle de ocupação</span>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 col-span-2 sm:col-span-1">
                    <span className="text-xs text-slate-500 font-bold">Repasse Consolidado</span>
                    <p className="text-2xl font-extrabold text-emerald-700 mt-1">
                      R$ {partnerNetConsolidated.toLocaleString('pt-BR')}
                    </p>
                    <span className="text-[11px] text-emerald-700">Passeios realizados</span>
                  </div>
                </div>

                {/* Navegação por Módulos do Parceiro */}
                <div className="flex flex-wrap gap-2 bg-white p-2 rounded-2xl border border-slate-200">
                  {[
                    { id: 'bookings', label: `Reservas (${partnerBookings.length})` },
                    { id: 'financial', label: `Financeiro & Repasses (${activePartnerFinancialSummary?.payments.length ?? 0})` },
                    { id: 'departures', label: `Saídas & Ocupação (${partnerDepartures.length})` },
                    { id: 'tours', label: `Meus Passeios (${partnerTours.length})` },
                    { id: 'vessels', label: `Minha Frota (${partnerVessels.length})` },
                    { id: 'profile', label: 'Dados Operacionais' },
                  ].map((tabItem) => (
                    <button
                      key={tabItem.id}
                      type="button"
                      onClick={() => setPartnerModuleTab(tabItem.id as any)}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold transition ${
                        partnerModuleTab === tabItem.id
                          ? 'bg-[#0A2540] text-cyan-300 shadow-sm'
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {tabItem.label}
                    </button>
                  ))}
                </div>

                {/* Aba 1 do Parceiro: Reservas Vinculadas */}
                {partnerModuleTab === 'bookings' && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h2 className="text-lg font-extrabold text-slate-900">
                        Reservas Vinculadas à Operação de {activePartner.name}
                      </h2>
                      <span className="text-xs text-slate-500">
                        Credenciais públicas e hashes HMAC ocultados por segurança (Missão 02.16/02.18)
                      </span>
                    </div>
                    {partnerBookings.length === 0 ? (
                      <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
                        Nenhuma reserva encontrada para a operação de {activePartner.name}.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {partnerBookings.map((bk) => (
                          <div
                            key={bk.id}
                            className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-4"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="px-2.5 py-0.5 rounded-md bg-[#0A2540] text-cyan-300 font-mono text-xs font-bold">
                                  {bk.code}
                                </span>
                                <span className="text-xs font-bold text-slate-800">{bk.customerName}</span>
                                <span className="text-xs text-slate-500">• {bk.customerContactMasked}</span>
                              </div>
                              <p className="text-sm font-bold text-slate-900 mt-1">
                                {bk.tourTitle} • <span className="text-cyan-800">{bk.vesselName}</span>
                              </p>
                              <p className="text-xs text-slate-600 mt-0.5">
                                Data: <strong>{bk.date}</strong> • Check-in: <strong>{bk.checkInTime}</strong> • Saída: <strong>{bk.departureTime}</strong> • Passageiros: <strong>{bk.passengers}</strong> • Embarque: <strong>{bk.departurePoint}</strong>
                              </p>
                              <p className="text-xs text-slate-500 mt-1">
                                Bruto: R$ {bk.grossAmount} | Comissão Plataforma ({bk.commissionRuleUsed}): R$ {bk.commissionAmount} | <strong>Seu Líquido: R$ {bk.netPartnerAmount}</strong>
                              </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                                  bk.status === 'PASSEIO_REALIZADO'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : bk.status === 'CONFIRMADA'
                                    ? 'bg-cyan-100 text-cyan-900'
                                    : bk.status === 'CANCELADA' || bk.status === 'RECUSADA'
                                    ? 'bg-rose-100 text-rose-800'
                                    : 'bg-amber-100 text-amber-900'
                                }`}
                              >
                                {bk.status}
                              </span>

                              {(bk.status === 'SOLICITADA' || bk.status === 'AGUARDANDO_CONFIRMACAO') && (
                                <button
                                  onClick={() => handleUpdateBookingStatus(bk.id, 'CONFIRMADA')}
                                  className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
                                >
                                  Confirmar Vaga
                                </button>
                              )}
                              {bk.status === 'CONFIRMADA' && (
                                <button
                                  onClick={() => handleUpdateBookingStatus(bk.id, 'PASSEIO_REALIZADO')}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                                >
                                  Marcar Passeio Realizado
                                </button>
                              )}
                              {(() => {
                                const payRec = financialStore.payments.find((p) => p.bookingId === bk.id);
                                const pStatus: PaymentStatusType | 'SEM_PAGAMENTO' = payRec ? payRec.paymentStatus : 'SEM_PAGAMENTO';
                                return (
                                  <>
                                    <span className="px-2.5 py-1 rounded-full bg-slate-200 text-slate-800 text-[11px] font-bold">
                                      Pgto: {pStatus}
                                    </span>
                                    {!payRec && bk.status !== 'CANCELADA' && bk.status !== 'RECUSADA' && (
                                      <button
                                        type="button"
                                        onClick={() => handleInitiateBookingPayment(bk.id, 'PIX')}
                                        className="px-2.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold"
                                      >
                                        Iniciar PIX
                                      </button>
                                    )}
                                    {payRec && (payRec.paymentStatus === 'PAGO' || payRec.paymentStatus === 'ESTORNO_PARCIAL') && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleRequestBookingRefund(
                                            bk.id,
                                            'Solicitação operacional de estorno registrada pelo parceiro'
                                          )
                                        }
                                        className="px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold"
                                      >
                                        Solicitar Estorno
                                      </button>
                                    )}
                                  </>
                                );
                              })()}
                              {(bk.status === 'SOLICITADA' || bk.status === 'AGUARDANDO_CONFIRMACAO' || bk.status === 'CONFIRMADA') && (
                                <button
                                  onClick={() =>
                                    handleUpdateBookingStatus(
                                      bk.id,
                                      bk.status === 'CONFIRMADA' ? 'CANCELADA' : 'RECUSADA',
                                      'Indisponibilidade operacional informada pelo parceiro'
                                    )
                                  }
                                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                                >
                                  Recusar / Cancelar
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Aba Financeira do Parceiro: Resumo de Pagamentos, Comissões e Repasses (Missão 02.22 — F03) */}
                {partnerModuleTab === 'financial' && activePartnerFinancialSummary && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h2 className="text-lg font-extrabold text-slate-900">
                          Demonstrativo Financeiro & Repasses — {activePartnerFinancialSummary.partnerName}
                        </h2>
                        <p className="text-xs text-slate-500">
                          A confirmação de pagamento (PAGO) e o processamento final de estornos são exclusivos do gateway/Admin. O parceiro pode iniciar cobrança ou solicitar estorno (ESTORNO_PENDENTE).
                        </p>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-extrabold">
                        Pagamentos Confirmados: {activePartnerFinancialSummary.paidBookingsCount}/{activePartnerFinancialSummary.totalBookingsCount}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-slate-500 font-bold">Volume Bruto</span>
                        <p className="text-lg font-extrabold text-slate-900 mt-1">
                          R$ {activePartnerFinancialSummary.grossVolumeTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-slate-500 font-bold">Comissão Plataforma</span>
                        <p className="text-lg font-extrabold text-indigo-800 mt-1">
                          R$ {activePartnerFinancialSummary.commissionRetainedByPlatform.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                        <span className="text-emerald-800 font-bold">Líquido Consolidado</span>
                        <p className="text-lg font-extrabold text-emerald-700 mt-1">
                          R$ {activePartnerFinancialSummary.netPartnerConsolidated.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                        <span className="text-amber-900 font-bold">Líquido Provisionado</span>
                        <p className="text-lg font-extrabold text-amber-800 mt-1">
                          R$ {activePartnerFinancialSummary.netPartnerPending.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                      <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 col-span-2 sm:col-span-1">
                        <span className="text-rose-800 font-bold">Total Estornado</span>
                        <p className="text-lg font-extrabold text-rose-700 mt-1">
                          R$ {activePartnerFinancialSummary.refundedTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-xs font-extrabold uppercase text-slate-500">
                        Pagamentos Vinculados ({activePartnerFinancialSummary.payments.length})
                      </h3>
                      {activePartnerFinancialSummary.payments.map((pay) => (
                        <div key={pay.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                          <div>
                            <span className="px-2 py-0.5 rounded bg-[#0A2540] text-cyan-300 font-mono font-bold">
                              {pay.bookingCode}
                            </span>
                            <span className="ml-2 font-bold text-slate-900">
                              {pay.paymentMethod} • Status: {pay.paymentStatus}
                            </span>
                            <p className="text-slate-600 mt-1">
                              Bruto: R$ {pay.grossAmount.toFixed(2)} | Pago: R$ {pay.paidGrossAmount.toFixed(2)} | Estornado: R$ {pay.refundedGrossAmount.toFixed(2)} | Comissão Efetiva: R$ {pay.effectiveCommissionAmount.toFixed(2)} | <strong>Líquido Parceiro: R$ {pay.effectiveNetPartnerAmount.toFixed(2)}</strong>
                            </p>
                          </div>
                          {(pay.paymentStatus === 'PAGO' || pay.paymentStatus === 'ESTORNO_PARCIAL') && (
                            <button
                              type="button"
                              onClick={() =>
                                handleRequestBookingRefund(
                                  pay.bookingId,
                                  'Solicitação de estorno pelo parceiro no painel financeiro'
                                )
                              }
                              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                            >
                              Solicitar Estorno (ESTORNO_PENDENTE)
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Aba 2 do Parceiro: Saídas e Ocupação */}
                {partnerModuleTab === 'departures' && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h2 className="text-lg font-extrabold text-slate-900">
                          Ocupação das Minhas Saídas ({partnerDepartures.length})
                        </h2>
                        <p className="text-xs text-slate-500">
                          Cálculo unificado de disponibilidade respeitando capacidade da embarcação, bloqueios e datas passadas.
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="date"
                          value={departureDateSelect}
                          onChange={(e) => setDepartureDateSelect(e.target.value)}
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                        {departureDateSelect && (
                          <button
                            type="button"
                            onClick={() => setDepartureDateSelect('')}
                            className="px-3 py-2 rounded-xl bg-slate-100 text-xs font-bold text-slate-700"
                          >
                            Ver Todas as Datas
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-500 uppercase">
                            <th className="py-2.5 px-3">Data / Horário</th>
                            <th className="py-2.5 px-3">Passeio / Embarque</th>
                            <th className="py-2.5 px-3">Embarcação</th>
                            <th className="py-2.5 px-3">Capacidade</th>
                            <th className="py-2.5 px-3">Reservado</th>
                            <th className="py-2.5 px-3">Vagas Restantes</th>
                            <th className="py-2.5 px-3">Situação da Saída</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {partnerDepartures.map((dep) => (
                            <tr key={dep.departureId} className="hover:bg-slate-50">
                              <td className="py-3 px-3 font-mono font-bold text-slate-900">
                                {dep.date}
                                <div className="text-[11px] font-sans text-slate-500">
                                  Check-in {dep.checkInTime} • {dep.departureTime}–{dep.returnTime}
                                </div>
                              </td>
                              <td className="py-3 px-3 font-bold text-slate-900">
                                {dep.tourTitle}
                                <div className="text-[11px] font-normal text-slate-500">{dep.departurePoint} ({dep.tourType})</div>
                              </td>
                              <td className="py-3 px-3 text-slate-700">{dep.vesselName}</td>
                              <td className="py-3 px-3 font-bold text-slate-800">{dep.effectiveCapacity} pax</td>
                              <td className="py-3 px-3 font-bold text-cyan-800">{dep.reservedPassengers} pax ({dep.occupancyPercent}%)</td>
                              <td className="py-3 px-3 font-extrabold text-emerald-700">{dep.remainingSeats} vagas</td>
                              <td className="py-3 px-3">
                                <span
                                  className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold ${
                                    dep.departureStatus === 'DISPONIVEL'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : dep.departureStatus === 'PARCIALMENTE_OCUPADA'
                                      ? 'bg-cyan-100 text-cyan-900'
                                      : dep.departureStatus === 'LOTADA'
                                      ? 'bg-amber-100 text-amber-900'
                                      : 'bg-slate-200 text-slate-700'
                                  }`}
                                >
                                  {dep.departureStatus}
                                </span>
                                {dep.blockReason && (
                                  <div className="text-[10px] text-rose-600 mt-0.5">{dep.blockReason}</div>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Aba 3 do Parceiro: Gestão de Passeios */}
                {partnerModuleTab === 'tours' && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Cadastrar e Gerenciar Passeios de {activePartner.name}
                    </h2>
                    <form onSubmit={handlePartnerCreateTour} className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                      <input
                        type="text"
                        value={newTourTitle}
                        onChange={(e) => setNewTourTitle(e.target.value)}
                        placeholder="Nome do passeio (ex: Lancha Ilha das Couves Sunset)..."
                        className="sm:col-span-2 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        required
                      />
                      <select
                        value={newTourVesselId || partnerVessels[0]?.id || ''}
                        onChange={(e) => setNewTourVesselId(e.target.value)}
                        className="px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      >
                        {partnerVessels.map((pv) => (
                          <option key={pv.id} value={pv.id}>
                            Barco: {pv.name} ({pv.capacity} pax)
                          </option>
                        ))}
                      </select>
                      <select
                        value={newTourDeparture}
                        onChange={(e) => setNewTourDeparture(e.target.value as any)}
                        className="px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      >
                        <option value="Praia do Itaguá">Saída: Praia do Itaguá</option>
                        <option value="Saco da Ribeira">Saída: Saco da Ribeira</option>
                        <option value="Praia de Picinguaba">Saída: Picinguaba</option>
                        <option value="Praia da Enseada">Saída: Enseada</option>
                      </select>
                      <select
                        value={newTourType}
                        onChange={(e) => setNewTourType(e.target.value as any)}
                        className="px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      >
                        <option value="Compartilhado">Compartilhado (Por Pessoa)</option>
                        <option value="Privativo">Privativo (Barco Fechado)</option>
                      </select>
                      <div className="flex gap-2">
                        <input
                          type="number"
                          min={50}
                          value={newTourPrice}
                          onChange={(e) => setNewTourPrice(Number(e.target.value))}
                          placeholder="Preço (R$)"
                          className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                        <button
                          type="submit"
                          className="px-4 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold shrink-0"
                        >
                          Cadastrar Passeio
                        </button>
                      </div>
                    </form>

                    <div className="pt-4 border-t border-slate-100 space-y-2">
                      <h3 className="text-xs font-extrabold uppercase text-slate-500">
                        Meus Passeios Cadastrados ({partnerTours.length})
                      </h3>
                      {partnerTours.map((pt) => (
                        <div key={pt.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                          <div>
                            <span className="font-bold text-slate-900">{pt.title}</span>
                            <span className="text-slate-500 ml-2">
                              ({pt.status} • {pt.isActive === false ? 'INATIVO' : 'ATIVO'} • {pt.departurePoint} • {pt.departureTime}–{pt.returnTime} • Cap: {pt.capacity} pax)
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span>R$:</span>
                            <input
                              type="number"
                              value={pt.price}
                              onChange={(e) => {
                                const val = Math.max(50, Number(e.target.value) || 50);
                                handleOperationalUpdateTour(pt.id, { price: val });
                              }}
                              className="w-20 px-2 py-1 rounded bg-white border border-slate-300 font-bold"
                            />
                            <button
                              type="button"
                              onClick={() => handleOperationalUpdateTour(pt.id, { isActive: pt.isActive === false })}
                              className="px-2.5 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold"
                            >
                              {pt.isActive === false ? 'Reativar' : 'Desativar'}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Aba 4 do Parceiro: Frota e Agenda */}
                {partnerModuleTab === 'vessels' && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
                      <h3 className="text-base font-extrabold text-slate-900">Cadastrar Nova Embarcação na Frota</h3>
                      <form onSubmit={handlePartnerCreateVessel} className="grid grid-cols-2 gap-2.5">
                        <input
                          type="text"
                          value={newVesselName}
                          onChange={(e) => setNewVesselName(e.target.value)}
                          placeholder="Nome da embarcação..."
                          className="col-span-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                          required
                        />
                        <select
                          value={newVesselType}
                          onChange={(e) => setNewVesselType(e.target.value as any)}
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        >
                          <option value="Lancha">Lancha</option>
                          <option value="Escuna">Escuna</option>
                          <option value="Catamarã / Flexboat">Catamarã / Flexboat</option>
                        </select>
                        <input
                          type="number"
                          min={1}
                          value={newVesselCapacity}
                          onChange={(e) => setNewVesselCapacity(Number(e.target.value))}
                          placeholder="Capacidade"
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                        <button
                          type="submit"
                          className="col-span-2 py-2.5 rounded-xl bg-[#0A2540] text-cyan-300 text-xs font-extrabold"
                        >
                          + Adicionar Embarcação à Frota
                        </button>
                      </form>

                      <div className="pt-3 border-t border-slate-100 space-y-2">
                        <h4 className="text-xs font-extrabold uppercase text-slate-500">Embarcações de {activePartner.name}</h4>
                        {partnerVessels.map((pv) => (
                          <div key={pv.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                            <div>
                              <span className="font-bold text-slate-900">{pv.name}</span>
                              <span className="text-slate-500 ml-2">({pv.type} • {pv.capacity} vagas • {pv.availabilityStatus || 'DISPONIVEL'})</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                min={1}
                                value={pv.capacity}
                                onChange={(e) => handleOperationalUpdateVessel(pv.id, { capacity: Number(e.target.value) })}
                                className="w-16 px-2 py-1 rounded bg-white border border-slate-300 font-bold"
                                title="Capacidade máxima (validada contra ocupações ativas)"
                              />
                              <button
                                type="button"
                                onClick={() =>
                                  handleOperationalUpdateVessel(pv.id, {
                                    isActive: pv.isActive === false,
                                    availabilityStatus: pv.isActive === false ? 'DISPONIVEL' : 'INATIVA',
                                  })
                                }
                                className="px-2.5 py-1 rounded-lg bg-slate-200 text-slate-800 font-bold"
                              >
                                {pv.isActive === false ? 'Ativar' : 'Desativar'}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
                      <h3 className="text-base font-extrabold text-slate-900">Bloquear Data na Agenda (Manutenção / Férias)</h3>
                      <form onSubmit={handleAddAvailabilityBlock} className="grid grid-cols-2 gap-2.5">
                        <input
                          type="date"
                          min={currentBrazilDate}
                          value={blockDateInput}
                          onChange={(e) => setBlockDateInput(e.target.value)}
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                          required
                        />
                        <select
                          value={blockTypeInput}
                          onChange={(e) => setBlockTypeInput(e.target.value as AvailabilityBlockType)}
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        >
                          <option value="MANUTENCAO">Manutenção</option>
                          <option value="BLOQUEIO_TOTAL">Bloqueio Total</option>
                          <option value="INTERDICAO_MARINHA">Aviso Marinha</option>
                        </select>
                        <input
                          type="text"
                          value={blockReasonInput}
                          onChange={(e) => setBlockReasonInput(e.target.value)}
                          placeholder="Observação do bloqueio..."
                          className="col-span-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                        <button
                          type="submit"
                          className="col-span-2 py-2.5 rounded-xl bg-amber-400 text-slate-950 text-xs font-extrabold"
                        >
                          Registrar Bloqueio de Agenda
                        </button>
                      </form>
                      {availabilityBlocks.filter((b) => b.partnerId === activePartner.id).length > 0 && (
                        <div className="pt-2 border-t border-slate-100 space-y-1.5">
                          {availabilityBlocks
                            .filter((b) => b.partnerId === activePartner.id)
                            .map((blk) => (
                              <div key={blk.id} className="flex items-center justify-between text-xs bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                                <span className="font-semibold text-slate-700">
                                  {blk.vesselName} • {blk.blockDate} ({blk.blockType})
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveAvailabilityBlock(blk.id)}
                                  className="text-rose-600 hover:text-rose-700 font-bold"
                                >
                                  Remover
                                </button>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Aba 5 do Parceiro: Atualização dos Próprios Dados Operacionais */}
                {partnerModuleTab === 'profile' && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Dados Operacionais de {activePartner.name}
                    </h2>
                    <p className="text-xs text-slate-500">
                      Você pode atualizar seus dados operacionais autorizados (WhatsApp, e-mail, marina base e descrição). Regras de comissão e homologação são exclusivas da administração.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-slate-500 block">Razão Social & CNPJ</span>
                        <strong className="text-slate-900">{activePartner.legalName} ({activePartner.cnpj})</strong>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-slate-500 block">Situação Cadastral</span>
                        <strong className="text-emerald-700">{activePartner.status}</strong>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <span className="text-slate-500 block">Marina Base / WhatsApp</span>
                        <strong className="text-slate-900">{activePartner.baseMarina} • {activePartner.whatsapp}</strong>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                      <input
                        type="text"
                        placeholder={`Novo WhatsApp (${activePartner.whatsapp})`}
                        value={editPartnerPhone}
                        onChange={(e) => setEditPartnerPhone(e.target.value)}
                        className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      />
                      <input
                        type="email"
                        placeholder={`Novo E-mail (${activePartner.email})`}
                        value={editPartnerEmail}
                        onChange={(e) => setEditPartnerEmail(e.target.value)}
                        className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      />
                      <input
                        type="text"
                        placeholder={`Marina Base (${activePartner.baseMarina})`}
                        value={editPartnerMarina}
                        onChange={(e) => setEditPartnerMarina(e.target.value)}
                        className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      />
                      <button
                        type="button"
                        onClick={() => handleSavePartnerEdit(activePartner.id)}
                        className="px-4 py-2 rounded-xl bg-[#0A2540] text-cyan-300 text-xs font-extrabold"
                      >
                        Salvar Dados Operacionais
                      </button>
                    </div>
                  </div>
                )}
              </>
            );
          })()}
        </main>
      )}

      {/* ========================================================================
          PÁGINA 8: PAINEL ADMINISTRATIVO MASTER — ROTA AZUL (MISSÃO 02.18)
         ======================================================================== */}
      {activeTab === 'admin-portal' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
          <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-amber-400/30 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold mb-2">
                <Shield className="w-3.5 h-3.5" /> Rota Azul • Governança Operacional & Painel Administrativo
                <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono text-[10px]">
                  {isSupabaseConfigured ? 'CONECTADO SUPABASE' : canUseDemoData ? 'AMBIENTE DEMONSTRATIVO LOCAL' : 'ESTADO VAZIO'}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
                Central de Operações, Parceiros, Passeios, Embarcações, Reservas e Saídas
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Indicadores calculados em tempo real a partir da camada operacional, com separação de permissões e proteção de integridade.
              </p>
            </div>
            {canUseDemoData && (
              <button
                onClick={handleResetDatabase}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-xs font-bold text-slate-200"
              >
                Restaurar Base Demonstrativa
              </button>
            )}
          </div>

          {/* Navegação dos 6 Módulos Administrativos (Seções 3.1 a 3.6) */}
          <div className="flex flex-wrap gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
            {[
              { id: 'overview', label: '3.1 Visão Consolidada & Indicadores' },
              { id: 'partners', label: `3.2 Gestão de Parceiros (${partners.length})` },
              { id: 'tours', label: `3.3 Gestão de Passeios (${tours.length})` },
              { id: 'vessels', label: `3.4 Gestão de Embarcações (${vessels.length})` },
              { id: 'bookings', label: `3.5 Gestão de Reservas (${bookings.length})` },
              { id: 'departures', label: '3.6 Saídas & Ocupação' },
              { id: 'financial', label: `3.7 Pagamentos & Conciliação (${financialReconciliationReport?.divergentCount ?? 0} div.)` },
            ].map((mod) => (
              <button
                key={mod.id}
                type="button"
                onClick={() => setAdminModuleTab(mod.id as any)}
                className={`px-4 py-2.5 rounded-xl text-xs font-extrabold transition ${
                  adminModuleTab === mod.id
                    ? 'bg-[#0A2540] text-amber-300 shadow-sm'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {mod.label}
              </button>
            ))}
          </div>

          {/* 3.1. VISÃO CONSOLIDADA DA OPERAÇÃO E INDICADORES */}
          {adminModuleTab === 'overview' && adminDashboardMetrics && (
            <div className="space-y-6">
              {adminDashboardMetrics.isEmptyState && (
                <div className="p-6 rounded-2xl bg-amber-50 border border-amber-300 text-amber-900 text-xs font-semibold">
                  Estado vazio: não há registros carregados na camada de persistência atual.
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Total de Passeios</span>
                  <p className="text-xl font-extrabold text-slate-900 mt-1">{adminDashboardMetrics.totalTours}</p>
                  <span className="text-[10px] text-emerald-700 font-bold">
                    {adminDashboardMetrics.activeTours} ativos • {adminDashboardMetrics.inactiveTours} inativos
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Total de Parceiros</span>
                  <p className="text-xl font-extrabold text-slate-900 mt-1">{adminDashboardMetrics.totalPartners}</p>
                  <span className="text-[10px] text-cyan-800 font-bold">
                    {adminDashboardMetrics.activePartners} ativos • {adminDashboardMetrics.pendingPartners} pendentes
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Total Embarcações</span>
                  <p className="text-xl font-extrabold text-slate-900 mt-1">{adminDashboardMetrics.totalVessels}</p>
                  <span className="text-[10px] text-slate-600 font-bold">
                    {adminDashboardMetrics.activeVessels} operacionais
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Reservas Recebidas</span>
                  <p className="text-xl font-extrabold text-cyan-800 mt-1">{adminDashboardMetrics.bookingsReceived}</p>
                  <span className="text-[10px] text-amber-700 font-bold">
                    {adminDashboardMetrics.bookingsPending} pendentes
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Reservas Confirmadas</span>
                  <p className="text-xl font-extrabold text-emerald-700 mt-1">{adminDashboardMetrics.bookingsConfirmed}</p>
                  <span className="text-[10px] text-rose-700 font-bold">
                    {adminDashboardMetrics.bookingsCancelledOrRejected} canceladas/recusadas
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 font-bold">Passeios Realizados</span>
                  <p className="text-xl font-extrabold text-emerald-800 mt-1">{adminDashboardMetrics.completedToursCount}</p>
                  <span className="text-[10px] text-emerald-700 font-bold">
                    GMV R$ {adminDashboardMetrics.grossConsolidatedAmount.toLocaleString('pt-BR')}
                  </span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 col-span-2 sm:col-span-1">
                  <span className="text-[11px] text-slate-500 font-bold">Ocupação de Saídas</span>
                  <p className="text-xl font-extrabold text-indigo-800 mt-1">
                    {adminDashboardMetrics.departuresSummary.averageOccupancyPercent}%
                  </p>
                  <span className="text-[10px] text-slate-600 font-bold">
                    {adminDashboardMetrics.departuresSummary.totalReservedSeats}/{adminDashboardMetrics.departuresSummary.totalCapacitySeats} vagas
                  </span>
                </div>
              </div>

              {/* Resumo Financeiro de Comissões */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <span className="text-xs text-slate-500 font-bold">GMV Consolidado (Passeios Realizados)</span>
                  <p className="text-2xl font-extrabold text-slate-900 mt-1">
                    R$ {financialMetrics.totalGrossConsolidated.toLocaleString('pt-BR')}
                  </p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-emerald-300 bg-emerald-50/40">
                  <span className="text-xs text-emerald-800 font-bold">
                    Receita de Comissões Consolidada ({financialMetrics.consolidatedCount})
                  </span>
                  <p className="text-2xl font-extrabold text-emerald-700 mt-1">
                    R$ {financialMetrics.totalCommissionConsolidated.toLocaleString('pt-BR')}
                  </p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-amber-300 bg-amber-50/40">
                  <span className="text-xs text-amber-900 font-bold">
                    Comissões Pendentes ({financialMetrics.pendingCount} reservas ativas)
                  </span>
                  <p className="text-2xl font-extrabold text-amber-700 mt-1">
                    R$ {financialMetrics.totalCommissionPending.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>

              {/* Histórico Recente de Atividades Operacionais */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                <h2 className="text-lg font-extrabold text-slate-900 mb-3">
                  Histórico Recente de Atividades Operacionais ({adminDashboardMetrics.recentActivities.length})
                </h2>
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {adminDashboardMetrics.recentActivities.map((act) => (
                    <div key={act.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="px-2 py-0.5 rounded bg-[#0A2540] text-cyan-300 font-mono text-[10px] font-bold mr-2">
                          {act.action}
                        </span>
                        <strong className="text-slate-900">{act.entityName}</strong> — <span className="text-slate-600">{act.summary}</span>
                      </div>
                      <span className="text-slate-400 font-mono text-[11px]">{act.timestamp} ({act.actorName})</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 3.2. GESTÃO DE PARCEIROS */}
          {adminModuleTab === 'partners' && (() => {
            const adminCtx: OperationalAuthContext = { ...currentAuthContext, actorRole: 'admin' };
            const partnerViewsRes = listPartnersWithOperationalDetails(operationalState, adminCtx, {
              search: partnerSearchQuery,
              status: partnerStatusFilter,
            });
            const partnerViews = partnerViewsRes.data || [];

            return (
              <div className="space-y-6">
                {/* Formulário de Cadastro de Novo Parceiro */}
                <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                  <h2 className="text-lg font-extrabold text-slate-900">Cadastrar Novo Parceiro Náutico</h2>
                  <form onSubmit={handleAdminCreatePartner} className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                    <input
                      type="text"
                      value={newPartnerName}
                      onChange={(e) => setNewPartnerName(e.target.value)}
                      placeholder="Nome Fantasia..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      required
                    />
                    <input
                      type="text"
                      value={newPartnerLegalName}
                      onChange={(e) => setNewPartnerLegalName(e.target.value)}
                      placeholder="Razão Social..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <input
                      type="text"
                      value={newPartnerCnpj}
                      onChange={(e) => setNewPartnerCnpj(e.target.value)}
                      placeholder="CNPJ (14 dígitos)..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      required
                    />
                    <input
                      type="text"
                      value={newPartnerWhatsapp}
                      onChange={(e) => setNewPartnerWhatsapp(e.target.value)}
                      placeholder="WhatsApp (551299...)"
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      required
                    />
                    <input
                      type="email"
                      value={newPartnerEmail}
                      onChange={(e) => setNewPartnerEmail(e.target.value)}
                      placeholder="E-mail corporativo..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                    >
                      + Cadastrar Parceiro
                    </button>
                  </form>
                </div>

                {/* Busca, Filtros e Listagem de Parceiros */}
                <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Parceiros Cadastrados ({partnerViews.length})
                    </h2>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        value={partnerSearchQuery}
                        onChange={(e) => setPartnerSearchQuery(e.target.value)}
                        placeholder="Buscar por nome, CNPJ ou marina..."
                        className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                      />
                      <select
                        value={partnerStatusFilter}
                        onChange={(e) => setPartnerStatusFilter(e.target.value as any)}
                        className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                      >
                        <option value="TODOS">Todas as Situações</option>
                        <option value="APROVADO">Aprovados</option>
                        <option value="PENDENTE">Pendentes de Aprovação</option>
                        <option value="SUSPENSO">Suspensos / Rejeitados</option>
                        <option value="INATIVO">Inativos</option>
                        <option value="COM_PENDENCIAS">Com Pendências Cadastrais</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {partnerViews.map(({ partner: p, pendingIssues, vesselsCount, toursCount, bookingsCount, history }) => (
                      <div key={p.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-4">
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-extrabold text-sm text-slate-900">{p.name}</span>
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                                  p.status === 'APROVADO' && p.isActive !== false
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : p.status === 'PENDENTE'
                                    ? 'bg-amber-100 text-amber-900'
                                    : 'bg-rose-100 text-rose-800'
                                }`}
                              >
                                {p.status} {p.isActive === false ? '(INATIVO)' : ''}
                              </span>
                              <span className="text-xs text-slate-500">
                                {vesselsCount} embarcações • {toursCount} passeios • {bookingsCount} reservas
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {p.legalName} • CNPJ: {p.cnpj} • Marina: {p.baseMarina} • WhatsApp: {p.whatsapp} • {p.email}
                            </p>
                            {pendingIssues.length > 0 && (
                              <div className="mt-1.5 flex flex-wrap gap-1.5">
                                {pendingIssues.map((iss, idx) => (
                                  <span key={idx} className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 text-[10px] font-bold">
                                    Pendência: {iss}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-2">
                            <select
                              value={p.commissionModel}
                              onChange={(e) => {
                                const model = e.target.value as Partner['commissionModel'];
                                setPartners((prev) =>
                                  prev.map((item) => {
                                    if (item.id !== p.id) return item;
                                    const nextRate = model !== 'FIXED_AMOUNT' && item.commissionRate <= 0 ? 15 : item.commissionRate;
                                    const nextFixed = model !== 'PERCENTAGE' && item.commissionFixed <= 0 ? 25 : item.commissionFixed;
                                    return { ...item, commissionModel: model, commissionRate: nextRate, commissionFixed: nextFixed };
                                  })
                                );
                                appendAuditLog('UPDATE_COMMISSION', p.name, `Modelo alterado para ${model}`);
                                showToast('Modelo de Comissão Atualizado', `Parceiro ${p.name} agora usa ${model}.`);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-xs font-bold"
                            >
                              <option value="PERCENTAGE">Comissão Percentual (%)</option>
                              <option value="FIXED_AMOUNT">Comissão Fixa (R$)</option>
                              <option value="CUSTOM_OVERRIDE">Personalizada Híbrida (% + R$)</option>
                            </select>

                            {p.status !== 'APROVADO' ? (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    handleModeratePartner(p.id, 'APROVAR', 'Homologação cadastral concluída');
                                    handleAdminModerateOnboardingAction(p.id, 'APROVAR', 'Homologação de onboarding aprovada');
                                  }}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                                >
                                  Aprovar Cadastro
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleModeratePartner(p.id, 'REJEITAR', 'Documentação naval pendente')}
                                  className="px-3 py-1.5 rounded-xl bg-rose-100 text-rose-800 text-xs font-bold"
                                >
                                  Rejeitar
                                </button>
                              </>
                            ) : (
                              <button
                                type="button"
                                onClick={() =>
                                  handleModeratePartner(
                                    p.id,
                                    p.isActive === false ? 'ATIVAR' : 'DESATIVAR',
                                    p.isActive === false ? 'Reativação operacional' : 'Desativação temporária pelo Admin'
                                  )
                                }
                                className="px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 text-xs font-bold"
                              >
                                {p.isActive === false ? 'Reativar' : 'Desativar'}
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => setInspectingPartnerId(inspectingPartnerId === p.id ? null : p.id)}
                              className="px-3 py-1.5 rounded-xl bg-slate-200 text-slate-800 text-xs font-bold"
                            >
                              {inspectingPartnerId === p.id ? 'Ocultar Detalhes' : 'Detalhes & Histórico'}
                            </button>
                          </div>
                        </div>

                        {inspectingPartnerId === p.id && (
                          <div className="pt-3 border-t border-slate-200 text-xs space-y-2">
                            <p className="text-slate-700">
                              <strong>Bio / Operação:</strong> {p.bio}
                            </p>
                            {history.length > 0 && (
                              <div className="space-y-1">
                                <strong className="text-slate-600">Histórico de Alterações ({history.length}):</strong>
                                {history.slice(0, 5).map((h) => (
                                  <div key={h.id} className="text-[11px] text-slate-500">
                                    • [{h.timestamp}] {h.action}: {h.summary}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* 3.3. GESTÃO DE PASSEIOS */}
          {adminModuleTab === 'tours' && (
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <h2 className="text-lg font-extrabold text-slate-900">Cadastrar Novo Passeio Náutico</h2>
                <form onSubmit={handlePartnerCreateTour} className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                  <input
                    type="text"
                    value={newTourTitle}
                    onChange={(e) => setNewTourTitle(e.target.value)}
                    placeholder="Título do passeio..."
                    className="sm:col-span-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <select
                    value={newTourPartnerSelect}
                    onChange={(e) => {
                      setNewTourPartnerSelect(e.target.value);
                      const firstV = vessels.find((v) => v.partnerId === e.target.value);
                      if (firstV) setNewTourVesselId(firstV.id);
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    {partners.map((p) => (
                      <option key={p.id} value={p.id}>
                        Parceiro: {p.name}
                      </option>
                    ))}
                  </select>
                  <select
                    value={newTourVesselId || vessels.find((v) => v.partnerId === newTourPartnerSelect)?.id || ''}
                    onChange={(e) => setNewTourVesselId(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    {vessels
                      .filter((v) => v.partnerId === newTourPartnerSelect)
                      .map((v) => (
                        <option key={v.id} value={v.id}>
                          Embarcação: {v.name} ({v.capacity} pax)
                        </option>
                      ))}
                  </select>
                  <input
                    type="number"
                    min={50}
                    value={newTourPrice}
                    onChange={(e) => setNewTourPrice(Number(e.target.value))}
                    placeholder="Preço (R$)"
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                  >
                    + Publicar Passeio
                  </button>
                </form>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-lg font-extrabold text-slate-900">
                    Moderação, Horários, Capacidade e Exclusão Segura de Passeios ({tours.length})
                  </h2>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={adminTourSearch}
                      onChange={(e) => setAdminTourSearch(e.target.value)}
                      placeholder="Buscar passeio ou embarque..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <select
                      value={adminTourPartnerFilter}
                      onChange={(e) => setAdminTourPartnerFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todos os Parceiros</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                    <select
                      value={adminTourStatusFilter}
                      onChange={(e) => setAdminTourStatusFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todas as Situações</option>
                      <option value="APROVADO">Aprovados</option>
                      <option value="PENDENTE_APROVACAO">Pendentes de Aprovação</option>
                      <option value="SUSPENSO">Suspensos / Arquivados</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-3">
                  {tours
                    .filter((t) => {
                      if (adminTourPartnerFilter !== 'TODOS' && t.partnerId !== adminTourPartnerFilter) return false;
                      if (adminTourStatusFilter !== 'TODOS' && t.status !== adminTourStatusFilter) return false;
                      if (adminTourSearch.trim() !== '') {
                        const q = adminTourSearch.toLowerCase();
                        return t.title.toLowerCase().includes(q) || t.departurePoint.toLowerCase().includes(q);
                      }
                      return true;
                    })
                    .map((t) => {
                      const linkedBookingsCount = bookings.filter((b) => b.tourId === t.id).length;
                      const ownerPartner = partners.find((p) => p.id === t.partnerId);
                      const linkedVessel = vessels.find((v) => v.id === t.vesselId);
                      return (
                        <div
                          key={t.id}
                          className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-4"
                        >
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                                  t.status === 'APROVADO' && t.isActive !== false
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-900'
                                }`}
                              >
                                {t.status} {t.isActive === false ? '(INATIVO)' : ''}
                              </span>
                              <span className="text-xs text-slate-500">
                                Parceiro: <strong>{ownerPartner?.name || t.partnerId}</strong> • Embarcação: <strong>{linkedVessel?.name || t.vesselId}</strong>
                              </span>
                            </div>
                            <h4 className="font-bold text-sm text-slate-900 mt-1">{t.title}</h4>
                            <p className="text-xs text-slate-500">
                              R$ {t.price} ({t.pricingModel}) • Check-in {t.checkInTime} • Saída {t.departureTime} • Retorno {t.returnTime} ({t.durationHours}h) • Cap: {t.capacity} pax • Embarque: {t.departurePoint} • Reservas vinculadas: <strong>{linkedBookingsCount}</strong>
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center gap-2">
                            {t.status !== 'APROVADO' && (
                              <button
                                type="button"
                                onClick={() => handleOperationalUpdateTour(t.id, { status: 'APROVADO', isActive: true })}
                                className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                              >
                                Aprovar e Publicar
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleOperationalUpdateTour(t.id, { isActive: t.isActive === false })}
                              className="px-3 py-1.5 rounded-xl bg-amber-100 text-amber-900 text-xs font-bold"
                            >
                              {t.isActive === false ? 'Reativar Passeio' : 'Desativar / Arquivar'}
                            </button>

                            {confirmDeleteTourId === t.id ? (
                              <div className="flex items-center gap-1.5 bg-rose-50 px-2.5 py-1 rounded-xl border border-rose-200">
                                <span className="text-[11px] font-bold text-rose-800">Confirmar exclusão?</span>
                                <button
                                  type="button"
                                  onClick={() => handleOperationalSafeDeleteTour(t.id)}
                                  className="px-2 py-0.5 rounded bg-rose-600 text-white text-[11px] font-bold"
                                >
                                  Sim
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteTourId(null)}
                                  className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-[11px] font-bold"
                                >
                                  Não
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteTourId(t.id)}
                                className="px-3 py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold"
                              >
                                Excluir com Segurança
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* 3.4. GESTÃO DE EMBARCAÇÕES */}
          {adminModuleTab === 'vessels' && (
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <h2 className="text-lg font-extrabold text-slate-900">Cadastrar Embarcação Homologada</h2>
                <form onSubmit={handlePartnerCreateVessel} className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                  <input
                    type="text"
                    value={newVesselName}
                    onChange={(e) => setNewVesselName(e.target.value)}
                    placeholder="Nome da embarcação..."
                    className="sm:col-span-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <select
                    value={newVesselPartnerSelect}
                    onChange={(e) => setNewVesselPartnerSelect(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    {partners.map((p) => (
                      <option key={p.id} value={p.id}>
                        Proprietário: {p.name}
                      </option>
                    ))}
                  </select>
                  <select
                    value={newVesselType}
                    onChange={(e) => setNewVesselType(e.target.value as any)}
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  >
                    <option value="Lancha">Lancha</option>
                    <option value="Escuna">Escuna</option>
                    <option value="Catamarã / Flexboat">Catamarã / Flexboat</option>
                  </select>
                  <input
                    type="number"
                    min={1}
                    max={250}
                    value={newVesselCapacity}
                    onChange={(e) => setNewVesselCapacity(Number(e.target.value))}
                    placeholder="Capacidade máxima"
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                  >
                    + Cadastrar Embarcação
                  </button>
                </form>
              </div>

              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-lg font-extrabold text-slate-900">
                    Frota Cadastrada & Controle de Capacidade ({vessels.length})
                  </h2>
                  <input
                    type="text"
                    value={adminVesselSearch}
                    onChange={(e) => setAdminVesselSearch(e.target.value)}
                    placeholder="Buscar embarcação..."
                    className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  />
                </div>
                <div className="space-y-3">
                  {vessels
                    .filter((v) => !adminVesselSearch.trim() || v.name.toLowerCase().includes(adminVesselSearch.toLowerCase()))
                    .map((v) => {
                      const owner = partners.find((p) => p.id === v.partnerId);
                      return (
                        <div key={v.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs">
                          <div>
                            <span className="font-extrabold text-sm text-slate-900">{v.name}</span>
                            <span className="ml-2 px-2 py-0.5 rounded bg-cyan-100 text-cyan-900 font-bold">
                              {v.type} • {v.lengthFeet} pés
                            </span>
                            <p className="text-slate-500 mt-1">
                              Proprietário: <strong>{owner?.name || v.partnerId}</strong> • Base: {v.baseLocation} • Motorização: {v.engineSpec} • Situação: <strong>{v.availabilityStatus || 'DISPONIVEL'}</strong>
                            </p>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-slate-600 font-bold">Capacidade máx.:</span>
                            <input
                              type="number"
                              min={1}
                              value={v.capacity}
                              onChange={(e) => handleOperationalUpdateVessel(v.id, { capacity: Number(e.target.value) })}
                              className="w-16 px-2 py-1 rounded bg-white border border-slate-300 font-bold"
                            />
                            <select
                              value={v.availabilityStatus || 'DISPONIVEL'}
                              onChange={(e) =>
                                handleOperationalUpdateVessel(v.id, {
                                  availabilityStatus: e.target.value as VesselOperationalStatus,
                                  isActive: e.target.value === 'DISPONIVEL',
                                })
                              }
                              className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 font-bold"
                            >
                              <option value="DISPONIVEL">Disponível</option>
                              <option value="MANUTENCAO">Em Manutenção</option>
                              <option value="INATIVA">Inativa</option>
                            </select>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          {/* 3.5. GESTÃO ADMINISTRATIVA DE RESERVAS (CAMADA PRÓPRIA SEM EXPOR TOKENS/HMAC) */}
          {adminModuleTab === 'bookings' && (() => {
            const adminCtx: OperationalAuthContext = { ...currentAuthContext, actorRole: 'admin' };
            const adminBookingsRes = queryOperationalBookings(operationalState, adminCtx, {
              code: adminBookingSearchCode,
              partnerId: adminBookingPartnerFilter,
              tourId: adminBookingTourFilter,
              date: adminBookingDateFilter,
              status: adminBookingFilter as any,
            });
            const adminBookings = adminBookingsRes.data || [];

            return (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Central Administrativa de Reservas ({adminBookings.length})
                    </h2>
                    <p className="text-xs text-slate-500">
                      Consulta operacional dedicada (não utiliza a RPC pública do turista e oculta `lookup_token`, HMACs e segredos).
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={adminBookingSearchCode}
                      onChange={(e) => setAdminBookingSearchCode(e.target.value)}
                      placeholder="Buscar código (UBT-...) ou passeio..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <select
                      value={adminBookingPartnerFilter}
                      onChange={(e) => setAdminBookingPartnerFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todos os Parceiros</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                    <select
                      value={adminBookingTourFilter}
                      onChange={(e) => setAdminBookingTourFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todos os Passeios</option>
                      {tours.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.title}
                        </option>
                      ))}
                    </select>
                    <input
                      type="date"
                      value={adminBookingDateFilter}
                      onChange={(e) => setAdminBookingDateFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <select
                      value={adminBookingFilter}
                      onChange={(e) => setAdminBookingFilter(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODAS">Todas as Situações</option>
                      <option value="SOLICITADA">SOLICITADA</option>
                      <option value="AGUARDANDO_CONFIRMACAO">AGUARDANDO_CONFIRMACAO</option>
                      <option value="CONFIRMADA">CONFIRMADA</option>
                      <option value="PASSEIO_REALIZADO">PASSEIO_REALIZADO</option>
                      <option value="CANCELADA">CANCELADA</option>
                      <option value="RECUSADA">RECUSADA</option>
                      <option value="EM_DISPUTA">EM_DISPUTA</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {adminBookings.map((bk) => (
                    <div key={bk.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div>
                        <span className="px-2 py-0.5 rounded bg-[#0A2540] text-cyan-300 font-mono font-bold">{bk.code}</span>
                        <span className="font-extrabold text-slate-900 ml-2">{bk.customerName}</span>
                        <span className="text-slate-500 ml-2">• {bk.customerContactMasked}</span>
                        <p className="text-slate-800 font-bold mt-1">
                          {bk.tourTitle} • {bk.vesselName} ({bk.partnerName})
                        </p>
                        <p className="text-slate-600 mt-0.5">
                          Data: <strong>{bk.date}</strong> ({bk.departureTime}–{bk.returnTime}) • Passageiros: <strong>{bk.passengers}</strong> • Embarque: {bk.departurePoint} • Bruto: R$ {bk.grossAmount} | <strong>Comissão: R$ {bk.commissionAmount}</strong> | Líquido Parceiro: R$ {bk.netPartnerAmount}
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-1 rounded-full bg-slate-200 text-slate-800 font-bold">{bk.status}</span>
                        {(bk.status === 'SOLICITADA' || bk.status === 'AGUARDANDO_CONFIRMACAO') && (
                          <button
                            onClick={() => handleUpdateBookingStatus(bk.id, 'CONFIRMADA')}
                            className="px-3 py-1.5 rounded-xl bg-cyan-600 text-white font-bold"
                          >
                            Confirmar Reserva
                          </button>
                        )}
                        {(bk.status === 'CONFIRMADA' || bk.status === 'EM_DISPUTA') && (
                          <button
                            onClick={() => handleUpdateBookingStatus(bk.id, 'PASSEIO_REALIZADO')}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold"
                          >
                            Consolidar Realização
                          </button>
                        )}
                        {(() => {
                          const payRec = financialStore.payments.find((p) => p.bookingId === bk.id);
                          const pStatus: PaymentStatusType | 'SEM_PAGAMENTO' = payRec ? payRec.paymentStatus : 'SEM_PAGAMENTO';
                          return (
                            <>
                              <span className="px-2.5 py-1 rounded-full bg-cyan-50 border border-cyan-200 text-cyan-900 font-bold">
                                Pgto: {pStatus}
                              </span>
                              {!payRec && bk.status !== 'CANCELADA' && bk.status !== 'RECUSADA' && (
                                <button
                                  type="button"
                                  onClick={() => handleInitiateBookingPayment(bk.id, 'PIX')}
                                  className="px-2.5 py-1.5 rounded-xl bg-indigo-600 text-white font-bold"
                                >
                                  Iniciar Pgto
                                </button>
                              )}
                              {payRec && (payRec.paymentStatus === 'PENDENTE' || payRec.paymentStatus === 'PROCESSANDO') && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleTransitionBookingPayment(
                                      bk.id,
                                      'PAGO',
                                      'Conciliação bancária administrativa verificada pelo Admin'
                                    )
                                  }
                                  className="px-2.5 py-1.5 rounded-xl bg-emerald-700 text-white font-bold"
                                >
                                  Confirmar PAGO
                                </button>
                              )}
                              {payRec && (payRec.paymentStatus === 'PAGO' || payRec.paymentStatus === 'ESTORNO_PARCIAL') && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleRequestBookingRefund(
                                      bk.id,
                                      'Solicitação de estorno registrada pela administração'
                                    )
                                  }
                                  className="px-2.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold"
                                >
                                  Solicitar Estorno
                                </button>
                              )}
                              {payRec && payRec.paymentStatus === 'ESTORNO_PENDENTE' && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleConfirmBookingRefund(
                                        bk.id,
                                        'Estorno confirmado e liquidado pela administração Rota Azul'
                                      )
                                    }
                                    className="px-2.5 py-1.5 rounded-xl bg-rose-700 text-white font-bold"
                                  >
                                    Confirmar Estorno
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleRevertFailedBookingRefund(
                                        bk.id,
                                        'Falha de processamento no adquirente; pagamento mantido'
                                      )
                                    }
                                    className="px-2.5 py-1.5 rounded-xl bg-slate-700 text-white font-bold"
                                  >
                                    Reverter Falha Estorno
                                  </button>
                                </>
                              )}
                              {bk.status === 'PASSEIO_REALIZADO' &&
                                bk.ledgerStatus !== 'PAGA' &&
                                payRec &&
                                (payRec.paymentStatus === 'PAGO' || payRec.paymentStatus === 'ESTORNO_PARCIAL') && (
                                  <button
                                    type="button"
                                    onClick={() => handleSettleBookingCommission(bk.id)}
                                    className="px-2.5 py-1.5 rounded-xl bg-teal-700 text-white font-bold"
                                  >
                                    Liquidar Repasse (PAGA)
                                  </button>
                                )}
                            </>
                          );
                        })()}
                        {bk.status !== 'PASSEIO_REALIZADO' && bk.status !== 'CANCELADA' && bk.status !== 'RECUSADA' && (
                          <button
                            onClick={() => handleUpdateBookingStatus(bk.id, 'CANCELADA', 'Cancelado pelo Admin')}
                            className="px-3 py-1.5 rounded-xl bg-rose-100 text-rose-800 font-bold"
                          >
                            Cancelar
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* 3.6. GESTÃO DE SAÍDAS E OCUPAÇÃO */}
          {adminModuleTab === 'departures' && (() => {
            const adminCtx: OperationalAuthContext = { ...currentAuthContext, actorRole: 'admin' };
            const adminDepsRes = listOperationalDepartures(operationalState, adminCtx, {
              date: departureDateSelect || undefined,
              partnerId: departurePartnerSelect,
              status: departureStatusSelect,
              search: departureSearchQuery,
            });
            const adminDeps = adminDepsRes.data || [];

            return (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Visão Operacional das Saídas e Ocupação ({adminDeps.length})
                    </h2>
                    <p className="text-xs text-slate-500">
                      Sincronizado com o motor canônico de disponibilidade (`get_tour_availability`). Saídas passadas são encerradas automaticamente.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={departureSearchQuery}
                      onChange={(e) => setDepartureSearchQuery(e.target.value)}
                      placeholder="Buscar passeio, barco ou parceiro..."
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <input
                      type="date"
                      value={departureDateSelect}
                      onChange={(e) => setDepartureDateSelect(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    />
                    <select
                      value={departurePartnerSelect}
                      onChange={(e) => setDeparturePartnerSelect(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todos os Parceiros</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                    <select
                      value={departureStatusSelect}
                      onChange={(e) => setDepartureStatusSelect(e.target.value as any)}
                      className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="TODOS">Todas as Situações</option>
                      <option value="DISPONIVEL">DISPONÍVEL</option>
                      <option value="PARCIALMENTE_OCUPADA">PARCIALMENTE OCUPADA</option>
                      <option value="LOTADA">LOTADA</option>
                      <option value="BLOQUEADA_AGENDA">BLOQUEADA NA AGENDA</option>
                      <option value="ENCERRADA_PASSADA">ENCERRADA (PASSADA)</option>
                      <option value="INATIVA">INATIVA</option>
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 uppercase">
                        <th className="py-2.5 px-3">Data / Horário</th>
                        <th className="py-2.5 px-3">Passeio</th>
                        <th className="py-2.5 px-3">Embarcação</th>
                        <th className="py-2.5 px-3">Parceiro Responsável</th>
                        <th className="py-2.5 px-3">Capacidade</th>
                        <th className="py-2.5 px-3">Reservado</th>
                        <th className="py-2.5 px-3">Vagas Restantes</th>
                        <th className="py-2.5 px-3">Situação da Saída</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {adminDeps.map((dep) => (
                        <tr key={dep.departureId} className="hover:bg-slate-50">
                          <td className="py-3 px-3 font-mono font-bold text-slate-900">
                            {dep.date}
                            <div className="text-[11px] font-sans text-slate-500">
                              {dep.departureTime}–{dep.returnTime} (Check-in {dep.checkInTime})
                            </div>
                          </td>
                          <td className="py-3 px-3 font-bold text-slate-900">
                            {dep.tourTitle}
                            <div className="text-[11px] font-normal text-slate-500">{dep.departurePoint}</div>
                          </td>
                          <td className="py-3 px-3 text-slate-700">{dep.vesselName}</td>
                          <td className="py-3 px-3 text-slate-700 font-semibold">{dep.partnerName}</td>
                          <td className="py-3 px-3 font-bold text-slate-900">{dep.effectiveCapacity} pax</td>
                          <td className="py-3 px-3 font-bold text-cyan-800">{dep.reservedPassengers} pax ({dep.occupancyPercent}%)</td>
                          <td className="py-3 px-3 font-extrabold text-emerald-700">{dep.remainingSeats} vagas</td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold ${
                                dep.departureStatus === 'DISPONIVEL'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : dep.departureStatus === 'PARCIALMENTE_OCUPADA'
                                  ? 'bg-cyan-100 text-cyan-900'
                                  : dep.departureStatus === 'LOTADA'
                                  ? 'bg-amber-100 text-amber-900'
                                  : 'bg-slate-200 text-slate-700'
                              }`}
                            >
                              {dep.departureStatus}
                            </span>
                            {dep.blockReason && (
                              <div className="text-[10px] text-rose-600 mt-0.5">{dep.blockReason}</div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}

          {/* 3.7. PAGAMENTOS, COMISSÕES, ESTORNOS EM 2 ETAPAS E CONCILIAÇÃO FINANCEIRA (MISSÃO 02.22 — F01 A F07) */}
          {adminModuleTab === 'financial' && adminFinancialSummary && financialReconciliationReport && (
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900">
                      Conciliação Financeira das 5 Entidades & Controle de Estornos (Missão 02.22)
                    </h2>
                    <p className="text-xs text-slate-500">
                      Auditoria cruzada entre <code className="bg-slate-100 px-1 rounded">bookings</code>, <code className="bg-slate-100 px-1 rounded">commission_ledger</code>, <code className="bg-slate-100 px-1 rounded">booking_payments</code>, <code className="bg-slate-100 px-1 rounded">booking_payment_history</code> e <code className="bg-slate-100 px-1 rounded">financial_ledger_entries</code> • Sessão Verificada: <strong>{verifiedOperationalContext.actorRole}</strong>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                        financialReconciliationReport.divergentCount === 0
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {financialReconciliationReport.divergentCount === 0
                        ? `100% Conciliado (${financialReconciliationReport.reconciledCount}/${financialReconciliationReport.totalBookingsAudited})`
                        : `${financialReconciliationReport.divergentCount} Divergência(s) Detectada(s)`}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <span className="text-slate-500 font-bold">GMV Bruto Esperado</span>
                    <p className="text-lg font-extrabold text-slate-900 mt-1">
                      R$ {financialReconciliationReport.summaryMetrics.totalGrossExpected.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                    <span className="text-emerald-800 font-bold">Total Pago Retido</span>
                    <p className="text-lg font-extrabold text-emerald-700 mt-1">
                      R$ {financialReconciliationReport.summaryMetrics.totalPaidConfirmed.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200">
                    <span className="text-indigo-900 font-bold">Comissão Consolidada</span>
                    <p className="text-lg font-extrabold text-indigo-800 mt-1">
                      R$ {financialReconciliationReport.summaryMetrics.totalCommissionConsolidated.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="p-4 rounded-2xl bg-cyan-50 border border-cyan-200">
                    <span className="text-cyan-900 font-bold">Repasse Líquido Consolidado</span>
                    <p className="text-lg font-extrabold text-cyan-800 mt-1">
                      R$ {financialReconciliationReport.summaryMetrics.totalNetPartnerConsolidated.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 col-span-2 sm:col-span-1">
                    <span className="text-rose-800 font-bold">Total Estornado</span>
                    <p className="text-lg font-extrabold text-rose-700 mt-1">
                      R$ {financialReconciliationReport.summaryMetrics.totalRefunded.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>

                {/* Tabela de Conciliação por Reserva */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-extrabold uppercase text-slate-500">
                    Itens Auditados na Conciliação ({financialReconciliationReport.items.length})
                  </h3>
                  {financialReconciliationReport.items.map((item) => (
                    <div
                      key={item.bookingId}
                      className={`p-4 rounded-2xl border text-xs flex flex-wrap items-center justify-between gap-3 ${
                        item.isReconciled
                          ? 'bg-slate-50 border-slate-200'
                          : 'bg-rose-50/70 border-rose-300'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-[#0A2540] text-cyan-300 font-mono font-bold">
                            {item.bookingCode}
                          </span>
                          <span className="font-extrabold text-slate-900">{item.tourTitle}</span>
                          <span className="text-slate-500">({item.partnerName})</span>
                          <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-800 font-bold">
                            Reserva: {item.bookingStatus}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-cyan-100 text-cyan-900 font-bold">
                            Pgto: {item.paymentStatus}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 font-bold">
                            Ledger: {item.ledgerStatus}
                          </span>
                        </div>
                        <p className="text-slate-600">
                          Bruto: R$ {item.recordedGrossAmount.toFixed(2)} (Pago: R$ {item.paidGrossAmount.toFixed(2)} | Estornado: R$ {item.refundedGrossAmount.toFixed(2)}) • Comissão Efetiva: <strong>R$ {item.effectiveCommissionAmount.toFixed(2)}</strong> • Líquido Parceiro: <strong>R$ {item.effectiveNetPartnerAmount.toFixed(2)}</strong>
                        </p>
                        {item.divergences.length > 0 && (
                          <div className="space-y-0.5 pt-1">
                            {item.divergences.map((div, dIdx) => (
                              <div key={dIdx} className="text-rose-800 font-bold">
                                • [{div.code}] {div.description}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      <span
                        className={`px-2.5 py-1 rounded-full font-extrabold ${
                          item.isReconciled
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-200 text-rose-900'
                        }`}
                      >
                        {item.isReconciled ? 'CONCILIADO' : 'DIVERGENTE'}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Breakdown por Parceiro */}
                <div className="pt-4 border-t border-slate-100 space-y-2">
                  <h3 className="text-xs font-extrabold uppercase text-slate-500">
                    Resumo Financeiro por Parceiro ({adminFinancialSummary.byPartnerBreakdown.length})
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {adminFinancialSummary.byPartnerBreakdown.map((pb) => (
                      <div key={pb.partnerId} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                        <div className="font-extrabold text-slate-900">{pb.partnerName}</div>
                        <div className="text-slate-600">
                          Reservas: <strong>{pb.bookingsCount}</strong> • Pago: <strong>R$ {pb.paidConfirmed.toFixed(2)}</strong>
                        </div>
                        <div className="text-slate-600">
                          Comissão Cons.: <strong>R$ {pb.commissionConsolidated.toFixed(2)}</strong> • Líquido Cons.: <strong>R$ {pb.netPartnerConsolidated.toFixed(2)}</strong>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Logs de Auditoria */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <h2 className="text-lg font-extrabold text-slate-900 mb-3">
              Logs de Auditoria do Sistema ({auditLogs.length})
            </h2>
            <div className="max-h-52 overflow-y-auto space-y-2">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex justify-between">
                  <span>
                    <strong className="text-cyan-800">[{log.action}]</strong> {log.target} — {log.details}
                  </span>
                  <span className="text-slate-400 font-mono">{log.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        </main>
      )}

      {/* ========================================================================
          PÁGINA 9: ARQUITETURA SUPABASE (SQL + RLS + EDGE FUNCTIONS) & SEO/MARKETING
         ======================================================================== */}
      {activeTab === 'architecture-seo' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
          <div className="bg-[#0A2540] text-white rounded-3xl p-6 sm:p-8">
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
              Especificação de Produção • Supabase PostgreSQL + SEO + Rastreamento de Conversão
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
              Arquitetura Backend, Segurança RLS, Idempotência Financeira e SEO
            </h1>
            <p className="text-sm text-slate-300 mt-1">
              Estrutura pronta para implantação com Row Level Security (isolamento entre parceiros), dados estruturados Schema.org e rastreamento Meta Pixel / GA4 / UTMs.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Schema SQL Supabase + Políticas RLS */}
            <div className="bg-slate-900 text-slate-100 rounded-3xl p-6 border border-slate-800 overflow-x-auto">
              <h2 className="text-base font-extrabold text-cyan-400 mb-2">
                1. Schema PostgreSQL + Políticas RLS (Supabase)
              </h2>
              <pre className="text-[11px] font-mono text-slate-300 leading-relaxed whitespace-pre-wrap">
{`-- Isolamento Multi-Tenant de Parceiros (Row Level Security)
ALTER TABLE partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_ledger ENABLE ROW LEVEL SECURITY;

-- Parceiro acessa e altera SOMENTE seus próprios registros
CREATE POLICY "partner_isolated_vessels" ON vessels
  FOR ALL USING (partner_id = auth.uid());

CREATE POLICY "partner_isolated_bookings" ON bookings
  FOR SELECT USING (partner_id = auth.uid());

-- Idempotência Financeira: Comissão só consolida após PASSEIO_REALIZADO
CREATE UNIQUE INDEX idx_idempotent_commission_per_booking
  ON commission_ledger (booking_id)
  WHERE ledger_status = 'CONFIRMADA';`}
              </pre>
            </div>

            {/* SEO & Marketing Acquisition */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
              <h2 className="text-base font-extrabold text-slate-900">
                2. SEO Dinâmico, JSON-LD & Aquisição (Google Analytics 4 + Meta Pixel)
              </h2>
              <div className="space-y-2 text-xs text-slate-700">
                <p>
                  • <strong>Palavras-Chave Prioritárias Indexadas:</strong> Passeios de lancha em Ubatuba, Passeios de escuna em Ubatuba, Passeios de barco em Ubatuba, O que fazer em Ubatuba, Praias de Ubatuba, Ilhas de Ubatuba, Cachoeiras de Ubatuba.
                </p>
                <p>
                  • <strong>Eventos de Conversão Rastreados:</strong> <code className="bg-slate-100 px-1.5 py-0.5 rounded">Lead_WhatsApp_Partner</code> e <code className="bg-slate-100 px-1.5 py-0.5 rounded">Booking_Request_Submitted</code> com parâmetros <code className="bg-slate-100 px-1.5 py-0.5 rounded">utm_source</code>, <code className="bg-slate-100 px-1.5 py-0.5 rounded">partner_id</code>, <code className="bg-slate-100 px-1.5 py-0.5 rounded">booking_code</code> e <code className="bg-slate-100 px-1.5 py-0.5 rounded">value</code>.
                </p>
              </div>
              <pre className="p-4 rounded-2xl bg-slate-900 text-emerald-300 text-[11px] font-mono overflow-x-auto">
{`{
  "@context": "https://schema.org",
  "@type": "TouristTrip",
  "name": "Passeios de Lancha e Escuna em Ubatuba - Ilha das Couves e Ilha Anchieta",
  "touristType": ["Turismo Náutico", "Famílias", "Ecoturismo"],
  "offers": {
    "@type": "AggregateOffer",
    "priceCurrency": "BRL",
    "lowPrice": "110.00",
    "highPrice": "2100.00"
  }
}`}
              </pre>
            </div>
          </div>
        </main>
      )}

      {/* ========================================================================
          MODAL DE RESERVA HÍBRIDA (OPÇÃO 1 WHATSAPP RASTREADO | OPÇÃO 2 SITE)
         ======================================================================== */}
      {bookingModalTour && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8">
            <button
              onClick={() => setBookingModalTour(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
              Sistema Híbrido de Reservas • Sem Confirmação Automática Indevida
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 pr-8">
              {bookingModalTour.title}
            </h2>

            {/* Seletor das 2 Opções Exigidas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-5">
              <button
                type="button"
                onClick={() => setBookingChannel('WHATSAPP')}
                className={`p-3.5 rounded-2xl border text-left transition ${
                  bookingChannel === 'WHATSAPP'
                    ? 'border-emerald-600 bg-emerald-50/70 text-slate-900'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="font-extrabold text-xs flex items-center gap-1.5 text-emerald-800">
                  <MessageCircle className="w-4 h-4" /> OPÇÃO 1 — Via WhatsApp do Parceiro
                </div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Registra a solicitação, gera código único, identifica o parceiro e abre o WhatsApp preenchido.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setBookingChannel('SITE_DIRECT')}
                className={`p-3.5 rounded-2xl border text-left transition ${
                  bookingChannel === 'SITE_DIRECT'
                    ? 'border-cyan-600 bg-cyan-50/70 text-slate-900'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="font-extrabold text-xs flex items-center gap-1.5 text-cyan-900">
                  <Calendar className="w-4 h-4" /> OPÇÃO 2 — Solicitação pelo Site
                </div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Envia pedido de disponibilidade ao painel do parceiro e aguarda confirmação oficial.
                </p>
              </button>
            </div>

            {!lastCreatedBooking ? (
              <form onSubmit={handleCreateBookingRequest} className="mt-5 space-y-4">
                {(() => {
                  const modalAvail =
                    isSupabaseConfigured && liveModalAvailability && liveModalAvailability.booking_date === bookingDate
                      ? {
                          blocked: liveModalAvailability.blocked,
                          remainingSeats: liveModalAvailability.remaining_seats,
                          blockReason: liveModalAvailability.block_reason,
                          departureTime: liveModalAvailability.departure_time || bookingModalTour.departureTime,
                          returnTime: liveModalAvailability.return_time || bookingModalTour.returnTime,
                          checkInTime: liveModalAvailability.check_in_time || bookingModalTour.checkInTime,
                          departurePoint: liveModalAvailability.departure_point || bookingModalTour.departurePoint,
                        }
                      : {
                          ...getTourAvailabilityForDate(bookingModalTour, bookingDate),
                          departureTime: bookingModalTour.departureTime,
                          returnTime: bookingModalTour.returnTime,
                          checkInTime: bookingModalTour.checkInTime,
                          departurePoint: bookingModalTour.departurePoint,
                        };
                  return (
                    <div
                      className={`p-3.5 rounded-2xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
                        modalAvail.blocked
                          ? 'bg-rose-50 border-rose-200 text-rose-900'
                          : 'bg-cyan-50/70 border-cyan-200 text-slate-800'
                      }`}
                    >
                      <div>
                        <span className="font-extrabold">
                          Embarque: {modalAvail.departurePoint} • Check-in {modalAvail.checkInTime} • Saída{' '}
                          {modalAvail.departureTime} (Retorno {modalAvail.returnTime})
                        </span>
                        <p className="text-[11px] mt-0.5">
                          {loadingModalAvailability
                            ? 'Consultando disponibilidade real no servidor...'
                            : modalAvail.blocked
                            ? `Indisponível nesta data: ${modalAvail.blockReason}`
                            : `Disponibilidade para ${bookingDate}: ${modalAvail.remainingSeats} vaga(s) restante(s)`}
                        </p>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 font-mono text-[11px] font-bold">
                        Hoje (Brasília): {currentBrazilDate}
                      </span>
                    </div>
                  );
                })()}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Data do Passeio</label>
                    <input
                      type="date"
                      min={currentBrazilDate}
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Passageiros (Máx {bookingModalTour.capacity})
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={bookingModalTour.capacity}
                      value={bookingPassengers}
                      onChange={(e) => setBookingPassengers(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Origem do Visitante (UTM)</label>
                    <select
                      value={bookingUtmSource}
                      onChange={(e) => setBookingUtmSource(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold"
                    >
                      <option value="instagram_ads">Instagram Ads</option>
                      <option value="facebook_ads">Facebook Ads</option>
                      <option value="google_search">Google Search (SEO/Ads)</option>
                      <option value="direct_organic">Acesso Direto</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    value={bookingName}
                    onChange={(e) => setBookingName(e.target.value)}
                    placeholder="Seu nome completo"
                    className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="tel"
                    value={bookingPhone}
                    onChange={(e) => setBookingPhone(e.target.value)}
                    placeholder="WhatsApp (DDD + Número)"
                    className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="email"
                    value={bookingEmail}
                    onChange={(e) => setBookingEmail(e.target.value)}
                    placeholder="Seu e-mail"
                    className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                  <div className="text-xs text-slate-600">
                    <p className="font-bold text-slate-900">
                      Valor Total Estimado:{' '}
                      R${' '}
                      {(bookingModalTour.pricingModel === 'POR_PESSOA'
                        ? bookingModalTour.price * bookingPassengers
                        : bookingModalTour.price
                      ).toLocaleString('pt-BR')}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Importante: Solicitações dependem da confirmação de disponibilidade pelo parceiro responsável.
                    </p>
                  </div>
                  <button
                    type="submit"
                    disabled={isSubmittingBooking}
                    className="px-5 py-3 rounded-xl bg-[#0A2540] hover:bg-cyan-600 disabled:opacity-50 text-white text-xs font-extrabold transition"
                  >
                    {isSubmittingBooking
                      ? 'Processando Reserva...'
                      : bookingChannel === 'WHATSAPP'
                      ? 'Gerar Código & Abrir WhatsApp'
                      : 'Enviar Solicitação pelo Site'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="mt-5 p-5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-extrabold uppercase text-emerald-800">
                    Solicitação Rastreável Registrada com Sucesso!
                  </span>
                  <span className="px-3 py-1 rounded-lg bg-[#0A2540] text-cyan-300 font-mono text-xs font-bold">
                    Código: {lastCreatedBooking.code}
                  </span>
                </div>
                <p className="text-xs text-slate-700">
                  Parceiro Identificado: <strong>{lastCreatedBooking.partnerName}</strong> • Status Inicial:{' '}
                  <strong>{lastCreatedBooking.status}</strong> (Aguardando confirmação do operador).
                </p>

                {lastCreatedBooking.lookupToken && (
                  <div className="p-3.5 rounded-xl bg-white border border-emerald-300 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-extrabold uppercase text-slate-700 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5 text-emerald-700" /> Chave de Consulta Segura do Turista
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (navigator.clipboard && lastCreatedBooking.lookupToken) {
                            navigator.clipboard.writeText(
                              `Código: ${lastCreatedBooking.code} | Chave: ${lastCreatedBooking.lookupToken}`
                            );
                            showToast('Credenciais Copiadas!', 'Código e chave de consulta copiados para a área de transferência.', 'info');
                          }
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-[11px] font-bold text-slate-700 inline-flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" /> Copiar Credenciais
                      </button>
                    </div>
                    <p className="font-mono text-xs font-bold text-[#0A2540] break-all">
                      {lastCreatedBooking.lookupToken}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Esta credencial foi salva neste navegador para que você acompanhe ou cancele sua reserva mesmo após atualizar a página (F5).
                    </p>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {lastCreatedBooking.channel === 'WHATSAPP' && (() => {
                    const bookedPartner = partners.find((p) => p.id === lastCreatedBooking.partnerId) || partners[0];
                    const dynamicPhone = (bookedPartner?.whatsapp || '').replace(/\D/g, '');
                    return (
                      <a
                        href={`https://wa.me/${dynamicPhone}?text=${encodeURIComponent(
                          `Olá ${lastCreatedBooking.partnerName}! Solicitação #${lastCreatedBooking.code} via Ubatuba Mar & Praias.\nPasseio: ${lastCreatedBooking.tourTitle}\nData: ${lastCreatedBooking.date}\nPassageiros: ${lastCreatedBooking.passengers}\nValor Estimado: R$ ${lastCreatedBooking.grossAmount}`
                        )}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold"
                      >
                        <MessageCircle className="w-4 h-4" /> Abrir WhatsApp de {lastCreatedBooking.partnerName} ({dynamicPhone})
                      </a>
                    );
                  })()}
                  <button
                    type="button"
                    onClick={() => {
                      setLookupCodeInput(lastCreatedBooking.code);
                      setLookupTokenInput(lastCreatedBooking.lookupToken || '');
                      setBookingModalTour(null);
                      setTouristTrackerOpen(true);
                    }}
                    className="px-4 py-3 rounded-xl bg-[#0A2540] hover:bg-slate-800 text-cyan-300 text-xs font-extrabold inline-flex items-center gap-1.5"
                  >
                    <CheckSquare className="w-4 h-4" /> Acompanhar Minha Reserva
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================
          LIGHTBOX EM TELA AMPLIADA E PLAYER DE VÍDEO INTEGRADO
         ======================================================================== */}
      {lightboxMedia && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-4xl w-full bg-slate-900 rounded-3xl overflow-hidden border border-white/15 shadow-2xl">
            <div className="p-4 flex items-center justify-between border-b border-white/10 text-white">
              <div>
                <span className="text-[11px] font-bold uppercase text-cyan-400">
                  {lightboxMedia.type === 'video' ? 'Player de Vídeo Integrado' : 'Visualização em Tela Ampliada'}
                </span>
                <h3 className="font-bold text-base">{lightboxMedia.title}</h3>
                {lightboxMedia.subtitle && <p className="text-xs text-slate-400">{lightboxMedia.subtitle}</p>}
              </div>
              <button
                onClick={() => setLightboxMedia(null)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="relative bg-black">
              <img
                src={lightboxMedia.url}
                alt={lightboxMedia.title}
                className="w-full max-h-[70vh] object-contain mx-auto"
              />
              {lightboxMedia.type === 'video' && (
                <div className="absolute bottom-4 left-4 right-4 bg-slate-950/85 backdrop-blur-md p-3 rounded-2xl border border-white/15 text-white flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-cyan-400 text-slate-950 flex items-center justify-center shrink-0">
                    <Play className="w-4 h-4 fill-slate-950" />
                  </div>
                  <div className="flex-1">
                    <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
                      <div className="h-full w-2/3 bg-cyan-400 rounded-full" />
                    </div>
                  </div>
                  <span className="text-xs font-mono text-cyan-300">HD 1080p • Player Ativo</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE AUTENTICAÇÃO, SESSÃO E ONBOARDING DE PARCEIROS (MISSÃO 02.19) */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5 my-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#0A2540] text-cyan-300 text-[11px] font-bold">
                  <Shield className="w-3.5 h-3.5" /> Rota Azul • Autenticação, Sessões & Onboarding (Missão 02.19)
                </span>
                <h2 className="text-xl font-extrabold text-slate-900 mt-1">
                  Controle de Acesso e Credenciamento de Parceiros
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Estado atual da sessão: <strong>{verifiedSession.accountState}</strong>
                  {verifiedSession.email ? ` (${verifiedSession.email} • perfil: ${verifiedSession.serverRole})` : ' (Visitante não autenticado)'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAuthModalOpen(false)}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap gap-2 bg-slate-100 p-1.5 rounded-2xl text-xs font-extrabold">
              {[
                { id: 'login', label: 'Entrar / Sessão' },
                { id: 'register', label: 'Criar Conta' },
                { id: 'recovery', label: 'Recuperar Senha' },
                { id: 'reset-password', label: 'Redefinir Senha' },
                { id: 'onboarding', label: 'Onboarding de Parceiro' },
              ].map((tb) => (
                <button
                  key={tb.id}
                  type="button"
                  onClick={() => {
                    setAuthViewMode(tb.id as any);
                    setAuthFeedback(null);
                  }}
                  className={`px-3 py-1.5 rounded-xl transition ${
                    authViewMode === tb.id
                      ? 'bg-[#0A2540] text-cyan-300 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tb.label}
                </button>
              ))}
            </div>

            {authFeedback && (
              <div
                className={`p-3.5 rounded-2xl text-xs font-bold border ${
                  authFeedback.type === 'error'
                    ? 'bg-rose-50 border-rose-200 text-rose-800'
                    : authFeedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-cyan-50 border-cyan-200 text-cyan-900'
                }`}
              >
                {authFeedback.message}
              </div>
            )}

            {authViewMode === 'login' && (
              <form onSubmit={handleAuthLoginSubmit} className="space-y-3">
                <input
                  type="email"
                  value={loginEmailInput}
                  onChange={(e) => setLoginEmailInput(e.target.value)}
                  placeholder="Seu e-mail de acesso..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <input
                  type="password"
                  value={loginPasswordInput}
                  onChange={(e) => setLoginPasswordInput(e.target.value)}
                  placeholder="Sua senha..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="px-5 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                  >
                    {authLoading ? 'Verificando credenciais...' : 'Entrar na Conta'}
                  </button>
                  {verifiedSession.isAuthenticated && (
                    <button
                      type="button"
                      onClick={handleAuthLogout}
                      className="px-4 py-2.5 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-extrabold"
                    >
                      Encerrar Sessão (Logout)
                    </button>
                  )}
                </div>
              </form>
            )}

            {authViewMode === 'register' && (
              <form onSubmit={handleAuthRegisterSubmit} className="space-y-3">
                <input
                  type="text"
                  value={regFullNameInput}
                  onChange={(e) => setRegFullNameInput(e.target.value)}
                  placeholder="Nome completo..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <input
                  type="email"
                  value={regEmailInput}
                  onChange={(e) => setRegEmailInput(e.target.value)}
                  placeholder="E-mail válido..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="password"
                    value={regPasswordInput}
                    onChange={(e) => setRegPasswordInput(e.target.value)}
                    placeholder="Senha (mín. 8 caracteres, letra e número)..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="password"
                    value={regConfirmPasswordInput}
                    onChange={(e) => setRegConfirmPasswordInput(e.target.value)}
                    placeholder="Confirmar senha..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-700 font-semibold">
                  <input
                    type="checkbox"
                    checked={regAcceptedTerms}
                    onChange={(e) => setRegAcceptedTerms(e.target.checked)}
                  />
                  Aceito os Termos de Uso e a Política de Privacidade (LGPD) do Rota Azul.
                </label>
                <button
                  type="submit"
                  disabled={authLoading}
                  className="px-5 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                >
                  Criar Conta Segura
                </button>
              </form>
            )}

            {authViewMode === 'recovery' && (
              <form onSubmit={handleAuthRecoverySubmit} className="space-y-3">
                <p className="text-xs text-slate-600">
                  Informe o e-mail da sua conta para receber o link de uso único de recuperação de senha via provedor de autenticação.
                </p>
                <input
                  type="email"
                  value={recoveryEmailInput}
                  onChange={(e) => setRecoveryEmailInput(e.target.value)}
                  placeholder="E-mail cadastrado..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                >
                  Solicitar Recuperação de Senha
                </button>
              </form>
            )}

            {authViewMode === 'reset-password' && (
              <form onSubmit={handleAuthResetPasswordSubmit} className="space-y-3">
                <input
                  type="text"
                  value={resetTokenInput}
                  onChange={(e) => setResetTokenInput(e.target.value)}
                  placeholder="Token de recuperação recebido..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  required
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="password"
                    value={resetNewPasswordInput}
                    onChange={(e) => setResetNewPasswordInput(e.target.value)}
                    placeholder="Nova senha (mín. 8 caracteres)..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="password"
                    value={resetConfirmPasswordInput}
                    onChange={(e) => setResetConfirmPasswordInput(e.target.value)}
                    placeholder="Confirmar nova senha..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold"
                >
                  Confirmar Nova Senha
                </button>
              </form>
            )}

            {authViewMode === 'onboarding' && (
              <div className="space-y-4">
                {verifiedSession.partnerOnboardingStage && (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                    <div>
                      <strong>Estágio Atual do Onboarding:</strong>{' '}
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold">
                        {verifiedSession.partnerOnboardingStage}
                      </span>
                    </div>
                    {verifiedSession.partnerRejectionReason && (
                      <div className="text-rose-700">
                        <strong>Parecer Administrativo:</strong> {verifiedSession.partnerRejectionReason}
                      </div>
                    )}
                  </div>
                )}

                <form onSubmit={handlePartnerOnboardingSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={onbCompanyName}
                    onChange={(e) => setOnbCompanyName(e.target.value)}
                    placeholder="Nome Fantasia da Operadora..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="text"
                    value={onbLegalName}
                    onChange={(e) => setOnbLegalName(e.target.value)}
                    placeholder="Razão Social LTDA..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="text"
                    value={onbCnpj}
                    onChange={(e) => setOnbCnpj(e.target.value)}
                    placeholder="CNPJ (14 dígitos)..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="text"
                    value={onbWhatsapp}
                    onChange={(e) => setOnbWhatsapp(e.target.value)}
                    placeholder="WhatsApp Operacional (551299...)"
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="email"
                    value={onbBusinessEmail}
                    onChange={(e) => setOnbBusinessEmail(e.target.value)}
                    placeholder="E-mail Corporativo..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="text"
                    value={onbBaseMarina}
                    onChange={(e) => setOnbBaseMarina(e.target.value)}
                    placeholder="Marina Base (ex: Saco da Ribeira)..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                    required
                  />
                  <input
                    type="number"
                    min={1}
                    value={onbYearsOperating}
                    onChange={(e) => setOnbYearsOperating(Number(e.target.value))}
                    placeholder="Anos de operação"
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  />
                  <input
                    type="text"
                    value={onbBio}
                    onChange={(e) => setOnbBio(e.target.value)}
                    placeholder="Resumo da operação e certificações..."
                    className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-2 py-2.5 rounded-xl bg-[#0A2540] hover:bg-cyan-600 text-white text-xs font-extrabold"
                  >
                    Enviar Solicitação de Credenciamento de Parceiro (PENDENTE)
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL DE CONSULTA SEGURA E ACOMPANHAMENTO DE RESERVAS PELO TURISTA (MISSÃO 02.16 — SEÇÕES 7 E 8) */}
      {touristTrackerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8 space-y-5">
            <button
              onClick={() => setTouristTrackerOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-cyan-700 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" /> Consulta Segura Protegida por Credencial Criptográfica (Zero Exposição de PII)
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
                Consultar ou Cancelar Minha Reserva
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                Informe o código da reserva (<strong>UBT-XXXX</strong>) e a sua Chave de Consulta Segura (<strong>ubtk-...</strong>) emitida no momento da solicitação.
              </p>
            </div>

            <form
              onSubmit={handleTouristLookupSubmit}
              className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                <div className="sm:col-span-4">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Código da Reserva
                  </label>
                  <input
                    type="text"
                    value={lookupCodeInput}
                    onChange={(e) => setLookupCodeInput(e.target.value)}
                    placeholder="Ex: UBT-8492"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-bold uppercase"
                    required
                  />
                </div>
                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Chave de Consulta Segura (ubtk-...)
                  </label>
                  <input
                    type="text"
                    value={lookupTokenInput}
                    onChange={(e) => setLookupTokenInput(e.target.value)}
                    placeholder="ubtk-..."
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-semibold"
                    required
                  />
                </div>
                <div className="sm:col-span-3 flex items-end">
                  <button
                    type="submit"
                    disabled={lookupLoading}
                    className="w-full py-2 px-3 rounded-xl bg-[#0A2540] hover:bg-cyan-600 disabled:opacity-50 text-white text-xs font-extrabold transition"
                  >
                    {lookupLoading ? 'Verificando...' : 'Consultar Reserva'}
                  </button>
                </div>
              </div>
              {lookupError && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{lookupError}</span>
                </div>
              )}
            </form>

            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 bg-slate-100 px-3.5 py-2 rounded-xl border border-slate-200 flex-1">
                <Search className="w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={trackerSearchCode}
                  onChange={(e) => setTrackerSearchCode(e.target.value)}
                  placeholder="Filtrar reservas autenticadas neste navegador por código ou passeio..."
                  className="w-full bg-transparent text-xs font-semibold text-slate-800 focus:outline-none"
                />
              </div>
            </div>

            <div className="max-h-[48vh] overflow-y-auto space-y-3">
              {(() => {
                const authenticatedList = Object.values(verifiedTouristBookings).filter(
                  (item) => item && item.ok && item.booking_code
                );
                const filteredList = authenticatedList.filter((item) => {
                  if (!trackerSearchCode.trim()) return true;
                  const q = trackerSearchCode.toLowerCase();
                  return (
                    (item.booking_code || '').toLowerCase().includes(q) ||
                    (item.tour_title || '').toLowerCase().includes(q)
                  );
                });

                if (filteredList.length === 0) {
                  return (
                    <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-1.5">
                      <p className="text-xs font-bold text-slate-700">
                        Nenhuma reserva autenticada exibida no momento.
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Utilize o formulário acima com o seu Código (UBT-XXXX) e Chave de Consulta (ubtk-...) para visualizar ou cancelar sua solicitação com proteção de dados.
                      </p>
                    </div>
                  );
                }

                return filteredList.map((item) => {
                  const bCode = String(item.booking_code || '');
                  const cleanPhone = String(item.partner_whatsapp || '').replace(/\D/g, '');
                  const savedReceipt = savedTouristReceipts.find((r) => r.bookingCode === bCode);
                  const canCancel =
                    item.status === 'SOLICITADA' ||
                    item.status === 'AGUARDANDO_CONFIRMACAO' ||
                    item.status === 'CONFIRMADA';
                  return (
                    <div key={bCode} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded bg-[#0A2540] text-cyan-300 font-mono font-bold">
                            {bCode}
                          </span>
                          {savedReceipt && (
                            <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-mono text-[10px]">
                              Chave: {savedReceipt.lookupToken.slice(0, 13)}...
                            </span>
                          )}
                        </div>
                        <span className="px-3 py-1 rounded-full bg-cyan-100 text-cyan-900 font-extrabold">
                          {item.status}
                        </span>
                      </div>
                      <p className="font-bold text-sm text-slate-900">{item.tour_title}</p>
                      <p className="text-slate-600">
                        Parceiro: <strong>{item.partner_name}</strong> • Embarcação: <strong>{item.vessel_name}</strong>
                      </p>
                      <p className="text-slate-600">
                        Data: <strong>{item.booking_date}</strong> • Passageiros: <strong>{item.passengers}</strong> • Valor Total:{' '}
                        <strong>R$ {Number(item.gross_amount || 0).toLocaleString('pt-BR')}</strong>
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Embarque: {item.departure_point} • Check-in {item.check_in_time} • Saída {item.departure_time} • Retorno {item.return_time}
                      </p>
                      {item.rejection_or_cancel_reason && (
                        <p className="text-[11px] text-rose-700 font-semibold">
                          Observação de Status: {item.rejection_or_cancel_reason}
                        </p>
                      )}
                      <div className="pt-2 flex flex-wrap gap-2">
                        {cleanPhone && (
                          <a
                            href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent(
                              `Olá ${item.partner_name}! Consulta da reserva #${bCode} (${item.tour_title} em ${item.booking_date}).`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold inline-flex items-center gap-1"
                          >
                            <MessageCircle className="w-3.5 h-3.5" /> WhatsApp de {item.partner_name}
                          </a>
                        )}
                        {canCancel && (
                          <button
                            type="button"
                            disabled={cancellingBookingCode === bCode}
                            onClick={() => handleTouristCancelByToken(bCode, savedReceipt?.lookupToken)}
                            className="px-3 py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 disabled:opacity-50 text-rose-800 font-bold"
                          >
                            {cancellingBookingCode === bCode ? 'Cancelando...' : 'Cancelar Solicitação'}
                          </button>
                        )}
                        {savedReceipt && (
                          <button
                            type="button"
                            onClick={() => {
                              const nextReceipts = removeTouristReceipt(bCode);
                              setSavedTouristReceipts(nextReceipts);
                              setVerifiedTouristBookings((prev) => {
                                const copy = { ...prev };
                                delete copy[bCode];
                                return copy;
                              });
                            }}
                            className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold"
                          >
                            Remover deste navegador
                          </button>
                        )}
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-[#061829] text-slate-400 py-10 px-4 sm:px-6 border-t border-white/10 mt-16">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div>
            <span className="font-extrabold text-white">UBATUBA MAR & PRAIAS</span> — Marketplace Independente de Turismo Náutico, Lanchas, Escunas e Guia Oficial de Ubatuba/SP.
          </div>
          <div className="flex flex-wrap gap-4">
            <button onClick={() => navigateToTab('guide')} className="hover:text-cyan-300">
              Guia de Praias & Ilhas ({destinations.length})
            </button>
            <button onClick={() => navigateToTab('tours')} className="hover:text-cyan-300">
              Marketplace de Passeios
            </button>
            <button onClick={() => navigateToTab('partner-portal', 'partner')} className="hover:text-cyan-300">
              Área do Parceiro
            </button>
            <button onClick={() => navigateToTab('admin-portal', 'admin')} className="hover:text-cyan-300">
              Painel Admin
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}