#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.2
SUÍTE DE TESTES AUTOMATIZADOS DAS TRAVAS DE PROTEÇÃO CONTRA EXECUÇÃO DESTRUTIVA,
PARSER ADVERSARIAL DE DATABASE_URL, HIGIENIZAÇÃO DE VARIÁVEIS LIBPQ, TRATAMENTO DE SINAIS
E VERIFICAÇÃO DE PORTA / CONTAINER PREEXISTENTE DO RUNNER
(M01.9-001, M01.9-003, M02.0-F04, M02.0-F06, M02.0-F07, M02.2-F03 E M02.2-F04)
Arquivo: supabase/tests/test_runner_destructive_guards.py

Cobre obrigatoriamente os cenários GUARD-00 a GUARD-15:
  - GUARD-00: Verificação estrutural de sessão única `DO $guard$`, higienização `unset PG*` e reaplicação atômica `--single-transaction`
  - GUARD-01: Container descartável autorizado (`--docker` com `ubatuba_homolog_disposable`, `tmpfs` e label `run_id`)
  - GUARD-02: Banco local de homologação autorizado (`127.0.0.1` + `ubatuba_homolog_ci_01` + confirmação explícita)
  - GUARD-03: Banco externo não autorizado (host remoto `*.supabase.co` / IP externo) -> BLOQUEADO ANTES DO DROP
  - GUARD-04: Banco com nome de produção (`prod`, `production`, `prd`, `live`, `main`, `master`) -> BLOQUEADO ANTES DO DROP
  - GUARD-05: URL sem identificação confiável do ambiente (`postgres`, `defaultdb`, `supabase`, ou sem dbname) -> BLOQUEADO ANTES DO DROP
  - GUARD-06: Falha na consulta de identificação (erro de conexão ou `current_database()` vazio/nulo) -> BLOQUEADO ANTES DO DROP
  - GUARD-07: Tentativa de execução sem confirmação explícita (`UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB` ausente) -> BLOQUEADO ANTES DO DROP
  - GUARD-08: Tentativa de executar DROP em conexão não autorizada detectada DENTRO da mesma sessão `psql` -> BLOQUEADO ANTES DO DROP
  - GUARD-09: Proteção de propriedade do container (`--stop-container` recusa parar container de outro `run_id`)
  - GUARD-10 (M02.0-F06): Senha contendo `@` funciona quando o destino é válido, e parâmetros de redirecionamento
    na query string (`?host=`, `?hostaddr=`, `?dbname=`, `?user=`, `?service=`, `?passfile=`, `?options=`) são
    bloqueados ANTES de qualquer invocação de `psql`
  - GUARD-11 (M02.0-F06): URLs ambíguas ou malformadas (sem `@`, múltiplos `?`, espaços, porta inválida) são bloqueadas ANTES do `psql`
  - GUARD-12 (M02.0-F07): Preservação do `exit_code` original e limpeza do container próprio em erro pós-guarda
  - GUARD-13 (M02.0-F07): Verificação de colisão de porta TCP (`UBATUBA_DOCKER_PORT` ocupada é rejeitada com `PORT_IN_USE` antes do `docker run`)
  - GUARD-14 (M02.2-F03): Bloqueio adversarial de spoofing com `@` na query string (`?application_name=x@127.0.0.1:54322/ubatuba_homolog`),
    bloqueio de percent-encoding (`%`) e fragmentos (`#`), whitelist de query params e neutralização (`unset`) de variáveis `PGHOST`/`PGDATABASE`/`PGSERVICE`
  - GUARD-15 (M02.2-F04): Detecção de colisão com container preexistente de mesmo nome (`CONTAINER_ALREADY_EXISTS`) antes do `docker run`
"""

import json
import os
import re
import stat
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RUNNER_SCRIPT = PROJECT_ROOT / "supabase" / "tests" / "run_postgresql_homologation.sh"


def create_instrumented_shims(shim_dir: Path) -> None:
    psql_shim = shim_dir / "psql"
    psql_code = r'''#!/usr/bin/env python3
import json
import ipaddress
import os
import re
import sys

args = sys.argv[1:]
log_file = os.environ.get("MOCK_PSQL_LOG", "")

sql_input = ""
vars_map = {}
i = 0
while i < len(args):
    a = args[i]
    if a == "-c" and i + 1 < len(args):
        sql_input = args[i + 1]
        i += 2
    elif a == "-f" and i + 1 < len(args):
        sql_input = f"FILE:{args[i + 1]}"
        i += 2
    elif a == "-v" and i + 1 < len(args):
        kv = args[i + 1]
        if "=" in kv:
            k, v = kv.split("=", 1)
            vars_map[k] = v
        i += 2
    else:
        i += 1

if not sql_input and not sys.stdin.isatty():
    sql_input = sys.stdin.read()

def append_log(entry):
    if not log_file:
        return
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

if sql_input.strip() == "SELECT 1;":
    print("1")
    sys.exit(0)

is_guard_session = ("DO $guard$" in sql_input and "DROP SCHEMA IF EXISTS public CASCADE" in sql_input)
if is_guard_session:
    if os.environ.get("MOCK_PG_ID_QUERY_FAIL") == "1":
        append_log({
            "event": "guard_session_aborted",
            "reason": "ID_QUERY_FAILED_CONNECTION_ERROR",
            "same_session_verified": True,
            "drop_executed": False,
        })
        sys.stderr.write("psql: error: connection to server failed during identification query\n")
        sys.exit(1)

    cur_db = os.environ.get("MOCK_PG_CURRENT_DB", vars_map.get("expected_db", ""))
    cur_user = os.environ.get("MOCK_PG_CURRENT_USER", "postgres")
    sess_user = os.environ.get("MOCK_PG_SESSION_USER", "postgres")
    srv_addr = os.environ.get("MOCK_PG_SERVER_ADDR", "127.0.0.1")
    srv_port = int(os.environ.get("MOCK_PG_SERVER_PORT", "54322"))

    expected_db = vars_map.get("expected_db", "")
    confirm_token = vars_map.get("confirm_token", "")
    exec_mode = vars_map.get("execution_mode", "")
    run_id = vars_map.get("mission_run_id", "")

    def abort_guard(code, msg):
        append_log({
            "event": "guard_session_aborted",
            "reason": code,
            "message": msg,
            "same_session_verified": True,
            "drop_executed": False,
        })
        sys.stderr.write(f"ERROR:  RUNNER_GUARD_ABORT [{code}]: {msg}\n")
        sys.exit(1)

    if not cur_db or not cur_db.strip() or not cur_user or not sess_user:
        abort_guard("ID_QUERY_FAILED", "Falha ao identificar current_database/current_user/session_user na sessão ativa.")

    if confirm_token != "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO":
        abort_guard("MISSING_CONFIRMATION", "Variável de confirmação explícita ausente ou inválida na sessão.")

    if cur_db != expected_db:
        abort_guard("DB_MISMATCH", f"current_database() ({cur_db}) difere do banco esperado na URL ({expected_db}).")

    if cur_db.lower() in ("postgres", "defaultdb", "supabase", "template0", "template1"):
        abort_guard("FORBIDDEN_DEFAULT_DB", f"Banco padrão ({cur_db}) não pode sofrer reset destrutivo.")

    if re.search(r"(prod|production|prd|live|main|master|staging_real)", cur_db.lower()):
        abort_guard("PRODUCTION_DB_DETECTED", f"Nome do banco conectado ({cur_db}) contém indicador de produção.")

    if not re.match(r"^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$", cur_db):
        abort_guard("INVALID_DB_PATTERN", f"Nome do banco conectado ({cur_db}) fora do padrão obrigatório.")

    if exec_mode == "docker" and cur_db != "ubatuba_homolog_disposable":
        abort_guard("DOCKER_DB_MISMATCH", f"Modo docker exige banco ubatuba_homolog_disposable (atual={cur_db}).")

    if cur_user not in ("postgres", "supabase_admin") or sess_user not in ("postgres", "supabase_admin"):
        abort_guard("UNAUTHORIZED_DB_USER", f"Usuário conectado ({cur_user}/{sess_user}) não autorizado.")

    if srv_addr and srv_addr != "local_socket":
        ip_obj = ipaddress.ip_address(srv_addr)
        allowed_ip = (
            ip_obj.is_loopback
            or (exec_mode == "docker" and ip_obj.is_private)
        )
        if not allowed_ip:
            abort_guard("REMOTE_SERVER_ADDR_FORBIDDEN", f"Endereço do servidor PostgreSQL ({srv_addr}) não é local/descartável autorizado.")

    append_log({
        "event": "guard_session_passed_and_drop_executed",
        "same_session_verified": True,
        "drop_executed": True,
        "db": cur_db,
        "user": cur_user,
        "server_addr": srv_addr,
        "server_port": srv_port,
        "mode": exec_mode,
        "run_id": run_id,
        "pghost_env_seen_by_psql": os.environ.get("PGHOST", ""),
        "pgdatabase_env_seen_by_psql": os.environ.get("PGDATABASE", ""),
        "pgservice_env_seen_by_psql": os.environ.get("PGSERVICE", ""),
    })
    print(f"NOTICE:  [RUNNER_GUARD_PASS] Sessão validada com sucesso: db={cur_db}, mode={exec_mode}")
    sys.exit(0)

append_log({
    "event": "other_sql",
    "sql_preview": sql_input[:120],
    "drop_executed": ("DROP SCHEMA" in sql_input),
})
sys.exit(0)
'''
    psql_shim.write_text(psql_code, encoding="utf-8")
    psql_shim.chmod(psql_shim.stat().st_mode | stat.S_IEXEC)

    docker_shim = shim_dir / "docker"
    docker_code = r'''#!/usr/bin/env python3
import json
import os
import sys

args = sys.argv[1:]
state_file = os.environ.get("MOCK_DOCKER_STATE", "")
log_file = os.environ.get("MOCK_PSQL_LOG", "")

def load_state():
    if state_file and os.path.exists(state_file) and os.path.getsize(state_file) > 0:
        with open(state_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"containers": {}}

def save_state(st):
    if state_file:
        with open(state_file, "w", encoding="utf-8") as f:
            json.dump(st, f)

def append_log(entry):
    if log_file:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

state = load_state()
cmd = args[0] if args else ""

if cmd == "run":
    name = ""
    labels = {}
    has_tmpfs = False
    env_vars = {}
    port_mapping = ""
    i = 1
    while i < len(args):
        a = args[i]
        if a == "--name" and i + 1 < len(args):
            name = args[i + 1]
            i += 2
        elif a == "--label" and i + 1 < len(args):
            kv = args[i + 1]
            if "=" in kv:
                k, v = kv.split("=", 1)
                labels[k] = v
            i += 2
        elif a == "--tmpfs" and i + 1 < len(args):
            if "/var/lib/postgresql/data" in args[i + 1]:
                has_tmpfs = True
            i += 2
        elif a == "-e" and i + 1 < len(args):
            kv = args[i + 1]
            if "=" in kv:
                k, v = kv.split("=", 1)
                env_vars[k] = v
            i += 2
        elif a == "-p" and i + 1 < len(args):
            port_mapping = args[i + 1]
            i += 2
        else:
            i += 1
    state["containers"][name] = {
        "labels": labels,
        "has_tmpfs": has_tmpfs,
        "env": env_vars,
        "port_mapping": port_mapping,
        "running": True,
    }
    save_state(state)
    append_log({
        "event": "docker_run",
        "container_name": name,
        "labels": labels,
        "has_tmpfs": has_tmpfs,
        "port_mapping": port_mapping,
        "postgres_db": env_vars.get("POSTGRES_DB", ""),
    })
    print(f"cid_{name}")
    sys.exit(0)

if cmd == "inspect":
    target = args[-1]
    c = state["containers"].get(target)
    if not c:
        sys.exit(1)
    print(c["labels"].get("com.ubatuba.mission_run_id", ""))
    sys.exit(0)

if cmd in ("stop", "rm"):
    target = args[-1]
    if target in state["containers"]:
        if cmd == "stop":
            state["containers"][target]["running"] = False
        elif cmd == "rm":
            del state["containers"][target]
        save_state(state)
    append_log({"event": f"docker_{cmd}", "container_name": target})
    sys.exit(0)

sys.exit(0)
'''
    docker_shim.write_text(docker_code, encoding="utf-8")
    docker_shim.chmod(docker_shim.stat().st_mode | stat.S_IEXEC)


def run_guard_case(
    shim_dir: Path,
    args: List[str],
    env_overrides: Dict[str, str],
) -> Tuple[int, str, str, List[Dict]]:
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".jsonl", dir=str(shim_dir), delete=False) as tf_log, \
         tempfile.NamedTemporaryFile(mode="w+", suffix=".json", dir=str(shim_dir), delete=False) as tf_docker:
        log_path = Path(tf_log.name)
        docker_path = Path(tf_docker.name)
        if "INITIAL_DOCKER_STATE" in env_overrides:
            docker_path.write_text(env_overrides["INITIAL_DOCKER_STATE"], encoding="utf-8")

    env = dict(os.environ)
    env["PATH"] = f"{shim_dir}:{env.get('PATH', '')}"
    env["MOCK_PSQL_LOG"] = str(log_path)
    env["MOCK_DOCKER_STATE"] = str(docker_path)
    env["UBATUBA_TEST_ONLY_RESET_GUARD"] = "1"
    for k in (
        "DATABASE_URL",
        "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB",
        "UBATUBA_DOCKER_PORT",
        "MOCK_BUSY_PORT",
        "UBATUBA_SIMULATE_POST_GUARD_FAIL_RC",
    ):
        env.pop(k, None)
    for k in list(env.keys()):
        if k.startswith("MOCK_PG_"):
            env.pop(k, None)

    for k, v in env_overrides.items():
        if k == "INITIAL_DOCKER_STATE":
            continue
        env[k] = v

    proc = subprocess.run(
        ["bash", str(RUNNER_SCRIPT)] + args,
        cwd=str(PROJECT_ROOT),
        env=env,
        capture_output=True,
        text=True,
    )
    events: List[Dict] = []
    if log_path.exists():
        for line in log_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(json.loads(line))
        log_path.unlink(missing_ok=True)
    docker_path.unlink(missing_ok=True)
    return proc.returncode, proc.stdout, proc.stderr, events


def verify_same_session_and_atomic_reapply_structure() -> Tuple[bool, str]:
    txt = RUNNER_SCRIPT.read_text(encoding="utf-8")
    guard_blocks = re.findall(r"DO \$guard\$(.*?)\$guard\$;", txt, flags=re.S)
    if len(guard_blocks) != 1:
        return False, f"Esperado exatamente 1 bloco DO $guard$, encontrado: {len(guard_blocks)}"
    blk = guard_blocks[0]
    pos_id = blk.find("current_database()")
    pos_addr = blk.find("inet_server_addr()")
    pos_drop = blk.find("DROP SCHEMA IF EXISTS public CASCADE")
    total_drops_in_file = txt.count("DROP SCHEMA IF EXISTS public CASCADE")
    has_single_tx_reapply = (
        "--single-transaction" in txt
        and "20261115000009_missao02_1_residual_fixes.sql" in txt
        and "v_obsolete_policies" in txt
        and "unset PGHOST PGHOSTADDR PGPORT PGDATABASE" in txt
    )
    ok = (
        (0 < pos_id < pos_drop)
        and (0 < pos_addr < pos_drop)
        and (total_drops_in_file == 1)
        and has_single_tx_reapply
    )
    detail = (
        f"Bloco atômico único DO $guard$ na mesma sessão psql, unset PG* e reaplicação --single-transaction verificados "
        f"(pos_id={pos_id}, pos_inet={pos_addr} < pos_drop={pos_drop}, total_drops={total_drops_in_file})."
    )
    return ok, detail


def run_all_guard_tests() -> int:
    results: List[Tuple[str, bool, str]] = []

    def record(code: str, ok: bool, detail: str) -> None:
        results.append((code, ok, detail))
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] [{code}] {detail}")

    st_ok, st_detail = verify_same_session_and_atomic_reapply_structure()
    record("GUARD-00-SAME-SESSION-AND-ATOMIC-REAPPLY", st_ok, st_detail)

    with tempfile.TemporaryDirectory(prefix=".tmp_guard_shims_", dir=str(PROJECT_ROOT / "supabase" / "tests")) as tmp_dir:
        shim_dir = Path(tmp_dir)
        create_instrumented_shims(shim_dir)

        # Caso 1: Container descartável autorizado (--docker)
        rc1, _, _, ev1 = run_guard_case(
            shim_dir,
            ["--docker", "--run-id", "test_run_docker_01"],
            {"MOCK_PG_CURRENT_DB": "ubatuba_homolog_disposable"},
        )
        docker_runs = [e for e in ev1 if e.get("event") == "docker_run"]
        guard_pass_1 = [e for e in ev1 if e.get("event") == "guard_session_passed_and_drop_executed"]
        docker_stops = [e for e in ev1 if e.get("event") == "docker_stop"]
        c1_ok = (
            rc1 == 0
            and len(docker_runs) == 1
            and docker_runs[0].get("has_tmpfs") is True
            and docker_runs[0].get("postgres_db") == "ubatuba_homolog_disposable"
            and docker_runs[0].get("labels", {}).get("com.ubatuba.mission_run_id") == "test_run_docker_01"
            and len(guard_pass_1) == 1
            and guard_pass_1[0].get("same_session_verified") is True
            and len(docker_stops) == 1
        )
        record(
            "GUARD-01-DOCKER-AUTORIZADO",
            c1_ok,
            f"Container descartável autorizado validou identidade, executou reset na mesma sessão e limpou container ao final (rc={rc1}).",
        )

        # Caso 2: Banco local de homologação autorizado com confirmação explícita
        rc2, _, _, ev2 = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog_ci_01",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog_ci_01",
            },
        )
        guard_pass_2 = [e for e in ev2 if e.get("event") == "guard_session_passed_and_drop_executed"]
        c2_ok = rc2 == 0 and len(guard_pass_2) == 1 and guard_pass_2[0].get("drop_executed") is True
        record(
            "GUARD-02-HOMOLOG-AUTORIZADO",
            c2_ok,
            f"Banco local 'ubatuba_homolog_ci_01' com confirmação explícita aprovado na mesma sessão (rc={rc2}).",
        )

        # Caso 3: Banco externo não autorizado
        rc3, _, err3, ev3 = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:secret@db.aphheooljbmldpjeyuim.supabase.co:5432/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
            },
        )
        c3_ok = rc3 != 0 and len(ev3) == 0 and "RUNNER_GUARD_ABORT" in err3
        record(
            "GUARD-03-HOST-EXTERNO-BLOQUEADO",
            c3_ok,
            f"Banco externo (db.aphheooljbmldpjeyuim.supabase.co) bloqueado ANTES de qualquer invocação psql (rc={rc3}).",
        )

        # Caso 4: Banco com nome de produção
        prod_names = [
            "ubatuba_prod",
            "ubatuba_production_db",
            "ubatuba_homolog_prod",
            "ubatuba_live",
            "ubatuba_main",
            "ubatuba_master",
        ]
        c4_all_ok = True
        for pname in prod_names:
            rc4, _, err4, ev4 = run_guard_case(
                shim_dir,
                [],
                {
                    "DATABASE_URL": f"postgresql://postgres:postgres@127.0.0.1:54322/{pname}",
                    "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                },
            )
            if rc4 == 0 or len(ev4) != 0 or "RUNNER_GUARD_ABORT" not in err4:
                c4_all_ok = False
        record(
            "GUARD-04-NOME-PRODUCAO-BLOQUEADO",
            c4_all_ok,
            f"Todos os {len(prod_names)} nomes com indicadores de produção foram bloqueados ANTES do psql.",
        )

        # Caso 5: URL sem identificação confiável do ambiente
        unreliable_urls = [
            "postgresql://postgres:postgres@127.0.0.1:54322/postgres",
            "postgresql://postgres:postgres@127.0.0.1:54322/defaultdb",
            "postgresql://postgres:postgres@127.0.0.1:54322/supabase",
            "postgresql://postgres:postgres@127.0.0.1:54322/",
        ]
        c5_all_ok = True
        for uurl in unreliable_urls:
            rc5, _, err5, ev5 = run_guard_case(
                shim_dir,
                [],
                {
                    "DATABASE_URL": uurl,
                    "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                },
            )
            if rc5 == 0 or len(ev5) != 0 or "RUNNER_GUARD_ABORT" not in err5:
                c5_all_ok = False
        record(
            "GUARD-05-URL-SEM-ID-CONFIAVEL-BLOQUEADA",
            c5_all_ok,
            f"Todas as {len(unreliable_urls)} URLs padrão/sem identificação confiável foram bloqueadas ANTES do psql.",
        )

        # Caso 6: Falha na consulta de identificação
        rc6a, _, _, ev6a = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_ID_QUERY_FAIL": "1",
            },
        )
        rc6b, _, _, ev6b = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "   ",
            },
        )
        c6_ok = rc6a != 0 and rc6b != 0 and not any(e.get("drop_executed") for e in ev6a + ev6b)
        record(
            "GUARD-06-FALHA-CONSULTA-ID-BLOQUEADA",
            c6_ok,
            f"Falha na consulta de identificação e retorno vazio abortaram em modo fail-closed ANTES do DROP (rc6a={rc6a}, rc6b={rc6b}).",
        )

        # Caso 7: Tentativa de execução sem confirmação explícita
        rc7, _, err7, ev7 = run_guard_case(
            shim_dir,
            [],
            {"DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog"},
        )
        c7_ok = rc7 != 0 and len(ev7) == 0 and "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB" in err7
        record(
            "GUARD-07-SEM-CONFIRMACAO-BLOQUEADO",
            c7_ok,
            f"Execução sem UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB bloqueada imediatamente ANTES do psql (rc={rc7}).",
        )

        # Caso 8: Tentativa de executar DROP em conexão não autorizada detectada DENTRO da mesma sessão psql
        rc8a, _, err8a, ev8a = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_prod_real",
            },
        )
        rc8b, _, err8b, ev8b = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog",
                "MOCK_PG_SERVER_ADDR": "203.0.113.50",
            },
        )
        rc8c, _, err8c, ev8c = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog",
                "MOCK_PG_CURRENT_USER": "authenticator",
            },
        )
        c8_ok = (
            rc8a != 0
            and rc8b != 0
            and rc8c != 0
            and not any(e.get("drop_executed") for e in ev8a + ev8b + ev8c)
            and "DB_MISMATCH" in err8a
            and "REMOTE_SERVER_ADDR_FORBIDDEN" in err8b
            and "UNAUTHORIZED_DB_USER" in err8c
        )
        record(
            "GUARD-08-CONEXAO-NAO-AUTORIZADA-NA-SESSAO-BLOQUEADA",
            c8_ok,
            "Divergência de current_database(), inet_server_addr() remoto e current_user inválido abortaram dentro do bloco atômico DO $guard$ ANTES do DROP.",
        )

        # Caso 9: --stop-container recusa parar container cujo label pertence a outro run_id
        foreign_state = json.dumps(
            {
                "containers": {
                    "ubatuba_homolog_pg15_run_legitimo_99": {
                        "labels": {"com.ubatuba.mission_run_id": "outro_owner_diferente"},
                        "has_tmpfs": True,
                        "env": {"POSTGRES_DB": "ubatuba_homolog_disposable"},
                        "running": True,
                    }
                }
            }
        )
        rc9, _, err9, ev9 = run_guard_case(
            shim_dir,
            ["--stop-container", "--run-id", "run_legitimo_99"],
            {"INITIAL_DOCKER_STATE": foreign_state},
        )
        c9_ok = rc9 != 0 and not any(e.get("event") in ("docker_stop", "docker_rm") for e in ev9) and "RUNNER_GUARD_ABORT" in err9
        record(
            "GUARD-09-CONTAINER-OWNERSHIP-PROTECTION",
            c9_ok,
            f"Proteção de propriedade impediu encerrar container pertencente a outro run_id (rc={rc9}).",
        )

        # Caso 10 (M02.0-F06): Senha contendo '@' funciona para destino local autorizado, e query params proibidos
        rc10_at, _, _, ev10_at = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:p@ss@word!123@127.0.0.1:54322/ubatuba_homolog_02",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog_02",
            },
        )
        forbidden_query_urls = [
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?host=db.prod.supabase.co",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?hostaddr=203.0.113.10",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?dbname=ubatuba_prod",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?user=authenticator",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?service=prod_service",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?sslmode=disable&host=evil.example.com",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?passfile=/tmp/pgpass",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?options=-c_role=postgres",
        ]
        q_blocked_ok = True
        for qurl in forbidden_query_urls:
            rc_q, _, err_q, ev_q = run_guard_case(
                shim_dir,
                [],
                {
                    "DATABASE_URL": qurl,
                    "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                },
            )
            if rc_q == 0 or len(ev_q) != 0 or "QUERY_PARAM_FORBIDDEN" not in err_q:
                q_blocked_ok = False
        c10_ok = rc10_at == 0 and any(e.get("drop_executed") for e in ev10_at) and q_blocked_ok
        record(
            "GUARD-10-PASSWORD-AT-AND-QUERY-PARAMS",
            c10_ok,
            f"Senha com '@' suportada (rc={rc10_at}) e todos os {len(forbidden_query_urls)} parâmetros de redirecionamento (?host=, ?hostaddr=, ?dbname=, ?user=, ?service=, etc.) bloqueados ANTES do psql.",
        )

        # Caso 11 (M02.0-F06): URLs ambíguas ou malformadas
        malformed_urls = [
            "postgresql://127.0.0.1:54322/ubatuba_homolog",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?sslmode=disable?host=1.2.3.4",
            "postgresql://postgres:postgres@127.0.0.1:99999/ubatuba_homolog",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog/extra",
            "http://postgres:postgres@127.0.0.1:54322/ubatuba_homolog",
        ]
        c11_ok = True
        for murl in malformed_urls:
            rc_m, _, err_m, ev_m = run_guard_case(
                shim_dir,
                [],
                {
                    "DATABASE_URL": murl,
                    "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                },
            )
            if rc_m == 0 or len(ev_m) != 0 or "RUNNER_GUARD_ABORT" not in err_m:
                c11_ok = False
        record(
            "GUARD-11-MALFORMED-AND-AMBIGUOUS-URLS",
            c11_ok,
            f"Todas as {len(malformed_urls)} URLs ambíguas/malformadas foram rejeitadas ANTES de invocar o psql.",
        )

        # Caso 12 (M02.0-F07): Preservação do código de saída original (ex.: rc=42) após cleanup do container próprio
        rc12, _, _, ev12 = run_guard_case(
            shim_dir,
            ["--docker", "--run-id", "test_exit_code_preserve"],
            {
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog_disposable",
                "UBATUBA_SIMULATE_POST_GUARD_FAIL_RC": "42",
            },
        )
        stops_12 = [e for e in ev12 if e.get("event") == "docker_stop"]
        c12_ok = rc12 == 42 and len(stops_12) == 1
        record(
            "GUARD-12-EXIT-CODE-PRESERVATION-AND-CLEANUP",
            c12_ok,
            f"Cleanup do container executou em falha subsequente e preservou exatamente o código de saída original (rc={rc12}).",
        )

        # Caso 13 (M02.0-F07): Verificação de colisão de porta TCP local (UBATUBA_DOCKER_PORT ocupada)
        rc13, _, err13, ev13 = run_guard_case(
            shim_dir,
            ["--docker", "--run-id", "test_port_collision"],
            {
                "UBATUBA_DOCKER_PORT": "55499",
                "MOCK_BUSY_PORT": "55499",
            },
        )
        c13_ok = rc13 == 3 and len(ev13) == 0 and "PORT_IN_USE" in err13
        record(
            "GUARD-13-PORT-COLLISION-DETECTION",
            c13_ok,
            f"Colisão na porta local 55499 detectada e bloqueada com PORT_IN_USE antes do docker run (rc={rc13}).",
        )

        # Caso 14 (M02.2-F03): Spoofing de host via '@' na query string, percent-encoding '%', '#' e unset de variáveis PG* da libpq
        spoof_urls = [
            "postgresql://postgres:secret@db.prod.supabase.co:5432/ubatuba_prod?application_name=x@127.0.0.1:54322/ubatuba_homolog",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?%68ost=db.prod.supabase.co",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog#fragment",
            "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog?unknown_param=1",
        ]
        c14_spoof_blocked = True
        for surl in spoof_urls:
            rc_s, _, err_s, ev_s = run_guard_case(
                shim_dir,
                [],
                {
                    "DATABASE_URL": surl,
                    "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                },
            )
            if rc_s == 0 or len(ev_s) != 0 or "RUNNER_GUARD_ABORT" not in err_s:
                c14_spoof_blocked = False

        # Verifica que PGHOST/PGDATABASE/PGSERVICE injetados no ambiente são removidos pelo runner antes do psql
        rc14_env, _, _, ev14_env = run_guard_case(
            shim_dir,
            [],
            {
                "DATABASE_URL": "postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog_ci_02?sslmode=disable&connect_timeout=5",
                "UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB": "CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO",
                "MOCK_PG_CURRENT_DB": "ubatuba_homolog_ci_02",
                "PGHOST": "db.evil-override.supabase.co",
                "PGDATABASE": "ubatuba_prod",
                "PGSERVICE": "evil_service",
            },
        )
        gp14 = [e for e in ev14_env if e.get("event") == "guard_session_passed_and_drop_executed"]
        c14_env_unset = (
            rc14_env == 0
            and len(gp14) == 1
            and gp14[0].get("pghost_env_seen_by_psql") == ""
            and gp14[0].get("pgdatabase_env_seen_by_psql") == ""
            and gp14[0].get("pgservice_env_seen_by_psql") == ""
        )
        record(
            "GUARD-14-QUERY-AT-SPOOF-AND-LIBPQ-ENV-UNSET",
            c14_spoof_blocked and c14_env_unset,
            f"Spoofing de host via '@' na query string, '%', '#' e params fora da whitelist bloqueados ANTES do psql; variáveis PGHOST/PGDATABASE/PGSERVICE neutralizadas.",
        )

        # Caso 15 (M02.2-F04): Detecção de colisão com container preexistente de mesmo nome antes do docker run
        preexisting_state = json.dumps(
            {
                "containers": {
                    "ubatuba_homolog_pg15_dup_run_01": {
                        "labels": {"com.ubatuba.mission_run_id": "dup_run_01"},
                        "has_tmpfs": True,
                        "env": {"POSTGRES_DB": "ubatuba_homolog_disposable"},
                        "running": True,
                    }
                }
            }
        )
        rc15, _, err15, ev15 = run_guard_case(
            shim_dir,
            ["--docker", "--run-id", "dup_run_01"],
            {"INITIAL_DOCKER_STATE": preexisting_state},
        )
        c15_ok = rc15 == 3 and len(ev15) == 0 and "CONTAINER_ALREADY_EXISTS" in err15
        record(
            "GUARD-15-CONTAINER-PREEXISTENCE-COLLISION",
            c15_ok,
            f"Container preexistente com mesmo nome detectado e bloqueado com CONTAINER_ALREADY_EXISTS antes do docker run (rc={rc15}).",
        )

    passed = sum(1 for _, ok, _ in results if ok)
    print("=" * 78)
    print(f"RESULTADO DA SUÍTE DE GUARDA DO RUNNER (GUARD-00 A GUARD-15): {passed}/{len(results)} APROVADOS")
    print("=" * 78)
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(run_all_guard_tests())
