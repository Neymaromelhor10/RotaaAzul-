#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.2
SUÍTE EXECUTÁVEL REAL DE CARGA E ESTABILIDADE L1, L2 E L3 PARA POSTGRESQL 15+
Arquivo: supabase/tests/load_stability_plan_pg.py

Correções implementadas nas Missões 02.1 e 02.2 (M02.0-F01, M02.0-F02, M02.0-F08 e M02.2-F06):
  1. M02.0-F01 (P0): Todas as consultas a `public.commission_ledger` utilizam a coluna real
     `ledger_status` e os valores reais do enum `public.ledger_status_type`
     (`'PREVISTA'`, `'CONFIRMADA'`, `'PAGA'`, `'REVERTIDA'`, `'EM_DISPUTA'`).
  2. M02.0-F02 (P0):
     - `ensure_load_test_partner_users()` provisiona de forma idempotente os usuários
       parceiros de teste em `auth.users`, `public.profiles` e `public.partner_members` para
       os parceiros reais do seed 000004 (`1111...101` e `1111...103`).
     - Utiliza exclusivamente o valor válido `'AJUSTE_CAPACIDADE'` aceito pela
       constraint `availability_blocks_block_type_check` e pela RPC `upsert_availability_block`.
     - Em L3, a tentativa de reativação de reserva expirada exige bloqueio específico pela regra
       de transição (`INVALID_STATUS_TRANSITION`), jamais aceitando falha de permissão.
  3. M02.0-F08 & M02.2-F06 (P2):
     - Utiliza sessões `psql` pré-conectadas (`execute_prewarmed_psql_at_barrier` via `subprocess.Popen`)
       que realizam o `fork/exec`, abrem a conexão TCP/PostgreSQL e respondem ao ping
       `SELECT 'UBATUBA_SESSION_READY';` ANTES de liberar a barreira (`barrier.wait()`).
     - Se qualquer worker falhar na etapa de pré-conexão, aciona imediatamente `barrier.abort()`
       e captura `threading.BrokenBarrierError` em todos os workers, evitando travamentos ou
       exceções `NoneType` na agregação de resultados.
"""

import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REPORT_JSON_PATH = PROJECT_ROOT / "supabase" / "tests" / "load_stability_report.json"
DATABASE_URL = os.environ.get("DATABASE_URL", "")

PARTNER_KAIMARES_ID = "11111111-1111-4111-8111-111111111101"
PARTNER_ESCUNA_ID = "11111111-1111-4111-8111-111111111103"

PARTNER_KAIMARES_USER = "bbbb2222-2222-4222-8222-222222222201"
PARTNER_ESCUNA_USER = "bbbb2222-2222-4222-8222-222222222203"


def run_psql(sql: str, timeout_sec: float = 30.0) -> Tuple[int, str, str]:
    try:
        proc = subprocess.run(
            ["psql", DATABASE_URL, "-X", "-v", "ON_ERROR_STOP=1", "-t", "-A", "-c", sql],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except subprocess.TimeoutExpired as exc:
        return 124, "", f"TIMEOUT_EXPIRED ({timeout_sec}s): {exc}"


def execute_prewarmed_psql_at_barrier(
    sql: str,
    barrier: threading.Barrier,
    timeout_sec: float = 30.0,
) -> Dict[str, Any]:
    """
    M02.0-F08 & M02.2-F06:
    1) Inicia o processo `psql` interativo (`process_spawn_ms`);
    2) Envia `SELECT 'UBATUBA_SESSION_READY';` e aguarda a linha de resposta para comprovar
       que a conexão PostgreSQL está estabelecida e autenticada (`connection_ready_ms`);
    3) Se falhar no prewarm, chama `barrier.abort()` para liberar imediatamente as demais threads;
    4) Aguarda todas as threads na barreira (`barrier.wait()`) com as sessões já abertas;
    5) Envia o SQL do teste e mede exclusivamente `sql_exec_ms` até o término da execução.
    """
    t_start = time.perf_counter()
    proc = subprocess.Popen(
        ["psql", DATABASE_URL, "-X", "-v", "ON_ERROR_STOP=1", "-t", "-A"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    t_spawned = time.perf_counter()
    process_spawn_ms = round((t_spawned - t_start) * 1000.0, 3)

    assert proc.stdin is not None and proc.stdout is not None and proc.stderr is not None
    try:
        proc.stdin.write("SELECT 'UBATUBA_SESSION_READY';\n")
        proc.stdin.flush()
        ready_line = proc.stdout.readline().strip()
        if ready_line != "UBATUBA_SESSION_READY":
            err_early = proc.stderr.read()
            proc.kill()
            barrier.abort()
            return {
                "return_code": 1,
                "stdout": ready_line,
                "stderr": f"SESSION_PREWARM_FAILED: {err_early}",
                "process_spawn_ms": process_spawn_ms,
                "connection_ready_ms": 0.0,
                "sql_exec_ms": 0.0,
                "total_client_ms": round((time.perf_counter() - t_start) * 1000.0, 3),
            }
        t_ready = time.perf_counter()
        connection_ready_ms = round((t_ready - t_spawned) * 1000.0, 3)

        barrier.wait(timeout=timeout_sec)

        t_sql_start = time.perf_counter()
        out, err = proc.communicate(input=sql + "\n\\q\n", timeout=timeout_sec)
        t_sql_end = time.perf_counter()
        sql_exec_ms = round((t_sql_end - t_sql_start) * 1000.0, 3)
        total_client_ms = round(process_spawn_ms + connection_ready_ms + sql_exec_ms, 3)

        return {
            "return_code": proc.returncode,
            "stdout": (out or "").strip(),
            "stderr": (err or "").strip(),
            "process_spawn_ms": process_spawn_ms,
            "connection_ready_ms": connection_ready_ms,
            "sql_exec_ms": sql_exec_ms,
            "total_client_ms": total_client_ms,
        }
    except threading.BrokenBarrierError as exc:
        proc.kill()
        return {
            "return_code": 1,
            "stdout": "",
            "stderr": f"BARRIER_ABORTED_BY_PEER_PREWARM_FAILURE: {exc}",
            "process_spawn_ms": process_spawn_ms,
            "connection_ready_ms": 0.0,
            "sql_exec_ms": 0.0,
            "total_client_ms": round((time.perf_counter() - t_start) * 1000.0, 3),
        }
    except subprocess.TimeoutExpired as exc:
        proc.kill()
        barrier.abort()
        return {
            "return_code": 124,
            "stdout": "",
            "stderr": f"TIMEOUT_EXPIRED ({timeout_sec}s): {exc}",
            "process_spawn_ms": process_spawn_ms,
            "connection_ready_ms": 0.0,
            "sql_exec_ms": round(timeout_sec * 1000.0, 3),
            "total_client_ms": round((time.perf_counter() - t_start) * 1000.0, 3),
        }


def compute_latency_stats(latencies_ms: List[float]) -> Dict[str, float]:
    if not latencies_ms:
        return {"count": 0, "min_ms": 0.0, "avg_ms": 0.0, "max_ms": 0.0, "p95_ms": 0.0, "p99_ms": 0.0}
    sorted_vals = sorted(latencies_ms)
    n = len(sorted_vals)

    def percentile(p: float) -> float:
        idx = max(0, min(n - 1, math.ceil((p / 100.0) * n) - 1))
        return round(sorted_vals[idx], 3)

    return {
        "count": n,
        "min_ms": round(sorted_vals[0], 3),
        "avg_ms": round(sum(sorted_vals) / n, 3),
        "max_ms": round(sorted_vals[-1], 3),
        "p95_ms": percentile(95.0),
        "p99_ms": percentile(99.0),
    }


def classify_booking_outcome(rc: int, stdout: str, stderr: str) -> str:
    err_upper = stderr.upper()
    if rc == 124 or "57014" in err_upper or "STATEMENT TIMEOUT" in err_upper or "TIMEOUT_EXPIRED" in err_upper:
        return "TIMEOUT"
    if "40P01" in err_upper or "DEADLOCK" in err_upper:
        return "DEADLOCK"
    if rc == 0 and ("UBT-" in stdout or '"code"' in stdout):
        return "SUCCESS"
    if "CAPACITY_EXCEEDED" in err_upper or "VESSEL_BLOCKED" in err_upper:
        return "EXPECTED_CAPACITY_CONFLICT"
    return "UNEXPECTED_FAILURE"


def verify_safe_disposable_database() -> None:
    if os.environ.get("UBATUBA_ALLOW_LOAD_TEST") != "1":
        raise RuntimeError(
            "Execução recusada: defina UBATUBA_ALLOW_LOAD_TEST=1 apenas quando conectado a banco de homologação descartável."
        )
    if not re.search(r"127\.0\.0\.1|localhost|::1", DATABASE_URL):
        raise RuntimeError("Execução recusada: DATABASE_URL deve apontar exclusivamente para host local (127.0.0.1/localhost).")

    rc, out, err = run_psql("SELECT current_database() || '|' || COUNT(*)::text FROM pg_trigger WHERE NOT tgisinternal AND tgenabled = 'D';")
    if rc != 0 or "|" not in out:
        raise RuntimeError(f"Falha ao verificar banco e triggers antes da carga: {err}")
    db_name, disabled_triggers = out.split("|", 1)
    if re.search(r"(prod|production|prd|live|main|master)", db_name.lower()) or not re.match(
        r"^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$", db_name
    ):
        raise RuntimeError(f"Banco conectado '{db_name}' não é um banco descartável autorizado (^ubatuba_(homolog|test|ci)...).")
    if int(disabled_triggers.strip()) != 0:
        raise RuntimeError(f"Detectadas {disabled_triggers} triggers desabilitadas antes dos testes de carga.")


def ensure_load_test_partner_users() -> None:
    setup_users_sql = f"""
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon NOLOGIN;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
        CREATE ROLE authenticated NOLOGIN;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
        CREATE ROLE service_role NOLOGIN BYPASSRLS;
      END IF;

      GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
      GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
      GRANT UPDATE ON public.tours, public.vessels TO authenticated;

      INSERT INTO auth.users (
        id, email, email_confirmed_at, confirmed_at, raw_user_meta_data, raw_app_meta_data, created_at, updated_at
      ) VALUES
        (
          '{PARTNER_KAIMARES_USER}'::uuid,
          'load.partner.kaimares@homolog.invalid',
          now(),
          now(),
          '{{"full_name": "Operador Carga Kaimares", "phone": "(12) 99776-6789"}}'::jsonb,
          '{{"system_role": "partner"}}'::jsonb,
          now(),
          now()
        ),
        (
          '{PARTNER_ESCUNA_USER}'::uuid,
          'load.partner.escuna@homolog.invalid',
          now(),
          now(),
          '{{"full_name": "Operador Carga Escuna Caicara", "phone": "(12) 99184-7933"}}'::jsonb,
          '{{"system_role": "partner"}}'::jsonb,
          now(),
          now()
        )
      ON CONFLICT (id) DO UPDATE
      SET email_confirmed_at = COALESCE(auth.users.email_confirmed_at, now()),
          confirmed_at = COALESCE(auth.users.confirmed_at, now()),
          updated_at = now();

      PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', '{PARTNER_KAIMARES_USER}'::uuid, 'partner');
      UPDATE public.profiles
      SET system_role = 'partner', is_active = true
      WHERE id = '{PARTNER_KAIMARES_USER}'::uuid;
      PERFORM internal_guard.cleanup_tokens('AUTH_PROFILE_SYNC', '{PARTNER_KAIMARES_USER}'::uuid);

      PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', '{PARTNER_ESCUNA_USER}'::uuid, 'partner');
      UPDATE public.profiles
      SET system_role = 'partner', is_active = true
      WHERE id = '{PARTNER_ESCUNA_USER}'::uuid;
      PERFORM internal_guard.cleanup_tokens('AUTH_PROFILE_SYNC', '{PARTNER_ESCUNA_USER}'::uuid);

      INSERT INTO public.partner_members (partner_id, user_id, member_role, is_active)
      VALUES
        ('{PARTNER_KAIMARES_ID}'::uuid, '{PARTNER_KAIMARES_USER}'::uuid, 'owner', true),
        ('{PARTNER_ESCUNA_ID}'::uuid, '{PARTNER_ESCUNA_USER}'::uuid, 'owner', true)
      ON CONFLICT (partner_id, user_id) DO UPDATE
      SET member_role = 'owner', is_active = true;
    END $$;

    SET LOCAL ROLE authenticated;
    SELECT set_config('request.jwt.claim.sub', '{PARTNER_KAIMARES_USER}', true);
    SELECT set_config('request.jwt.claim.role', 'authenticated', true);
    SELECT CASE WHEN public.is_partner_member('{PARTNER_KAIMARES_ID}'::uuid) THEN 'KAIMARES_OK' ELSE 'KAIMARES_FAIL' END;

    SELECT set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
    SELECT CASE WHEN public.is_partner_member('{PARTNER_ESCUNA_ID}'::uuid) THEN 'ESCUNA_OK' ELSE 'ESCUNA_FAIL' END;
    RESET ROLE;
    """
    rc, out, err = run_psql(setup_users_sql)
    if rc != 0 or "KAIMARES_OK" not in out or "ESCUNA_OK" not in out:
        raise RuntimeError(f"Falha ao provisionar e validar usuários parceiros de teste (M02.0-F02): out={out} err={err}")


def cleanup_bookings_and_blocks_via_rpcs(dates: List[str], tag: str) -> None:
    dates_sql = ", ".join(f"DATE '{d}'" for d in dates)
    cleanup_sql = f"""
    DO $$
    DECLARE
      r_blk RECORD;
      r_bk RECORD;
    BEGIN
      PERFORM set_config('request.jwt.claim.sub', '', true);
      PERFORM set_config('request.jwt.claim.role', 'service_role', true);

      FOR r_blk IN
        SELECT id FROM public.availability_blocks
        WHERE block_date IN ({dates_sql})
      LOOP
        PERFORM public.delete_availability_block(r_blk.id);
      END LOOP;

      FOR r_bk IN
        SELECT id FROM public.bookings
        WHERE booking_date IN ({dates_sql})
          AND status NOT IN ('CANCELADA', 'RECUSADA', 'PASSEIO_REALIZADO')
      LOOP
        PERFORM public.transition_booking_status(
          r_bk.id::text,
          'CANCELADA',
          'Limpeza controlada pós-teste de carga ({tag}) via RPC oficial'
        );
      END LOOP;

      UPDATE public.vessels SET capacity = 65 WHERE slug = 'ves-escuna-corsario' AND capacity <> 65;
      UPDATE public.tours SET capacity = 65 WHERE slug = 'tour-escuna-anchieta' AND capacity <> 65;
      UPDATE public.vessels SET capacity = 12 WHERE slug = 'ves-phantom-340' AND capacity <> 12;
      UPDATE public.tours SET capacity = 12 WHERE slug = 'tour-lancha-norte-comp' AND capacity <> 12;
    END $$;
    """
    run_psql(cleanup_sql)


def execute_scenario_l1(tag: str) -> Dict[str, Any]:
    l1_date = "2027-02-10"
    total_requests = 50
    passengers_per_req = 2
    tour_capacity = 12

    cleanup_bookings_and_blocks_via_rpcs([l1_date], tag)

    barrier = threading.Barrier(total_requests)
    individual_results: List[Dict[str, Any]] = [None] * total_requests  # type: ignore

    def worker_l1(req_idx: int) -> None:
        sql = f"""
        SET LOCAL ROLE anon;
        SELECT set_config('request.jwt.claim.sub', '', true);
        SELECT set_config('request.jwt.claim.role', 'anon', true);
        SELECT public.create_booking_request(
          'tour-lancha-norte-comp',
          DATE '{l1_date}',
          {passengers_per_req}::smallint,
          'SITE_DIRECT',
          'Carga L1 Sintetico {req_idx:02d}',
          '(12) 99100-{req_idx:04d}',
          'l1.req{req_idx:02d}.{tag}@homolog.invalid',
          'load_l1',
          'concurrency_50',
          'missao_02_2',
          'Teste L1 requisicao {req_idx:02d}',
          'idem-l1-{tag}-{req_idx:02d}'
        )::text;
        """
        metrics = execute_prewarmed_psql_at_barrier(sql, barrier)
        classification = classify_booking_outcome(
            metrics["return_code"],
            metrics["stdout"],
            metrics["stderr"],
        )
        individual_results[req_idx - 1] = {
            "request_id": req_idx,
            "return_code": metrics["return_code"],
            "process_spawn_ms": metrics["process_spawn_ms"],
            "connection_ready_ms": metrics["connection_ready_ms"],
            "sql_exec_ms": metrics["sql_exec_ms"],
            "total_client_ms": metrics["total_client_ms"],
            "latency_ms": metrics["sql_exec_ms"],
            "classification": classification,
            "error_excerpt": metrics["stderr"][:160] if metrics["return_code"] != 0 else "",
        }

    try:
        threads = [threading.Thread(target=worker_l1, args=(i,)) for i in range(1, total_requests + 1)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        valid_results = [r for r in individual_results if r is not None]
        sql_latencies = [r["sql_exec_ms"] for r in valid_results]
        client_latencies = [r["total_client_ms"] for r in valid_results]
        spawn_latencies = [r["process_spawn_ms"] for r in valid_results]
        conn_latencies = [r["connection_ready_ms"] for r in valid_results]

        counts = {
            "SUCCESS": sum(1 for r in valid_results if r["classification"] == "SUCCESS"),
            "EXPECTED_CAPACITY_CONFLICT": sum(
                1 for r in valid_results if r["classification"] == "EXPECTED_CAPACITY_CONFLICT"
            ),
            "DEADLOCK": sum(1 for r in valid_results if r["classification"] == "DEADLOCK"),
            "TIMEOUT": sum(1 for r in valid_results if r["classification"] == "TIMEOUT"),
            "UNEXPECTED_FAILURE": sum(1 for r in valid_results if r["classification"] == "UNEXPECTED_FAILURE"),
        }

        verify_sql = f"""
        SELECT jsonb_build_object(
          'occupied_seats', COALESCE((public.get_tour_availability('tour-lancha-norte-comp', DATE '{l1_date}')->>'occupied_seats')::int, -1),
          'active_bookings_count', (
            SELECT COUNT(*) FROM public.bookings b
            JOIN public.tours t ON t.id = b.tour_id
            WHERE t.slug = 'tour-lancha-norte-comp'
              AND b.booking_date = DATE '{l1_date}'
              AND b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO')
          ),
          'active_passengers_sum', COALESCE((
            SELECT SUM(b.passengers) FROM public.bookings b
            JOIN public.tours t ON t.id = b.tour_id
            WHERE t.slug = 'tour-lancha-norte-comp'
              AND b.booking_date = DATE '{l1_date}'
              AND b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO')
          ), 0),
          'ledger_prevista_count', (
            SELECT COUNT(*) FROM public.commission_ledger cl
            JOIN public.bookings b ON b.id = cl.booking_id
            JOIN public.tours t ON t.id = b.tour_id
            WHERE t.slug = 'tour-lancha-norte-comp'
              AND b.booking_date = DATE '{l1_date}'
              AND b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA')
              AND cl.ledger_status = 'PREVISTA'
          ),
          'residual_tokens', (SELECT COUNT(*) FROM internal_guard.execution_tokens)
        )::text;
        """
        rc_v, out_v, _ = run_psql(verify_sql)
        db_state = json.loads(out_v.splitlines()[-1]) if rc_v == 0 and out_v else {}

        expected_successes = tour_capacity // passengers_per_req
        expected_conflicts = total_requests - expected_successes

        passed = (
            len(valid_results) == total_requests
            and counts["SUCCESS"] > 0
            and counts["SUCCESS"] == expected_successes
            and counts["EXPECTED_CAPACITY_CONFLICT"] == expected_conflicts
            and counts["DEADLOCK"] == 0
            and counts["TIMEOUT"] == 0
            and counts["UNEXPECTED_FAILURE"] == 0
            and db_state.get("occupied_seats") == tour_capacity
            and db_state.get("active_passengers_sum") == tour_capacity
            and db_state.get("active_bookings_count") == counts["SUCCESS"]
            and db_state.get("ledger_prevista_count") == counts["SUCCESS"]
            and db_state.get("residual_tokens") == 0
        )

        return {
            "scenario": "L1",
            "passed": passed,
            "total_requests": total_requests,
            "passengers_per_request": passengers_per_req,
            "tour_capacity": tour_capacity,
            "classifications": counts,
            "latency_ms": compute_latency_stats(sql_latencies),
            "timing_breakdown_ms": {
                "sql_exec_ms": compute_latency_stats(sql_latencies),
                "total_client_ms": compute_latency_stats(client_latencies),
                "process_spawn_ms": compute_latency_stats(spawn_latencies),
                "connection_ready_ms": compute_latency_stats(conn_latencies),
            },
            "db_verification": db_state,
            "individual_results": valid_results,
        }
    finally:
        cleanup_bookings_and_blocks_via_rpcs([l1_date], tag)


def execute_scenario_l2(tag: str) -> Dict[str, Any]:
    l2_date = "2027-02-15"
    cleanup_bookings_and_blocks_via_rpcs([l2_date], tag)

    seed_ids: List[str] = []
    try:
        for idx in range(1, 7):
            sql_seed = f"""
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT (public.create_booking_request(
              'tour-escuna-anchieta',
              DATE '{l2_date}',
              5::smallint,
              'SITE_DIRECT',
              'Base L2 Reserva {idx}',
              '(12) 99200-{idx:04d}',
              'l2.seed{idx}.{tag}@homolog.invalid',
              'load_l2',
              'seed',
              'missao_02_2',
              'Reserva base L2 #{idx}',
              'idem-l2-seed-{tag}-{idx}'
            )->>'id');
            """
            rc_s, out_s, err_s = run_psql(sql_seed)
            if rc_s != 0 or not out_s:
                raise RuntimeError(f"Falha ao preparar reserva base #{idx} do cenário L2: {err_s}")
            seed_ids.append(out_s.splitlines()[-1].strip())

        total_ops = 20
        barrier = threading.Barrier(total_ops)
        op_results: List[Dict[str, Any]] = [None] * total_ops  # type: ignore

        def worker_l2(op_idx: int) -> None:
            if 1 <= op_idx <= 6:
                op_type = "CREATE_BOOKING"
                sql = f"""
                SET LOCAL ROLE anon;
                SELECT set_config('request.jwt.claim.sub', '', true);
                SELECT set_config('request.jwt.claim.role', 'anon', true);
                SELECT public.create_booking_request(
                  'tour-escuna-anchieta',
                  DATE '{l2_date}',
                  4::smallint,
                  'SITE_DIRECT',
                  'Concorrente L2 Cliente {op_idx}',
                  '(12) 99210-{op_idx:04d}',
                  'l2.new{op_idx}.{tag}@homolog.invalid',
                  'load_l2',
                  'cross_op',
                  'missao_02_2',
                  'Criacao concorrente L2 #{op_idx}',
                  'idem-l2-new-{tag}-{op_idx}'
                )::text;
                """
            elif 7 <= op_idx <= 9:
                op_type = "CONFIRM_BOOKING"
                target_id = seed_ids[op_idx - 7]
                sql = f"""
                SET LOCAL ROLE authenticated;
                SELECT set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
                SELECT set_config('request.jwt.claim.role', 'authenticated', true);
                SELECT public.transition_booking_status('{target_id}', 'CONFIRMADA', 'Confirmacao concorrente L2 op {op_idx}')::text;
                """
            elif 10 <= op_idx <= 12:
                op_type = "CANCEL_BOOKING"
                target_id = seed_ids[op_idx - 7]
                sql = f"""
                SET LOCAL ROLE authenticated;
                SELECT set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
                SELECT set_config('request.jwt.claim.role', 'authenticated', true);
                SELECT public.transition_booking_status('{target_id}', 'CANCELADA', 'Cancelamento concorrente L2 op {op_idx}')::text;
                """
            elif 13 <= op_idx <= 15:
                op_type = "UPDATE_TOUR_CAPACITY"
                new_cap = 10 if op_idx == 13 else (55 if op_idx == 14 else 60)
                sql = f"""
                DO $$
                DECLARE v_rows INT;
                BEGIN
                  SET LOCAL ROLE authenticated;
                  PERFORM set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
                  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
                  UPDATE public.tours SET capacity = {new_cap} WHERE slug = 'tour-escuna-anchieta';
                  GET DIAGNOSTICS v_rows = ROW_COUNT;
                  IF v_rows <> 1 THEN
                    RAISE EXCEPTION 'RLS_UPDATE_TOUR_ZERO_ROWS: Parceiro autenticado não conseguiu atualizar public.tours';
                  END IF;
                END $$;
                """
            elif 16 <= op_idx <= 17:
                op_type = "UPDATE_VESSEL_CAPACITY"
                new_vcap = 10 if op_idx == 16 else 65
                sql = f"""
                DO $$
                DECLARE v_rows INT;
                BEGIN
                  SET LOCAL ROLE authenticated;
                  PERFORM set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
                  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
                  UPDATE public.vessels SET capacity = {new_vcap} WHERE slug = 'ves-escuna-corsario';
                  GET DIAGNOSTICS v_rows = ROW_COUNT;
                  IF v_rows <> 1 THEN
                    RAISE EXCEPTION 'RLS_UPDATE_VESSEL_ZERO_ROWS: Parceiro autenticado não conseguiu atualizar public.vessels';
                  END IF;
                END $$;
                """
            else:
                op_type = "UPSERT_DELETE_AVAILABILITY_BLOCK"
                override_cap = 10 if op_idx == 18 else (50 if op_idx == 19 else 55)
                sql = f"""
                DO $$
                DECLARE v_blk JSONB;
                BEGIN
                  SET LOCAL ROLE authenticated;
                  PERFORM set_config('request.jwt.claim.sub', '{PARTNER_ESCUNA_USER}', true);
                  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
                  v_blk := public.upsert_availability_block(
                    'ves-escuna-corsario',
                    DATE '{l2_date}',
                    'AJUSTE_CAPACIDADE',
                    'Bloqueio concorrente L2 op {op_idx}',
                    {override_cap}::smallint,
                    'tour-escuna-anchieta'
                  );
                  IF {op_idx} = 20 THEN
                    PERFORM public.delete_availability_block((v_blk->>'id')::uuid);
                  END IF;
                END $$;
                """

            metrics = execute_prewarmed_psql_at_barrier(sql, barrier)
            rc = metrics["return_code"]
            err = metrics["stderr"]
            err_up = err.upper()

            if rc == 124 or "57014" in err_up or "TIMEOUT" in err_up:
                outcome = "TIMEOUT"
            elif "40P01" in err_up or "DEADLOCK" in err_up:
                outcome = "DEADLOCK"
            elif rc == 0:
                outcome = "SUCCESS"
            elif any(
                code in err_up
                for code in (
                    "CAPACITY_EXCEEDED",
                    "VESSEL_BLOCKED",
                    "TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS",
                    "VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS",
                    "TOUR_CAPACITY_EXCEEDS_VESSEL",
                    "CAPACITY_EXCEEDS_VESSEL",
                    "BLOCK_CONFLICTS_WITH_EXISTING_BOOKINGS",
                    "BLOCK_NOT_FOUND",
                )
            ):
                outcome = "EXPECTED_BUSINESS_GUARD_REJECTION"
            else:
                outcome = "UNEXPECTED_FAILURE"

            op_results[op_idx - 1] = {
                "op_id": op_idx,
                "op_type": op_type,
                "return_code": rc,
                "process_spawn_ms": metrics["process_spawn_ms"],
                "connection_ready_ms": metrics["connection_ready_ms"],
                "sql_exec_ms": metrics["sql_exec_ms"],
                "total_client_ms": metrics["total_client_ms"],
                "latency_ms": metrics["sql_exec_ms"],
                "classification": outcome,
                "error_excerpt": err[:160] if rc != 0 else "",
            }

        threads = [threading.Thread(target=worker_l2, args=(i,)) for i in range(1, total_ops + 1)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        valid_ops = [r for r in op_results if r is not None]

        verify_l2_sql = f"""
        SELECT jsonb_build_object(
          'avail', public.get_tour_availability('tour-escuna-anchieta', DATE '{l2_date}'),
          'tour_capacity', (SELECT capacity FROM public.tours WHERE slug = 'tour-escuna-anchieta'),
          'vessel_capacity', (SELECT capacity FROM public.vessels WHERE slug = 'ves-escuna-corsario'),
          'confirmed_seeds', (
            SELECT COUNT(*) FROM public.bookings
            WHERE id IN ('{seed_ids[0]}'::uuid, '{seed_ids[1]}'::uuid, '{seed_ids[2]}'::uuid)
              AND status = 'CONFIRMADA'
          ),
          'cancelled_seeds', (
            SELECT COUNT(*) FROM public.bookings
            WHERE id IN ('{seed_ids[3]}'::uuid, '{seed_ids[4]}'::uuid, '{seed_ids[5]}'::uuid)
              AND status = 'CANCELADA'
          ),
          'ledger_inconsistencies', (
            SELECT COUNT(*) FROM public.bookings b
            LEFT JOIN public.commission_ledger cl ON cl.booking_id = b.id
            WHERE b.booking_date = DATE '{l2_date}'
              AND (
                (b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA') AND COALESCE(cl.ledger_status::text, '') <> 'PREVISTA')
                OR (b.status = 'PASSEIO_REALIZADO' AND COALESCE(cl.ledger_status::text, '') NOT IN ('CONFIRMADA', 'PAGA'))
                OR (b.status IN ('CANCELADA', 'RECUSADA') AND COALESCE(cl.ledger_status::text, '') <> 'REVERTIDA')
                OR (b.status = 'EM_DISPUTA' AND COALESCE(cl.ledger_status::text, '') <> 'EM_DISPUTA')
              )
          ),
          'residual_tokens', (SELECT COUNT(*) FROM internal_guard.execution_tokens)
        )::text;
        """
        rc_v, out_v, _ = run_psql(verify_l2_sql)
        state_l2 = json.loads(out_v.splitlines()[-1]) if rc_v == 0 and out_v else {}
        avail_obj = state_l2.get("avail", {})
        occupied_seats = int(avail_obj.get("occupied_seats", 0))
        effective_capacity = int(avail_obj.get("effective_capacity", 0))
        tour_cap = int(state_l2.get("tour_capacity", 0))
        vessel_cap = int(state_l2.get("vessel_capacity", 0))

        deadlocks = sum(1 for r in valid_ops if r["classification"] == "DEADLOCK")
        timeouts = sum(1 for r in valid_ops if r["classification"] == "TIMEOUT")
        unexpected = sum(1 for r in valid_ops if r["classification"] == "UNEXPECTED_FAILURE")
        successes = sum(1 for r in valid_ops if r["classification"] == "SUCCESS")
        guard_rejections = sum(1 for r in valid_ops if r["classification"] == "EXPECTED_BUSINESS_GUARD_REJECTION")

        cap_or_block_successes = sum(
            1 for r in valid_ops if r["op_id"] >= 13 and r["classification"] == "SUCCESS"
        )

        passed = (
            len(valid_ops) == total_ops
            and deadlocks == 0
            and timeouts == 0
            and unexpected == 0
            and successes > 0
            and cap_or_block_successes > 0
            and occupied_seats <= effective_capacity
            and tour_cap <= vessel_cap
            and state_l2.get("confirmed_seeds") == 3
            and state_l2.get("cancelled_seeds") == 3
            and state_l2.get("ledger_inconsistencies") == 0
            and state_l2.get("residual_tokens") == 0
        )

        sql_latencies = [r["sql_exec_ms"] for r in valid_ops]
        client_latencies = [r["total_client_ms"] for r in valid_ops]

        return {
            "scenario": "L2",
            "passed": passed,
            "total_operations": total_ops,
            "classifications": {
                "SUCCESS": successes,
                "EXPECTED_BUSINESS_GUARD_REJECTION": guard_rejections,
                "DEADLOCK": deadlocks,
                "TIMEOUT": timeouts,
                "UNEXPECTED_FAILURE": unexpected,
            },
            "latency_ms": compute_latency_stats(sql_latencies),
            "timing_breakdown_ms": {
                "sql_exec_ms": compute_latency_stats(sql_latencies),
                "total_client_ms": compute_latency_stats(client_latencies),
            },
            "db_verification": {
                "occupied_seats": occupied_seats,
                "effective_capacity": effective_capacity,
                "tour_capacity": tour_cap,
                "vessel_capacity": vessel_cap,
                "confirmed_seeds": state_l2.get("confirmed_seeds"),
                "cancelled_seeds": state_l2.get("cancelled_seeds"),
                "cap_or_block_successes": cap_or_block_successes,
                "ledger_inconsistencies": state_l2.get("ledger_inconsistencies"),
                "residual_tokens": state_l2.get("residual_tokens"),
            },
            "individual_results": valid_ops,
        }
    finally:
        cleanup_bookings_and_blocks_via_rpcs([l2_date], tag)


def execute_scenario_l3(tag: str) -> Dict[str, Any]:
    l3_dates = ["2027-02-20", "2027-02-21"]
    cleanup_bookings_and_blocks_via_rpcs(l3_dates, tag)

    expired_ids: List[str] = []
    valid_ids: List[str] = []

    try:
        expired_specs = [
            ("tour-lancha-norte-comp", "2027-02-20", 4),
            ("tour-lancha-norte-comp", "2027-02-20", 4),
            ("tour-lancha-norte-comp", "2027-02-21", 4),
            ("tour-lancha-norte-comp", "2027-02-21", 4),
            ("tour-escuna-anchieta", "2027-02-20", 10),
            ("tour-escuna-anchieta", "2027-02-21", 10),
        ]
        for idx, (tslug, bdate, pax) in enumerate(expired_specs, start=1):
            sql = f"""
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT (public.create_booking_request(
              '{tslug}',
              DATE '{bdate}',
              {pax}::smallint,
              'SITE_DIRECT',
              'L3 Expirada {idx}',
              '(12) 99300-{idx:04d}',
              'l3.exp{idx}.{tag}@homolog.invalid',
              'load_l3',
              'expired_batch',
              'missao_02_2',
              'Reserva pendente vencida L3 #{idx}',
              'idem-l3-exp-{tag}-{idx}'
            )->>'id');
            """
            rc, out, err = run_psql(sql)
            if rc != 0 or not out:
                raise RuntimeError(f"Erro ao criar reserva expirada #{idx} em L3: {err}")
            bk_id = out.splitlines()[-1].strip()
            expired_ids.append(bk_id)

        exp_ids_sql = ", ".join(f"'{bid}'::uuid" for bid in expired_ids)
        age_sql = f"""
        DO $$
        DECLARE r RECORD;
        BEGIN
          PERFORM set_config('request.jwt.claim.sub', '', true);
          PERFORM set_config('request.jwt.claim.role', 'service_role', true);
          FOR r IN SELECT id, status FROM public.bookings WHERE id IN ({exp_ids_sql}) LOOP
            PERFORM internal_guard.issue_token('BOOKING_MUTATION', r.id, r.status::text);
            UPDATE public.bookings SET expires_at = now() - interval '3 hours' WHERE id = r.id;
            PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', r.id);
          END LOOP;
        END $$;
        """
        rc_age, _, err_age = run_psql(age_sql)
        if rc_age != 0:
            raise RuntimeError(f"Erro ao retroagir expires_at no cenário L3: {err_age}")

        valid_specs = [
            ("tour-lancha-norte-comp", "2027-02-20", 4),
            ("tour-lancha-norte-comp", "2027-02-21", 4),
            ("tour-escuna-anchieta", "2027-02-20", 8),
            ("tour-escuna-anchieta", "2027-02-21", 8),
        ]
        for idx, (tslug, bdate, pax) in enumerate(valid_specs, start=1):
            sql = f"""
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT (public.create_booking_request(
              '{tslug}',
              DATE '{bdate}',
              {pax}::smallint,
              'SITE_DIRECT',
              'L3 Valida {idx}',
              '(12) 99310-{idx:04d}',
              'l3.val{idx}.{tag}@homolog.invalid',
              'load_l3',
              'valid_batch',
              'missao_02_2',
              'Reserva pendente valida L3 #{idx}',
              'idem-l3-val-{tag}-{idx}'
            )->>'id');
            """
            rc, out, err = run_psql(sql)
            if rc != 0 or not out:
                raise RuntimeError(f"Erro ao criar reserva válida #{idx} em L3: {err}")
            valid_ids.append(out.splitlines()[-1].strip())

        val_ids_sql = ", ".join(f"'{bid}'::uuid" for bid in valid_ids)
        pre_check_sql = f"""
        SELECT jsonb_build_object(
          'expired_pending_before', (SELECT COUNT(*) FROM public.bookings WHERE id IN ({exp_ids_sql}) AND status = 'AGUARDANDO_CONFIRMACAO'),
          'valid_pending_before', (SELECT COUNT(*) FROM public.bookings WHERE id IN ({val_ids_sql}) AND status = 'AGUARDANDO_CONFIRMACAO'),
          'ledger_prevista_before', (SELECT COUNT(*) FROM public.commission_ledger WHERE booking_id IN ({exp_ids_sql}, {val_ids_sql}) AND ledger_status = 'PREVISTA')
        )::text;
        """
        _, out_pre, _ = run_psql(pre_check_sql)
        pre_state = json.loads(out_pre.splitlines()[-1])

        total_workers = 12
        barrier = threading.Barrier(total_workers)
        l3_results: List[Dict[str, Any]] = [None] * total_workers  # type: ignore

        def worker_l3(w_idx: int) -> None:
            if w_idx in (1, 2):
                w_type = "EXPIRE_STALE_BOOKINGS"
                sql = """
                SET LOCAL ROLE service_role;
                SELECT set_config('request.jwt.claim.sub', '', true);
                SELECT set_config('request.jwt.claim.role', 'service_role', true);
                SELECT public.expire_stale_bookings()::text;
                """
            else:
                w_type = "NEW_CONCURRENT_BOOKING"
                target_date = "2027-02-20" if (w_idx % 2 == 0) else "2027-02-21"
                target_tour = "tour-lancha-norte-comp" if w_idx <= 8 else "tour-escuna-anchieta"
                sql = f"""
                SET LOCAL ROLE anon;
                SELECT set_config('request.jwt.claim.sub', '', true);
                SELECT set_config('request.jwt.claim.role', 'anon', true);
                SELECT public.create_booking_request(
                  '{target_tour}',
                  DATE '{target_date}',
                  2::smallint,
                  'SITE_DIRECT',
                  'L3 Nova Concorrente {w_idx}',
                  '(12) 99320-{w_idx:04d}',
                  'l3.new{w_idx}.{tag}@homolog.invalid',
                  'load_l3',
                  'concurrent_new',
                  'missao_02_2',
                  'Nova reserva concorrente com expire_stale_bookings #{w_idx}',
                  'idem-l3-new-{tag}-{w_idx}'
                )::text;
                """
            metrics = execute_prewarmed_psql_at_barrier(sql, barrier)
            rc = metrics["return_code"]
            out = metrics["stdout"]
            err = metrics["stderr"]
            err_up = err.upper()

            if rc == 124 or "57014" in err_up or "TIMEOUT" in err_up:
                outcome = "TIMEOUT"
            elif "40P01" in err_up or "DEADLOCK" in err_up:
                outcome = "DEADLOCK"
            elif rc == 0:
                outcome = "SUCCESS"
            elif "CAPACITY_EXCEEDED" in err_up or "VESSEL_BLOCKED" in err_up:
                outcome = "EXPECTED_CAPACITY_CONFLICT"
            else:
                outcome = "UNEXPECTED_FAILURE"

            l3_results[w_idx - 1] = {
                "worker_id": w_idx,
                "worker_type": w_type,
                "return_code": rc,
                "process_spawn_ms": metrics["process_spawn_ms"],
                "connection_ready_ms": metrics["connection_ready_ms"],
                "sql_exec_ms": metrics["sql_exec_ms"],
                "total_client_ms": metrics["total_client_ms"],
                "latency_ms": metrics["sql_exec_ms"],
                "classification": outcome,
                "output_excerpt": out[:120] if rc == 0 else err[:160],
            }

        threads = [threading.Thread(target=worker_l3, args=(i,)) for i in range(1, total_workers + 1)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        valid_l3 = [r for r in l3_results if r is not None]

        reactivate_sql = f"""
        SET LOCAL ROLE authenticated;
        SELECT set_config('request.jwt.claim.sub', '{PARTNER_KAIMARES_USER}', true);
        SELECT set_config('request.jwt.claim.role', 'authenticated', true);
        SELECT public.transition_booking_status('{expired_ids[0]}', 'CONFIRMADA', 'Tentativa ilegal de reativar reserva expirada');
        """
        rc_re, _, err_re = run_psql(reactivate_sql)
        err_re_up = err_re.upper()
        expired_reactivation_blocked = (
            rc_re != 0
            and "INVALID_STATUS_TRANSITION" in err_re_up
            and "UNAUTHORIZED" not in err_re_up
        )

        post_check_sql = f"""
        SELECT jsonb_build_object(
          'expired_cancelled_after', (SELECT COUNT(*) FROM public.bookings WHERE id IN ({exp_ids_sql}) AND status = 'CANCELADA'),
          'expired_ledger_reverted_after', (SELECT COUNT(*) FROM public.commission_ledger WHERE booking_id IN ({exp_ids_sql}) AND ledger_status = 'REVERTIDA'),
          'expired_history_rows', (SELECT COUNT(*) FROM public.booking_status_history WHERE booking_id IN ({exp_ids_sql}) AND new_status = 'CANCELADA'),
          'valid_still_protected_after', (SELECT COUNT(*) FROM public.bookings WHERE id IN ({val_ids_sql}) AND status = 'AGUARDANDO_CONFIRMACAO'),
          'valid_ledger_prevista_after', (SELECT COUNT(*) FROM public.commission_ledger WHERE booking_id IN ({val_ids_sql}) AND ledger_status = 'PREVISTA'),
          'lancha_d1_occupied', COALESCE((public.get_tour_availability('tour-lancha-norte-comp', DATE '2027-02-20')->>'occupied_seats')::int, -1),
          'lancha_d2_occupied', COALESCE((public.get_tour_availability('tour-lancha-norte-comp', DATE '2027-02-21')->>'occupied_seats')::int, -1),
          'residual_tokens', (SELECT COUNT(*) FROM internal_guard.execution_tokens)
        )::text;
        """
        rc_post, out_post, _ = run_psql(post_check_sql)
        post_state = json.loads(out_post.splitlines()[-1]) if rc_post == 0 and out_post else {}

        deadlocks = sum(1 for r in valid_l3 if r["classification"] == "DEADLOCK")
        timeouts = sum(1 for r in valid_l3 if r["classification"] == "TIMEOUT")
        unexpected = sum(1 for r in valid_l3 if r["classification"] == "UNEXPECTED_FAILURE")
        new_booking_successes = sum(
            1 for r in valid_l3 if r["worker_type"] == "NEW_CONCURRENT_BOOKING" and r["classification"] == "SUCCESS"
        )

        passed = (
            len(valid_l3) == total_workers
            and pre_state.get("expired_pending_before") == 6
            and pre_state.get("valid_pending_before") == 4
            and pre_state.get("ledger_prevista_before") == 10
            and post_state.get("expired_cancelled_after") == 6
            and post_state.get("expired_ledger_reverted_after") == 6
            and post_state.get("expired_history_rows") == 6
            and post_state.get("valid_still_protected_after") == 4
            and post_state.get("valid_ledger_prevista_after") == 4
            and 0 < post_state.get("lancha_d1_occupied", 99) <= 12
            and 0 < post_state.get("lancha_d2_occupied", 99) <= 12
            and new_booking_successes > 0
            and expired_reactivation_blocked
            and deadlocks == 0
            and timeouts == 0
            and unexpected == 0
            and post_state.get("residual_tokens") == 0
        )

        sql_latencies = [r["sql_exec_ms"] for r in valid_l3]
        client_latencies = [r["total_client_ms"] for r in valid_l3]

        return {
            "scenario": "L3",
            "passed": passed,
            "expired_batch_size": 6,
            "valid_batch_size": 4,
            "concurrent_new_requests": 10,
            "expired_reactivation_blocked": expired_reactivation_blocked,
            "classifications": {
                "SUCCESS": sum(1 for r in valid_l3 if r["classification"] == "SUCCESS"),
                "EXPECTED_CAPACITY_CONFLICT": sum(
                    1 for r in valid_l3 if r["classification"] == "EXPECTED_CAPACITY_CONFLICT"
                ),
                "DEADLOCK": deadlocks,
                "TIMEOUT": timeouts,
                "UNEXPECTED_FAILURE": unexpected,
            },
            "latency_ms": compute_latency_stats(sql_latencies),
            "timing_breakdown_ms": {
                "sql_exec_ms": compute_latency_stats(sql_latencies),
                "total_client_ms": compute_latency_stats(client_latencies),
            },
            "pre_state": pre_state,
            "post_state": post_state,
            "individual_results": valid_l3,
        }
    finally:
        cleanup_bookings_and_blocks_via_rpcs(l3_dates, tag)


def main() -> int:
    if not shutil.which("psql") or not DATABASE_URL:
        pending_report = {
            "mission": "02.2",
            "status": "PENDING_POSTGRESQL_15_RUNTIME",
            "reason": "Cliente psql ou DATABASE_URL ausente neste ambiente. Nenhuma métrica de runtime foi simulada.",
            "scenarios": {
                "L1": {"status": "PENDING", "concurrent_requests": 50},
                "L2": {"status": "PENDING", "concurrent_operations": 20},
                "L3": {"status": "PENDING", "expired_batch_size": 6, "valid_batch_size": 4},
            },
        }
        REPORT_JSON_PATH.write_text(json.dumps(pending_report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(
            "[CENÁRIOS DE CARGA L1, L2 E L3: PENDING — AMBIENTE POSTGRESQL 15+ NÃO DISPONÍVEL]\n"
            "Nenhuma métrica foi inventada ou simulada. Para executar em instância PostgreSQL 15+ descartável:\n"
            "  bash supabase/tests/run_postgresql_homologation.sh --docker"
        )
        return 2

    verify_safe_disposable_database()
    ensure_load_test_partner_users()
    tag = uuid.uuid4().hex[:6]
    print(f"=== INICIANDO SUÍTE REAL DE CARGA E ESTABILIDADE L1, L2 E L3 (RUN={tag}) ===")

    l1_report = execute_scenario_l1(tag)
    print(
        f"[{'PASS' if l1_report['passed'] else 'FAIL'}] [L1] "
        f"50 reqs concorrentes -> SUCCESS={l1_report['classifications']['SUCCESS']}, "
        f"CONFLICT={l1_report['classifications']['EXPECTED_CAPACITY_CONFLICT']}, "
        f"DEADLOCK={l1_report['classifications']['DEADLOCK']}, "
        f"UNEXPECTED={l1_report['classifications']['UNEXPECTED_FAILURE']} | "
        f"SQL Latência (ms): min={l1_report['latency_ms']['min_ms']}, avg={l1_report['latency_ms']['avg_ms']}, "
        f"P95={l1_report['latency_ms']['p95_ms']}, P99={l1_report['latency_ms']['p99_ms']}, max={l1_report['latency_ms']['max_ms']}"
    )

    l2_report = execute_scenario_l2(tag)
    print(
        f"[{'PASS' if l2_report['passed'] else 'FAIL'}] [L2] "
        f"20 ops cruzadas -> SUCCESS={l2_report['classifications']['SUCCESS']}, "
        f"GUARD_REJECT={l2_report['classifications']['EXPECTED_BUSINESS_GUARD_REJECTION']}, "
        f"DEADLOCK={l2_report['classifications']['DEADLOCK']}, "
        f"UNEXPECTED={l2_report['classifications']['UNEXPECTED_FAILURE']} | "
        f"SQL Latência (ms): min={l2_report['latency_ms']['min_ms']}, avg={l2_report['latency_ms']['avg_ms']}, "
        f"P95={l2_report['latency_ms']['p95_ms']}, P99={l2_report['latency_ms']['p99_ms']}, max={l2_report['latency_ms']['max_ms']}"
    )

    l3_report = execute_scenario_l3(tag)
    print(
        f"[{'PASS' if l3_report['passed'] else 'FAIL'}] [L3] "
        f"Expiração em lote (6 expiradas + 4 válidas + 10 novas) -> "
        f"Expiradas canceladas={l3_report['post_state'].get('expired_cancelled_after')}/6, "
        f"Válidas protegidas={l3_report['post_state'].get('valid_still_protected_after')}/4, "
        f"Reativação bloqueada={l3_report['expired_reactivation_blocked']}, "
        f"DEADLOCK={l3_report['classifications']['DEADLOCK']}"
    )

    all_passed = l1_report["passed"] and l2_report["passed"] and l3_report["passed"]
    full_report = {
        "mission": "02.2",
        "run_tag": tag,
        "status": "PASS" if all_passed else "FAIL",
        "scenarios": {
            "L1": l1_report,
            "L2": l2_report,
            "L3": l3_report,
        },
    }
    REPORT_JSON_PATH.write_text(json.dumps(full_report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
