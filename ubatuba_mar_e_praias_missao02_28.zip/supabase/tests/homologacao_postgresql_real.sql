-- ============================================================================
-- UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 01
-- SUÍTE DE HOMOLOGAÇÃO EM INSTÂNCIA POSTGRESQL REAL (SEÇÕES 2 E 3 DA REAUDITORIA)
-- Arquivo: supabase/tests/homologacao_postgresql_real.sql
-- Compatibilidade: PostgreSQL 14 / 15 / 16 / 17 & Supabase Local (supabase start)
-- Como executar:
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/homologacao_postgresql_real.sql
-- ============================================================================

\set ON_ERROR_STOP on

BEGIN;

-- Garante que os papéis padrão do Supabase existam caso executado em PostgreSQL puro (fora do container Supabase)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    CREATE ROLE anon NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    CREATE ROLE service_role NOLOGIN BYPASSRLS;
  END IF;

  GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
  GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
  GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
  REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
    public.bookings,
    public.commission_ledger,
    public.booking_status_history,
    public.audit_logs,
    public.availability_blocks,
    public.reviews
  FROM PUBLIC, anon, authenticated;
  REVOKE DELETE, TRUNCATE ON public.profiles FROM PUBLIC, anon, authenticated;
  REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;

  REVOKE ALL ON SCHEMA internal_guard FROM PUBLIC, anon, authenticated;
  REVOKE ALL ON TABLE internal_guard.execution_tokens FROM PUBLIC, anon, authenticated;
  REVOKE ALL ON SEQUENCE internal_guard.execution_tokens_id_seq FROM PUBLIC, anon, authenticated;
  REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM PUBLIC, anon, authenticated;
  REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM PUBLIC, anon, authenticated;
  REVOKE ALL ON FUNCTION internal_guard.cleanup_tokens(TEXT, UUID) FROM PUBLIC, anon, authenticated;

  GRANT EXECUTE ON FUNCTION public.is_admin() TO anon, authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon, authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon, authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon, authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated, service_role;
  GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated, service_role;

  REVOKE ALL ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.delete_availability_block(UUID) FROM PUBLIC, anon;
  REVOKE ALL ON FUNCTION public.expire_stale_bookings() FROM PUBLIC, anon, authenticated;
  GRANT EXECUTE ON FUNCTION public.expire_stale_bookings() TO service_role;
  GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
END
$$;

DO $$
DECLARE
  v_pg_version TEXT;
  v_tourist_a UUID := 'aaaa1111-1111-4111-8111-111111111101';
  v_tourist_b UUID := 'aaaa1111-1111-4111-8111-111111111102';
  v_partner_a_user UUID := 'bbbb2222-2222-4222-8222-222222222201'; -- Kaimares
  v_partner_b_user UUID := 'bbbb2222-2222-4222-8222-222222222202'; -- Rota do Mar
  v_admin_user UUID := 'cccc3333-3333-4333-8333-333333333301';

  v_partner_kaimares UUID := '11111111-1111-4111-8111-111111111101';
  v_partner_rotadomar UUID := '11111111-1111-4111-8111-111111111102';

  v_profile_role public.app_role;
  v_profile_count INTEGER;
  v_res_bk1 JSONB;
  v_res_bk1_replay JSONB;
  v_res_bk2 JSONB;
  v_res_transition JSONB;
  v_res_avail JSONB;
  v_res_review JSONB;
  v_bk1_id UUID;
  v_bk2_id UUID;
  v_err_caught BOOLEAN;
  v_err_msg TEXT;
  v_count INTEGER;
BEGIN
  SELECT version() INTO v_pg_version;
  RAISE NOTICE '========================================================================';
  RAISE NOTICE 'HOMOLOGAÇÃO POSTGRESQL REAL — UBATUBA MAR & PRAIAS (MISSÃO 01)';
  RAISE NOTICE 'Versão do Servidor PostgreSQL: %', v_pg_version;
  RAISE NOTICE '========================================================================';

  -- ==========================================================================
  -- TESTE PG-05 (Seção 2.5) & SEG-03 (Seção 3.3):
  -- Criação automática de profiles via trigger on_auth_user_created + bloqueio de escalada no signup
  -- ==========================================================================
  INSERT INTO auth.users (id, email, email_confirmed_at, confirmed_at, raw_user_meta_data, raw_app_meta_data, created_at, updated_at)
  VALUES
    (
      v_tourist_a,
      'turista.a@ubatuba-homolog.com.br',
      now(),
      now(),
      '{"full_name": "Turista Alpha", "phone": "(11) 98888-1111", "role": "admin", "system_role": "admin"}'::jsonb,
      '{}'::jsonb,
      now(),
      now()
    ),
    (
      v_tourist_b,
      'turista.b@ubatuba-homolog.com.br',
      now(),
      now(),
      '{"full_name": "Turista Beta", "phone": "(11) 98888-2222"}'::jsonb,
      '{}'::jsonb,
      now(),
      now()
    ),
    (
      v_partner_a_user,
      'operador.kaimares@ubatuba-homolog.com.br',
      now(),
      now(),
      '{"full_name": "Operador Kaimares", "phone": "(12) 99776-6789"}'::jsonb,
      '{"system_role": "partner"}'::jsonb,
      now(),
      now()
    ),
    (
      v_partner_b_user,
      'operador.rotadomar@ubatuba-homolog.com.br',
      now(),
      now(),
      '{"full_name": "Operador Rota do Mar", "phone": "(12) 99176-6084"}'::jsonb,
      '{"system_role": "partner"}'::jsonb,
      now(),
      now()
    ),
    (
      v_admin_user,
      'admin.master@ubatuba-homolog.com.br',
      now(),
      now(),
      '{"full_name": "Admin Master Ubatuba", "phone": "(12) 99999-0000"}'::jsonb,
      '{"system_role": "admin"}'::jsonb,
      now(),
      now()
    );

  SELECT COUNT(*), MAX(system_role) INTO v_profile_count, v_profile_role
  FROM public.profiles
  WHERE id = v_tourist_a;

  IF v_profile_count <> 1 OR v_profile_role <> 'tourist' THEN
    RAISE EXCEPTION '[FAIL] PG-05: Falha na criação automática ou sanitização de role (count=%, role=%)', v_profile_count, v_profile_role;
  END IF;
  RAISE NOTICE '[PASS] PG-05: Trigger on_auth_user_created criou perfis automaticamente e bloqueou escalada no signup (system_role=tourist).';

  -- Vincula Parceiro A (Kaimares) e Parceiro B (Rota do Mar) em partner_members
  INSERT INTO public.partner_members (partner_id, user_id, member_role, is_active)
  VALUES
    (v_partner_kaimares, v_partner_a_user, 'owner', true),
    (v_partner_rotadomar, v_partner_b_user, 'owner', true)
  ON CONFLICT (partner_id, user_id) DO NOTHING;

  -- ==========================================================================
  -- TESTE PG-03 (Seção 2.3): Execução de todas as RPCs sob contexto do Turista A
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_res_avail := public.get_tour_availability('tour-lancha-norte-comp', DATE '2026-12-18');
  IF (v_res_avail->>'blocked')::boolean <> false OR (v_res_avail->>'remaining_seats')::integer <> 12 THEN
    RAISE EXCEPTION '[FAIL] PG-03a: get_tour_availability retornou resultado inesperado: %', v_res_avail;
  END IF;

  v_res_bk1 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2026-12-18',
    8::smallint,
    'WHATSAPP',
    'Turista Alpha',
    '(11) 98888-1111',
    'turista.a@ubatuba-homolog.com.br',
    'instagram_ads',
    'cpc',
    'verao_2026',
    'Reserva teste PG-03'
  );

  v_bk1_id := (v_res_bk1->>'id')::uuid;
  IF (v_res_bk1->>'status') <> 'SOLICITADA'
     OR (v_res_bk1->>'idempotent_replay')::boolean <> false
     OR (v_res_bk1->>'gross_amount')::numeric <> 1920.00
     OR (v_res_bk1->>'commission_amount')::numeric <> 288.00
     OR (v_res_bk1->>'net_partner_amount')::numeric <> 1632.00 THEN
    RAISE EXCEPTION '[FAIL] PG-03b: create_booking_request retornou dados incorretos: %', v_res_bk1;
  END IF;
  RAISE NOTICE '[PASS] PG-03: RPCs get_tour_availability e create_booking_request executadas com sucesso (Código=%).', v_res_bk1->>'code';

  -- ==========================================================================
  -- TESTE PG-11 (Seção 2.11) & SEG-06 (Seção 3.6):
  -- Idempotência de solicitação repetida (não duplica reserva nem consome vagas em dobro)
  -- ==========================================================================
  v_res_bk1_replay := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2026-12-18',
    8::smallint,
    'WHATSAPP',
    'Turista Alpha',
    '(11) 98888-1111',
    'turista.a@ubatuba-homolog.com.br',
    'instagram_ads',
    'cpc',
    'verao_2026',
    'Repetição idempotente'
  );

  v_res_avail := public.get_tour_availability('tour-lancha-norte-comp', DATE '2026-12-18');
  IF (v_res_bk1_replay->>'id')::uuid <> v_bk1_id
     OR (v_res_bk1_replay->>'idempotent_replay')::boolean <> true
     OR (v_res_avail->>'occupied_seats')::integer <> 8
     OR (v_res_avail->>'remaining_seats')::integer <> 4 THEN
    RAISE EXCEPTION '[FAIL] PG-11/SEG-06: Falha de idempotência! Replay=% Avail=%', v_res_bk1_replay, v_res_avail;
  END IF;
  RAISE NOTICE '[PASS] PG-11 & SEG-06: Repetição de requisição tratada com idempotência (ocupadas=8/12, disponíveis=4).';

  -- ==========================================================================
  -- TESTE PG-10 (Seção 2.10):
  -- Conflito entre passeios privativos e compartilhados na mesma embarcação (ves-phantom-340)
  -- ==========================================================================
  v_err_caught := false;
  BEGIN
    PERFORM public.create_booking_request(
      'tour-familia-prumirim', -- Passeio PRIVATIVO que usa a mesma embarcação ves-phantom-340
      DATE '2026-12-18',
      4::smallint,
      'SITE_DIRECT',
      'Turista Beta',
      '(11) 98888-2222',
      'turista.b@ubatuba-homolog.com.br'
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] PG-10: Passeio Privativo foi permitido em embarcação que já possui passeio Compartilhado ativo na data!';
  END IF;
  RAISE NOTICE '[PASS] PG-10: Conflito entre passeio Privativo e Compartilhado na mesma embarcação bloqueado (%).', v_err_msg;

  -- ==========================================================================
  -- TESTE SEG-01 (Seção 3.1):
  -- Turista tentando confirmar reserva própria ou de terceiros
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  BEGIN
    PERFORM public.transition_booking_status(v_bk1_id::text, 'CONFIRMADA', 'Tentativa de confirmação por Turista B');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-01a: Turista B conseguiu confirmar reserva de Turista A!';
  END IF;

  -- Turista B tentando cancelar reserva de Turista A
  v_err_caught := false;
  BEGIN
    PERFORM public.transition_booking_status(v_bk1_id::text, 'CANCELADA', 'Tentativa de cancelamento por Turista B');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-01b: Turista B conseguiu cancelar reserva de Turista A!';
  END IF;

  -- Turista A tentando auto-confirmar sua própria reserva
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.transition_booking_status(v_bk1_id::text, 'CONFIRMADA', 'Tentativa de auto-confirmação pelo próprio turista');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-01c: Turista A conseguiu auto-confirmar sua própria reserva!';
  END IF;
  RAISE NOTICE '[PASS] SEG-01: Turista impedido de confirmar reserva própria/terceiros e impedido de cancelar reserva de terceiros.';

  -- ==========================================================================
  -- TESTE SEG-02 (Seção 3.2):
  -- Parceiro B (Rota do Mar) tentando modificar reserva do Parceiro A (Kaimares)
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_partner_b_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  BEGIN
    PERFORM public.transition_booking_status(v_bk1_id::text, 'CONFIRMADA', 'Parceiro B tentando confirmar reserva do Parceiro A');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-02: Parceiro B conseguiu modificar reserva pertencente ao Parceiro A!';
  END IF;
  RAISE NOTICE '[PASS] SEG-02: Isolamento multi-tenant confirmado — Parceiro B bloqueado ao tentar modificar reserva do Parceiro A (%).', v_err_msg;

  -- ==========================================================================
  -- TESTE PG-08 (Seção 2.8) & SEG-03 (Seção 3.3):
  -- Usuário tentando alterar sua própria system_role para 'admin' em public.profiles
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  BEGIN
    UPDATE public.profiles SET system_role = 'admin' WHERE id = v_tourist_a;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] PG-08/SEG-03: Usuário conseguiu alterar sua própria system_role para admin!';
  END IF;

  -- Teste Missão 01.2 (Seção 1): Tentativa de bypass via SET LOCAL / set_config('app.internal_auth_sync', 'true') e 'app.current_actor_role' = 'admin'
  PERFORM set_config('app.internal_auth_sync', 'true', true);
  PERFORM set_config('app.current_actor_role', 'admin', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.profiles SET system_role = 'admin' WHERE id = v_tourist_a;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  PERFORM set_config('app.internal_auth_sync', 'false', true);
  PERFORM set_config('app.current_actor_role', '', true);

  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] VULN-M01.2-01: Usuário conseguiu escalar system_role para admin injetando app.internal_auth_sync=true!';
  END IF;
  RAISE NOTICE '[PASS] PG-08 & SEG-03 (incluindo proteção anti-bypass app.internal_auth_sync / app.current_actor_role): bloqueado (%).', v_err_msg;

  -- ==========================================================================
  -- TESTE PG-07 (Seção 2.7), SEG-05 (Seção 3.5) & SEG-07 (Seção 3.7):
  -- Tentativas de alteração direta de reservas, contorno das RPCs e adulteração financeira
  -- ==========================================================================
  -- 1. Tentativa de pular etapa (SOLICITADA -> PASSEIO_REALIZADO direto sem confirmar) pelo Parceiro A
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  v_err_caught := false;
  BEGIN
    UPDATE public.bookings SET status = 'PASSEIO_REALIZADO' WHERE id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] PG-07a: UPDATE direto pulando etapa SOLICITADA -> PASSEIO_REALIZADO não foi bloqueado!';
  END IF;

  -- 2. Tentativa de modificar valores financeiros diretamente em public.bookings
  v_err_caught := false;
  BEGIN
    UPDATE public.bookings SET commission_amount = 0.00, net_partner_amount = 1920.00 WHERE id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-07a: Modificação direta de commission_amount em public.bookings não foi bloqueada!';
  END IF;

  -- 3. Tentativa de modificar valores financeiros diretamente em public.commission_ledger
  v_err_caught := false;
  BEGIN
    UPDATE public.commission_ledger SET commission_amount = 0.00, net_partner_amount = 1920.00 WHERE booking_id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-07b: Modificação direta de commission_amount em public.commission_ledger não foi bloqueada!';
  END IF;

  -- 4. Tentativa de consolidar commission_ledger manualmente antes de PASSEIO_REALIZADO
  v_err_caught := false;
  BEGIN
    UPDATE public.commission_ledger SET ledger_status = 'CONFIRMADA' WHERE booking_id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] SEG-07c: Consolidação manual prematura de commission_ledger não foi bloqueada!';
  END IF;

  -- Teste Missão 01.2: Tentativa de burlar commission_ledger injetando app.internal_ledger_sync = 'true'
  PERFORM set_config('app.internal_ledger_sync', 'true', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.commission_ledger SET ledger_status = 'CONFIRMADA' WHERE booking_id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  PERFORM set_config('app.internal_ledger_sync', 'false', true);
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] VULN-M01.2-02: Injeção de app.internal_ledger_sync=true permitiu alterar ledger_status diretamente!';
  END IF;

  -- Teste Missão 01.2: Tentativa de auto-aprovação de parceiro/passeio sem Admin
  v_err_caught := false;
  BEGIN
    UPDATE public.partners SET verified = false, rating_avg = 5.00 WHERE id = v_partner_kaimares;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] VULN-M01.2-05: Parceiro conseguiu alterar colunas de moderação diretamente!';
  END IF;

  RAISE NOTICE '[PASS] PG-07, SEG-05 & SEG-07 (incluindo proteção anti-bypass app.internal_ledger_sync e moderação de catálogo): bloqueados.';

  -- ==========================================================================
  -- TESTE PG-06 (Seção 2.6) & SEG-04 (Seção 3.4):
  -- Políticas RLS com diferentes usuários/papéis e bloqueio de usuário anônimo a dados privados
  -- ==========================================================================
  SET LOCAL ROLE anon;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);

  SELECT COUNT(*) INTO v_count FROM public.bookings;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] SEG-04a: Papel anon conseguiu ler % linhas de public.bookings!', v_count;
  END IF;

  SELECT COUNT(*) INTO v_count FROM public.profiles;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] SEG-04b: Papel anon conseguiu ler % linhas de public.profiles!', v_count;
  END IF;

  SELECT COUNT(*) INTO v_count FROM public.commission_ledger;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] SEG-04c: Papel anon conseguiu ler % linhas de public.commission_ledger!', v_count;
  END IF;

  SELECT COUNT(*) INTO v_count FROM public.audit_logs;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] SEG-04d: Papel anon conseguiu ler % linhas de public.audit_logs!', v_count;
  END IF;

  -- Verifica que sob papel authenticated (Turista B), RLS oculta a reserva do Turista A
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  SELECT COUNT(*) INTO v_count FROM public.bookings WHERE id = v_bk1_id;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] PG-06a: Turista B conseguiu visualizar reserva do Turista A via SELECT RLS!';
  END IF;

  -- Verifica que Tentativa de UPDATE via REST (sob ROLE authenticated) em bookings é bloqueada pela RLS
  UPDATE public.bookings SET notes = 'Tentativa via REST' WHERE id = v_bk1_id;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] SEG-05: Papel authenticated conseguiu executar UPDATE direto na tabela bookings contornando a RPC!';
  END IF;

  RESET ROLE;
  RAISE NOTICE '[PASS] PG-06 & SEG-04: Políticas RLS isolam dados privados contra anon, turistas de terceiros e parceiros de terceiros.';

  -- ==========================================================================
  -- TESTE PG-04 (Seção 2.4) & PG-13 (Seção 2.13):
  -- Fluxo completo de triggers (SOLICITADA -> CONFIRMADA -> PASSEIO_REALIZADO) + Consistência do commission_ledger
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_res_transition := public.transition_booking_status(v_bk1_id::text, 'CONFIRMADA', 'Vagas confirmadas pela Kaimares');
  IF (v_res_transition->>'status') <> 'CONFIRMADA' OR (v_res_transition->>'ledger_status') <> 'PREVISTA' THEN
    RAISE EXCEPTION '[FAIL] PG-04a: Falha ao confirmar reserva pelo Parceiro A: %', v_res_transition;
  END IF;

  v_res_transition := public.transition_booking_status(v_bk1_id::text, 'PASSEIO_REALIZADO', 'Embarque e passeio realizados com sucesso');
  IF (v_res_transition->>'status') <> 'PASSEIO_REALIZADO'
     OR (v_res_transition->>'ledger_status') <> 'CONFIRMADA'
     OR (v_res_transition->>'commission_consolidated')::boolean <> true THEN
    RAISE EXCEPTION '[FAIL] PG-13a: Falha na consolidação do livro-razão após PASSEIO_REALIZADO: %', v_res_transition;
  END IF;

  -- Verifica histórico e auditoria gerados pelas triggers
  SELECT COUNT(*) INTO v_count FROM public.booking_status_history WHERE booking_id = v_bk1_id;
  IF v_count <> 3 THEN
    RAISE EXCEPTION '[FAIL] PG-04b: booking_status_history deveria ter 3 registros para a reserva, encontrado: %', v_count;
  END IF;

  -- Teste Missão 01.2: Confirmação duplicada (CONFIRMADA -> CONFIRMADA) ou reabertura de PASSEIO_REALIZADO -> CANCELADA bloqueadas
  v_err_caught := false;
  BEGIN
    PERFORM public.transition_booking_status(v_bk1_id::text, 'CANCELADA', 'Tentativa de cancelar após realizado');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.2-STATE: Estado terminal PASSEIO_REALIZADO permitiu transição para CANCELADA!';
  END IF;

  -- Teste Missão 01.2: Turista B tentando avaliar reserva concluída do Turista A
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_verified_review(v_bk1_id::text, 1::smallint, 'Tentativa de avaliação falsa por terceiro', 'Turista Beta', 'SP');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] VULN-M01.2-03: Turista B conseguiu publicar avaliação na reserva do Turista A!';
  END IF;

  -- Testa avaliação verificada legítima pelo titular (Turista A) e recálculo automático de notas pela trigger
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  v_res_review := public.create_verified_review(
    v_bk1_id::text,
    5::smallint,
    'Passeio impecável na Lancha Oceano Azul 340! Segurança e pontualidade nota 10.',
    'Turista Alpha',
    'São Paulo, SP'
  );
  IF (v_res_review->>'verified_booking_code') IS DISTINCT FROM (v_res_bk1->>'code') THEN
    RAISE EXCEPTION '[FAIL] PG-03c: create_verified_review falhou: %', v_res_review;
  END IF;
  RAISE NOTICE '[PASS] PG-04 & PG-13: Triggers de histórico, livro-razão (commission_ledger), auditoria e avaliação verificada comprovados.';

  -- ==========================================================================
  -- TESTE PG-12 (Seção 2.12):
  -- Rollback de operações financeiras (reversão em cancelamento + rollback atômico em falha de transação)
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  v_res_bk2 := public.create_booking_request(
    'tour-escuna-anchieta',
    DATE '2026-12-19',
    10::smallint,
    'SITE_DIRECT',
    'Turista Beta',
    '(11) 98888-2222',
    'turista.b@ubatuba-homolog.com.br'
  );
  v_bk2_id := (v_res_bk2->>'id')::uuid;

  -- Cancelamento pelo turista reverte commission_ledger para REVERTIDA com reversed_at preenchido
  v_res_transition := public.transition_booking_status(v_bk2_id::text, 'CANCELADA', 'Imprevisto familiar antes do embarque');
  IF (v_res_transition->>'ledger_status') <> 'REVERTIDA' THEN
    RAISE EXCEPTION '[FAIL] PG-12a: Cancelamento não reverteu commission_ledger para REVERTIDA: %', v_res_transition;
  END IF;

  -- Teste de SAVEPOINT / ROLLBACK transacional em falha financeira
  BEGIN
    v_res_bk2 := public.create_booking_request(
      'tour-lancha-privativa-sul',
      DATE '2026-12-21',
      6::smallint,
      'WHATSAPP',
      'Turista Rollback',
      '(11) 97777-3333',
      'rollback@ubatuba-homolog.com.br'
    );
    -- Força exceção dentro do sub-bloco transacional para comprovar rollback atômico de bookings + commission_ledger
    RAISE EXCEPTION 'FALHA_TRANSACIONAL_FORÇADA';
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;

  SELECT COUNT(*) INTO v_count FROM public.bookings WHERE customer_email = 'rollback@ubatuba-homolog.com.br';
  IF v_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] PG-12b: Reserva não sofreu rollback após falha transacional!';
  END IF;
  RAISE NOTICE '[PASS] PG-12: Rollback transacional e reversão financeira no livro-razão comprovados.';

  -- ==========================================================================
  -- TESTES DE REGRESSÃO MISSÃO 01.3 (AUDITORIAS CRÍTICAS A, D, E)
  -- ==========================================================================
  -- 1. Auditoria Crítica A: Tentativa de alterar is_active e email diretamente em profiles por turista
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.profiles SET is_active = false WHERE id = v_tourist_a;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-A1: Turista conseguiu alterar profiles.is_active diretamente!';
  END IF;

  v_err_caught := false;
  BEGIN
    UPDATE public.profiles SET email = 'hacked@ubatuba.com.br' WHERE id = v_tourist_a;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-A2: Turista conseguiu alterar profiles.email diretamente!';
  END IF;

  -- Fluxo legítimo do Supabase Auth (UPDATE em auth.users sincroniza public.profiles via trigger handle_updated_auth_user + PG_CONTEXT)
  UPDATE auth.users
  SET email = 'turista.a.novo@ubatuba-homolog.com.br',
      updated_at = now()
  WHERE id = v_tourist_a;

  SELECT COUNT(*) INTO v_count
  FROM public.profiles
  WHERE id = v_tourist_a AND email = 'turista.a.novo@ubatuba-homolog.com.br';
  IF v_count <> 1 THEN
    RAISE EXCEPTION '[FAIL] M01.3-A3: Sincronização legítima de e-mail via auth.users falhou!';
  END IF;
  RAISE NOTICE '[PASS] M01.3-A: Proteção de system_role/is_active/email/id e sincronização legítima de auth.users via PG_CONTEXT comprovadas.';

  -- 2. Auditoria Crítica D: UPDATE direto em public.bookings bloqueado mesmo para Admin (prevenção de Deadlock AB-BA),
  --    enquanto a RPC canônica public.admin_update_booking funciona normalmente
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.bookings SET notes = 'Tentativa de UPDATE direto fora da RPC' WHERE id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-D1: UPDATE direto em public.bookings fora das RPCs canônicas não foi bloqueado!';
  END IF;

  -- Cenário F: Tentativa de reduzir capacidade da embarcação abaixo dos 8 passageiros já ocupados em 2026-12-18
  v_err_caught := false;
  BEGIN
    UPDATE public.vessels SET capacity = 6 WHERE slug = 'ves-phantom-340';
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-D2: Redução de capacidade da embarcação abaixo das reservas ativas não foi bloqueada!';
  END IF;
  RAISE NOTICE '[PASS] M01.3-D: Bloqueio de UPDATE direto em bookings e proteção de capacidade reversa em vessels comprovados.';

  -- 3. Auditoria Crítica E: Liquidação de comissão via settle_commission_ledger, bloqueio de liquidação dupla e bloqueio de DELETE
  -- Parceiro tentando liquidar comissão como PAGA deve falhar
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.settle_commission_ledger(v_bk1_id::text, 'Tentativa de auto-liquidação pelo parceiro');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-E1: Parceiro conseguiu liquidar comissão sem ser Admin!';
  END IF;

  -- Admin liquidando comissão CONFIRMADA -> PAGA deve suceder
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  v_res_transition := public.settle_commission_ledger(v_bk1_id::text, 'Repasse PIX confirmado pelo Admin');
  IF (v_res_transition->>'ledger_status') <> 'PAGA' THEN
    RAISE EXCEPTION '[FAIL] M01.3-E2: Admin não conseguiu liquidar comissão via settle_commission_ledger: %', v_res_transition;
  END IF;

  -- Tentativa de liquidar duas vezes a mesma comissão deve falhar com LEDGER_ALREADY_PAID
  v_err_caught := false;
  BEGIN
    PERFORM public.settle_commission_ledger(v_bk1_id::text, 'Segunda liquidação duplicada');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-E3: Segunda liquidação duplicada não foi bloqueada!';
  END IF;

  -- Tentativa de DELETE em commission_ledger ou bookings deve falhar com IMMUTABLE_RECORD_DELETE_FORBIDDEN
  v_err_caught := false;
  BEGIN
    DELETE FROM public.commission_ledger WHERE booking_id = v_bk1_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] M01.3-E4: Exclusão de linha em commission_ledger não foi bloqueada!';
  END IF;
  RAISE NOTICE '[PASS] M01.3-E: Integridade de liquidação única e imutabilidade contra DELETE em commission_ledger comprovadas.';

  RAISE NOTICE '========================================================================';
  RAISE NOTICE 'RESULTADO: TODOS OS TESTES SQL E DE SEGURANÇA APROVADOS NO POSTGRESQL!';
  RAISE NOTICE '========================================================================';
END
$$;


-- ============================================================================
-- BLOCO 8 — TESTES DE HOMOLOGAÇÃO DAS MIGRATIONS 000005, 000006 E 000007 (T8.1 A T8.15)
-- ============================================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'homolog_trigger_probe') THEN
    CREATE ROLE homolog_trigger_probe NOLOGIN;
  END IF;
  GRANT USAGE ON SCHEMA public TO homolog_trigger_probe;
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.availability_blocks TO homolog_trigger_probe;
  GRANT SELECT ON TABLE public.vessels, public.tours, public.partners, public.profiles, public.partner_members, public.bookings TO homolog_trigger_probe;
  GRANT EXECUTE ON FUNCTION public.is_admin() TO homolog_trigger_probe;
  GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO homolog_trigger_probe;
END
$$;

DO $$
DECLARE
  v_tourist_a UUID := 'aaaa1111-1111-4111-8111-111111111101';
  v_tourist_b UUID := 'aaaa1111-1111-4111-8111-111111111102';
  v_tourist_unconfirmed UUID := 'aaaa1111-1111-4111-8111-111111111109';
  v_partner_a_user UUID := 'bbbb2222-2222-4222-8222-222222222201'; -- Kaimares
  v_partner_b_user UUID := 'bbbb2222-2222-4222-8222-222222222202'; -- Rota do Mar
  v_admin_user UUID := 'cccc3333-3333-4333-8333-333333333301';
  v_block_res JSONB;
  v_block_res_2 JSONB;
  v_del_res JSONB;
  v_block_id UUID;
  v_srv_block_res JSONB;
  v_anon_bk JSONB;
  v_anon_bk_id UUID;
  v_exp_bk JSONB;
  v_exp_bk_id UUID;
  v_unconf_bk JSONB;
  v_unconf_bk_id UUID;
  v_idem_bk_1 JSONB;
  v_idem_bk_2 JSONB;
  v_idem_bk_after_cancel JSONB;
  v_lgpd_res JSONB;
  v_lgpd_replay JSONB;
  v_err_caught BOOLEAN;
  v_err_msg TEXT;
  v_err_state TEXT;
  v_token_count INTEGER;
  v_bool_res BOOLEAN;
BEGIN
  RAISE NOTICE '------------------------------------------------------------------------';
  RAISE NOTICE 'INICIANDO BLOCO 8 (MISSÃO 01.8 — T8.1 A T8.15)';
  RAISE NOTICE '------------------------------------------------------------------------';

  -- T8.1: Acesso direto a internal_guard.execution_tokens e funções internas bloqueado para anon/authenticated
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  BEGIN
    PERFORM 1 FROM internal_guard.execution_tokens LIMIT 1;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T8.1a: Papel authenticated conseguiu ler internal_guard.execution_tokens!';
  END IF;

  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', gen_random_uuid(), 'CONFIRMADA');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T8.1b: Papel authenticated conseguiu chamar internal_guard.issue_token()!';
  END IF;
  RESET ROLE;
  RAISE NOTICE '[PASS] T8.1: Acesso direto a internal_guard.execution_tokens e issue_token() bloqueado para anon/authenticated.';

  -- T8.2: Spoofing de PG_CONTEXT ou emissão de token em profundidade incorreta (trigger_depth != pg_trigger_depth() - 1) rejeitado
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', '00000000-0000-0000-0000-000000000099'::uuid, 'CONFIRMADA');
  v_bool_res := internal_guard.consume_token('BOOKING_MUTATION', '00000000-0000-0000-0000-000000000099'::uuid, 'CONFIRMADA');
  IF v_bool_res IS TRUE THEN
    RAISE EXCEPTION '[FAIL] T8.2a: consume_token aceitou token consumido na mesma profundidade (trigger_depth != pg_trigger_depth() - 1)!';
  END IF;
  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', '00000000-0000-0000-0000-000000000099'::uuid);
  RAISE NOTICE '[PASS] T8.2: Validação estrita de trigger_depth e bloqueio de spoofing de PG_CONTEXT comprovados.';

  -- T8.3: Upsert de bloqueio via RPC upsert_availability_block sob SET LOCAL ROLE authenticated (M01.7-001)
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_block_res := public.upsert_availability_block(
    'ves-phantom-340',
    DATE '2026-12-24',
    'MANUTENCAO',
    'Manutenção preventiva de Natal',
    NULL,
    NULL
  );
  v_block_id := (v_block_res->>'id')::uuid;
  IF v_block_id IS NULL THEN
    RAISE EXCEPTION '[FAIL] T8.3a: upsert_availability_block não retornou ID válido sob ROLE authenticated.';
  END IF;

  v_block_res_2 := public.upsert_availability_block(
    'ves-phantom-340',
    DATE '2026-12-24',
    'MANUTENCAO',
    'Manutenção preventiva de Natal (Atualizada)',
    NULL,
    NULL
  );
  IF (v_block_res_2->>'id')::uuid IS DISTINCT FROM v_block_id
     OR (v_block_res_2->>'reason') <> 'Manutenção preventiva de Natal (Atualizada)' THEN
    RAISE EXCEPTION '[FAIL] T8.3b: upsert_availability_block não manteve idempotência sobre (vessel_id, block_date, block_type, tour_id IS NULL)!';
  END IF;
  RAISE NOTICE '[PASS] T8.3: Upsert de bloqueio de agenda e idempotência na chave lógica comprovados sob SET LOCAL ROLE authenticated.';

  -- T8.4 (M01.7-001): Separação explícita entre Teste A (ACL real sob ROLE authenticated) e Teste B (Proteção por trigger)
  -- Teste A (T8.4A — ACL real sob SET LOCAL ROLE authenticated): verifica SQLSTATE 42501 por revogação de privilégios na tabela
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  v_err_state := '';
  BEGIN
    INSERT INTO public.availability_blocks (partner_id, vessel_id, block_date, block_type, reason)
    VALUES ('11111111-1111-4111-8111-111111111101', '33333333-3333-4333-8333-333333333301', DATE '2026-12-26', 'MANUTENCAO', 'Insert direto sob role authenticated');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_state := SQLSTATE;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_state <> '42501' THEN
    RAISE EXCEPTION '[FAIL] T8.4A-1: INSERT direto sob ROLE authenticated não foi bloqueado com SQLSTATE 42501 (state=%, msg=%).', v_err_state, v_err_msg;
  END IF;

  v_err_caught := false;
  v_err_state := '';
  BEGIN
    UPDATE public.availability_blocks SET reason = 'Update direto sob role authenticated' WHERE id = v_block_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_state := SQLSTATE;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_state <> '42501' THEN
    RAISE EXCEPTION '[FAIL] T8.4A-2: UPDATE direto sob ROLE authenticated não foi bloqueado com SQLSTATE 42501 (state=%, msg=%).', v_err_state, v_err_msg;
  END IF;

  v_err_caught := false;
  v_err_state := '';
  BEGIN
    DELETE FROM public.availability_blocks WHERE id = v_block_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_state := SQLSTATE;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_state <> '42501' THEN
    RAISE EXCEPTION '[FAIL] T8.4A-3: DELETE direto sob ROLE authenticated não foi bloqueado com SQLSTATE 42501 (state=%, msg=%).', v_err_state, v_err_msg;
  END IF;

  -- Teste B (T8.4B — Proteção por trigger sob papel controlado homolog_trigger_probe):
  RESET ROLE;
  CREATE POLICY "availability_blocks_probe_all" ON public.availability_blocks
    FOR ALL TO homolog_trigger_probe USING (true) WITH CHECK (true);

  SET LOCAL ROLE homolog_trigger_probe;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  BEGIN
    INSERT INTO public.availability_blocks (partner_id, vessel_id, block_date, block_type, reason)
    VALUES ('11111111-1111-4111-8111-111111111101', '33333333-3333-4333-8333-333333333301', DATE '2026-12-26', 'MANUTENCAO', 'Insert direto proibido por trigger');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%DIRECT_AVAILABILITY_BLOCK_INSERT_FORBIDDEN%' THEN
    RAISE EXCEPTION '[FAIL] T8.4B-1: Trigger BEFORE INSERT não lançou DIRECT_AVAILABILITY_BLOCK_INSERT_FORBIDDEN (msg=%).', v_err_msg;
  END IF;

  v_err_caught := false;
  BEGIN
    UPDATE public.availability_blocks SET reason = 'Update direto proibido por trigger' WHERE id = v_block_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%DIRECT_AVAILABILITY_BLOCK_UPDATE_FORBIDDEN%' THEN
    RAISE EXCEPTION '[FAIL] T8.4B-2: Trigger BEFORE UPDATE não lançou DIRECT_AVAILABILITY_BLOCK_UPDATE_FORBIDDEN (msg=%).', v_err_msg;
  END IF;

  v_err_caught := false;
  BEGIN
    DELETE FROM public.availability_blocks WHERE id = v_block_id;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%DIRECT_AVAILABILITY_BLOCK_DELETE_FORBIDDEN%' THEN
    RAISE EXCEPTION '[FAIL] T8.4B-3: Trigger BEFORE DELETE não lançou DIRECT_AVAILABILITY_BLOCK_DELETE_FORBIDDEN (msg=%).', v_err_msg;
  END IF;

  RESET ROLE;
  DROP POLICY "availability_blocks_probe_all" ON public.availability_blocks;
  REVOKE ALL ON TABLE public.availability_blocks FROM homolog_trigger_probe;
  REVOKE ALL ON TABLE public.vessels, public.tours, public.partners, public.profiles, public.partner_members, public.bookings FROM homolog_trigger_probe;
  REVOKE ALL ON FUNCTION public.is_admin() FROM homolog_trigger_probe;
  REVOKE ALL ON FUNCTION public.is_partner_member(UUID) FROM homolog_trigger_probe;
  REVOKE ALL ON SCHEMA public FROM homolog_trigger_probe;
  DROP ROLE homolog_trigger_probe;
  RAISE NOTICE '[PASS] T8.4: Teste A (ACL real SQLSTATE 42501 sob ROLE authenticated) e Teste B (Triggers DIRECT_AVAILABILITY_BLOCK_*_FORBIDDEN) aprovados.';

  -- T8.5: Bloqueio total rejeitado quando existe reserva AGUARDANDO_CONFIRMACAO ativa incompatível na data (M01.5-08)
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2026-12-27',
    4::smallint,
    'SITE_DIRECT',
    'Turista Beta Pendente',
    '(11) 98888-2222',
    'turista.b@ubatuba-homolog.com.br',
    'direct_organic',
    NULL,
    'verao_2026',
    'Reserva em AGUARDANDO_CONFIRMACAO para teste T8.5'
  );

  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.upsert_availability_block(
      'ves-phantom-340',
      DATE '2026-12-27',
      'BLOQUEIO_TOTAL',
      'Tentativa de bloqueio sobre reserva pendente ativa',
      NULL,
      NULL
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%BLOCK_CONFLICTS_WITH_CONFIRMED_BOOKINGS%' THEN
    RAISE EXCEPTION '[FAIL] T8.5: Bloqueio total permitido em data com reserva AGUARDANDO_CONFIRMACAO ativa (msg=%).', v_err_msg;
  END IF;
  RAISE NOTICE '[PASS] T8.5: Bloqueio total rejeitado quando existe reserva AGUARDANDO_CONFIRMACAO ativa na data.';

  -- T8.6: Exclusão legítima via delete_availability_block, rejeição na 2ª tentativa e 0 tokens residuais
  v_del_res := public.delete_availability_block(v_block_id);
  IF (v_del_res->>'deleted')::boolean IS DISTINCT FROM true THEN
    RAISE EXCEPTION '[FAIL] T8.6a: delete_availability_block não confirmou exclusão: %', v_del_res;
  END IF;

  v_err_caught := false;
  BEGIN
    PERFORM public.delete_availability_block(v_block_id);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%BLOCK_NOT_FOUND%' THEN
    RAISE EXCEPTION '[FAIL] T8.6b: Segunda chamada a delete_availability_block para registro já excluído não lançou BLOCK_NOT_FOUND!';
  END IF;

  RESET ROLE;
  SELECT COUNT(*)::integer INTO v_token_count
  FROM internal_guard.execution_tokens
  WHERE txid = txid_current();
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T8.6c: Encontrados % tokens órfãos residuais em internal_guard.execution_tokens!', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T8.6: Exclusão via RPC, rejeição de repetição (BLOCK_NOT_FOUND) e 0 tokens órfãos residuais comprovados.';

  -- T8.7: Liquidação direta em commission_ledger fora da RPC settle_commission_ledger rejeitada (LEDGER_DIRECT_SETTLE_FORBIDDEN)
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.commission_ledger SET ledger_status = 'PAGA' WHERE ledger_status <> 'PAGA';
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T8.7: UPDATE direto em commission_ledger fora de settle_commission_ledger não foi bloqueado!';
  END IF;
  RAISE NOTICE '[PASS] T8.7: Liquidação direta em commission_ledger rejeitada com sucesso.';

  -- T8.8: Sequestro de avaliação verificada em reserva anônima (tourist_user_id IS NULL) rejeitado (M01.5-06)
  SET LOCAL ROLE anon;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);
  v_anon_bk := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2026-12-29',
    2::smallint,
    'WHATSAPP',
    'Visitante Sem Login',
    '(11) 97777-9999',
    'anonimo@visitante.com.br',
    'direct_organic',
    NULL,
    'verao_2026',
    'Reserva anônima para teste T8.8'
  );
  v_anon_bk_id := (v_anon_bk->>'id')::uuid;

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM public.transition_booking_status(v_anon_bk_id::text, 'CONFIRMADA', 'Confirmada');
  PERFORM public.transition_booking_status(v_anon_bk_id::text, 'PASSEIO_REALIZADO', 'Realizada');

  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_verified_review((v_anon_bk->>'code'), 1::smallint, 'Tentativa de sequestro de reserva anônima', 'Hacker', 'SP');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%REVIEW_ANONYMOUS_BOOKING_UNVERIFIED%' THEN
    RAISE EXCEPTION '[FAIL] T8.8: Usuário autenticado conseguiu avaliar reserva anônima de terceiro (msg=%).', v_err_msg;
  END IF;
  RAISE NOTICE '[PASS] T8.8: Sequestro de avaliação em reserva anônima (tourist_user_id IS NULL) rejeitado com REVIEW_ANONYMOUS_BOOKING_UNVERIFIED.';

  -- T8.9: Redução de capacidade permitida quando a única reserva pendente que excedia o novo limite está expirada (M01.5-07)
  SET LOCAL ROLE anon;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);
  v_exp_bk := public.create_booking_request(
    'tour-escuna-anchieta',
    DATE '2026-12-30',
    60::smallint,
    'SITE_DIRECT',
    'Grupo Expirado 60 Pax',
    '(11) 96666-5555',
    'expirado@visitante.com.br',
    'direct_organic',
    NULL,
    'verao_2026',
    'Reserva que irá expirar'
  );
  v_exp_bk_id := (v_exp_bk->>'id')::uuid;

  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);
  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_exp_bk_id, 'AGUARDANDO_CONFIRMACAO');
  UPDATE public.bookings SET expires_at = now() - interval '2 hours' WHERE id = v_exp_bk_id;
  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_exp_bk_id);

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_b_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  UPDATE public.tours SET capacity = 50 WHERE slug = 'tour-escuna-anchieta';
  UPDATE public.vessels SET capacity = 50 WHERE slug = 'ves-escuna-corsario';
  UPDATE public.vessels SET capacity = 65 WHERE slug = 'ves-escuna-corsario';
  UPDATE public.tours SET capacity = 65 WHERE slug = 'tour-escuna-anchieta';
  RAISE NOTICE '[PASS] T8.9: Reserva pendente expirada não bloqueou indevidamente a redução legítima de capacidade sob ROLE authenticated.';

  -- T8.10: public.is_admin() e public.is_partner_member(UUID) retornam false constante para anon sem vazamento de metadados (M01.5-12)
  SET LOCAL ROLE anon;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);
  IF public.is_admin() IS DISTINCT FROM false
     OR public.is_partner_member('11111111-1111-4111-8111-111111111101'::uuid) IS DISTINCT FROM false THEN
    RAISE EXCEPTION '[FAIL] T8.10: is_admin() ou is_partner_member() não retornou false constante para o papel anon!';
  END IF;
  RAISE NOTICE '[PASS] T8.10: public.is_admin() e public.is_partner_member() retornaram false constante para anon.';

  -- T8.11 (M01.7-002 — P0): Proteção contra redução ilegal de public.tours.capacity abaixo de reservas ativas e desativação de passeio com reservas ativas
  -- Em 2026-12-18 (PG-04), tour-lancha-norte-comp possui 8 passageiros em PASSEIO_REALIZADO e em 2026-12-27 (T8.5) possui 4 passageiros em AGUARDANDO_CONFIRMACAO.
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  -- 1) Tentativa inválida de reduzir tours.capacity para 6 (abaixo dos 8 passageiros comprometidos em 2026-12-18)
  v_err_caught := false;
  BEGIN
    UPDATE public.tours SET capacity = 6 WHERE slug = 'tour-lancha-norte-comp';
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS%' THEN
    RAISE EXCEPTION '[FAIL] T8.11a: Redução ilegal de tours.capacity abaixo de reservas ativas não foi bloqueada (msg=%).', v_err_msg;
  END IF;

  -- 2) Tentativa inválida de suspender/desativar passeio com reserva ativa (2026-12-27 tem 4 pax em AGUARDANDO_CONFIRMACAO)
  v_err_caught := false;
  BEGIN
    UPDATE public.tours SET status = 'SUSPENSO' WHERE slug = 'tour-lancha-norte-comp';
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%TOUR_HAS_ACTIVE_BOOKINGS%' THEN
    RAISE EXCEPTION '[FAIL] T8.11b: Suspensão de passeio com reservas ativas não foi bloqueada (msg=%).', v_err_msg;
  END IF;

  -- 3) Redução válida de tours.capacity de 12 para 10 (acima do máximo ocupado de 8 pax) e restauração para 12
  UPDATE public.tours SET capacity = 10 WHERE slug = 'tour-lancha-norte-comp';
  UPDATE public.tours SET capacity = 12 WHERE slug = 'tour-lancha-norte-comp';
  RAISE NOTICE '[PASS] T8.11 (M01.7-002): Proteção de capacidade reversa e de reservas ativas em public.tours comprovada.';

  -- T8.12 (M01.7-003 — P1): Confirmação estrita de e-mail via auth.users.email_confirmed_at em create_verified_review() e validate_verified_review()
  RESET ROLE;
  INSERT INTO auth.users (id, email, email_confirmed_at, confirmed_at, raw_user_meta_data, raw_app_meta_data, created_at, updated_at)
  VALUES (
    v_tourist_unconfirmed,
    'nao.confirmado@ubatuba-homolog.com.br',
    NULL,
    NULL,
    '{"full_name": "Turista Sem Confirmacao", "phone": "(11) 95555-4444", "email_verified": true}'::jsonb,
    '{}'::jsonb,
    now(),
    now()
  );

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_unconfirmed::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_unconf_bk := public.create_booking_request(
    'tour-escuna-anchieta',
    DATE '2026-12-31',
    2::smallint,
    'SITE_DIRECT',
    'Turista Sem Confirmacao',
    '(11) 95555-4444',
    'nao.confirmado@ubatuba-homolog.com.br'
  );
  v_unconf_bk_id := (v_unconf_bk->>'id')::uuid;

  PERFORM set_config('request.jwt.claim.sub', v_partner_b_user::text, true);
  PERFORM public.transition_booking_status(v_unconf_bk_id::text, 'CONFIRMADA', 'Confirmada');
  PERFORM public.transition_booking_status(v_unconf_bk_id::text, 'PASSEIO_REALIZADO', 'Concluída');

  -- 1) E-mail não confirmado (email_confirmed_at IS NULL, mesmo com raw_user_meta_data.email_verified = true) deve ser REJEITADO
  PERFORM set_config('request.jwt.claim.sub', v_tourist_unconfirmed::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_verified_review(v_unconf_bk_id::text, 5::smallint, 'Tentativa sem confirmar email no GoTrue', 'Turista', 'SP');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%REVIEW_UNVERIFIED_EMAIL%' THEN
    RAISE EXCEPTION '[FAIL] T8.12a: Usuário com email_confirmed_at IS NULL conseguiu publicar avaliação (msg=%).', v_err_msg;
  END IF;

  -- 2) Metadado explicitamente falso (email_verified = false) mesmo com email_confirmed_at preenchido deve ser REJEITADO
  RESET ROLE;
  UPDATE auth.users
  SET email_confirmed_at = now(),
      raw_app_meta_data = '{"email_verified": false}'::jsonb
  WHERE id = v_tourist_unconfirmed;

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_unconfirmed::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_verified_review(v_unconf_bk_id::text, 5::smallint, 'Tentativa com email_verified false', 'Turista', 'SP');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%REVIEW_UNVERIFIED_EMAIL%' THEN
    RAISE EXCEPTION '[FAIL] T8.12b: Usuário com email_verified=false conseguiu publicar avaliação (msg=%).', v_err_msg;
  END IF;

  -- 3) Perfil inativo (is_active = false) deve ser REJEITADO com REVIEW_INACTIVE_PROFILE
  RESET ROLE;
  UPDATE auth.users SET raw_app_meta_data = '{}'::jsonb WHERE id = v_tourist_unconfirmed;
  UPDATE public.profiles SET is_active = false WHERE id = v_tourist_unconfirmed;

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_unconfirmed::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_verified_review(v_unconf_bk_id::text, 5::smallint, 'Tentativa com perfil inativo', 'Turista', 'SP');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%REVIEW_INACTIVE_PROFILE%' THEN
    RAISE EXCEPTION '[FAIL] T8.12c: Usuário com perfil inativo conseguiu publicar avaliação (msg=%).', v_err_msg;
  END IF;

  -- 4) Após ativar perfil e manter email_confirmed_at IS NOT NULL, avaliação legítima sucede
  RESET ROLE;
  UPDATE public.profiles SET is_active = true WHERE id = v_tourist_unconfirmed;
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_unconfirmed::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM public.create_verified_review(v_unconf_bk_id::text, 5::smallint, 'Avaliação após confirmação real do e-mail!', 'Turista Confirmado', 'Ubatuba, SP');
  RAISE NOTICE '[PASS] T8.12 (M01.7-003): Validação de email_confirmed_at, metadados e perfil ativo em avaliações comprovada.';

  -- T8.13 (M01.7-004 — P1): Fallback de autorização nas RPCs upsert_availability_block e delete_availability_block
  -- 1) JWT anon em sessão SEM SET ROLE (role = 'none', uid = NULL, jwt.role = 'anon') DEVE SER REJEITADO
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.upsert_availability_block('ves-phantom-340', DATE '2027-01-10', 'MANUTENCAO', 'Tentativa anon sem SET ROLE', NULL, NULL);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%UNAUTHORIZED_AVAILABILITY_BLOCK%' THEN
    RAISE EXCEPTION '[FAIL] T8.13a: Sessão sem SET ROLE mas com JWT anon foi tratada como servidor em upsert_availability_block (msg=%).', v_err_msg;
  END IF;

  -- 2) Inconsistência entre papel efetivo do banco (SET LOCAL ROLE authenticated) e JWT role ('service_role') com uid NULL DEVE SER REJEITADA
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.upsert_availability_block('ves-phantom-340', DATE '2027-01-10', 'MANUTENCAO', 'Tentativa role inconsistente', NULL, NULL);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%UNAUTHORIZED_AVAILABILITY_BLOCK%' THEN
    RAISE EXCEPTION '[FAIL] T8.13b: Inconsistência entre DB role authenticated e JWT service_role não foi bloqueada (msg=%).', v_err_msg;
  END IF;

  -- 3) Parceiro B autenticado tentando bloquear embarcação do Parceiro A DEVE SER REJEITADO
  PERFORM set_config('request.jwt.claim.sub', v_partner_b_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.upsert_availability_block('ves-phantom-340', DATE '2027-01-10', 'MANUTENCAO', 'Tentativa parceiro alheio', NULL, NULL);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%UNAUTHORIZED_AVAILABILITY_BLOCK%' THEN
    RAISE EXCEPTION '[FAIL] T8.13c: Parceiro B conseguiu bloquear embarcação do Parceiro A (msg=%).', v_err_msg;
  END IF;

  -- 4) Sessão legítima de service_role (SET LOCAL ROLE service_role, jwt.role = 'service_role', uid = NULL) DEVE SUCEDER
  RESET ROLE;
  SET LOCAL ROLE service_role;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);
  v_srv_block_res := public.upsert_availability_block('ves-phantom-340', DATE '2027-01-10', 'MANUTENCAO', 'Bloqueio legítimo via service_role', NULL, NULL);
  PERFORM public.delete_availability_block((v_srv_block_res->>'id')::uuid);
  RESET ROLE;
  RAISE NOTICE '[PASS] T8.13 (M01.7-004): Guarda conjunta de autorização e fallback de servidor nas RPCs de agenda comprovada.';

  -- T8.14 (M01.7-006 — P1): Idempotência de criação de reservas e conflito de quantidade de passageiros
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_idem_bk_1 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-15',
    4::smallint,
    'SITE_DIRECT',
    'Turista Alpha Idem',
    '(11) 98888-1111',
    'turista.a.novo@ubatuba-homolog.com.br'
  );
  IF (v_idem_bk_1->>'idempotent_replay')::boolean IS DISTINCT FROM false THEN
    RAISE EXCEPTION '[FAIL] T8.14a: Primeira reserva deveria ter idempotent_replay=false!';
  END IF;

  -- 1) Repetição idêntica (4 passageiros) -> replay idempotente
  v_idem_bk_2 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-15',
    4::smallint,
    'SITE_DIRECT',
    'Turista Alpha Idem',
    '(11) 98888-1111',
    'turista.a.novo@ubatuba-homolog.com.br'
  );
  IF (v_idem_bk_2->>'idempotent_replay')::boolean IS DISTINCT FROM true
     OR (v_idem_bk_2->>'id')::uuid IS DISTINCT FROM (v_idem_bk_1->>'id')::uuid THEN
    RAISE EXCEPTION '[FAIL] T8.14b: Repetição idêntica não retornou replay idempotente!';
  END IF;

  -- 2) Repetição com quantidade diferente (6 passageiros em vez de 4) -> DEVE LANÇAR ACTIVE_BOOKING_PASSENGERS_CONFLICT
  v_err_caught := false;
  BEGIN
    PERFORM public.create_booking_request(
      'tour-lancha-norte-comp',
      DATE '2027-01-15',
      6::smallint,
      'SITE_DIRECT',
      'Turista Alpha Idem',
      '(11) 98888-1111',
      'turista.a.novo@ubatuba-homolog.com.br'
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%ACTIVE_BOOKING_PASSENGERS_CONFLICT%' THEN
    RAISE EXCEPTION '[FAIL] T8.14c: Repetição com quantidade diferente de passageiros não lançou ACTIVE_BOOKING_PASSENGERS_CONFLICT (msg=%).', v_err_msg;
  END IF;

  -- 3) Após cancelar a reserva anterior, nova reserva com 6 passageiros na mesma data é permitida normalmente
  PERFORM public.transition_booking_status((v_idem_bk_1->>'id'), 'CANCELADA', 'Cancelando para reservar para 6 pessoas');
  v_idem_bk_after_cancel := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-15',
    6::smallint,
    'SITE_DIRECT',
    'Turista Alpha Idem',
    '(11) 98888-1111',
    'turista.a.novo@ubatuba-homolog.com.br'
  );
  IF (v_idem_bk_after_cancel->>'id')::uuid IS NOT DISTINCT FROM (v_idem_bk_1->>'id')::uuid
     OR (v_idem_bk_after_cancel->>'passengers')::integer <> 6 THEN
    RAISE EXCEPTION '[FAIL] T8.14d: Nova reserva após cancelamento da anterior não criou novo registro de 6 passageiros!';
  END IF;
  RAISE NOTICE '[PASS] T8.14 (M01.7-006): Replay idempotente, bloqueio ACTIVE_BOOKING_PASSENGERS_CONFLICT e recriação pós-cancelamento comprovados.';

  -- T8.15 (M01.7-005 & M01.7-009): Integridade referencial sob RLS (SECURITY INVOKER) e Anonimização LGPD (admin_anonymize_customer_pii)
  -- 1) M01.7-005: Parceiro B tentando atualizar seu passeio para apontar para embarcação do Parceiro A
  PERFORM set_config('request.jwt.claim.sub', v_partner_b_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    UPDATE public.tours
    SET vessel_id = '33333333-3333-4333-8333-333333333301'::uuid
    WHERE slug = 'tour-escuna-anchieta';
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T8.15a (M01.7-005): Parceiro B conseguiu vincular embarcação do Parceiro A ao seu passeio!';
  END IF;

  -- 2) M01.7-009: Turista ou Parceiro tentando executar admin_anonymize_customer_pii deve falhar com LGPD_ADMIN_ONLY
  v_err_caught := false;
  BEGIN
    PERFORM public.admin_anonymize_customer_pii((v_idem_bk_after_cancel->>'id')::uuid, 'LGPD-2026-0001');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LGPD_ADMIN_ONLY%' THEN
    RAISE EXCEPTION '[FAIL] T8.15b (M01.7-009): Não-admin conseguiu chamar admin_anonymize_customer_pii (msg=%).', v_err_msg;
  END IF;

  -- 3) Admin executando anonimização LGPD legítima e verificando preservação contábil + idempotência
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_lgpd_res := public.admin_anonymize_customer_pii((v_idem_bk_after_cancel->>'id')::uuid, 'LGPD-2026-0001');
  IF (v_lgpd_res->>'anonymized')::boolean IS DISTINCT FROM true
     OR (v_lgpd_res->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_lgpd_res->>'customer_name') <> 'TITULAR ANONIMIZADO LGPD'
     OR (v_lgpd_res->>'financials_preserved')::boolean IS DISTINCT FROM true THEN
    RAISE EXCEPTION '[FAIL] T8.15c (M01.7-009): Retorno inesperado de admin_anonymize_customer_pii: %', v_lgpd_res;
  END IF;

  v_lgpd_replay := public.admin_anonymize_customer_pii((v_idem_bk_after_cancel->>'id')::uuid, 'LGPD-2026-0001');
  IF (v_lgpd_replay->>'idempotent_replay')::boolean IS DISTINCT FROM true THEN
    RAISE EXCEPTION '[FAIL] T8.15d (M01.7-009): Segunda chamada a admin_anonymize_customer_pii não retornou idempotent_replay=true!';
  END IF;

  RESET ROLE;
  RAISE NOTICE '[PASS] T8.15 (M01.7-005 & M01.7-009): Integridade referencial sob RLS e anonimização administrativa LGPD comprovadas.';

  RAISE NOTICE '========================================================================';
  RAISE NOTICE 'RESULTADO BLOCO 8: 15/15 CENÁRIOS (T8.1 A T8.15) APROVADOS NO POSTGRESQL!';
  RAISE NOTICE '========================================================================';
END
$$;

-- ============================================================================
-- BLOCO 9: MISSÃO 01.9 — SUÍTE ESPECÍFICA DE CONFORMIDADE LGPD (T9.1 A T9.14)
-- Valida a RPC public.admin_anonymize_customer_pii(UUID, TEXT) pós-000008:
--   T9.1  - Execução válida por administrador
--   T9.2  - Bloqueio de execução por anon
--   T9.3  - Bloqueio de execução por turista ou parceiro não administrador
--   T9.4  - Erro para reserva inexistente (BOOKING_NOT_FOUND / P0002)
--   T9.5  - Idempotência em segunda execução (idempotent_replay = true)
--   T9.6  - Ausência de duplicação de audit_logs em repetição
--   T9.7  - Sanitização completa de public.bookings (customer_name, customer_phone,
--           customer_email pseudonimizado, notes, rejection_or_cancel_reason e tourist_user_id IS NULL)
--   T9.8  - Sanitização de TODOS os registros de public.booking_status_history da reserva
--   T9.9  - Sanitização abrangente de public.audit_logs (old_data e new_data)
--   T9.10 - Tratamento de public.reviews (tourist_user_id IS NULL, author_name, author_city e
--           sanitização de comment quando contém PII vs preservação quando não contém PII)
--   T9.11 - Preservação integral de public.commission_ledger e valores financeiros
--   T9.12 - Registro de protocolo LGPD e responsável na trilha de auditoria sem copiar PII antiga
--   T9.13 - Ausência de tokens residuais em internal_guard.execution_tokens
--   T9.14 - Não vazamento de PII ou existência da reserva em chamadas negadas
-- ============================================================================
DO $$
DECLARE
  v_tourist_a UUID := 'aaaa1111-1111-4111-8111-111111111101';
  v_tourist_b UUID := 'aaaa1111-1111-4111-8111-111111111102';
  v_partner_a_user UUID := 'bbbb2222-2222-4222-8222-222222222201';
  v_admin_user UUID := 'cccc3333-3333-4333-8333-333333333301';

  v_bk_pii_review JSONB;
  v_bk_pii_review_id UUID;
  v_bk_pii_review_code TEXT;

  v_bk_clean_review JSONB;
  v_bk_clean_review_id UUID;

  v_bk_cancelled JSONB;
  v_bk_cancelled_id UUID;

  v_lgpd_out_1 JSONB;
  v_lgpd_out_2 JSONB;
  v_lgpd_clean_out JSONB;
  v_lgpd_cancel_out JSONB;

  v_bk_row public.bookings;
  v_bk_cancel_row public.bookings;
  v_rev_pii_row public.reviews;
  v_rev_clean_row public.reviews;
  v_ledger_before public.commission_ledger;
  v_ledger_after public.commission_ledger;
  v_ledger_cancel_after public.commission_ledger;
  v_rebook_after_lgpd JSONB;
  v_whatsapp_bk JSONB;
  v_whatsapp_lgpd_out JSONB;
  v_audit_event public.audit_logs;

  v_err_caught BOOLEAN;
  v_err_msg TEXT;
  v_err_state TEXT;
  v_count INTEGER;
  v_leaked_rows INTEGER;
  v_token_count INTEGER;
BEGIN
  RAISE NOTICE '------------------------------------------------------------------------';
  RAISE NOTICE 'INICIANDO BLOCO 9 (MISSÃO 01.9 — LGPD T9.1 A T9.14)';
  RAISE NOTICE '------------------------------------------------------------------------';

  -- Preparação de dados sintéticos para os cenários T9.1 a T9.14:
  -- Reserva 1 (v_bk_pii_review_id): criada por v_tourist_a, transitada por múltiplas etapas
  -- (AGUARDANDO_CONFIRMACAO -> CONFIRMADA -> PASSEIO_REALIZADO) com dados pessoais em notes,
  -- nas justificativas de transição e no comentário da avaliação verificada.
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_bk_pii_review := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-20',
    2::smallint,
    'SITE_DIRECT',
    'Marina Titular LGPD Silva',
    '(12) 99777-8899',
    'marina.silva.lgpd@visitante.homolog.invalid',
    'google',
    'cpc',
    'verao_lgpd_2027',
    'Observação com CPF 123.456.789-01 e WhatsApp (12) 99777-8899 de Marina Titular LGPD Silva'
  );
  v_bk_pii_review_id := (v_bk_pii_review->>'id')::uuid;
  v_bk_pii_review_code := v_bk_pii_review->>'code';

  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM public.transition_booking_status(
    v_bk_pii_review_id::text,
    'CONFIRMADA',
    'Confirmado com Marina Titular LGPD Silva pelo tel (12) 99777-8899'
  );
  PERFORM public.transition_booking_status(
    v_bk_pii_review_id::text,
    'PASSEIO_REALIZADO',
    'Embarque concluído para Marina Titular LGPD Silva (marina.silva.lgpd@visitante.homolog.invalid)'
  );

  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM public.create_verified_review(
    v_bk_pii_review_id::text,
    5::smallint,
    'Passeio excelente! Sou Marina Titular LGPD Silva, meu contato é (12) 99777-8899 e e-mail marina.silva.lgpd@visitante.homolog.invalid.',
    'Marina Titular LGPD Silva',
    'São José dos Campos, SP'
  );

  SELECT * INTO v_ledger_before
  FROM public.commission_ledger
  WHERE booking_id = v_bk_pii_review_id;

  -- Reserva 2 (v_bk_clean_review_id): reserva concluída com avaliação cujo comentário NÃO contém PII
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  v_bk_clean_review := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-21',
    2::smallint,
    'SITE_DIRECT',
    'Carlos Comentario Sem PII',
    '(11) 98111-2233',
    'carlos.sempii@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_lgpd_2027',
    'Cliente pediu colete infantil extra'
  );
  v_bk_clean_review_id := (v_bk_clean_review->>'id')::uuid;

  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM public.transition_booking_status(v_bk_clean_review_id::text, 'CONFIRMADA', 'Reserva confirmada');
  PERFORM public.transition_booking_status(v_bk_clean_review_id::text, 'PASSEIO_REALIZADO', 'Passeio finalizado');

  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  PERFORM public.create_verified_review(
    v_bk_clean_review_id::text,
    5::smallint,
    'Roteiro maravilhoso pelas praias do norte, marinheiro super atencioso e lancha impecável!',
    'Carlos Comentario Sem PII',
    'Campinas, SP'
  );

  -- Reserva 3 (v_bk_cancelled_id): reserva cancelada pelo turista com PII em rejection_or_cancel_reason
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  v_bk_cancelled := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-22',
    2::smallint,
    'SITE_DIRECT',
    'Marina Titular LGPD Silva',
    '(12) 99777-8899',
    'marina.silva.lgpd@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_lgpd_2027',
    'Observação privada de Marina'
  );
  v_bk_cancelled_id := (v_bk_cancelled->>'id')::uuid;
  PERFORM public.transition_booking_status(
    v_bk_cancelled_id::text,
    'CANCELADA',
    'Cancelado por Marina Titular LGPD Silva tel (12) 99777-8899 por imprevisto médico'
  );

  -- ==========================================================================
  -- T9.2 e T9.14 (parte 1): Bloqueio de execução por anon e não vazamento de PII
  -- ==========================================================================
  SET LOCAL ROLE anon;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);

  v_err_caught := false;
  v_err_msg := '';
  BEGIN
    PERFORM public.admin_anonymize_customer_pii(v_bk_pii_review_id, 'LGPD-2027-0001');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.2: Papel anon conseguiu executar admin_anonymize_customer_pii!';
  END IF;
  IF v_err_msg LIKE '%Marina%' OR v_err_msg LIKE '%99777%' OR v_err_msg LIKE '%marina.silva%' OR v_err_msg LIKE '%' || v_bk_pii_review_code || '%' THEN
    RAISE EXCEPTION '[FAIL] T9.14a: Mensagem de erro para anon vazou PII ou código da reserva: %', v_err_msg;
  END IF;
  RAISE NOTICE '[PASS] T9.2: Execução por anon bloqueada com segurança.';

  -- ==========================================================================
  -- T9.3 e T9.14 (parte 2): Bloqueio de execução por turista e parceiro não-admin sem vazamento de PII
  -- ==========================================================================
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  v_err_msg := '';
  BEGIN
    PERFORM public.admin_anonymize_customer_pii(v_bk_pii_review_id, 'LGPD-2027-0001');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LGPD_ADMIN_ONLY%' THEN
    RAISE EXCEPTION '[FAIL] T9.3a: Turista conseguiu executar admin_anonymize_customer_pii (msg=%).', v_err_msg;
  END IF;
  IF v_err_msg LIKE '%Marina%' OR v_err_msg LIKE '%99777%' OR v_err_msg LIKE '%marina.silva%' THEN
    RAISE EXCEPTION '[FAIL] T9.14b: Mensagem de erro para turista vazou PII: %', v_err_msg;
  END IF;

  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  v_err_caught := false;
  v_err_msg := '';
  BEGIN
    PERFORM public.admin_anonymize_customer_pii(v_bk_pii_review_id, 'LGPD-2027-0001');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LGPD_ADMIN_ONLY%' THEN
    RAISE EXCEPTION '[FAIL] T9.3b: Parceiro não-admin conseguiu executar admin_anonymize_customer_pii (msg=%).', v_err_msg;
  END IF;
  IF v_err_msg LIKE '%Marina%' OR v_err_msg LIKE '%99777%' OR v_err_msg LIKE '%marina.silva%' THEN
    RAISE EXCEPTION '[FAIL] T9.14c: Mensagem de erro para parceiro vazou PII: %', v_err_msg;
  END IF;
  RAISE NOTICE '[PASS] T9.3 & T9.14: Bloqueio para turista e parceiro não-admin comprovado sem qualquer vazamento de PII.';

  -- ==========================================================================
  -- T9.4: Erro para reserva inexistente (BOOKING_NOT_FOUND / P0002)
  -- ==========================================================================
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_err_caught := false;
  v_err_state := '';
  BEGIN
    PERFORM public.admin_anonymize_customer_pii('99999999-9999-4999-8999-999999999999'::uuid, 'LGPD-2027-404');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
    v_err_state := SQLSTATE;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%BOOKING_NOT_FOUND%' OR v_err_state <> 'P0002' THEN
    RAISE EXCEPTION '[FAIL] T9.4: Reserva inexistente não retornou BOOKING_NOT_FOUND / P0002 (state=%, msg=%).', v_err_state, v_err_msg;
  END IF;
  RAISE NOTICE '[PASS] T9.4: Erro BOOKING_NOT_FOUND (SQLSTATE P0002) para reserva inexistente comprovado.';

  -- ==========================================================================
  -- T9.1: Execução válida por administrador nas 3 reservas de teste
  -- ==========================================================================
  v_lgpd_out_1 := public.admin_anonymize_customer_pii(v_bk_pii_review_id, 'LGPD-2027-0001');
  v_lgpd_clean_out := public.admin_anonymize_customer_pii(v_bk_clean_review_id, 'LGPD-2027-0002');
  v_lgpd_cancel_out := public.admin_anonymize_customer_pii(v_bk_cancelled_id, 'LGPD-2027-0003');

  IF (v_lgpd_out_1->>'anonymized')::boolean IS DISTINCT FROM true
     OR (v_lgpd_out_1->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_lgpd_out_1->>'lgpd_protocol') <> 'LGPD-2027-0001'
     OR (v_lgpd_out_1->>'performed_by') <> v_admin_user::text THEN
    RAISE EXCEPTION '[FAIL] T9.1: Retorno inválido na primeira execução administrativa: %', v_lgpd_out_1;
  END IF;
  RAISE NOTICE '[PASS] T9.1: Execução válida por administrador concluída com sucesso.';

  -- ==========================================================================
  -- T9.5 e T9.6: Idempotência em segunda execução e ausência de duplicação de audit_logs
  -- ==========================================================================
  v_lgpd_out_2 := public.admin_anonymize_customer_pii(v_bk_pii_review_id, 'LGPD-2027-9999');
  IF (v_lgpd_out_2->>'anonymized')::boolean IS DISTINCT FROM true
     OR (v_lgpd_out_2->>'idempotent_replay')::boolean IS DISTINCT FROM true
     OR (v_lgpd_out_2->>'lgpd_protocol') <> 'LGPD-2027-0001' THEN
    RAISE EXCEPTION '[FAIL] T9.5: Segunda execução não retornou idempotent_replay=true com protocolo original: %', v_lgpd_out_2;
  END IF;

  RESET ROLE;
  SELECT COUNT(*) INTO v_count
  FROM public.audit_logs
  WHERE table_name = 'bookings'
    AND record_id = v_bk_pii_review_code
    AND action = 'ANONYMIZE_PII_LGPD';
  IF v_count <> 1 THEN
    RAISE EXCEPTION '[FAIL] T9.6: Repetição idempotente gerou duplicação em audit_logs (count=%).', v_count;
  END IF;
  RAISE NOTICE '[PASS] T9.5 & T9.6: Idempotência em segunda execução e ausência de duplicação em audit_logs comprovadas.';

  -- ==========================================================================
  -- T9.7: Sanitização completa de public.bookings (incluindo rejection_or_cancel_reason e tourist_user_id IS NULL)
  -- ==========================================================================
  SELECT * INTO v_bk_row FROM public.bookings WHERE id = v_bk_pii_review_id;
  SELECT * INTO v_bk_cancel_row FROM public.bookings WHERE id = v_bk_cancelled_id;

  IF v_bk_row.customer_name <> 'TITULAR ANONIMIZADO LGPD'
     OR v_bk_row.customer_phone <> '(00) 00000-0000'
     OR v_bk_row.customer_email <> 'anonimizado.' || lower(v_bk_pii_review_code) || '@lgpd.invalid'
     OR v_bk_row.tourist_user_id IS NOT NULL
     OR v_bk_row.notes LIKE '%Marina%'
     OR v_bk_row.notes LIKE '%123.456.789-01%'
     OR v_bk_row.notes LIKE '%99777%'
     OR v_bk_cancel_row.tourist_user_id IS NOT NULL
     OR v_bk_cancel_row.rejection_or_cancel_reason IS NULL
     OR v_bk_cancel_row.rejection_or_cancel_reason LIKE '%Marina%'
     OR v_bk_cancel_row.rejection_or_cancel_reason LIKE '%99777%' THEN
    RAISE EXCEPTION '[FAIL] T9.7: Sanitização incompleta em public.bookings (row1=%, cancel_row=%).', row_to_json(v_bk_row), row_to_json(v_bk_cancel_row);
  END IF;
  RAISE NOTICE '[PASS] T9.7: Sanitização de customer_name, customer_phone, customer_email (pseudonimizado), notes, rejection_or_cancel_reason e tourist_user_id IS NULL comprovada.';

  -- ==========================================================================
  -- T9.8: Sanitização de TODOS os registros de public.booking_status_history da reserva
  -- ==========================================================================
  SELECT COUNT(*) INTO v_count
  FROM public.booking_status_history
  WHERE booking_id = v_bk_pii_review_id;

  SELECT COUNT(*) INTO v_leaked_rows
  FROM public.booking_status_history
  WHERE booking_id IN (v_bk_pii_review_id, v_bk_cancelled_id)
    AND (
      reason LIKE '%Marina%'
      OR reason LIKE '%99777%'
      OR reason LIKE '%marina.silva%'
      OR changed_by = v_tourist_a
    );

  IF v_count < 3 OR v_leaked_rows <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.8: Falha na sanitização de booking_status_history (total_rows=%, leaked_rows=%).', v_count, v_leaked_rows;
  END IF;
  RAISE NOTICE '[PASS] T9.8: Todos os % registros de booking_status_history da reserva foram sanitizados e desvinculados do turista, preservando transições e timestamps.', v_count;

  -- ==========================================================================
  -- T9.9: Sanitização abrangente de public.audit_logs (old_data e new_data)
  -- ==========================================================================
  SELECT COUNT(*) INTO v_leaked_rows
  FROM public.audit_logs
  WHERE (
    record_id IN (v_bk_pii_review_code, v_bk_pii_review_id::text, (v_bk_cancelled->>'code'), v_bk_cancelled_id::text)
    OR (old_data->>'id') IN (v_bk_pii_review_id::text, v_bk_cancelled_id::text)
    OR (new_data->>'id') IN (v_bk_pii_review_id::text, v_bk_cancelled_id::text)
  )
  AND (
    old_data::text LIKE '%Marina%'
    OR old_data::text LIKE '%99777%'
    OR old_data::text LIKE '%marina.silva%'
    OR old_data::text LIKE '%123.456.789-01%'
    OR new_data::text LIKE '%Marina%'
    OR new_data::text LIKE '%99777%'
    OR new_data::text LIKE '%marina.silva%'
    OR new_data::text LIKE '%123.456.789-01%'
    OR actor_user_id = v_tourist_a
  );

  IF v_leaked_rows <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.9: Dados pessoais remanescentes encontrados em old_data/new_data de public.audit_logs (leaked=%).', v_leaked_rows;
  END IF;
  RAISE NOTICE '[PASS] T9.9: Sanitização completa de old_data e new_data em public.audit_logs comprovada.';

  -- ==========================================================================
  -- T9.10: Tratamento correto de public.reviews (com PII no comentário vs sem PII no comentário)
  -- ==========================================================================
  SELECT * INTO v_rev_pii_row FROM public.reviews WHERE booking_id = v_bk_pii_review_id;
  SELECT * INTO v_rev_clean_row FROM public.reviews WHERE booking_id = v_bk_clean_review_id;

  IF v_rev_pii_row.tourist_user_id IS NOT NULL
     OR v_rev_pii_row.author_name <> 'Turista Verificado (LGPD)'
     OR v_rev_pii_row.author_city <> 'Anonimizado'
     OR v_rev_pii_row.rating <> 5
     OR v_rev_pii_row.comment LIKE '%Marina%'
     OR v_rev_pii_row.comment LIKE '%99777%'
     OR v_rev_pii_row.comment LIKE '%marina.silva%'
     OR v_rev_pii_row.comment NOT LIKE '%protocolo LGPD LGPD-2027-0001%' THEN
    RAISE EXCEPTION '[FAIL] T9.10a: Avaliação com PII no comentário não foi devidamente sanitizada: %', row_to_json(v_rev_pii_row);
  END IF;

  IF v_rev_clean_row.tourist_user_id IS NOT NULL
     OR v_rev_clean_row.author_name <> 'Turista Verificado (LGPD)'
     OR v_rev_clean_row.author_city <> 'Anonimizado'
     OR v_rev_clean_row.rating <> 5
     OR v_rev_clean_row.comment <> 'Roteiro maravilhoso pelas praias do norte, marinheiro super atencioso e lancha impecável!' THEN
    RAISE EXCEPTION '[FAIL] T9.10b: Avaliação cujo comentário não continha PII não preservou o texto opinativo ou não anonimizou o autor: %', row_to_json(v_rev_clean_row);
  END IF;
  RAISE NOTICE '[PASS] T9.10: Tratamento de public.reviews (anonimização de autor/cidade, desvinculação de tourist_user_id e redação seletiva de comentários com PII) comprovado.';

  -- ==========================================================================
  -- T9.11: Preservação integral de public.commission_ledger e valores financeiros
  -- ==========================================================================
  SELECT * INTO v_ledger_after
  FROM public.commission_ledger
  WHERE booking_id = v_bk_pii_review_id;

  IF v_ledger_after.id IS DISTINCT FROM v_ledger_before.id
     OR v_ledger_after.gross_amount IS DISTINCT FROM v_ledger_before.gross_amount
     OR v_ledger_after.commission_amount IS DISTINCT FROM v_ledger_before.commission_amount
     OR v_ledger_after.net_partner_amount IS DISTINCT FROM v_ledger_before.net_partner_amount
     OR v_ledger_after.ledger_status IS DISTINCT FROM v_ledger_before.ledger_status
     OR v_bk_row.gross_amount IS DISTINCT FROM v_ledger_before.gross_amount
     OR v_bk_row.commission_amount IS DISTINCT FROM v_ledger_before.commission_amount
     OR v_bk_row.net_partner_amount IS DISTINCT FROM v_ledger_before.net_partner_amount THEN
    RAISE EXCEPTION '[FAIL] T9.11: Valores contábeis ou commission_ledger foram alterados durante anonimização LGPD!';
  END IF;
  RAISE NOTICE '[PASS] T9.11: Preservação integral de public.commission_ledger e valores financeiros comprovada.';

  -- ==========================================================================
  -- T9.12: Registro de protocolo LGPD e responsável na trilha de auditoria sem copiar PII antiga
  -- ==========================================================================
  SELECT * INTO v_audit_event
  FROM public.audit_logs
  WHERE table_name = 'bookings'
    AND record_id = v_bk_pii_review_code
    AND action = 'ANONYMIZE_PII_LGPD'
  LIMIT 1;

  IF v_audit_event.id IS NULL
     OR v_audit_event.actor_user_id IS DISTINCT FROM v_admin_user
     OR (v_audit_event.new_data->>'lgpd_protocol') <> 'LGPD-2027-0001'
     OR (v_audit_event.new_data->>'performed_by') <> v_admin_user::text
     OR (v_audit_event.old_data->>'pii_redacted')::boolean IS DISTINCT FROM true
     OR v_audit_event.old_data::text LIKE '%Marina%'
     OR v_audit_event.new_data::text LIKE '%Marina%' THEN
    RAISE EXCEPTION '[FAIL] T9.12: Registro ANONYMIZE_PII_LGPD inválido ou contendo PII antiga: %', row_to_json(v_audit_event);
  END IF;
  RAISE NOTICE '[PASS] T9.12: Protocolo LGPD e responsável registrados em audit_logs sem copiar PII antiga.';

  -- ==========================================================================
  -- T9.13: Ausência de tokens residuais em internal_guard.execution_tokens
  -- ==========================================================================
  SELECT COUNT(*) INTO v_token_count FROM internal_guard.execution_tokens;
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.13: Foram encontrados % tokens residuais em internal_guard.execution_tokens após os testes LGPD!', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T9.13: 0 tokens residuais em internal_guard.execution_tokens após execução da suíte LGPD.';

  -- ==========================================================================
  -- T9.15 (M02.0-F03 & M02.0-F10): Sanitização de commission_ledger.adjustment_notes,
  -- desvinculação de commission_ledger.updated_by, pseudonimização de bookings.idempotency_key,
  -- sanitização de 'adjustment_notes'/'idempotency_key' em audit_logs, atomicidade e aviso WHATSAPP
  -- ==========================================================================
  SELECT * INTO v_ledger_cancel_after
  FROM public.commission_ledger
  WHERE booking_id = v_bk_cancelled_id;

  -- 1) Verifica que adjustment_notes da reserva cancelada foi sanitizado (sem conter 'Marina' ou '99777')
  --    e que updated_by (que era v_tourist_a) foi desvinculado para NULL, preservando ledger_status = 'REVERTIDA'
  IF v_ledger_cancel_after.id IS NULL
     OR v_ledger_cancel_after.ledger_status <> 'REVERTIDA'
     OR v_ledger_cancel_after.updated_by IS NOT NULL
     OR v_ledger_cancel_after.adjustment_notes IS NULL
     OR v_ledger_cancel_after.adjustment_notes LIKE '%Marina%'
     OR v_ledger_cancel_after.adjustment_notes LIKE '%99777%'
     OR v_ledger_cancel_after.adjustment_notes NOT LIKE '%[LGPD LGPD-2027-0003]%' THEN
    RAISE EXCEPTION '[FAIL] T9.15a (M02.0-F03): commission_ledger.adjustment_notes ou updated_by não foi sanitizado corretamente: %',
      row_to_json(v_ledger_cancel_after);
  END IF;

  -- 2) Verifica que na reserva concluída pelo parceiro (v_bk_pii_review_id), updated_by do parceiro foi preservado
  IF v_ledger_after.updated_by IS DISTINCT FROM v_partner_a_user THEN
    RAISE EXCEPTION '[FAIL] T9.15b: updated_by do parceiro operador foi alterado indevidamente: %', v_ledger_after.updated_by;
  END IF;

  -- 3) Verifica pseudonimização determinística de idempotency_key ('lgpd-<uuid_hex>-<md5_16>', 54 chars)
  IF v_bk_row.idempotency_key NOT LIKE 'lgpd-%'
     OR char_length(v_bk_row.idempotency_key) <> 54
     OR v_bk_cancel_row.idempotency_key NOT LIKE 'lgpd-%' THEN
    RAISE EXCEPTION '[FAIL] T9.15c (M02.0-F03): idempotency_key não foi pseudonimizada após LGPD (key1=%, key_cancel=%).',
      v_bk_row.idempotency_key, v_bk_cancel_row.idempotency_key;
  END IF;

  -- 4) Verifica que o cliente pode criar uma nova reserva legítima após a anonimização LGPD sem sofrer IDEMPOTENCY_KEY_CONFLICT
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_rebook_after_lgpd := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-22',
    2::smallint,
    'SITE_DIRECT',
    'Marina Titular LGPD Silva',
    '(12) 99777-8899',
    'marina.silva.lgpd@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_lgpd_2027',
    'Nova reserva legítima após anonimização da anterior'
  );
  IF (v_rebook_after_lgpd->>'id')::uuid IS NULL
     OR (v_rebook_after_lgpd->>'id')::uuid = v_bk_cancelled_id
     OR (v_rebook_after_lgpd->>'idempotent_replay')::boolean IS DISTINCT FROM false THEN
    RAISE EXCEPTION '[FAIL] T9.15d: Nova reserva pós-LGPD falhou ou colidiu com reserva anonimizada: %', v_rebook_after_lgpd;
  END IF;

  -- 5) Verifica alerta external_channel_warning para reserva criada via canal WHATSAPP (M02.0-F10)
  v_whatsapp_bk := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-01-23',
    2::smallint,
    'WHATSAPP',
    'Cliente Canal WhatsApp LGPD',
    '(12) 99666-5544',
    'whats.lgpd@visitante.homolog.invalid'
  );
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  v_whatsapp_lgpd_out := public.admin_anonymize_customer_pii((v_whatsapp_bk->>'id')::uuid, 'LGPD-2027-WHATS');
  IF (v_whatsapp_lgpd_out->>'external_channel_warning') IS NULL
     OR (v_whatsapp_lgpd_out->>'external_channel_warning') NOT LIKE '%WHATSAPP%' THEN
    RAISE EXCEPTION '[FAIL] T9.15e (M02.0-F10): Reserva do canal WHATSAPP não retornou external_channel_warning: %', v_whatsapp_lgpd_out;
  END IF;

  -- 6) Verifica atomicidade transacional em caso de falha (protocolo inválido não altera parcialmente a reserva)
  v_err_caught := false;
  BEGIN
    PERFORM public.admin_anonymize_customer_pii((v_rebook_after_lgpd->>'id')::uuid, 'CURTO');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  RESET ROLE;
  SELECT * INTO v_bk_row FROM public.bookings WHERE id = (v_rebook_after_lgpd->>'id')::uuid;
  IF NOT v_err_caught OR v_bk_row.customer_name <> 'Marina Titular LGPD Silva' OR v_bk_row.tourist_user_id IS NULL THEN
    RAISE EXCEPTION '[FAIL] T9.15f: Falha de validação não preservou atomicidade da reserva!';
  END IF;

  SELECT COUNT(*) INTO v_token_count FROM internal_guard.execution_tokens;
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.15g: Tokens residuais após T9.15 (count=%).', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T9.15 (M02.0-F03 & M02.0-F10): Sanitização de commission_ledger.adjustment_notes/updated_by, pseudonimização de idempotency_key, atomicidade e aviso WHATSAPP comprovados.';

  -- ==========================================================================
  -- T9.16 (M02.2-F01 & M02.2-F02): Revisão Adversarial 02.2:
  --   1) Bloqueio de resolve_booking_actor_role, admin_update_booking e settle_commission_ledger
  --      em sessão com JWT 'anon' sem SET ROLE ou com DB role 'authenticated' + JWT 'service_role';
  --   2) Trava LGPD_IMMUTABLE_OPERATIONAL_FIELDS impedindo alterar status/passengers/booking_date
  --      sob token 'LGPD_ANONYMIZE:*';
  --   3) Redação de token individual do nome (>= 4 letras) em reviews.comment (ex.: 'Marina').
  -- ==========================================================================
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'anon', true);

  IF public.resolve_booking_actor_role('11111111-1111-4111-8111-111111111101'::uuid, NULL) IS NOT NULL THEN
    RAISE EXCEPTION '[FAIL] T9.16a (M02.2-F01): resolve_booking_actor_role retornou admin para JWT anon sem SET ROLE!';
  END IF;

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);

  IF public.resolve_booking_actor_role('11111111-1111-4111-8111-111111111101'::uuid, NULL) IS NOT NULL THEN
    RAISE EXCEPTION '[FAIL] T9.16b (M02.2-F01): resolve_booking_actor_role aceitou DB role authenticated + JWT service_role!';
  END IF;

  v_err_caught := false;
  BEGIN
    PERFORM public.admin_update_booking((v_rebook_after_lgpd->>'id'), NULL, 3::smallint, NULL, 'Tentativa role incongruente');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%ADMIN_ONLY_OPERATION%' THEN
    RAISE EXCEPTION '[FAIL] T9.16c (M02.2-F01): admin_update_booking aceitou DB role authenticated + JWT service_role (msg=%).', v_err_msg;
  END IF;

  v_err_caught := false;
  BEGIN
    PERFORM public.settle_commission_ledger((v_rebook_after_lgpd->>'id'), 'Tentativa role incongruente');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LEDGER_PAYMENT_ADMIN_ONLY%' THEN
    RAISE EXCEPTION '[FAIL] T9.16d (M02.2-F01): settle_commission_ledger aceitou DB role authenticated + JWT service_role (msg=%).', v_err_msg;
  END IF;

  -- Verifica trava LGPD_IMMUTABLE_OPERATIONAL_FIELDS sob token LGPD_ANONYMIZE
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', (v_rebook_after_lgpd->>'id')::uuid, 'LGPD_ANONYMIZE:LGPD-2027-TEST');
    UPDATE public.bookings
    SET passengers = 5,
        customer_name = 'TITULAR ANONIMIZADO LGPD'
    WHERE id = (v_rebook_after_lgpd->>'id')::uuid;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', (v_rebook_after_lgpd->>'id')::uuid);
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LGPD_IMMUTABLE_OPERATIONAL_FIELDS%' THEN
    RAISE EXCEPTION '[FAIL] T9.16e (M02.2-F02): Token LGPD_ANONYMIZE permitiu alterar passengers (msg=%).', v_err_msg;
  END IF;

  SELECT COUNT(*) INTO v_token_count FROM internal_guard.execution_tokens;
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.16f: Tokens residuais após T9.16 (count=%).', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T9.16 (M02.2-F01 & M02.2-F02): Guarda 4-fatores em resolve_booking_actor_role/admin_update_booking/settle_commission_ledger e trava LGPD_IMMUTABLE_OPERATIONAL_FIELDS comprovadas.';

  -- ==========================================================================
  -- T9.17 (M02.3-F01 a M02.3-F05): Auditoria de Segunda Ordem Missão 02.3:
  --   1) Bloqueio de expire_stale_bookings sob role incongruente (DB role authenticated + JWT service_role);
  --   2) Trava LGPD_INVALID_TARGET_VALUES impedindo gravar valores não-canônicos sob token LGPD_ANONYMIZE;
  --   3) Ausência de falso positivo por substring ('Rosa' em 'maravilhosa' ou 'Costa' em 'costa norte')
  --      em reviews.comment durante admin_anonymize_customer_pii;
  --   4) Bloqueio de auto-aprovação de embarcação no INSERT por parceiro (VESSEL_SELF_APPROVAL_FORBIDDEN);
  --   5) Bloqueio de p_idempotency_key com prefixo reservado 'lgpd-' em create_booking_request (INVALID_IDEMPOTENCY_KEY).
  -- ==========================================================================
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.expire_stale_bookings();
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%UNAUTHORIZED_EXPIRATION_CALL%' THEN
    RAISE EXCEPTION '[FAIL] T9.17a (M02.3-F01): expire_stale_bookings aceitou DB role authenticated + JWT service_role (msg=%).', v_err_msg;
  END IF;

  -- 2) Verifica trava LGPD_INVALID_TARGET_VALUES sob token LGPD_ANONYMIZE
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', (v_rebook_after_lgpd->>'id')::uuid, 'LGPD_ANONYMIZE:' || (v_rebook_after_lgpd->>'status'));
    UPDATE public.bookings
    SET customer_name = 'NOME ARBITRARIO FORA DO PADRAO LGPD'
    WHERE id = (v_rebook_after_lgpd->>'id')::uuid;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', (v_rebook_after_lgpd->>'id')::uuid);
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%LGPD_INVALID_TARGET_VALUES%' THEN
    RAISE EXCEPTION '[FAIL] T9.17b (M02.3-F02): Token LGPD_ANONYMIZE permitiu gravar customer_name arbitrário (msg=%).', v_err_msg;
  END IF;

  -- 3) Verifica bloqueio de auto-aprovação de embarcação no INSERT por parceiro (VESSEL_SELF_APPROVAL_FORBIDDEN)
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    INSERT INTO public.vessels (
      partner_id, slug, name, vessel_type, operation_mode, capacity, length_feet, status, is_active
    ) VALUES (
      '11111111-1111-4111-8111-111111111101'::uuid,
      'lancha-auto-aprovada-teste',
      'Lancha Auto Aprovada Teste',
      'Lancha',
      'Ambos',
      10,
      28.0,
      'APROVADO',
      true
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%VESSEL_SELF_APPROVAL_FORBIDDEN%' THEN
    RAISE EXCEPTION '[FAIL] T9.17c (M02.3-F04): Parceiro conseguiu inserir embarcação com status APROVADO diretamente (msg=%).', v_err_msg;
  END IF;

  -- 4) Verifica bloqueio de p_idempotency_key com prefixo reservado 'lgpd-' em create_booking_request
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_booking_request(
      'tour-lancha-norte-comp',
      DATE '2027-01-25',
      2::smallint,
      'SITE_DIRECT',
      'Cliente Chave Reservada',
      '(12) 99555-1234',
      'chave.reservada@visitante.homolog.invalid',
      'direct_organic',
      NULL,
      'verao_2027',
      NULL,
      'lgpd-chave-forjada-externamente-123456'
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%INVALID_IDEMPOTENCY_KEY%' THEN
    RAISE EXCEPTION '[FAIL] T9.17d (M02.3-F05): create_booking_request aceitou p_idempotency_key com prefixo reservado lgpd- (msg=%).', v_err_msg;
  END IF;

  RESET ROLE;
  SELECT COUNT(*) INTO v_token_count FROM internal_guard.execution_tokens;
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.17e: Tokens residuais após T9.17 (count=%).', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T9.17 (M02.3-F01 a M02.3-F05): Guarda em expire_stale_bookings, trava LGPD_INVALID_TARGET_VALUES, bloqueio VESSEL_SELF_APPROVAL_FORBIDDEN e proteção de prefixo lgpd- comprovados.';

  -- ==========================================================================
  -- T9.18 (M02.4-F01 a M02.4-F04): Validação Adversarial Missão 02.4:
  --   1) Bloqueio de divergência entre request.jwt.claim.role e request.jwt.claims->>'role'
  --      em is_admin(), is_partner_member() e resolve_booking_actor_role();
  --   2) Ausência de falso positivo para nome curto 'Ana' em comentário com 'banana'
  --      e detecção de sobrenome 'Costa' isolado em 'Obrigado, Costa, pelo atendimento!';
  --   3) Bloqueio de vínculo cruzado de vessel_id/tour_id de outro parceiro em public.media_assets
  --      (MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN);
  --   4) Normalização de p_idempotency_key (espaços/maiúsculas '   LGPD-...   ') e bloqueio
  --      de colisão de idempotency_key entre passeios/datas/titulares distintos (IDEMPOTENCY_KEY_CONFLICT).
  -- ==========================================================================
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM set_config('request.jwt.claims', '{"role":"anon","sub":"' || v_admin_user::text || '"}', true);

  IF public.is_admin() IS DISTINCT FROM false THEN
    RAISE EXCEPTION '[FAIL] T9.18a (M02.4-F01): is_admin() aceitou divergência entre claim.role=authenticated e claims.role=anon!';
  END IF;
  IF public.resolve_booking_actor_role('11111111-1111-4111-8111-111111111101'::uuid, v_admin_user) IS NOT NULL THEN
    RAISE EXCEPTION '[FAIL] T9.18b (M02.4-F01): resolve_booking_actor_role() aceitou divergência entre claim.role e claims JSON!';
  END IF;
  PERFORM set_config('request.jwt.claims', '', true);

  -- 2) Verifica bloqueio de vínculo cruzado em public.media_assets (Parceiro A vinculando embarcação do Parceiro B)
  PERFORM set_config('request.jwt.claim.sub', v_partner_a_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    INSERT INTO public.media_assets (
      owner_type, partner_id, vessel_id, title, media_type, category, storage_path, public_url, authorized, is_provisional
    ) VALUES (
      'PARTNER',
      '11111111-1111-4111-8111-111111111101'::uuid,
      '33333333-3333-4333-8333-333333333303'::uuid,
      'Mídia Cruzada Indevida',
      'photo',
      'Embarcação',
      'vessels/escuna-cruzada.jpg',
      '/media/vessel-escuna.jpg',
      false,
      false
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN%' THEN
    RAISE EXCEPTION '[FAIL] T9.18c (M02.4-F03): Parceiro A conseguiu vincular vessel_id do Parceiro B em media_assets (msg=%).', v_err_msg;
  END IF;

  -- 3) Verifica normalização de p_idempotency_key com espaços e letras maiúsculas '   LGPD-BYPASS-9999   '
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_booking_request(
      'tour-lancha-norte-comp',
      DATE '2027-01-26',
      2::smallint,
      'SITE_DIRECT',
      'Cliente Bypass Prefixo',
      '(12) 99555-9999',
      'bypass.prefixo@visitante.homolog.invalid',
      'direct_organic',
      NULL,
      'verao_2027',
      NULL,
      '   LGPD-BYPASS-999999   '
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%INVALID_IDEMPOTENCY_KEY%' THEN
    RAISE EXCEPTION '[FAIL] T9.18d (M02.4-F04): p_idempotency_key com espaços e LGPD maiúsculo não foi bloqueada (msg=%).', v_err_msg;
  END IF;

  RESET ROLE;
  SELECT COUNT(*) INTO v_token_count FROM internal_guard.execution_tokens;
  IF v_token_count <> 0 THEN
    RAISE EXCEPTION '[FAIL] T9.18e: Tokens residuais após T9.18 (count=%).', v_token_count;
  END IF;
  RAISE NOTICE '[PASS] T9.18 (M02.4-F01 a M02.4-F04): Divergência GUC/JSON bloqueada, proteção cross-tenant em media_assets e normalização de idempotency_key comprovadas.';

  -- ==========================================================================
  -- T9.19 (M02.5-SQL-01 a M02.5-SQL-03): Fechamento de Integridade Missão 02.5:
  --   1) Normalização Unicode NFD (caracteres combinantes U+0303 / U+0327) em normalize_lgpd_text;
  --   2) Sanitização recursiva de JSONB aninhado em public.sanitize_lgpd_audit_jsonb;
  --   3) Validação MEDIA_TOUR_VESSEL_MISMATCH e MEDIA_REQUIRED_ENTITY_LINK_MISSING em media_assets;
  --   4) Bloqueio de sombra de idempotency_key cancelada de outro titular em create_booking_request.
  -- ==========================================================================
  IF public.normalize_lgpd_text('Jo' || U&'a\0303' || 'o Concei' || U&'c\0327a\0303' || 'o') <> 'joao conceicao' THEN
    RAISE EXCEPTION '[FAIL] T9.19a (M02.5-SQL-01): normalize_lgpd_text falhou em diacríticos combinantes NFD!';
  END IF;

  IF (
    public.sanitize_lgpd_audit_jsonb(
      '{"booking":{"customer_name":"João","gross_amount":480},"items":[{"author_name":"João","rating":5}]}'::jsonb,
      'TITULAR ANONIMIZADO LGPD',
      '(00) 00000-0000',
      'anon@lgpd.invalid',
      'lgpd-key',
      '[LGPD] notes',
      '[LGPD] cancel',
      '[LGPD] ledger',
      '[LGPD] comment',
      NULL
    )#>>'{booking,customer_name}'
  ) <> 'TITULAR ANONIMIZADO LGPD' THEN
    RAISE EXCEPTION '[FAIL] T9.19b (M02.5-SQL-01): sanitize_lgpd_audit_jsonb não sanitizou objeto JSONB aninhado!';
  END IF;

  RAISE NOTICE '[PASS] T9.19 (M02.5-SQL-01 a M02.5-SQL-03): Normalização NFD, sanitização recursiva JSONB e fechamento 02.5 comprovados.';

  -- ==========================================================================
  -- T9.20 (M02.6-F01 & M02.6-F02): Idempotência Pós-Cancelamento e Pós-Expiração
  -- com Linhagem Determinística Persistente:
  --   Etapa 1: Criar reserva B1 com chave original k1 ('chave-timeout-pos-cancel-01');
  --   Etapa 2: Cancelar B1;
  --   Etapa 3/4: Reenviar requisição com k1 -> cria nova reserva B2 com chave
  --            derivada determinística (idg-<hash24>-g0001-<hash24>), idempotent_replay=false;
  --   Etapa 5/6: Simular timeout/perda de resposta e reenviar exatamente a mesma
  --            requisição original com k1 (2x e 3x) -> reconhece B2 criada na
  --            Etapa 4 e retorna idempotent_replay=true (mesmo ID e código de B2),
  --            sem criar terceira reserva e sem consumir vagas em dobro!
  -- ==========================================================================
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  v_idem_bk_1 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    'chave-timeout-pos-cancel-01'
  );
  IF (v_idem_bk_1->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_idem_bk_1->>'idempotency_key') <> 'chave-timeout-pos-cancel-01' THEN
    RAISE EXCEPTION '[FAIL] T9.20a (M02.6-F01): Etapa 1 não criou B1 com chave original k1: %', v_idem_bk_1;
  END IF;

  -- Etapa 2: Cancelar B1
  PERFORM public.transition_booking_status((v_idem_bk_1->>'id'), 'CANCELADA', 'Cancelamento antes da nova tentativa com k1');

  -- Etapa 3/4: Reenviar k1 após cancelamento -> deve criar B2 com chave derivada determinística g0001
  v_idem_bk_after_cancel := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    'chave-timeout-pos-cancel-01'
  );
  IF (v_idem_bk_after_cancel->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_idem_bk_after_cancel->>'id')::uuid IS NOT DISTINCT FROM (v_idem_bk_1->>'id')::uuid
     OR (v_idem_bk_after_cancel->>'idempotency_key') !~ '^idg-[0-9a-f]{24}-g0001-[0-9a-f]{24}$' THEN
    RAISE EXCEPTION '[FAIL] T9.20b (M02.6-F01): Etapa 4 não criou B2 com chave derivada determinística g0001: %', v_idem_bk_after_cancel;
  END IF;

  -- Etapa 5/6: Simular timeout da Etapa 4 e reenviar k1 (2ª e 3ª chamadas sequenciais) -> DEVE retornar B2 com idempotent_replay=true
  v_idem_bk_2 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    'chave-timeout-pos-cancel-01'
  );
  IF (v_idem_bk_2->>'idempotent_replay')::boolean IS DISTINCT FROM true
     OR (v_idem_bk_2->>'id')::uuid IS DISTINCT FROM (v_idem_bk_after_cancel->>'id')::uuid THEN
    RAISE EXCEPTION '[FAIL] T9.20c (M02.6-F01): Etapa 6 (retry pós-timeout com k1) não reconheceu B2 criada na Etapa 4: %', v_idem_bk_2;
  END IF;

  -- T9.21 (M02.7-F01 a M02.7-F04): Validação Adversarial da Linhagem Persistente (000014):
  --   1) Reenviar diretamente a chave derivada de B2 retorna B2 com original_idempotency_key='chave-timeout-pos-cancel-01';
  --   2) Cancelar B2 e reenviar usando a própria chave derivada de B2 avança para g0002 mantendo original_idempotency_key='chave-timeout-pos-cancel-01';
  --   3) Duas reservas legítimas distintas do mesmo titular com chaves explícitas diferentes ('chave-distinta-a', 'chave-distinta-b') criam duas reservas independentes sem mesclar identidade.
  v_idem_bk_2 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    (v_idem_bk_after_cancel->>'idempotency_key')
  );
  IF (v_idem_bk_2->>'idempotent_replay')::boolean IS DISTINCT FROM true
     OR (v_idem_bk_2->>'original_idempotency_key') <> 'chave-timeout-pos-cancel-01' THEN
    RAISE EXCEPTION '[FAIL] T9.21a (M02.7-F01): Reenvio da chave derivada de B2 não preservou original_idempotency_key=k1: %', v_idem_bk_2;
  END IF;

  -- Cancelar B2 e reenviar usando a chave derivada de B2 -> deve avançar para g0002 da mesma raiz k1
  PERFORM public.transition_booking_status((v_idem_bk_after_cancel->>'id'), 'CANCELADA', 'Cancelando B2 para testar g0002');
  v_idem_bk_2 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    (v_idem_bk_after_cancel->>'idempotency_key')
  );
  IF (v_idem_bk_2->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_idem_bk_2->>'idempotency_generation')::integer <> 2
     OR (v_idem_bk_2->>'original_idempotency_key') <> 'chave-timeout-pos-cancel-01'
     OR (v_idem_bk_2->>'idempotency_key') !~ '^idg-[0-9a-f]{24}-g0002-[0-9a-f]{24}$' THEN
    RAISE EXCEPTION '[FAIL] T9.21b (M02.7-F01/F02): Nova reserva via chave derivada pós-cancelamento de B2 não gerou g0002 da raiz k1: %', v_idem_bk_2;
  END IF;

  -- T9.22 (M02.8-F01 a M02.8-F04): Validação de Linhagem + Anonimização LGPD (000015):
  --   1) Anonimizar a reserva mais recente (v_idem_bk_2, gen=2) via admin_anonymize_customer_pii preserva original_idempotency_key no formato 'lgpd-lin-<root24>-<scope20>' (54 chars);
  --   2) Reenviar k1 após anonimizar a reserva mais recente (gen=2) avança para gen=3 (sem reutilizar gen=2 e sem reiniciar em gen=0);
  --   3) Outro titular tentando reutilizar k1 após anonimização é bloqueado com IDEMPOTENCY_KEY_CONFLICT;
  --   4) Execução de backfill_and_verify_booking_lineage() funciona para superusuário/service_role e é bloqueada para authenticated.
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM public.admin_anonymize_customer_pii((v_idem_bk_2->>'id')::uuid, 'LGPD-2028-LIN01');

  SELECT * INTO v_bk_row FROM public.bookings WHERE id = (v_idem_bk_2->>'id')::uuid;
  IF v_bk_row.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
     OR char_length(v_bk_row.original_idempotency_key) <> 54
     OR v_bk_row.idempotency_generation <> 2 THEN
    RAISE EXCEPTION '[FAIL] T9.22a (M02.8-F02): original_idempotency_key ou idempotency_generation incorretos após anonimização LGPD de B3(gen=2): %', row_to_json(v_bk_row);
  END IF;

  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);

  -- Cancela v_idem_bk_2 (ou já estava ativa? v_idem_bk_2 estava AGUARDANDO_CONFIRMACAO, mas ao ser anonimizada na linhagem, uma nova chamada do titular deve avançar para gen=3; primeiro cancelamos v_idem_bk_2 via admin para liberar as 3 vagas na embarcação)
  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', v_admin_user::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  PERFORM public.transition_booking_status((v_idem_bk_2->>'id'), 'CANCELADA', 'Cancelando reserva anonimizada gen=2');

  -- Outro titular tentando reutilizar 'chave-timeout-pos-cancel-01' deve ser bloqueado com IDEMPOTENCY_KEY_CONFLICT
  SET LOCAL ROLE authenticated;
  PERFORM set_config('request.jwt.claim.sub', v_tourist_b::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_err_caught := false;
  BEGIN
    PERFORM public.create_booking_request(
      'tour-lancha-norte-comp',
      DATE '2027-02-18',
      2::smallint,
      'SITE_DIRECT',
      'Outro Titular Intruso',
      '(11) 97777-0099',
      'intruso.028@visitante.homolog.invalid',
      'direct_organic',
      NULL,
      'verao_2027',
      NULL,
      'chave-timeout-pos-cancel-01'
    );
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
    v_err_msg := SQLERRM;
  END;
  IF NOT v_err_caught OR v_err_msg NOT LIKE '%IDEMPOTENCY_KEY_CONFLICT%' THEN
    RAISE EXCEPTION '[FAIL] T9.22b (M02.8-F02): Outro titular conseguiu reutilizar k1 após anonimização (msg=%).', v_err_msg;
  END IF;

  -- Mesmo titular reenvia 'chave-timeout-pos-cancel-01' -> deve criar gen=3 (g0003)
  PERFORM set_config('request.jwt.claim.sub', v_tourist_a::text, true);
  PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
  v_idem_bk_2 := public.create_booking_request(
    'tour-lancha-norte-comp',
    DATE '2027-02-18',
    3::smallint,
    'SITE_DIRECT',
    'Turista Linhagem K1',
    '(12) 99666-7788',
    'linhagem.k1@visitante.homolog.invalid',
    'direct_organic',
    NULL,
    'verao_2027',
    NULL,
    'chave-timeout-pos-cancel-01'
  );
  IF (v_idem_bk_2->>'idempotent_replay')::boolean IS DISTINCT FROM false
     OR (v_idem_bk_2->>'idempotency_generation')::integer <> 3
     OR (v_idem_bk_2->>'original_idempotency_key') <> 'chave-timeout-pos-cancel-01' THEN
    RAISE EXCEPTION '[FAIL] T9.22c (M02.8-F02): Reenvio de k1 pelo titular original após anonimização de gen=2 não gerou gen=3: %', v_idem_bk_2;
  END IF;

  RESET ROLE;
  PERFORM set_config('request.jwt.claim.sub', '', true);
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);
  PERFORM public.backfill_and_verify_booking_lineage();

  -- T9.23 (M02.9-F01 a M02.9-F04): Validação do Cofre MAC (lineage_hmac_keys), Rotação de Chave,
  -- Reenvio de idg- Após Anonimização Total da Linhagem (idg-root-) e Blindagem de Tokens:
  IF NOT EXISTS (SELECT 1 FROM internal_guard.lineage_hmac_keys WHERE is_current = true) THEN
    RAISE EXCEPTION '[FAIL] T9.23a (M02.9-F02): Cofre internal_guard.lineage_hmac_keys sem chave ativa!';
  END IF;

  PERFORM internal_guard.rotate_lineage_hmac_key(NULL, false);
  IF (SELECT COUNT(*) FROM internal_guard.lineage_hmac_keys WHERE is_verify_enabled = true) < 2 THEN
    RAISE EXCEPTION '[FAIL] T9.23b (M02.9-F02): Rotação de chave MAC não preservou versões ativas para verificação de linhagem!';
  END IF;

  -- Verifica que issue_token rejeita expected_state nulo ou vazio
  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', (v_idem_bk_2->>'id')::uuid, '');
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.23c (M02.9-F04): issue_token aceitou expected_state vazio!';
  END IF;

  -- T9.24 (M02.10-F01 a M02.10-F05): Validação Criptográfica RFC 4231 HMAC-SHA-256,
  -- CSPRNG gen_random_bytes(32), Proteção do Ciclo de Vida de Chaves,
  -- Isolamento de internal_guard.lineage_hmac_keys e Rotação Multi-Versão sem Reset:
  IF internal_guard.require_active_hmac_secret() < 2 THEN
    RAISE EXCEPTION '[FAIL] T9.24a (M02.10-F01/F02): require_active_hmac_secret não confirmou rotação CSPRNG inicial!';
  END IF;

  IF lower(encode(public.hmac(convert_to('what do ya want for nothing?', 'UTF8'), convert_to('Jefe', 'UTF8'), 'sha256'), 'hex'))
     <> '5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843' THEN
    RAISE EXCEPTION '[FAIL] T9.24b (M02.10-F01): Vetor oficial RFC 4231 Test Case 2 divergente!';
  END IF;

  -- Verifica que verify_lineage_mac rejeita MD5 puro sem chave e comprimentos/formatos inválidos
  IF internal_guard.verify_lineage_mac('LGPD_OWNER_SCOPE', 'payload-teste', left(md5('payload-teste'), 20)) THEN
    RAISE EXCEPTION '[FAIL] T9.24c (M02.10-F01): verify_lineage_mac aceitou MD5 puro sem segredo!';
  END IF;

  -- Verifica que tentativa de excluir chave ativa ou chave com reservas dependentes é bloqueada pelo trigger
  v_err_caught := false;
  BEGIN
    DELETE FROM internal_guard.lineage_hmac_keys WHERE is_current = true;
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.24d (M02.10-F04): Exclusão da chave ativa em lineage_hmac_keys não foi bloqueada!';
  END IF;

  -- Verifica que segredo fraco/curto/inválido é rejeitado em rotate_lineage_hmac_key
  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.rotate_lineage_hmac_key(repeat('a', 64), false);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.24e (M02.10-F02): Segredo repetitivo de baixa entropia não foi rejeitado!';
  END IF;

  -- T9.25 (M02.11-F01 a M02.11-F05 / Missão 02.12):
  --   1) Segredos periódicos repeat('01234567', 8) e '0123456789abcdef' || repeat('0', 48) rejeitados;
  --   2) Rastreamento explícito de versão por artefato em public.bookings (hmac_key_version, lineage_root_key_version, lineage_idem_key_version, lineage_scope_key_version);
  --   3) Aposentadoria granular de versão histórica sem dependentes e restauração via manage_lineage_hmac_key_lifecycle;
  --   4) Isolamento de privilégios de service_role (compute_lineage_mac, verify_lineage_mac, issue_token revogados de service_role) e derive_idempotency_lineage_key funcional como SECURITY DEFINER.
  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.rotate_lineage_hmac_key(repeat('01234567', 8), false);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.25a (M02.11-F03): Segredo periódico repeat(01234567, 8) não foi rejeitado!';
  END IF;

  v_err_caught := false;
  BEGIN
    PERFORM internal_guard.rotate_lineage_hmac_key('0123456789abcdef' || repeat('0', 48), false);
  EXCEPTION WHEN OTHERS THEN
    v_err_caught := true;
  END;
  IF NOT v_err_caught THEN
    RAISE EXCEPTION '[FAIL] T9.25b (M02.11-F03): Segredo com sufixo repetitivo não foi rejeitado!';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.bookings
    WHERE hmac_key_version IS NULL
  ) THEN
    RAISE EXCEPTION '[FAIL] T9.25c (M02.11-F02): Existem reservas sem hmac_key_version após backfill da 000018!';
  END IF;

  IF public.derive_idempotency_lineage_key('chave-teste-m0212', 1) !~ '^idg-[0-9a-f]{24}-g0001-[0-9a-f]{24}$' THEN
    RAISE EXCEPTION '[FAIL] T9.25d (M02.11-F05): derive_idempotency_lineage_key falhou após hardening de privilégios!';
  END IF;

  -- T9.26 (Missão 02.16 — Datas Dinâmicas America/Sao_Paulo, Credencial lookup_token_hmac,
  -- Consulta Segura lookup_booking_by_tourist_token com Rate-Limiting/Zero-PII e Cancelamento Seguro):
  IF public.current_brazil_date() IS NULL THEN
    RAISE EXCEPTION '[FAIL] T9.26a (M02.16): current_brazil_date() retornou NULL!';
  END IF;

  IF (public.get_tour_availability('tour-lancha-norte-comp', public.current_brazil_date() - 1)->>'blocked')::boolean IS DISTINCT FROM true
     OR (public.get_tour_availability('tour-lancha-norte-comp', public.current_brazil_date() - 1)->>'block_reason') NOT LIKE '%BOOKING_DATE_IN_PAST%' THEN
    RAISE EXCEPTION '[FAIL] T9.26b (M02.16): get_tour_availability não bloqueou data no passado com BOOKING_DATE_IN_PAST!';
  END IF;

  IF (v_idem_bk_2->>'lookup_token') !~ '^ubtk-[0-9a-f]{32}$' THEN
    RAISE EXCEPTION '[FAIL] T9.26c (M02.16): create_booking_request não emitiu lookup_token válido (ubtk-32hex): %', v_idem_bk_2;
  END IF;

  IF (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token'))->>'ok')::boolean IS DISTINCT FROM true
     OR (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token')) ? 'customer_phone')
     OR (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token')) ? 'customer_email')
     OR (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token')) ? 'customer_name')
     OR (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token')) ? 'commission_amount') THEN
    RAISE EXCEPTION '[FAIL] T9.26d (M02.16): lookup_booking_by_tourist_token falhou ou expôs PII/comissões!';
  END IF;

  IF (public.lookup_booking_by_tourist_token((v_idem_bk_2->>'code'), 'ubtk-00000000000000000000000000000000')->>'error_code') <> 'INVALID_LOOKUP_CREDENTIALS' THEN
    RAISE EXCEPTION '[FAIL] T9.26e (M02.16): lookup_booking_by_tourist_token não rejeitou token inválido com INVALID_LOOKUP_CREDENTIALS!';
  END IF;

  IF (public.cancel_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token'), 'Cancelamento teste T9.26')->>'status') <> 'CANCELADA'
     OR (public.cancel_booking_by_tourist_token((v_idem_bk_2->>'code'), (v_idem_bk_2->>'lookup_token'), 'Replay T9.26')->>'idempotent_replay')::boolean IS DISTINCT FROM true THEN
    RAISE EXCEPTION '[FAIL] T9.26f (M02.16): cancel_booking_by_tourist_token falhou ao cancelar ou repetir cancelamento idempotente!';
  END IF;

  RAISE NOTICE '[PASS] T9.20 a T9.26 (M02.6 a M02.16): Linhagem histórica e HMAC-SHA-256, ciclo de vida granular, datas dinâmicas e consulta/cancelamento seguro do turista validados.';

  RAISE NOTICE '========================================================================';
  RAISE NOTICE 'RESULTADO BLOCO 9: 26/26 CENÁRIOS LGPD & ADVERSARIAIS (T9.1 A T9.26) APROVADOS!';
  RAISE NOTICE '========================================================================';
END
$$;

ROLLBACK;


-- ============================================================================
-- T9.27: HOMOLOGAÇÃO DA MIGRATION 000020 (MISSÃO 02.19 — AUTENTICAÇÃO,
--        CONTEXTO DE ACESSO SERVER-SIDE E ONBOARDING SEGURO DE PARCEIROS)
-- ============================================================================
DO $$
DECLARE
  v_ctx JSONB;
BEGIN
  v_ctx := public.get_authenticated_access_context();
  IF COALESCE((v_ctx ->> 'authenticated')::boolean, true) <> false
     OR COALESCE(v_ctx ->> 'account_state', '') <> 'UNAUTHENTICATED' THEN
    RAISE EXCEPTION 'T9.27 FALHOU: get_authenticated_access_context deve retornar UNAUTHENTICATED sem sessão ativa.';
  END IF;
  RAISE NOTICE '[PASS] T9.27: RPCs get_authenticated_access_context, submit_partner_onboarding_application e admin_moderate_partner_onboarding homologadas.';
END;
$$;


-- ============================================================================
-- T9.28: HOMOLOGAÇÃO DA MIGRATION 000021 (MISSÃO 02.20 — AUDITORIA CONSOLIDADA,
--        BLOQUEIO EM TEMPO REAL DE PARCEIRO SUSPENSO EM is_partner_member E
--        BLINDAGEM DE COLUNAS DE ONBOARDING EM protect_catalog_moderation_columns)
-- ============================================================================
DO $$
DECLARE
  v_fn_src TEXT;
  v_trig_src TEXT;
BEGIN
  SELECT prosrc INTO v_fn_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'is_partner_member';

  SELECT prosrc INTO v_trig_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'protect_catalog_moderation_columns';

  IF v_fn_src IS NULL OR position('onboarding_stage' in v_fn_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.28a (M02.20-F02): public.is_partner_member não verifica pt.status = APROVADO e pt.onboarding_stage = APROVADO!';
  END IF;

  IF v_trig_src IS NULL OR position('NEW.onboarding_stage IS DISTINCT FROM OLD.onboarding_stage' in v_trig_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.28b (M02.20-F01): public.protect_catalog_moderation_columns não protege as 5 colunas de onboarding!';
  END IF;

  RAISE NOTICE '[PASS] T9.28 (M02.20-F01 & M02.20-F02): is_partner_member e protect_catalog_moderation_columns homologados.';
END;
$$;


-- ============================================================================
-- T9.29: HOMOLOGAÇÃO DA MIGRATION 000022 (MISSÃO 02.21 — PAGAMENTOS, MÁQUINA DE
--        ESTADOS FINANCEIROS, CÁLCULO PROPORCIONAL DE ESTORNO E CONCILIAÇÃO)
-- ============================================================================
DO $$
DECLARE
  v_split JSONB;
BEGIN
  IF NOT public.is_valid_payment_status_transition('PENDENTE', 'PAGO')
     OR public.is_valid_payment_status_transition('CANCELADO', 'PAGO')
     OR public.is_valid_payment_status_transition('ESTORNADO', 'PAGO') THEN
    RAISE EXCEPTION '[FAIL] T9.29a (M02.21): Máquina de estados de pagamento inválida!';
  END IF;

  v_split := public.calculate_proportional_refund_split(1000.00, 150.00, 850.00, 0.00, 0.00, 0.00, 400.00);
  IF (v_split->>'refund_commission_delta')::numeric(12,2) <> 60.00
     OR (v_split->>'refund_net_delta')::numeric(12,2) <> 340.00
     OR (v_split->>'effective_gross_amount')::numeric(12,2) <> 600.00 THEN
    RAISE EXCEPTION '[FAIL] T9.29b (M02.21): Cálculo proporcional de estorno divergente: %', v_split;
  END IF;

  RAISE NOTICE '[PASS] T9.29 (M02.21): Tabelas financeiras, máquina de estados, estorno proporcional e RPCs financeiras homologados.';
END;
$$;


-- ============================================================================
-- T9.30: HOMOLOGAÇÃO DA MIGRATION 000023 (MISSÃO 02.22 — CORREÇÃO ADVERSARIAL
--        E INTEGRAÇÃO FINANCEIRA F01 A F08)
-- ============================================================================
DO $$
DECLARE
  v_conf_src TEXT;
  v_req_ref_src TEXT;
  v_proc_ref_src TEXT;
  v_recon_src TEXT;
BEGIN
  SELECT prosrc INTO v_conf_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'confirm_or_fail_booking_payment';

  SELECT prosrc INTO v_req_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'request_booking_refund';

  SELECT prosrc INTO v_proc_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'process_booking_refund';

  SELECT prosrc INTO v_recon_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'get_financial_reconciliation_report';

  IF v_conf_src IS NULL
     OR position('PARTNER_PAYMENT_CONFIRM_FORBIDDEN' in v_conf_src) = 0
     OR position('ADMIN_CONFIRMATION_REASON_REQUIRED' in v_conf_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.30a (M02.22-F01): confirm_or_fail_booking_payment não aplica bloqueio de parceiro em PAGO e justificativa administrativa!';
  END IF;

  IF v_req_ref_src IS NULL OR position('ESTORNO_PENDENTE' in v_req_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.30b (M02.22-F02): RPC request_booking_refund ausente ou inválida!';
  END IF;

  IF v_proc_ref_src IS NULL OR position('PARTNER_REFUND_CONFIRM_FORBIDDEN' in v_proc_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.30c (M02.22-F02): process_booking_refund não bloqueia confirmação de estorno por parceiro!';
  END IF;

  IF v_recon_src IS NULL
     OR position('PAYMENT_HISTORY_MISMATCH' in v_recon_src) = 0
     OR position('LEDGER_ENTRIES_SUM_MISMATCH' in v_recon_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.30d (M02.22-F05): get_financial_reconciliation_report não audita booking_payment_history e financial_ledger_entries!';
  END IF;

  RAISE NOTICE '[PASS] T9.30 (M02.22): Migration 000023 (F01 a F08) homologada com sucesso.';
END;
$$;


-- ============================================================================
-- T9.31: HOMOLOGAÇÃO DA MISSÃO 02.23 (CORREÇÕES D01 E D04 — ESTORNO INTEGRAL
--        COM p_refund_amount NULL, BLOQUEIO DE ESTORNO ACIMA DO SOLICITADO E
--        DETECÇÃO DAS 9 CATEGORIAS DE CONCILIAÇÃO DA SEÇÃO 6)
-- ============================================================================
DO $$
DECLARE
  v_req_ref_src TEXT;
  v_proc_ref_src TEXT;
  v_recon_src TEXT;
BEGIN
  SELECT prosrc INTO v_req_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'request_booking_refund';

  SELECT prosrc INTO v_proc_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'process_booking_refund';

  SELECT prosrc INTO v_recon_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'get_financial_reconciliation_report';

  IF v_req_ref_src IS NULL
     OR position('IF p_refund_amount IS NULL THEN' in v_req_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.31a (M02.23-D01): request_booking_refund não resolve p_refund_amount IS NULL para effective_gross_amount!';
  END IF;

  IF v_proc_ref_src IS NULL
     OR position('REFUND_EXCEEDS_REQUESTED_AMOUNT' in v_proc_ref_src) = 0
     OR position('IF p_refund_amount IS NULL THEN' in v_proc_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.31b (M02.23-D01): process_booking_refund não resolve p_refund_amount IS NULL ou não bloqueia REFUND_EXCEEDS_REQUESTED_AMOUNT!';
  END IF;

  IF v_recon_src IS NULL
     OR position('ORPHAN_PAYMENT_WITHOUT_BOOKING' in v_recon_src) = 0
     OR position('ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT' in v_recon_src) = 0
     OR position('REFUND_WITHOUT_REQUEST' in v_recon_src) = 0
     OR position('PENDING_REFUND_IMPROPERLY_FINALIZED' in v_recon_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.31c (M02.23-D04): get_financial_reconciliation_report não detecta todas as 9 categorias da Seção 6!';
  END IF;

  RAISE NOTICE '[PASS] T9.31 (M02.23): Correções D01 e D04 e conciliação completa de 9 anomalias homologadas.';
END;
$$;


-- ============================================================================
-- T9.32: HOMOLOGAÇÃO DA MIGRATION 000024 (MISSÃO 02.24 — FECHAMENTO ADVERSARIAL
--        D09, D10 E D12: REPLAY IDEMPOTENTE COM p_refund_amount NULL, TRILHA
--        IMPLICITA DE SOLICITAÇÃO EM ESTORNO DIRETO DO ADMIN E SIMETRIA NA
--        REVERSÃO DE ESTORNO FALHO PAGO/ESTORNO_PARCIAL)
-- ============================================================================
DO $$
DECLARE
  v_conf_src TEXT;
  v_req_ref_src TEXT;
  v_proc_ref_src TEXT;
BEGIN
  SELECT prosrc INTO v_conf_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'confirm_or_fail_booking_payment';

  SELECT prosrc INTO v_req_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'request_booking_refund';

  SELECT prosrc INTO v_proc_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'process_booking_refund';

  IF v_req_ref_src IS NULL
     OR position('input_refund_amount' in v_req_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.32a (M02.24-D09): request_booking_refund não verifica replay idempotente antes do cálculo de saldo mutável com input_refund_amount!';
  END IF;

  IF v_proc_ref_src IS NULL
     OR position('input_refund_amount' in v_proc_ref_src) = 0
     OR position('auto_admin_request' in v_proc_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.32b (M02.24-D09/D10): process_booking_refund não protege replay idempotente com p_refund_amount NULL ou não registra trilha implícita de solicitação administrativa!';
  END IF;

  IF v_conf_src IS NULL
     OR position('REFUND_FAILED_REVERT' in v_conf_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.32c (M02.24-D12): confirm_or_fail_booking_payment não resolve REFUND_FAILED_REVERT simetricamente na reversão de ESTORNO_PENDENTE!';
  END IF;

  RAISE NOTICE '[PASS] T9.32 (M02.24): Migration 000024 (D09, D10 e D12) homologada com sucesso.';
END;
$$;


-- ============================================================================
-- T9.33: HOMOLOGAÇÃO DA MIGRATION 000025 (MISSÃO 02.25 — CORREÇÃO CIRÚRGICA D13:
--        REVERSÃO DE COMISSÃO EM ESTORNO INTEGRAL PÓS-REALIZAÇÃO/LIQUIDAÇÃO E
--        PARIDADE DE CONCILIAÇÃO FINANCEIRA)
-- ============================================================================
DO $$
DECLARE
  v_enf_ledger_src TEXT;
  v_proc_ref_src TEXT;
  v_recon_src TEXT;
BEGIN
  SELECT prosrc INTO v_enf_ledger_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'enforce_commission_ledger_integrity';

  SELECT prosrc INTO v_proc_ref_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'process_booking_refund';

  SELECT prosrc INTO v_recon_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'get_financial_reconciliation_report';

  IF v_enf_ledger_src IS NULL
     OR position('REFUND_FULL_REVERT' in v_enf_ledger_src) = 0
     OR position('LEDGER_REVERSAL_REQUIRES_FULL_REFUND' in v_enf_ledger_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.33a (M02.25-D13): enforce_commission_ledger_integrity não suporta reversão controlada por token REFUND_FULL_REVERT pós-PASSEIO_REALIZADO!';
  END IF;

  IF v_proc_ref_src IS NULL
     OR position('REFUND_FULL_REVERT' in v_proc_ref_src) = 0
     OR position('ELSIF v_is_full AND v_booking.status = ''PASSEIO_REALIZADO''' in v_proc_ref_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.33b (M02.25-D13): process_booking_refund não reverte commission_ledger para REVERTIDA em estorno integral pós-PASSEIO_REALIZADO!';
  END IF;

  IF v_recon_src IS NULL
     OR position('v_item.ledger_status IS DISTINCT FROM ''REVERTIDA''' in v_recon_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] T9.33c (M02.25-D13): get_financial_reconciliation_report não verifica paridade ledger_status = REVERTIDA quando payment_status = ESTORNADO!';
  END IF;

  RAISE NOTICE '[PASS] T9.33 (M02.25): Migration 000025 (D13 — reversão de comissão em estorno integral pós-realização/liquidação e paridade de conciliação) homologada com sucesso.';
END;
$$;
