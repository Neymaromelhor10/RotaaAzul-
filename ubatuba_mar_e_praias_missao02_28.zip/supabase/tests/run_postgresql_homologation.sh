#!/usr/bin/env -S env -u BASH_ENV -u ENV bash
# ============================================================================
# UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.2
# SCRIPT EXECUTÁVEL DE HOMOLOGAÇÃO EM POSTGRESQL 15+ REAL / DOCKER DESCARTÁVEL
# Arquivo: supabase/tests/run_postgresql_homologation.sh
#
# Correções implementadas (M01.9-001, M01.9-003, M02.0-F04/F06/F07, M02.2-F03/F04):
#   1. Sanitização de variáveis de ambiente libpq (`unset PGHOST PGHOSTADDR ...`)
#      para impedir que variáveis de sessão externas sobrescrevam a conexão (M02.2-F03).
#   2. Separação estrita entre `URL_AUTHORITY` (antes do 1º `/`) e `URL_PATH_AND_QUERY`
#      (após o 1º `/`), impedindo que um `@` na query string (`?application_name=x@127.0.0.1...`)
#      engane o extrator `##*@` de host (M02.2-F03).
#   3. Bloqueio de `#` (fragmentos), `%` (percent-encoding em host/dbname/query) e
#      whitelist estrita de query string (`sslmode`, `connect_timeout`, `application_name`),
#      bloqueando `?host=`, `?hostaddr=`, `?dbname=`, `?user=`, `?service=`, `?passfile=`,
#      `?options=`, `?target_session_attrs=` e equivalentes codificados (M02.0-F06 / M02.2-F03).
#   4. Verificação de preexistência do container (`CONTAINER_ALREADY_EXISTS`) antes do
#      `docker run` para evitar colisões em execuções paralelas (M02.2-F04).
#   5. Preservação do `exit_code` original, tratamento de `EXIT`, `INT` (`130`) e `TERM` (`143`)
#      e verificação de porta TCP local livre (`PORT_IN_USE`) (M02.0-F07).
#   6. Reaplicação transacional atômica (`psql --single-transaction`) de `000003` a `000009`
#      e auditoria pós-reaplicação de `pg_policies` e `pg_proc` (M02.0-F04).
# ============================================================================

set -euo pipefail
# D14 (Missão 02.25): Sanitiza BASH_ENV e ENV para impedir que arquivos de inicialização alterem o diretório corrente em subshells
unset BASH_ENV ENV

# M02.2-F03: Remove variáveis de ambiente da libpq que poderiam redirecionar ou alterar a conexão psql
unset PGHOST PGHOSTADDR PGPORT PGDATABASE PGUSER PGPASSWORD PGSERVICE PGSERVICEFILE PGPASSFILE PGOPTIONS PGSSLMODE PGREQUIRESSL PGKRBSRVNAME PGTARGETSESSIONATTRS PGAPPNAME PGCLIENTENCODING PGCONNECT_TIMEOUT PGGSSLIB PGSSLKEY PGSSLCERT PGSSLROOTCERT PGSSLCRL PGCHANNELBINDING

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$PROJECT_ROOT"

EXECUTION_MODE="external_url"
KEEP_CONTAINER=0
STOP_CONTAINER_ONLY=0
CUSTOM_RUN_ID=""
SKIP_POST_RESET_SUITES="${UBATUBA_TEST_ONLY_RESET_GUARD:-0}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --docker)
      EXECUTION_MODE="docker"
      shift
      ;;
    --keep-container)
      KEEP_CONTAINER=1
      shift
      ;;
    --stop-container)
      STOP_CONTAINER_ONLY=1
      shift
      ;;
    --run-id)
      if [[ -z "${2:-}" ]]; then
        echo "[RUNNER_GUARD_ABORT] A opção --run-id exige um identificador não vazio." >&2
        exit 3
      fi
      CUSTOM_RUN_ID="$2"
      shift 2
      ;;
    *)
      echo "[RUNNER_GUARD_ABORT] Argumento desconhecido: $1" >&2
      exit 3
      ;;
  esac
done

if [[ -n "$CUSTOM_RUN_ID" ]]; then
  if [[ ! "$CUSTOM_RUN_ID" =~ ^[A-Za-z0-9_.-]+$ ]]; then
    echo "[RUNNER_GUARD_ABORT] Identificador --run-id inválido: '$CUSTOM_RUN_ID'." >&2
    exit 3
  fi
  MISSION_RUN_ID="$CUSTOM_RUN_ID"
else
  MISSION_RUN_ID="m022_$(date -u +%Y%m%dT%H%M%SZ)_$$"
fi

CONTAINER_NAME="ubatuba_homolog_pg15_${MISSION_RUN_ID}"
DISPOSABLE_DOCKER_DB="ubatuba_homolog_disposable"
CONTAINER_STARTED_BY_THIS_RUN=0
CLEANUP_ALREADY_RAN=0
FORCED_SIGNAL_EXIT_CODE=0

cleanup_owned_container() {
  local original_rc=$?
  set +e
  if [[ "$FORCED_SIGNAL_EXIT_CODE" -ne 0 ]]; then
    original_rc="$FORCED_SIGNAL_EXIT_CODE"
  fi
  if [[ "$CLEANUP_ALREADY_RAN" -eq 1 ]]; then
    return "$original_rc"
  fi
  CLEANUP_ALREADY_RAN=1

  if [[ "$CONTAINER_STARTED_BY_THIS_RUN" -ne 1 ]]; then
    return "$original_rc"
  fi
  if [[ "$KEEP_CONTAINER" -eq 1 ]]; then
    echo "[CONTAINER_PERSISTIDO] Container '$CONTAINER_NAME' (run_id=$MISSION_RUN_ID) mantido ativo para inspeção."
    echo "Para encerrar manualmente: bash supabase/tests/run_postgresql_homologation.sh --stop-container --run-id $MISSION_RUN_ID"
    return "$original_rc"
  fi
  if command -v docker >/dev/null 2>&1; then
    local owner_label
    owner_label="$(docker inspect -f '{{ index .Config.Labels "com.ubatuba.mission_run_id" }}' "$CONTAINER_NAME" 2>/dev/null || true)"
    if [[ "$owner_label" == "$MISSION_RUN_ID" ]]; then
      echo "=== Encerrando e removendo container descartável da execução atual ($CONTAINER_NAME, exit_code=$original_rc) ==="
      docker stop "$CONTAINER_NAME" >/dev/null 2>&1 || true
      docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
    fi
  fi
  return "$original_rc"
}

handle_interrupt_signal() {
  local sig_rc="$1"
  FORCED_SIGNAL_EXIT_CODE="$sig_rc"
  echo "[RUNNER_SIGNAL_ABORT] Sinal de interrupção recebido (exit_code=$sig_rc). Executando limpeza segura..." >&2
  cleanup_owned_container || true
  exit "$sig_rc"
}

is_local_tcp_port_free() {
  local candidate_port="$1"
  if [[ "${MOCK_BUSY_PORT:-}" == "$candidate_port" ]]; then
    return 1
  fi
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$candidate_port" <<'PY'
import socket
import sys
port = int(sys.argv[1])
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind(("127.0.0.1", port))
except OSError:
    sys.exit(1)
finally:
    s.close()
sys.exit(0)
PY
    return $?
  fi
  return 0
}

# Encerramento manual explícito de container persistido com --keep-container --run-id <ID>
if [[ "$STOP_CONTAINER_ONLY" -eq 1 ]]; then
  if [[ -z "$CUSTOM_RUN_ID" ]]; then
    echo "[RUNNER_GUARD_ABORT] --stop-container exige --run-id <ID> explícito para verificar propriedade." >&2
    exit 3
  fi
  if ! command -v docker >/dev/null 2>&1; then
    echo "[HOMOLOGAÇÃO POSTGRESQL REAL: PENDENTE] Docker não está disponível neste ambiente." >&2
    exit 2
  fi
  OWNER_LABEL="$(docker inspect -f '{{ index .Config.Labels "com.ubatuba.mission_run_id" }}' "$CONTAINER_NAME" 2>/dev/null || true)"
  if [[ "$OWNER_LABEL" != "$MISSION_RUN_ID" ]]; then
    echo "[RUNNER_GUARD_ABORT] Container '$CONTAINER_NAME' não pertence ao run_id '$MISSION_RUN_ID' (label='$OWNER_LABEL'). Operação recusada." >&2
    exit 3
  fi
  docker stop "$CONTAINER_NAME" >/dev/null 2>&1 || true
  docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
  echo "[OK] Container descartável '$CONTAINER_NAME' (run_id=$MISSION_RUN_ID) encerrado com segurança."
  exit 0
fi

# ----------------------------------------------------------------------------
# MODO A: DOCKER DESCARTÁVEL (--docker)
# ----------------------------------------------------------------------------
if [[ "$EXECUTION_MODE" == "docker" ]]; then
  if ! command -v docker >/dev/null 2>&1; then
    echo "[HOMOLOGAÇÃO POSTGRESQL REAL: PENDENTE] Docker não encontrado no PATH deste ambiente."
    exit 2
  fi
  if ! command -v psql >/dev/null 2>&1; then
    echo "[HOMOLOGAÇÃO POSTGRESQL REAL: PENDENTE] Utilitário 'psql' não está instalado neste ambiente."
    exit 2
  fi

  # M02.2-F04: Impede colisão com container preexistente de mesmo nome
  if docker inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
    echo "[RUNNER_GUARD_ABORT] [CONTAINER_ALREADY_EXISTS] Já existe um container ativo ou parado com nome '$CONTAINER_NAME'." >&2
    exit 3
  fi

  # Verificação de disponibilidade da porta local antes de subir o container (M02.0-F07)
  if [[ -n "${UBATUBA_DOCKER_PORT:-}" ]]; then
    if [[ ! "$UBATUBA_DOCKER_PORT" =~ ^[0-9]{4,5}$ ]] || (( UBATUBA_DOCKER_PORT < 1024 || UBATUBA_DOCKER_PORT > 65535 )); then
      echo "[RUNNER_GUARD_ABORT] Porta UBATUBA_DOCKER_PORT inválida: '$UBATUBA_DOCKER_PORT'." >&2
      exit 3
    fi
    if ! is_local_tcp_port_free "$UBATUBA_DOCKER_PORT"; then
      echo "[RUNNER_GUARD_ABORT] [PORT_IN_USE] A porta local solicitada ($UBATUBA_DOCKER_PORT) já está em uso." >&2
      exit 3
    fi
    DOCKER_HOST_PORT="$UBATUBA_DOCKER_PORT"
  else
    BASE_CANDIDATE_PORT=$(( 55400 + ($$ % 400) ))
    DOCKER_HOST_PORT=""
    for offset in $(seq 0 50); do
      CAND_PORT=$(( BASE_CANDIDATE_PORT + offset ))
      if is_local_tcp_port_free "$CAND_PORT"; then
        DOCKER_HOST_PORT="$CAND_PORT"
        break
      fi
    done
    if [[ -z "$DOCKER_HOST_PORT" ]]; then
      echo "[RUNNER_GUARD_ABORT] [PORT_IN_USE] Nenhuma porta TCP livre encontrada na faixa ${BASE_CANDIDATE_PORT}..$((BASE_CANDIDATE_PORT + 50))." >&2
      exit 3
    fi
  fi

  trap cleanup_owned_container EXIT
  trap 'handle_interrupt_signal 130' INT
  trap 'handle_interrupt_signal 143' TERM

  echo "=== Subindo container PostgreSQL 15 descartável isolado (run_id=$MISSION_RUN_ID, port=$DOCKER_HOST_PORT) ==="
  docker run -d \
    --name "$CONTAINER_NAME" \
    --label "com.ubatuba.mission_run_id=$MISSION_RUN_ID" \
    --label "com.ubatuba.disposable_homolog=true" \
    --tmpfs /var/lib/postgresql/data:rw \
    -e POSTGRES_USER=postgres \
    -e POSTGRES_PASSWORD=postgres \
    -e POSTGRES_DB="$DISPOSABLE_DOCKER_DB" \
    -p "127.0.0.1:${DOCKER_HOST_PORT}:5432" \
    postgres:15-alpine >/dev/null

  CONTAINER_STARTED_BY_THIS_RUN=1

  export DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:${DOCKER_HOST_PORT}/${DISPOSABLE_DOCKER_DB}"
  export UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB="CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO"

  echo "=== Aguardando prontidão real do PostgreSQL 15 no container '$CONTAINER_NAME' ==="
  READY=0
  for _ in $(seq 1 30); do
    if psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -t -A -c "SELECT 1;" >/dev/null 2>&1; then
      READY=1
      break
    fi
    sleep 1
  done
  if [[ "$READY" -ne 1 ]]; then
    echo "[RUNNER_GUARD_ABORT] Timeout aguardando prontidão do container PostgreSQL '$CONTAINER_NAME'." >&2
    exit 3
  fi
fi

# ----------------------------------------------------------------------------
# VERIFICAÇÃO DE DISPONIBILIDADE DO CLIENTE psql E DA DATABASE_URL
# ----------------------------------------------------------------------------
if ! command -v psql >/dev/null 2>&1; then
  echo "[HOMOLOGAÇÃO POSTGRESQL REAL: PENDENTE] Utilitário 'psql' não está instalado neste ambiente."
  echo "Execute em máquina com PostgreSQL 15+ / Docker: bash supabase/tests/run_postgresql_homologation.sh --docker"
  exit 2
fi

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "[RUNNER_GUARD_ABORT] Variável DATABASE_URL não definida. Operação abortada antes de qualquer conexão." >&2
  exit 3
fi

# ----------------------------------------------------------------------------
# CAMADA 1 (ESTÁTICA / PRÉ-CONEXÃO): VALIDAÇÃO ENDURECIDA DA DATABASE_URL (M02.0-F06 & M02.2-F03)
# ----------------------------------------------------------------------------
REQUIRED_CONFIRM_VALUE="CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO"
if [[ "${UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB:-}" != "$REQUIRED_CONFIRM_VALUE" ]]; then
  echo "[RUNNER_GUARD_ABORT] Execução bloqueada: UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB ausente ou diferente de '$REQUIRED_CONFIRM_VALUE'." >&2
  exit 3
fi

# Rejeita espaços, caracteres de controle ou fragmentos '#' na URL
if [[ "$DATABASE_URL" =~ [[:space:][:cntrl:]#] ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL inválida: contém espaços, caracteres de controle ou fragmento '#'." >&2
  exit 3
fi

URL_WITHOUT_PROTO="${DATABASE_URL#postgresql://}"
URL_WITHOUT_PROTO="${URL_WITHOUT_PROTO#postgres://}"

if [[ "$URL_WITHOUT_PROTO" == "$DATABASE_URL" ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL deve iniciar com postgresql:// ou postgres://." >&2
  exit 3
fi

# M02.2-F03: Separa PRIMEIRO a autoridade (userinfo@host:port) do caminho (/dbname?query) no PRIMEIRO '/'
if [[ "$URL_WITHOUT_PROTO" != *"/"* ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL sem separador de caminho '/<database>'." >&2
  exit 3
fi

URL_AUTHORITY="${URL_WITHOUT_PROTO%%/*}"
URL_PATH_AND_QUERY="${URL_WITHOUT_PROTO#*/}"

# Exige presença explícita de credenciais/usuário com '@' DENTRO da autoridade
if [[ "$URL_AUTHORITY" != *"@"* ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL ambígua: deve especificar explicitamente usuario@host:porta/banco." >&2
  exit 3
fi

# Extração gulosa (##*@) aplicada EXCLUSIVAMENTE dentro de URL_AUTHORITY (suporta '@' na senha e impede bypass via '@' na query string)
URL_HOST_PORT="${URL_AUTHORITY##*@}"
URL_CREDENTIALS_PART="${URL_AUTHORITY%@*}"
URL_USER_NAME="${URL_CREDENTIALS_PART%%:*}"

if [[ -z "$URL_USER_NAME" ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL sem identificação de usuário." >&2
  exit 3
fi

# Extrai host e porta opcional (suportando IPv6 entre colchetes [::1]:54322 ou IPv4/hostname)
if [[ "$URL_HOST_PORT" =~ ^\[([^]]+)\](:([0-9]+))?$ ]]; then
  URL_HOST="[${BASH_REMATCH[1]}]"
  URL_PORT="${BASH_REMATCH[3]:-5432}"
elif [[ "$URL_HOST_PORT" =~ ^([^:]+)(:([0-9]+))?$ ]]; then
  URL_HOST="${BASH_REMATCH[1]}"
  URL_PORT="${BASH_REMATCH[3]:-5432}"
else
  echo "[RUNNER_GUARD_ABORT] Formato de host:porta inválido na DATABASE_URL." >&2
  exit 3
fi

if (( 10#$URL_PORT < 1 || 10#$URL_PORT > 65535 )); then
  echo "[RUNNER_GUARD_ABORT] Porta fora do intervalo válido na DATABASE_URL: '$URL_PORT'." >&2
  exit 3
fi

# Inspeciona a query string ANTES de removê-la (M02.0-F06 & M02.2-F03):
if [[ "$URL_PATH_AND_QUERY" == *"?"* ]]; then
  URL_DB_NAME="${URL_PATH_AND_QUERY%%\?*}"
  URL_QUERY_STRING="${URL_PATH_AND_QUERY#*\?}"
  if [[ "$URL_QUERY_STRING" == *"?"* ]]; then
    echo "[RUNNER_GUARD_ABORT] DATABASE_URL contém múltiplos '?' na query string." >&2
    exit 3
  fi
  URL_QUERY_LOWER="$(printf '%s' "$URL_QUERY_STRING" | tr '[:upper:]' '[:lower:]')"
  if [[ "$URL_QUERY_LOWER" =~ (^|&|;)(host|hostaddr|dbname|user|password|service|passfile|options|target_session_attrs)(=|%3d) ]]; then
    echo "[RUNNER_GUARD_ABORT] [QUERY_PARAM_FORBIDDEN] Parâmetro de redirecionamento proibido detectado na query string da DATABASE_URL ('${BASH_REMATCH[2]}=')." >&2
    exit 3
  fi
  if [[ "$URL_QUERY_STRING" == *"%"* || "$URL_QUERY_STRING" == *"@"* ]]; then
    echo "[RUNNER_GUARD_ABORT] [QUERY_PARAM_FORBIDDEN] Percent-encoding ou '@' não permitido na query string da DATABASE_URL." >&2
    exit 3
  fi
  IFS='&;' read -r -a QUERY_PAIRS <<< "$URL_QUERY_STRING"
  for pair in "${QUERY_PAIRS[@]}"; do
    if [[ -z "$pair" ]]; then
      continue
    fi
    if [[ ! "$pair" =~ ^(sslmode|connect_timeout|application_name)=[A-Za-z0-9_.-]+$ ]]; then
      echo "[RUNNER_GUARD_ABORT] [QUERY_PARAM_FORBIDDEN] Parâmetro de query não autorizado na DATABASE_URL: '$pair'." >&2
      exit 3
    fi
  done
else
  URL_DB_NAME="$URL_PATH_AND_QUERY"
fi

if [[ -z "$URL_HOST" || -z "$URL_DB_NAME" || "$URL_DB_NAME" == *"/"* || "$URL_HOST" == *"%"* || "$URL_DB_NAME" == *"%"* ]]; then
  echo "[RUNNER_GUARD_ABORT] DATABASE_URL sem host ou com nome de banco inválido." >&2
  exit 3
fi

# Bloqueia qualquer host que não seja estritamente local
case "$URL_HOST" in
  127.0.0.1|localhost|::1|"[::1]")
    ;;
  *)
    echo "[RUNNER_GUARD_ABORT] Host externo ou não autorizado detectado na DATABASE_URL ('$URL_HOST'). Somente 127.0.0.1/localhost é permitido." >&2
    exit 3
    ;;
esac

# Rejeita explicitamente nomes proibidos ou de produção/default
URL_DB_LOWER="$(printf '%s' "$URL_DB_NAME" | tr '[:upper:]' '[:lower:]')"
if [[ "$URL_DB_LOWER" == "postgres" || "$URL_DB_LOWER" == "defaultdb" || "$URL_DB_LOWER" == "supabase" || "$URL_DB_LOWER" == "template0" || "$URL_DB_LOWER" == "template1" ]]; then
  echo "[RUNNER_GUARD_ABORT] Nome de banco padrão/sistema proibido para reset destrutivo: '$URL_DB_NAME'." >&2
  exit 3
fi

if [[ "$URL_DB_LOWER" =~ (prod|production|prd|live|main|master|staging_real) ]]; then
  echo "[RUNNER_GUARD_ABORT] Nome de banco contém marcador de ambiente protegido/produção: '$URL_DB_NAME'." >&2
  exit 3
fi

# Exige o padrão estrito ^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$
if [[ ! "$URL_DB_NAME" =~ ^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$ ]]; then
  echo "[RUNNER_GUARD_ABORT] Nome de banco '$URL_DB_NAME' fora do padrão obrigatório '^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$'." >&2
  exit 3
fi

if [[ "$EXECUTION_MODE" == "docker" && "$URL_DB_NAME" != "$DISPOSABLE_DOCKER_DB" ]]; then
  echo "[RUNNER_GUARD_ABORT] No modo --docker o banco deve ser exclusivamente '$DISPOSABLE_DOCKER_DB' (recebido: '$URL_DB_NAME')." >&2
  exit 3
fi

echo "=== 0.1. Verificação de Identidade do Servidor e Reset Atômico na Mesma Sessão/Conexão (M01.9-001 & M02.2-F03) ==="
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 \
  -v expected_db="$URL_DB_NAME" \
  -v confirm_token="${UBATUBA_CONFIRM_DISPOSABLE_HOMOLOG_DB:-}" \
  -v execution_mode="$EXECUTION_MODE" \
  -v mission_run_id="$MISSION_RUN_ID" <<'SQL'
SELECT set_config('ubatuba.expected_db', :'expected_db', false);
SELECT set_config('ubatuba.confirm_token', :'confirm_token', false);
SELECT set_config('ubatuba.execution_mode', :'execution_mode', false);
SELECT set_config('ubatuba.mission_run_id', :'mission_run_id', false);

DO $guard$
DECLARE
  v_cur_db TEXT;
  v_cur_user TEXT;
  v_sess_user TEXT;
  v_srv_addr INET;
  v_srv_host TEXT;
  v_srv_port INTEGER;
  v_expected_db TEXT := COALESCE(current_setting('ubatuba.expected_db', true), '');
  v_confirm_token TEXT := COALESCE(current_setting('ubatuba.confirm_token', true), '');
  v_exec_mode TEXT := COALESCE(current_setting('ubatuba.execution_mode', true), '');
  v_run_id TEXT := COALESCE(current_setting('ubatuba.mission_run_id', true), '');
BEGIN
  -- 1. Consulta obrigatória de identificação na própria conexão ativa
  SELECT
    current_database(),
    current_user,
    session_user,
    inet_server_addr(),
    inet_server_port()
  INTO
    v_cur_db,
    v_cur_user,
    v_sess_user,
    v_srv_addr,
    v_srv_port;

  IF v_cur_db IS NULL OR btrim(v_cur_db) = '' OR v_cur_user IS NULL OR v_sess_user IS NULL THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [ID_QUERY_FAILED]: Falha ao identificar current_database/current_user/session_user na sessão ativa.';
  END IF;

  -- 2. Verifica confirmação explícita na sessão
  IF v_confirm_token <> 'CONFIRMO_BANCO_DESCARTAVEL_HOMOLOGACAO' THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [MISSING_CONFIRMATION]: Variável de confirmação explícita ausente ou inválida na sessão.';
  END IF;

  -- 3. Verifica correspondência exata entre o banco da URL e current_database() da sessão
  IF v_cur_db <> v_expected_db THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [DB_MISMATCH]: current_database() (%) difere do banco esperado na URL (%).', v_cur_db, v_expected_db;
  END IF;

  -- 4. Rejeita nomes de bancos padrão ou de produção na própria conexão
  IF lower(v_cur_db) IN ('postgres', 'defaultdb', 'supabase', 'template0', 'template1') THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [FORBIDDEN_DEFAULT_DB]: Banco padrão (%) não pode sofrer reset destrutivo.', v_cur_db;
  END IF;

  IF lower(v_cur_db) ~ '(prod|production|prd|live|main|master|staging_real)' THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [PRODUCTION_DB_DETECTED]: Nome do banco conectado (%) contém indicador de produção/ambiente protegido.', v_cur_db;
  END IF;

  IF v_cur_db !~ '^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$' THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [INVALID_DB_PATTERN]: Nome do banco conectado (%) não atende ao padrão ^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$.', v_cur_db;
  END IF;

  IF v_exec_mode = 'docker' AND v_cur_db <> 'ubatuba_homolog_disposable' THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [DOCKER_DB_MISMATCH]: Modo docker exige banco ubatuba_homolog_disposable (atual=%).', v_cur_db;
  END IF;

  -- 5. Verifica usuário da sessão
  IF v_cur_user NOT IN ('postgres', 'supabase_admin') OR v_sess_user NOT IN ('postgres', 'supabase_admin') THEN
    RAISE EXCEPTION 'RUNNER_GUARD_ABORT [UNAUTHORIZED_DB_USER]: Usuário conectado (current_user=%, session_user=%) não é um administrador local de homologação.', v_cur_user, v_sess_user;
  END IF;

  -- 6. Verifica endereço IP do servidor
  v_srv_host := COALESCE(host(v_srv_addr), 'local_socket');
  IF v_srv_addr IS NOT NULL THEN
    IF NOT (
      v_srv_addr <<= inet '127.0.0.0/8'
      OR v_srv_addr = inet '::1'
      OR (
        v_exec_mode = 'docker'
        AND (
          v_srv_addr <<= inet '172.16.0.0/12'
          OR v_srv_addr <<= inet '10.0.0.0/8'
          OR v_srv_addr <<= inet '192.168.0.0/16'
        )
      )
    ) THEN
      RAISE EXCEPTION 'RUNNER_GUARD_ABORT [REMOTE_SERVER_ADDR_FORBIDDEN]: Endereço do servidor PostgreSQL (%) não é local/descartável autorizado.', v_srv_host;
    END IF;
  END IF;

  RAISE NOTICE '[RUNNER_GUARD_PASS] Sessão validada com sucesso: db=%, current_user=%, session_user=%, server_addr=%, server_port=%, mode=%, run_id=%',
    v_cur_db, v_cur_user, v_sess_user, v_srv_host, COALESCE(v_srv_port, 0), v_exec_mode, v_run_id;

  -- 7. Executa o reset destrutivo DENTRO DA MESMA SESSÃO E TRANSAÇÃO já validada
  EXECUTE 'DROP SCHEMA IF EXISTS public CASCADE';
  EXECUTE 'DROP SCHEMA IF EXISTS internal_guard CASCADE';
  EXECUTE 'CREATE SCHEMA public';
  EXECUTE 'GRANT ALL ON SCHEMA public TO postgres';
  EXECUTE 'REVOKE CREATE ON SCHEMA public FROM PUBLIC';
  EXECUTE 'GRANT USAGE ON SCHEMA public TO PUBLIC';
END
$guard$;
SQL

if [[ -n "${UBATUBA_SIMULATE_POST_GUARD_FAIL_RC:-}" ]]; then
  exit "${UBATUBA_SIMULATE_POST_GUARD_FAIL_RC}"
fi

if [[ "$SKIP_POST_RESET_SUITES" == "1" ]]; then
  echo "[RUNNER_GUARD_TEST_COMPLETE] Guarda e reset na mesma sessão concluídos com sucesso."
  exit 0
fi

echo "=== 0.2. Versão do PostgreSQL ==="
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -c "SELECT version();"

echo "=== 1. (PG-01 — INSTALAÇÃO INICIAL DO ZERO) Aplicação das 9 migrations (000001 a 000009) ==="
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -c "
  CREATE SCHEMA IF NOT EXISTS auth;
  CREATE EXTENSION IF NOT EXISTS pgcrypto;
  CREATE TABLE IF NOT EXISTS auth.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE,
    email_confirmed_at TIMESTAMPTZ,
    confirmed_at TIMESTAMPTZ,
    raw_user_meta_data JSONB DEFAULT '{}'::jsonb,
    raw_app_meta_data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );
  CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID LANGUAGE sql STABLE AS \$\$
    SELECT NULLIF(current_setting('request.jwt.claim.sub', true), '')::uuid;
  \$\$;
  CREATE OR REPLACE FUNCTION auth.jwt() RETURNS JSONB LANGUAGE sql STABLE AS \$\$
    SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
  \$\$;
"
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261108000001_initial_schema.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261108000002_rls_and_rpcs.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261110000004_missao01_official_catalog_seed.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261115000009_missao02_1_residual_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261117000011_missao02_4_adversarial_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261118000012_missao02_5_integrity_closure.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261119000013_missao02_6_post_cancel_idempotency.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261120000014_missao02_7_lineage_persistence_and_hardening.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261130000024_missao02_24_adversarial_closure_and_hardening.sql
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/migrations/20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql
echo "[PASS] PG-01: Aplicação das 19 migrations (000001 a 000019) do zero concluída sem erros."

echo "=== 2. (PG-02, PG-14 & M02.0-F04) Reaplicação ATÔMICA (--single-transaction) de 000003 a 000014 e verificação anti-regressão ==="
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 --single-transaction \
  -f supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql \
  -f supabase/migrations/20261110000004_missao01_official_catalog_seed.sql \
  -f supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql \
  -f supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql \
  -f supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql \
  -f supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql \
  -f supabase/migrations/20261115000009_missao02_1_residual_fixes.sql \
  -f supabase/migrations/20261116000010_missao02_3_surgical_fixes.sql \
  -f supabase/migrations/20261117000011_missao02_4_adversarial_fixes.sql \
  -f supabase/migrations/20261118000012_missao02_5_integrity_closure.sql \
  -f supabase/migrations/20261119000013_missao02_6_post_cancel_idempotency.sql \
  -f supabase/migrations/20261120000014_missao02_7_lineage_persistence_and_hardening.sql \
  -f supabase/migrations/20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql \
  -f supabase/migrations/20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql \
  -f supabase/migrations/20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql \
  -f supabase/migrations/20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql \
  -f supabase/migrations/20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql \
  -f supabase/migrations/20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql \
  -f supabase/migrations/20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql \
  -f supabase/migrations/20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql \
  -f supabase/migrations/20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql \
  -f supabase/migrations/20261130000024_missao02_24_adversarial_closure_and_hardening.sql \
  -f supabase/migrations/20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql

psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 <<'SQL'
DO $$
DECLARE
  v_partners INT;
  v_tours INT;
  v_blocks INT;
  v_obsolete_policies INT;
  v_lgpd_fn_src TEXT;
  v_actor_fn_src TEXT;
BEGIN
  SELECT COUNT(*) INTO v_partners FROM public.partners;
  SELECT COUNT(*) INTO v_tours FROM public.tours;
  SELECT COUNT(*) INTO v_blocks FROM public.availability_blocks;

  IF v_partners <> 4 OR v_tours <> 4 OR v_blocks <> 1 THEN
    RAISE EXCEPTION '[FAIL] PG-14: Duplicação detectada após reaplicação (partners=%, tours=%, blocks=%).',
      v_partners, v_tours, v_blocks;
  END IF;

  SELECT COUNT(*) INTO v_obsolete_policies
  FROM pg_policies
  WHERE schemaname = 'public'
    AND policyname IN (
      'availability_blocks_partner_write',
      'availability_blocks_partner_insert',
      'reviews_tourist_insert',
      'ledger_admin_update'
    );

  IF v_obsolete_policies <> 0 THEN
    RAISE EXCEPTION '[FAIL] M02.0-F04: Detectadas % políticas RLS obsoletas após reaplicação!', v_obsolete_policies;
  END IF;

  SELECT prosrc INTO v_lgpd_fn_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'admin_anonymize_customer_pii';

  SELECT prosrc INTO v_actor_fn_src
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'resolve_booking_actor_role';

  IF v_lgpd_fn_src IS NULL
     OR position('ledger_notes_sanitized' in v_lgpd_fn_src) = 0
     OR v_actor_fn_src IS NULL
     OR position('session_user IN' in v_actor_fn_src) = 0 THEN
    RAISE EXCEPTION '[FAIL] M02.0-F04: Corpos ativos de funções regrediram após reaplicação!';
  END IF;

  RAISE NOTICE '[PASS] PG-02, PG-14 & M02.0-F04: Reaplicação atômica concluída sem duplicação e sem regressão de políticas/funções.';
END $$;
SQL

echo "=== 3. Executando Suíte de Homologação PostgreSQL (PG-03 a PG-13, SEG-01 a SEG-07, Bloco 8 T8.1..T8.15 e Bloco 9 T9.1..T9.15) ==="
psql "$DATABASE_URL" -X -v ON_ERROR_STOP=1 -f supabase/tests/homologacao_postgresql_real.sql

echo "=== 4. (PG-09, M01.7-002, M01.7-006, M01.7-010, M02.0-F05) Executando Suíte de Concorrência Real sob RLS (2 rodadas consecutivas) ==="
UBATUBA_ALLOW_CONCURRENCY_TEST=1 python3 supabase/tests/test_concorrencia_real_pg.py
UBATUBA_ALLOW_CONCURRENCY_TEST=1 python3 supabase/tests/test_concorrencia_real_pg.py

echo "=== 5. (M01.9-002, M02.0-F01, M02.0-F02, M02.0-F08) Executando Suíte Real de Carga e Estabilidade L1, L2 e L3 no Mesmo Ciclo de Vida ==="
UBATUBA_ALLOW_LOAD_TEST=1 python3 supabase/tests/load_stability_plan_pg.py

echo "=== HOMOLOGAÇÃO POSTGRESQL REAL + CARGA L1/L2/L3 100% CONCLUÍDA COM SUCESSO (RUN_ID=$MISSION_RUN_ID) ==="
