#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.2
TESTE DE CONCORRÊNCIA REAL ENTRE TRANSAÇÕES PARALELAS NO POSTGRESQL
(PG-09, M01.7-002, M01.7-006, M01.7-010, M02.0-F05 E M02.2-F05)
Arquivo: supabase/tests/test_concorrencia_real_pg.py

Regras de Segurança, RLS e Limpeza:
  1. NUNCA desativa triggers (zero uso de DISABLE TRIGGER USER / ALL).
  2. NUNCA executa DELETE direto em tabelas imutáveis (`bookings`, `commission_ledger`,
     `booking_status_history`, `audit_logs`).
  3. M02.2-F05: Exige conjuntamente (`AND`) `UBATUBA_ALLOW_CONCURRENCY_TEST=1`, host local
     (`127.0.0.1`, `localhost`, `::1`) e nome de banco obedecendo estritamente ao padrão
     `^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$` (rejeitando `postgres`, `defaultdb`, `prod`, etc.),
     além de executar todos os workers de reservas sob `SET LOCAL ROLE anon` e a redução de
     capacidade sob `SET LOCAL ROLE authenticated`.
"""

import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
from typing import List, Tuple
from urllib.parse import urlparse

DATABASE_URL = os.environ.get("DATABASE_URL", "")
TEST_DATE_SEATS = "2026-12-28"
TEST_DATE_CAP = "2027-01-20"
TEST_DATE_IDEM = "2027-01-21"

PARTNER_KAIMARES_ID = "11111111-1111-4111-8111-111111111101"
PARTNER_ROTADOMAR_ID = "11111111-1111-4111-8111-111111111102"

PARTNER_KAIMARES_USER = "bbbb2222-2222-4222-8222-222222222201"
PARTNER_ROTADOMAR_USER = "bbbb2222-2222-4222-8222-222222222202"


def run_psql(sql: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["psql", DATABASE_URL, "-X", "-v", "ON_ERROR_STOP=1", "-t", "-A", "-c", sql],
        capture_output=True,
        text=True,
    )


def verify_test_environment_and_triggers(stage: str) -> None:
    """
    M02.2-F05:
    Garante conjuntamente (AND) que:
      1) UBATUBA_ALLOW_CONCURRENCY_TEST == "1";
      2) Host é estritamente local ("127.0.0.1", "localhost", "::1");
      3) Nome do banco obedece a ^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$ e não contém indicadores de produção;
      4) Nenhuma trigger de usuário está desativada no schema public/auth.
    """
    parsed = urlparse(DATABASE_URL)
    hostname = (parsed.hostname or "").lower()
    dbname = (parsed.path or "").lstrip("/")
    dbname_lower = dbname.lower()
    allow_flag = os.environ.get("UBATUBA_ALLOW_CONCURRENCY_TEST", "") == "1"

    is_safe_host = hostname in ("127.0.0.1", "localhost", "::1")
    is_safe_db = (
        bool(re.match(r"^ubatuba_(homolog|test|ci)(_[a-z0-9_]+)?$", dbname))
        and not bool(re.search(r"(prod|production|prd|live|main|master|staging_real)", dbname_lower))
    )

    if not (allow_flag and is_safe_host and is_safe_db):
        print(
            f"[ABORTADO POR SEGURANÇA - M01.7-010 / M02.2-F05] O banco alvo (host={hostname}, db={dbname}, allow={allow_flag}) "
            "não atende aos critérios obrigatórios de ambiente descartável de homologação."
        )
        sys.exit(1)

    trig_sql = """
    SELECT COUNT(*)
    FROM pg_trigger t
    JOIN pg_class c ON c.oid = t.tgrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname IN ('public', 'auth')
      AND NOT t.tgisinternal
      AND t.tgenabled = 'D';
    """
    res = run_psql(trig_sql)
    if res.returncode != 0:
        print(f"[FAIL] ({stage}) Erro ao inspecionar pg_trigger: {res.stderr.strip()}")
        sys.exit(1)

    disabled_count = int((res.stdout or "0").strip() or "0")
    if disabled_count != 0:
        print(f"[FAIL] ({stage}) Detectadas {disabled_count} triggers desativadas no banco!")
        sys.exit(1)


def ensure_partner_users_and_verify_rls_isolation() -> None:
    rls_setup_sql = f"""
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon NOLOGIN;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
        CREATE ROLE authenticated NOLOGIN;
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
        CREATE ROLE service_role NOLOGIN BYPASSRLS;
      END IF;

      GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
      GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
      GRANT UPDATE ON public.tours, public.vessels TO authenticated;

      INSERT INTO auth.users (
        id, email, email_confirmed_at, confirmed_at, raw_user_meta_data, raw_app_meta_data, created_at, updated_at
      ) VALUES
        (
          '{PARTNER_KAIMARES_USER}'::uuid,
          'conc.kaimares@homolog.invalid',
          now(),
          now(),
          '{{"full_name": "Operador Concorrencia Kaimares", "phone": "(12) 99776-6789"}}'::jsonb,
          '{{"system_role": "partner"}}'::jsonb,
          now(),
          now()
        ),
        (
          '{PARTNER_ROTADOMAR_USER}'::uuid,
          'conc.rotadomar@homolog.invalid',
          now(),
          now(),
          '{{"full_name": "Operador Concorrencia Rota do Mar", "phone": "(12) 99176-6084"}}'::jsonb,
          '{{"system_role": "partner"}}'::jsonb,
          now(),
          now()
        )
      ON CONFLICT (id) DO UPDATE
      SET email_confirmed_at = COALESCE(auth.users.email_confirmed_at, now()),
          confirmed_at = COALESCE(auth.users.confirmed_at, now()),
          updated_at = now();

      PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', '{PARTNER_KAIMARES_USER}'::uuid, 'partner');
      UPDATE public.profiles SET system_role = 'partner', is_active = true WHERE id = '{PARTNER_KAIMARES_USER}'::uuid;
      PERFORM internal_guard.cleanup_tokens('AUTH_PROFILE_SYNC', '{PARTNER_KAIMARES_USER}'::uuid);

      PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', '{PARTNER_ROTADOMAR_USER}'::uuid, 'partner');
      UPDATE public.profiles SET system_role = 'partner', is_active = true WHERE id = '{PARTNER_ROTADOMAR_USER}'::uuid;
      PERFORM internal_guard.cleanup_tokens('AUTH_PROFILE_SYNC', '{PARTNER_ROTADOMAR_USER}'::uuid);

      INSERT INTO public.partner_members (partner_id, user_id, member_role, is_active)
      VALUES
        ('{PARTNER_KAIMARES_ID}'::uuid, '{PARTNER_KAIMARES_USER}'::uuid, 'owner', true),
        ('{PARTNER_ROTADOMAR_ID}'::uuid, '{PARTNER_ROTADOMAR_USER}'::uuid, 'owner', true)
      ON CONFLICT (partner_id, user_id) DO UPDATE
      SET member_role = 'owner', is_active = true;
    END $$;

    BEGIN;
    SET LOCAL ROLE authenticated;
    SELECT set_config('request.jwt.claim.sub', '{PARTNER_ROTADOMAR_USER}', true);
    SELECT set_config('request.jwt.claim.role', 'authenticated', true);
    WITH upd_foreign AS (
      UPDATE public.tours SET capacity = 11 WHERE slug = 'tour-lancha-norte-comp' RETURNING id
    )
    SELECT 'FOREIGN_ROWS=' || COUNT(*)::text FROM upd_foreign;

    SELECT set_config('request.jwt.claim.sub', '{PARTNER_KAIMARES_USER}', true);
    WITH upd_owner AS (
      UPDATE public.tours SET capacity = 11 WHERE slug = 'tour-lancha-norte-comp' RETURNING id
    )
    SELECT 'OWNER_ROWS=' || COUNT(*)::text FROM upd_owner;
    UPDATE public.tours SET capacity = 12 WHERE slug = 'tour-lancha-norte-comp';
    COMMIT;
    """
    res = run_psql(rls_setup_sql)
    if res.returncode != 0 or "FOREIGN_ROWS=0" not in res.stdout or "OWNER_ROWS=1" not in res.stdout:
        print(f"[FAIL] M02.0-F05: Falha ao validar isolamento RLS tours_partner_update: out={res.stdout} err={res.stderr}")
        sys.exit(1)
    print("[PASS] M02.0-F05: Isolamento RLS (FOREIGN_ROWS=0) e autorização do proprietário (OWNER_ROWS=1) em tours_partner_update comprovados.")


def cancel_active_bookings_and_restore_tour(stage_label: str) -> None:
    cleanup_sql = f"""
    BEGIN;
    DO $$
    DECLARE
      r_bk RECORD;
    BEGIN
      PERFORM set_config('request.jwt.claim.sub', '', true);
      PERFORM set_config('request.jwt.claim.role', 'service_role', true);

      FOR r_bk IN
        SELECT id, code, status
        FROM public.bookings
        WHERE booking_date IN (DATE '{TEST_DATE_SEATS}', DATE '{TEST_DATE_CAP}', DATE '{TEST_DATE_IDEM}')
          AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA')
        ORDER BY booking_date ASC, created_at ASC
      LOOP
        PERFORM public.transition_booking_status(
          r_bk.id::text,
          'CANCELADA'::public.booking_status_type,
          'Limpeza oficial via RPC (' || '{stage_label}' || ')'
        );
      END LOOP;

      UPDATE public.vessels
      SET capacity = 12
      WHERE slug = 'ves-phantom-340' AND capacity <> 12;

      UPDATE public.tours
      SET capacity = 12
      WHERE slug = 'tour-lancha-norte-comp' AND capacity <> 12;
    END
    $$;
    COMMIT;
    """
    res = run_psql(cleanup_sql)
    if res.returncode != 0:
        print(f"[FAIL] Falha na limpeza transacional via RPC ({stage_label}): {res.stderr.strip()}")
        sys.exit(1)


def main() -> int:
    if not shutil.which("psql") or not DATABASE_URL:
        print(
            "[HOMOLOGAÇÃO POSTGRESQL REAL: PENDENTE] Binário 'psql' ou variável DATABASE_URL não disponível neste container.\n"
            "Para executar os testes de concorrência real em uma instância PostgreSQL 15+:\n"
            "  DATABASE_URL='postgresql://postgres:postgres@127.0.0.1:54322/ubatuba_homolog' python3 supabase/tests/test_concorrencia_real_pg.py"
        )
        return 2

    verify_test_environment_and_triggers("pre-check")
    ensure_partner_users_and_verify_rls_isolation()
    run_tag = uuid.uuid4().hex[:6]
    print(f"=== INICIANDO SUÍTE DE CONCORRÊNCIA REAL POSTGRESQL (RUN={run_tag}) ===")

    try:
        cancel_active_bookings_and_restore_tour(f"pre-setup-{run_tag}")

        # ----------------------------------------------------------------------
        # CENÁRIO 1 (PG-09): Disputa pelas últimas 4 vagas de tour-lancha-norte-comp (12 vagas)
        # ----------------------------------------------------------------------
        setup_sql = f"""
        BEGIN;
        SET LOCAL ROLE anon;
        SELECT set_config('request.jwt.claim.sub', '', true);
        SELECT set_config('request.jwt.claim.role', 'anon', true);
        SELECT public.create_booking_request(
          'tour-lancha-norte-comp',
          DATE '{TEST_DATE_SEATS}',
          8::smallint,
          'SITE_DIRECT',
          'Grupo Base Ocupacao Inicial {run_tag}',
          '(11) 98888-0000',
          'base.{run_tag}@ubatuba.com.br',
          'direct_organic',
          NULL,
          'marketplace_ubatuba_2026',
          'Reserva base para ocupar 8 de 12 vagas',
          'idem-base-{run_tag}'
        );
        COMMIT;
        """
        setup_res = run_psql(setup_sql)
        if setup_res.returncode != 0:
            print("[FAIL] Erro ao preparar cenário base (8/12 vagas):", setup_res.stderr.strip())
            return 1

        barrier_1 = threading.Barrier(2)
        outcomes_1: List[Tuple[int, int, str, str]] = []

        def worker_last_seats(worker_id: int) -> None:
            tx_sql = f"""
            BEGIN;
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT public.create_booking_request(
              'tour-lancha-norte-comp',
              DATE '{TEST_DATE_SEATS}',
              4::smallint,
              'WHATSAPP',
              'Concorrente Real PG {worker_id}',
              '(11) 97777-000{worker_id}',
              'concorrente{worker_id}.{run_tag}@ubatuba.com.br',
              'direct_organic',
              NULL,
              'marketplace_ubatuba_2026',
              'Disputa concorrente pela última vaga',
              'idem-conc-{run_tag}-{worker_id}'
            );
            SELECT pg_sleep(0.15);
            COMMIT;
            """
            barrier_1.wait()
            proc = run_psql(tx_sql)
            outcomes_1.append((worker_id, proc.returncode, proc.stdout.strip(), proc.stderr.strip()))

        t1 = threading.Thread(target=worker_last_seats, args=(1,))
        t2 = threading.Thread(target=worker_last_seats, args=(2,))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        successes_1 = [o for o in outcomes_1 if o[1] == 0]
        failures_1 = [o for o in outcomes_1 if o[1] != 0 and ("CAPACITY_EXCEEDED" in o[3] or "INSUFFICIENT_CAPACITY" in o[3])]

        verify_res = run_psql(
            f"SELECT (public.get_tour_availability('tour-lancha-norte-comp', DATE '{TEST_DATE_SEATS}'))->>'occupied_seats';"
        )
        occupied_final = int((verify_res.stdout or "0").strip() or "0")
        if len(successes_1) != 1 or len(failures_1) != 1 or occupied_final != 12:
            print("[FAIL] PG-09: Resultado inesperado na disputa pelas últimas vagas:", outcomes_1)
            return 1
        print(f"[PASS] Cenário 1 (PG-09): 1 aprovada, 1 bloqueada, ocupação final={occupied_final}/12.")

        # ----------------------------------------------------------------------
        # CENÁRIO 2 (M01.7-002 & M02.0-F05): Reserva concorrente (8 pax) vs Redução de
        # capacidade do passeio para 6 pax sob SET LOCAL ROLE authenticated (RLS tours_partner_update)
        # ----------------------------------------------------------------------
        barrier_2 = threading.Barrier(2)
        outcomes_2: List[Tuple[str, int, str, str]] = []

        def worker_booking_cap() -> None:
            tx_sql = f"""
            BEGIN;
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT public.create_booking_request(
              'tour-lancha-norte-comp',
              DATE '{TEST_DATE_CAP}',
              8::smallint,
              'SITE_DIRECT',
              'Grupo Concorrente Cap {run_tag}',
              '(11) 96666-1111',
              'cap.{run_tag}@ubatuba.com.br',
              'direct_organic',
              NULL,
              'marketplace_ubatuba_2026',
              'Reserva concorrente com redução de capacidade',
              'idem-cap-{run_tag}'
            );
            SELECT pg_sleep(0.10);
            COMMIT;
            """
            barrier_2.wait()
            proc = run_psql(tx_sql)
            outcomes_2.append(("BOOKING_8_PAX", proc.returncode, proc.stdout.strip(), proc.stderr.strip()))

        def worker_reduce_tour_cap() -> None:
            tx_sql = f"""
            BEGIN;
            SET LOCAL ROLE authenticated;
            SELECT set_config('request.jwt.claim.sub', '{PARTNER_KAIMARES_USER}', true);
            SELECT set_config('request.jwt.claim.role', 'authenticated', true);
            SELECT pg_sleep(0.03);
            DO $$
            DECLARE v_updated INT;
            BEGIN
              UPDATE public.tours SET capacity = 6 WHERE slug = 'tour-lancha-norte-comp';
              GET DIAGNOSTICS v_updated = ROW_COUNT;
              IF v_updated <> 1 THEN
                RAISE EXCEPTION 'RLS_TOUR_UPDATE_REJECTED: Nenhuma linha atualizada sob ROLE authenticated';
              END IF;
            END $$;
            COMMIT;
            """
            barrier_2.wait()
            proc = run_psql(tx_sql)
            outcomes_2.append(("REDUCE_TOUR_CAP_6_AUTHENTICATED", proc.returncode, proc.stdout.strip(), proc.stderr.strip()))

        tb = threading.Thread(target=worker_booking_cap)
        tc = threading.Thread(target=worker_reduce_tour_cap)
        tb.start()
        tc.start()
        tb.join()
        tc.join()

        both_succeeded = all(o[1] == 0 for o in outcomes_2)
        deadlock_found = any("40P01" in o[3] or "deadlock" in o[3].lower() for o in outcomes_2)
        rls_rejected = any("RLS_TOUR_UPDATE_REJECTED" in o[3] for o in outcomes_2)
        if both_succeeded or deadlock_found or rls_rejected:
            print("[FAIL] M01.7-002 / M02.0-F05: Violação concorrente entre reserva de 8 pax e redução de capacidade para 6:", outcomes_2)
            return 1
        print("[PASS] Cenário 2 (M01.7-002 & M02.0-F05): Reserva de 8 pax e redução de capacidade para 6 sob ROLE authenticated serializadas sem deadlock e sem violação.")

        # ----------------------------------------------------------------------
        # CENÁRIO 3 (M01.7-006): Duas requisições concorrentes do mesmo cliente com quantidades divergentes (4 vs 6)
        # ----------------------------------------------------------------------
        barrier_3 = threading.Barrier(2)
        outcomes_3: List[Tuple[int, int, str, str]] = []

        def worker_divergent_idem(pax: int) -> None:
            tx_sql = f"""
            BEGIN;
            SET LOCAL ROLE anon;
            SELECT set_config('request.jwt.claim.sub', '', true);
            SELECT set_config('request.jwt.claim.role', 'anon', true);
            SELECT public.create_booking_request(
              'tour-lancha-norte-comp',
              DATE '{TEST_DATE_IDEM}',
              {pax}::smallint,
              'SITE_DIRECT',
              'Cliente Divergente {run_tag}',
              '(11) 95555-7777',
              'div.{run_tag}@ubatuba.com.br',
              'direct_organic',
              NULL,
              'marketplace_ubatuba_2026',
              'Teste divergência concorrente'
            );
            COMMIT;
            """
            barrier_3.wait()
            proc = run_psql(tx_sql)
            outcomes_3.append((pax, proc.returncode, proc.stdout.strip(), proc.stderr.strip()))

        td1 = threading.Thread(target=worker_divergent_idem, args=(4,))
        td2 = threading.Thread(target=worker_divergent_idem, args=(6,))
        td1.start()
        td2.start()
        td1.join()
        td2.join()

        succ_3 = [o for o in outcomes_3 if o[1] == 0]
        conf_3 = [o for o in outcomes_3 if o[1] != 0 and "ACTIVE_BOOKING_PASSENGERS_CONFLICT" in o[3]]
        if len(succ_3) != 1 or len(conf_3) != 1:
            print("[FAIL] M01.7-006: Requisições concorrentes com passageiros divergentes não lançaram ACTIVE_BOOKING_PASSENGERS_CONFLICT:", outcomes_3)
            return 1
        print("[PASS] Cenário 3 (M01.7-006): Conflito concorrente de passageiros bloqueado com ACTIVE_BOOKING_PASSENGERS_CONFLICT.")

        return 0
    finally:
        cancel_active_bookings_and_restore_tour(f"post-finally-{run_tag}")
        verify_test_environment_and_triggers("post-finally-check")
        print("[PASS] M01.7-010 & M02.0-F05: Limpeza transacional via RPC (tours e vessels restaurados) concluída e 100% das triggers confirmadas ativas.")


if __name__ == "__main__":
    sys.exit(main())
