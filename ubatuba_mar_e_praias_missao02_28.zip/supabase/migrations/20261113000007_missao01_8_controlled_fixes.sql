-- ============================================================================
-- MIGRATION 0007: MISSÃO 01.8 — CORREÇÃO CONTROLADA DOS ACHADOS M01.7-001 A M01.7-010
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations 000001 a 000006 preservadas integralmente.
-- Escopo:
--   1. M01.7-002 (P0): Proteção de capacidade reversa (LEAST(tour.capacity, vessel.capacity))
--      e bloqueio de desativação/troca de embarcação em public.tours quando houver reservas
--      ativas, adquirindo Lock #1 (vessels FOR UPDATE), Lock #2 (pg_advisory_xact_lock em
--      ordem cronológica ASC) e Lock #3 (bookings FOR UPDATE).
--   2. M01.7-003 (P1): Verificação estrita de confirmação real de e-mail via coluna nativa
--      auth.users.email_confirmed_at IS NOT NULL (sem DEFAULT now() artificial e sem confiar
--      exclusivamente em metadados JSON controlados pelo usuário) em validate_verified_review()
--      e create_verified_review().
--   3. M01.7-004 (P1): Endurecimento conjunto de autorização (auth.uid(), auth.jwt(),
--      request.jwt.claim.role, current_setting('role') e session_user) em
--      upsert_availability_block() e delete_availability_block(), impedindo que sessões com
--      JWT anon ou papéis inconsistentes sejam tratadas como servidor.
--   4. M01.7-005 (P1): Preservação justificada de validate_tour_vessel_ownership() e
--      validate_commission_rule_ownership() como SECURITY INVOKER sob RLS (impede referências
--      cruzadas entre parceiros e evita oráculo de existência de embarcações não aprovadas).
--   5. M01.7-006 (P1): Validação de divergência de p_passengers no replay idempotente de
--      create_booking_request() (lançando ACTIVE_BOOKING_PASSENGERS_CONFLICT) e exclusão de
--      reservas pendentes já expiradas (expires_at <= now()) da busca de reserva ativa.
--   6. M01.7-009 (P2): Implementação da RPC administrativa idempotente
--      public.admin_anonymize_customer_pii(p_booking_id UUID, p_lgpd_protocol TEXT) para
--      anonimização de PII em bookings, booking_status_history, reviews e audit_logs sem
--      enfraquecer triggers de imutabilidade nem alterar valores contábeis do livro-razão.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ESTRUTURA STANDALONE DE auth.users PARA CONFIRMAÇÃO DE E-MAIL (M01.7-003)
-- Adiciona as colunas nativas do Supabase Auth (GoTrue) caso o ambiente de teste
-- standalone tenha criado auth.users pela migration 000003.
-- IMPORTANTE: Sem DEFAULT now()! Contas não confirmadas permanecem com NULL.
-- ----------------------------------------------------------------------------
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = 'auth' AND table_name = 'users'
  ) THEN
    ALTER TABLE auth.users ADD COLUMN IF NOT EXISTS email_confirmed_at TIMESTAMPTZ;
    ALTER TABLE auth.users ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMPTZ;
  END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- 2. PROTEÇÃO DE CAPACIDADE REVERSA E RESERVAS ATIVAS EM public.tours E public.vessels
--    (M01.7-002 — P0)
-- Ordem Canônica Anti-Deadlock (idêntica a create_booking_request e transition_booking_status):
--   Lock #1: Linha(s) da embarcação em public.vessels (FOR UPDATE, ORDER BY id ASC)
--   Lock #2: pg_advisory_xact_lock(hashtext(vessel_id), hashtext(booking_date)) em ordem ASC
--   Lock #3: Linhas de public.bookings (FOR UPDATE)
-- Como toda operação concorrente de reserva, confirmação ou bloqueio adquire Lock #1
-- (vessels FOR UPDATE) como primeiro passo, duas transações concorrentes na mesma
-- embarcação são estritamente serializadas na raiz, eliminando inversão AB-BA.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_max_tour_cap SMALLINT;
  v_vessel_cap SMALLINT;
  v_eff_tour_cap INTEGER;
  v_lock_date RECORD;
  v_max_occupied_date RECORD;
  v_active_pending_or_disputed_count INTEGER := 0;
BEGIN
  -- 2.1. Validações de capacidade reversa e desativação em public.vessels
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.is_active = false AND OLD.is_active = true)
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN

      -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
      PERFORM 1 FROM public.vessels WHERE id = NEW.id FOR UPDATE;

      -- Lock #2 e Lock #3 em ordem cronológica estrita (ASC):
      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        -- Lock #2: Advisory Lock por (embarcação + data)
        PERFORM pg_advisory_xact_lock(hashtext(NEW.id::text), hashtext(v_lock_date.booking_date::text));

        -- Lock #3: Lock das linhas filhas em public.bookings (FOR UPDATE)
        PERFORM 1
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;
    END IF;

    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
        INTO v_max_occupied_date
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        AND (
          bk.expires_at IS NULL
          OR bk.expires_at > now()
          OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        )
      GROUP BY bk.booking_date
      HAVING SUM(bk.passengers) > NEW.capacity
      ORDER BY bk.booking_date ASC
      LIMIT 1;

      IF v_max_occupied_date.booking_date IS NOT NULL THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados ativos.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END IF;
    END IF;

    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND (
          bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
          OR (
            bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
            AND (bk.expires_at IS NULL OR bk.expires_at > now())
          )
        );

      IF v_active_pending_or_disputed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
          v_active_pending_or_disputed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  -- 2.2. Validações de capacidade reversa e desativação em public.tours (M01.7-002)
  IF TG_TABLE_NAME = 'tours' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN

      -- Lock #1: Embarcação(ões) vinculada(s) em public.vessels (FOR UPDATE em ordem de UUID ASC)
      PERFORM 1
      FROM public.vessels v
      WHERE v.id IN (OLD.vessel_id, NEW.vessel_id)
      ORDER BY v.id ASC
      FOR UPDATE;

      SELECT v.capacity INTO v_vessel_cap
      FROM public.vessels v
      WHERE v.id = NEW.vessel_id;

      -- Lock #2 e Lock #3 em ordem cronológica estrita (ASC) para todas as datas com reservas ativas:
      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        -- Lock #2: Advisory Lock por (embarcação + data)
        PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        IF OLD.vessel_id IS DISTINCT FROM NEW.vessel_id THEN
          PERFORM pg_advisory_xact_lock(hashtext(OLD.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        END IF;

        -- Lock #3: Lock das linhas filhas em public.bookings (FOR UPDATE)
        PERFORM 1
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;

      IF NEW.capacity < OLD.capacity THEN
        v_eff_tour_cap := LEAST(NEW.capacity::integer, COALESCE(v_vessel_cap::integer, NEW.capacity::integer));

        SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
          INTO v_max_occupied_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        GROUP BY bk.booking_date
        HAVING SUM(bk.passengers) > v_eff_tour_cap
        ORDER BY bk.booking_date ASC
        LIMIT 1;

        IF v_max_occupied_date.booking_date IS NOT NULL THEN
          RAISE EXCEPTION 'TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade do passeio para % (capacidade efetiva %) pois a data % já possui % passageiros reservados ativos.',
            NEW.capacity, v_eff_tour_cap, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
            USING ERRCODE = 'P0001';
        END IF;
      END IF;

      IF (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN
        SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND (
            bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
            OR (
              bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
              AND (bk.expires_at IS NULL OR bk.expires_at > now())
            )
          );

        IF v_active_pending_or_disputed_count > 0 THEN
          RAISE EXCEPTION 'TOUR_HAS_ACTIVE_BOOKINGS: Não é possível desativar, suspender ou alterar embarcação/modalidade do passeio enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
            v_active_pending_or_disputed_count
            USING ERRCODE = 'P0001';
        END IF;
      END IF;
    END IF;
  END IF;

  -- Sincronização automática de rating_avg/reviews_count disparada por recalculate_ratings_after_review via token de uso único
  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  v_is_admin_or_server := (
    v_db_role <> 'anon'
    AND v_jwt_role <> 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND public.is_admin()
  ) OR (
    v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
    AND v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    AND session_user IN ('postgres', 'supabase_admin', 'service_role')
  );

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status NOT IN ('PENDENTE_APROVACAO', 'APROVADO') THEN
        RAISE EXCEPTION 'VESSEL_INVALID_INITIAL_STATUS: Status inicial inválido para embarcação.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem reativar embarcação suspensa ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' AND TG_OP = 'INSERT' THEN
    IF NEW.owner_type <> 'PARTNER' OR NEW.authorized = true THEN
      RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem aguardar autorização administrativa.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. CONFIRMAÇÃO ESTRITA DE E-MAIL EM AVALIAÇÕES VERIFICADAS (M01.7-003 — P1)
-- Exige que auth.users.email_confirmed_at IS NOT NULL e que os metadados JSON
-- não marquem email_verified = 'false', nunca confiando apenas em raw_user_meta_data.
-- Também suporta anonimização de autor via token REVIEW_MUTATION ('ANONYMIZE_LGPD').
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.validate_verified_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_profile_active BOOLEAN := false;
  v_auth_user RECORD;
BEGIN
  v_is_admin_or_server := (
    v_db_role <> 'anon'
    AND v_jwt_role <> 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND public.is_admin()
  ) OR (
    v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
    AND v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    AND session_user IN ('postgres', 'supabase_admin', 'service_role')
  );

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
       OR NEW.rating IS DISTINCT FROM OLD.rating
       OR NEW.comment IS DISTINCT FROM OLD.comment THEN
      RAISE EXCEPTION 'REVIEW_IMMUTABLE_CONTENT: Não é permitido alterar nota, comentário ou vínculos de uma avaliação publicada.'
        USING ERRCODE = '42501';
    END IF;

    IF (NEW.author_name IS DISTINCT FROM OLD.author_name OR NEW.author_city IS DISTINCT FROM OLD.author_city) THEN
      IF NOT internal_guard.consume_token('REVIEW_MUTATION', OLD.booking_id, 'ANONYMIZE_LGPD') THEN
        RAISE EXCEPTION 'REVIEW_IMMUTABLE_CONTENT: Identificação do autor da avaliação só pode ser alterada por rotina oficial de anonimização LGPD.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF NOT v_is_admin_or_server THEN
      RAISE EXCEPTION 'REVIEW_MODERATION_ADMIN_ONLY: Somente administradores podem moderar a visibilidade de avaliações.'
        USING ERRCODE = '42501';
    END IF;

    RETURN NEW;
  END IF;

  -- TG_OP = 'INSERT': exige token emitido por public.create_verified_review() (exceto durante seed de servidor)
  IF NOT internal_guard.consume_token('REVIEW_MUTATION', NEW.booking_id, 'INSERT') THEN
    IF NOT (
      v_is_admin_or_server
      AND v_uid IS NULL
      AND v_db_role NOT IN ('anon', 'authenticated')
      AND v_jwt_role NOT IN ('anon', 'authenticated')
    ) THEN
      RAISE EXCEPTION 'DIRECT_REVIEW_INSERT_FORBIDDEN: Inserção direta em public.reviews é proibida. Utilize public.create_verified_review().'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  SELECT id, code, tour_id, partner_id, tourist_user_id, customer_name, status
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: A reserva informada (%) não existe.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_REQUIRES_COMPLETED_BOOKING: Avaliações só podem ser publicadas para reservas com status PASSEIO_REALIZADO (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS DISTINCT FROM v_booking.tour_id OR NEW.partner_id IS DISTINCT FROM v_booking.partner_id THEN
    RAISE EXCEPTION 'REVIEW_ENTITY_MISMATCH: O passeio ou parceiro da avaliação não corresponde à reserva %.',
      v_booking.code
      USING ERRCODE = '23514';
  END IF;

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas criadas sem usuário autenticado (tourist_user_id IS NULL) não podem ser avaliadas sem vinculação prévia verificada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular autenticado da reserva (%) pode avaliá-la.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de usuário inativa ou perfil não localizado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT
      u.id,
      u.email_confirmed_at,
      u.confirmed_at,
      u.raw_app_meta_data,
      u.raw_user_meta_data
      INTO v_auth_user
    FROM auth.users u
    WHERE u.id = v_uid;

    IF v_auth_user.id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de autenticação não localizada em auth.users.'
        USING ERRCODE = '42501';
    END IF;

    -- Exige timestamp nativo email_confirmed_at preenchido (não confia apenas em metadados JSON)
    -- e rejeita qualquer flag explícita email_verified = 'false'
    IF COALESCE(v_auth_user.email_confirmed_at, v_auth_user.confirmed_at) IS NULL
       OR COALESCE(v_auth_user.raw_app_meta_data->>'email_verified', 'true') = 'false'
       OR COALESCE(v_auth_user.raw_user_meta_data->>'email_verified', 'true') = 'false' THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: É necessário confirmar seu endereço de e-mail antes de publicar uma avaliação.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  NEW.tourist_user_id := v_booking.tourist_user_id;
  NEW.author_name := COALESCE(NULLIF(trim(COALESCE(NEW.author_name, '')), ''), v_booking.customer_name);
  NEW.author_city := COALESCE(NULLIF(trim(COALESCE(NEW.author_city, '')), ''), 'Visitante Verificado');

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_verified_review(
  p_booking_id TEXT,
  p_rating SMALLINT,
  p_comment TEXT,
  p_author_name TEXT DEFAULT NULL,
  p_author_city TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_review public.reviews;
  v_clean_identifier TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_profile_active BOOLEAN := false;
  v_auth_user RECORD;
BEGIN
  IF v_clean_identifier = '' THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: Informe o ID ou código da reserva para avaliar.'
      USING ERRCODE = '23514';
  END IF;

  IF p_rating IS NULL OR p_rating < 1 OR p_rating > 5 THEN
    RAISE EXCEPTION 'INVALID_REVIEW_RATING: A nota da avaliação deve estar entre 1 e 5.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(trim(COALESCE(p_comment, ''))) < 5 THEN
    RAISE EXCEPTION 'INVALID_REVIEW_COMMENT: O comentário da avaliação deve ter pelo menos 5 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  SELECT *
    INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_identifier OR code = v_clean_identifier
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_identifier
      USING ERRCODE = 'P0002';
  END IF;

  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));

  -- Lock #3: Reserva em public.bookings (FOR UPDATE)
  SELECT *
    INTO v_booking
  FROM public.bookings
  WHERE id = v_booking.id
  FOR UPDATE;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_REQUIRES_COMPLETED_BOOKING: Somente reservas com status PASSEIO_REALIZADO podem ser avaliadas (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  v_is_admin_or_server := (
    v_db_role <> 'anon'
    AND v_jwt_role <> 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND public.is_admin()
  ) OR (
    v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
    AND v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    AND session_user IN ('postgres', 'supabase_admin', 'service_role')
  );

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas anônimas (tourist_user_id IS NULL) não podem ser avaliadas sem verificação administrativa de titularidade.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular da reserva (%) pode publicar avaliação.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Seu perfil está inativo ou não foi encontrado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT
      u.id,
      u.email_confirmed_at,
      u.confirmed_at,
      u.raw_app_meta_data,
      u.raw_user_meta_data
      INTO v_auth_user
    FROM auth.users u
    WHERE u.id = v_uid;

    IF v_auth_user.id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de autenticação não localizada em auth.users.'
        USING ERRCODE = '42501';
    END IF;

    IF COALESCE(v_auth_user.email_confirmed_at, v_auth_user.confirmed_at) IS NULL
       OR COALESCE(v_auth_user.raw_app_meta_data->>'email_verified', 'true') = 'false'
       OR COALESCE(v_auth_user.raw_user_meta_data->>'email_verified', 'true') = 'false' THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: Seu endereço de e-mail precisa estar confirmado em auth.users (email_confirmed_at) para avaliar passeios.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM public.reviews r WHERE r.booking_id = v_booking.id) THEN
    RAISE EXCEPTION 'REVIEW_ALREADY_EXISTS: A reserva % já possui uma avaliação verificada publicada.', v_booking.code
      USING ERRCODE = '23505';
  END IF;

  PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_booking.id, 'INSERT');

  INSERT INTO public.reviews (
    booking_id,
    tour_id,
    partner_id,
    tourist_user_id,
    author_name,
    author_city,
    rating,
    comment,
    is_published
  ) VALUES (
    v_booking.id,
    v_booking.tour_id,
    v_booking.partner_id,
    v_booking.tourist_user_id,
    COALESCE(NULLIF(trim(COALESCE(p_author_name, '')), ''), v_booking.customer_name),
    COALESCE(NULLIF(trim(COALESCE(p_author_city, '')), ''), 'Visitante Verificado'),
    p_rating,
    trim(p_comment),
    true
  )
  RETURNING * INTO v_review;

  PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_booking.id);

  RETURN jsonb_build_object(
    'id', v_review.id,
    'booking_id', v_review.booking_id,
    'verified_booking_code', v_booking.code,
    'tour_id', v_review.tour_id,
    'partner_id', v_review.partner_id,
    'author_name', v_review.author_name,
    'author_city', v_review.author_city,
    'rating', v_review.rating,
    'comment', v_review.comment,
    'created_at', v_review.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. ENDURECIMENTO DE AUTORIZAÇÃO E FALLBACK DE SERVIDOR NAS RPCS DE AGENDA
--    (M01.7-004 — P1)
-- Avalia conjuntamente: auth.uid(), auth.jwt(), request.jwt.claim.role,
-- current_setting('role', true) e session_user.
-- NUNCA interpreta uma sessão com JWT anon ou inconsistência entre DB role e JWT role
-- como sessão administrativa de servidor.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.upsert_availability_block(
  p_vessel_id TEXT,
  p_block_date DATE,
  p_block_type TEXT,
  p_reason TEXT DEFAULT NULL,
  p_custom_capacity_override SMALLINT DEFAULT NULL,
  p_tour_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel RECORD;
  v_resolved_tour_id UUID := NULL;
  v_existing_id UUID;
  v_result public.availability_blocks;
  v_clean_vessel TEXT := trim(COALESCE(p_vessel_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized BOOLEAN := false;
BEGIN
  IF v_clean_vessel = '' OR p_block_date IS NULL THEN
    RAISE EXCEPTION 'INVALID_BLOCK_INPUT: Embarcação e data são obrigatórias.'
      USING ERRCODE = '23514';
  END IF;

  -- 1. Bloqueio imediato de qualquer contexto anon ou inconsistência entre DB role e JWT role
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Contexto de autenticação inválido ou não autorizado para gerenciar agenda.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, partner_id, name, capacity
    INTO v_vessel
  FROM public.vessels
  WHERE id::text = v_clean_vessel OR slug = v_clean_vessel
  FOR UPDATE;

  IF v_vessel.id IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', v_clean_vessel
      USING ERRCODE = 'P0002';
  END IF;

  -- 2. Verificação conjunta de autorização (Usuário autenticado titular/admin OU sessão legítima de servidor/service_role)
  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized := (public.is_admin() OR public.is_partner_member(v_vessel.partner_id));
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized := true;
  END IF;

  IF NOT v_is_authorized THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Você não possui permissão para gerenciar a agenda desta embarcação.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_block_date::text));

  IF p_tour_id IS NOT NULL AND trim(p_tour_id) <> '' THEN
    v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
    IF v_resolved_tour_id IS NULL THEN
      RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado para o bloqueio.', p_tour_id
        USING ERRCODE = 'P0002';
    END IF;
  END IF;

  -- Lock #3: Verifica se já existe registro para a chave lógica (vessel_id, block_date, block_type, tour_id)
  SELECT id INTO v_existing_id
  FROM public.availability_blocks
  WHERE vessel_id = v_vessel.id
    AND block_date = p_block_date
    AND block_type = p_block_type
    AND tour_id IS NOT DISTINCT FROM v_resolved_tour_id
  FOR UPDATE;

  -- Emite token somente após os locks e revalidações
  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_vessel.id, p_block_date::text);

  IF v_existing_id IS NOT NULL THEN
    UPDATE public.availability_blocks
    SET custom_capacity_override = p_custom_capacity_override,
        reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional atualizado'),
        tour_id = v_resolved_tour_id
    WHERE id = v_existing_id
    RETURNING * INTO v_result;
  ELSE
    INSERT INTO public.availability_blocks (
      partner_id,
      vessel_id,
      tour_id,
      block_date,
      block_type,
      custom_capacity_override,
      reason,
      created_by
    ) VALUES (
      v_vessel.partner_id,
      v_vessel.id,
      v_resolved_tour_id,
      p_block_date,
      p_block_type,
      p_custom_capacity_override,
      COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional agendado'),
      v_uid
    )
    RETURNING * INTO v_result;
  END IF;

  PERFORM internal_guard.cleanup_tokens('AVAILABILITY_BLOCK_MUTATION', v_vessel.id);

  RETURN to_jsonb(v_result);
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_availability_block(
  p_block_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_candidate RECORD;
  v_locked_block RECORD;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized BOOLEAN := false;
BEGIN
  IF p_block_id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Identificador do bloqueio é obrigatório.'
      USING ERRCODE = 'P0002';
  END IF;

  -- 1. Bloqueio imediato de qualquer contexto anon ou inconsistência entre DB role e JWT role
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Contexto de autenticação inválido ou não autorizado para remover bloqueio.'
      USING ERRCODE = '42501';
  END IF;

  -- 2. Leitura inicial dos identificadores para adquirir Lock #1 (vessels) e Lock #2 (advisory_lock) na ordem canônica
  SELECT id, partner_id, vessel_id, block_date, block_type
    INTO v_candidate
  FROM public.availability_blocks
  WHERE id = p_block_id;

  IF v_candidate.id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Bloqueio de agenda (%) não encontrado.', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized := (public.is_admin() OR public.is_partner_member(v_candidate.partner_id));
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized := true;
  END IF;

  IF NOT v_is_authorized THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Sem permissão para remover este bloqueio.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_candidate.vessel_id FOR UPDATE;
  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_candidate.vessel_id::text), hashtext(v_candidate.block_date::text));

  -- Lock #3: Revalida e trava a linha em public.availability_blocks antes de emitir o token
  SELECT id, partner_id, vessel_id, block_date, block_type
    INTO v_locked_block
  FROM public.availability_blocks
  WHERE id = p_block_id
  FOR UPDATE;

  IF v_locked_block.id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Bloqueio de agenda (%) já foi removido por outra transação.', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_locked_block.vessel_id, v_locked_block.block_date::text);

  DELETE FROM public.availability_blocks
  WHERE id = v_locked_block.id;

  PERFORM internal_guard.cleanup_tokens('AVAILABILITY_BLOCK_MUTATION', v_locked_block.vessel_id);

  RETURN jsonb_build_object(
    'deleted', true,
    'id', v_locked_block.id,
    'vessel_id', v_locked_block.vessel_id,
    'block_date', v_locked_block.block_date,
    'block_type', v_locked_block.block_type
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. CORREÇÃO DE IDEMPOTÊNCIA E CONFLITO DE PASSAGEIROS EM create_booking_request()
--    (M01.7-006 — P1)
-- - Ignora reservas canceladas, recusadas ou pendentes já expiradas (expires_at <= now())
--   ao procurar reserva ativa existente.
-- - Quando encontra reserva ativa existente para o mesmo (passeio, data, telefone) ou
--   idempotency_key:
--   * Se v_existing.passengers = p_passengers -> preserva o replay idempotente.
--   * Se v_existing.passengers <> p_passengers -> lança ACTIVE_BOOKING_PASSENGERS_CONFLICT.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_uid UUID;
BEGIN
  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));

  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  -- Hierarquia Canônica Anti-Deadlock:
  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  -- Lock #2: Advisory lock transacional (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_computed_idem_key := left(
    COALESCE(
      NULLIF(trim(p_idempotency_key), ''),
      md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
      || md5(v_phone_digits || ':' || v_tour.id::text)
    ),
    64
  );

  v_uid := (SELECT auth.uid());
  IF v_uid IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
    v_uid := NULL;
  END IF;

  -- Prioriza busca de reserva ativa não expirada para (idempotency_key) ou (tour_id + booking_date + phone_digits)
  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE (
      b.idempotency_key = v_computed_idem_key
      OR (
        b.tour_id = v_tour.id
        AND b.booking_date = p_booking_date
        AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      )
    )
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.created_at DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );
  END IF;

  -- Se existe uma reserva ativa não expirada, valida titularidade e igualdade de passageiros (M01.7-006)
  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF (v_existing.tourist_user_id IS NOT NULL AND v_uid IS DISTINCT FROM v_existing.tourist_user_id AND NOT public.is_admin())
       OR regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') <> v_phone_digits
       OR lower(trim(v_existing.customer_email)) <> v_clean_email THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação ativa conflitante ou a chave de idempotência pertence a outro titular.'
        USING ERRCODE = '23505';
    END IF;

    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  -- Se existia uma reserva anterior CANCELADA, RECUSADA ou EXPIRADA com a mesma idempotency_key,
  -- gera novo sufixo único para permitir a nova reserva legítima sem violar UNIQUE(idempotency_key)
  IF EXISTS (SELECT 1 FROM public.bookings b WHERE b.idempotency_key = v_computed_idem_key) THEN
    v_computed_idem_key := left(
      md5(v_computed_idem_key || ':' || clock_timestamp()::text)
      || md5(gen_random_uuid()::text),
      64
    );
  END IF;

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(trim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 6. ANONIMIZAÇÃO ADMINISTRATIVA LGPD DE DADOS PESSOAIS EM RESERVAS E LOGS
--    (M01.7-009 — P2)
-- - Restrita a admin ou service_role (com verificação conjunta de contexto).
-- - Preserva 100% dos registros e valores contábeis/fiscais em bookings e
--   commission_ledger (gross_amount, commission_amount, net_partner_amount, snapshots).
-- - Anonimiza PII identificável:
--   1) public.bookings: customer_name, customer_phone, customer_email e notes.
--   2) public.booking_status_history: reason do registro inicial (onde notes foi copiado).
--   3) public.reviews: author_name e author_city (mantendo nota e avaliação verificada).
--   4) public.audit_logs: sanitiza customer_name, customer_phone, customer_email e notes
--      nos objetos JSONB old_data/new_data da reserva, sem deletar linhas.
-- - Registra evento ANONYMIZE_PII_LGPD em audit_logs sem copiar a PII antiga.
-- - Idempotente: chamadas repetidas para a mesma reserva retornam idempotent_replay = true.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_notes TEXT;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock:
  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  -- Lock #3: Reserva em public.bookings (FOR UPDATE)
  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_anon_notes := format('[LGPD %s] Dados pessoais anonimizados conforme solicitação.', v_clean_protocol);

  -- Idempotência: se a reserva já está anonimizada, retorna confirmação sem duplicar logs
  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email THEN
    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'lgpd_protocol', v_clean_protocol,
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount
    );
  END IF;

  -- 1. Atualiza PII em public.bookings via token oficial BOOKING_MUTATION
  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, v_target.status::text);

  UPDATE public.bookings
  SET customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  -- 2. Sanitiza observações livres do cliente copiadas no registro inicial de booking_status_history
  UPDATE public.booking_status_history
  SET reason = v_anon_notes
  WHERE booking_id = v_target.id
    AND previous_status IS NULL;

  -- 3. Se houver avaliação publicada vinculada à reserva, anonimiza nome e cidade do autor mantendo nota e comentário
  IF EXISTS (SELECT 1 FROM public.reviews WHERE booking_id = v_target.id) THEN
    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado'
    WHERE booking_id = v_target.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  -- 4. Sanitiza PII dentro de old_data e new_data em public.audit_logs sem remover linhas nem tocar em dados financeiros
  UPDATE public.audit_logs
  SET old_data = CASE
        WHEN old_data IS NOT NULL AND (old_data ? 'customer_name' OR old_data ? 'customer_phone' OR old_data ? 'customer_email' OR old_data ? 'notes') THEN
          old_data || jsonb_build_object(
            'customer_name', v_anon_name,
            'customer_phone', v_anon_phone,
            'customer_email', v_anon_email,
            'notes', v_anon_notes,
            'lgpd_anonymized', true,
            'lgpd_protocol', v_clean_protocol
          )
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL AND (new_data ? 'customer_name' OR new_data ? 'customer_phone' OR new_data ? 'customer_email' OR new_data ? 'notes') THEN
          new_data || jsonb_build_object(
            'customer_name', v_anon_name,
            'customer_phone', v_anon_phone,
            'customer_email', v_anon_email,
            'notes', v_anon_notes,
            'lgpd_anonymized', true,
            'lgpd_protocol', v_clean_protocol
          )
        ELSE new_data
      END
  WHERE table_name = 'bookings'
    AND record_id = v_target.code;

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  -- 5. Registra a operação de anonimização em audit_logs SEM copiar a PII anterior
  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'bookings',
    v_target.code,
    'ANONYMIZE_PII_LGPD',
    jsonb_build_object(
      'booking_id', v_target.id,
      'pii_redacted', true
    ),
    jsonb_build_object(
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'lgpd_protocol', v_clean_protocol,
      'audit_rows_sanitized', v_audit_updated_count,
      'review_author_anonymized', v_review_updated,
      'financials_preserved', true
    )
  );

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'lgpd_protocol', v_clean_protocol,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 7. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000007
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
    REVOKE DELETE, TRUNCATE ON public.profiles FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    FOR r_fn IN
      SELECT p.oid::regprocedure AS fn_sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('public', 'internal_guard')
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END LOOP;
  END IF;
END
$$;
