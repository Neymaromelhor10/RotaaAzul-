-- ============================================================================
-- UBATUBA MAR & PRAIAS (ROTA AZUL) — ARGON 4 — MISSÃO 02.24
-- MIGRATION 000024: FECHAMENTO ADVERSARIAL DE IDEMPOTÊNCIA COM NULL (D09),
-- TRILHA AUTOMÁTICA DE SOLICITAÇÃO ADMINISTRATIVA DE ESTORNO (D10) E
-- SIMETRIA DE REVERSÃO DE FALHA DE ESTORNO PARCIAL (D12)
-- Arquivo: supabase/migrations/20261130000024_missao02_24_adversarial_closure_and_hardening.sql
--
-- Regra de Preservação (Seção 1.8 e 1.9):
--   As 23 migrations históricas (000001 a 000023) permanecem 100% inalteradas
--   byte a byte. Esta migration incremental aplica as correções D09, D10 e D12.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.confirm_or_fail_booking_payment(
  p_booking_id UUID,
  p_target_status public.payment_status_type,
  p_idempotency_key TEXT,
  p_external_transaction_id TEXT DEFAULT NULL,
  p_client_gross_amount NUMERIC DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_prev_status public.payment_status_type;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_service_role BOOLEAN := false;
  v_confirmation_origin TEXT := NULL;
  v_is_refund_fail_revert BOOLEAN := false;
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_ext TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_external_transaction_id, '')), '');
  v_clean_reason TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), '');
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Contexto de autenticação inválido ou não autorizado para atualizar pagamento.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NULL
     AND v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND v_json_role IS DISTINCT FROM 'anon'
     AND v_json_role IS DISTINCT FROM 'authenticated'
     AND (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    v_is_service_role := true;
  END IF;

  IF p_booking_id IS NULL OR p_target_status IS NULL THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_TRANSITION_ARGS: Reserva e status alvo são obrigatórios.'
      USING ERRCODE = '23514';
  END IF;

  IF p_target_status NOT IN ('PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'INVALID_TARGET_PAYMENT_STATUS: Utilize request_booking_refund() ou process_booking_refund() para operações de estorno.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência inválida.'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Sem permissão para atualizar pagamento desta reserva.'
      USING ERRCODE = '42501';
  END IF;

  -- F01-B: Turista jamais pode alterar diretamente estados financeiros (PROCESSANDO, PAGO, FALHOU, CANCELADO)
  IF v_actor_role = 'tourist' THEN
    IF p_target_status = 'PAGO' THEN
      RAISE EXCEPTION 'TOURIST_PAYMENT_CONFIRM_FORBIDDEN: O turista não tem permissão para confirmar pagamento diretamente.'
        USING ERRCODE = '42501';
    END IF;
    RAISE EXCEPTION 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN: O turista não tem permissão para alterar estados financeiros diretamente (%).' ,
      p_target_status
      USING ERRCODE = '42501';
  END IF;

  -- F01-A: Parceiro jamais pode confirmar pagamento como PAGO ou reverter estorno
  IF v_actor_role = 'partner' AND p_target_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'PARTNER_PAYMENT_CONFIRM_FORBIDDEN: Parceiros não possuem permissão para confirmar pagamentos como PAGO.'
      USING ERRCODE = '42501';
  END IF;

  IF p_client_gross_amount IS NOT NULL AND pg_catalog.round(p_client_gross_amount::numeric, 2) <> v_booking.gross_amount THEN
    RAISE EXCEPTION 'PAYMENT_CLIENT_AMOUNT_MISMATCH: Valor informado (%) diverge do valor oficial da reserva (%).',
      pg_catalog.round(p_client_gross_amount::numeric, 2), v_booking.gross_amount
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Nenhum pagamento iniciado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- F06-B: Verifica idempotência rigorosa no histórico de operações financeiras (comparando todos os parâmetros do payload)
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR (
         v_hist_existing.new_status IS DISTINCT FROM p_target_status
         AND NOT (
           COALESCE((v_hist_existing.metadata_json->>'refund_fail_revert')::boolean, false) = true
           AND p_target_status = 'PAGO'
           AND v_hist_existing.new_status = 'ESTORNO_PARCIAL'
         )
       )
       OR v_hist_existing.external_transaction_id IS DISTINCT FROM v_clean_ext
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência (%) reutilizada com parâmetros incompatíveis.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'previous_status', v_hist_existing.previous_status,
      'payment_status', v_payment.payment_status,
      'gross_amount', v_payment.gross_amount,
      'commission_amount', v_payment.commission_amount,
      'net_partner_amount', v_payment.net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount,
      'confirmed_at', v_payment.confirmed_at
    );
  END IF;

  IF v_payment.payment_status = 'PAGO' AND p_target_status = 'PAGO' THEN
    RAISE EXCEPTION 'PAYMENT_ALREADY_CONFIRMED_DUPLICATE: O pagamento da reserva % já foi confirmado anteriormente.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  -- F02-B & D12: Tratamento de falha de processamento de estorno (ESTORNO_PENDENTE -> PAGO ou ESTORNO_PARCIAL)
  IF v_payment.payment_status = 'ESTORNO_PENDENTE' AND p_target_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    IF v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou service_role podem reverter estorno pendente após falha no gateway.'
        USING ERRCODE = '42501';
    END IF;
    IF v_payment.refunded_gross_amount = 0 AND p_target_status = 'ESTORNO_PARCIAL' THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Estorno pendente sem saldo estornado anterior deve retornar para PAGO.'
        USING ERRCODE = '23514';
    END IF;
    IF v_payment.refunded_gross_amount > 0 THEN
      p_target_status := 'ESTORNO_PARCIAL';
    ELSE
      p_target_status := 'PAGO';
    END IF;
    IF v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 5 THEN
      RAISE EXCEPTION 'REFUND_FAILURE_REASON_REQUIRED: É obrigatório informar o motivo da falha do estorno (mínimo 5 caracteres).'
        USING ERRCODE = '23514';
    END IF;
    v_is_refund_fail_revert := true;
  ELSIF p_target_status = 'ESTORNO_PARCIAL' THEN
    RAISE EXCEPTION 'INVALID_TARGET_PAYMENT_STATUS: Utilize process_booking_refund() para confirmar estorno parcial.'
      USING ERRCODE = '23514';
  END IF;

  -- F01-C: Validações obrigatórias para confirmação de pagamento (PAGO)
  IF p_target_status = 'PAGO' AND NOT v_is_refund_fail_revert THEN
    IF v_booking.status IN ('CANCELADA', 'RECUSADA') THEN
      RAISE EXCEPTION 'PAYMENT_CONFIRM_ON_CANCELLED_FORBIDDEN: Não é permitido confirmar pagamento de uma reserva cancelada ou recusada (%).',
        v_booking.status
        USING ERRCODE = '23514';
    END IF;

    IF COALESCE(v_clean_ext, v_payment.external_transaction_id) IS NULL THEN
      RAISE EXCEPTION 'EXTERNAL_TRANSACTION_ID_REQUIRED: A confirmação de pagamento (PAGO) exige external_transaction_id válido.'
        USING ERRCODE = '23514';
    END IF;

    IF v_is_service_role THEN
      v_confirmation_origin := 'GATEWAY_WEBHOOK';
    ELSE
      v_confirmation_origin := 'MANUAL_ADMIN';
      IF v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 5 THEN
        RAISE EXCEPTION 'ADMIN_CONFIRMATION_REASON_REQUIRED: Confirmação manual administrativa de pagamento exige justificativa auditável (mínimo 5 caracteres).'
          USING ERRCODE = '23514';
      END IF;
    END IF;
  END IF;

  IF NOT public.is_valid_payment_status_transition(v_payment.payment_status, p_target_status) THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Transição financeira inválida de % para %.',
      v_payment.payment_status, p_target_status
      USING ERRCODE = '23514';
  END IF;

  v_prev_status := v_payment.payment_status;

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, p_target_status::text);
  UPDATE public.booking_payments
  SET payment_status = p_target_status,
      external_transaction_id = COALESCE(v_clean_ext, external_transaction_id),
      last_operation_idempotency_key = v_clean_idem,
      confirmed_at = CASE WHEN p_target_status = 'PAGO' THEN COALESCE(confirmed_at, now()) ELSE confirmed_at END,
      cancelled_at = CASE WHEN p_target_status = 'CANCELADO' THEN COALESCE(cancelled_at, now()) ELSE cancelled_at END,
      failure_or_cancel_reason = CASE
        WHEN p_target_status IN ('FALHOU', 'CANCELADO') OR v_is_refund_fail_revert THEN COALESCE(v_clean_reason, failure_or_cancel_reason)
        ELSE failure_or_cancel_reason
      END
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    external_transaction_id,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_status,
    p_target_status,
    CASE WHEN v_is_refund_fail_revert THEN 'REFUND_FAILED_REVERT' ELSE 'TRANSITION_' || p_target_status::text END,
    CASE WHEN v_is_refund_fail_revert THEN 0.00 ELSE v_payment.gross_amount END,
    v_clean_idem,
    v_clean_ext,
    v_uid,
    v_actor_role,
    COALESCE(v_clean_reason, pg_catalog.format('Transição de pagamento %s -> %s', v_prev_status, p_target_status)),
    jsonb_build_object(
      'input_reason', v_clean_reason,
      'external_transaction_id', v_clean_ext,
      'confirmation_origin', v_confirmation_origin,
      'refund_fail_revert', v_is_refund_fail_revert
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  IF p_target_status = 'PAGO' AND NOT v_is_refund_fail_revert THEN
    PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
    INSERT INTO public.financial_ledger_entries (
      booking_id,
      payment_id,
      partner_id,
      tour_id,
      entry_type,
      gross_delta,
      commission_delta,
      net_partner_delta,
      currency,
      idempotency_key,
      reference_transaction_id,
      description,
      actor_user_id,
      actor_role
    ) VALUES (
      v_booking.id,
      v_payment.id,
      v_booking.partner_id,
      v_booking.tour_id,
      'PAYMENT_CONFIRMED',
      v_payment.gross_amount,
      v_payment.commission_amount,
      v_payment.net_partner_amount,
      'BRL',
      'fled-pay-' || v_clean_idem,
      v_payment.external_transaction_id,
      pg_catalog.format('Pagamento confirmado (%s) para reserva %s (%s)', v_confirmation_origin, v_booking.code, v_payment.commission_rule_snapshot->>'commission_rule_label'),
      v_uid,
      v_actor_role
    );
    PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    CASE
      WHEN v_is_refund_fail_revert THEN 'REVERT_FAILED_REFUND'
      WHEN p_target_status = 'PAGO' THEN 'CONFIRM_BOOKING_PAYMENT'
      ELSE 'TRANSITION_BOOKING_PAYMENT'
    END,
    jsonb_build_object('payment_status', v_prev_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'external_transaction_id', v_payment.external_transaction_id,
      'confirmation_origin', v_confirmation_origin,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_status,
    'payment_status', v_payment.payment_status,
    'confirmation_origin', v_confirmation_origin,
    'gross_amount', v_payment.gross_amount,
    'commission_amount', v_payment.commission_amount,
    'net_partner_amount', v_payment.net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount,
    'confirmed_at', v_payment.confirmed_at
  );
END;
$body$;

-- 6. RPC 3A (Nova): Solicitar Estorno em 2 Etapas sem alterar comissão/líquido antes da confirmação (F02, F06-C, F08)
CREATE OR REPLACE FUNCTION public.request_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC,
  p_idempotency_key TEXT,
  p_reason TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_preview_split JSONB;
  v_prev_pay_status public.payment_status_type;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Contexto de autenticação inválido para solicitar estorno.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de solicitação de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo da solicitação de estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL OR v_actor_role = 'tourist' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_REQUEST: Somente administradores ou o parceiro responsável podem solicitar estornos financeiros diretamente.'
      USING ERRCODE = '42501';
  END IF;

  IF p_refund_amount IS NOT NULL AND pg_catalog.round(p_refund_amount::numeric, 2) <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      pg_catalog.round(p_refund_amount::numeric, 2)
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para solicitação de estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- F06-C & D09: Validação estrita de idempotência da solicitação de estorno preservando compatibilidade com p_refund_amount IS NULL
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_type <> 'REFUND_REQUESTED'
       OR (
         p_refund_amount IS NOT NULL
         AND v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount
       )
       OR (
         p_refund_amount IS NULL
         AND (v_hist_existing.metadata_json ? 'input_refund_amount')
         AND (v_hist_existing.metadata_json->>'input_refund_amount') IS NOT NULL
       )
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de solicitação de estorno (%) reutilizada com parâmetros divergentes.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'previous_status', v_hist_existing.previous_status,
      'payment_status', v_payment.payment_status,
      'requested_refund_amount', v_hist_existing.operation_amount,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  IF p_refund_amount IS NULL THEN
    v_req_amount := v_payment.effective_gross_amount;
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status = 'ESTORNO_PENDENTE' THEN
    RAISE EXCEPTION 'REFUND_REQUEST_ALREADY_PENDING: O pagamento da reserva % já possui solicitação de estorno pendente de confirmação.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido solicitar estorno para pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  -- Valida matematicamente que o valor solicitado é positivo e não excede o saldo disponível
  v_preview_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_prev_pay_status := v_payment.payment_status;

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, 'ESTORNO_PENDENTE');
  UPDATE public.booking_payments
  SET payment_status = 'ESTORNO_PENDENTE',
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_pay_status,
    'ESTORNO_PENDENTE',
    'REFUND_REQUESTED',
    v_req_amount,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    jsonb_build_object(
      'input_reason', v_clean_reason,
      'input_refund_amount', CASE WHEN p_refund_amount IS NULL THEN NULL ELSE v_req_amount END,
      'requested_refund_amount', v_req_amount,
      'preview_split', v_preview_split
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    'REQUEST_BOOKING_REFUND',
    jsonb_build_object('payment_status', v_prev_pay_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'requested_refund_amount', v_req_amount,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'requested_refund_amount', v_req_amount,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;

-- 7. RPC 3B: Confirmar e Liquidar Estorno Integral ou Parcial — Restrito a Admin / service_role (F02-A, F06-C, F08)
CREATE OR REPLACE FUNCTION public.process_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC,
  p_idempotency_key TEXT,
  p_reason TEXT,
  p_mark_booking_cancelled BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_mark_cancel BOOLEAN := COALESCE(p_mark_booking_cancelled, false);
  v_split JSONB;
  v_is_full BOOLEAN;
  v_next_pay_status public.payment_status_type;
  v_prev_pay_status public.payment_status_type;
  v_delta_gross NUMERIC(12,2);
  v_delta_comm NUMERIC(12,2);
  v_delta_net NUMERIC(12,2);
  v_pending_req_amount NUMERIC(12,2);
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Contexto de autenticação inválido ou não autorizado para confirmar estorno.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo do estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);

  -- F02-A: Parceiro e turista nunca podem confirmar/liquidar estornos diretamente
  IF v_actor_role = 'partner' THEN
    RAISE EXCEPTION 'PARTNER_REFUND_CONFIRM_FORBIDDEN: Parceiros podem apenas solicitar estorno via request_booking_refund(), sendo a confirmação restrita à administração ou ao gateway.'
      USING ERRCODE = '42501';
  END IF;

  IF v_actor_role IS NULL OR v_actor_role <> 'admin' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou service_role podem confirmar e processar estornos financeiros.'
      USING ERRCODE = '42501';
  END IF;

  IF p_refund_amount IS NOT NULL AND pg_catalog.round(p_refund_amount::numeric, 2) <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      pg_catalog.round(p_refund_amount::numeric, 2)
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- F06-C & D09: Verifica idempotência rigorosa ANTES de calcular o saldo residual mutável quando p_refund_amount IS NULL
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_type NOT IN ('REFUND_FULL', 'REFUND_PARTIAL')
       OR (
         p_refund_amount IS NOT NULL
         AND v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount
       )
       OR (
         p_refund_amount IS NULL
         AND (v_hist_existing.metadata_json ? 'input_refund_amount')
         AND (v_hist_existing.metadata_json->>'input_refund_amount') IS NOT NULL
       )
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason
       OR COALESCE((v_hist_existing.metadata_json->>'mark_booking_cancelled')::boolean, false) IS DISTINCT FROM v_mark_cancel THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de estorno (%) reutilizada com parâmetros divergentes.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'payment_status', v_payment.payment_status,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'refunded_commission_amount', v_payment.refunded_commission_amount,
      'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  SELECT bph.operation_amount INTO v_pending_req_amount
  FROM public.booking_payment_history AS bph
  WHERE bph.payment_id = v_payment.id
    AND bph.operation_type IN ('REFUND_REQUESTED', 'REFUND_REQUESTED_ON_BOOKING_CANCEL')
  ORDER BY bph.created_at DESC, bph.id DESC
  LIMIT 1;

  IF p_refund_amount IS NULL THEN
    IF v_payment.payment_status = 'ESTORNO_PENDENTE' AND COALESCE(v_pending_req_amount, 0) > 0 THEN
      v_req_amount := v_pending_req_amount;
    ELSE
      v_req_amount := v_payment.effective_gross_amount;
    END IF;
  ELSIF v_payment.payment_status = 'ESTORNO_PENDENTE'
        AND COALESCE(v_pending_req_amount, 0) > 0
        AND v_req_amount > v_pending_req_amount THEN
    RAISE EXCEPTION 'REFUND_EXCEEDS_REQUESTED_AMOUNT: O valor confirmado para estorno (%) excede o valor solicitado pendente (%).',
      v_req_amount, v_pending_req_amount
      USING ERRCODE = '23514';
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido estornar um pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  v_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_is_full := (v_split->>'is_full_refund')::boolean;
  v_next_pay_status := CASE WHEN v_is_full THEN 'ESTORNADO'::public.payment_status_type ELSE 'ESTORNO_PARCIAL'::public.payment_status_type END;
  v_prev_pay_status := v_payment.payment_status;
  v_delta_gross := (v_split->>'refund_gross_delta')::numeric(12,2);
  v_delta_comm := (v_split->>'refund_commission_delta')::numeric(12,2);
  v_delta_net := (v_split->>'refund_net_delta')::numeric(12,2);

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, v_next_pay_status::text);
  UPDATE public.booking_payments
  SET payment_status = v_next_pay_status,
      refunded_gross_amount = (v_split->>'total_refunded_gross')::numeric(12,2),
      refunded_commission_amount = (v_split->>'total_refunded_commission')::numeric(12,2),
      refunded_net_partner_amount = (v_split->>'total_refunded_net')::numeric(12,2),
      effective_gross_amount = (v_split->>'effective_gross_amount')::numeric(12,2),
      effective_commission_amount = (v_split->>'effective_commission_amount')::numeric(12,2),
      effective_net_partner_amount = (v_split->>'effective_net_partner_amount')::numeric(12,2),
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason,
      refunded_at = now()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  -- D10: Se o Admin executou process_booking_refund diretamente a partir de PAGO ou ESTORNO_PARCIAL,
  -- registra primeiro a solicitação administrativa implícita (ESTORNO_PENDENTE / REFUND_REQUESTED) no histórico
  IF v_prev_pay_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
    INSERT INTO public.booking_payment_history (
      payment_id,
      booking_id,
      partner_id,
      previous_status,
      new_status,
      operation_type,
      operation_amount,
      idempotency_key,
      actor_user_id,
      actor_role,
      reason,
      metadata_json
    ) VALUES (
      v_payment.id,
      v_booking.id,
      v_booking.partner_id,
      v_prev_pay_status,
      'ESTORNO_PENDENTE',
      'REFUND_REQUESTED',
      v_delta_gross,
      'aut-req-' || v_clean_idem,
      v_uid,
      v_actor_role,
      v_clean_reason,
      jsonb_build_object(
        'input_reason', v_clean_reason,
        'requested_refund_amount', v_delta_gross,
        'auto_admin_request', true
      )
    )
    ON CONFLICT (idempotency_key) DO NOTHING;
    PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
  END IF;

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    CASE WHEN v_prev_pay_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN 'ESTORNO_PENDENTE'::public.payment_status_type ELSE v_prev_pay_status END,
    v_next_pay_status,
    CASE WHEN v_is_full THEN 'REFUND_FULL' ELSE 'REFUND_PARTIAL' END,
    v_delta_gross,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    v_split || jsonb_build_object(
      'input_reason', v_clean_reason,
      'input_refund_amount', CASE WHEN p_refund_amount IS NULL THEN NULL ELSE v_req_amount END,
      'mark_booking_cancelled', v_mark_cancel
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Registra lançamento compensatório negativo (append-only) no razão financeiro
  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_payment.id,
    v_booking.partner_id,
    v_booking.tour_id,
    CASE WHEN v_is_full THEN 'REFUND_FULL'::public.financial_entry_type ELSE 'REFUND_PARTIAL'::public.financial_entry_type END,
    -v_delta_gross,
    -v_delta_comm,
    -v_delta_net,
    'BRL',
    'fled-ref-' || v_clean_idem,
    v_payment.external_transaction_id,
    pg_catalog.format('Estorno %s confirmado na reserva %s: %s', CASE WHEN v_is_full THEN 'integral' ELSE 'parcial' END, v_booking.code, v_clean_reason),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Se o estorno foi integral ou solicitado cancelamento conjunto da reserva e a reserva ainda está ativa
  IF (v_is_full OR v_mark_cancel) AND v_booking.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'EM_DISPUTA') THEN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_booking.id, 'CANCELADA');
    PERFORM internal_guard.issue_token('LEDGER_SYNC', v_booking.id, 'REVERTIDA');
    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = v_clean_reason,
        cancelled_at = COALESCE(cancelled_at, now())
    WHERE id = v_booking.id;
    PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_booking.id);
    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_booking.id);
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    CASE WHEN v_is_full THEN 'CONFIRM_REFUND_FULL' ELSE 'CONFIRM_REFUND_PARTIAL' END,
    jsonb_build_object('payment_status', v_prev_pay_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'refund_gross_delta', v_delta_gross,
      'refund_commission_delta', v_delta_comm,
      'refund_net_delta', v_delta_net,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'refund_gross_delta', v_delta_gross,
    'refund_commission_delta', v_delta_comm,
    'refund_net_delta', v_delta_net,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;


-- Garantir OWNER TO postgres e privilégios mínimos nas 3 RPCs atualizadas
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
    ALTER FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) OWNER TO postgres;
  END IF;

  REVOKE ALL ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) FROM PUBLIC;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO service_role;
  END IF;
END
$$;
