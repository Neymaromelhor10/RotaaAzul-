-- ============================================================================
-- MIGRATION 0010: MISSÃO 02.3 — AUDITORIA INDEPENDENTE DE SEGUNDA ORDEM
-- E CORREÇÃO CIRÚRGICA (M02.3-F01, M02.3-F02, M02.3-F03, M02.3-F04 E M02.3-F05)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations históricas 000001 a 000009 preservadas byte a byte.
--
-- Escopo estritamente cirúrgico desta migration incremental:
--   1. M02.3-F01 (P1): Padroniza a guarda de 4 fatores (incluindo verificação de
--      session_user e bloqueio de combinações incongruentes entre DB role e JWT role)
--      nas demais rotinas SECURITY DEFINER que possuíam fallback parcial:
--        - public.protect_profile_privileged_columns()
--        - public.expire_stale_bookings()
--        - public.validate_availability_block_ownership()
--        - public.protect_catalog_moderation_columns()
--        - public.validate_verified_review()
--        - public.create_verified_review()
--        - public.resolve_booking_actor_role(UUID, UUID)
--        - public.admin_update_booking()
--        - public.settle_commission_ledger()
--   2. M02.3-F02 (P1): Restringe estritamente os valores alvo permitidos sob token
--      'LGPD_ANONYMIZE:*' em public.enforce_booking_invariants_and_transitions()
--      (exigindo exatamente as constantes LGPD em customer_name, customer_phone,
--      customer_email, notes e rejection_or_cancel_reason) e em
--      public.enforce_commission_ledger_integrity() (exigindo '[LGPD %' ou NULL em
--      adjustment_notes e proibindo atribuir updated_by a outro UUID arbitrário).
--   3. M02.3-F03 (P1): Elimina falsos positivos por substring ('position(...)') na
--      detecção de tokens do nome em public.reviews.comment dentro de
--      public.admin_anonymize_customer_pii(UUID, TEXT), passando a usar tokenização
--      alfanumérica com fronteira de palavra (\y / regex delimitada) e stop-list
--      de termos náuticos/geográficos de Ubatuba, além de sanitizar 'reviewer_name',
--      'reviewer_city' e 'changed_by' nos JSONBs de public.audit_logs.
--   4. M02.3-F04 (P1): Corrige auto-aprovação de embarcação por parceiro não-admin em
--      public.protect_catalog_moderation_columns() (exigindo status = 'PENDENTE_APROVACAO'
--      no INSERT de vessels por parceiro e proibindo parceiro de transitar vessels.status
--      para 'APROVADO' no UPDATE) e estende trg_protect_media_moderation para
--      BEFORE INSERT OR UPDATE ON public.media_assets.
--   5. M02.3-F05 (P2): Bloqueia o uso externo do prefixo reservado 'lgpd-' em
--      p_idempotency_key na RPC public.create_booking_request() (INVALID_IDEMPOTENCY_KEY).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. M02.3-F01: PADRONIZAÇÃO DA GUARDA DE 4 FATORES EM resolve_booking_actor_role,
--    admin_update_booking, settle_commission_ledger, protect_profile_privileged_columns,
--    expire_stale_bookings E validate_availability_block_ownership
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.resolve_booking_actor_role(
  p_partner_id UUID,
  p_tourist_user_id UUID
)
RETURNS public.app_role
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    NULLIF(v_jwt ->> 'role', ''),
    ''
  );
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RETURN NULL;
  END IF;

  -- Usuário autenticado: se v_db_role for 'none'/'postgres' (sem SET LOCAL ROLE authenticated),
  -- exige que session_user seja um papel administrativo/autenticador legítimo (M02.3-F01)
  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     ) THEN
    IF public.is_admin() THEN
      RETURN 'admin';
    END IF;

    IF public.is_partner_member(p_partner_id) THEN
      RETURN 'partner';
    END IF;

    IF p_tourist_user_id IS NOT NULL AND v_uid = p_tourist_user_id THEN
      IF EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
        RETURN 'tourist';
      END IF;
    END IF;

    RETURN NULL;
  END IF;

  IF v_uid IS NULL
     AND v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
     AND (
       v_db_role = 'service_role'
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RETURN 'admin';
  END IF;

  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_update_booking(
  p_booking_id TEXT,
  p_new_booking_date DATE DEFAULT NULL,
  p_new_passengers SMALLINT DEFAULT NULL,
  p_new_status public.booking_status_type DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_eff_date DATE;
  v_eff_pax SMALLINT;
  v_eff_status public.booking_status_type;
  v_date_min DATE;
  v_date_max DATE;
  v_ledger_status public.ledger_status_type;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Contexto de autenticação inválido ou não autorizado para admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Somente administradores podem executar admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_eff_date := COALESCE(p_new_booking_date, v_target.booking_date);
  v_eff_pax := COALESCE(p_new_passengers, v_target.passengers);
  v_eff_status := COALESCE(p_new_status, v_target.status);

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;

  v_date_min := LEAST(v_target.booking_date, v_eff_date);
  v_date_max := GREATEST(v_target.booking_date, v_eff_date);
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_min::text));
  IF v_date_max IS DISTINCT FROM v_date_min THEN
    PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_max::text));
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF v_eff_date IS NOT DISTINCT FROM v_target.booking_date
     AND v_eff_pax IS NOT DISTINCT FROM v_target.passengers
     AND v_eff_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_BOOKING_UPDATE: Nenhuma alteração efetiva de data, passageiros ou status foi solicitada para a reserva %.', v_target.code
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, v_eff_status::text);

  UPDATE public.bookings
  SET booking_date = v_eff_date,
      passengers = v_eff_pax,
      status = v_eff_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'booking_date', v_updated.booking_date,
    'passengers', v_updated.passengers,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.settle_commission_ledger(
  p_booking_id TEXT,
  p_adjustment_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_ledger public.commission_ledger;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));
  PERFORM 1 FROM public.bookings WHERE id = v_booking.id FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_ledger.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_NOT_FOUND: Registro financeiro não encontrado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF v_ledger.ledger_status = 'PAGA' THEN
    RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão da reserva % já foi liquidada em %.', v_booking.code, v_ledger.paid_at
      USING ERRCODE = '23514';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' OR v_ledger.ledger_status <> 'CONFIRMADA' THEN
    RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (atual: reserva=%, ledger=%).',
      v_booking.status, v_ledger.ledger_status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('LEDGER_SETTLE', v_booking.id, 'PAGA');

  UPDATE public.commission_ledger
  SET ledger_status = 'PAGA',
      paid_at = now(),
      adjustment_notes = COALESCE(NULLIF(trim(COALESCE(p_adjustment_notes, '')), ''), adjustment_notes),
      updated_by = v_uid,
      updated_at = now()
  WHERE id = v_ledger.id
  RETURNING * INTO v_ledger;

  PERFORM internal_guard.cleanup_tokens('LEDGER_SETTLE', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'commission_ledger',
    v_booking.code,
    'SETTLE_COMMISSION',
    jsonb_build_object('ledger_status', 'CONFIRMADA'),
    jsonb_build_object('ledger_status', 'PAGA', 'paid_at', v_ledger.paid_at, 'commission_amount', v_ledger.commission_amount)
  );

  RETURN jsonb_build_object(
    'ledger_id', v_ledger.id,
    'booking_id', v_booking.id,
    'booking_code', v_booking.code,
    'ledger_status', v_ledger.ledger_status,
    'gross_amount', v_ledger.gross_amount,
    'commission_amount', v_ledger.commission_amount,
    'net_partner_amount', v_ledger.net_partner_amount,
    'paid_at', v_ledger.paid_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.protect_profile_privileged_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_jwt JSONB;
  v_jwt_role TEXT;
  v_db_role TEXT;
  v_auth_email TEXT;
  v_auth_role_str TEXT;
  v_auth_expected_role public.app_role;
BEGIN
  IF NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'PROFILE_IMMUTABLE_ID: Não é permitido alterar o identificador do perfil.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.system_role IS NOT DISTINCT FROM OLD.system_role
     AND NEW.is_active IS NOT DISTINCT FROM OLD.is_active
     AND NEW.email IS NOT DISTINCT FROM OLD.email THEN
    RETURN NEW;
  END IF;

  v_uid := (SELECT auth.uid());
  v_jwt := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    NULLIF(v_jwt ->> 'role', ''),
    ''
  );
  v_db_role := COALESCE(NULLIF(current_setting('role', true), ''), 'none');

  -- Caso A: Sincronização disparada por auth.users comprovada por token de uso único em internal_guard + paridade com auth.users
  IF pg_trigger_depth() >= 2 THEN
    SELECT lower(trim(u.email)),
           lower(trim(COALESCE(u.raw_app_meta_data->>'system_role', u.raw_app_meta_data->>'role', '')))
      INTO v_auth_email, v_auth_role_str
    FROM auth.users u
    WHERE u.id = NEW.id;

    v_auth_expected_role := CASE
      WHEN v_auth_role_str IN ('tourist', 'partner', 'admin') THEN v_auth_role_str::public.app_role
      ELSE OLD.system_role
    END;

    IF (
         (NEW.email IS DISTINCT FROM OLD.email AND internal_guard.consume_token('AUTH_PROFILE_SYNC', NEW.id, v_auth_email))
         OR (NEW.system_role IS DISTINCT FROM OLD.system_role AND internal_guard.consume_token('AUTH_PROFILE_SYNC', NEW.id, v_auth_expected_role::text))
       )
       AND (NEW.email IS NOT DISTINCT FROM OLD.email OR NEW.email = v_auth_email)
       AND (NEW.system_role IS NOT DISTINCT FROM OLD.system_role OR NEW.system_role = v_auth_expected_role)
       AND (NEW.is_active IS NOT DISTINCT FROM OLD.is_active) THEN
      RETURN NEW;
    END IF;
  END IF;

  -- Caso B: Administrador autenticado e ativo no banco (com bloqueio de combinações incongruentes — M02.3-F01)
  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     )
     AND public.is_admin() THEN
    RETURN NEW;
  END IF;

  -- Caso C: Operação administrativa de backend via service_role ou superuser puro (exige session_user verificado — M02.3-F01)
  IF v_uid IS NULL
     AND v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
     AND (
       v_db_role = 'service_role'
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin', 'supabase_auth_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'supabase_auth_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RETURN NEW;
  END IF;

  IF NEW.system_role IS DISTINCT FROM OLD.system_role THEN
    RAISE EXCEPTION 'PROFILE_ROLE_ESCALATION_FORBIDDEN: Somente administradores podem alterar o papel (system_role) do usuário.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
    RAISE EXCEPTION 'PROFILE_ACTIVE_STATUS_FORBIDDEN: Somente administradores podem alterar o status ativo do perfil.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'PROFILE_EMAIL_DIRECT_CHANGE_FORBIDDEN: O e-mail deve ser atualizado via Supabase Auth.'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.expire_stale_bookings()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_rec RECORD;
  v_locked_id UUID;
  v_expired_count INTEGER := 0;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_is_authorized BOOLEAN := false;
BEGIN
  -- Guarda estrita de 4 fatores (M02.3-F01)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'UNAUTHORIZED_EXPIRATION_CALL: Contexto de autenticação inválido ou não autorizado para executar a rotina de expiração.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     ) THEN
    v_is_authorized := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized := true;
  END IF;

  IF NOT v_is_authorized THEN
    RAISE EXCEPTION 'UNAUTHORIZED_EXPIRATION_CALL: Apenas service_role ou administrador pode executar a rotina de expiração.'
      USING ERRCODE = '42501';
  END IF;

  FOR v_rec IN
    SELECT id, vessel_id, booking_date
    FROM public.bookings
    WHERE status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    ORDER BY vessel_id, booking_date, id
  LOOP
    PERFORM 1 FROM public.vessels WHERE id = v_rec.vessel_id FOR UPDATE;
    PERFORM pg_advisory_xact_lock(hashtext(v_rec.vessel_id::text), hashtext(v_rec.booking_date::text));

    SELECT id INTO v_locked_id
    FROM public.bookings
    WHERE id = v_rec.id
      AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    FOR UPDATE;

    IF v_locked_id IS NOT NULL THEN
      PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_locked_id, 'CANCELADA');

      UPDATE public.bookings
      SET status = 'CANCELADA',
          rejection_or_cancel_reason = 'Reserva expirada automaticamente por decurso do prazo de confirmação (SLA 48h)',
          cancelled_at = now(),
          updated_at = now()
      WHERE id = v_locked_id
        AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO');

      IF FOUND THEN
        v_expired_count := v_expired_count + 1;
      END IF;

      PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_locked_id);
    END IF;
  END LOOP;

  RETURN v_expired_count;
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_availability_block_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
  v_tour_partner UUID;
  v_tour_vessel UUID;
  v_active_occupied INTEGER := 0;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_server_seed BOOLEAN;
BEGIN
  -- M02.3-F01: Exige session_user verificado para seed de servidor
  v_is_server_seed := (
    v_uid IS NULL
    AND v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
    AND (
      v_db_role = 'service_role'
      OR (
        v_db_role IN ('none', 'postgres', 'supabase_admin')
        AND session_user IN ('postgres', 'supabase_admin', 'service_role')
        AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
      )
    )
  );

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.block_date IS DISTINCT FROM OLD.block_date THEN
      RAISE EXCEPTION 'BLOCK_IMMUTABLE_KEYS: Não é permitido alterar embarcação, parceiro ou data de um bloqueio existente; exclua e recrie via RPC.'
        USING ERRCODE = '42501';
    END IF;

    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_UPDATE_FORBIDDEN: Atualização direta em availability_blocks é proibida para evitar inversão da ordem de locks. Utilize public.upsert_availability_block().'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_OP = 'INSERT' THEN
    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      IF NOT v_is_server_seed THEN
        RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_INSERT_FORBIDDEN: Inserção direta em availability_blocks é proibida. Utilize public.upsert_availability_block().'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels
  WHERE id = NEW.vessel_id
  FOR UPDATE;

  IF v_vessel_partner IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', NEW.vessel_id
      USING ERRCODE = '23503';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(NEW.block_date::text));

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'BLOCK_VESSEL_OWNERSHIP_MISMATCH: A embarcação bloqueada não pertence ao parceiro informado.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS NOT NULL THEN
    SELECT partner_id, vessel_id INTO v_tour_partner, v_tour_vessel
    FROM public.tours
    WHERE id = NEW.tour_id;

    IF v_tour_partner IS DISTINCT FROM NEW.partner_id OR v_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
      RAISE EXCEPTION 'BLOCK_TOUR_MISMATCH: O passeio informado no bloqueio não pertence à mesma embarcação/parceiro.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override > v_vessel_cap THEN
    RAISE EXCEPTION 'OVERRIDE_EXCEEDS_VESSEL_CAPACITY: Ajuste de capacidade (%) excede a capacidade máxima da embarcação (%).',
      NEW.custom_capacity_override, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  PERFORM 1
  FROM public.bookings bk
  WHERE bk.vessel_id = NEW.vessel_id
    AND bk.booking_date = NEW.block_date
    AND (NEW.tour_id IS NULL OR bk.tour_id = NEW.tour_id)
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    )
  FOR UPDATE;

  SELECT COALESCE(SUM(bk.passengers), 0)::integer INTO v_active_occupied
  FROM public.bookings bk
  WHERE bk.vessel_id = NEW.vessel_id
    AND bk.booking_date = NEW.block_date
    AND (NEW.tour_id IS NULL OR bk.tour_id = NEW.tour_id)
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    );

  IF NEW.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') AND v_active_occupied > 0 THEN
    RAISE EXCEPTION 'BLOCK_CONFLICTS_WITH_CONFIRMED_BOOKINGS: Não é possível aplicar % em % pois já existem % passageiros com reserva ativa (confirmada ou aguardando confirmação) na data.',
      NEW.block_type, NEW.block_date, v_active_occupied
      USING ERRCODE = 'P0001';
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override < v_active_occupied THEN
    RAISE EXCEPTION 'OVERRIDE_BELOW_OCCUPIED_SEATS: Ajuste de capacidade (%) é inferior aos % passageiros com reserva ativa na data %.',
      NEW.custom_capacity_override, v_active_occupied, NEW.block_date
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. M02.3-F01 & M02.3-F04: ENDURECIMENTO DE protect_catalog_moderation_columns(),
--    validate_verified_review() E create_verified_review() + TRIGGER EM media_assets
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN := false;
  v_max_tour_cap SMALLINT;
  v_vessel_cap SMALLINT;
  v_eff_tour_cap INTEGER;
  v_lock_date RECORD;
  v_max_occupied_date RECORD;
  v_active_pending_or_disputed_count INTEGER := 0;
BEGIN
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.is_active = false AND OLD.is_active = true)
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN

      PERFORM 1 FROM public.vessels WHERE id = NEW.id FOR UPDATE;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_advisory_xact_lock(hashtext(NEW.id::text), hashtext(v_lock_date.booking_date::text));

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;
    END IF;

    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
        INTO v_max_occupied_date
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        AND (
          bk.expires_at IS NULL
          OR bk.expires_at > now()
          OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        )
      GROUP BY bk.booking_date
      HAVING SUM(bk.passengers) > NEW.capacity
      ORDER BY bk.booking_date ASC
      LIMIT 1;

      IF v_max_occupied_date.booking_date IS NOT NULL THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados ativos.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END IF;
    END IF;

    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND (
          bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
          OR (
            bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
            AND (bk.expires_at IS NULL OR bk.expires_at > now())
          )
        );

      IF v_active_pending_or_disputed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
          v_active_pending_or_disputed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  IF TG_TABLE_NAME = 'tours' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN

      PERFORM 1
      FROM public.vessels v
      WHERE v.id IN (OLD.vessel_id, NEW.vessel_id)
      ORDER BY v.id ASC
      FOR UPDATE;

      SELECT v.capacity INTO v_vessel_cap
      FROM public.vessels v
      WHERE v.id = NEW.vessel_id;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        IF OLD.vessel_id IS DISTINCT FROM NEW.vessel_id THEN
          PERFORM pg_advisory_xact_lock(hashtext(OLD.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        END IF;

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;

      IF NEW.capacity < OLD.capacity THEN
        v_eff_tour_cap := LEAST(NEW.capacity::integer, COALESCE(v_vessel_cap::integer, NEW.capacity::integer));

        SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
          INTO v_max_occupied_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        GROUP BY bk.booking_date
        HAVING SUM(bk.passengers) > v_eff_tour_cap
        ORDER BY bk.booking_date ASC
        LIMIT 1;

        IF v_max_occupied_date.booking_date IS NOT NULL THEN
          RAISE EXCEPTION 'TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade do passeio para % (capacidade efetiva %) pois a data % já possui % passageiros reservados ativos.',
            NEW.capacity, v_eff_tour_cap, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
            USING ERRCODE = 'P0001';
        END IF;
      END IF;

      IF (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN
        SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND (
            bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
            OR (
              bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
              AND (bk.expires_at IS NULL OR bk.expires_at > now())
            )
          );

        IF v_active_pending_or_disputed_count > 0 THEN
          RAISE EXCEPTION 'TOUR_HAS_ACTIVE_BOOKINGS: Não é possível desativar, suspender ou alterar embarcação/modalidade do passeio enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
            v_active_pending_or_disputed_count
            USING ERRCODE = 'P0001';
        END IF;
      END IF;
    END IF;
  END IF;

  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  -- Guarda estrita de 4 fatores (M02.3-F01)
  IF NOT (
       v_db_role = 'anon'
       OR v_jwt_role = 'anon'
       OR (v_jwt ->> 'role') = 'anon'
       OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
       OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
       OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated')
     ) THEN
    IF v_uid IS NOT NULL
       AND v_jwt_role = 'authenticated'
       AND (
         v_db_role = 'authenticated'
         OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
       ) THEN
      v_is_admin_or_server := public.is_admin();
    ELSIF v_uid IS NULL
          AND v_db_role NOT IN ('anon', 'authenticated')
          AND v_jwt_role NOT IN ('anon', 'authenticated')
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
          AND (
            v_db_role = 'service_role'
            OR (
              v_db_role IN ('none', 'postgres', 'supabase_admin')
              AND session_user IN ('postgres', 'supabase_admin', 'service_role')
              AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
            )
          ) THEN
      v_is_admin_or_server := true;
    END IF;
  END IF;

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, reativar passeios suspensos, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    -- M02.3-F04: Proíbe parceiro não-admin de auto-aprovar embarcação no INSERT ou no UPDATE
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' THEN
        RAISE EXCEPTION 'VESSEL_SELF_APPROVAL_FORBIDDEN: Novas embarcações cadastradas por parceiros devem iniciar como PENDENTE_APROVACAO.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar embarcações, reativar embarcação suspensa ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.owner_type <> 'PARTNER' OR NEW.authorized = true THEN
        RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem aguardar autorização administrativa.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.owner_type IS DISTINCT FROM OLD.owner_type
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.authorized IS DISTINCT FROM OLD.authorized THEN
        RAISE EXCEPTION 'MEDIA_MODERATION_COLUMNS_FORBIDDEN: Somente administradores podem autorizar mídias ou alterar titularidade.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_media_moderation ON public.media_assets;
CREATE TRIGGER trg_protect_media_moderation
  BEFORE INSERT OR UPDATE ON public.media_assets
  FOR EACH ROW EXECUTE FUNCTION public.protect_catalog_moderation_columns();

CREATE OR REPLACE FUNCTION public.validate_verified_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN := false;
  v_profile_active BOOLEAN := false;
  v_auth_user RECORD;
  v_lgpd_review_token BOOLEAN := false;
BEGIN
  IF NOT (
       v_db_role = 'anon'
       OR v_jwt_role = 'anon'
       OR (v_jwt ->> 'role') = 'anon'
       OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
       OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
       OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated')
     ) THEN
    IF v_uid IS NOT NULL
       AND v_jwt_role = 'authenticated'
       AND (
         v_db_role = 'authenticated'
         OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
       ) THEN
      v_is_admin_or_server := public.is_admin();
    ELSIF v_uid IS NULL
          AND v_db_role NOT IN ('anon', 'authenticated')
          AND v_jwt_role NOT IN ('anon', 'authenticated')
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
          AND (
            v_db_role = 'service_role'
            OR (
              v_db_role IN ('none', 'postgres', 'supabase_admin')
              AND session_user IN ('postgres', 'supabase_admin', 'service_role')
              AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
            )
          ) THEN
      v_is_admin_or_server := true;
    END IF;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_review_token := internal_guard.consume_token('REVIEW_MUTATION', OLD.booking_id, 'ANONYMIZE_LGPD');

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.rating IS DISTINCT FROM OLD.rating
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_review_token AND NEW.tourist_user_id IS NULL)
       )
       OR (
         NEW.comment IS DISTINCT FROM OLD.comment
         AND NOT v_lgpd_review_token
       )
       OR (
         (NEW.author_name IS DISTINCT FROM OLD.author_name OR NEW.author_city IS DISTINCT FROM OLD.author_city)
         AND NOT (
           v_lgpd_review_token
           AND NEW.author_name = 'Turista Verificado (LGPD)'
           AND NEW.author_city = 'Anonimizado'
         )
       ) THEN
      RAISE EXCEPTION 'REVIEW_IMMUTABLE_CONTENT: Não é permitido alterar nota, comentário, autor ou vínculos de uma avaliação publicada fora da rotina oficial de anonimização LGPD.'
        USING ERRCODE = '42501';
    END IF;

    IF NOT v_is_admin_or_server THEN
      RAISE EXCEPTION 'REVIEW_MODERATION_ADMIN_ONLY: Somente administradores podem moderar a visibilidade de avaliações.'
        USING ERRCODE = '42501';
    END IF;

    RETURN NEW;
  END IF;

  IF NOT internal_guard.consume_token('REVIEW_MUTATION', NEW.booking_id, 'INSERT') THEN
    IF NOT (
      v_is_admin_or_server
      AND v_uid IS NULL
      AND v_db_role NOT IN ('anon', 'authenticated')
      AND v_jwt_role NOT IN ('anon', 'authenticated')
    ) THEN
      RAISE EXCEPTION 'DIRECT_REVIEW_INSERT_FORBIDDEN: Inserção direta em public.reviews é proibida. Utilize public.create_verified_review().'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  SELECT id, code, tour_id, partner_id, tourist_user_id, customer_name, status
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: A reserva informada (%) não existe.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_REQUIRES_COMPLETED_BOOKING: Avaliações só podem ser publicadas para reservas com status PASSEIO_REALIZADO (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS DISTINCT FROM v_booking.tour_id OR NEW.partner_id IS DISTINCT FROM v_booking.partner_id THEN
    RAISE EXCEPTION 'REVIEW_ENTITY_MISMATCH: O passeio ou parceiro da avaliação não corresponde à reserva %.',
      v_booking.code
      USING ERRCODE = '23514';
  END IF;

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas criadas sem usuário autenticado (tourist_user_id IS NULL) não podem ser avaliadas sem vinculação prévia verificada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular autenticado da reserva (%) pode avaliá-la.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de usuário inativa ou perfil não localizado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT
      u.id,
      u.email_confirmed_at,
      u.confirmed_at,
      u.raw_app_meta_data,
      u.raw_user_meta_data
      INTO v_auth_user
    FROM auth.users u
    WHERE u.id = v_uid;

    IF v_auth_user.id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de autenticação não localizada em auth.users.'
        USING ERRCODE = '42501';
    END IF;

    IF COALESCE(v_auth_user.email_confirmed_at, v_auth_user.confirmed_at) IS NULL
       OR COALESCE(v_auth_user.raw_app_meta_data->>'email_verified', 'true') = 'false'
       OR COALESCE(v_auth_user.raw_user_meta_data->>'email_verified', 'true') = 'false' THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: É necessário confirmar seu endereço de e-mail antes de publicar uma avaliação.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  NEW.tourist_user_id := v_booking.tourist_user_id;
  NEW.author_name := COALESCE(NULLIF(trim(COALESCE(NEW.author_name, '')), ''), v_booking.customer_name);
  NEW.author_city := COALESCE(NULLIF(trim(COALESCE(NEW.author_city, '')), ''), 'Visitante Verificado');

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_verified_review(
  p_booking_id TEXT,
  p_rating SMALLINT,
  p_comment TEXT,
  p_author_name TEXT DEFAULT NULL,
  p_author_city TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_review public.reviews;
  v_clean_identifier TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN := false;
  v_profile_active BOOLEAN := false;
  v_auth_user RECORD;
BEGIN
  IF v_clean_identifier = '' THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: Informe o ID ou código da reserva para avaliar.'
      USING ERRCODE = '23514';
  END IF;

  IF p_rating IS NULL OR p_rating < 1 OR p_rating > 5 THEN
    RAISE EXCEPTION 'INVALID_REVIEW_RATING: A nota da avaliação deve estar entre 1 e 5.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(trim(COALESCE(p_comment, ''))) < 5 THEN
    RAISE EXCEPTION 'INVALID_REVIEW_COMMENT: O comentário da avaliação deve ter pelo menos 5 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  SELECT *
    INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_identifier OR code = v_clean_identifier
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_identifier
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));

  SELECT *
    INTO v_booking
  FROM public.bookings
  WHERE id = v_booking.id
  FOR UPDATE;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_REQUIRES_COMPLETED_BOOKING: Somente reservas com status PASSEIO_REALIZADO podem ser avaliadas (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NOT (
       v_db_role = 'anon'
       OR v_jwt_role = 'anon'
       OR (v_jwt ->> 'role') = 'anon'
       OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
       OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
       OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated')
     ) THEN
    IF v_uid IS NOT NULL
       AND v_jwt_role = 'authenticated'
       AND (
         v_db_role = 'authenticated'
         OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
       ) THEN
      v_is_admin_or_server := public.is_admin();
    ELSIF v_uid IS NULL
          AND v_db_role NOT IN ('anon', 'authenticated')
          AND v_jwt_role NOT IN ('anon', 'authenticated')
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
          AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
          AND (
            v_db_role = 'service_role'
            OR (
              v_db_role IN ('none', 'postgres', 'supabase_admin')
              AND session_user IN ('postgres', 'supabase_admin', 'service_role')
              AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
            )
          ) THEN
      v_is_admin_or_server := true;
    END IF;
  END IF;

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas anônimas (tourist_user_id IS NULL) não podem ser avaliadas sem verificação administrativa de titularidade.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular da reserva (%) pode publicar avaliação.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Seu perfil está inativo ou não foi encontrado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT
      u.id,
      u.email_confirmed_at,
      u.confirmed_at,
      u.raw_app_meta_data,
      u.raw_user_meta_data
      INTO v_auth_user
    FROM auth.users u
    WHERE u.id = v_uid;

    IF v_auth_user.id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de autenticação não localizada em auth.users.'
        USING ERRCODE = '42501';
    END IF;

    IF COALESCE(v_auth_user.email_confirmed_at, v_auth_user.confirmed_at) IS NULL
       OR COALESCE(v_auth_user.raw_app_meta_data->>'email_verified', 'true') = 'false'
       OR COALESCE(v_auth_user.raw_user_meta_data->>'email_verified', 'true') = 'false' THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: Seu endereço de e-mail precisa estar confirmado em auth.users (email_confirmed_at) para avaliar passeios.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM public.reviews r WHERE r.booking_id = v_booking.id) THEN
    RAISE EXCEPTION 'REVIEW_ALREADY_EXISTS: A reserva % já possui uma avaliação verificada publicada.', v_booking.code
      USING ERRCODE = '23505';
  END IF;

  PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_booking.id, 'INSERT');

  INSERT INTO public.reviews (
    booking_id,
    tour_id,
    partner_id,
    tourist_user_id,
    author_name,
    author_city,
    rating,
    comment,
    is_published
  ) VALUES (
    v_booking.id,
    v_booking.tour_id,
    v_booking.partner_id,
    v_booking.tourist_user_id,
    COALESCE(NULLIF(trim(COALESCE(p_author_name, '')), ''), v_booking.customer_name),
    COALESCE(NULLIF(trim(COALESCE(p_author_city, '')), ''), 'Visitante Verificado'),
    p_rating,
    trim(p_comment),
    true
  )
  RETURNING * INTO v_review;

  PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_booking.id);

  RETURN jsonb_build_object(
    'id', v_review.id,
    'booking_id', v_review.booking_id,
    'verified_booking_code', v_booking.code,
    'tour_id', v_review.tour_id,
    'partner_id', v_review.partner_id,
    'author_name', v_review.author_name,
    'author_city', v_review.author_city,
    'rating', v_review.rating,
    'comment', v_review.comment,
    'created_at', v_review.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. M02.3-F02: RESTRIÇÃO ESTRITA DOS VALORES ALVO SOB TOKEN LGPD_ANONYMIZE
--    EM enforce_booking_invariants_and_transitions E enforce_commission_ledger_integrity
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
  v_expected_lgpd_idem_key VARCHAR(64);
  v_expected_lgpd_email TEXT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    v_expected_lgpd_idem_key := ('lgpd-' || replace(OLD.id::text, '-', '') || '-' || left(md5(OLD.id::text), 16))::varchar(64);
    v_expected_lgpd_email := 'anonimizado.' || lower(OLD.code) || '@lgpd.invalid';

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR (
         NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         AND NOT (v_lgpd_anonymize AND NEW.idempotency_key = v_expected_lgpd_idem_key)
       )
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    IF v_lgpd_anonymize THEN
      IF NEW.status IS DISTINCT FROM OLD.status
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_OPERATIONAL_FIELDS: A operação de anonimização LGPD não pode alterar status, data, passageiros, UTMs ou timestamps operacionais da reserva.'
          USING ERRCODE = '42501';
      END IF;

      -- M02.3-F02: Sob token LGPD_ANONYMIZE, exige que os campos de cliente e textos livres recebam exclusivamente o padrão oficial LGPD
      IF NEW.customer_name <> 'TITULAR ANONIMIZADO LGPD'
         OR NEW.customer_phone <> '(00) 00000-0000'
         OR NEW.customer_email <> v_expected_lgpd_email
         OR NEW.tourist_user_id IS NOT NULL
         OR NEW.idempotency_key <> v_expected_lgpd_idem_key
         OR NEW.notes IS NULL
         OR NEW.notes NOT LIKE '[LGPD %'
         OR (NEW.rejection_or_cancel_reason IS NOT NULL AND NEW.rejection_or_cancel_reason NOT LIKE '[LGPD %') THEN
        RAISE EXCEPTION 'LGPD_INVALID_TARGET_VALUES: O token LGPD_ANONYMIZE permite gravar exclusivamente os valores canônicos de anonimização LGPD.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.enforce_commission_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_expected_ledger_status public.ledger_status_type;
BEGIN
  SELECT id, partner_id, tour_id, status, gross_amount, commission_amount, net_partner_amount
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_BOOKING_NOT_FOUND: Reserva (%) não encontrada para o livro-razão.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Os valores financeiros e vínculos do livro-razão devem corresponder exatamente à reserva e são imutáveis.'
      USING ERRCODE = '42501';
  END IF;

  v_expected_ledger_status := CASE
    WHEN v_booking.status = 'PASSEIO_REALIZADO' THEN 'CONFIRMADA'::public.ledger_status_type
    WHEN v_booking.status IN ('CANCELADA', 'RECUSADA') THEN 'REVERTIDA'::public.ledger_status_type
    WHEN v_booking.status = 'EM_DISPUTA' THEN 'EM_DISPUTA'::public.ledger_status_type
    ELSE 'PREVISTA'::public.ledger_status_type
  END;

  IF TG_OP = 'INSERT' THEN
    IF pg_trigger_depth() < 2
       OR NEW.ledger_status <> 'PREVISTA'
       OR NOT internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'PREVISTA') THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_INSERT_FORBIDDEN: O registro no livro-razão é criado exclusivamente pela trigger sync_booking_history_ledger_and_audit com status PREVISTA.'
        USING ERRCODE = '42501';
    END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id OR NEW.booking_id IS DISTINCT FROM OLD.booking_id THEN
      RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Identificadores do livro-razão são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    -- Caso 1: Sanitização LGPD de adjustment_notes e updated_by sem alterar status nem valores financeiros (M02.0-F03 & M02.3-F02)
    IF NEW.ledger_status IS NOT DISTINCT FROM OLD.ledger_status
       AND NEW.rule_snapshot_json IS NOT DISTINCT FROM OLD.rule_snapshot_json
       AND NEW.consolidated_at IS NOT DISTINCT FROM OLD.consolidated_at
       AND NEW.paid_at IS NOT DISTINCT FROM OLD.paid_at
       AND NEW.reversed_at IS NOT DISTINCT FROM OLD.reversed_at
       AND (NEW.adjustment_notes IS NULL OR NEW.adjustment_notes LIKE '[LGPD %')
       AND (NEW.updated_by IS NOT DISTINCT FROM OLD.updated_by OR NEW.updated_by IS NULL)
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'LGPD_ANONYMIZE:' || OLD.ledger_status::text) THEN
      RETURN NEW;
    END IF;

    -- Caso 2: Liquidação financeira ('CONFIRMADA' -> 'PAGA') via RPC settle_commission_ledger
    IF NEW.ledger_status = 'PAGA' AND OLD.ledger_status = 'CONFIRMADA' THEN
      IF v_booking.status IS DISTINCT FROM 'PASSEIO_REALIZADO' THEN
        RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Comissão só pode ser paga quando a reserva estiver em PASSEIO_REALIZADO.'
          USING ERRCODE = '23514';
      END IF;
      IF NOT internal_guard.consume_token('LEDGER_SETTLE', NEW.booking_id, 'PAGA') THEN
        RAISE EXCEPTION 'LEDGER_DIRECT_SETTLE_FORBIDDEN: A liquidação para PAGA deve ser executada exclusivamente via RPC public.settle_commission_ledger().'
          USING ERRCODE = '42501';
      END IF;
      NEW.paid_at := COALESCE(NEW.paid_at, now());
      RETURN NEW;
    END IF;

    -- Caso 3: Sincronização automática via token LEDGER_SYNC emitido por sync_booking_history_ledger_and_audit
    IF pg_trigger_depth() >= 2
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, v_expected_ledger_status::text)
       AND (
         NEW.ledger_status = v_expected_ledger_status
         OR (OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' AND v_booking.status = 'PASSEIO_REALIZADO')
       ) THEN
      RETURN NEW;
    END IF;

    IF OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' THEN
      RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão desta reserva já foi liquidada anteriormente em %.', OLD.paid_at
        USING ERRCODE = '23514';
    END IF;

    RAISE EXCEPTION 'LEDGER_DIRECT_STATUS_FORBIDDEN: O status do livro-razão (%) não pode divergir do estado da reserva (%) nem ser alterado fora da máquina de estados.',
      NEW.ledger_status, v_booking.status
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. M02.3-F03: DETECÇÃO DE TOKENS DO NOME COM FRONTEIRA DE PALAVRA EM reviews.comment
--    E SANITIZAÇÃO AMPLIADA DE CHAVES EM audit_logs EM admin_anonymize_customer_pii
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin', 'service_role', 'authenticator'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_anon_idem_key := ('lgpd-' || replace(v_target.id::text, '-', '') || '-' || left(md5(v_target.id::text), 16))::varchar(64);
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key = v_anon_idem_key
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %') THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := trim(COALESCE(v_target.customer_name, ''));
  v_old_email := lower(trim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  v_anon_notes := format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  UPDATE public.booking_status_history
  SET reason = format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (char_length(v_old_name) >= 3 AND v_old_name <> v_anon_name AND position(lower(v_old_name) in lower(v_review.comment)) > 0)
      OR (char_length(v_old_email) >= 5 AND position(v_old_email in lower(v_review.comment)) > 0)
      OR (char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND position(v_old_phone_digits in regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
    );

    -- M02.3-F03: Tokenização alfanumérica com correspondência por FRONTEIRA DE PALAVRA
    -- (impede que 'Rosa' dê falso positivo em 'maravilhosa' ou 'Costa' dê falso positivo em 'costa norte')
    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT regexp_split_to_table(lower(v_old_name), '[^a-záàâãéêíóôõúç]+')
      LOOP
        IF char_length(v_name_token) >= 4
           AND v_name_token NOT IN (
             'para', 'pelo', 'pela', 'como', 'mais', 'muito', 'toda', 'todo', 'todos', 'todas',
             'ilha', 'ilhas', 'praia', 'praias', 'lancha', 'escuna', 'passeio', 'barco', 'roteiro',
             'norte', 'costa', 'verde', 'anchieta', 'prumirim', 'couves', 'ubatuba', 'saco',
             'ribeira', 'itagua', 'familia', 'aguas', 'calmas', 'titular', 'anonimizado', 'lgpd',
             'cliente', 'turista', 'visitante', 'grupo', 'comentario', 'sem', 'pii'
           )
           AND lower(v_review.comment) ~ ('(^|[^a-záàâãéêíóôõúç0-9])' || v_name_token || '($|[^a-záàâãéêíóôõúç0-9])') THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  -- 5. Sanitização abrangente de public.audit_logs (incluindo reviewer_name, reviewer_city e changed_by — M02.3-F03)
  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          old_data
          || CASE WHEN old_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'idempotency_key' THEN jsonb_build_object('idempotency_key', v_anon_idem_key) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'adjustment_notes' THEN jsonb_build_object('adjustment_notes', COALESCE(v_anon_ledger_notes, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'updated_by' AND v_old_tourist_uid IS NOT NULL AND (old_data->>'updated_by') = v_old_tourist_uid::text THEN jsonb_build_object('updated_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'changed_by' AND v_old_tourist_uid IS NOT NULL AND (old_data->>'changed_by') = v_old_tourist_uid::text THEN jsonb_build_object('changed_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'reviewer_name' THEN jsonb_build_object('reviewer_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'reviewer_city' THEN jsonb_build_object('reviewer_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          new_data
          || CASE WHEN new_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'idempotency_key' THEN jsonb_build_object('idempotency_key', v_anon_idem_key) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'adjustment_notes' THEN jsonb_build_object('adjustment_notes', COALESCE(v_anon_ledger_notes, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'updated_by' AND v_old_tourist_uid IS NOT NULL AND (new_data->>'updated_by') = v_old_tourist_uid::text THEN jsonb_build_object('updated_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'changed_by' AND v_old_tourist_uid IS NOT NULL AND (new_data->>'changed_by') = v_old_tourist_uid::text THEN jsonb_build_object('changed_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'reviewer_name' THEN jsonb_build_object('reviewer_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'reviewer_city' THEN jsonb_build_object('reviewer_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. M02.3-F05: PROTEÇÃO DO PREFIXO RESERVADO 'lgpd-' EM p_idempotency_key
--    DENTRO DE public.create_booking_request()
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_uid UUID;
BEGIN
  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));
  v_clean_idem_input := trim(COALESCE(p_idempotency_key, ''));

  IF v_clean_idem_input <> '' AND lower(v_clean_idem_input) LIKE 'lgpd-%' THEN
    RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "lgpd-" é reservado exclusivamente para chaves pseudonimizadas pela rotina de conformidade LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_computed_idem_key := left(
    COALESCE(
      NULLIF(v_clean_idem_input, ''),
      md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
      || md5(v_phone_digits || ':' || v_tour.id::text)
    ),
    64
  );

  v_uid := (SELECT auth.uid());
  IF v_uid IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
    v_uid := NULL;
  END IF;

  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE (
      b.idempotency_key = v_computed_idem_key
      OR (
        b.tour_id = v_tour.id
        AND b.booking_date = p_booking_date
        AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      )
    )
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.created_at DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF (v_existing.tourist_user_id IS NOT NULL AND v_uid IS DISTINCT FROM v_existing.tourist_user_id AND NOT public.is_admin())
       OR regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') <> v_phone_digits
       OR lower(trim(v_existing.customer_email)) <> v_clean_email THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação ativa conflitante ou a chave de idempotência pertence a outro titular.'
        USING ERRCODE = '23505';
    END IF;

    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  IF EXISTS (SELECT 1 FROM public.bookings b WHERE b.idempotency_key = v_computed_idem_key) THEN
    v_computed_idem_key := left(
      md5(v_computed_idem_key || ':' || clock_timestamp()::text)
      || md5(gen_random_uuid()::text),
      64
    );
  END IF;

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(trim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 6. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000010
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT ALL ON SCHEMA public TO service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role;
  END IF;
END;
$$;
