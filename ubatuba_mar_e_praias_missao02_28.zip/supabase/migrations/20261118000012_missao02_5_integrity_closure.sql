-- ============================================================================
-- MIGRATION 0012: MISSÃO 02.5 — AUDITORIA DE INTEGRIDADE, PROVA DE CORREÇÃO
-- E FECHAMENTO DE PENDÊNCIAS (F02, F03, F04 E F05)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations históricas 000001 a 000011 preservadas byte a byte.
--
-- Achados concretos reproduzidos e corrigidos nesta migration incremental:
--   1. M02.5-SQL-01 (F03 — LGPD, Unicode Combinado NFD e JSONB Recursivo em audit_logs):
--      - Em `000011`, `public.normalize_lgpd_text(TEXT)` aplicava `translate(...)`
--        apenas sobre caracteres precompostos (NFC) e em seguida executava
--        `regexp_replace(..., '[^a-z0-9]+', ' ', 'g')`, convertendo marcas
--        combinantes Unicode NFD (`[\u0300-\u036f]`, ex.: `Joa\u0303o` ou
--        `Conceic\u0327a\u0303o`) em espaços (`'joa o'`, `'conceic a o'`).
--        Correção: aplica `normalize(..., NFC)` nativo do PostgreSQL e remove
--        explicitamente todas as marcas diacríticas combinantes Unicode
--        `[\u0300-\u036f]+` antes do `translate(...)`, sem depender de extensões
--        externas (`unaccent`).
--      - Em `000011` (`L2119`), a verificação do nome completo usava `v_norm_comment`
--        bruto em vez de `v_norm_comment_geo_stripped`, gerando falso positivo para
--        homônimos compostos de termos geográficos (ex.: titular `"Costa Norte"` ou
--        `"Marina do Saco"` em comentário geográfico). Correção: usa
--        `v_norm_comment_geo_stripped` tanto para o nome completo quanto para os
--        tokens individuais, ampliando as expressões geográficas compostas com
--        `'praia da costa'`, `'praia da rosa'`, `'praia brava'`, `'praia grande'`,
--        `'ilha comprida'`, `'ilha grande'`, `'mar aberto'`, `'mar calmo'`.
--      - Em `000011` (`L2172–2229`), a sanitização de `old_data` e `new_data` em
--        `public.audit_logs` tratava apenas chaves de 1º nível (`?`). Criada a
--        função recursiva `public.sanitize_lgpd_audit_jsonb(...)` que percorre
--        objetos e arrays JSONB em qualquer profundidade e sanitiza todas as
--        16 chaves nominais da auditoria (`customer_name`, `customer_phone`,
--        `customer_email`, `email`, `phone`, `full_name`, `name`, `actor_name`,
--        `notes`, `rejection_or_cancel_reason`, `adjustment_notes`, `reviewer_name`,
--        `reviewer_city`, `author_name`, `author_city`, `changed_by`) além das
--        chaves correlatas (`idempotency_key`, `reason`, `rejection_reason`,
--        `cancel_reason`, `tourist_user_id`, `updated_by`, `comment`), preservando
--        intactos todos os campos financeiros e operacionais não pessoais.
--      - Revoga `EXECUTE` de `authenticated` e `anon` sobre `public.normalize_lgpd_text`
--        e `public.sanitize_lgpd_audit_jsonb` (alinhamento 1:1 com `function_inventory.json`).
--   2. M02.5-SQL-02 (F04 — Isolamento Multitenant e Consistência de Vínculos em media_assets):
--      - Em `public.protect_catalog_moderation_columns()`, exige que em `TG_OP = 'UPDATE'`
--        de `public.media_assets`, `public.vessels`, `public.tours` e `public.partners`
--        o ator não-admin seja membro ativo do `OLD.partner_id` (defesa em profundidade
--        além da política RLS); valida em `public.media_assets` que, quando `vessel_id`
--        e `tour_id` são ambos informados, o passeio pertence àquela embarcação
--        (`MEDIA_TOUR_VESSEL_MISMATCH`); e impede remover o vínculo obrigatório
--        (`vessel_id IS NULL` em `category = 'Embarcação'`, `tour_id IS NULL` em
--        `category = 'Passeio'`, `destination_id IS NULL` em `category = 'Destino'`).
--   3. M02.5-SQL-03 (F05 & F02 — Separação da Busca de idempotency_key e Guarda 4-Fatores em create_booking_request):
--      - Em `000011` (`L2462–2485`), a consulta combinava `lower(b.idempotency_key) = v_computed_idem_key`
--        com `(b.tour_id = v_tour.id AND b.booking_date = p_booking_date AND phone = v_phone_digits)`
--        em um único `OR ... ORDER BY active ASC LIMIT 1`, permitindo que uma reserva
--        ativa de um segundo titular sombreasse uma reserva cancelada/expirada de outro
--        titular que detinha aquela `idempotency_key`. Correção: valida separadamente a
--        colisão por `idempotency_key` antes da busca de reserva ativa por `(tour_id, booking_date, phone)`,
--        e aplica a guarda de 4 fatores na resolução de `v_uid`.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. F03 (M02.5-SQL-01): NORMALIZAÇÃO UNICODE (NFC + NFD COMBINING MARKS) E
--    SANITIZAÇÃO RECURSIVA DE JSONB PARA AUDIT_LOGS
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.normalize_lgpd_text(p_input TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $$
  SELECT btrim(
    regexp_replace(
      translate(
        regexp_replace(
          lower(normalize(COALESCE(p_input, ''), NFC)),
          '[\u0300-\u036f]+',
          '',
          'g'
        ),
        'áàâãäåéèêëíìîïóòôõöøúùûüçñýÿšž',
        'aaaaaaeeeeiiiioooooouuuucnyysz'
      ),
      '[^a-z0-9]+',
      ' ',
      'g'
    )
  );
$$;

CREATE OR REPLACE FUNCTION public.sanitize_lgpd_audit_jsonb(
  p_data JSONB,
  p_anon_name TEXT,
  p_anon_phone TEXT,
  p_anon_email TEXT,
  p_anon_idem_key TEXT,
  p_anon_notes TEXT,
  p_anon_cancel_reason TEXT,
  p_anon_ledger_notes TEXT,
  p_new_review_comment TEXT,
  p_old_tourist_uid UUID
)
RETURNS JSONB
LANGUAGE plpgsql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_result JSONB := '{}'::jsonb;
  v_arr_result JSONB := '[]'::jsonb;
  v_key TEXT;
  v_val JSONB;
  v_elem JSONB;
BEGIN
  IF p_data IS NULL THEN
    RETURN NULL;
  END IF;

  IF jsonb_typeof(p_data) = 'array' THEN
    FOR v_elem IN SELECT * FROM jsonb_array_elements(p_data)
    LOOP
      IF jsonb_typeof(v_elem) IN ('object', 'array') THEN
        v_arr_result := v_arr_result || jsonb_build_array(
          public.sanitize_lgpd_audit_jsonb(
            v_elem,
            p_anon_name,
            p_anon_phone,
            p_anon_email,
            p_anon_idem_key,
            p_anon_notes,
            p_anon_cancel_reason,
            p_anon_ledger_notes,
            p_new_review_comment,
            p_old_tourist_uid
          )
        );
      ELSE
        v_arr_result := v_arr_result || jsonb_build_array(v_elem);
      END IF;
    END LOOP;
    RETURN v_arr_result;
  END IF;

  IF jsonb_typeof(p_data) <> 'object' THEN
    RETURN p_data;
  END IF;

  FOR v_key, v_val IN SELECT * FROM jsonb_each(p_data)
  LOOP
    IF jsonb_typeof(v_val) IN ('object', 'array') THEN
      v_result := v_result || jsonb_build_object(
        v_key,
        public.sanitize_lgpd_audit_jsonb(
          v_val,
          p_anon_name,
          p_anon_phone,
          p_anon_email,
          p_anon_idem_key,
          p_anon_notes,
          p_anon_cancel_reason,
          p_anon_ledger_notes,
          p_new_review_comment,
          p_old_tourist_uid
        )
      );
    ELSIF v_key IN ('customer_name', 'full_name', 'name', 'actor_name') THEN
      v_result := v_result || jsonb_build_object(v_key, p_anon_name);
    ELSIF v_key IN ('customer_phone', 'phone') THEN
      v_result := v_result || jsonb_build_object(v_key, p_anon_phone);
    ELSIF v_key IN ('customer_email', 'email') THEN
      v_result := v_result || jsonb_build_object(v_key, p_anon_email);
    ELSIF v_key = 'idempotency_key' THEN
      v_result := v_result || jsonb_build_object(v_key, p_anon_idem_key);
    ELSIF v_key IN ('notes', 'reason') THEN
      v_result := v_result || jsonb_build_object(v_key, p_anon_notes);
    ELSIF v_key IN ('rejection_or_cancel_reason', 'rejection_reason', 'cancel_reason') THEN
      v_result := v_result || jsonb_build_object(v_key, COALESCE(p_anon_cancel_reason, p_anon_notes));
    ELSIF v_key = 'adjustment_notes' THEN
      v_result := v_result || jsonb_build_object(v_key, COALESCE(p_anon_ledger_notes, p_anon_notes));
    ELSIF v_key IN ('author_name', 'reviewer_name') THEN
      v_result := v_result || jsonb_build_object(v_key, 'Turista Verificado (LGPD)');
    ELSIF v_key IN ('author_city', 'reviewer_city') THEN
      v_result := v_result || jsonb_build_object(v_key, 'Anonimizado');
    ELSIF v_key = 'comment' THEN
      v_result := v_result || jsonb_build_object(v_key, COALESCE(p_new_review_comment, p_anon_notes));
    ELSIF v_key IN ('tourist_user_id', 'changed_by') THEN
      v_result := v_result || jsonb_build_object(v_key, NULL);
    ELSIF v_key = 'updated_by' AND p_old_tourist_uid IS NOT NULL AND (p_data->>'updated_by') = p_old_tourist_uid::text THEN
      v_result := v_result || jsonb_build_object(v_key, NULL);
    ELSE
      v_result := v_result || jsonb_build_object(v_key, v_val);
    END IF;
  END LOOP;

  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_norm_old_name TEXT;
  v_norm_comment TEXT;
  v_norm_comment_geo_stripped TEXT;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND v_json_role IS DISTINCT FROM 'anon'
        AND v_json_role IS DISTINCT FROM 'authenticated'
        AND (
          (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_anon_idem_key := ('lgpd-' || replace(v_target.id::text, '-', '') || '-' || left(md5(v_target.id::text), 16))::varchar(64);
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key = v_anon_idem_key
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %') THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := trim(COALESCE(v_target.customer_name, ''));
  v_old_email := lower(trim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  v_anon_notes := format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  UPDATE public.booking_status_history
  SET reason = format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_norm_old_name := public.normalize_lgpd_text(v_old_name);
    v_norm_comment := public.normalize_lgpd_text(v_review.comment);

    -- Remove expressões geográficas/náuticas compostas de Ubatuba antes de testar o nome completo e os tokens individuais
    v_norm_comment_geo_stripped := regexp_replace(
      ' ' || v_norm_comment || ' ',
      ' (pela costa norte|da costa norte|na costa norte|costa norte|pela costa sul|da costa sul|na costa sul|costa sul|costa verde|costa brava|costa atlantica|praia da costa|pela costa|da costa|na costa|base marina|marina do saco|marina no saco|marina saco|marina itagua|marina porto|vaga na marina|praia da rosa|praia brava|praia grande|ilha anchieta|ilha das couves|ilha do prumirim|ilha comprida|ilha grande|ilha bela|praia do prumirim|cachoeira do prumirim|rio escuro|mar aberto|mar calmo) ',
      ' ',
      'g'
    );

    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (char_length(v_old_email) >= 5 AND position(v_old_email in lower(v_review.comment)) > 0)
      OR (char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND position(v_old_phone_digits in regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
      OR (
        char_length(v_norm_old_name) >= 3
        AND v_old_name <> v_anon_name
        AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_norm_old_name || '($|[^a-z0-9])')
      )
    );

    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT regexp_split_to_table(v_norm_old_name, '\s+')
      LOOP
        IF char_length(v_name_token) >= 3
           AND v_name_token NOT IN (
             'dos', 'das', 'com', 'sem', 'por', 'que', 'uma', 'uns', 'meu', 'sua', 'seu', 'foi', 'era',
             'bom', 'boa', 'dia', 'mar', 'sol', 'sul', 'rio', 'rua', 'cep', 'cpf', 'pii',
             'para', 'pelo', 'pela', 'como', 'mais', 'muito', 'toda', 'todo', 'todos', 'todas',
             'ilha', 'ilhas', 'praia', 'praias', 'lancha', 'escuna', 'passeio', 'barco', 'roteiro',
             'norte', 'verde', 'anchieta', 'prumirim', 'couves',
             'ubatuba', 'saco', 'ribeira', 'itagua', 'familia', 'aguas', 'calmas',
             'titular', 'anonimizado', 'lgpd', 'cliente', 'turista', 'visitante', 'grupo', 'comentario'
           )
           AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_name_token || '($|[^a-z0-9])') THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  -- Sanitização recursiva das 16 chaves de PII em old_data e new_data (incluindo estruturas JSONB aninhadas)
  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            old_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            new_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. F04 (M02.5-SQL-02): REFORÇO DE ISOLAMENTO MULTITENANT E CONSISTÊNCIA DE
--    VÍNCULOS EM public.protect_catalog_moderation_columns()
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN := false;
  v_max_tour_cap SMALLINT;
  v_vessel_cap SMALLINT;
  v_eff_tour_cap INTEGER;
  v_lock_date RECORD;
  v_max_occupied_date RECORD;
  v_active_pending_or_disputed_count INTEGER := 0;
  v_media_vessel_partner UUID;
  v_media_tour_partner UUID;
  v_media_tour_vessel UUID;
BEGIN
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.is_active = false AND OLD.is_active = true)
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN

      PERFORM 1 FROM public.vessels WHERE id = NEW.id FOR UPDATE;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_advisory_xact_lock(hashtext(NEW.id::text), hashtext(v_lock_date.booking_date::text));

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;
    END IF;

    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
        INTO v_max_occupied_date
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        AND (
          bk.expires_at IS NULL
          OR bk.expires_at > now()
          OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        )
      GROUP BY bk.booking_date
      HAVING SUM(bk.passengers) > NEW.capacity
      ORDER BY bk.booking_date ASC
      LIMIT 1;

      IF v_max_occupied_date.booking_date IS NOT NULL THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados ativos.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END IF;
    END IF;

    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND (
          bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
          OR (
            bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
            AND (bk.expires_at IS NULL OR bk.expires_at > now())
          )
        );

      IF v_active_pending_or_disputed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
          v_active_pending_or_disputed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  IF TG_TABLE_NAME = 'tours' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN

      PERFORM 1
      FROM public.vessels v
      WHERE v.id IN (OLD.vessel_id, NEW.vessel_id)
      ORDER BY v.id ASC
      FOR UPDATE;

      SELECT v.capacity INTO v_vessel_cap
      FROM public.vessels v
      WHERE v.id = NEW.vessel_id;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        IF OLD.vessel_id IS DISTINCT FROM NEW.vessel_id THEN
          PERFORM pg_advisory_xact_lock(hashtext(OLD.vessel_id::text), hashtext(v_lock_date.booking_date::text));
        END IF;

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;

      IF NEW.capacity < OLD.capacity THEN
        v_eff_tour_cap := LEAST(NEW.capacity::integer, COALESCE(v_vessel_cap::integer, NEW.capacity::integer));

        SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
          INTO v_max_occupied_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        GROUP BY bk.booking_date
        HAVING SUM(bk.passengers) > v_eff_tour_cap
        ORDER BY bk.booking_date ASC
        LIMIT 1;

        IF v_max_occupied_date.booking_date IS NOT NULL THEN
          RAISE EXCEPTION 'TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade do passeio para % (capacidade efetiva %) pois a data % já possui % passageiros reservados ativos.',
            NEW.capacity, v_eff_tour_cap, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
            USING ERRCODE = 'P0001';
        END IF;
      END IF;

      IF (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN
        SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND (
            bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
            OR (
              bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
              AND (bk.expires_at IS NULL OR bk.expires_at > now())
            )
          );

        IF v_active_pending_or_disputed_count > 0 THEN
          RAISE EXCEPTION 'TOUR_HAS_ACTIVE_BOOKINGS: Não é possível desativar, suspender ou alterar embarcação/modalidade do passeio enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
            v_active_pending_or_disputed_count
            USING ERRCODE = 'P0001';
        END IF;
      END IF;
    END IF;
  END IF;

  -- Validação estrutural sobre os valores finais de NEW em media_assets (aplicada inclusive a Admin Master — F04)
  IF TG_TABLE_NAME = 'media_assets' THEN
    IF (NEW.category = 'Embarcação' AND NEW.vessel_id IS NULL)
       OR (NEW.category = 'Passeio' AND NEW.tour_id IS NULL)
       OR (NEW.category = 'Destino' AND NEW.destination_id IS NULL) THEN
      RAISE EXCEPTION 'MEDIA_REQUIRED_ENTITY_LINK_MISSING: A categoria % exige o vínculo correspondente (vessel_id, tour_id ou destination_id).',
        NEW.category
        USING ERRCODE = '23514';
    END IF;

    IF NEW.owner_type = 'PARTNER' AND NEW.partner_id IS NOT NULL THEN
      IF NEW.vessel_id IS NOT NULL THEN
        SELECT partner_id INTO v_media_vessel_partner
        FROM public.vessels
        WHERE id = NEW.vessel_id;
        IF v_media_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
          RAISE EXCEPTION 'MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN: A embarcação vinculada à mídia não pertence ao parceiro informado.'
            USING ERRCODE = '42501';
        END IF;
      END IF;

      IF NEW.tour_id IS NOT NULL THEN
        SELECT partner_id, vessel_id INTO v_media_tour_partner, v_media_tour_vessel
        FROM public.tours
        WHERE id = NEW.tour_id;
        IF v_media_tour_partner IS DISTINCT FROM NEW.partner_id THEN
          RAISE EXCEPTION 'MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN: O passeio vinculado à mídia não pertence ao parceiro informado.'
            USING ERRCODE = '42501';
        END IF;
        IF NEW.vessel_id IS NOT NULL AND v_media_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
          RAISE EXCEPTION 'MEDIA_TOUR_VESSEL_MISMATCH: O passeio e a embarcação vinculados à mídia não são compatíveis entre si.'
            USING ERRCODE = '23514';
        END IF;
      END IF;
    END IF;
  END IF;

  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  IF NOT (
       v_db_role = 'anon'
       OR v_jwt_role = 'anon'
       OR v_json_role = 'anon'
       OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
       OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
       OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
       OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
       OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
       OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL))
     ) THEN
    IF v_uid IS NOT NULL
       AND v_jwt_role = 'authenticated'
       AND (
         v_db_role = 'authenticated'
         OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
       ) THEN
      v_is_admin_or_server := public.is_admin();
    ELSIF v_uid IS NULL
          AND v_db_role NOT IN ('anon', 'authenticated')
          AND v_jwt_role NOT IN ('anon', 'authenticated')
          AND v_json_role IS DISTINCT FROM 'anon'
          AND v_json_role IS DISTINCT FROM 'authenticated'
          AND (
            (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
            OR (
              v_db_role IN ('none', 'postgres', 'supabase_admin')
              AND session_user IN ('postgres', 'supabase_admin', 'service_role')
              AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
            )
          ) THEN
      v_is_admin_or_server := true;
    END IF;
  END IF;

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NOT public.is_partner_member(OLD.id)
       OR NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NOT public.is_partner_member(NEW.partner_id)
         OR NEW.status <> 'PENDENTE_APROVACAO'
         OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem pertencer ao próprio parceiro, iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status IN ('SUSPENSO', 'REPROVADO') AND NEW.status <> OLD.status)
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, reativar passeios suspensos/reprovados, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NOT public.is_partner_member(NEW.partner_id)
         OR NEW.status <> 'PENDENTE_APROVACAO' THEN
        RAISE EXCEPTION 'VESSEL_SELF_APPROVAL_FORBIDDEN: Novas embarcações cadastradas por parceiros devem pertencer ao próprio parceiro e iniciar como PENDENTE_APROVACAO.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status IN ('SUSPENSO', 'REPROVADO') AND (NEW.status <> OLD.status OR (OLD.is_active = false AND NEW.is_active = true)))
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar embarcações, reativar embarcação suspensa/reprovada ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.owner_type <> 'PARTNER'
         OR NEW.partner_id IS NULL
         OR NOT public.is_partner_member(NEW.partner_id)
         OR NEW.authorized = true
         OR (NEW.uploaded_by IS NOT NULL AND NEW.uploaded_by IS DISTINCT FROM v_uid) THEN
        RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem pertencer ao próprio parceiro e aguardar autorização administrativa.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF OLD.owner_type <> 'PARTNER'
         OR OLD.partner_id IS NULL
         OR NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.owner_type IS DISTINCT FROM OLD.owner_type
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.authorized IS DISTINCT FROM OLD.authorized
         OR NEW.is_provisional IS DISTINCT FROM OLD.is_provisional
         OR NEW.uploaded_by IS DISTINCT FROM OLD.uploaded_by
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'MEDIA_MODERATION_COLUMNS_FORBIDDEN: Somente administradores podem autorizar mídias ou alterar titularidade e metadados protegidos.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. F05 & F02 (M02.5-SQL-03): SEPARAÇÃO DA BUSCA DE idempotency_key E GUARDA
--    DE IDENTIDADE EM public.create_booking_request()
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_key_match RECORD;
  v_key_same_owner BOOLEAN := false;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_existing_same_owner BOOLEAN := false;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_raw_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_uid UUID := NULL;
BEGIN
  -- F02: Rejeita conflito explícito entre claims GUC e JSON JWT
  IF (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_raw_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_raw_uid::text <> v_json_sub) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_CONTEXT: Conflito de identidade entre claims JWT GUC e JSON.'
      USING ERRCODE = '42501';
  END IF;

  -- Aceita v_uid somente quando a sessão está legitimamente autenticada (4 fatores)
  IF v_raw_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     )
     AND EXISTS (SELECT 1 FROM public.profiles WHERE id = v_raw_uid AND is_active = true) THEN
    v_uid := v_raw_uid;
  END IF;

  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));

  v_clean_idem_input := lower(
    regexp_replace(
      COALESCE(p_idempotency_key, ''),
      '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$',
      '',
      'g'
    )
  );

  IF v_clean_idem_input <> '' THEN
    IF v_clean_idem_input LIKE 'lgpd-%' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "lgpd-" é reservado exclusivamente para chaves pseudonimizadas pela rotina de conformidade LGPD.'
        USING ERRCODE = '23514';
    END IF;

    IF char_length(v_clean_idem_input) < 8
       OR char_length(v_clean_idem_input) > 64
       OR v_clean_idem_input !~ '^[a-z0-9._:-]+$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: A chave de idempotência deve conter entre 8 e 64 caracteres alfanuméricos (a-z, 0-9, ., _, :, -) sem espaços internos.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_computed_idem_key := left(
    COALESCE(
      NULLIF(v_clean_idem_input, ''),
      md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
      || md5(v_phone_digits || ':' || v_tour.id::text)
    ),
    64
  );

  -- 1) Verifica primeiro e isoladamente qualquer registro que já possua exatamente a mesma idempotency_key (sem risco de sombra por OR)
  SELECT b.*
    INTO v_key_match
  FROM public.bookings b
  WHERE lower(b.idempotency_key) = v_computed_idem_key
  LIMIT 1
  FOR UPDATE;

  IF v_key_match.id IS NOT NULL THEN
    v_key_same_owner := (
      (v_key_match.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_key_match.tourist_user_id OR public.is_admin())
      AND regexp_replace(v_key_match.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND lower(trim(v_key_match.customer_email)) = v_clean_email
      AND v_key_match.tour_id = v_tour.id
      AND v_key_match.booking_date = p_booking_date
    );

    IF NOT v_key_same_owner THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: A chave de idempotência informada já pertence a outro titular, outro passeio ou outra data.'
        USING ERRCODE = '23505';
    END IF;
  END IF;

  -- 2) Busca reserva existente para o mesmo (tour_id, booking_date, telefone) ou para a própria idempotency_key validada
  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE lower(b.idempotency_key) = v_computed_idem_key
     OR (
       b.tour_id = v_tour.id
       AND b.booking_date = p_booking_date
       AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
     )
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.created_at DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );

    v_existing_same_owner := (
      (v_existing.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_existing.tourist_user_id OR public.is_admin())
      AND regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND lower(trim(v_existing.customer_email)) = v_clean_email
      AND v_existing.tour_id = v_tour.id
      AND v_existing.booking_date = p_booking_date
    );
  END IF;

  IF v_existing.id IS NOT NULL AND NOT v_existing_same_owner THEN
    RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação conflitante ou a chave de idempotência pertence a outro titular/passeio/data.'
      USING ERRCODE = '23505';
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  IF EXISTS (SELECT 1 FROM public.bookings b WHERE lower(b.idempotency_key) = v_computed_idem_key) THEN
    v_computed_idem_key := left(
      md5(v_computed_idem_key || ':' || clock_timestamp()::text)
      || md5(gen_random_uuid()::text),
      64
    );
  END IF;

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(trim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000012
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.normalize_lgpd_text(TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.sanitize_lgpd_audit_jsonb(JSONB, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, UUID) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;
    REVOKE ALL ON FUNCTION public.normalize_lgpd_text(TEXT) FROM authenticated;
    REVOKE ALL ON FUNCTION public.sanitize_lgpd_audit_jsonb(JSONB, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, UUID) FROM authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT ALL ON SCHEMA public TO service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role;
  END IF;
END;
$$;
