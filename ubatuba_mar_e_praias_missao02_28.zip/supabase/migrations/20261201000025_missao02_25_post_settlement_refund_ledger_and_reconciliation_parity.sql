-- ============================================================================
-- MIGRATION 0025: MISSÃO 02.25 — FECHAMENTO DAS PENDÊNCIAS, CORREÇÃO CIRÚRGICA
-- DE ESTORNO INTEGRAL PÓS-REALIZAÇÃO/LIQUIDAÇÃO E PARIDADE DE CONCILIAÇÃO (D13)
-- Projeto: Ubatuba Mar & Praias — Rota Azul (ARGON 4)
--Arquivo: supabase/migrations/20261201000025_missao02_25_post_settlement_refund_ledger_and_reconciliation_parity.sql
-- Pré-requisito: Migrations históricas 000001 a 000024 preservadas byte a byte.
-- Nota Cronológica: A migration 000024 utilizou o prefixo 20261130000024
--   (30/11/2026, último dia calendário de novembro). Para manter validade
--   calendário estrita (YYYYMMDDHHMMSS) e ordenação monotônica lexicográfica
--   em supabase_migrations.schema_migrations sem gerar a data inválida
--   20261131, esta migration 000025 inicia em 20261201000025 (01/12/2026).
--
-- Escopo estritamente cirúrgico desta migration incremental:
--   1. D13-A (CRÍTICA): Corrige public.enforce_commission_ledger_integrity()
--      adicionando a transição controlada por token ('REFUND_FULL_REVERT')
--      para permitir que uma comissão em 'CONFIRMADA' ou 'PAGA' de uma reserva
--      já concluída ('PASSEIO_REALIZADO') seja revertida para 'REVERTIDA'
--      exclusivamente quando o pagamento correspondente em public.booking_payments
--      estiver integralmente estornado ('ESTORNADO' com effective_gross_amount = 0.00),
--      além de preservar 'REVERTIDA' em sincronizações subsequentes.
--   2. D13-B (CRÍTICA): Corrige public.process_booking_refund() para que, quando
--      ocorrer estorno integral (v_is_full = true -> 'ESTORNADO') sobre reserva
--      no estado terminal 'PASSEIO_REALIZADO', o livro-razão de comissões
--      (public.commission_ledger) seja transacionado atomicamente para 'REVERTIDA'
--      via token 'REFUND_FULL_REVERT', eliminando a dessincronização entre
--      PostgreSQL e TypeScript e impedindo que comissões liquidadas ('PAGA')
--      permaneçam ativas após estorno de 100% do pagamento.
--   3. D13-C (ALTA): Reforça public.get_financial_reconciliation_report() para
--      sinalizar 'INCONSISTENT_REFUND_STATE' caso um pagamento conste como
--      'ESTORNADO' enquanto public.commission_ledger.ledger_status divergir de
--      'REVERTIDA'.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. D13-A: public.enforce_commission_ledger_integrity()
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_commission_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking RECORD;
  v_expected_ledger_status public.ledger_status_type;
BEGIN
  SELECT id, partner_id, tour_id, status, gross_amount, commission_amount, net_partner_amount
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_BOOKING_NOT_FOUND: Reserva (%) não encontrada para o livro-razão.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Os valores financeiros e vínculos do livro-razão devem corresponder exatamente à reserva e são imutáveis.'
      USING ERRCODE = '42501';
  END IF;

  v_expected_ledger_status := CASE
    WHEN v_booking.status = 'PASSEIO_REALIZADO' THEN 'CONFIRMADA'::public.ledger_status_type
    WHEN v_booking.status IN ('CANCELADA', 'RECUSADA') THEN 'REVERTIDA'::public.ledger_status_type
    WHEN v_booking.status = 'EM_DISPUTA' THEN 'EM_DISPUTA'::public.ledger_status_type
    ELSE 'PREVISTA'::public.ledger_status_type
  END;

  IF TG_OP = 'INSERT' THEN
    IF pg_trigger_depth() < 2
       OR NEW.ledger_status <> 'PREVISTA'
       OR NOT internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'PREVISTA') THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_INSERT_FORBIDDEN: O registro no livro-razão é criado exclusivamente pela trigger sync_booking_history_ledger_and_audit com status PREVISTA.'
        USING ERRCODE = '42501';
    END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id OR NEW.booking_id IS DISTINCT FROM OLD.booking_id THEN
      RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Identificadores do livro-razão são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    -- Caso 1: Sanitização LGPD de adjustment_notes e updated_by sem alterar status nem valores financeiros (M02.0-F03 & M02.3-F02)
    IF NEW.ledger_status IS NOT DISTINCT FROM OLD.ledger_status
       AND NEW.rule_snapshot_json IS NOT DISTINCT FROM OLD.rule_snapshot_json
       AND NEW.consolidated_at IS NOT DISTINCT FROM OLD.consolidated_at
       AND NEW.paid_at IS NOT DISTINCT FROM OLD.paid_at
       AND NEW.reversed_at IS NOT DISTINCT FROM OLD.reversed_at
       AND (NEW.adjustment_notes IS NULL OR NEW.adjustment_notes LIKE '[LGPD %')
       AND (NEW.updated_by IS NOT DISTINCT FROM OLD.updated_by OR NEW.updated_by IS NULL)
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'LGPD_ANONYMIZE:' || OLD.ledger_status::text) THEN
      RETURN NEW;
    END IF;

    -- Caso 2: Liquidação financeira ('CONFIRMADA' -> 'PAGA') via RPC settle_commission_ledger
    IF NEW.ledger_status = 'PAGA' AND OLD.ledger_status = 'CONFIRMADA' THEN
      IF v_booking.status IS DISTINCT FROM 'PASSEIO_REALIZADO' THEN
        RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Comissão só pode ser paga quando a reserva estiver em PASSEIO_REALIZADO.'
          USING ERRCODE = '23514';
      END IF;
      IF NOT internal_guard.consume_token('LEDGER_SETTLE', NEW.booking_id, 'PAGA') THEN
        RAISE EXCEPTION 'LEDGER_DIRECT_SETTLE_FORBIDDEN: A liquidação para PAGA deve ser executada exclusivamente via RPC public.settle_commission_ledger().'
          USING ERRCODE = '42501';
      END IF;
      NEW.paid_at := COALESCE(NEW.paid_at, now());
      RETURN NEW;
    END IF;

    -- Caso 3 (D13 - Missão 02.25): Reversão de comissão ('CONFIRMADA' ou 'PAGA' -> 'REVERTIDA')
    -- quando ocorre estorno integral ('ESTORNADO') após realização do passeio ('PASSEIO_REALIZADO')
    -- exclusivamente via RPC public.process_booking_refund()
    IF NEW.ledger_status = 'REVERTIDA'
       AND OLD.ledger_status IN ('CONFIRMADA', 'PAGA', 'REVERTIDA')
       AND v_booking.status = 'PASSEIO_REALIZADO'
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'REFUND_FULL_REVERT') THEN
      IF NOT EXISTS (
        SELECT 1
        FROM public.booking_payments AS bp
        WHERE bp.booking_id = NEW.booking_id
          AND bp.payment_status = 'ESTORNADO'
          AND bp.effective_gross_amount = 0.00
      ) THEN
        RAISE EXCEPTION 'LEDGER_REVERSAL_REQUIRES_FULL_REFUND: A reversão de comissão em PASSEIO_REALIZADO exige pagamento integralmente estornado (ESTORNADO).'
          USING ERRCODE = '23514';
      END IF;
      NEW.reversed_at := COALESCE(NEW.reversed_at, now());
      RETURN NEW;
    END IF;

    -- Caso 4: Sincronização automática via token LEDGER_SYNC emitido por sync_booking_history_ledger_and_audit
    IF pg_trigger_depth() >= 2
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, v_expected_ledger_status::text)
       AND (
         NEW.ledger_status = v_expected_ledger_status
         OR (OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' AND v_booking.status = 'PASSEIO_REALIZADO')
         OR (OLD.ledger_status = 'REVERTIDA' AND NEW.ledger_status = 'REVERTIDA' AND v_booking.status = 'PASSEIO_REALIZADO')
       ) THEN
      RETURN NEW;
    END IF;

    IF OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' THEN
      RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão desta reserva já foi liquidada anteriormente em %.', OLD.paid_at
        USING ERRCODE = '23514';
    END IF;

    RAISE EXCEPTION 'LEDGER_DIRECT_STATUS_FORBIDDEN: O status do livro-razão (%) não pode divergir do estado da reserva (%) nem ser alterado fora da máquina de estados.',
      NEW.ledger_status, v_booking.status
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$body$;

-- ----------------------------------------------------------------------------
-- 2. D13-B: public.process_booking_refund()
--    Garante que o estorno integral (ESTORNADO) sobre reserva já concluída
--    (PASSEIO_REALIZADO) reverta atomicamente commission_ledger para REVERTIDA
--    sem violar o estado terminal da reserva nem deixar comissão PAGA/CONFIRMADA
--    sem lastro financeiro.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.process_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL,
  p_reason TEXT DEFAULT NULL,
  p_mark_booking_cancelled BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_mark_cancel BOOLEAN := COALESCE(p_mark_booking_cancelled, false);
  v_split JSONB;
  v_is_full BOOLEAN;
  v_next_pay_status public.payment_status_type;
  v_prev_pay_status public.payment_status_type;
  v_delta_gross NUMERIC(12,2);
  v_delta_comm NUMERIC(12,2);
  v_delta_net NUMERIC(12,2);
  v_pending_req_amount NUMERIC(12,2);
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Contexto de autenticação inválido ou não autorizado para confirmar estorno.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo do estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);

  -- F02-A: Parceiro e turista nunca podem confirmar/liquidar estornos diretamente
  IF v_actor_role = 'partner' THEN
    RAISE EXCEPTION 'PARTNER_REFUND_CONFIRM_FORBIDDEN: Parceiros podem apenas solicitar estorno via request_booking_refund(), sendo a confirmação restrita à administração ou ao gateway.'
      USING ERRCODE = '42501';
  END IF;

  IF v_actor_role IS NULL OR v_actor_role <> 'admin' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou service_role podem confirmar e processar estornos financeiros.'
      USING ERRCODE = '42501';
  END IF;

  IF p_refund_amount IS NOT NULL AND pg_catalog.round(p_refund_amount::numeric, 2) <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      pg_catalog.round(p_refund_amount::numeric, 2)
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- F06-C & D09: Verifica idempotência rigorosa ANTES de calcular o saldo residual mutável quando p_refund_amount IS NULL
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_type NOT IN ('REFUND_FULL', 'REFUND_PARTIAL')
       OR (
         p_refund_amount IS NOT NULL
         AND v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount
       )
       OR (
         p_refund_amount IS NULL
         AND (v_hist_existing.metadata_json ? 'input_refund_amount')
         AND (v_hist_existing.metadata_json->>'input_refund_amount') IS NOT NULL
       )
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason
       OR COALESCE((v_hist_existing.metadata_json->>'mark_booking_cancelled')::boolean, false) IS DISTINCT FROM v_mark_cancel THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de estorno (%) reutilizada com parâmetros divergentes.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'payment_status', v_payment.payment_status,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'refunded_commission_amount', v_payment.refunded_commission_amount,
      'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  SELECT bph.operation_amount INTO v_pending_req_amount
  FROM public.booking_payment_history AS bph
  WHERE bph.payment_id = v_payment.id
    AND bph.operation_type IN ('REFUND_REQUESTED', 'REFUND_REQUESTED_ON_BOOKING_CANCEL')
  ORDER BY bph.created_at DESC, bph.id DESC
  LIMIT 1;

  IF p_refund_amount IS NULL THEN
    IF v_payment.payment_status = 'ESTORNO_PENDENTE' AND COALESCE(v_pending_req_amount, 0) > 0 THEN
      v_req_amount := v_pending_req_amount;
    ELSE
      v_req_amount := v_payment.effective_gross_amount;
    END IF;
  ELSIF v_payment.payment_status = 'ESTORNO_PENDENTE'
        AND COALESCE(v_pending_req_amount, 0) > 0
        AND v_req_amount > v_pending_req_amount THEN
    RAISE EXCEPTION 'REFUND_EXCEEDS_REQUESTED_AMOUNT: O valor confirmado para estorno (%) excede o valor solicitado pendente (%).',
      v_req_amount, v_pending_req_amount
      USING ERRCODE = '23514';
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido estornar um pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  v_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_is_full := (v_split->>'is_full_refund')::boolean;
  v_next_pay_status := CASE WHEN v_is_full THEN 'ESTORNADO'::public.payment_status_type ELSE 'ESTORNO_PARCIAL'::public.payment_status_type END;
  v_prev_pay_status := v_payment.payment_status;
  v_delta_gross := (v_split->>'refund_gross_delta')::numeric(12,2);
  v_delta_comm := (v_split->>'refund_commission_delta')::numeric(12,2);
  v_delta_net := (v_split->>'refund_net_delta')::numeric(12,2);

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, v_next_pay_status::text);
  UPDATE public.booking_payments
  SET payment_status = v_next_pay_status,
      refunded_gross_amount = (v_split->>'total_refunded_gross')::numeric(12,2),
      refunded_commission_amount = (v_split->>'total_refunded_commission')::numeric(12,2),
      refunded_net_partner_amount = (v_split->>'total_refunded_net')::numeric(12,2),
      effective_gross_amount = (v_split->>'effective_gross_amount')::numeric(12,2),
      effective_commission_amount = (v_split->>'effective_commission_amount')::numeric(12,2),
      effective_net_partner_amount = (v_split->>'effective_net_partner_amount')::numeric(12,2),
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason,
      refunded_at = now()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  -- D10: Se o Admin executou process_booking_refund diretamente a partir de PAGO ou ESTORNO_PARCIAL,
  -- registra primeiro a solicitação administrativa implícita (ESTORNO_PENDENTE / REFUND_REQUESTED) no histórico
  IF v_prev_pay_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
    INSERT INTO public.booking_payment_history (
      payment_id,
      booking_id,
      partner_id,
      previous_status,
      new_status,
      operation_type,
      operation_amount,
      idempotency_key,
      actor_user_id,
      actor_role,
      reason,
      metadata_json
    ) VALUES (
      v_payment.id,
      v_booking.id,
      v_booking.partner_id,
      v_prev_pay_status,
      'ESTORNO_PENDENTE',
      'REFUND_REQUESTED',
      v_delta_gross,
      'aut-req-' || v_clean_idem,
      v_uid,
      v_actor_role,
      v_clean_reason,
      jsonb_build_object(
        'input_reason', v_clean_reason,
        'requested_refund_amount', v_delta_gross,
        'auto_admin_request', true
      )
    )
    ON CONFLICT (idempotency_key) DO NOTHING;
    PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
  END IF;

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    CASE WHEN v_prev_pay_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN 'ESTORNO_PENDENTE'::public.payment_status_type ELSE v_prev_pay_status END,
    v_next_pay_status,
    CASE WHEN v_is_full THEN 'REFUND_FULL' ELSE 'REFUND_PARTIAL' END,
    v_delta_gross,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    v_split || jsonb_build_object(
      'input_reason', v_clean_reason,
      'input_refund_amount', CASE WHEN p_refund_amount IS NULL THEN NULL ELSE v_req_amount END,
      'mark_booking_cancelled', v_mark_cancel
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Registra lançamento compensatório negativo (append-only) no razão financeiro
  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_payment.id,
    v_booking.partner_id,
    v_booking.tour_id,
    CASE WHEN v_is_full THEN 'REFUND_FULL'::public.financial_entry_type ELSE 'REFUND_PARTIAL'::public.financial_entry_type END,
    -v_delta_gross,
    -v_delta_comm,
    -v_delta_net,
    'BRL',
    'fled-ref-' || v_clean_idem,
    v_payment.external_transaction_id,
    pg_catalog.format('Estorno %s confirmado na reserva %s: %s', CASE WHEN v_is_full THEN 'integral' ELSE 'parcial' END, v_booking.code, v_clean_reason),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Se o estorno foi integral ou solicitado cancelamento conjunto da reserva e a reserva ainda está ativa
  IF (v_is_full OR v_mark_cancel) AND v_booking.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'EM_DISPUTA') THEN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_booking.id, 'CANCELADA');
    PERFORM internal_guard.issue_token('LEDGER_SYNC', v_booking.id, 'REVERTIDA');
    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = v_clean_reason,
        cancelled_at = COALESCE(cancelled_at, now())
    WHERE id = v_booking.id;
    PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_booking.id);
    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_booking.id);
  -- D13 (Missão 02.25): Quando o estorno é integral (ESTORNADO) e a reserva já se encontra no estado
  -- terminal PASSEIO_REALIZADO, preserva bookings.status = 'PASSEIO_REALIZADO' e reverte atomicamente
  -- commission_ledger.ledger_status ('CONFIRMADA' ou 'PAGA' -> 'REVERTIDA') sob token REFUND_FULL_REVERT
  ELSIF v_is_full AND v_booking.status = 'PASSEIO_REALIZADO' THEN
    PERFORM internal_guard.issue_token('LEDGER_SYNC', v_booking.id, 'REFUND_FULL_REVERT');
    UPDATE public.commission_ledger
    SET ledger_status = 'REVERTIDA',
        reversed_at = COALESCE(reversed_at, now()),
        adjustment_notes = COALESCE(v_clean_reason, adjustment_notes),
        updated_by = v_uid,
        updated_at = now()
    WHERE booking_id = v_booking.id
      AND ledger_status <> 'REVERTIDA';
    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_booking.id);
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    CASE WHEN v_is_full THEN 'CONFIRM_REFUND_FULL' ELSE 'CONFIRM_REFUND_PARTIAL' END,
    jsonb_build_object('payment_status', v_prev_pay_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'refund_gross_delta', v_delta_gross,
      'refund_commission_delta', v_delta_comm,
      'refund_net_delta', v_delta_net,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'refund_gross_delta', v_delta_gross,
    'refund_commission_delta', v_delta_comm,
    'refund_net_delta', v_delta_net,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;

-- ----------------------------------------------------------------------------
-- 3. D13-C: public.get_financial_reconciliation_report()
--    Garante que qualquer pagamento em ESTORNADO cujo commission_ledger não
--    esteja em REVERTIDA seja sinalizado como INCONSISTENT_REFUND_STATE.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_financial_reconciliation_report(
  p_partner_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_admin BOOLEAN := false;
  v_effective_partner_id UUID := p_partner_id;
  v_discrepancies JSONB := '[]'::jsonb;
  v_item RECORD;
  v_exp_gross NUMERIC(12,2);
  v_exp_comm NUMERIC(12,2);
  v_exp_net NUMERIC(12,2);
  v_last_hist_status public.payment_status_type;
  v_hist_count INTEGER;
  v_fle_count INTEGER;
  v_fle_sum_gross NUMERIC(12,2);
  v_fle_sum_comm NUMERIC(12,2);
  v_fle_sum_net NUMERIC(12,2);
  v_dup_pay_confirmed INTEGER;
  v_dup_refund_full INTEGER;
  v_dup_payout_settled INTEGER;
  v_exp_fle_gross NUMERIC(12,2);
  v_exp_fle_comm NUMERIC(12,2);
  v_exp_fle_net NUMERIC(12,2);
  v_total_gross_received NUMERIC(12,2) := 0.00;
  v_total_commissions NUMERIC(12,2) := 0.00;
  v_total_net_partner NUMERIC(12,2) := 0.00;
  v_total_refunded NUMERIC(12,2) := 0.00;
  v_pending_payments_count INTEGER := 0;
  v_confirmed_payments_count INTEGER := 0;
  v_refunded_payments_count INTEGER := 0;
  v_pending_refunds_count INTEGER := 0;
  v_orphan_payments_count INTEGER := 0;
  v_orphan_history_count INTEGER := 0;
  v_refund_req_count INTEGER := 0;
  v_improper_refund_count INTEGER := 0;
  v_orph_pay RECORD;
  v_orph_hist RECORD;
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Autenticação válida é obrigatória para consultar conciliação financeira.'
      USING ERRCODE = '42501';
  END IF;

  IF public.is_admin() OR (
    v_uid IS NULL
    AND v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND v_json_role IS DISTINCT FROM 'anon'
    AND v_json_role IS DISTINCT FROM 'authenticated'
    AND (
      (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
      OR (
        v_db_role IN ('none', 'postgres', 'supabase_admin')
        AND session_user IN ('postgres', 'supabase_admin', 'service_role')
        AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
      )
    )
  ) THEN
    v_is_admin := true;
  END IF;

  IF NOT v_is_admin THEN
    IF v_uid IS NULL THEN
      RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Sessão não autenticada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_effective_partner_id IS NULL THEN
      SELECT pm.partner_id INTO v_effective_partner_id
      FROM public.partner_members AS pm
      WHERE pm.user_id = v_uid AND pm.is_active = true
      LIMIT 1;
    END IF;

    IF v_effective_partner_id IS NULL OR NOT public.is_partner_member(v_effective_partner_id) THEN
      RAISE EXCEPTION 'CROSS_TENANT_FINANCIAL_ACCESS_DENIED: Usuário não possui permissão financeira para consultar este parceiro.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  FOR v_item IN
    SELECT
      bk.id AS booking_id,
      bk.code AS booking_code,
      bk.partner_id,
      bk.tour_id,
      bk.passengers,
      bk.status AS booking_status,
      bk.pricing_model_snapshot,
      bk.unit_price_snapshot,
      bk.commission_model_snapshot,
      bk.commission_rate_snapshot,
      bk.commission_fixed_snapshot,
      bk.gross_amount AS booking_gross,
      bk.commission_amount AS booking_commission,
      bk.net_partner_amount AS booking_net,
      cl.id AS commission_ledger_id,
      cl.ledger_status,
      cl.gross_amount AS ledger_gross,
      cl.commission_amount AS ledger_commission,
      cl.net_partner_amount AS ledger_net,
      bp.id AS payment_id,
      bp.payment_status,
      bp.gross_amount AS payment_gross,
      bp.commission_amount AS payment_commission,
      bp.net_partner_amount AS payment_net,
      bp.refunded_gross_amount,
      bp.refunded_commission_amount,
      bp.refunded_net_partner_amount,
      bp.effective_gross_amount,
      bp.effective_commission_amount,
      bp.effective_net_partner_amount
    FROM public.bookings AS bk
    LEFT JOIN public.commission_ledger AS cl ON cl.booking_id = bk.id
    LEFT JOIN public.booking_payments AS bp ON bp.booking_id = bk.id
    WHERE (v_effective_partner_id IS NULL OR bk.partner_id = v_effective_partner_id)
    ORDER BY bk.created_at ASC
  LOOP
    -- F05-B: Calcula os valores esperados exclusivamente a partir do snapshot histórico persistido na reserva
    IF v_item.pricing_model_snapshot = 'POR_EMBARCACAO' THEN
      v_exp_gross := pg_catalog.round(COALESCE(v_item.unit_price_snapshot, 0)::numeric, 2);
    ELSE
      v_exp_gross := pg_catalog.round((COALESCE(v_item.unit_price_snapshot, 0) * COALESCE(v_item.passengers, 1))::numeric, 2);
    END IF;

    IF v_item.commission_model_snapshot = 'PERCENTUAL' THEN
      v_exp_comm := pg_catalog.round((v_exp_gross * COALESCE(v_item.commission_rate_snapshot, 0)) / 100.0, 2);
    ELSIF v_item.commission_model_snapshot = 'VALOR_FIXO' THEN
      v_exp_comm := pg_catalog.least(v_exp_gross, pg_catalog.round(COALESCE(v_item.commission_fixed_snapshot, 0)::numeric, 2));
    ELSE
      v_exp_comm := pg_catalog.least(
        v_exp_gross,
        pg_catalog.round(((v_exp_gross * COALESCE(v_item.commission_rate_snapshot, 0)) / 100.0) + COALESCE(v_item.commission_fixed_snapshot, 0), 2)
      );
    END IF;

    v_exp_net := v_exp_gross - v_exp_comm;

    -- 1. Divergência de split financeiro ou snapshot histórico (bookings vs snapshot vs commission_ledger vs booking_payments)
    IF v_item.booking_gross <> (v_item.booking_commission + v_item.booking_net)
       OR v_item.booking_gross <> v_exp_gross
       OR v_item.booking_commission <> v_exp_comm
       OR v_item.booking_net <> v_exp_net
       OR (v_item.ledger_gross IS NOT NULL AND (
            v_item.ledger_gross <> v_item.booking_gross
            OR v_item.ledger_commission <> v_item.booking_commission
            OR v_item.ledger_net <> v_item.booking_net
          ))
       OR (v_item.payment_id IS NOT NULL AND (
            v_item.payment_gross <> v_item.booking_gross
            OR v_item.payment_commission <> v_item.booking_commission
            OR v_item.payment_net <> v_item.booking_net
            OR v_item.effective_gross_amount <> (v_item.payment_gross - v_item.refunded_gross_amount)
            OR v_item.effective_commission_amount <> (v_item.payment_commission - v_item.refunded_commission_amount)
            OR v_item.effective_net_partner_amount <> (v_item.payment_net - v_item.refunded_net_partner_amount)
            OR v_item.effective_gross_amount <> (v_item.effective_commission_amount + v_item.effective_net_partner_amount)
          )) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'FINANCIAL_SPLIT_MISMATCH',
          'expected_gross', v_exp_gross,
          'expected_commission', v_exp_comm,
          'expected_net', v_exp_net,
          'recorded_booking_gross', v_item.booking_gross,
          'recorded_ledger_gross', v_item.ledger_gross,
          'recorded_payment_gross', v_item.payment_gross,
          'justification', 'Divergência entre o snapshot histórico da reserva, os valores da reserva, o livro-razão de comissões ou o pagamento.'
        )
      );
    END IF;

    -- 2. Reserva concluída (PASSEIO_REALIZADO) sem pagamento confirmado compatível
    IF v_item.booking_status = 'PASSEIO_REALIZADO'
       AND (v_item.payment_id IS NULL OR v_item.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL', 'ESTORNADO')) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'COMPLETED_BOOKING_UNPAID',
          'booking_status', v_item.booking_status,
          'payment_status', COALESCE(v_item.payment_status::text, 'SEM_PAGAMENTO'),
          'justification', 'Reserva marcada como PASSEIO_REALIZADO não possui pagamento confirmado.'
        )
      );
    END IF;

    -- 3. Reserva cancelada/recusada com pagamento não sincronizado (PENDENTE, PROCESSANDO, FALHOU, PAGO, ESTORNO_PARCIAL)
    IF v_item.booking_status IN ('CANCELADA', 'RECUSADA')
       AND v_item.payment_id IS NOT NULL
       AND v_item.payment_status IN ('PENDENTE', 'PROCESSANDO', 'FALHOU', 'PAGO', 'ESTORNO_PARCIAL') THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'CANCELLED_BOOKING_UNREFUNDED_PAYMENT',
          'booking_status', v_item.booking_status,
          'payment_status', v_item.payment_status,
          'justification', 'Reserva cancelada/recusada possui pagamento dessincronizado (sem transição para CANCELADO ou ESTORNO_PENDENTE/ESTORNADO).'
        )
      );
    END IF;

    -- 4. Estorno inconsistente (D13-C: inclui verificação de commission_ledger.ledger_status = 'REVERTIDA' quando payment_status = 'ESTORNADO')
    IF v_item.payment_id IS NOT NULL AND (
         (v_item.payment_status = 'ESTORNADO' AND (
            v_item.refunded_gross_amount <> v_item.payment_gross
            OR v_item.effective_gross_amount <> 0
            OR (v_item.commission_ledger_id IS NOT NULL AND v_item.ledger_status IS DISTINCT FROM 'REVERTIDA')
         ))
         OR (v_item.payment_status = 'ESTORNO_PARCIAL' AND (v_item.refunded_gross_amount <= 0 OR v_item.refunded_gross_amount >= v_item.payment_gross))
         OR (v_item.payment_status IN ('PENDENTE', 'PROCESSANDO', 'FALHOU', 'CANCELADO') AND v_item.refunded_gross_amount > 0)
       ) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'INCONSISTENT_REFUND_STATE',
          'payment_status', v_item.payment_status,
          'ledger_status', v_item.ledger_status,
          'refunded_gross_amount', v_item.refunded_gross_amount,
          'effective_gross_amount', v_item.effective_gross_amount,
          'justification', 'Estado de estorno do pagamento incompatível com os montantes estornado/efetivo ou com o status do livro-razão de comissões.'
        )
      );
    END IF;

    -- 5. Liquidação de comissão (PAGA) sem pagamento confirmado ou saldo líquido positivo
    IF v_item.ledger_status = 'PAGA'
       AND (
         v_item.booking_status <> 'PASSEIO_REALIZADO'
         OR v_item.payment_id IS NULL
         OR v_item.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL')
         OR v_item.effective_net_partner_amount <= 0
       ) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'SETTLED_COMMISSION_WITHOUT_CONFIRMED_PAYMENT',
          'booking_status', v_item.booking_status,
          'ledger_status', v_item.ledger_status,
          'payment_status', COALESCE(v_item.payment_status::text, 'SEM_PAGAMENTO'),
          'justification', 'Comissão consta como PAGA no livro-razão sem pagamento confirmado ativo e passeio realizado.'
        )
      );
    END IF;

    -- 6. Conciliação cruzada com booking_payment_history e financial_ledger_entries
    IF v_item.payment_id IS NOT NULL THEN
      SELECT COUNT(*) INTO v_hist_count
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id;

      SELECT bph.new_status INTO v_last_hist_status
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id
      ORDER BY bph.created_at DESC, bph.id DESC
      LIMIT 1;

      IF v_hist_count = 0 OR v_last_hist_status IS DISTINCT FROM v_item.payment_status THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'PAYMENT_HISTORY_MISMATCH',
            'payment_status', v_item.payment_status,
            'last_history_status', v_last_hist_status,
            'history_entries_count', v_hist_count,
            'justification', 'O último estado registrado em booking_payment_history diverge do status atual em booking_payments.'
          )
        );
      END IF;

      -- 6B. Estorno sem solicitação prévia em 2 etapas (REFUND_WITHOUT_REQUEST)
      IF v_item.payment_status IN ('ESTORNADO', 'ESTORNO_PARCIAL') OR v_item.refunded_gross_amount > 0 THEN
        SELECT COUNT(*) INTO v_refund_req_count
        FROM public.booking_payment_history AS bph
        WHERE bph.payment_id = v_item.payment_id
          AND (
            bph.new_status = 'ESTORNO_PENDENTE'
            OR bph.operation_type IN ('REFUND_REQUESTED', 'REFUND_REQUESTED_ON_BOOKING_CANCEL')
          );

        IF v_refund_req_count = 0 THEN
          v_discrepancies := v_discrepancies || jsonb_build_array(
            jsonb_build_object(
              'booking_id', v_item.booking_id,
              'booking_code', v_item.booking_code,
              'discrepancy_code', 'REFUND_WITHOUT_REQUEST',
              'payment_status', v_item.payment_status,
              'refunded_gross_amount', v_item.refunded_gross_amount,
              'justification', 'Estorno confirmado sem registro prévio de solicitação (ESTORNO_PENDENTE) em booking_payment_history.'
            )
          );
        END IF;
      END IF;

      -- 6C. Estorno pendente indevidamente finalizado (PENDING_REFUND_IMPROPERLY_FINALIZED)
      SELECT COUNT(*) INTO v_improper_refund_count
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id
        AND bph.operation_type IN ('REFUND_FULL', 'REFUND_PARTIAL')
        AND bph.actor_role IN ('partner', 'tourist');

      IF v_improper_refund_count > 0
         OR (
           v_item.payment_status = 'ESTORNO_PENDENTE'
           AND v_item.refunded_gross_amount > 0
           AND NOT EXISTS (
             SELECT 1 FROM public.booking_payment_history AS bph
             WHERE bph.payment_id = v_item.payment_id
               AND bph.operation_type = 'REFUND_PARTIAL'
           )
         ) THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'PENDING_REFUND_IMPROPERLY_FINALIZED',
            'payment_status', v_item.payment_status,
            'refunded_gross_amount', v_item.refunded_gross_amount,
            'justification', 'Estorno pendente finalizado por papel não autorizado ou com abatimento contábil prematuro antes da confirmação administrativa.'
          )
        );
      END IF;

      SELECT
        COUNT(*),
        COALESCE(SUM(fle.gross_delta), 0.00),
        COALESCE(SUM(fle.commission_delta), 0.00),
        COALESCE(SUM(fle.net_partner_delta), 0.00),
        COUNT(*) FILTER (WHERE fle.entry_type = 'PAYMENT_CONFIRMED'),
        COUNT(*) FILTER (WHERE fle.entry_type = 'REFUND_FULL'),
        COUNT(*) FILTER (WHERE fle.entry_type = 'PARTNER_PAYOUT_SETTLED')
      INTO
        v_fle_count,
        v_fle_sum_gross,
        v_fle_sum_comm,
        v_fle_sum_net,
        v_dup_pay_confirmed,
        v_dup_refund_full,
        v_dup_payout_settled
      FROM public.financial_ledger_entries AS fle
      WHERE fle.booking_id = v_item.booking_id;

      IF v_item.payment_status IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL', 'ESTORNADO') THEN
        v_exp_fle_gross := v_item.effective_gross_amount;
        v_exp_fle_comm := v_item.effective_commission_amount;
        v_exp_fle_net := v_item.effective_net_partner_amount;
      ELSE
        v_exp_fle_gross := 0.00;
        v_exp_fle_comm := 0.00;
        v_exp_fle_net := 0.00;
      END IF;

      IF v_fle_count = 0
         OR v_fle_sum_gross <> v_exp_fle_gross
         OR v_fle_sum_comm <> v_exp_fle_comm
         OR v_fle_sum_net <> v_exp_fle_net THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'LEDGER_ENTRIES_SUM_MISMATCH',
            'expected_effective_gross', v_exp_fle_gross,
            'ledger_entries_sum_gross', v_fle_sum_gross,
            'expected_effective_commission', v_exp_fle_comm,
            'ledger_entries_sum_commission', v_fle_sum_comm,
            'expected_effective_net', v_exp_fle_net,
            'ledger_entries_sum_net', v_fle_sum_net,
            'justification', 'A soma algébrica dos lançamentos em financial_ledger_entries diverge do saldo efetivo do pagamento.'
          )
        );
      END IF;

      IF v_dup_pay_confirmed > 1 OR v_dup_refund_full > 1 OR v_dup_payout_settled > 1 THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'DUPLICATE_LEDGER_ENTRY',
            'payment_confirmed_entries', v_dup_pay_confirmed,
            'refund_full_entries', v_dup_refund_full,
            'payout_settled_entries', v_dup_payout_settled,
            'justification', 'Foram detectados lançamentos contábeis unitários duplicados em financial_ledger_entries.'
          )
        );
      END IF;

      -- Acumuladores financeiros por estado
      IF v_item.payment_status IN ('PENDENTE', 'PROCESSANDO') THEN
        v_pending_payments_count := v_pending_payments_count + 1;
      ELSIF v_item.payment_status = 'ESTORNO_PENDENTE' THEN
        v_pending_refunds_count := v_pending_refunds_count + 1;
        v_confirmed_payments_count := v_confirmed_payments_count + 1;
        v_total_gross_received := v_total_gross_received + v_item.effective_gross_amount;
        v_total_commissions := v_total_commissions + v_item.effective_commission_amount;
        v_total_net_partner := v_total_net_partner + v_item.effective_net_partner_amount;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      ELSIF v_item.payment_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
        v_confirmed_payments_count := v_confirmed_payments_count + 1;
        v_total_gross_received := v_total_gross_received + v_item.effective_gross_amount;
        v_total_commissions := v_total_commissions + v_item.effective_commission_amount;
        v_total_net_partner := v_total_net_partner + v_item.effective_net_partner_amount;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      ELSIF v_item.payment_status = 'ESTORNADO' THEN
        v_refunded_payments_count := v_refunded_payments_count + 1;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      END IF;
    END IF;
  END LOOP;

  -- 7. Pagamentos órfãos sem reserva correspondente (ORPHAN_PAYMENT_WITHOUT_BOOKING)
  FOR v_orph_pay IN
    SELECT bp.id AS payment_id, bp.booking_id, bp.partner_id, bp.payment_status, bp.gross_amount
    FROM public.booking_payments AS bp
    WHERE NOT EXISTS (SELECT 1 FROM public.bookings AS bk WHERE bk.id = bp.booking_id)
      AND (v_effective_partner_id IS NULL OR bp.partner_id = v_effective_partner_id)
  LOOP
    v_orphan_payments_count := v_orphan_payments_count + 1;
    v_discrepancies := v_discrepancies || jsonb_build_array(
      jsonb_build_object(
        'booking_id', v_orph_pay.booking_id,
        'payment_id', v_orph_pay.payment_id,
        'discrepancy_code', 'ORPHAN_PAYMENT_WITHOUT_BOOKING',
        'payment_status', v_orph_pay.payment_status,
        'recorded_payment_gross', v_orph_pay.gross_amount,
        'justification', 'Pagamento órfão em booking_payments sem reserva correspondente em bookings.'
      )
    );
  END LOOP;

  -- 8. Históricos de pagamento órfãos sem registro correspondente em booking_payments (ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT)
  FOR v_orph_hist IN
    SELECT bph.id AS history_id, bph.payment_id, bph.booking_id, bph.new_status, bph.operation_type
    FROM public.booking_payment_history AS bph
    WHERE NOT EXISTS (SELECT 1 FROM public.booking_payments AS bp WHERE bp.id = bph.payment_id)
      AND (v_effective_partner_id IS NULL OR bph.partner_id = v_effective_partner_id)
  LOOP
    v_orphan_history_count := v_orphan_history_count + 1;
    v_discrepancies := v_discrepancies || jsonb_build_array(
      jsonb_build_object(
        'booking_id', v_orph_hist.booking_id,
        'payment_id', v_orph_hist.payment_id,
        'history_id', v_orph_hist.history_id,
        'discrepancy_code', 'ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT',
        'last_history_status', v_orph_hist.new_status,
        'justification', 'Registro órfão em booking_payment_history sem pagamento correspondente em booking_payments.'
      )
    );
  END LOOP;

  RETURN jsonb_build_object(
    'ok', true,
    'scope_partner_id', v_effective_partner_id,
    'total_gross_received', v_total_gross_received,
    'total_commissions', v_total_commissions,
    'total_net_partner', v_total_net_partner,
    'total_refunded', v_total_refunded,
    'pending_payments_count', v_pending_payments_count,
    'pending_refunds_count', v_pending_refunds_count,
    'confirmed_payments_count', v_confirmed_payments_count,
    'refunded_payments_count', v_refunded_payments_count,
    'orphan_payments_count', v_orphan_payments_count,
    'orphan_history_count', v_orphan_history_count,
    'discrepancies_count', pg_catalog.jsonb_array_length(v_discrepancies),
    'discrepancies', v_discrepancies
  );
END;
$body$;

-- ----------------------------------------------------------------------------
-- 4. Ownership Explícito (OWNER TO postgres) e Privilégios Mínimos (F08-A & F08-C)
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
    ALTER FUNCTION public.enforce_commission_ledger_integrity() OWNER TO postgres;
    ALTER FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) OWNER TO postgres;
    ALTER FUNCTION public.get_financial_reconciliation_report(UUID) OWNER TO postgres;
  END IF;

  FOR r_fn IN
    SELECT p_proc.oid::regprocedure AS fn_sig, p_proc.proname AS fn_name
    FROM pg_proc AS p_proc
    JOIN pg_namespace AS n_ns ON n_ns.oid = p_proc.pronamespace
    WHERE n_ns.nspname = 'public'
      AND p_proc.proname IN (
        'enforce_commission_ledger_integrity',
        'process_booking_refund',
        'get_financial_reconciliation_report'
      )
  LOOP
    EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM service_role', r_fn.fn_sig);
    END IF;
  END LOOP;

  -- Concede EXECUTE apenas nas RPCs (NUNCA na função de trigger enforce_commission_ledger_integrity)
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_financial_reconciliation_report(UUID) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO service_role;
    GRANT EXECUTE ON FUNCTION public.get_financial_reconciliation_report(UUID) TO service_role;
  END IF;
END
$$;
