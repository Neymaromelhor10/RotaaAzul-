-- ============================================================================
-- MIGRATION 0008: MISSÃO 01.9 — COMPLEMENTAÇÃO FORENSE DE ANONIMIZAÇÃO LGPD
-- (M01.9-004 E SUPORTE AOS TESTES T9.1 A T9.14)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations 000001 a 000007 preservadas integralmente.
-- Justificativa Técnica da Migration Incremental 000008:
--   A auditoria independente da Missão 01.8 identificou que a RPC
--   public.admin_anonymize_customer_pii(UUID, TEXT) introduzida na 000007:
--   1) Não sanitizava o campo livre public.bookings.rejection_or_cancel_reason
--      nem desvinculava public.bookings.tourist_user_id (permitindo reidentificação
--      por associação com public.profiles).
--   2) Sanitizava apenas o registro inicial (previous_status IS NULL) de
--      public.booking_status_history, deixando potenciais dados pessoais em
--      registros posteriores de transição (reason) e changed_by do turista.
--   3) Não possuía regra explícita para sanitizar comentários de avaliações
--      (public.reviews.comment) quando contêm dados pessoais (telefone, e-mail,
--      CPF ou nome/contato do titular), nem desvinculava reviews.tourist_user_id.
--   4) Sanitizava apenas 4 chaves em public.audit_logs (customer_name,
--      customer_phone, customer_email, notes), sem abranger reason,
--      rejection_reason, cancel_reason, rejection_or_cancel_reason,
--      tourist_user_id, author_name, author_city e comment.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. EXCEÇÃO CONTROLADA E AUTENTICADA POR TOKEN EM enforce_booking_invariants_and_transitions()
-- Permite que exclusivamente a RPC public.admin_anonymize_customer_pii(), mediante
-- emissão de token 'BOOKING_MUTATION' com estado 'LGPD_ANONYMIZE:<status>',
-- desvincule tourist_user_id := NULL e sanitize customer_name, customer_phone,
-- customer_email, notes e rejection_or_cancel_reason, mantendo 100% imutáveis
-- todos os campos financeiros, de datas, passageiros, status e códigos.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. EXCEÇÃO CONTROLADA POR TOKEN EM validate_verified_review() PARA SANITIZAÇÃO LGPD
-- Permite que exclusivamente admin_anonymize_customer_pii(), mediante token
-- 'REVIEW_MUTATION' com estado 'ANONYMIZE_LGPD', desvincule tourist_user_id := NULL,
-- anonimize author_name / author_city e sanitize comment quando contiver PII,
-- mantendo nota (rating), vínculos de passeio/parceiro e reserva imutáveis.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.validate_verified_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_profile_active BOOLEAN := false;
  v_auth_user RECORD;
  v_lgpd_review_token BOOLEAN := false;
BEGIN
  v_is_admin_or_server := (
    v_db_role <> 'anon'
    AND v_jwt_role <> 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND public.is_admin()
  ) OR (
    v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
    AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
    AND v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    AND session_user IN ('postgres', 'supabase_admin', 'service_role')
  );

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_review_token := internal_guard.consume_token('REVIEW_MUTATION', OLD.booking_id, 'ANONYMIZE_LGPD');

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.rating IS DISTINCT FROM OLD.rating
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_review_token AND NEW.tourist_user_id IS NULL)
       )
       OR (
         NEW.comment IS DISTINCT FROM OLD.comment
         AND NOT v_lgpd_review_token
       )
       OR (
         (NEW.author_name IS DISTINCT FROM OLD.author_name OR NEW.author_city IS DISTINCT FROM OLD.author_city)
         AND NOT v_lgpd_review_token
       ) THEN
      RAISE EXCEPTION 'REVIEW_IMMUTABLE_CONTENT: Não é permitido alterar nota, comentário, autor ou vínculos de uma avaliação publicada fora da rotina oficial de anonimização LGPD.'
        USING ERRCODE = '42501';
    END IF;

    IF NOT v_is_admin_or_server THEN
      RAISE EXCEPTION 'REVIEW_MODERATION_ADMIN_ONLY: Somente administradores podem moderar a visibilidade de avaliações.'
        USING ERRCODE = '42501';
    END IF;

    RETURN NEW;
  END IF;

  -- TG_OP = 'INSERT': exige token emitido por public.create_verified_review() (exceto durante seed de servidor)
  IF NOT internal_guard.consume_token('REVIEW_MUTATION', NEW.booking_id, 'INSERT') THEN
    IF NOT (
      v_is_admin_or_server
      AND v_uid IS NULL
      AND v_db_role NOT IN ('anon', 'authenticated')
      AND v_jwt_role NOT IN ('anon', 'authenticated')
    ) THEN
      RAISE EXCEPTION 'DIRECT_REVIEW_INSERT_FORBIDDEN: Inserção direta em public.reviews é proibida. Utilize public.create_verified_review().'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  SELECT id, code, tour_id, partner_id, tourist_user_id, customer_name, status
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: A reserva informada (%) não existe.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_REQUIRES_COMPLETED_BOOKING: Avaliações só podem ser publicadas para reservas com status PASSEIO_REALIZADO (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS DISTINCT FROM v_booking.tour_id OR NEW.partner_id IS DISTINCT FROM v_booking.partner_id THEN
    RAISE EXCEPTION 'REVIEW_ENTITY_MISMATCH: O passeio ou parceiro da avaliação não corresponde à reserva %.',
      v_booking.code
      USING ERRCODE = '23514';
  END IF;

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas criadas sem usuário autenticado (tourist_user_id IS NULL) não podem ser avaliadas sem vinculação prévia verificada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular autenticado da reserva (%) pode avaliá-la.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de usuário inativa ou perfil não localizado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT
      u.id,
      u.email_confirmed_at,
      u.confirmed_at,
      u.raw_app_meta_data,
      u.raw_user_meta_data
      INTO v_auth_user
    FROM auth.users u
    WHERE u.id = v_uid;

    IF v_auth_user.id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Conta de autenticação não localizada em auth.users.'
        USING ERRCODE = '42501';
    END IF;

    IF COALESCE(v_auth_user.email_confirmed_at, v_auth_user.confirmed_at) IS NULL
       OR COALESCE(v_auth_user.raw_app_meta_data->>'email_verified', 'true') = 'false'
       OR COALESCE(v_auth_user.raw_user_meta_data->>'email_verified', 'true') = 'false' THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: É necessário confirmar seu endereço de e-mail antes de publicar uma avaliação.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  NEW.tourist_user_id := v_booking.tourist_user_id;
  NEW.author_name := COALESCE(NULLIF(trim(COALESCE(NEW.author_name, '')), ''), v_booking.customer_name);
  NEW.author_city := COALESCE(NULLIF(trim(COALESCE(NEW.author_city, '')), ''), 'Visitante Verificado');

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. COMPLEMENTAÇÃO DA RPC public.admin_anonymize_customer_pii(UUID, TEXT)
--    (M01.9-004 & M01.9-005 — T9.1 A T9.14)
-- Cobertura integral:
--   - Autorização estrita verificada ANTES de qualquer consulta à tabela bookings
--     (não vaza existência da reserva nem PII em chamadas negadas — T9.2, T9.3, T9.14).
--   - public.bookings:
--     * tourist_user_id -> NULL (elimina reidentificação por associação com profiles)
--     * customer_name -> 'TITULAR ANONIMIZADO LGPD' (anonimizado)
--     * customer_phone -> '(00) 00000-0000' (anonimizado)
--     * customer_email -> 'anonimizado.<code_lower>@lgpd.invalid' (pseudonimizado por código contábil)
--     * notes -> '[LGPD <protocolo>] Observações livres sanitizadas conforme solicitação.'
--     * rejection_or_cancel_reason -> quando não nulo, '[LGPD <protocolo>] Motivo de cancelamento/recusa sanitizado.'
--   - public.booking_status_history (TODOS os registros da reserva — T9.8):
--     * reason -> '[LGPD <protocolo>] Transição (<prev> -> <new>) preservada com justificativa sanitizada.'
--     * changed_by -> NULL quando igual ao tourist_user_id original (mantendo changed_by de partner/admin).
--   - public.reviews (T9.10):
--     * tourist_user_id -> NULL
--     * author_name -> 'Turista Verificado (LGPD)'
--     * author_city -> 'Anonimizado'
--     * comment -> se contiver e-mail, telefone (8+ dígitos), CPF ou menção ao nome/e-mail/telefone
--       do titular, substitui por '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD <protocolo>]';
--       caso contrário, preserva o texto opinativo sem PII.
--   - public.audit_logs (T9.9 e T9.12):
--     * Sanitiza em old_data e new_data todas as chaves presentes dentre:
--       customer_name, customer_phone, customer_email, notes, reason,
--       rejection_reason, cancel_reason, rejection_or_cancel_reason,
--       tourist_user_id, author_name, author_city e comment.
--     * Desvincula actor_user_id -> NULL quando igual ao tourist_user_id original.
--     * Registra evento único ANONYMIZE_PII_LGPD com protocolo e responsável sem copiar PII antiga.
--   - Idempotência (T9.5 e T9.6):
--     * Segunda chamada retorna idempotent_replay = true e o protocolo original sem duplicar logs.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
BEGIN
  -- 1. Guarda estrita de autorização ANTES de acessar qualquer dado da reserva (T9.2, T9.3, T9.14)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock:
  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  -- Lock #3: Reserva em public.bookings (FOR UPDATE)
  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);

  -- Idempotência (T9.5 & T9.6): se a reserva já foi anonimizada, não duplica evento em audit_logs
  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount
    );
  END IF;

  -- Captura referências originais apenas em variáveis locais para detecção em comentários/logs (jamais persistidas)
  v_old_name := trim(COALESCE(v_target.customer_name, ''));
  v_old_email := lower(trim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  v_anon_notes := format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  -- 1. Atualiza PII e desvincula tourist_user_id em public.bookings via token específico LGPD_ANONYMIZE
  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  -- 2. Sanitiza TODOS os registros de public.booking_status_history da reserva (T9.8)
  --    Preserva previous_status, new_status, changed_by_role, created_at e changed_by quando não for o próprio turista.
  UPDATE public.booking_status_history
  SET reason = format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  -- 3. Tratamento de public.reviews (T9.10):
  --    Anonimiza author_name e author_city, desvincula tourist_user_id e sanitiza comment
  --    se contiver e-mail, telefone (8+ dígitos), CPF ou menção ao nome/e-mail/telefone do titular.
  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (char_length(v_old_name) >= 3 AND position(lower(v_old_name) in lower(v_review.comment)) > 0)
      OR (char_length(v_old_email) >= 5 AND position(v_old_email in lower(v_review.comment)) > 0)
      OR (char_length(v_old_phone_digits) >= 8 AND position(v_old_phone_digits in regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
    );

    IF v_comment_has_pii THEN
      v_new_review_comment := format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  -- 4. Sanitização abrangente de public.audit_logs (T9.9):
  --    Abrange customer_name, customer_phone, customer_email, notes, reason,
  --    rejection_reason, cancel_reason, rejection_or_cancel_reason, tourist_user_id,
  --    author_name, author_city e comment em old_data e new_data, sem apagar linhas.
  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          old_data
          || CASE WHEN old_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          new_data
          || CASE WHEN new_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  -- 5. Registra o evento auditável ANONYMIZE_PII_LGPD com protocolo e responsável SEM copiar PII antiga (T9.12)
  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'bookings',
    v_target.code,
    'ANONYMIZE_PII_LGPD',
    jsonb_build_object(
      'booking_id', v_target.id,
      'pii_redacted', true
    ),
    jsonb_build_object(
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'lgpd_protocol', v_clean_protocol,
      'performed_by', v_responsible_actor,
      'history_rows_sanitized', v_history_updated_count,
      'audit_rows_sanitized', v_audit_updated_count,
      'review_author_anonymized', v_review_updated,
      'review_comment_redacted', v_comment_has_pii,
      'financials_preserved', true
    )
  );

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000008
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
    REVOKE DELETE, TRUNCATE ON public.profiles FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    FOR r_fn IN
      SELECT p.oid::regprocedure AS fn_sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('public', 'internal_guard')
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END LOOP;
  END IF;
END
$$;
