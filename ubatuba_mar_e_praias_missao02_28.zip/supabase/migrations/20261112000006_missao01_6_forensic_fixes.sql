-- ============================================================================
-- MIGRATION 0006: MISSÃO 01.6 — CORREÇÃO CONTROLADA DOS ACHADOS DA AUDITORIA 01.5
-- (M01.5-05, M01.5-06, M01.5-07, M01.5-08, M01.5-09 E M01.5-12)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations 000001 a 000005 preservadas integralmente.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ENDURECIMENTO DE internal_guard.execution_tokens (M01.5-05 & M01.5-06)
-- - Adiciona o escopo 'REVIEW_MUTATION' na constraint de escopos válidos.
-- - Valida estritamente t.trigger_depth = pg_trigger_depth() - 1 em consume_token().
-- - Cria internal_guard.cleanup_tokens(p_scope, p_target_id) restrito à transação
--   e profundidade atuais para impedir tokens órfãos residuais.
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  v_con_name TEXT;
BEGIN
  FOR v_con_name IN
    SELECT con.conname
    FROM pg_constraint con
    JOIN pg_class rel ON rel.oid = con.conrelid
    JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
    WHERE nsp.nspname = 'internal_guard'
      AND rel.relname = 'execution_tokens'
      AND con.contype = 'c'
      AND pg_get_constraintdef(con.oid) LIKE '%scope%'
  LOOP
    EXECUTE format('ALTER TABLE internal_guard.execution_tokens DROP CONSTRAINT %I', v_con_name);
  END LOOP;
END
$$;

ALTER TABLE internal_guard.execution_tokens
  ADD CONSTRAINT chk_internal_guard_execution_tokens_scope
  CHECK (
    scope IN (
      'AUTH_PROFILE_SYNC',
      'BOOKING_MUTATION',
      'LEDGER_SYNC',
      'LEDGER_SETTLE',
      'CATALOG_RATING_SYNC',
      'AVAILABILITY_BLOCK_MUTATION',
      'REVIEW_MUTATION'
    )
  );

-- Consome atomicamente um token transacional de uso único validando:
-- 1) Mesma transação (t.txid = txid_current())
-- 2) Mesmo escopo (t.scope = p_scope)
-- 3) Mesmo registro alvo (t.target_id = p_target_id)
-- 4) Mesmo estado esperado (t.expected_state IS NOT DISTINCT FROM p_expected_state)
-- 5) Profundidade exata de disparo da trigger (t.trigger_depth = pg_trigger_depth() - 1)
CREATE OR REPLACE FUNCTION internal_guard.consume_token(
  p_scope TEXT,
  p_target_id UUID,
  p_expected_state TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_token_id BIGINT;
BEGIN
  DELETE FROM internal_guard.execution_tokens
  WHERE id = (
    SELECT t.id
    FROM internal_guard.execution_tokens t
    WHERE t.txid = txid_current()
      AND t.scope = p_scope
      AND t.target_id = p_target_id
      AND (p_expected_state IS NULL OR t.expected_state IS NOT DISTINCT FROM p_expected_state)
      AND t.trigger_depth = pg_trigger_depth() - 1
    ORDER BY t.id DESC
    LIMIT 1
  )
  RETURNING id INTO v_token_id;

  RETURN (v_token_id IS NOT NULL);
END;
$$;

-- Remove qualquer token residual não consumido emitido na mesma transação,
-- na mesma profundidade de execução (pg_trigger_depth()), mesmo escopo e mesmo alvo.
CREATE OR REPLACE FUNCTION internal_guard.cleanup_tokens(
  p_scope TEXT,
  p_target_id UUID
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_removed INTEGER := 0;
BEGIN
  DELETE FROM internal_guard.execution_tokens
  WHERE txid = txid_current()
    AND trigger_depth = pg_trigger_depth()
    AND scope = p_scope
    AND target_id = p_target_id;

  GET DIAGNOSTICS v_removed = ROW_COUNT;
  RETURN v_removed;
END;
$$;

REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION internal_guard.cleanup_tokens(TEXT, UUID) FROM PUBLIC;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION internal_guard.cleanup_tokens(TEXT, UUID) FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM authenticated;
    REVOKE ALL ON FUNCTION internal_guard.cleanup_tokens(TEXT, UUID) FROM authenticated;
  END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- 2. UNICIDADE, CONFLITOS DE RESERVAS PENDENTES E BLOQUEIO DE INSERT DIRETO
--    EM public.availability_blocks (M01.5-05, M01.5-08 & M01.5-09)
-- ----------------------------------------------------------------------------

-- Verifica antes da criação do índice único se existem duplicidades lógicas
-- (vessel_id, block_date, block_type, tour_id) sem excluir dados automaticamente.
DO $$
DECLARE
  v_dup_count INTEGER := 0;
BEGIN
  SELECT COUNT(*)::integer INTO v_dup_count
  FROM (
    SELECT vessel_id, block_date, block_type, tour_id
    FROM public.availability_blocks
    GROUP BY vessel_id, block_date, block_type, tour_id
    HAVING COUNT(*) > 1
  ) dups;

  IF v_dup_count > 0 THEN
    RAISE EXCEPTION 'DUPLICATE_AVAILABILITY_BLOCKS_FOUND: Encontrados % grupos de bloqueios duplicados em public.availability_blocks. Inspecione manualmente antes de criar o índice único.',
      v_dup_count
      USING ERRCODE = '23505';
  END IF;
END
$$;

-- Índice único tratando NULLS NOT DISTINCT em tour_id (nativo do PostgreSQL 15+)
CREATE UNIQUE INDEX IF NOT EXISTS idx_availability_blocks_unique_logical_key
  ON public.availability_blocks (vessel_id, block_date, block_type, tour_id)
  NULLS NOT DISTINCT;

-- Remove política RLS que permitia INSERT direto por parceiro autenticado fora da RPC
DROP POLICY IF EXISTS "availability_blocks_partner_insert" ON public.availability_blocks;

CREATE OR REPLACE FUNCTION public.validate_availability_block_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
  v_tour_partner UUID;
  v_tour_vessel UUID;
  v_active_occupied INTEGER := 0;
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_server_seed BOOLEAN;
BEGIN
  v_is_server_seed := (
    v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
  );

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.block_date IS DISTINCT FROM OLD.block_date THEN
      RAISE EXCEPTION 'BLOCK_IMMUTABLE_KEYS: Não é permitido alterar embarcação, parceiro ou data de um bloqueio existente; exclua e recrie via RPC.'
        USING ERRCODE = '42501';
    END IF;

    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_UPDATE_FORBIDDEN: Atualização direta em availability_blocks é proibida para evitar inversão da ordem de locks. Utilize public.upsert_availability_block().'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_OP = 'INSERT' THEN
    -- Exige token emitido por upsert_availability_block(), exceto durante seed de servidor (migration 000004)
    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      IF NOT v_is_server_seed THEN
        RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_INSERT_FORBIDDEN: Inserção direta em availability_blocks é proibida. Utilize public.upsert_availability_block().'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels
  WHERE id = NEW.vessel_id
  FOR UPDATE;

  IF v_vessel_partner IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', NEW.vessel_id
      USING ERRCODE = '23503';
  END IF;

  -- Lock #2: Advisory lock transacional (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(NEW.block_date::text));

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'BLOCK_VESSEL_OWNERSHIP_MISMATCH: A embarcação bloqueada não pertence ao parceiro informado.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS NOT NULL THEN
    SELECT partner_id, vessel_id INTO v_tour_partner, v_tour_vessel
    FROM public.tours
    WHERE id = NEW.tour_id;

    IF v_tour_partner IS DISTINCT FROM NEW.partner_id OR v_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
      RAISE EXCEPTION 'BLOCK_TOUR_MISMATCH: O passeio informado no bloqueio não pertence à mesma embarcação/parceiro.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override > v_vessel_cap THEN
    RAISE EXCEPTION 'OVERRIDE_EXCEEDS_VESSEL_CAPACITY: Ajuste de capacidade (%) excede a capacidade máxima da embarcação (%).',
      NEW.custom_capacity_override, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  -- Lock #3: Bloqueia pessimistamente todas as reservas ativas não expiradas na data (M01.5-08)
  PERFORM 1
  FROM public.bookings bk
  WHERE bk.vessel_id = NEW.vessel_id
    AND bk.booking_date = NEW.block_date
    AND (NEW.tour_id IS NULL OR bk.tour_id = NEW.tour_id)
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    )
  FOR UPDATE;

  -- Soma passageiros de todas as reservas ativas não expiradas (incluindo SOLICITADA e AGUARDANDO_CONFIRMACAO válidas)
  SELECT COALESCE(SUM(bk.passengers), 0)::integer INTO v_active_occupied
  FROM public.bookings bk
  WHERE bk.vessel_id = NEW.vessel_id
    AND bk.booking_date = NEW.block_date
    AND (NEW.tour_id IS NULL OR bk.tour_id = NEW.tour_id)
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    );

  IF NEW.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') AND v_active_occupied > 0 THEN
    RAISE EXCEPTION 'BLOCK_CONFLICTS_WITH_CONFIRMED_BOOKINGS: Não é possível aplicar % em % pois já existem % passageiros com reserva ativa (confirmada ou aguardando confirmação) na data.',
      NEW.block_type, NEW.block_date, v_active_occupied
      USING ERRCODE = 'P0001';
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override < v_active_occupied THEN
    RAISE EXCEPTION 'OVERRIDE_BELOW_OCCUPIED_SEATS: Ajuste de capacidade (%) é inferior aos % passageiros com reserva ativa na data %.',
      NEW.custom_capacity_override, v_active_occupied, NEW.block_date
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.upsert_availability_block(
  p_vessel_id TEXT,
  p_block_date DATE,
  p_block_type TEXT,
  p_reason TEXT DEFAULT NULL,
  p_custom_capacity_override SMALLINT DEFAULT NULL,
  p_tour_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel RECORD;
  v_resolved_tour_id UUID := NULL;
  v_existing_id UUID;
  v_result public.availability_blocks;
  v_clean_vessel TEXT := trim(COALESCE(p_vessel_id, ''));
BEGIN
  IF v_clean_vessel = '' OR p_block_date IS NULL THEN
    RAISE EXCEPTION 'INVALID_BLOCK_INPUT: Embarcação e data são obrigatórias.'
      USING ERRCODE = '23514';
  END IF;

  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, partner_id, name, capacity
    INTO v_vessel
  FROM public.vessels
  WHERE id::text = v_clean_vessel OR slug = v_clean_vessel
  FOR UPDATE;

  IF v_vessel.id IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', v_clean_vessel
      USING ERRCODE = 'P0002';
  END IF;

  IF NOT (
    public.is_admin()
    OR public.is_partner_member(v_vessel.partner_id)
    OR ((SELECT auth.uid()) IS NULL AND COALESCE(NULLIF(current_setting('role', true), ''), 'none') IN ('none', 'postgres', 'service_role'))
  ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Você não possui permissão para gerenciar a agenda desta embarcação.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_block_date::text));

  IF p_tour_id IS NOT NULL AND trim(p_tour_id) <> '' THEN
    v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
    IF v_resolved_tour_id IS NULL THEN
      RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado para o bloqueio.', p_tour_id
        USING ERRCODE = 'P0002';
    END IF;
  END IF;

  -- Lock #3: Verifica se já existe registro para a chave lógica (vessel_id, block_date, block_type, tour_id)
  SELECT id INTO v_existing_id
  FROM public.availability_blocks
  WHERE vessel_id = v_vessel.id
    AND block_date = p_block_date
    AND block_type = p_block_type
    AND tour_id IS NOT DISTINCT FROM v_resolved_tour_id
  FOR UPDATE;

  -- Emite token somente após os locks e revalidações
  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_vessel.id, p_block_date::text);

  IF v_existing_id IS NOT NULL THEN
    UPDATE public.availability_blocks
    SET custom_capacity_override = p_custom_capacity_override,
        reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional atualizado'),
        tour_id = v_resolved_tour_id
    WHERE id = v_existing_id
    RETURNING * INTO v_result;
  ELSE
    INSERT INTO public.availability_blocks (
      partner_id,
      vessel_id,
      tour_id,
      block_date,
      block_type,
      custom_capacity_override,
      reason,
      created_by
    ) VALUES (
      v_vessel.partner_id,
      v_vessel.id,
      v_resolved_tour_id,
      p_block_date,
      p_block_type,
      p_custom_capacity_override,
      COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional agendado'),
      (SELECT auth.uid())
    )
    RETURNING * INTO v_result;
  END IF;

  PERFORM internal_guard.cleanup_tokens('AVAILABILITY_BLOCK_MUTATION', v_vessel.id);

  RETURN to_jsonb(v_result);
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_availability_block(
  p_block_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_candidate RECORD;
  v_locked_block RECORD;
BEGIN
  IF p_block_id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Identificador do bloqueio é obrigatório.'
      USING ERRCODE = 'P0002';
  END IF;

  -- 1. Leitura inicial dos identificadores para adquirir Lock #1 (vessels) e Lock #2 (advisory_lock) na ordem canônica
  SELECT id, partner_id, vessel_id, block_date, block_type
    INTO v_candidate
  FROM public.availability_blocks
  WHERE id = p_block_id;

  IF v_candidate.id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Bloqueio de agenda (%) não encontrado.', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  IF NOT (
    public.is_admin()
    OR public.is_partner_member(v_candidate.partner_id)
    OR ((SELECT auth.uid()) IS NULL AND COALESCE(NULLIF(current_setting('role', true), ''), 'none') IN ('none', 'postgres', 'service_role'))
  ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Sem permissão para remover este bloqueio.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_candidate.vessel_id FOR UPDATE;

  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_candidate.vessel_id::text), hashtext(v_candidate.block_date::text));

  -- Lock #3: Revalida e bloqueia a linha alvo em availability_blocks ANTES de emitir o token (M01.5-05)
  SELECT id, partner_id, vessel_id, block_date, block_type
    INTO v_locked_block
  FROM public.availability_blocks
  WHERE id = p_block_id
  FOR UPDATE;

  IF v_locked_block.id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Bloqueio de agenda (%) já foi removido por outra operação concorrente.', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Emite token de uso único somente após confirmar que a linha existe e está bloqueada
  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_locked_block.vessel_id, v_locked_block.block_date::text);

  DELETE FROM public.availability_blocks WHERE id = v_locked_block.id;

  IF NOT FOUND THEN
    PERFORM internal_guard.cleanup_tokens('AVAILABILITY_BLOCK_MUTATION', v_locked_block.vessel_id);
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Nenhuma linha foi excluída para o bloqueio (%).', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM internal_guard.cleanup_tokens('AVAILABILITY_BLOCK_MUTATION', v_locked_block.vessel_id);

  RETURN jsonb_build_object(
    'deleted', true,
    'id', v_locked_block.id,
    'vessel_id', v_locked_block.vessel_id,
    'block_date', v_locked_block.block_date
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. SEGURANÇA DE AVALIAÇÕES VERIFICADAS E BLOQUEIO DE SEQUESTRO DE RESERVA
--    ANÔNIMA (M01.5-05 & M01.5-06)
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "reviews_tourist_insert" ON public.reviews;

CREATE OR REPLACE FUNCTION public.validate_verified_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_profile_active BOOLEAN := false;
  v_email_unverified BOOLEAN := false;
BEGIN
  v_is_admin_or_server := (
    (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (
      v_db_role NOT IN ('anon', 'authenticated')
      AND v_jwt_role NOT IN ('anon', 'authenticated')
      AND v_uid IS NULL
      AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    )
  );

  IF TG_OP = 'INSERT' THEN
    IF NOT internal_guard.consume_token('REVIEW_MUTATION', NEW.booking_id, 'INSERT') THEN
      RAISE EXCEPTION 'DIRECT_REVIEW_INSERT_FORBIDDEN: A publicação de avaliações deve ocorrer exclusivamente via RPC public.create_verified_review().'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  SELECT id, code, status, tour_id, partner_id, tourist_user_id, customer_name, customer_email
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: Reserva informada para avaliação não existe.'
      USING ERRCODE = '23503';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_COMPLETED: Somente reservas com status PASSEIO_REALIZADO podem ser avaliadas (status atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS DISTINCT FROM v_booking.tour_id OR NEW.partner_id IS DISTINCT FROM v_booking.partner_id THEN
    RAISE EXCEPTION 'REVIEW_ENTITY_MISMATCH: O passeio ou parceiro da avaliação não corresponde à reserva original.'
      USING ERRCODE = '23514';
  END IF;

  -- Proteção contra sequestro de reservas anônimas (tourist_user_id IS NULL) e validação de titularidade (M01.5-06)
  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas criadas sem autenticação (tourist_user_id IS NULL) não possuem prova verificável de titularidade e não podem ser avaliadas sem validação administrativa.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id OR NEW.tourist_user_id IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular autenticado da reserva (%) pode publicar avaliação.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Seu perfil está inativo ou não existe.'
        USING ERRCODE = '42501';
    END IF;

    SELECT (
      COALESCE(u.raw_app_meta_data->>'email_verified', '') = 'false'
      OR COALESCE(u.raw_user_meta_data->>'email_verified', '') = 'false'
    )
      INTO v_email_unverified
    FROM auth.users u
    WHERE u.id = v_uid;

    IF COALESCE(v_email_unverified, false) = true THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: É necessário possuir e-mail verificado para publicar avaliação.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  IF char_length(trim(COALESCE(NEW.comment, ''))) < 5 THEN
    RAISE EXCEPTION 'REVIEW_COMMENT_TOO_SHORT: O comentário da avaliação deve ter ao menos 5 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_verified_review(
  p_booking_id TEXT,
  p_rating SMALLINT,
  p_comment TEXT,
  p_author_name TEXT DEFAULT NULL,
  p_author_city TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_review public.reviews;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_profile_active BOOLEAN := false;
  v_email_unverified BOOLEAN := false;
BEGIN
  IF v_clean_id = '' THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: Identificador da reserva é obrigatório.'
      USING ERRCODE = 'P0002';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Hierarquia Canônica de Locks: Lock #1 (vessels FOR UPDATE) -> Lock #2 (advisory_lock) -> Lock #3 (bookings FOR SHARE)
  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id = v_booking.id
  FOR SHARE;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_COMPLETED: Somente reservas com status PASSEIO_REALIZADO podem ser avaliadas (atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  v_is_admin_or_server := (
    (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (
      v_db_role NOT IN ('anon', 'authenticated')
      AND v_jwt_role NOT IN ('anon', 'authenticated')
      AND v_uid IS NULL
      AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    )
  );

  IF NOT v_is_admin_or_server THEN
    IF v_booking.tourist_user_id IS NULL THEN
      RAISE EXCEPTION 'REVIEW_ANONYMOUS_BOOKING_UNVERIFIED: Reservas anônimas (tourist_user_id IS NULL) não podem ser avaliadas sem verificação administrativa de titularidade.'
        USING ERRCODE = '42501';
    END IF;

    IF v_uid IS NULL OR v_uid IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular da reserva (%) pode publicar avaliação.',
        v_booking.code
        USING ERRCODE = '42501';
    END IF;

    SELECT pr.is_active INTO v_profile_active
    FROM public.profiles pr
    WHERE pr.id = v_uid;

    IF COALESCE(v_profile_active, false) = false THEN
      RAISE EXCEPTION 'REVIEW_INACTIVE_PROFILE: Seu perfil está inativo ou não foi encontrado.'
        USING ERRCODE = '42501';
    END IF;

    SELECT (
      COALESCE(u.raw_app_meta_data->>'email_verified', '') = 'false'
      OR COALESCE(u.raw_user_meta_data->>'email_verified', '') = 'false'
    )
      INTO v_email_unverified
    FROM auth.users u
    WHERE u.id = v_uid;

    IF COALESCE(v_email_unverified, false) = true THEN
      RAISE EXCEPTION 'REVIEW_UNVERIFIED_EMAIL: Seu endereço de e-mail precisa estar verificado para avaliar passeios.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM public.reviews r WHERE r.booking_id = v_booking.id) THEN
    RAISE EXCEPTION 'REVIEW_ALREADY_EXISTS: A reserva % já possui uma avaliação verificada publicada.', v_booking.code
      USING ERRCODE = '23505';
  END IF;

  PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_booking.id, 'INSERT');

  INSERT INTO public.reviews (
    booking_id,
    tour_id,
    partner_id,
    tourist_user_id,
    author_name,
    author_city,
    rating,
    comment,
    is_published
  ) VALUES (
    v_booking.id,
    v_booking.tour_id,
    v_booking.partner_id,
    v_booking.tourist_user_id,
    COALESCE(NULLIF(trim(COALESCE(p_author_name, '')), ''), v_booking.customer_name),
    COALESCE(NULLIF(trim(COALESCE(p_author_city, '')), ''), 'Visitante Verificado'),
    p_rating,
    trim(p_comment),
    true
  )
  RETURNING * INTO v_review;

  PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_booking.id);

  RETURN jsonb_build_object(
    'id', v_review.id,
    'booking_id', v_review.booking_id,
    'verified_booking_code', v_booking.code,
    'tour_id', v_review.tour_id,
    'partner_id', v_review.partner_id,
    'author_name', v_review.author_name,
    'author_city', v_review.author_city,
    'rating', v_review.rating,
    'comment', v_review.comment,
    'created_at', v_review.created_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.recalculate_ratings_after_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_tour_id UUID := COALESCE(NEW.tour_id, OLD.tour_id);
  v_partner_id UUID := COALESCE(NEW.partner_id, OLD.partner_id);
BEGIN
  IF v_tour_id IS NOT NULL THEN
    PERFORM 1 FROM public.tours WHERE id = v_tour_id FOR UPDATE;
    IF FOUND THEN
      PERFORM internal_guard.issue_token('CATALOG_RATING_SYNC', v_tour_id, 'tours');
      UPDATE public.tours
      SET rating_avg = COALESCE((
            SELECT ROUND(AVG(rating)::numeric, 2)
            FROM public.reviews
            WHERE tour_id = v_tour_id AND is_published = true
          ), 5.00),
          reviews_count = (
            SELECT COUNT(*)::integer
            FROM public.reviews
            WHERE tour_id = v_tour_id AND is_published = true
          )
      WHERE id = v_tour_id;
      PERFORM internal_guard.cleanup_tokens('CATALOG_RATING_SYNC', v_tour_id);
    END IF;
  END IF;

  IF v_partner_id IS NOT NULL THEN
    PERFORM 1 FROM public.partners WHERE id = v_partner_id FOR UPDATE;
    IF FOUND THEN
      PERFORM internal_guard.issue_token('CATALOG_RATING_SYNC', v_partner_id, 'partners');
      UPDATE public.partners
      SET rating_avg = COALESCE((
            SELECT ROUND(AVG(rating)::numeric, 2)
            FROM public.reviews
            WHERE partner_id = v_partner_id AND is_published = true
          ), 5.00),
          reviews_count = (
            SELECT COUNT(*)::integer
            FROM public.reviews
            WHERE partner_id = v_partner_id AND is_published = true
          )
      WHERE id = v_partner_id;
      PERFORM internal_guard.cleanup_tokens('CATALOG_RATING_SYNC', v_partner_id);
    END IF;
  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. CORREÇÃO DE HIERARQUIA DE LOCKS E CAPACIDADE EM protect_catalog_moderation_columns
--    E LIMPEZA DETERMINÍSTICA DE TOKENS NAS RPCS DE RESERVA/LEDGER (M01.5-05 & M01.5-07)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_max_tour_cap SMALLINT;
  v_lock_date RECORD;
  v_max_occupied_date RECORD;
  v_active_pending_or_disputed_count INTEGER := 0;
BEGIN
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.is_active = false AND OLD.is_active = true)
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN

      -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
      PERFORM 1 FROM public.vessels WHERE id = NEW.id FOR UPDATE;

      -- Lock #2 e Lock #3 em ordem cronológica estrita (sem subquery FOR UPDATE dentro de GROUP BY):
      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        -- Lock #2: Advisory Lock por (embarcação + data)
        PERFORM pg_advisory_xact_lock(hashtext(NEW.id::text), hashtext(v_lock_date.booking_date::text));

        -- Lock #3: Lock das linhas filhas em public.bookings (FOR UPDATE)
        PERFORM 1
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;
    END IF;

    -- Validação de redução de capacidade (reservas pendentes já expiradas não bloqueiam a redução)
    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
        INTO v_max_occupied_date
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        AND (
          bk.expires_at IS NULL
          OR bk.expires_at > now()
          OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        )
      GROUP BY bk.booking_date
      HAVING SUM(bk.passengers) > NEW.capacity
      ORDER BY bk.booking_date ASC
      LIMIT 1;

      IF v_max_occupied_date.booking_date IS NOT NULL THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados ativos.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END IF;
    END IF;

    -- Validação de suspensão/desativação (inclui SOLICITADA/AGUARDANDO_CONFIRMACAO não expiradas, CONFIRMADA e EM_DISPUTA)
    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND (
          bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
          OR (
            bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
            AND (bk.expires_at IS NULL OR bk.expires_at > now())
          )
        );

      IF v_active_pending_or_disputed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
          v_active_pending_or_disputed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  -- Sincronização automática de rating_avg/reviews_count disparada por recalculate_ratings_after_review via token de uso único
  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  v_is_admin_or_server := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status NOT IN ('PENDENTE_APROVACAO', 'APROVADO') THEN
        RAISE EXCEPTION 'VESSEL_INVALID_INITIAL_STATUS: Status inicial inválido para embarcação.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem reativar embarcação suspensa ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' AND TG_OP = 'INSERT' THEN
    IF NEW.owner_type <> 'PARTNER' OR NEW.authorized = true THEN
      RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem aguardar autorização administrativa.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.transition_booking_status(
  p_booking_id TEXT,
  p_new_status public.booking_status_type,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_actor_role public.app_role;
  v_ledger_status public.ledger_status_type;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
BEGIN
  IF v_clean_id = '' THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: Identificador ou código da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_actor_role := public.resolve_booking_actor_role(v_target.partner_id, v_target.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Você não possui permissão sobre a reserva %.', v_target.code
      USING ERRCODE = '42501';
  END IF;

  -- Hierarquia canônica: Lock #1 Embarcação FOR UPDATE, Lock #2 Advisory Lock (embarcação+data), Lock #3 Reserva FOR UPDATE
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF p_new_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', v_target.code, v_target.status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, p_new_status::text);

  UPDATE public.bookings
  SET status = p_new_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'commission_consolidated', (v_updated.status = 'PASSEIO_REALIZADO'),
    'rejection_or_cancel_reason', v_updated.rejection_or_cancel_reason,
    'confirmed_at', v_updated.confirmed_at,
    'completed_at', v_updated.completed_at,
    'cancelled_at', v_updated.cancelled_at,
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.expire_stale_bookings()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_rec RECORD;
  v_locked_id UUID;
  v_expired_count INTEGER := 0;
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
BEGIN
  IF (v_db_role IN ('anon', 'authenticated') OR v_jwt_role IN ('anon', 'authenticated'))
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'UNAUTHORIZED_EXPIRATION_CALL: Apenas service_role ou administrador pode executar a rotina de expiração.'
      USING ERRCODE = '42501';
  END IF;

  FOR v_rec IN
    SELECT id, vessel_id, booking_date
    FROM public.bookings
    WHERE status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    ORDER BY vessel_id, booking_date, id
  LOOP
    -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
    PERFORM 1 FROM public.vessels WHERE id = v_rec.vessel_id FOR UPDATE;
    -- Lock #2: Advisory Lock (embarcação + data)
    PERFORM pg_advisory_xact_lock(hashtext(v_rec.vessel_id::text), hashtext(v_rec.booking_date::text));

    -- Lock #3: Revalida e trava a reserva antes de emitir o token (M01.5-05)
    SELECT id INTO v_locked_id
    FROM public.bookings
    WHERE id = v_rec.id
      AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    FOR UPDATE;

    IF v_locked_id IS NOT NULL THEN
      PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_locked_id, 'CANCELADA');

      UPDATE public.bookings
      SET status = 'CANCELADA',
          rejection_or_cancel_reason = 'Reserva expirada automaticamente por decurso do prazo de confirmação (SLA 48h)',
          cancelled_at = now(),
          updated_at = now()
      WHERE id = v_locked_id
        AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO');

      IF FOUND THEN
        v_expired_count := v_expired_count + 1;
      END IF;

      PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_locked_id);
    END IF;
  END LOOP;

  RETURN v_expired_count;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_update_booking(
  p_booking_id TEXT,
  p_new_booking_date DATE DEFAULT NULL,
  p_new_passengers SMALLINT DEFAULT NULL,
  p_new_status public.booking_status_type DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN;
  v_eff_date DATE;
  v_eff_pax SMALLINT;
  v_eff_status public.booking_status_type;
  v_date_min DATE;
  v_date_max DATE;
  v_ledger_status public.ledger_status_type;
BEGIN
  v_is_authorized_admin := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Somente administradores podem executar admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_eff_date := COALESCE(p_new_booking_date, v_target.booking_date);
  v_eff_pax := COALESCE(p_new_passengers, v_target.passengers);
  v_eff_status := COALESCE(p_new_status, v_target.status);

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;

  v_date_min := LEAST(v_target.booking_date, v_eff_date);
  v_date_max := GREATEST(v_target.booking_date, v_eff_date);
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_min::text));
  IF v_date_max IS DISTINCT FROM v_date_min THEN
    PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_max::text));
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF v_eff_date IS NOT DISTINCT FROM v_target.booking_date
     AND v_eff_pax IS NOT DISTINCT FROM v_target.passengers
     AND v_eff_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_BOOKING_UPDATE: Nenhuma alteração efetiva de data, passageiros ou status foi solicitada para a reserva %.', v_target.code
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, v_eff_status::text);

  UPDATE public.bookings
  SET booking_date = v_eff_date,
      passengers = v_eff_pax,
      status = v_eff_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'booking_date', v_updated.booking_date,
    'passengers', v_updated.passengers,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.settle_commission_ledger(
  p_booking_id TEXT,
  p_adjustment_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_ledger public.commission_ledger;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN;
BEGIN
  v_is_authorized_admin := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));
  PERFORM 1 FROM public.bookings WHERE id = v_booking.id FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_ledger.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_NOT_FOUND: Registro financeiro não encontrado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF v_ledger.ledger_status = 'PAGA' THEN
    RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão da reserva % já foi liquidada em %.', v_booking.code, v_ledger.paid_at
      USING ERRCODE = '23514';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' OR v_ledger.ledger_status <> 'CONFIRMADA' THEN
    RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (atual: reserva=%, ledger=%).',
      v_booking.status, v_ledger.ledger_status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('LEDGER_SETTLE', v_booking.id, 'PAGA');

  UPDATE public.commission_ledger
  SET ledger_status = 'PAGA',
      paid_at = now(),
      adjustment_notes = COALESCE(NULLIF(trim(COALESCE(p_adjustment_notes, '')), ''), adjustment_notes),
      updated_by = v_uid,
      updated_at = now()
  WHERE id = v_ledger.id
  RETURNING * INTO v_ledger;

  PERFORM internal_guard.cleanup_tokens('LEDGER_SETTLE', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'commission_ledger',
    v_booking.code,
    'SETTLE_COMMISSION',
    jsonb_build_object('ledger_status', 'CONFIRMADA'),
    jsonb_build_object('ledger_status', 'PAGA', 'paid_at', v_ledger.paid_at, 'commission_amount', v_ledger.commission_amount)
  );

  RETURN jsonb_build_object(
    'ledger_id', v_ledger.id,
    'booking_id', v_booking.id,
    'booking_code', v_booking.code,
    'ledger_status', v_ledger.ledger_status,
    'gross_amount', v_ledger.gross_amount,
    'commission_amount', v_ledger.commission_amount,
    'net_partner_amount', v_ledger.net_partner_amount,
    'paid_at', v_ledger.paid_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000006
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    -- Nota Técnica (M01.5-12 / REGRA ESPECIAL):
    -- As políticas RLS de SELECT nas tabelas públicas do catálogo (partners, tours, vessels, reviews)
    -- possuem cláusulas OR public.is_partner_member(...) OR public.is_admin(). Quando anon executa SELECT
    -- e o PostgreSQL avalia linhas com status='PENDENTE' (como part-nativaeco no seed 000004), o lado direito
    -- do OR é avaliado; sem GRANT EXECUTE para anon nessas duas funções, o SELECT público falharia com
    -- 'permission denied for function'. Ambas possuem curto-circuito constante retornando FALSE para anon.
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
    REVOKE DELETE, TRUNCATE ON public.profiles FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    FOR r_fn IN
      SELECT p.oid::regprocedure AS fn_sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('public', 'internal_guard')
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END LOOP;
  END IF;
END
$$;
