-- ============================================================================
-- UBATUBA MAR & PRAIAS — ARGON 4 — MISSÃO 02.16 (MISSÃO B)
-- MIGRATION 000019: DATAS DINÂMICAS NO FUSO DE BRASÍLIA (America/Sao_Paulo),
-- CREDENCIAL CRIPTOGRÁFICA DE CONSULTA DO TURISTA (HMAC-SHA-256 SEM TEXTO PURO),
-- RATE LIMITING ANTI-ENUMERAÇÃO E RPCS SEGURAS DE CONSULTA E CANCELAMENTO
-- Arquivo: supabase/migrations/20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql
--
-- Preserva integralmente as migrations 000001 a 000018.
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. FUNÇÃO CANÔNICA DE DATA ATUAL NO FUSO DE BRASÍLIA (America/Sao_Paulo)
--    Elimina a dependência da data literal fixa '2026-11-08' em reservas e
--    consultas de disponibilidade.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.current_brazil_date()
RETURNS DATE
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $$
  SELECT (pg_catalog.now() AT TIME ZONE 'America/Sao_Paulo')::date;
$$;

-- ----------------------------------------------------------------------------
-- 2. EXTENSÃO NÃO-DESTRUTIVA DE public.bookings E TABELA DE RATE LIMITING
--    EM internal_guard PARA PROTEÇÃO CONTRA FORÇA BRUTA E ENUMERAÇÃO
-- ----------------------------------------------------------------------------
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS lookup_token_hmac VARCHAR(64),
  ADD COLUMN IF NOT EXISTS lookup_token_hmac_version SMALLINT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_catalog.pg_constraint
    WHERE conname = 'fk_bookings_lookup_token_hmac_version'
      AND conrelid = 'public.bookings'::regclass
  ) THEN
    ALTER TABLE public.bookings
      ADD CONSTRAINT fk_bookings_lookup_token_hmac_version
      FOREIGN KEY (lookup_token_hmac_version)
      REFERENCES internal_guard.lineage_hmac_keys(key_version);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_catalog.pg_constraint
    WHERE conname = 'chk_bookings_lookup_token_hmac_format'
      AND conrelid = 'public.bookings'::regclass
  ) THEN
    ALTER TABLE public.bookings
      ADD CONSTRAINT chk_bookings_lookup_token_hmac_format
      CHECK (lookup_token_hmac IS NULL OR lookup_token_hmac ~ '^[0-9a-f]{64}$');
  END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_bookings_code_lookup_hmac
  ON public.bookings (code, lookup_token_hmac_version);

CREATE TABLE IF NOT EXISTS internal_guard.booking_lookup_rate_limits (
  booking_code VARCHAR(16) PRIMARY KEY,
  failed_attempts SMALLINT NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  window_started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  locked_until TIMESTAMPTZ NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE internal_guard.booking_lookup_rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_guard.booking_lookup_rate_limits FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "booking_lookup_rate_limits_definer_only" ON internal_guard.booking_lookup_rate_limits;
CREATE POLICY "booking_lookup_rate_limits_definer_only"
  ON internal_guard.booking_lookup_rate_limits
  AS RESTRICTIVE
  FOR ALL
  USING (current_user IN ('postgres', 'supabase_admin'))
  WITH CHECK (current_user IN ('postgres', 'supabase_admin'));

REVOKE ALL ON TABLE internal_guard.booking_lookup_rate_limits FROM PUBLIC;

-- ----------------------------------------------------------------------------
-- 3. ATUALIZAÇÃO DE internal_guard.enforce_lineage_hmac_key_lifecycle(),
--    require_active_hmac_secret(), compute_lineage_mac() E verify_lineage_mac()
--    PARA SUPORTAR O DOMÍNIO 'BOOKING_LOOKUP_TOKEN_V1' (256 BITS / 64 HEX)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_dependent_count BIGINT := 0;
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.is_current = true THEN
      RAISE EXCEPTION 'KEY_DELETE_ACTIVE_FORBIDDEN: Proibido excluir a versão de chave HMAC atualmente ativa (key_version=%).', OLD.key_version
        USING ERRCODE = '42501';
    END IF;

    IF OLD.is_verify_enabled = true THEN
      RAISE EXCEPTION 'KEY_DELETE_ENABLED_FORBIDDEN: A versão de chave HMAC (%) deve ser aposentada (RETIRE / is_verify_enabled = false) antes de poder ser expurgada.', OLD.key_version
        USING ERRCODE = '42501';
    END IF;

    SELECT COUNT(*)
      INTO v_dependent_count
    FROM public.bookings b
    WHERE b.hmac_key_version = OLD.key_version
       OR b.lineage_root_key_version = OLD.key_version
       OR b.lineage_idem_key_version = OLD.key_version
       OR b.lineage_scope_key_version = OLD.key_version
       OR b.lookup_token_hmac_version = OLD.key_version;

    IF v_dependent_count > 0 THEN
      RAISE EXCEPTION 'KEY_DELETE_DEPENDENT_RECORDS_EXIST: Proibido excluir a versão de chave HMAC (%) pois existem % reservas dependentes.', OLD.key_version, v_dependent_count
        USING ERRCODE = '23503';
    END IF;

    RETURN OLD;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.key_version IS DISTINCT FROM OLD.key_version
       OR NEW.secret_material IS DISTINCT FROM OLD.secret_material
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'KEY_MATERIAL_IMMUTABLE: O identificador key_version, o material secreto (secret_material) e created_at são imutáveis após a criação.'
        USING ERRCODE = '42501';
    END IF;

    IF OLD.is_verify_enabled = true AND NEW.is_verify_enabled = false THEN
      IF NEW.is_current = true THEN
        RAISE EXCEPTION 'KEY_DISABLE_ACTIVE_FORBIDDEN: Não é permitido desabilitar a verificação da chave atualmente ativa (key_version=%).', OLD.key_version
          USING ERRCODE = '42501';
      END IF;

      SELECT COUNT(*)
        INTO v_dependent_count
      FROM public.bookings b
      WHERE b.hmac_key_version = OLD.key_version
         OR b.lineage_root_key_version = OLD.key_version
         OR b.lineage_idem_key_version = OLD.key_version
         OR b.lineage_scope_key_version = OLD.key_version
         OR b.lookup_token_hmac_version = OLD.key_version;

      IF v_dependent_count > 0 THEN
        RAISE EXCEPTION 'KEY_RETIRE_DEPENDENT_RECORDS_EXIST: Não é permitido desabilitar a verificação da versão (%) enquanto existirem % reservas dependentes. Execute o backfill/migração antes.', OLD.key_version, v_dependent_count
          USING ERRCODE = '23503';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION internal_guard.require_active_hmac_secret()
RETURNS SMALLINT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  v_active_count INTEGER := 0;
  v_ver SMALLINT;
  v_secret TEXT;
  v_distinct_hex INTEGER := 0;
  v_distinct_bytes INTEGER := 0;
  v_w1_distinct INTEGER := 0;
  v_w2_distinct INTEGER := 0;
  v_w3_distinct INTEGER := 0;
  v_w4_distinct INTEGER := 0;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('compute_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('verify_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('rotate_lineage_hmac_key' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('manage_lineage_hmac_key_lifecycle' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('lookup_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('cancel_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('enforce_booking_invariants_and_transitions' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.require_active_hmac_secret não autorizada fora dos fluxos internos.'
      USING ERRCODE = '42501';
  END IF;

  SELECT COUNT(*), MAX(k.key_version), MAX(k.secret_material)
    INTO v_active_count, v_ver, v_secret
  FROM internal_guard.lineage_hmac_keys k
  WHERE k.is_current = true
    AND k.is_verify_enabled = true;

  IF v_active_count = 0 OR v_ver IS NULL OR v_secret IS NULL THEN
    RAISE EXCEPTION 'LINEAGE_MAC_KEY_UNAVAILABLE: Nenhuma chave criptográfica HMAC-SHA-256 ativa encontrada em internal_guard.lineage_hmac_keys.'
      USING ERRCODE = 'P0001';
  END IF;

  IF v_active_count > 1 THEN
    RAISE EXCEPTION 'LINEAGE_MAC_MULTIPLE_ACTIVE_KEYS: Estado inconsistente — mais de uma versão de chave marcada como ativa.'
      USING ERRCODE = '23505';
  END IF;

  IF pg_catalog.char_length(v_secret) < 64
     OR pg_catalog.char_length(v_secret) > 128
     OR (pg_catalog.char_length(v_secret) % 2) <> 0
     OR v_secret !~ '^[0-9a-f]+$' THEN
    RAISE EXCEPTION 'INVALID_HMAC_SECRET_FORMAT: O segredo ativo possui comprimento ou codificação hexadecimal inválida.'
      USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(DISTINCT ch) INTO v_distinct_hex
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 64), '') AS ch WHERE ch <> '';

  SELECT COUNT(DISTINCT pg_catalog.substr(v_secret, i * 2 + 1, 2)) INTO v_distinct_bytes
  FROM pg_catalog.generate_series(0, 31) AS g(i);

  SELECT COUNT(DISTINCT ch) INTO v_w1_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w2_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 17, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w3_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 33, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w4_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 49, 16), '') AS ch WHERE ch <> '';

  IF v_distinct_hex < 8
     OR v_distinct_bytes < 10
     OR v_w1_distinct < 5
     OR v_w2_distinct < 5
     OR v_w3_distinct < 5
     OR v_w4_distinct < 5
     OR v_secret ~ '([0-9a-f])\1{7,}'
     OR pg_catalog.substr(v_secret, 1, 64) ~ '^([0-9a-f]{1,32})\1+$'
     OR v_secret ~ '(01234567|12345678|23456789|89abcdef|fedcba98|98765432|76543210|a1b2c3d4e5f6)' THEN
    RAISE EXCEPTION 'WEAK_HMAC_SECRET_REJECTED: O segredo ativo contém padrão repetitivo, periódico, sequencial ou baixa diversidade estrutural.'
      USING ERRCODE = '23514';
  END IF;

  RETURN v_ver;
END;
$$;

CREATE OR REPLACE FUNCTION internal_guard.compute_lineage_mac(
  p_purpose TEXT,
  p_payload TEXT,
  p_key_version SMALLINT DEFAULT NULL
)
RETURNS TEXT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  v_secret TEXT;
  v_ver SMALLINT;
  v_canonical_msg TEXT;
  v_mac_bytes BYTEA;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('verify_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('derive_idempotency_lineage_key' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('lookup_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('cancel_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.compute_lineage_mac proibida fora dos fluxos internos autorizados.'
      USING ERRCODE = '42501';
  END IF;

  IF p_purpose IS NULL
     OR p_payload IS NULL
     OR p_purpose NOT IN (
       'LGPD_OWNER_SCOPE',
       'LGPD_IDEM_AUTH',
       'NATURAL_BOOKING_KEY',
       'LINEAGE_ROOT_V1',
       'LINEAGE_GEN_V1',
       'BOOKING_LOOKUP_TOKEN_V1'
     ) THEN
    RAISE EXCEPTION 'LINEAGE_MAC_INVALID_INPUT: Finalidade (purpose) inválida ou payload nulo para cálculo de HMAC-SHA-256.'
      USING ERRCODE = '23514';
  END IF;

  IF p_key_version IS NOT NULL THEN
    SELECT k.secret_material, k.key_version
      INTO v_secret, v_ver
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.key_version = p_key_version
      AND k.is_verify_enabled = true
    LIMIT 1;
  ELSE
    v_ver := internal_guard.require_active_hmac_secret();
    SELECT k.secret_material
      INTO v_secret
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.key_version = v_ver
      AND k.is_current = true
      AND k.is_verify_enabled = true
    LIMIT 1;
  END IF;

  IF v_secret IS NULL OR v_ver IS NULL THEN
    RAISE EXCEPTION 'LINEAGE_MAC_KEY_UNAVAILABLE: Versão de chave HMAC-SHA-256 solicitada inexistente ou desabilitada.'
      USING ERRCODE = 'P0001';
  END IF;

  IF pg_catalog.char_length(v_secret) < 64
     OR pg_catalog.char_length(v_secret) > 128
     OR (pg_catalog.char_length(v_secret) % 2) <> 0
     OR v_secret !~ '^[0-9a-f]+$' THEN
    RAISE EXCEPTION 'INVALID_HMAC_SECRET_FORMAT: Material secreto com codificação hexadecimal inválida.'
      USING ERRCODE = '23514';
  END IF;

  v_canonical_msg := 'v' || v_ver::text
    || ':' || pg_catalog.char_length(p_purpose)::text || ':' || p_purpose
    || ':' || pg_catalog.char_length(p_payload)::text || ':' || p_payload;

  v_mac_bytes := public.hmac(
    pg_catalog.convert_to(v_canonical_msg, 'UTF8'),
    pg_catalog.decode(v_secret, 'hex'),
    'sha256'::text
  );

  IF v_mac_bytes IS NULL OR pg_catalog.octet_length(v_mac_bytes) <> 32 THEN
    RAISE EXCEPTION 'HMAC_COMPUTATION_FAILURE: Falha na execução de HMAC-SHA-256 via pgcrypto.'
      USING ERRCODE = 'P0001';
  END IF;

  RETURN pg_catalog.lower(pg_catalog.encode(v_mac_bytes, 'hex'));
END;
$$;

CREATE OR REPLACE FUNCTION internal_guard.verify_lineage_mac(
  p_purpose TEXT,
  p_payload TEXT,
  p_expected_mac TEXT,
  p_key_version SMALLINT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  r_key RECORD;
  v_req_len INTEGER := 0;
  v_cand_mac TEXT;
  v_cand_bytes BYTEA;
  v_exp_bytes BYTEA;
  v_diff INTEGER;
  v_idx INTEGER;
  v_matched BOOLEAN := false;
  v_leg_in1 TEXT;
  v_leg_out1 TEXT;
  v_leg_in2 TEXT;
  v_leg_out2 TEXT;
  v_leg_cand TEXT;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('lookup_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('cancel_booking_by_tourist_token' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.verify_lineage_mac proibida fora dos fluxos internos autorizados.'
      USING ERRCODE = '42501';
  END IF;

  v_req_len := CASE p_purpose
    WHEN 'LGPD_IDEM_AUTH' THEN 16
    WHEN 'LGPD_OWNER_SCOPE' THEN 20
    WHEN 'LINEAGE_ROOT_V1' THEN 24
    WHEN 'LINEAGE_GEN_V1' THEN 24
    WHEN 'NATURAL_BOOKING_KEY' THEN 64
    WHEN 'BOOKING_LOOKUP_TOKEN_V1' THEN 64
    ELSE 0
  END;

  IF v_req_len = 0
     OR p_payload IS NULL
     OR p_expected_mac IS NULL
     OR pg_catalog.char_length(p_expected_mac) <> v_req_len
     OR p_expected_mac !~ '^[0-9a-f]+$' THEN
    RETURN false;
  END IF;

  v_exp_bytes := pg_catalog.convert_to(p_expected_mac, 'UTF8');

  FOR r_key IN
    SELECT k.key_version, k.secret_material
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.is_verify_enabled = true
      AND (p_key_version IS NULL OR k.key_version = p_key_version)
    ORDER BY k.is_current DESC, k.key_version DESC
  LOOP
    v_cand_mac := pg_catalog.left(
      internal_guard.compute_lineage_mac(p_purpose, p_payload, r_key.key_version),
      v_req_len
    );
    v_cand_bytes := pg_catalog.convert_to(v_cand_mac, 'UTF8');
    v_diff := 0;
    FOR v_idx IN 0..(v_req_len - 1) LOOP
      v_diff := v_diff | (pg_catalog.get_byte(v_cand_bytes, v_idx) # pg_catalog.get_byte(v_exp_bytes, v_idx));
    END LOOP;
    IF v_diff = 0 THEN
      v_matched := true;
    END IF;

    IF r_key.key_version = 1 AND p_purpose IN ('LGPD_IDEM_AUTH', 'LGPD_OWNER_SCOPE') THEN
      v_leg_in1 := pg_catalog.md5(r_key.secret_material || ':in1:v1:' || p_purpose || ':' || p_payload);
      v_leg_out1 := pg_catalog.md5(r_key.secret_material || ':out1:v1:' || v_leg_in1);
      v_leg_in2 := pg_catalog.md5(r_key.secret_material || ':in2:v1:' || p_purpose || ':' || p_payload);
      v_leg_out2 := pg_catalog.md5(r_key.secret_material || ':out2:v1:' || v_leg_in2);
      v_leg_cand := pg_catalog.left(v_leg_out1 || v_leg_out2, v_req_len);
      v_cand_bytes := pg_catalog.convert_to(v_leg_cand, 'UTF8');
      v_diff := 0;
      FOR v_idx IN 0..(v_req_len - 1) LOOP
        v_diff := v_diff | (pg_catalog.get_byte(v_cand_bytes, v_idx) # pg_catalog.get_byte(v_exp_bytes, v_idx));
      END LOOP;
      IF v_diff = 0 THEN
        v_matched := true;
      END IF;
    END IF;
  END LOOP;

  RETURN v_matched;
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. ATUALIZAÇÃO DE public.get_tour_availability() COM DATA DINÂMICA
--    DE BRASÍLIA E HORÁRIOS REAIS DO PASSEIO (SEÇÃO 4)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_tour_availability(
  p_tour_id TEXT,
  p_booking_date DATE
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_block RECORD;
  v_today_br DATE := public.current_brazil_date();
  v_effective_capacity INTEGER;
  v_occupied_seats INTEGER := 0;
  v_active_count INTEGER := 0;
  v_active_private INTEGER := 0;
  v_blocked BOOLEAN := false;
  v_block_reason TEXT := '';
  v_remaining INTEGER := 0;
BEGIN
  IF p_booking_date IS NULL THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data para consulta de disponibilidade é obrigatória.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT
    id,
    slug,
    title,
    vessel_id,
    partner_id,
    tour_type,
    pricing_model,
    price,
    capacity,
    duration_hours,
    departure_time,
    return_time,
    check_in_time,
    departure_point,
    status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id;

  v_effective_capacity := LEAST(v_tour.capacity::integer, v_vessel.capacity::integer);

  IF p_booking_date < v_today_br THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'current_brazil_date', v_today_br,
      'departure_time', v_tour.departure_time,
      'return_time', v_tour.return_time,
      'check_in_time', v_tour.check_in_time,
      'departure_point', v_tour.departure_point,
      'blocked', true,
      'block_reason', 'BOOKING_DATE_IN_PAST: Não é permitido selecionar datas no passado.',
      'effective_capacity', v_effective_capacity,
      'occupied_seats', 0,
      'remaining_seats', 0
    );
  END IF;

  IF v_tour.status <> 'APROVADO' OR v_vessel.status <> 'APROVADO' OR v_vessel.is_active = false THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'current_brazil_date', v_today_br,
      'departure_time', v_tour.departure_time,
      'return_time', v_tour.return_time,
      'check_in_time', v_tour.check_in_time,
      'departure_point', v_tour.departure_point,
      'blocked', true,
      'block_reason', 'Passeio ou embarcação indisponível para reservas',
      'effective_capacity', v_effective_capacity,
      'occupied_seats', 0,
      'remaining_seats', 0
    );
  END IF;

  FOR v_block IN
    SELECT block_type, custom_capacity_override, COALESCE(reason, 'Bloqueio operacional') AS reason
    FROM public.availability_blocks
    WHERE vessel_id = v_vessel.id
      AND block_date = p_booking_date
      AND (tour_id IS NULL OR tour_id = v_tour.id)
    ORDER BY CASE WHEN block_type = 'AJUSTE_CAPACIDADE' THEN 2 ELSE 1 END
  LOOP
    IF v_block.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') THEN
      v_blocked := true;
      v_block_reason := v_block.block_type || ': ' || v_block.reason;
      EXIT;
    ELSIF v_block.block_type = 'AJUSTE_CAPACIDADE' AND v_block.custom_capacity_override IS NOT NULL THEN
      v_effective_capacity := LEAST(v_effective_capacity, v_block.custom_capacity_override::integer);
    END IF;
  END LOOP;

  IF v_blocked THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'current_brazil_date', v_today_br,
      'departure_time', v_tour.departure_time,
      'return_time', v_tour.return_time,
      'check_in_time', v_tour.check_in_time,
      'departure_point', v_tour.departure_point,
      'blocked', true,
      'block_reason', v_block_reason,
      'effective_capacity', v_effective_capacity,
      'occupied_seats', 0,
      'remaining_seats', 0
    );
  END IF;

  SELECT
    COALESCE(SUM(b.passengers), 0)::integer,
    COUNT(*)::integer,
    COALESCE(SUM(CASE WHEN t.tour_type = 'Privativo' OR b.pricing_model_snapshot = 'POR_EMBARCACAO' THEN 1 ELSE 0 END), 0)::integer
  INTO v_occupied_seats, v_active_count, v_active_private
  FROM public.bookings b
  JOIN public.tours t ON t.id = b.tour_id
  WHERE b.vessel_id = v_vessel.id
    AND b.booking_date = p_booking_date
    AND b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      b.expires_at IS NULL
      OR b.expires_at > now()
      OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    );

  IF v_active_private > 0 OR (v_tour.tour_type = 'Privativo' AND v_active_count > 0) THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'current_brazil_date', v_today_br,
      'departure_time', v_tour.departure_time,
      'return_time', v_tour.return_time,
      'check_in_time', v_tour.check_in_time,
      'departure_point', v_tour.departure_point,
      'blocked', true,
      'block_reason', 'Embarcação já reservada nesta data',
      'effective_capacity', v_effective_capacity,
      'occupied_seats', v_effective_capacity,
      'remaining_seats', 0
    );
  END IF;

  v_remaining := GREATEST(0, v_effective_capacity - v_occupied_seats);

  RETURN jsonb_build_object(
    'tour_id', v_tour.id,
    'vessel_id', v_vessel.id,
    'booking_date', p_booking_date,
    'current_brazil_date', v_today_br,
    'departure_time', v_tour.departure_time,
    'return_time', v_tour.return_time,
    'check_in_time', v_tour.check_in_time,
    'departure_point', v_tour.departure_point,
    'blocked', (v_remaining = 0),
    'block_reason', CASE WHEN v_remaining = 0 THEN 'Lotação máxima atingida nesta data' ELSE '' END,
    'effective_capacity', v_effective_capacity,
    'occupied_seats', v_occupied_seats,
    'remaining_seats', v_remaining
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. ATUALIZAÇÃO DE public.enforce_booking_invariants_and_transitions()
--    - Suporta o token de execução 'TOURIST_TOKEN_CANCEL:CANCELADA' emitido
--      exclusivamente por public.cancel_booking_by_tourist_token() após
--      autenticação criptográfica HMAC-SHA-256 do lookup_token;
--    - Protege a imutabilidade de lookup_token_hmac e lookup_token_hmac_version;
--    - Limpa lookup_token_hmac e lookup_token_hmac_version automaticamente
--      durante anonimização LGPD.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
  v_lineage_backfill BOOLEAN := false;
  v_tourist_token_cancel BOOLEAN := false;
  v_expected_lgpd_email TEXT;
  v_active_ver SMALLINT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.id IS NULL THEN
      NEW.id := pg_catalog.gen_random_uuid();
    END IF;

    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    IF NEW.original_idempotency_key IS NULL OR pg_catalog.btrim(NEW.original_idempotency_key) = '' THEN
      NEW.original_idempotency_key := pg_catalog.lower(pg_catalog.btrim(NEW.idempotency_key));
    END IF;

    IF NEW.idempotency_generation IS NULL THEN
      NEW.idempotency_generation := 0;
    END IF;

    IF NEW.original_idempotency_key ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      RAISE EXCEPTION 'INVALID_ORIGINAL_IDEMPOTENCY_KEY: Uma chave derivada de geração (idg-...-gNNNN-...) não pode ser gravada como original_idempotency_key.'
        USING ERRCODE = '23514';
    END IF;

    IF NEW.hmac_key_version IS NULL THEN
      v_active_ver := internal_guard.require_active_hmac_secret();
      NEW.hmac_key_version := v_active_ver;
      NEW.lineage_root_key_version := COALESCE(NEW.lineage_root_key_version, v_active_ver);
      NEW.lineage_idem_key_version := COALESCE(NEW.lineage_idem_key_version, v_active_ver);
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      v_lineage_backfill := internal_guard.consume_token(
        'BOOKING_MUTATION',
        OLD.id,
        'LINEAGE_BACKFILL:' || NEW.status::text
      );
    END IF;

    IF NOT v_lgpd_anonymize AND NOT v_lineage_backfill THEN
      v_tourist_token_cancel := internal_guard.consume_token(
        'BOOKING_MUTATION',
        OLD.id,
        'TOURIST_TOKEN_CANCEL:' || NEW.status::text
      );
    END IF;

    IF NOT v_lgpd_anonymize AND NOT v_lineage_backfill AND NOT v_tourist_token_cancel THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF v_lineage_backfill THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.code IS DISTINCT FROM OLD.code
         OR NEW.status IS DISTINCT FROM OLD.status
         OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.channel IS DISTINCT FROM OLD.channel
         OR NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
         OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
         OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
         OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
         OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
         OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
         OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
         OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
         OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
         OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.rejection_or_cancel_reason IS DISTINCT FROM OLD.rejection_or_cancel_reason
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_IMMUTABLE_VIOLATION: O reparo de linhagem não pode modificar dados operacionais, financeiros, UTMs, notas, timestamps ou dados de cliente.'
          USING ERRCODE = '42501';
      END IF;

      IF (
           OLD.customer_name = 'TITULAR ANONIMIZADO LGPD'
           OR OLD.idempotency_key LIKE 'lgpd-%'
           OR OLD.original_idempotency_key LIKE 'lgpd-%'
         )
         AND (
           NEW.idempotency_key !~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
           OR NEW.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         ) THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_LGPD_DOWNGRADE_FORBIDDEN: O backfill não pode remover a pseudonimização LGPD nem restaurar identificadores originais em reserva anonimizada.'
          USING ERRCODE = '42501';
      END IF;

      IF NEW.original_idempotency_key IS NULL
         OR pg_catalog.char_length(pg_catalog.btrim(NEW.original_idempotency_key)) < 8
         OR pg_catalog.char_length(NEW.original_idempotency_key) > 64
         OR NEW.original_idempotency_key ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$'
         OR NEW.idempotency_generation IS NULL
         OR NEW.idempotency_generation < 0
         OR NEW.idempotency_generation > 9999 THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_INVALID_VALUES: Valores de original_idempotency_key ou idempotency_generation inválidos durante backfill.'
          USING ERRCODE = '23514';
      END IF;

      RETURN NEW;
    END IF;

    v_expected_lgpd_email := 'anonimizado.' || pg_catalog.lower(OLD.code) || '@lgpd.invalid';

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR (
         NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         )
       )
       OR (
         NEW.original_idempotency_key IS DISTINCT FROM OLD.original_idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         )
       )
       OR NEW.idempotency_generation IS DISTINCT FROM OLD.idempotency_generation
       OR (
         (
           NEW.hmac_key_version IS DISTINCT FROM OLD.hmac_key_version
           OR NEW.lineage_root_key_version IS DISTINCT FROM OLD.lineage_root_key_version
           OR NEW.lineage_idem_key_version IS DISTINCT FROM OLD.lineage_idem_key_version
           OR NEW.lineage_scope_key_version IS DISTINCT FROM OLD.lineage_scope_key_version
           OR NEW.lookup_token_hmac IS DISTINCT FROM OLD.lookup_token_hmac
           OR NEW.lookup_token_hmac_version IS DISTINCT FROM OLD.lookup_token_hmac_version
         )
         AND NOT v_lgpd_anonymize
       )
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de linhagem de idempotência, de versão de chave HMAC, de credencial de consulta, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    IF v_lgpd_anonymize THEN
      IF NEW.status IS DISTINCT FROM OLD.status
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_OPERATIONAL_FIELDS: A operação de anonimização LGPD não pode alterar status, data, passageiros, UTMs ou timestamps operacionais da reserva.'
          USING ERRCODE = '42501';
      END IF;

      IF NEW.customer_name <> 'TITULAR ANONIMIZADO LGPD'
         OR NEW.customer_phone <> '(00) 00000-0000'
         OR NEW.customer_email <> v_expected_lgpd_email
         OR NEW.tourist_user_id IS NOT NULL
         OR NEW.idempotency_key !~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         OR NEW.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         OR NEW.notes IS NULL
         OR NEW.notes NOT LIKE '[LGPD %'
         OR (NEW.rejection_or_cancel_reason IS NOT NULL AND NEW.rejection_or_cancel_reason NOT LIKE '[LGPD %') THEN
        RAISE EXCEPTION 'LGPD_INVALID_TARGET_VALUES: O token LGPD_ANONYMIZE permite gravar exclusivamente os valores canônicos de anonimização LGPD.'
          USING ERRCODE = '42501';
      END IF;

      NEW.lookup_token_hmac := NULL;
      NEW.lookup_token_hmac_version := NULL;
    END IF;

    IF v_tourist_token_cancel THEN
      IF NEW.status <> 'CANCELADA' OR OLD.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA') THEN
        RAISE EXCEPTION 'FORBIDDEN_TOURIST_CANCELLATION_STATUS: O cancelamento por credencial de turista é permitido apenas para reservas em SOLICITADA, AGUARDANDO_CONFIRMACAO ou CONFIRMADA.'
          USING ERRCODE = '42501';
      END IF;
      v_actor_role := 'tourist'::public.app_role;
    ELSE
      v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
      IF v_actor_role IS NULL THEN
        RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) AND NEW.status IS DISTINCT FROM OLD.status THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status inválida (% -> %) para a reserva %.', OLD.status, NEW.status, OLD.code
          USING ERRCODE = '23514';
      END IF;
      IF NEW.status NOT IN ('CANCELADA', 'RECUSADA') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          OLD.id
        );
      END IF;
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status inválida (% -> %) para a reserva %.', OLD.status, NEW.status, OLD.code
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'FORBIDDEN_STATUS_TRANSITION: O papel % não possui permissão para realizar a transição % -> %.', v_actor_role, OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          OLD.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' THEN
        NEW.confirmed_at := COALESCE(NEW.confirmed_at, now());
        NEW.completed_at := COALESCE(NEW.completed_at, now());
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 6. ATUALIZAÇÃO DE public.backfill_and_verify_booking_lineage()
--    - Migra também lookup_token_hmac e lookup_token_hmac_version para a chave
--      HMAC ativa (v_active_ver) em reservas não anonimizadas, permitindo que
--      chaves antigas sejam aposentadas (RETIRE) sem registros órfãos;
--    - Limpa lookup_token_hmac e lookup_token_hmac_version em reservas
--      anonimizadas LGPD.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.backfill_and_verify_booking_lineage()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_active_ver SMALLINT;
  r_bk RECORD;
  r_sib RECORD;
  r_k RECORD;
  v_new_idem VARCHAR(64);
  v_new_orig VARCHAR(64);
  v_new_gen INTEGER;
  v_new_hmac_ver SMALLINT;
  v_new_root_ver SMALLINT;
  v_new_idem_ver SMALLINT;
  v_new_scope_ver SMALLINT;
  v_new_lookup_hmac VARCHAR(64);
  v_new_lookup_ver SMALLINT;
  v_cand_tok TEXT;
  v_resolved_tok TEXT;
  v_root_hash24 TEXT;
  v_scope_hash20 TEXT;
  v_sib_scope_payload TEXT;
  v_is_anon_row BOOLEAN;
  v_has_real_pii BOOLEAN;
  v_skip_row BOOLEAN;
  v_updated_count INTEGER := 0;
  v_skipped_unreconstructable_count INTEGER := 0;
BEGIN
  IF v_uid IS NOT NULL
     OR v_json_sub IS NOT NULL
     OR v_db_role IN ('anon', 'authenticated')
     OR v_jwt_role IN ('anon', 'authenticated')
     OR NOT (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_LINEAGE_BACKFILL: Apenas service_role ou superusuário administrativo pode executar o reparo de linhagem.'
      USING ERRCODE = '42501';
  END IF;

  v_active_ver := internal_guard.require_active_hmac_secret();

  FOR r_bk IN
    SELECT
      b.id,
      b.code,
      b.status,
      b.idempotency_key,
      b.original_idempotency_key,
      b.idempotency_generation,
      b.hmac_key_version,
      b.lineage_root_key_version,
      b.lineage_idem_key_version,
      b.lineage_scope_key_version,
      b.lookup_token_hmac,
      b.lookup_token_hmac_version,
      b.tour_id,
      b.booking_date,
      b.customer_name,
      b.customer_phone,
      b.customer_email,
      b.created_at
    FROM public.bookings b
    ORDER BY b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    v_skip_row := false;
    v_new_idem := pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.idempotency_key, '')));
    v_new_orig := pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.original_idempotency_key, '')));
    v_new_hmac_ver := r_bk.hmac_key_version;
    v_new_root_ver := r_bk.lineage_root_key_version;
    v_new_idem_ver := r_bk.lineage_idem_key_version;
    v_new_scope_ver := r_bk.lineage_scope_key_version;
    v_new_lookup_hmac := r_bk.lookup_token_hmac;
    v_new_lookup_ver := r_bk.lookup_token_hmac_version;

    v_is_anon_row := (
      r_bk.customer_name = 'TITULAR ANONIMIZADO LGPD'
      OR v_new_idem LIKE 'lgpd-%'
      OR v_new_orig LIKE 'lgpd-%'
    );

    v_has_real_pii := (
      r_bk.customer_name <> 'TITULAR ANONIMIZADO LGPD'
      AND r_bk.customer_phone <> '(00) 00000-0000'
      AND pg_catalog.lower(COALESCE(r_bk.customer_email, '')) NOT LIKE 'anonimizado.%@lgpd.invalid'
    );

    IF v_is_anon_row THEN
      v_new_lookup_hmac := NULL;
      v_new_lookup_ver := NULL;

      IF v_new_orig ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
        v_root_hash24 := pg_catalog.substring(v_new_orig from 10 for 24);
        v_scope_hash20 := pg_catalog.substring(v_new_orig from 35 for 20);

        IF v_new_root_ver IS NULL OR v_new_scope_ver IS NULL THEN
          r_sib := NULL;
          FOR r_sib IN
            SELECT
              p.id,
              p.tour_id,
              p.booking_date,
              p.customer_phone,
              p.customer_email,
              pg_catalog.lower(pg_catalog.btrim(COALESCE(NULLIF(p.original_idempotency_key, 'legacy-orig-key'), p.idempotency_key))) AS cand_root
            FROM public.bookings p
            WHERE p.id <> r_bk.id
              AND p.tour_id = r_bk.tour_id
              AND p.booking_date = r_bk.booking_date
              AND p.customer_name <> 'TITULAR ANONIMIZADO LGPD'
              AND pg_catalog.lower(COALESCE(p.original_idempotency_key, '')) NOT LIKE 'lgpd-%'
              AND pg_catalog.lower(COALESCE(p.original_idempotency_key, '')) NOT LIKE 'idg-root-%'
              AND pg_catalog.lower(COALESCE(p.idempotency_key, '')) NOT LIKE 'lgpd-%'
            ORDER BY p.idempotency_generation ASC, p.created_at ASC
          LOOP
            v_sib_scope_payload := r_sib.tour_id::text || ':' || r_sib.booking_date::text || ':'
              || pg_catalog.regexp_replace(COALESCE(r_sib.customer_phone, ''), '[^0-9]', '', 'g') || ':'
              || pg_catalog.lower(pg_catalog.btrim(COALESCE(r_sib.customer_email, '')));

            IF (
                 internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', r_sib.cand_root, v_root_hash24)
                 OR pg_catalog.left(pg_catalog.md5(r_sib.cand_root), 24) = v_root_hash24
               )
               AND (
                 internal_guard.verify_lineage_mac('LGPD_OWNER_SCOPE', v_sib_scope_payload, v_scope_hash20)
                 OR pg_catalog.left(pg_catalog.md5(v_sib_scope_payload), 20) = v_scope_hash20
               ) THEN
              v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', r_sib.cand_root, v_active_ver), 24);
              v_scope_hash20 := pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_OWNER_SCOPE', v_sib_scope_payload, v_active_ver), 20);
              v_new_orig := ('lgpd-lin-' || v_root_hash24 || '-' || v_scope_hash20)::varchar(64);
              v_new_root_ver := v_active_ver;
              v_new_scope_ver := v_active_ver;
              v_new_hmac_ver := v_active_ver;
              EXIT;
            END IF;
          END LOOP;
        END IF;

        IF v_new_idem !~ ('^lgpd-' || pg_catalog.replace(r_bk.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
          v_new_idem := (
            'lgpd-'
            || pg_catalog.replace(r_bk.id::text, '-', '')
            || '-'
            || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', COALESCE(NULLIF(v_new_idem, ''), r_bk.id::text), v_active_ver), 16)
          )::varchar(64);
          v_new_idem_ver := v_active_ver;
        ELSE
          v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver, v_active_ver);
        END IF;

        v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
        v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
        v_new_scope_ver := COALESCE(v_new_scope_ver, v_new_hmac_ver);
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
      ELSIF v_has_real_pii THEN
        IF v_new_idem !~ ('^lgpd-' || pg_catalog.replace(r_bk.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
          v_new_idem := (
            'lgpd-'
            || pg_catalog.replace(r_bk.id::text, '-', '')
            || '-'
            || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', COALESCE(NULLIF(v_new_idem, ''), r_bk.id::text), v_active_ver), 16)
          )::varchar(64);
        END IF;

        IF v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_root_hash24 := pg_catalog.substring(v_new_orig from 5 for 24);
        ELSIF v_new_orig ~ '^idg-root-[0-9a-f]{24}$' THEN
          v_root_hash24 := pg_catalog.substring(v_new_orig from 10 for 24);
        ELSIF v_new_orig <> '' AND v_new_orig NOT LIKE 'lgpd-%' THEN
          v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_new_orig, v_active_ver), 24);
        ELSE
          v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_new_idem, v_active_ver), 24);
        END IF;

        v_scope_hash20 := pg_catalog.left(
          internal_guard.compute_lineage_mac(
            'LGPD_OWNER_SCOPE',
            r_bk.tour_id::text || ':' || r_bk.booking_date::text || ':'
              || pg_catalog.regexp_replace(COALESCE(r_bk.customer_phone, ''), '[^0-9]', '', 'g') || ':'
              || pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.customer_email, ''))),
            v_active_ver
          ),
          20
        );
        v_new_orig := ('lgpd-lin-' || v_root_hash24 || '-' || v_scope_hash20)::varchar(64);
        v_new_hmac_ver := v_active_ver;
        v_new_root_ver := v_active_ver;
        v_new_idem_ver := v_active_ver;
        v_new_scope_ver := v_active_ver;
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
      ELSE
        v_skip_row := true;
        v_skipped_unreconstructable_count := v_skipped_unreconstructable_count + 1;
      END IF;
    ELSE
      IF v_new_idem = '' THEN
        v_new_idem := ('legacy-' || pg_catalog.replace(r_bk.id::text, '-', ''))::varchar(64);
      END IF;

      IF v_new_idem ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
        v_new_gen := pg_catalog.substring(v_new_idem from 31 for 4)::integer;
        v_root_hash24 := pg_catalog.substring(v_new_idem from 5 for 24);

        IF v_new_orig = ''
           OR v_new_orig = 'legacy-orig-key'
           OR v_new_orig = v_new_idem
           OR v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          SELECT COALESCE(
                   NULLIF(pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)), ''),
                   pg_catalog.lower(pg_catalog.btrim(p.idempotency_key))
                 )
            INTO v_new_orig
          FROM public.bookings p
          WHERE p.id <> r_bk.id
            AND p.customer_name <> 'TITULAR ANONIMIZADO LGPD'
            AND p.tour_id = r_bk.tour_id
            AND p.booking_date = r_bk.booking_date
            AND pg_catalog.regexp_replace(COALESCE(p.customer_phone, ''), '[^0-9]', '', 'g')
                = pg_catalog.regexp_replace(COALESCE(r_bk.customer_phone, ''), '[^0-9]', '', 'g')
            AND pg_catalog.lower(pg_catalog.btrim(COALESCE(p.customer_email, '')))
                = pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.customer_email, '')))
            AND (
              (
                pg_catalog.lower(pg_catalog.btrim(COALESCE(p.original_idempotency_key, ''))) <> ''
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) <> 'legacy-orig-key'
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) !~ '^idg-'
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) !~ '^lgpd-'
                AND (
                  internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)), v_root_hash24)
                  OR (
                    r_bk.lineage_root_key_version IS NULL
                    AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key))), 24) = v_root_hash24
                  )
                )
              )
              OR (
                pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)) !~ '^idg-'
                AND pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)) !~ '^lgpd-'
                AND (
                  internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)), v_root_hash24)
                  OR (
                    r_bk.lineage_root_key_version IS NULL
                    AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(p.idempotency_key))), 24) = v_root_hash24
                  )
                )
              )
            )
          ORDER BY p.created_at ASC, p.id ASC
          LIMIT 1;

          v_new_orig := COALESCE(NULLIF(v_new_orig, ''), ('idg-root-' || v_root_hash24)::varchar(64));
        END IF;

        IF v_new_orig NOT LIKE 'idg-root-%' AND v_new_orig NOT LIKE 'lgpd-%' THEN
          IF NOT internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', v_new_orig, v_root_hash24, r_bk.lineage_root_key_version)
             OR NOT internal_guard.verify_lineage_mac('LINEAGE_GEN_V1', v_root_hash24 || ':gen:' || v_new_gen::text, pg_catalog.right(v_new_idem, 24), r_bk.lineage_idem_key_version) THEN
            v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
            v_new_hmac_ver := v_active_ver;
            v_new_root_ver := v_active_ver;
            v_new_idem_ver := v_active_ver;
          ELSE
            v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
            v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
            v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
          END IF;
        ELSE
          IF NOT internal_guard.verify_lineage_mac('LINEAGE_GEN_V1', v_root_hash24 || ':gen:' || v_new_gen::text, pg_catalog.right(v_new_idem, 24), r_bk.lineage_idem_key_version) THEN
            v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
            v_new_hmac_ver := v_active_ver;
            v_new_idem_ver := v_active_ver;
          ELSE
            v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
            v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
          END IF;
        END IF;
        v_new_scope_ver := NULL;
      ELSE
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
        IF v_new_orig = ''
           OR v_new_orig = 'legacy-orig-key'
           OR v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_new_orig := v_new_idem;
        END IF;
        v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
        v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
        v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
        v_new_scope_ver := NULL;
      END IF;

      -- Atualiza/migra lookup_token_hmac para a versão ativa preservando o lookup_token já emitido
      v_resolved_tok := NULL;
      IF r_bk.lookup_token_hmac IS NOT NULL THEN
        FOR r_k IN
          SELECT k.key_version
          FROM internal_guard.lineage_hmac_keys k
          WHERE k.is_verify_enabled = true
          ORDER BY k.is_current DESC, k.key_version DESC
        LOOP
          v_cand_tok := 'ubtk-' || pg_catalog.left(
            internal_guard.compute_lineage_mac(
              'BOOKING_LOOKUP_TOKEN_V1',
              'ISSUE:' || r_bk.id::text || ':' || pg_catalog.upper(r_bk.code),
              r_k.key_version
            ),
            32
          );
          IF internal_guard.verify_lineage_mac(
               'BOOKING_LOOKUP_TOKEN_V1',
               'VERIFY:' || pg_catalog.upper(r_bk.code) || ':' || v_cand_tok,
               r_bk.lookup_token_hmac,
               r_bk.lookup_token_hmac_version
             ) THEN
            v_resolved_tok := v_cand_tok;
            EXIT;
          END IF;
        END LOOP;
      END IF;

      IF v_resolved_tok IS NULL THEN
        v_resolved_tok := 'ubtk-' || pg_catalog.left(
          internal_guard.compute_lineage_mac(
            'BOOKING_LOOKUP_TOKEN_V1',
            'ISSUE:' || r_bk.id::text || ':' || pg_catalog.upper(r_bk.code),
            COALESCE(v_new_hmac_ver, v_active_ver)
          ),
          32
        );
      END IF;

      v_new_lookup_hmac := internal_guard.compute_lineage_mac(
        'BOOKING_LOOKUP_TOKEN_V1',
        'VERIFY:' || pg_catalog.upper(r_bk.code) || ':' || v_resolved_tok,
        v_active_ver
      );
      v_new_lookup_ver := v_active_ver;
    END IF;

    IF NOT v_skip_row THEN
      WHILE EXISTS (
        SELECT 1 FROM public.bookings x
        WHERE x.id <> r_bk.id
          AND x.original_idempotency_key = v_new_orig
          AND x.idempotency_generation = v_new_gen
      ) LOOP
        v_new_gen := v_new_gen + 1;
        IF v_new_idem ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
          v_new_hmac_ver := v_active_ver;
          v_new_idem_ver := v_active_ver;
        END IF;
      END LOOP;

      IF r_bk.idempotency_key IS DISTINCT FROM v_new_idem
         OR r_bk.original_idempotency_key IS DISTINCT FROM v_new_orig
         OR r_bk.idempotency_generation IS DISTINCT FROM v_new_gen
         OR r_bk.hmac_key_version IS DISTINCT FROM v_new_hmac_ver
         OR r_bk.lineage_root_key_version IS DISTINCT FROM v_new_root_ver
         OR r_bk.lineage_idem_key_version IS DISTINCT FROM v_new_idem_ver
         OR r_bk.lineage_scope_key_version IS DISTINCT FROM v_new_scope_ver
         OR r_bk.lookup_token_hmac IS DISTINCT FROM v_new_lookup_hmac
         OR r_bk.lookup_token_hmac_version IS DISTINCT FROM v_new_lookup_ver THEN
        PERFORM internal_guard.issue_token('BOOKING_MUTATION', r_bk.id, 'LINEAGE_BACKFILL:' || r_bk.status::text);
        UPDATE public.bookings
        SET idempotency_key = v_new_idem,
            original_idempotency_key = v_new_orig,
            idempotency_generation = v_new_gen,
            hmac_key_version = v_new_hmac_ver,
            lineage_root_key_version = v_new_root_ver,
            lineage_idem_key_version = v_new_idem_ver,
            lineage_scope_key_version = v_new_scope_ver,
            lookup_token_hmac = v_new_lookup_hmac,
            lookup_token_hmac_version = v_new_lookup_ver
        WHERE id = r_bk.id;
        PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', r_bk.id);
        v_updated_count := v_updated_count + 1;
      END IF;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'verified', true,
    'updated_rows', v_updated_count,
    'skipped_unreconstructable_anon_rows', v_skipped_unreconstructable_count,
    'active_hmac_key_version', v_active_ver
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 7. ATUALIZAÇÃO DE public.create_booking_request()
--    - Valida data mínima contra public.current_brazil_date() (rejeitando datas
--      passadas com BOOKING_DATE_IN_PAST);
--    - Emite lookup_token ('ubtk-' || 32 hex HMAC-SHA-256 de 128 bits) sem
--      armazenar o token em texto puro no banco (persiste apenas lookup_token_hmac
--      e lookup_token_hmac_version);
--    - Retorna o mesmo lookup_token em replay idempotente autenticado após timeout.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_today_br DATE := public.current_brazil_date();
  v_active_key_ver SMALLINT;
  v_root_key_ver SMALLINT;
  v_derived_row public.bookings;
  v_non_anon_root VARCHAR(64);
  v_input_root_hash24 TEXT;
  v_input_gen INTEGER;
  v_input_gen_hash24 TEXT;
  v_legacy_md5_root24 TEXT;
  v_key_match RECORD;
  v_key_same_owner BOOLEAN := false;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_existing_same_owner BOOLEAN := false;
  v_next_generation INTEGER := 0;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_has_explicit_key BOOLEAN := false;
  v_root_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_candidate_root_hashes TEXT[] := ARRAY[]::TEXT[];
  v_candidate_root_aliases TEXT[] := ARRAY[]::TEXT[];
  v_candidate_idg_prefixes TEXT[] := ARRAY[]::TEXT[];
  v_candidate_lgpd_prefixes TEXT[] := ARRAY[]::TEXT[];
  r_kver RECORD;
  v_ver_h24 TEXT;
  v_caller_scope_payload TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_new_booking_id UUID;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_lookup_token TEXT;
  v_cand_tok TEXT;
  v_lookup_hmac VARCHAR(64);
  v_inserted public.bookings;
  v_raw_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_uid UUID := NULL;
BEGIN
  IF (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_raw_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_raw_uid::text <> v_json_sub) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_CONTEXT: Conflito de identidade entre claims JWT GUC e JSON.'
      USING ERRCODE = '42501';
  END IF;

  IF v_raw_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     )
     AND EXISTS (SELECT 1 FROM public.profiles WHERE id = v_raw_uid AND is_active = true) THEN
    v_uid := v_raw_uid;
  END IF;

  v_clean_name := pg_catalog.btrim(COALESCE(p_customer_name, ''));
  v_clean_phone := pg_catalog.btrim(COALESCE(p_customer_phone, ''));
  v_phone_digits := pg_catalog.regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_customer_email, '')));
  v_clean_channel := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_channel, '')));

  v_clean_idem_input := pg_catalog.lower(
    pg_catalog.regexp_replace(
      COALESCE(p_idempotency_key, ''),
      '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$',
      '',
      'g'
    )
  );
  v_has_explicit_key := (v_clean_idem_input <> '');

  IF v_has_explicit_key THEN
    IF v_clean_idem_input LIKE 'lgpd-%' OR v_clean_idem_input LIKE 'idg-root-%' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Os prefixos "lgpd-" e "idg-root-" são reservados exclusivamente para controle interno de linhagem e conformidade LGPD.'
        USING ERRCODE = '23514';
    END IF;

    IF pg_catalog.char_length(v_clean_idem_input) < 8
       OR pg_catalog.char_length(v_clean_idem_input) > 64
       OR v_clean_idem_input !~ '^[a-z0-9._:-]+$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: A chave de idempotência deve conter entre 8 e 64 caracteres alfanuméricos (a-z, 0-9, ., _, :, -) sem espaços internos.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF pg_catalog.char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_phone_digits) < 10 OR pg_catalog.char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.position('@' in v_clean_email) <= 1 OR pg_catalog.char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < v_today_br THEN
    RAISE EXCEPTION 'BOOKING_DATE_IN_PAST: A data do passeio (%) não pode ser anterior à data atual em Brasília (%).', p_booking_date, v_today_br
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_active_key_ver := internal_guard.require_active_hmac_secret();

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT
    id,
    slug,
    title,
    partner_id,
    vessel_id,
    pricing_model,
    price,
    capacity,
    departure_time,
    return_time,
    check_in_time,
    departure_point,
    status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  -- Hierarquia Canônica de Locks:
  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  -- Lock #2: Advisory lock transacional (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, base_marina, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_caller_scope_payload := v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits || ':' || v_clean_email;

  IF v_clean_idem_input LIKE 'idg-%' THEN
    IF v_clean_idem_input !~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "idg-" é reservado para chaves derivadas de linhagem de idempotência.'
        USING ERRCODE = '23514';
    END IF;

    v_input_root_hash24 := pg_catalog.substring(v_clean_idem_input from 5 for 24);
    v_input_gen := pg_catalog.substring(v_clean_idem_input from 31 for 4)::integer;
    v_input_gen_hash24 := pg_catalog.right(v_clean_idem_input, 24);

    SELECT b.*
      INTO v_derived_row
    FROM public.bookings b
    WHERE pg_catalog.lower(b.idempotency_key) = v_clean_idem_input
       OR (
         b.idempotency_generation = v_input_gen
         AND b.original_idempotency_key LIKE ('lgpd-lin-' || v_input_root_hash24 || '-%')
         AND (
           internal_guard.verify_lineage_mac('LGPD_IDEM_AUTH', v_clean_idem_input, pg_catalog.right(b.idempotency_key, 16), b.lineage_idem_key_version)
           OR (
             b.lineage_idem_key_version IS NULL
             AND b.hmac_key_version IS NULL
             AND pg_catalog.right(b.idempotency_key, 16) = pg_catalog.left(pg_catalog.md5(v_clean_idem_input), 16)
           )
         )
       )
       OR (
         b.idempotency_generation = v_input_gen
         AND b.original_idempotency_key NOT LIKE 'lgpd-%'
         AND b.original_idempotency_key NOT LIKE 'idg-root-%'
         AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key))), 24) = v_input_root_hash24
         AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key)) || ':gen:' || v_input_gen::text), 24) = v_input_gen_hash24
       )
    ORDER BY CASE WHEN pg_catalog.lower(b.idempotency_key) = v_clean_idem_input THEN 0 ELSE 1 END ASC
    LIMIT 1
    FOR UPDATE;

    IF v_derived_row.id IS NULL
       OR v_derived_row.original_idempotency_key IS NULL
       OR v_derived_row.idempotency_generation <= 0 THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
        USING ERRCODE = '23514';
    END IF;

    IF v_derived_row.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      IF NOT (
           internal_guard.verify_lineage_mac('LGPD_IDEM_AUTH', v_clean_idem_input, pg_catalog.right(v_derived_row.idempotency_key, 16), v_derived_row.lineage_idem_key_version)
           OR (
             v_derived_row.lineage_idem_key_version IS NULL
             AND v_derived_row.hmac_key_version IS NULL
             AND pg_catalog.right(v_derived_row.idempotency_key, 16) = pg_catalog.left(pg_catalog.md5(v_clean_idem_input), 16)
           )
         ) THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;

      SELECT b.original_idempotency_key
        INTO v_non_anon_root
      FROM public.bookings b
      WHERE b.original_idempotency_key NOT LIKE 'lgpd-%'
        AND b.original_idempotency_key NOT LIKE 'idg-root-%'
        AND (
          internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key)), v_input_root_hash24, b.lineage_root_key_version)
          OR (
            v_derived_row.lineage_root_key_version IS NULL
            AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key))), 24) = v_input_root_hash24
          )
        )
      ORDER BY b.idempotency_generation ASC
      LIMIT 1;

      v_root_idem_key := COALESCE(v_non_anon_root, ('idg-root-' || v_input_root_hash24)::varchar(64));
      IF v_non_anon_root IS NOT NULL THEN
        v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_non_anon_root, v_active_key_ver), 24);
        v_root_key_ver := v_active_key_ver;
      ELSE
        v_root_hash24 := v_input_root_hash24;
        v_root_key_ver := COALESCE(v_derived_row.lineage_root_key_version, v_active_key_ver);
      END IF;
    ELSE
      IF NOT (
           internal_guard.verify_lineage_mac(
             'LINEAGE_GEN_V1',
             v_input_root_hash24 || ':gen:' || v_derived_row.idempotency_generation::text,
             v_input_gen_hash24,
             v_derived_row.lineage_idem_key_version
           )
           OR (
             v_derived_row.original_idempotency_key NOT LIKE 'idg-root-%'
             AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(v_derived_row.original_idempotency_key))), 24) = v_input_root_hash24
             AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(v_derived_row.original_idempotency_key)) || ':gen:' || v_derived_row.idempotency_generation::text), 24) = v_input_gen_hash24
           )
           OR (
             v_derived_row.lineage_idem_key_version IS NULL
             AND v_derived_row.original_idempotency_key = ('idg-root-' || v_input_root_hash24)
             AND pg_catalog.left(pg_catalog.md5(v_input_root_hash24 || ':gen:' || v_derived_row.idempotency_generation::text), 24) = v_input_gen_hash24
           )
         ) THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;

      v_root_idem_key := v_derived_row.original_idempotency_key;
      IF v_root_idem_key NOT LIKE 'idg-root-%' AND v_root_idem_key NOT LIKE 'lgpd-%' THEN
        v_root_hash24 := pg_catalog.left(
          internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, v_active_key_ver),
          24
        );
        v_root_key_ver := v_active_key_ver;
      ELSE
        v_root_hash24 := v_input_root_hash24;
        v_root_key_ver := COALESCE(v_derived_row.lineage_root_key_version, v_active_key_ver);
      END IF;
    END IF;
  ELSE
    v_root_idem_key := pg_catalog.left(
      COALESCE(
        NULLIF(v_clean_idem_input, ''),
        internal_guard.compute_lineage_mac('NATURAL_BOOKING_KEY', v_caller_scope_payload, v_active_key_ver)
      ),
      64
    );
    v_root_hash24 := pg_catalog.left(
      internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, v_active_key_ver),
      24
    );
    v_root_key_ver := v_active_key_ver;
  END IF;

  v_candidate_root_hashes := ARRAY[v_root_hash24];
  IF v_clean_idem_input LIKE 'idg-%' AND NOT (v_input_root_hash24 = ANY(v_candidate_root_hashes)) THEN
    v_candidate_root_hashes := array_append(v_candidate_root_hashes, v_input_root_hash24);
  END IF;

  IF v_root_idem_key NOT LIKE 'idg-root-%' AND v_root_idem_key NOT LIKE 'lgpd-%' THEN
    FOR r_kver IN
      SELECT k.key_version
      FROM internal_guard.lineage_hmac_keys k
      WHERE k.is_verify_enabled = true
      ORDER BY k.is_current DESC, k.key_version DESC
    LOOP
      v_ver_h24 := pg_catalog.left(
        internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, r_kver.key_version),
        24
      );
      IF NOT (v_ver_h24 = ANY(v_candidate_root_hashes)) THEN
        v_candidate_root_hashes := array_append(v_candidate_root_hashes, v_ver_h24);
      END IF;
    END LOOP;

    v_legacy_md5_root24 := pg_catalog.left(pg_catalog.md5(v_root_idem_key), 24);
  ELSE
    v_legacy_md5_root24 := NULL;
  END IF;

  FOREACH v_ver_h24 IN ARRAY v_candidate_root_hashes LOOP
    v_candidate_root_aliases := array_append(v_candidate_root_aliases, 'idg-root-' || v_ver_h24);
    v_candidate_idg_prefixes := array_append(v_candidate_idg_prefixes, 'idg-' || v_ver_h24 || '-g%');
    v_candidate_lgpd_prefixes := array_append(v_candidate_lgpd_prefixes, 'lgpd-lin-' || v_ver_h24 || '-%');
  END LOOP;

  FOR v_key_match IN
    SELECT b.*
    FROM public.bookings b
    WHERE b.original_idempotency_key = v_root_idem_key
       OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
       OR b.original_idempotency_key LIKE ANY(v_candidate_lgpd_prefixes)
       OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
       OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
       OR (
         v_legacy_md5_root24 IS NOT NULL
         AND b.lineage_root_key_version IS NULL
         AND (
           b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
           OR b.original_idempotency_key LIKE ('lgpd-lin-' || v_legacy_md5_root24 || '-%')
           OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
         )
       )
    ORDER BY b.idempotency_generation ASC, b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    IF v_key_match.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      v_key_same_owner := (
        (
          internal_guard.verify_lineage_mac(
            'LGPD_OWNER_SCOPE',
            v_caller_scope_payload,
            pg_catalog.substring(v_key_match.original_idempotency_key from 35 for 20),
            v_key_match.lineage_scope_key_version
          )
          OR (
            v_key_match.lineage_scope_key_version IS NULL
            AND v_key_match.hmac_key_version IS NULL
            AND pg_catalog.substring(v_key_match.original_idempotency_key from 35 for 20) = pg_catalog.left(pg_catalog.md5(v_caller_scope_payload), 20)
          )
        )
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    ELSE
      v_key_same_owner := (
        (v_key_match.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_key_match.tourist_user_id OR public.is_admin())
        AND pg_catalog.regexp_replace(v_key_match.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
        AND pg_catalog.lower(pg_catalog.btrim(v_key_match.customer_email)) = v_clean_email
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    END IF;

    IF NOT v_key_same_owner THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: A chave de idempotência informada já pertence a outro titular, outro passeio ou outra data.'
        USING ERRCODE = '23505';
    END IF;
  END LOOP;

  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE (
      b.original_idempotency_key = v_root_idem_key
      OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
      OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
      OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
      OR (
        v_legacy_md5_root24 IS NOT NULL
        AND b.lineage_root_key_version IS NULL
        AND (
          b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
          OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
        )
      )
      OR (
        NOT v_has_explicit_key
        AND b.tour_id = v_tour.id
        AND b.booking_date = p_booking_date
        AND pg_catalog.regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      )
    )
    AND b.original_idempotency_key NOT LIKE 'lgpd-%'
    AND b.idempotency_key NOT LIKE 'lgpd-%'
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.idempotency_generation DESC,
    b.created_at DESC,
    b.id DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );

    v_existing_same_owner := (
      (v_existing.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_existing.tourist_user_id OR public.is_admin())
      AND pg_catalog.regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND pg_catalog.lower(pg_catalog.btrim(v_existing.customer_email)) = v_clean_email
      AND v_existing.tour_id = v_tour.id
      AND v_existing.booking_date = p_booking_date
    );
  END IF;

  IF v_existing.id IS NOT NULL AND NOT v_existing_same_owner THEN
    RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação conflitante ou a chave de idempotência pertence a outro titular/passeio/data.'
      USING ERRCODE = '23505';
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    v_lookup_token := NULL;
    FOR r_kver IN
      SELECT k.key_version
      FROM internal_guard.lineage_hmac_keys k
      WHERE k.is_verify_enabled = true
      ORDER BY k.is_current DESC, k.key_version DESC
    LOOP
      v_cand_tok := 'ubtk-' || pg_catalog.left(
        internal_guard.compute_lineage_mac(
          'BOOKING_LOOKUP_TOKEN_V1',
          'ISSUE:' || v_existing.id::text || ':' || pg_catalog.upper(v_existing.code),
          r_kver.key_version
        ),
        32
      );
      IF v_existing.lookup_token_hmac IS NOT NULL
         AND internal_guard.verify_lineage_mac(
           'BOOKING_LOOKUP_TOKEN_V1',
           'VERIFY:' || pg_catalog.upper(v_existing.code) || ':' || v_cand_tok,
           v_existing.lookup_token_hmac,
           v_existing.lookup_token_hmac_version
         ) THEN
        v_lookup_token := v_cand_tok;
        EXIT;
      END IF;
    END LOOP;

    IF v_lookup_token IS NULL THEN
      v_lookup_token := 'ubtk-' || pg_catalog.left(
        internal_guard.compute_lineage_mac(
          'BOOKING_LOOKUP_TOKEN_V1',
          'ISSUE:' || v_existing.id::text || ':' || pg_catalog.upper(v_existing.code),
          COALESCE(v_existing.hmac_key_version, v_active_key_ver)
        ),
        32
      );
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'lookup_token', v_lookup_token,
      'idempotency_key', v_existing.idempotency_key,
      'original_idempotency_key', v_existing.original_idempotency_key,
      'idempotency_generation', v_existing.idempotency_generation,
      'hmac_key_version', v_existing.hmac_key_version,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'departure_time', v_tour.departure_time,
      'return_time', v_tour.return_time,
      'check_in_time', v_tour.check_in_time,
      'departure_point', v_tour.departure_point,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  SELECT COALESCE(MAX(b.idempotency_generation) + 1, 0)::integer
    INTO v_next_generation
  FROM public.bookings b
  WHERE b.original_idempotency_key = v_root_idem_key
      OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
      OR b.original_idempotency_key LIKE ANY(v_candidate_lgpd_prefixes)
      OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
      OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
      OR (
        v_legacy_md5_root24 IS NOT NULL
        AND b.lineage_root_key_version IS NULL
        AND (
          b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
          OR b.original_idempotency_key LIKE ('lgpd-lin-' || v_legacy_md5_root24 || '-%')
          OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
        )
      );

  v_computed_idem_key := public.derive_idempotency_lineage_key(v_root_idem_key, v_next_generation);

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  v_new_booking_id := pg_catalog.gen_random_uuid();

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || pg_catalog.lpad((pg_catalog.floor(1000 + pg_catalog.random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || pg_catalog.upper(pg_catalog.substr(pg_catalog.replace(pg_catalog.gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  -- Emite credencial de consulta segura (128 bits / 32 hex) e grava apenas o MAC de verificação de 256 bits
  v_lookup_token := 'ubtk-' || pg_catalog.left(
    internal_guard.compute_lineage_mac(
      'BOOKING_LOOKUP_TOKEN_V1',
      'ISSUE:' || v_new_booking_id::text || ':' || pg_catalog.upper(v_unique_code),
      v_active_key_ver
    ),
    32
  );
  v_lookup_hmac := internal_guard.compute_lineage_mac(
    'BOOKING_LOOKUP_TOKEN_V1',
    'VERIFY:' || pg_catalog.upper(v_unique_code) || ':' || v_lookup_token,
    v_active_key_ver
  );

  INSERT INTO public.bookings (
    id,
    code,
    idempotency_key,
    original_idempotency_key,
    idempotency_generation,
    hmac_key_version,
    lineage_root_key_version,
    lineage_idem_key_version,
    lineage_scope_key_version,
    lookup_token_hmac,
    lookup_token_hmac_version,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_new_booking_id,
    v_unique_code,
    v_computed_idem_key,
    v_root_idem_key,
    v_next_generation,
    v_active_key_ver,
    v_root_key_ver,
    v_active_key_ver,
    NULL,
    v_lookup_hmac,
    v_active_key_ver,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(pg_catalog.btrim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(pg_catalog.btrim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'lookup_token', v_lookup_token,
    'idempotency_key', v_inserted.idempotency_key,
    'original_idempotency_key', v_inserted.original_idempotency_key,
    'idempotency_generation', v_inserted.idempotency_generation,
    'hmac_key_version', v_inserted.hmac_key_version,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'departure_time', v_tour.departure_time,
    'return_time', v_tour.return_time,
    'check_in_time', v_tour.check_in_time,
    'departure_point', v_tour.departure_point,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 8. RPC PÚBLICA SEGURA DE CONSULTA PELO TURISTA (SEÇÃO 7)
--    public.lookup_booking_by_tourist_token(p_booking_code, p_lookup_token)
--    - Exige código da reserva + credencial criptográfica de 128 bits (ubtk-...);
--    - Aplica rate limiting por código (máx. 5 falhas em 15 minutos -> bloqueio de 15 min);
--    - Resposta de erro uniforme contra enumeração (INVALID_LOOKUP_CREDENTIALS);
--    - NUNCA expõe UUIDs internos, telefone, e-mail, nome completo ou comissões.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.lookup_booking_by_tourist_token(
  p_booking_code TEXT,
  p_lookup_token TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_clean_code VARCHAR(16) := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_booking_code, '')));
  v_clean_token TEXT := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_lookup_token, '')));
  v_rl internal_guard.booking_lookup_rate_limits;
  v_bk public.bookings;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_token_valid BOOLEAN := false;
  v_new_fails SMALLINT;
BEGIN
  IF v_clean_code !~ '^UBT-[A-Z0-9]{4,8}$'
     OR v_clean_token !~ '^ubtk-[0-9a-f]{32}$' THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'INVALID_LOOKUP_CREDENTIALS',
      'message', 'Código de reserva ou credencial de consulta inválidos.'
    );
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('LOOKUP_RL:' || v_clean_code));

  SELECT * INTO v_rl
  FROM internal_guard.booking_lookup_rate_limits
  WHERE booking_code = v_clean_code
  FOR UPDATE;

  IF v_rl.booking_code IS NOT NULL AND v_rl.locked_until IS NOT NULL AND v_rl.locked_until > now() THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'LOOKUP_RATE_LIMIT_EXCEEDED',
      'message', 'Limite de tentativas excedido para este código. Aguarde 15 minutos antes de tentar novamente.',
      'locked_until', v_rl.locked_until
    );
  END IF;

  SELECT * INTO v_bk
  FROM public.bookings b
  WHERE b.code = v_clean_code
  LIMIT 1;

  IF v_bk.id IS NOT NULL
     AND v_bk.customer_name <> 'TITULAR ANONIMIZADO LGPD'
     AND v_bk.idempotency_key NOT LIKE 'lgpd-%'
     AND v_bk.lookup_token_hmac IS NOT NULL THEN
    v_token_valid := internal_guard.verify_lineage_mac(
      'BOOKING_LOOKUP_TOKEN_V1',
      'VERIFY:' || v_clean_code || ':' || v_clean_token,
      v_bk.lookup_token_hmac,
      v_bk.lookup_token_hmac_version
    );
  END IF;

  IF NOT v_token_valid THEN
    IF v_rl.booking_code IS NULL THEN
      INSERT INTO internal_guard.booking_lookup_rate_limits (
        booking_code, failed_attempts, window_started_at, locked_until, updated_at
      ) VALUES (
        v_clean_code, 1, now(), NULL, now()
      );
    ELSE
      IF v_rl.window_started_at < (now() - interval '15 minutes') THEN
        v_new_fails := 1;
      ELSE
        v_new_fails := v_rl.failed_attempts + 1;
      END IF;

      UPDATE internal_guard.booking_lookup_rate_limits
      SET failed_attempts = v_new_fails,
          window_started_at = CASE WHEN v_new_fails = 1 THEN now() ELSE v_rl.window_started_at END,
          locked_until = CASE WHEN v_new_fails >= 5 THEN now() + interval '15 minutes' ELSE NULL END,
          updated_at = now()
      WHERE booking_code = v_clean_code;
    END IF;

    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'INVALID_LOOKUP_CREDENTIALS',
      'message', 'Código de reserva ou credencial de consulta inválidos.'
    );
  END IF;

  IF v_rl.booking_code IS NOT NULL AND (v_rl.failed_attempts > 0 OR v_rl.locked_until IS NOT NULL) THEN
    UPDATE internal_guard.booking_lookup_rate_limits
    SET failed_attempts = 0,
        locked_until = NULL,
        window_started_at = now(),
        updated_at = now()
    WHERE booking_code = v_clean_code;
  END IF;

  SELECT slug, title, departure_time, return_time, check_in_time, departure_point, cancellation_policy
    INTO v_tour
  FROM public.tours
  WHERE id = v_bk.tour_id;

  SELECT name
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_bk.vessel_id;

  SELECT name, whatsapp, base_marina
    INTO v_partner
  FROM public.partners
  WHERE id = v_bk.partner_id;

  RETURN jsonb_build_object(
    'ok', true,
    'booking_code', v_bk.code,
    'status', v_bk.status,
    'booking_date', v_bk.booking_date,
    'passengers', v_bk.passengers,
    'pricing_model', v_bk.pricing_model_snapshot,
    'unit_price', v_bk.unit_price_snapshot,
    'gross_amount', v_bk.gross_amount,
    'channel', v_bk.channel,
    'tour_slug', v_tour.slug,
    'tour_title', v_tour.title,
    'departure_time', v_tour.departure_time,
    'return_time', v_tour.return_time,
    'check_in_time', v_tour.check_in_time,
    'departure_point', v_tour.departure_point,
    'cancellation_policy', v_tour.cancellation_policy,
    'vessel_name', v_vessel.name,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'partner_base_marina', v_partner.base_marina,
    'rejection_or_cancel_reason', v_bk.rejection_or_cancel_reason,
    'expires_at', v_bk.expires_at,
    'confirmed_at', v_bk.confirmed_at,
    'completed_at', v_bk.completed_at,
    'cancelled_at', v_bk.cancelled_at,
    'created_at', v_bk.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 9. RPC PÚBLICA SEGURA DE CANCELAMENTO PELO TURISTA VIA CREDENCIAL (SEÇÃO 8)
--    public.cancel_booking_by_tourist_token(p_booking_code, p_lookup_token, p_reason)
--    - Respeita a hierarquia canônica de locks (STATIC-06):
--      Lock #1 Embarcação FOR UPDATE -> Lock #2 Advisory Lock -> Lock #3 Reserva FOR UPDATE;
--    - Autentica a credencial via HMAC-SHA-256 com rate limiting;
--    - Idempotente quando a reserva já está CANCELADA;
--    - Libera vagas imediatamente e reverte a comissão no livro-razão (REVERTIDA).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.cancel_booking_by_tourist_token(
  p_booking_code TEXT,
  p_lookup_token TEXT,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_clean_code VARCHAR(16) := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_booking_code, '')));
  v_clean_token TEXT := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_lookup_token, '')));
  v_clean_reason TEXT := COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), ''), 'Cancelado pelo turista via credencial de consulta');
  v_rl internal_guard.booking_lookup_rate_limits;
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger_status public.ledger_status_type;
  v_token_valid BOOLEAN := false;
  v_new_fails SMALLINT;
BEGIN
  IF v_clean_code !~ '^UBT-[A-Z0-9]{4,8}$'
     OR v_clean_token !~ '^ubtk-[0-9a-f]{32}$' THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'INVALID_LOOKUP_CREDENTIALS',
      'message', 'Código de reserva ou credencial de consulta inválidos.'
    );
  END IF;

  SELECT * INTO v_target
  FROM public.bookings b
  WHERE b.code = v_clean_code
  LIMIT 1;

  IF v_target.id IS NOT NULL THEN
    -- Hierarquia canônica de locks (STATIC-06):
    -- Lock #1: Embarcação FOR UPDATE
    PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
    -- Lock #2: Advisory Lock (embarcação + data)
    PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));
    -- Lock #3: Reserva FOR UPDATE
    SELECT * INTO v_target
    FROM public.bookings
    WHERE id = v_target.id
    FOR UPDATE;
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext('LOOKUP_RL:' || v_clean_code));

  SELECT * INTO v_rl
  FROM internal_guard.booking_lookup_rate_limits
  WHERE booking_code = v_clean_code
  FOR UPDATE;

  IF v_rl.booking_code IS NOT NULL AND v_rl.locked_until IS NOT NULL AND v_rl.locked_until > now() THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'LOOKUP_RATE_LIMIT_EXCEEDED',
      'message', 'Limite de tentativas excedido para este código. Aguarde 15 minutos antes de tentar novamente.',
      'locked_until', v_rl.locked_until
    );
  END IF;

  IF v_target.id IS NOT NULL
     AND v_target.customer_name <> 'TITULAR ANONIMIZADO LGPD'
     AND v_target.idempotency_key NOT LIKE 'lgpd-%'
     AND v_target.lookup_token_hmac IS NOT NULL THEN
    v_token_valid := internal_guard.verify_lineage_mac(
      'BOOKING_LOOKUP_TOKEN_V1',
      'VERIFY:' || v_clean_code || ':' || v_clean_token,
      v_target.lookup_token_hmac,
      v_target.lookup_token_hmac_version
    );
  END IF;

  IF NOT v_token_valid THEN
    IF v_rl.booking_code IS NULL THEN
      INSERT INTO internal_guard.booking_lookup_rate_limits (
        booking_code, failed_attempts, window_started_at, locked_until, updated_at
      ) VALUES (
        v_clean_code, 1, now(), NULL, now()
      );
    ELSE
      IF v_rl.window_started_at < (now() - interval '15 minutes') THEN
        v_new_fails := 1;
      ELSE
        v_new_fails := v_rl.failed_attempts + 1;
      END IF;

      UPDATE internal_guard.booking_lookup_rate_limits
      SET failed_attempts = v_new_fails,
          window_started_at = CASE WHEN v_new_fails = 1 THEN now() ELSE v_rl.window_started_at END,
          locked_until = CASE WHEN v_new_fails >= 5 THEN now() + interval '15 minutes' ELSE NULL END,
          updated_at = now()
      WHERE booking_code = v_clean_code;
    END IF;

    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'INVALID_LOOKUP_CREDENTIALS',
      'message', 'Código de reserva ou credencial de consulta inválidos.'
    );
  END IF;

  IF v_rl.booking_code IS NOT NULL AND (v_rl.failed_attempts > 0 OR v_rl.locked_until IS NOT NULL) THEN
    UPDATE internal_guard.booking_lookup_rate_limits
    SET failed_attempts = 0,
        locked_until = NULL,
        window_started_at = now(),
        updated_at = now()
    WHERE booking_code = v_clean_code;
  END IF;

  -- Idempotência do cancelamento (Seção 8)
  IF v_target.status = 'CANCELADA' THEN
    SELECT ledger_status INTO v_ledger_status
    FROM public.commission_ledger
    WHERE booking_id = v_target.id;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'booking_code', v_target.code,
      'previous_status', 'CANCELADA'::public.booking_status_type,
      'status', 'CANCELADA'::public.booking_status_type,
      'ledger_status', COALESCE(v_ledger_status, 'REVERTIDA'::public.ledger_status_type),
      'cancelled_at', v_target.cancelled_at,
      'rejection_or_cancel_reason', v_target.rejection_or_cancel_reason
    );
  END IF;

  IF v_target.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA') THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'FORBIDDEN_TOURIST_CANCELLATION_STATUS',
      'message', pg_catalog.format('A reserva %s encontra-se no status %s e não pode ser cancelada publicamente.', v_target.code, v_target.status)
    );
  END IF;

  IF v_target.booking_date < public.current_brazil_date() THEN
    RETURN jsonb_build_object(
      'ok', false,
      'error_code', 'CANCELLATION_PAST_DATE_FORBIDDEN',
      'message', 'Não é permitido cancelar reserva cuja data do passeio já passou.'
    );
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'TOURIST_TOKEN_CANCEL:CANCELADA');

  UPDATE public.bookings
  SET status = 'CANCELADA',
      rejection_or_cancel_reason = v_clean_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'ledger_status', COALESCE(v_ledger_status, 'REVERTIDA'::public.ledger_status_type),
    'cancelled_at', v_updated.cancelled_at,
    'rejection_or_cancel_reason', v_updated.rejection_or_cancel_reason
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 10. EXECUÇÃO DO BACKFILL PARA POPULAR lookup_token_hmac E VERSÕES ATIVAS
-- ----------------------------------------------------------------------------
DO $$
BEGIN
  PERFORM public.backfill_and_verify_booking_lineage();
END
$$;

-- ----------------------------------------------------------------------------
-- 11. CONSOLIDAÇÃO DE PRIVILÉGIOS E SEGURANÇA (SEÇÕES 9 E 11)
-- ----------------------------------------------------------------------------
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA internal_guard FROM PUBLIC;
REVOKE ALL ON TABLE internal_guard.booking_lookup_rate_limits FROM PUBLIC;

DO $$
DECLARE
  r_fn RECORD;
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
    FOR r_fn IN
      SELECT proc_row.oid::regprocedure AS fn_sig
      FROM pg_catalog.pg_proc proc_row
      JOIN pg_catalog.pg_namespace ns_row ON ns_row.oid = proc_row.pronamespace
      WHERE ns_row.nspname IN ('public', 'internal_guard')
        AND proc_row.prosecdef = true
    LOOP
      EXECUTE format('ALTER FUNCTION %s OWNER TO postgres', r_fn.fn_sig);
    END LOOP;
  END IF;

  REVOKE ALL ON FUNCTION public.current_brazil_date() FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.lookup_booking_by_tourist_token(TEXT, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.cancel_booking_by_tourist_token(TEXT, TEXT, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.backfill_and_verify_booking_lineage() FROM PUBLIC;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE CREATE ON SCHEMA public FROM anon;
    REVOKE ALL ON TABLE internal_guard.booking_lookup_rate_limits FROM anon;
    REVOKE ALL ON FUNCTION public.backfill_and_verify_booking_lineage() FROM anon;
    GRANT EXECUTE ON FUNCTION public.current_brazil_date() TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    GRANT EXECUTE ON FUNCTION public.lookup_booking_by_tourist_token(TEXT, TEXT) TO anon;
    GRANT EXECUTE ON FUNCTION public.cancel_booking_by_tourist_token(TEXT, TEXT, TEXT) TO anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE CREATE ON SCHEMA public FROM authenticated;
    REVOKE ALL ON TABLE internal_guard.booking_lookup_rate_limits FROM authenticated;
    REVOKE ALL ON FUNCTION public.backfill_and_verify_booking_lineage() FROM authenticated;
    GRANT EXECUTE ON FUNCTION public.current_brazil_date() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.lookup_booking_by_tourist_token(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.cancel_booking_by_tourist_token(TEXT, TEXT, TEXT) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    REVOKE ALL ON ALL TABLES IN SCHEMA internal_guard FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.compute_lineage_mac(TEXT, TEXT, SMALLINT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.verify_lineage_mac(TEXT, TEXT, TEXT, SMALLINT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.require_active_hmac_secret() FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle() FROM service_role;
    GRANT EXECUTE ON FUNCTION public.current_brazil_date() TO service_role;
    GRANT EXECUTE ON FUNCTION public.lookup_booking_by_tourist_token(TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.cancel_booking_by_tourist_token(TEXT, TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.backfill_and_verify_booking_lineage() TO service_role;
  END IF;
END
$$;

COMMIT;
