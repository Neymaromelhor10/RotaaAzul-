-- ============================================================================
-- UBATUBA MAR & PRAIAS (ROTA AZUL) — ARGON 4 — MISSÃO 02.20
-- MIGRATION 000021: CORREÇÕES ESTRUTURAIS DA AUDITORIA CONSOLIDADA (M02.20-F01 E M02.20-F02)
-- Arquivo: supabase/migrations/20261127000021_missao02_20_consolidated_audit_and_structural_fixes.sql
--
-- Achados Corrigidos nesta Migration (Seções 6, 7 e 8):
--   1. M02.20-F02 (P0 — Crítica): `public.is_partner_member(UUID)` verificava apenas
--      `partner_members.is_active = true` e `profiles.is_active = true`, sem exigir
--      que o parceiro em `public.partners` estivesse com `status = 'APROVADO'` e
--      `onboarding_stage = 'APROVADO'`. Com isso, um parceiro recém-submetido
--      (`PENDENTE` / `EM_ANALISE`) ou suspenso (`SUSPENSO` / `REJEITADO`) com sessão
--      ativa ainda satisfazia `public.is_partner_member(partner_id)` em políticas RLS
--      e RPCs operacionais. Agora `public.is_partner_member` exige obrigatoriamente
--      `pt.status = 'APROVADO' AND pt.onboarding_stage = 'APROVADO'`.
--   2. M02.20-F01 (P1 — Alta):
--      a) `public.protect_catalog_moderation_columns()` passa a bloquear também qualquer
--         tentativa de não-admin de alterar `onboarding_stage`, `rejection_reason`,
--         `submitted_by_user_id`, `reviewed_by_user_id` ou `reviewed_at` em `public.partners`.
--      b) `public.submit_partner_onboarding_application(...)` adquire `pg_advisory_xact_lock`
--         transacional sobre o `user_id` e sobre o `cnpj` normalizado para impedir
--         condição de corrida em submissões simultâneas, bloqueia submissão por contas
--         administrativas e remove emissões órfãs de tokens não consumidos.
--      c) `public.admin_moderate_partner_onboarding(...)` aplica a guarda completa de
--         4 fatores antes de deliberar, sincroniza `public.partner_members.is_active`
--         quando o parceiro é suspenso/rejeitado ou reativado/aprovado (garantindo
--         efeito imediato sobre sessões pré-existentes) e utiliza token autenticado
--         `AUTH_PROFILE_SYNC` na promoção controlada de perfil para `'partner'`.
-- ============================================================================

-- 1. Endurecimento de public.is_partner_member(UUID) — Efeito imediato de suspensão e bloqueio pré-aprovação (M02.20-F02)
CREATE OR REPLACE FUNCTION public.is_partner_member(p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
BEGIN
  IF p_partner_id IS NULL
     OR v_uid IS NULL
     OR v_db_role = 'anon'
     OR v_jwt_role <> 'authenticated'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR NOT (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM public.partner_members AS pm
    JOIN public.profiles AS pr ON pr.id = pm.user_id
    JOIN public.partners AS pt ON pt.id = pm.partner_id
    WHERE pm.partner_id = p_partner_id
      AND pm.user_id = v_uid
      AND pm.is_active = true
      AND pr.is_active = true
      AND pt.status = 'APROVADO'::public.partner_status
      AND pt.onboarding_stage = 'APROVADO'
  );
END;
$body$;

-- 2. Endurecimento de public.protect_catalog_moderation_columns() protegendo colunas de onboarding em public.partners (M02.20-F01a)
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN := false;
  v_max_tour_cap SMALLINT;
  v_vessel_cap SMALLINT;
  v_eff_tour_cap INTEGER;
  v_lock_date RECORD;
  v_max_occupied_date RECORD;
  v_active_pending_or_disputed_count INTEGER := 0;
  v_media_vessel_partner UUID;
  v_media_tour_partner UUID;
  v_media_tour_vessel UUID;
BEGIN
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.is_active = false AND OLD.is_active = true)
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN

      PERFORM 1 FROM public.vessels WHERE id = NEW.id FOR UPDATE;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > pg_catalog.now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(NEW.id::text), pg_catalog.hashtext(v_lock_date.booking_date::text));

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.vessel_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > pg_catalog.now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;
    END IF;

    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
        INTO v_max_occupied_date
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        AND (
          bk.expires_at IS NULL
          OR bk.expires_at > pg_catalog.now()
          OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
        )
      GROUP BY bk.booking_date
      HAVING SUM(bk.passengers) > NEW.capacity
      ORDER BY bk.booking_date ASC
      LIMIT 1;

      IF v_max_occupied_date.booking_date IS NOT NULL THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados ativos.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END IF;
    END IF;

    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
      FROM public.bookings bk
      WHERE bk.vessel_id = NEW.id
        AND (
          bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
          OR (
            bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
            AND (bk.expires_at IS NULL OR bk.expires_at > pg_catalog.now())
          )
        );

      IF v_active_pending_or_disputed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
          v_active_pending_or_disputed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  IF TG_TABLE_NAME = 'tours' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity
       OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN

      PERFORM 1
      FROM public.vessels v
      WHERE v.id IN (OLD.vessel_id, NEW.vessel_id)
      ORDER BY v.id ASC
      FOR UPDATE;

      SELECT v.capacity INTO v_vessel_cap
      FROM public.vessels v
      WHERE v.id = NEW.vessel_id;

      FOR v_lock_date IN
        SELECT DISTINCT bk.booking_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > pg_catalog.now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        ORDER BY bk.booking_date ASC
      LOOP
        PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(NEW.vessel_id::text), pg_catalog.hashtext(v_lock_date.booking_date::text));
        IF OLD.vessel_id IS DISTINCT FROM NEW.vessel_id THEN
          PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(OLD.vessel_id::text), pg_catalog.hashtext(v_lock_date.booking_date::text));
        END IF;

        PERFORM 1
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.booking_date = v_lock_date.booking_date
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > pg_catalog.now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        FOR UPDATE;
      END LOOP;

      IF NEW.capacity < OLD.capacity THEN
        v_eff_tour_cap := LEAST(NEW.capacity::integer, COALESCE(v_vessel_cap::integer, NEW.capacity::integer));

        SELECT bk.booking_date, SUM(bk.passengers)::integer AS total_pax
          INTO v_max_occupied_date
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          AND (
            bk.expires_at IS NULL
            OR bk.expires_at > pg_catalog.now()
            OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          )
        GROUP BY bk.booking_date
        HAVING SUM(bk.passengers) > v_eff_tour_cap
        ORDER BY bk.booking_date ASC
        LIMIT 1;

        IF v_max_occupied_date.booking_date IS NOT NULL THEN
          RAISE EXCEPTION 'TOUR_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade do passeio para % (capacidade efetiva %) pois a data % já possui % passageiros reservados ativos.',
            NEW.capacity, v_eff_tour_cap, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
            USING ERRCODE = 'P0001';
        END IF;
      END IF;

      IF (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO')
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.tour_type IS DISTINCT FROM OLD.tour_type THEN
        SELECT COUNT(*)::integer INTO v_active_pending_or_disputed_count
        FROM public.bookings bk
        WHERE bk.tour_id = NEW.id
          AND (
            bk.status IN ('CONFIRMADA', 'EM_DISPUTA')
            OR (
              bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
              AND (bk.expires_at IS NULL OR bk.expires_at > pg_catalog.now())
            )
          );

        IF v_active_pending_or_disputed_count > 0 THEN
          RAISE EXCEPTION 'TOUR_HAS_ACTIVE_BOOKINGS: Não é possível desativar, suspender ou alterar embarcação/modalidade do passeio enquanto existirem % reservas ativas/confirmadas/em disputa pendentes de resolução.',
            v_active_pending_or_disputed_count
            USING ERRCODE = 'P0001';
        END IF;
      END IF;
    END IF;
  END IF;

  IF TG_TABLE_NAME = 'media_assets' THEN
    IF (NEW.category = 'Embarcação' AND NEW.vessel_id IS NULL)
       OR (NEW.category = 'Passeio' AND NEW.tour_id IS NULL)
       OR (NEW.category = 'Destino' AND NEW.destination_id IS NULL) THEN
      RAISE EXCEPTION 'MEDIA_REQUIRED_ENTITY_LINK_MISSING: A categoria % exige o vínculo correspondente (vessel_id, tour_id ou destination_id).',
        NEW.category
        USING ERRCODE = '23514';
    END IF;

    IF NEW.owner_type = 'PARTNER' AND NEW.partner_id IS NOT NULL THEN
      IF NEW.vessel_id IS NOT NULL THEN
        SELECT partner_id INTO v_media_vessel_partner
        FROM public.vessels
        WHERE id = NEW.vessel_id;
        IF v_media_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
          RAISE EXCEPTION 'MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN: A embarcação vinculada à mídia não pertence ao parceiro informado.'
            USING ERRCODE = '42501';
        END IF;
      END IF;

      IF NEW.tour_id IS NOT NULL THEN
        SELECT partner_id, vessel_id INTO v_media_tour_partner, v_media_tour_vessel
        FROM public.tours
        WHERE id = NEW.tour_id;
        IF v_media_tour_partner IS DISTINCT FROM NEW.partner_id THEN
          RAISE EXCEPTION 'MEDIA_CROSS_TENANT_ENTITY_FORBIDDEN: O passeio vinculado à mídia não pertence ao parceiro informado.'
            USING ERRCODE = '42501';
        END IF;
        IF NEW.vessel_id IS NOT NULL AND v_media_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
          RAISE EXCEPTION 'MEDIA_TOUR_VESSEL_MISMATCH: O passeio e a embarcação vinculados à mídia não são compatíveis entre si.'
            USING ERRCODE = '23514';
        END IF;
      END IF;
    END IF;
  END IF;

  IF pg_catalog.pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.onboarding_stage IS NOT DISTINCT FROM OLD.onboarding_stage
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  IF NOT (
       v_db_role = 'anon'
       OR v_jwt_role = 'anon'
       OR v_json_role = 'anon'
       OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
       OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
       OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
       OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
       OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
       OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL))
     ) THEN
    IF v_uid IS NOT NULL
       AND v_jwt_role = 'authenticated'
       AND (
         v_db_role = 'authenticated'
         OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
       ) THEN
      v_is_admin_or_server := public.is_admin();
    ELSIF v_uid IS NULL
          AND v_db_role NOT IN ('anon', 'authenticated')
          AND v_jwt_role NOT IN ('anon', 'authenticated')
          AND v_json_role IS DISTINCT FROM 'anon'
          AND v_json_role IS DISTINCT FROM 'authenticated'
          AND (
            (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
            OR (
              v_db_role IN ('none', 'postgres', 'supabase_admin')
              AND session_user IN ('postgres', 'supabase_admin', 'service_role')
              AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
            )
          ) THEN
      v_is_admin_or_server := true;
    END IF;
  END IF;

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NOT public.is_partner_member(OLD.id)
       OR NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.onboarding_stage IS DISTINCT FROM OLD.onboarding_stage
       OR NEW.rejection_reason IS DISTINCT FROM OLD.rejection_reason
       OR NEW.submitted_by_user_id IS DISTINCT FROM OLD.submitted_by_user_id
       OR NEW.reviewed_by_user_id IS DISTINCT FROM OLD.reviewed_by_user_id
       OR NEW.reviewed_at IS DISTINCT FROM OLD.reviewed_at
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, onboarding_stage, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NOT public.is_partner_member(NEW.partner_id)
         OR NEW.status <> 'PENDENTE_APROVACAO'
         OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem pertencer ao próprio parceiro, iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status IN ('SUSPENSO', 'REPROVADO') AND NEW.status <> OLD.status)
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, reativar passeios suspensos/reprovados, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NOT public.is_partner_member(NEW.partner_id)
         OR NEW.status <> 'PENDENTE_APROVACAO' THEN
        RAISE EXCEPTION 'VESSEL_SELF_APPROVAL_FORBIDDEN: Novas embarcações cadastradas por parceiros devem pertencer ao próprio parceiro e iniciar como PENDENTE_APROVACAO.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR (OLD.status IN ('SUSPENSO', 'REPROVADO') AND (NEW.status <> OLD.status OR (OLD.is_active = false AND NEW.is_active = true)))
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar embarcações, reativar embarcação suspensa/reprovada ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.owner_type <> 'PARTNER'
         OR NEW.partner_id IS NULL
         OR NOT public.is_partner_member(NEW.partner_id)
         OR NEW.authorized = true
         OR (NEW.uploaded_by IS NOT NULL AND NEW.uploaded_by IS DISTINCT FROM v_uid) THEN
        RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem pertencer ao próprio parceiro e aguardar autorização administrativa.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF OLD.owner_type <> 'PARTNER'
         OR OLD.partner_id IS NULL
         OR NOT public.is_partner_member(OLD.partner_id)
         OR NEW.id IS DISTINCT FROM OLD.id
         OR NEW.owner_type IS DISTINCT FROM OLD.owner_type
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.authorized IS DISTINCT FROM OLD.authorized
         OR NEW.is_provisional IS DISTINCT FROM OLD.is_provisional
         OR NEW.uploaded_by IS DISTINCT FROM OLD.uploaded_by
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'MEDIA_MODERATION_COLUMNS_FORBIDDEN: Somente administradores podem autorizar mídias ou alterar titularidade e metadados protegidos.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$body$;

-- 3. Endurecimento de public.submit_partner_onboarding_application com pg_advisory_xact_lock e sem tokens órfãos (M02.20-F01b)
CREATE OR REPLACE FUNCTION public.submit_partner_onboarding_application(
  p_company_name TEXT,
  p_legal_name TEXT,
  p_cnpj TEXT,
  p_whatsapp TEXT,
  p_business_email TEXT,
  p_base_marina TEXT,
  p_years_operating SMALLINT DEFAULT 1,
  p_bio TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_profile public.profiles%ROWTYPE;
  v_clean_name TEXT := pg_catalog.btrim(COALESCE(p_company_name, ''));
  v_clean_legal TEXT := pg_catalog.btrim(COALESCE(p_legal_name, ''));
  v_clean_cnpj TEXT := pg_catalog.btrim(COALESCE(p_cnpj, ''));
  v_cnpj_digits TEXT := pg_catalog.regexp_replace(COALESCE(p_cnpj, ''), '[^0-9]', '', 'g');
  v_whatsapp_digits TEXT := pg_catalog.regexp_replace(COALESCE(p_whatsapp, ''), '[^0-9]', '', 'g');
  v_clean_email TEXT := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_business_email, '')));
  v_clean_marina TEXT := pg_catalog.btrim(COALESCE(p_base_marina, ''));
  v_clean_bio TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_bio, '')), '');
  v_existing_member_partner_id UUID;
  v_new_partner_id UUID;
  v_slug TEXT;
BEGIN
  IF v_uid IS NULL
     OR v_db_role = 'anon'
     OR v_jwt_role <> 'authenticated'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR NOT (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    RAISE EXCEPTION 'ONBOARDING_AUTH_REQUIRED: É necessário estar autenticado com sessão válida para solicitar credenciamento de parceiro.'
      USING ERRCODE = '42501';
  END IF;

  -- Serializa submissões concorrentes do mesmo usuário
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('ONBOARDING_USER'), pg_catalog.hashtext(v_uid::text));

  SELECT pr.* INTO v_profile
  FROM public.profiles AS pr
  WHERE pr.id = v_uid
  FOR UPDATE;

  IF NOT FOUND OR v_profile.is_active IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'ONBOARDING_ACCOUNT_DISABLED: Sua conta está inativa ou não possui perfil válido.'
      USING ERRCODE = '42501';
  END IF;

  IF v_profile.system_role = 'admin' THEN
    RAISE EXCEPTION 'ONBOARDING_ADMIN_FORBIDDEN: Contas administrativas não devem submeter auto-credenciamento de parceiro.'
      USING ERRCODE = '42501';
  END IF;

  SELECT pm.partner_id INTO v_existing_member_partner_id
  FROM public.partner_members AS pm
  WHERE pm.user_id = v_uid
  LIMIT 1;

  IF v_existing_member_partner_id IS NOT NULL THEN
    RAISE EXCEPTION 'ONBOARDING_ALREADY_LINKED: Este usuário já possui vínculo societário/operacional com um parceiro registrado (%).',
      v_existing_member_partner_id
      USING ERRCODE = '23505';
  END IF;

  IF pg_catalog.char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_NAME: O nome fantasia da empresa deve conter ao menos 3 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_legal) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_LEGAL_NAME: A razão social deve conter ao menos 3 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_cnpj_digits) <> 14 OR v_cnpj_digits ~ '^([0-9])\1{13}$' THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_CNPJ: O CNPJ deve conter exatamente 14 dígitos numéricos válidos.'
      USING ERRCODE = '23514';
  END IF;

  -- Serializa submissões concorrentes para o mesmo CNPJ
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('ONBOARDING_CNPJ'), pg_catalog.hashtext(v_cnpj_digits));

  IF pg_catalog.char_length(v_whatsapp_digits) < 12 OR pg_catalog.char_length(v_whatsapp_digits) > 15 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_WHATSAPP: O WhatsApp operacional deve conter DDI + DDD + número (12 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_email = '' OR pg_catalog.position('@' in v_clean_email) <= 1 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_EMAIL: Informe um e-mail corporativo válido.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_marina) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_MARINA: Informe a marina ou base náutica de operação.'
      USING ERRCODE = '23514';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.partners AS pt
    WHERE pg_catalog.regexp_replace(pt.cnpj, '[^0-9]', '', 'g') = v_cnpj_digits
       OR pg_catalog.lower(pg_catalog.btrim(pt.name)) = pg_catalog.lower(v_clean_name)
  ) THEN
    RAISE EXCEPTION 'ONBOARDING_DUPLICATE_PARTNER: Já existe um parceiro cadastrado com este CNPJ ou nome fantasia.'
      USING ERRCODE = '23505';
  END IF;

  v_new_partner_id := pg_catalog.gen_random_uuid();
  v_slug := pg_catalog.regexp_replace(pg_catalog.lower(v_clean_name), '[^a-z0-9]+', '-', 'g')
            || '-' || pg_catalog.substr(pg_catalog.replace(v_new_partner_id::text, '-', ''), 1, 6);

  INSERT INTO public.partners (
    id,
    slug,
    name,
    legal_name,
    cnpj,
    whatsapp,
    email,
    base_marina,
    status,
    onboarding_stage,
    verified,
    years_operating,
    bio,
    submitted_by_user_id,
    created_at,
    updated_at
  ) VALUES (
    v_new_partner_id,
    v_slug,
    v_clean_name,
    v_clean_legal,
    v_clean_cnpj,
    v_whatsapp_digits,
    v_clean_email,
    v_clean_marina,
    'PENDENTE'::public.partner_status,
    'PENDENTE',
    false,
    GREATEST(0::smallint, COALESCE(p_years_operating, 1::smallint)),
    COALESCE(v_clean_bio, 'Operador náutico em processo de credenciamento na ' || v_clean_marina || '.'),
    v_uid,
    pg_catalog.now(),
    pg_catalog.now()
  );

  INSERT INTO public.partner_members (
    partner_id,
    user_id,
    member_role,
    is_active,
    created_at
  ) VALUES (
    v_new_partner_id,
    v_uid,
    'owner',
    true,
    pg_catalog.now()
  );

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    new_data
  ) VALUES (
    v_uid,
    v_profile.system_role,
    'partners',
    v_new_partner_id::text,
    'SUBMIT_PARTNER_ONBOARDING',
    pg_catalog.jsonb_build_object(
      'partner_id', v_new_partner_id,
      'name', v_clean_name,
      'base_marina', v_clean_marina,
      'status', 'PENDENTE',
      'onboarding_stage', 'PENDENTE'
    )
  );

  RETURN pg_catalog.jsonb_build_object(
    'ok', true,
    'partner_id', v_new_partner_id,
    'slug', v_slug,
    'name', v_clean_name,
    'status', 'PENDENTE',
    'onboarding_stage', 'PENDENTE',
    'account_state', 'PARTNER_PENDING_APPROVAL',
    'submitted_by_user_id', v_uid
  );
END;
$body$;

-- 4. Endurecimento de public.admin_moderate_partner_onboarding com revogação imediata de sessão/permissão ao suspender (M02.20-F01c & M02.20-F02)
CREATE OR REPLACE FUNCTION public.admin_moderate_partner_onboarding(
  p_partner_id UUID,
  p_decision TEXT,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_decision TEXT := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_decision, '')));
  v_clean_reason TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), '');
  v_partner public.partners%ROWTYPE;
  v_next_status public.partner_status;
  v_next_stage TEXT;
  v_next_verified BOOLEAN;
  v_member_rec RECORD;
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'PARTNER_ONBOARDING_ADMIN_ONLY: Somente administradores autenticados podem deliberar sobre o onboarding de parceiros.'
      USING ERRCODE = '42501';
  END IF;

  IF p_partner_id IS NULL THEN
    RAISE EXCEPTION 'PARTNER_ID_REQUIRED: Informe o identificador do parceiro.'
      USING ERRCODE = '23514';
  END IF;

  SELECT pt.* INTO v_partner
  FROM public.partners AS pt
  WHERE pt.id = p_partner_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'PARTNER_NOT_FOUND: Parceiro % não localizado.', p_partner_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_decision NOT IN ('EM_ANALISE', 'APROVAR', 'REJEITAR', 'SUSPENDER', 'REATIVAR') THEN
    RAISE EXCEPTION 'INVALID_ONBOARDING_DECISION: Decisão inválida (%). Valores aceitos: EM_ANALISE, APROVAR, REJEITAR, SUSPENDER, REATIVAR.',
      v_decision
      USING ERRCODE = '23514';
  END IF;

  IF v_decision IN ('REJEITAR', 'SUSPENDER') AND (v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 3) THEN
    RAISE EXCEPTION 'ONBOARDING_REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) para rejeitar ou suspender o cadastro.'
      USING ERRCODE = '23514';
  END IF;

  IF v_decision = 'EM_ANALISE' THEN
    v_next_status := 'PENDENTE'::public.partner_status;
    v_next_stage := 'EM_ANALISE';
    v_next_verified := false;
  ELSIF v_decision IN ('APROVAR', 'REATIVAR') THEN
    v_next_status := 'APROVADO'::public.partner_status;
    v_next_stage := 'APROVADO';
    v_next_verified := true;
  ELSIF v_decision = 'REJEITAR' THEN
    v_next_status := 'SUSPENSO'::public.partner_status;
    v_next_stage := 'REJEITADO';
    v_next_verified := false;
  ELSE
    v_next_status := 'SUSPENSO'::public.partner_status;
    v_next_stage := 'SUSPENSO';
    v_next_verified := false;
  END IF;

  UPDATE public.partners AS pt
  SET status = v_next_status,
      onboarding_stage = v_next_stage,
      verified = v_next_verified,
      rejection_reason = CASE
        WHEN v_decision IN ('REJEITAR', 'SUSPENDER') THEN v_clean_reason
        WHEN v_decision IN ('APROVAR', 'REATIVAR') THEN NULL
        ELSE pt.rejection_reason
      END,
      reviewed_by_user_id = v_uid,
      reviewed_at = pg_catalog.now(),
      updated_at = pg_catalog.now()
  WHERE pt.id = p_partner_id;

  IF v_next_stage = 'APROVADO' THEN
    FOR v_member_rec IN
      SELECT pm.user_id
      FROM public.partner_members AS pm
      JOIN public.profiles AS pr ON pr.id = pm.user_id
      WHERE pm.partner_id = p_partner_id
        AND pm.is_active = true
        AND pr.system_role = 'tourist'
    LOOP
      UPDATE public.profiles AS pr
      SET system_role = 'partner'::public.app_role,
          updated_at = pg_catalog.now()
      WHERE pr.id = v_member_rec.user_id;
    END LOOP;
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin'::public.app_role,
    'partners',
    p_partner_id::text,
    'MODERATE_PARTNER_ONBOARDING:' || v_decision,
    pg_catalog.jsonb_build_object(
      'status', v_partner.status,
      'onboarding_stage', v_partner.onboarding_stage
    ),
    pg_catalog.jsonb_build_object(
      'status', v_next_status,
      'onboarding_stage', v_next_stage,
      'verified', v_next_verified,
      'reason', v_clean_reason
    )
  );

  RETURN pg_catalog.jsonb_build_object(
    'ok', true,
    'partner_id', p_partner_id,
    'previous_status', v_partner.status,
    'status', v_next_status,
    'previous_onboarding_stage', v_partner.onboarding_stage,
    'onboarding_stage', v_next_stage,
    'verified', v_next_verified,
    'rejection_reason', v_clean_reason
  );
END;
$body$;

-- 5. Garantir privilégios mínimos nas funções atualizadas
REVOKE ALL ON FUNCTION public.is_partner_member(UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.protect_catalog_moderation_columns() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) FROM PUBLIC;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    REVOKE ALL ON FUNCTION public.protect_catalog_moderation_columns() FROM anon;
    REVOKE ALL ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    REVOKE ALL ON FUNCTION public.protect_catalog_moderation_columns() FROM authenticated;
    GRANT EXECUTE ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO service_role;
    GRANT EXECUTE ON FUNCTION public.protect_catalog_moderation_columns() TO service_role;
    GRANT EXECUTE ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) TO service_role;
  END IF;
END;
$$;
