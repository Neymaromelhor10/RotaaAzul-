-- ============================================================================
-- MIGRATION 0002: FUNÇÕES DE SEGURANÇA, RLS MULTI-TENANT E RPCS TRANSACIONAIS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND system_role = 'admin' AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_partner_member(p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.partner_members pm
    JOIN public.profiles pr ON pr.id = pm.user_id
    WHERE pm.partner_id = p_partner_id
      AND pm.user_id = auth.uid()
      AND pm.is_active = true
      AND pr.is_active = true
  );
$$;

-- Habilita RLS em todas as tabelas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itineraries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tour_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.availability_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Políticas Principais
CREATE POLICY "profiles_self_or_admin" ON public.profiles
  FOR SELECT USING (id = auth.uid() OR public.is_admin());

CREATE POLICY "partners_public_or_member_or_admin" ON public.partners
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(id) OR public.is_admin());

CREATE POLICY "destinations_public_read" ON public.destinations
  FOR SELECT USING (is_published = true OR public.is_admin());

CREATE POLICY "vessels_public_or_owner" ON public.vessels
  FOR SELECT USING ((status = 'APROVADO' AND is_active = true) OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "vessels_partner_write" ON public.vessels
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_public_or_owner" ON public.tours
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_partner_insert" ON public.tours
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_isolated_read" ON public.commission_rules
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_admin_only_write" ON public.commission_rules
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "bookings_isolated_read" ON public.bookings
  FOR SELECT USING (tourist_user_id = auth.uid() OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "ledger_isolated_read" ON public.commission_ledger
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "audit_logs_admin_only" ON public.audit_logs
  FOR SELECT USING (public.is_admin());
