-- ============================================================================
-- MIGRATION 0013: MISSÃO 02.6 — CORREÇÃO DA IDEMPOTÊNCIA PÓS-CANCELAMENTO E
-- PÓS-EXPIRAÇÃO COM LINHAGEM DETERMINÍSTICA PERSISTENTE (F01 & F02)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations históricas 000001 a 000012 preservadas byte a byte.
--
-- Reprodução e Causa Raiz (Achado M02.6-F01):
--   Na migration 000012 (linhas 695–701), quando uma reserva anterior criada com
--   a chave original `k1` estava CANCELADA, RECUSADA ou EXPIRADA, a função
--   `public.create_booking_request()` derivava uma nova chave usando:
--     `left(md5(v_computed_idem_key || ':' || clock_timestamp()::text) || md5(gen_random_uuid()::text), 64)`
--   Esse sufixo não era determinístico e rompia o vínculo persistente entre a
--   chave original `k1` e a nova reserva criada na Etapa 4:
--     - A nova reserva recebia um hash aleatório sem relação pesquisável com `k1`;
--     - Em caso de timeout/perda de resposta após o commit da Etapa 4 e reenvio
--       da mesma requisição com `k1` (Etapa 6), a busca por `idempotency_key`
--       encontrava apenas a reserva antiga cancelada (`k1`), e não a reserva
--       ativa recriada na Etapa 4, ou gerava nova chave aleatória a cada tentativa
--       se a busca por telefone não coincidisse.
--
-- Estratégia Transacional Implementada nesta Migration 000013:
--   1. Cria o helper determinístico `public.derive_idempotency_lineage_key(p_root_key TEXT, p_generation INTEGER)`:
--      - Para `p_generation <= 0`: retorna a própria chave raiz canônica `p_root_key` (`k1`).
--      - Para `p_generation >= 1`: retorna a chave determinística de 59 caracteres:
--        `'idg-' || left(md5(p_root_key), 24) || '-g' || lpad(p_generation::text, 4, '0') || '-' || left(md5(p_root_key || ':gen:' || p_generation::text), 24)`
--      - Toda reserva derivada a partir de `k1` compartilha o prefixo determinístico
--        persistente `'idg-' || left(md5(k1), 24) || '-g'`, mantendo vínculo 1:N
--        rastreável entre a chave original `k1` e todas as gerações (`g0001`, `g0002`, ...)
--        sem violar a constraint física `idempotency_key VARCHAR(64) NOT NULL UNIQUE`
--        de `public.bookings`.
--   2. Em `public.create_booking_request()`:
--      - Normaliza a entrada (`lower` + remoção de espaços/caracteres de controle nas bordas).
--      - Rejeita prefixos reservados `'lgpd-%'` e qualquer chave `'idg-%'` forjada que
--        não corresponda a uma linhagem existente no banco (`INVALID_IDEMPOTENCY_KEY`).
--      - Se o cliente reenviar tanto a chave original `k1` quanto a própria chave
--        derivada `idg-...` retornada na Etapa 4, resolve o prefixo de linhagem
--        canônico `v_lineage_prefix := 'idg-' || v_root_hash24 || '-g'`.
--      - Sob lock pessimista da embarcação (`SELECT ... FROM public.vessels FOR UPDATE`)
--        e `pg_advisory_xact_lock(hashtext(vessel_id), hashtext(booking_date))`:
--        a) Trava (`FOR UPDATE`) e valida TODAS as reservas pertencentes à linhagem
--           de `k1` (`lower(b.idempotency_key) = v_root_idem_key OR lower(b.idempotency_key) LIKE v_lineage_prefix || '%'`).
--           Se qualquer registro da linhagem pertencer a outro titular, outro passeio
--           ou outra data (mesmo cancelado ou expirado), aborta imediatamente com
--           `IDEMPOTENCY_KEY_CONFLICT` (`23505`).
--        b) Busca reserva ativa existente na linhagem de `k1` (ou para o mesmo
--           `tour_id + booking_date + phone_digits`). Se existir reserva ativa
--           (como a reserva criada na Etapa 4 antes do timeout!), reconhece-a
--           imediatamente e retorna `idempotent_replay = true` com os mesmos IDs,
--           valores financeiros e quantidade de passageiros, sem criar duplicata
--           e sem consumir vagas duas vezes.
--        c) Somente quando NÃO existe nenhuma reserva ativa na linhagem (1ª chamada
--           ou após cancelamento/expiração de todas as anteriores da linhagem),
--           calcula `v_inactive_lineage_count` (quantidade de reservas inativas na
--           linhagem de `k1`) e deriva deterministicamente a chave da geração
--           `v_inactive_lineage_count` via `public.derive_idempotency_lineage_key(v_root_idem_key, v_inactive_lineage_count)`.
-- ============================================================================

CREATE OR REPLACE FUNCTION public.derive_idempotency_lineage_key(
  p_root_key TEXT,
  p_generation INTEGER
)
RETURNS VARCHAR(64)
LANGUAGE sql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $$
  SELECT CASE
    WHEN COALESCE(p_generation, 0) <= 0 THEN
      left(lower(btrim(COALESCE(p_root_key, ''))), 64)::varchar(64)
    ELSE
      (
        'idg-'
        || left(md5(lower(btrim(COALESCE(p_root_key, '')))), 24)
        || '-g'
        || lpad(LEAST(GREATEST(p_generation, 1), 9999)::text, 4, '0')
        || '-'
        || left(md5(lower(btrim(COALESCE(p_root_key, ''))) || ':gen:' || LEAST(GREATEST(p_generation, 1), 9999)::text), 24)
      )::varchar(64)
  END;
$$;

CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_key_match RECORD;
  v_key_same_owner BOOLEAN := false;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_existing_same_owner BOOLEAN := false;
  v_inactive_lineage_count INTEGER := 0;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_root_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_lineage_prefix TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_raw_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_uid UUID := NULL;
BEGIN
  -- Guarda de 4 fatores para validação de identidade JWT
  IF (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_raw_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_raw_uid::text <> v_json_sub) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_CONTEXT: Conflito de identidade entre claims JWT GUC e JSON.'
      USING ERRCODE = '42501';
  END IF;

  IF v_raw_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     )
     AND EXISTS (SELECT 1 FROM public.profiles WHERE id = v_raw_uid AND is_active = true) THEN
    v_uid := v_raw_uid;
  END IF;

  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));

  v_clean_idem_input := lower(
    regexp_replace(
      COALESCE(p_idempotency_key, ''),
      '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$',
      '',
      'g'
    )
  );

  IF v_clean_idem_input <> '' THEN
    IF v_clean_idem_input LIKE 'lgpd-%' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "lgpd-" é reservado exclusivamente para chaves pseudonimizadas pela rotina de conformidade LGPD.'
        USING ERRCODE = '23514';
    END IF;

    IF char_length(v_clean_idem_input) < 8
       OR char_length(v_clean_idem_input) > 64
       OR v_clean_idem_input !~ '^[a-z0-9._:-]+$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: A chave de idempotência deve conter entre 8 e 64 caracteres alfanuméricos (a-z, 0-9, ., _, :, -) sem espaços internos.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  -- Resolução determinística da chave raiz (`v_root_idem_key`) e do prefixo de linhagem (`v_lineage_prefix`)
  IF v_clean_idem_input LIKE 'idg-%' THEN
    IF v_clean_idem_input !~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$'
       OR NOT EXISTS (SELECT 1 FROM public.bookings b WHERE lower(b.idempotency_key) = v_clean_idem_input) THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "idg-" é reservado para chaves derivadas de linhagem de idempotência.'
        USING ERRCODE = '23514';
    END IF;
    v_root_idem_key := v_clean_idem_input;
    v_root_hash24 := substring(v_clean_idem_input from 5 for 24);
    v_lineage_prefix := 'idg-' || v_root_hash24 || '-g';
  ELSE
    v_root_idem_key := left(
      COALESCE(
        NULLIF(v_clean_idem_input, ''),
        md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
        || md5(v_phone_digits || ':' || v_tour.id::text)
      ),
      64
    );
    v_root_hash24 := left(md5(v_root_idem_key), 24);
    v_lineage_prefix := 'idg-' || v_root_hash24 || '-g';
  END IF;

  -- 1) Verifica e trava (FOR UPDATE) TODAS as reservas pertencentes à linhagem da chave informada
  --    (tanto a chave raiz `k1` quanto todas as gerações derivadas `idg-<hash24>-gXXXX-<hash24>`).
  --    Qualquer divergência de titular, passeio ou data em qualquer geração (ativa ou inativa) é bloqueada.
  FOR v_key_match IN
    SELECT b.*
    FROM public.bookings b
    WHERE lower(b.idempotency_key) = v_root_idem_key
       OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%')
    ORDER BY b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    v_key_same_owner := (
      (v_key_match.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_key_match.tourist_user_id OR public.is_admin())
      AND regexp_replace(v_key_match.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND lower(trim(v_key_match.customer_email)) = v_clean_email
      AND v_key_match.tour_id = v_tour.id
      AND v_key_match.booking_date = p_booking_date
    );

    IF NOT v_key_same_owner THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: A chave de idempotência informada já pertence a outro titular, outro passeio ou outra data.'
        USING ERRCODE = '23505';
    END IF;
  END LOOP;

  -- 2) Busca reserva existente na linhagem de `k1` (priorizando reserva ativa criada na Etapa 4)
  --    ou para o mesmo (tour_id, booking_date, telefone)
  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE lower(b.idempotency_key) = v_root_idem_key
     OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%')
     OR (
       b.tour_id = v_tour.id
       AND b.booking_date = p_booking_date
       AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
     )
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.created_at DESC,
    b.id DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );

    v_existing_same_owner := (
      (v_existing.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_existing.tourist_user_id OR public.is_admin())
      AND regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND lower(trim(v_existing.customer_email)) = v_clean_email
      AND v_existing.tour_id = v_tour.id
      AND v_existing.booking_date = p_booking_date
    );
  END IF;

  IF v_existing.id IS NOT NULL AND NOT v_existing_same_owner THEN
    RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação conflitante ou a chave de idempotência pertence a outro titular/passeio/data.'
      USING ERRCODE = '23505';
  END IF;

  -- Se já existe reserva ATIVA na linhagem de `k1` (inclusive uma reserva criada na Etapa 4 após cancelamento/expiração anterior!),
  -- retorna replay idempotente sem duplicar reserva e sem consumir vagas novamente.
  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'original_idempotency_key', v_root_idem_key,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  -- 3) Não há reserva ativa na linhagem: conta quantas reservas inativas (canceladas/recusadas/expiradas)
  --    já existem na linhagem de `v_root_idem_key` e deriva deterministicamente a chave da nova geração
  SELECT COUNT(*)::integer
    INTO v_inactive_lineage_count
  FROM public.bookings b
  WHERE lower(b.idempotency_key) = v_root_idem_key
     OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%');

  v_computed_idem_key := public.derive_idempotency_lineage_key(v_root_idem_key, v_inactive_lineage_count);

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(trim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'original_idempotency_key', v_root_idem_key,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- Consolidação de privilégios pós-migration 000013
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.normalize_lgpd_text(TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.sanitize_lgpd_audit_jsonb(JSONB, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, UUID) FROM anon;
    REVOKE ALL ON FUNCTION public.derive_idempotency_lineage_key(TEXT, INTEGER) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;
    REVOKE ALL ON FUNCTION public.normalize_lgpd_text(TEXT) FROM authenticated;
    REVOKE ALL ON FUNCTION public.sanitize_lgpd_audit_jsonb(JSONB, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, UUID) FROM authenticated;
    REVOKE ALL ON FUNCTION public.derive_idempotency_lineage_key(TEXT, INTEGER) FROM authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT ALL ON SCHEMA public TO service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role;
  END IF;
END;
$$;
