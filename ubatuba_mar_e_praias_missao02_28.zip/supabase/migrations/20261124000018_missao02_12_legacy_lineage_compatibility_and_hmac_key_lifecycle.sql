-- ============================================================================
-- MIGRATION 0018: MISSÃO 02.12 — CORREÇÃO CIRÚRGICA DOS ACHADOS FORENSES
-- M02.11-F01 A M02.11-F05: COMPATIBILIDADE DE LEITURA COM LINHAGENS LEGADAS,
-- RASTREAMENTO DE VERSÃO POR ARTEFATO HMAC, GATILHO DE CONSTRIÇÃO DIFERIDO
-- (DEFERRABLE INITIALLY DEFERRED), ENDURECIMENTO DE SEGREDOS MANUAIS,
-- VERIFICAÇÃO O(1) POR VERSÃO E PRIVILÉGIOS MÍNIMOS DE service_role
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations históricas 000001 a 000017 preservadas byte a byte.
--
-- Achados Comprovados na Auditoria Forense 02.11 e Corrigidos Nesta Migration:
--
--   1. M02.11-F01 (ALTO / P1 — Seção 5: Compatibilidade com Linhagens Legadas MD5
--      das Migrations 000013 a 000016):
--      - As migrations 000013 a 000016 persistiram identificadores de linhagem
--        baseados em `left(md5(k1), 24)` (`<root24>`) e
--        `left(md5(k1 || ':gen:' || generation), 24)` (`<gen24>`), além de
--        `<scope20> = left(md5(scope_payload), 20)` na 000015 e MAC chaveado v1
--        na 000016.
--      - Correção implementada:
--        * A resolução legada é estritamente restrita à leitura de registros
--          históricos efetivamente existentes em `public.bookings` (onde a versão
--          de chave do artefato é `NULL`) e vinculada ao contexto de titularidade,
--          passeio e data da reserva.
--        * `internal_guard.verify_lineage_mac()` NUNCA aceita MD5 sem segredo como
--          MAC, assinatura criptográfica ou prova autônoma de autenticidade.
--        * Todas as novas gravações (`create_booking_request`, `admin_anonymize_customer_pii`,
--          `derive_idempotency_lineage_key` e `backfill_and_verify_booking_lineage`)
--          utilizam exclusivamente `HMAC-SHA-256` (RFC 2104 / FIPS 198-1 via `pgcrypto`).
--        * `public.backfill_and_verify_booking_lineage()` migra registros legados
--          para `HMAC-SHA-256` quando há material suficiente para reconstruir e
--          validar a linhagem, registrando a versão HMAC em cada artefato, e
--          preserva intactos (sem fabricar associação fictícia) registros da
--          000014 totalmente anonimizados sem material de reconstrução.
--
--   2. M02.11-F02 (ALTO / P1 — Seção 6: Ciclo de Vida, Aposentadoria por Versão,
--      Invariante Transacional de Chave Ativa e Recuperação de Chaves HMAC):
--      - Mapeamento explícito dos artefatos de linhagem em `public.bookings`:
--        * `hmac_key_version SMALLINT`: versão ativa da última operação HMAC da linha;
--        * `lineage_root_key_version SMALLINT`: versão que assinou `<root24>` (`LINEAGE_ROOT_V1`);
--        * `lineage_idem_key_version SMALLINT`: versão que assinou `idempotency_key`
--          (`LINEAGE_GEN_V1`, `LGPD_IDEM_AUTH` ou `NATURAL_BOOKING_KEY`);
--        * `lineage_scope_key_version SMALLINT`: versão que assinou `<scope20>`
--          em `original_idempotency_key` (`LGPD_OWNER_SCOPE`).
--      - `internal_guard.enforce_lineage_hmac_key_lifecycle()` verifica dependências
--        reais filtradas por `OLD.key_version`, impedindo desativar ou excluir
--        versão que possua dependentes e permitindo aposentar versão sem dependentes.
--      - `CREATE CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit`
--        (`DEFERRABLE INITIALLY DEFERRED`) garante que, ao final de toda transação
--        válida, exista exatamente 1 chave com `is_current = true AND is_verify_enabled = true`,
--        permitindo instalação inicial, rotação transacional e restauração, mas
--        bloqueando qualquer `UPDATE ... SET is_current = false` isolado que deixe
--        a tabela sem chave ativa.
--      - Cria `internal_guard.manage_lineage_hmac_key_lifecycle(p_action, p_key_version, p_secret_material)`
--        para aposentadoria (`RETIRE`), reativação (`ENABLE_VERIFY`), restauração
--        autorizada de backup (`RESTORE`) e expurgo seguro (`PURGE_RETIRED`).
--
--   3. M02.11-F03 (MÉDIO / P2 — Seção 7: Validação de Segredos Manuais e
--      Privilégios Mínimos de `service_role`):
--      - Geração automática permanece exclusivamente via `public.gen_random_bytes(32)`
--        (256 bits CSPRNG) em modo fail-closed (`CSPRNG_FAILURE`).
--      - Segredos informados manualmente passam por filtro estrutural endurecido
--        (rejeitando repetições consecutivas `([0-9a-f])\1{7,}`, periodicidade
--        `^([0-9a-f]{1,32})\1+$`, sequências previsíveis como `01234567`,
--        `'0123456789abcdef' || repeat('0', 48)` e baixa diversidade por janela
--        de 16 caracteres), documentando explicitamente que validação sintática
--        não comprova entropia criptográfica formal.
--      - Remove `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role`,
--        revogando de `service_role` a execução direta de `compute_lineage_mac`,
--        `verify_lineage_mac`, `require_active_hmac_secret`, `issue_token`,
--        `consume_token`, `cleanup_tokens`, `enforce_lineage_hmac_key_lifecycle` e
--        `assert_active_lineage_hmac_key_invariant`, e concedendo `EXECUTE` a
--        `service_role` no schema `internal_guard` exclusivamente para
--        `rotate_lineage_hmac_key` e `manage_lineage_hmac_key_lifecycle`.
--
--   4. M02.11-F04 (MÉDIO / P2 — Seção 8: Verificação O(1) por Versão em
--      `verify_lineage_mac` e Precisão Documental do Laço XOR):
--      - `internal_guard.verify_lineage_mac(p_purpose, p_payload, p_expected_mac, p_key_version DEFAULT NULL)`
--        executa resolução direta `O(1)` quando `p_key_version IS NOT NULL`,
--        recorrendo à varredura multi-versão apenas para registros sem versão
--        explícita (`p_key_version IS NULL`).
--      - Documenta com precisão técnica que o laço acumulador XOR em PL/pgSQL
--        evita curto-circuito lógico byte a byte na comparação do tag, mas não
--        oferece garantia formal constant-time em nível de CPU/interpretador.
--
--   5. M02.11-F05 (MÉDIO / P2 — Seção 9: Segurança e Separação de Privilégios em
--      `public.derive_idempotency_lineage_key`):
--      - Converte `public.derive_idempotency_lineage_key(TEXT, INTEGER)` para
--        `SECURITY DEFINER` com `OWNER TO postgres` e
--        `SET search_path = pg_catalog, public, internal_guard, pg_temp`,
--        `REVOKE EXECUTE` de `PUBLIC, anon, authenticated`, `GRANT EXECUTE` apenas
--        a `service_role` e validação rigorosa de contexto de 4 fatores, garantindo
--        seu funcionamento após a revogação de `EXECUTE` direto em
--        `internal_guard.compute_lineage_mac` sem expor oráculo público de MAC.
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1. AUTO-TESTE DE EXTENSÃO pgcrypto, VETORES OFICIAIS RFC 4231 E CSPRNG
-- ----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
DECLARE
  v_tc1 TEXT;
  v_tc2 TEXT;
  v_tc3 TEXT;
  v_tc4 TEXT;
  v_rng BYTEA;
BEGIN
  v_tc1 := pg_catalog.lower(
    pg_catalog.encode(
      public.hmac(
        pg_catalog.convert_to('Hi There', 'UTF8'),
        pg_catalog.decode(pg_catalog.repeat('0b', 20), 'hex'),
        'sha256'::text
      ),
      'hex'
    )
  );
  IF v_tc1 <> 'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7' THEN
    RAISE EXCEPTION 'RFC4231_VECTOR_1_FAILED: Divergência no vetor oficial RFC 4231 Test Case 1 (obtido=%).', v_tc1
      USING ERRCODE = 'P0001';
  END IF;

  v_tc2 := pg_catalog.lower(
    pg_catalog.encode(
      public.hmac(
        pg_catalog.convert_to('what do ya want for nothing?', 'UTF8'),
        pg_catalog.convert_to('Jefe', 'UTF8'),
        'sha256'::text
      ),
      'hex'
    )
  );
  IF v_tc2 <> '5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843' THEN
    RAISE EXCEPTION 'RFC4231_VECTOR_2_FAILED: Divergência no vetor oficial RFC 4231 Test Case 2 (obtido=%).', v_tc2
      USING ERRCODE = 'P0001';
  END IF;

  v_tc3 := pg_catalog.lower(
    pg_catalog.encode(
      public.hmac(
        pg_catalog.decode(pg_catalog.repeat('dd', 50), 'hex'),
        pg_catalog.decode(pg_catalog.repeat('aa', 20), 'hex'),
        'sha256'::text
      ),
      'hex'
    )
  );
  IF v_tc3 <> '773ea91e36800e46854db8ebd09181a72959098b3ef8c122d9635514ced565fe' THEN
    RAISE EXCEPTION 'RFC4231_VECTOR_3_FAILED: Divergência no vetor oficial RFC 4231 Test Case 3 (obtido=%).', v_tc3
      USING ERRCODE = 'P0001';
  END IF;

  v_tc4 := pg_catalog.lower(
    pg_catalog.encode(
      public.hmac(
        pg_catalog.decode(pg_catalog.repeat('cd', 50), 'hex'),
        pg_catalog.decode('0102030405060708090a0b0c0d0e0f10111213141516171819', 'hex'),
        'sha256'::text
      ),
      'hex'
    )
  );
  IF v_tc4 <> '82558a389a443c0ea4cc819899f2083a85f0faa3e578f8077a2e3ff46729665b' THEN
    RAISE EXCEPTION 'RFC4231_VECTOR_4_FAILED: Divergência no vetor oficial RFC 4231 Test Case 4 (obtido=%).', v_tc4
      USING ERRCODE = 'P0001';
  END IF;

  v_rng := public.gen_random_bytes(32);
  IF v_rng IS NULL OR pg_catalog.octet_length(v_rng) <> 32 THEN
    RAISE EXCEPTION 'CSPRNG_SELF_TEST_FAILED: public.gen_random_bytes(32) não retornou 32 bytes.'
      USING ERRCODE = 'P0001';
  END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- 2. RASTREAMENTO EXPLÍCITO DE VERSÃO POR ARTEFATO DE LINHAGEM EM public.bookings
--    (M02.11-F02 & M02.11-F04 — Seções 6 e 8)
--    - hmac_key_version: versão da chave ativa na última operação criptográfica;
--    - lineage_root_key_version: versão da chave que gerou <root24> (LINEAGE_ROOT_V1);
--    - lineage_idem_key_version: versão da chave que gerou o MAC de idempotency_key
--      (LINEAGE_GEN_V1 em idg-..., LGPD_IDEM_AUTH em lgpd-... ou NATURAL_BOOKING_KEY);
--    - lineage_scope_key_version: versão da chave que gerou <scope20> em
--      original_idempotency_key (LGPD_OWNER_SCOPE em lgpd-lin-<root24>-<scope20>).
-- ----------------------------------------------------------------------------
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS hmac_key_version SMALLINT,
  ADD COLUMN IF NOT EXISTS lineage_root_key_version SMALLINT,
  ADD COLUMN IF NOT EXISTS lineage_idem_key_version SMALLINT,
  ADD COLUMN IF NOT EXISTS lineage_scope_key_version SMALLINT;

ALTER TABLE public.bookings
  DROP CONSTRAINT IF EXISTS bookings_hmac_key_version_check,
  DROP CONSTRAINT IF EXISTS bookings_lineage_root_key_version_check,
  DROP CONSTRAINT IF EXISTS bookings_lineage_idem_key_version_check,
  DROP CONSTRAINT IF EXISTS bookings_lineage_scope_key_version_check;

ALTER TABLE public.bookings
  ADD CONSTRAINT bookings_hmac_key_version_check
    CHECK (hmac_key_version IS NULL OR (hmac_key_version >= 1 AND hmac_key_version <= 999)),
  ADD CONSTRAINT bookings_lineage_root_key_version_check
    CHECK (lineage_root_key_version IS NULL OR (lineage_root_key_version >= 1 AND lineage_root_key_version <= 999)),
  ADD CONSTRAINT bookings_lineage_idem_key_version_check
    CHECK (lineage_idem_key_version IS NULL OR (lineage_idem_key_version >= 1 AND lineage_idem_key_version <= 999)),
  ADD CONSTRAINT bookings_lineage_scope_key_version_check
    CHECK (lineage_scope_key_version IS NULL OR (lineage_scope_key_version >= 1 AND lineage_scope_key_version <= 999));

CREATE INDEX IF NOT EXISTS idx_bookings_hmac_key_versions
  ON public.bookings (hmac_key_version, lineage_root_key_version, lineage_idem_key_version, lineage_scope_key_version);

-- ----------------------------------------------------------------------------
-- 3. ENDURECIMENTO DE internal_guard.lineage_hmac_keys, TRIGGER POR VERSÃO E
--    CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED (M02.11-F02 & M02.11-F03)
-- ----------------------------------------------------------------------------
ALTER TABLE internal_guard.lineage_hmac_keys
  DROP CONSTRAINT IF EXISTS chk_lineage_hmac_keys_hex_format,
  DROP CONSTRAINT IF EXISTS chk_lineage_hmac_keys_current_must_verify;

-- Caso a chave v1 histórica gerada na 000016 contenha algum padrão fraco residual,
-- mantemos a validação estrita para todas as chaves e exigimos que qualquer chave
-- ativa (is_current = true) esteja obrigatoriamente habilitada para verificação.
ALTER TABLE internal_guard.lineage_hmac_keys
  ADD CONSTRAINT chk_lineage_hmac_keys_hex_format
    CHECK (
      secret_material ~ '^[0-9a-f]{64,128}$'
      AND (pg_catalog.char_length(secret_material) % 2) = 0
      AND secret_material !~ '([0-9a-f])\1{7,}'
      AND pg_catalog.substr(secret_material, 1, 64) !~ '^([0-9a-f]{1,32})\1+$'
      AND secret_material !~ '(01234567|12345678|23456789|89abcdef|fedcba98|98765432|76543210|a1b2c3d4e5f6)'
    ),
  ADD CONSTRAINT chk_lineage_hmac_keys_current_must_verify
    CHECK (NOT is_current OR is_verify_enabled);

CREATE OR REPLACE FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_remaining_keys INTEGER := 0;
  v_has_dependent_bookings BOOLEAN := false;
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.is_current = true THEN
      RAISE EXCEPTION 'KEY_DELETE_ACTIVE_FORBIDDEN: Não é permitido excluir a versão de chave HMAC atualmente ativa (key_version=%).', OLD.key_version
        USING ERRCODE = '42501';
    END IF;

    SELECT COUNT(*)
      INTO v_remaining_keys
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.key_version <> OLD.key_version;

    IF v_remaining_keys <= 0 THEN
      RAISE EXCEPTION 'KEY_DELETE_LAST_KEY_FORBIDDEN: Proibido excluir todas as chaves de internal_guard.lineage_hmac_keys.'
        USING ERRCODE = '42501';
    END IF;

    -- M02.11-F02: Verifica dependência granular por versão (OLD.key_version) em cada artefato de linhagem,
    -- mantendo fallback fail-closed caso existam registros criptográficos ainda não versionados pelo backfill.
    SELECT EXISTS (
      SELECT 1
      FROM public.bookings b
      WHERE b.hmac_key_version = OLD.key_version
         OR b.lineage_root_key_version = OLD.key_version
         OR b.lineage_idem_key_version = OLD.key_version
         OR b.lineage_scope_key_version = OLD.key_version
         OR (
           b.hmac_key_version IS NULL
           AND b.lineage_root_key_version IS NULL
           AND b.lineage_idem_key_version IS NULL
           AND b.lineage_scope_key_version IS NULL
           AND (
             b.idempotency_key LIKE 'lgpd-%'
             OR b.original_idempotency_key LIKE 'lgpd-lin-%'
             OR b.original_idempotency_key LIKE 'idg-root-%'
             OR b.idempotency_key LIKE 'idg-%'
           )
         )
    ) INTO v_has_dependent_bookings;

    IF v_has_dependent_bookings THEN
      RAISE EXCEPTION 'KEY_DELETE_DEPENDENT_RECORDS_EXIST: Não é permitido excluir a versão histórica (key_version=%) enquanto existirem reservas ou artefatos de linhagem dependentes desta versão.', OLD.key_version
        USING ERRCODE = '42501';
    END IF;

    RETURN OLD;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.key_version IS DISTINCT FROM OLD.key_version
       OR NEW.secret_material IS DISTINCT FROM OLD.secret_material
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'KEY_MATERIAL_IMMUTABLE: O material secreto (secret_material), a versão (key_version) e o timestamp de criação de uma chave HMAC existente são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.is_current = true AND NEW.is_verify_enabled = false THEN
      RAISE EXCEPTION 'ACTIVE_KEY_VERIFY_DISABLED_FORBIDDEN: A chave HMAC ativa (key_version=%) não pode ter is_verify_enabled = false.', NEW.key_version
        USING ERRCODE = '23514';
    END IF;

    IF OLD.is_verify_enabled = true AND NEW.is_verify_enabled = false THEN
      SELECT EXISTS (
        SELECT 1
        FROM public.bookings b
        WHERE b.hmac_key_version = OLD.key_version
           OR b.lineage_root_key_version = OLD.key_version
           OR b.lineage_idem_key_version = OLD.key_version
           OR b.lineage_scope_key_version = OLD.key_version
           OR (
             b.hmac_key_version IS NULL
             AND b.lineage_root_key_version IS NULL
             AND b.lineage_idem_key_version IS NULL
             AND b.lineage_scope_key_version IS NULL
             AND (
               b.idempotency_key LIKE 'lgpd-%'
               OR b.original_idempotency_key LIKE 'lgpd-lin-%'
               OR b.original_idempotency_key LIKE 'idg-root-%'
               OR b.idempotency_key LIKE 'idg-%'
             )
           )
      ) INTO v_has_dependent_bookings;

      IF v_has_dependent_bookings THEN
        RAISE EXCEPTION 'KEY_DISABLE_DEPENDENT_RECORDS_EXIST: Não é permitido desabilitar a verificação da versão (key_version=%) enquanto existirem reservas ou artefatos de linhagem dependentes desta versão.', OLD.key_version
          USING ERRCODE = '42501';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_lineage_hmac_keys_lifecycle ON internal_guard.lineage_hmac_keys;
CREATE TRIGGER trg_protect_lineage_hmac_keys_lifecycle
  BEFORE UPDATE OR DELETE ON internal_guard.lineage_hmac_keys
  FOR EACH ROW
  EXECUTE FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle();

-- M02.11-F02 (Seção 6): Constraint Trigger DEFERRABLE INITIALLY DEFERRED garantindo que,
-- ao final de qualquer transação válida, exista exatamente 1 chave ativa e habilitada
-- (is_current = true AND is_verify_enabled = true), permitindo rotação transacional em 2 passos
-- mas impedindo que um UPDATE isolado deixe o banco com zero chaves ativas.
CREATE OR REPLACE FUNCTION internal_guard.assert_active_lineage_hmac_key_invariant()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_active_enabled_count INTEGER := 0;
  v_current_disabled_count INTEGER := 0;
BEGIN
  SELECT
    COUNT(*) FILTER (WHERE k.is_current = true AND k.is_verify_enabled = true),
    COUNT(*) FILTER (WHERE k.is_current = true AND k.is_verify_enabled = false)
    INTO v_active_enabled_count, v_current_disabled_count
  FROM internal_guard.lineage_hmac_keys k;

  IF v_current_disabled_count > 0 THEN
    RAISE EXCEPTION 'ACTIVE_KEY_VERIFY_DISABLED_FORBIDDEN: A chave HMAC atualmente ativa (is_current = true) deve manter is_verify_enabled = true.'
      USING ERRCODE = '23514';
  END IF;

  IF v_active_enabled_count = 0 THEN
    RAISE EXCEPTION 'NO_ACTIVE_HMAC_KEY_AT_COMMIT: Transação inválida — internal_guard.lineage_hmac_keys não pode terminar sem exatamente uma chave ativa e habilitada (is_current = true AND is_verify_enabled = true).'
      USING ERRCODE = '23514';
  END IF;

  IF v_active_enabled_count > 1 THEN
    RAISE EXCEPTION 'MULTIPLE_ACTIVE_HMAC_KEYS_AT_COMMIT: Transação inválida — mais de uma chave ativa encontrada ao final da transação.'
      USING ERRCODE = '23505';
  END IF;

  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_assert_active_lineage_hmac_key_commit ON internal_guard.lineage_hmac_keys;
CREATE CONSTRAINT TRIGGER trg_assert_active_lineage_hmac_key_commit
  AFTER INSERT OR UPDATE OR DELETE ON internal_guard.lineage_hmac_keys
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW
  EXECUTE FUNCTION internal_guard.assert_active_lineage_hmac_key_invariant();

-- ----------------------------------------------------------------------------
-- 4. FUNÇÕES CRIPTOGRÁFICAS E DE GESTÃO DE CICLO DE VIDA EM internal_guard
--    (M02.11-F02, M02.11-F03 & M02.11-F04 — Seções 6, 7 e 8)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION internal_guard.require_active_hmac_secret()
RETURNS SMALLINT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  v_active_count INTEGER := 0;
  v_ver SMALLINT;
  v_secret TEXT;
  v_distinct_hex INTEGER := 0;
  v_distinct_bytes INTEGER := 0;
  v_w1_distinct INTEGER := 0;
  v_w2_distinct INTEGER := 0;
  v_w3_distinct INTEGER := 0;
  v_w4_distinct INTEGER := 0;
BEGIN
  -- Nota de Arquitetura (Seção 7B): A autorização primária é garantida por REVOKE ALL ON FUNCTION
  -- de PUBLIC, anon, authenticated e service_role. A verificação de PG_CONTEXT abaixo atua apenas
  -- como defesa complementar em profundidade.
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('compute_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('verify_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('rotate_lineage_hmac_key' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('manage_lineage_hmac_key_lifecycle' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('enforce_booking_invariants_and_transitions' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.require_active_hmac_secret não autorizada fora dos fluxos internos.'
      USING ERRCODE = '42501';
  END IF;

  SELECT COUNT(*), MAX(k.key_version), MAX(k.secret_material)
    INTO v_active_count, v_ver, v_secret
  FROM internal_guard.lineage_hmac_keys k
  WHERE k.is_current = true
    AND k.is_verify_enabled = true;

  IF v_active_count = 0 OR v_ver IS NULL OR v_secret IS NULL THEN
    RAISE EXCEPTION 'LINEAGE_MAC_KEY_UNAVAILABLE: Nenhuma chave criptográfica HMAC-SHA-256 ativa encontrada em internal_guard.lineage_hmac_keys.'
      USING ERRCODE = 'P0001';
  END IF;

  IF v_active_count > 1 THEN
    RAISE EXCEPTION 'LINEAGE_MAC_MULTIPLE_ACTIVE_KEYS: Estado inconsistente — mais de uma versão de chave marcada como ativa.'
      USING ERRCODE = '23505';
  END IF;

  IF pg_catalog.char_length(v_secret) < 64
     OR pg_catalog.char_length(v_secret) > 128
     OR (pg_catalog.char_length(v_secret) % 2) <> 0
     OR v_secret !~ '^[0-9a-f]+$' THEN
    RAISE EXCEPTION 'INVALID_HMAC_SECRET_FORMAT: O segredo ativo possui comprimento ou codificação hexadecimal inválida.'
      USING ERRCODE = '23514';
  END IF;

  -- M02.11-F03: Filtro estrutural de sanidade contra repetições em qualquer posição,
  -- padrões periódicos (períodos 1..32) e sequências previsíveis.
  -- Nota técnica: Este filtro bloqueia chaves fracas/previsíveis em entradas manuais,
  -- mas a garantia real de entropia provém exclusivamente de public.gen_random_bytes(32).
  SELECT COUNT(DISTINCT ch) INTO v_distinct_hex
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 64), '') AS ch WHERE ch <> '';

  SELECT COUNT(DISTINCT pg_catalog.substr(v_secret, i * 2 + 1, 2)) INTO v_distinct_bytes
  FROM pg_catalog.generate_series(0, 31) AS g(i);

  SELECT COUNT(DISTINCT ch) INTO v_w1_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w2_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 17, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w3_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 33, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w4_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 49, 16), '') AS ch WHERE ch <> '';

  IF v_distinct_hex < 8
     OR v_distinct_bytes < 10
     OR v_w1_distinct < 5
     OR v_w2_distinct < 5
     OR v_w3_distinct < 5
     OR v_w4_distinct < 5
     OR v_secret ~ '([0-9a-f])\1{7,}'
     OR pg_catalog.substr(v_secret, 1, 64) ~ '^([0-9a-f]{1,32})\1+$'
     OR v_secret ~ '(01234567|12345678|23456789|89abcdef|fedcba98|98765432|76543210|a1b2c3d4e5f6)' THEN
    RAISE EXCEPTION 'WEAK_HMAC_SECRET_REJECTED: O segredo ativo contém padrão repetitivo, periódico, sequencial ou baixa diversidade estrutural.'
      USING ERRCODE = '23514';
  END IF;

  RETURN v_ver;
END;
$$;

CREATE OR REPLACE FUNCTION internal_guard.compute_lineage_mac(
  p_purpose TEXT,
  p_payload TEXT,
  p_key_version SMALLINT DEFAULT NULL
)
RETURNS TEXT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  v_secret TEXT;
  v_ver SMALLINT;
  v_canonical_msg TEXT;
  v_mac_bytes BYTEA;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('verify_lineage_mac' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('derive_idempotency_lineage_key' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.compute_lineage_mac proibida fora dos fluxos internos autorizados.'
      USING ERRCODE = '42501';
  END IF;

  IF p_purpose IS NULL
     OR p_payload IS NULL
     OR p_purpose NOT IN (
       'LGPD_OWNER_SCOPE',
       'LGPD_IDEM_AUTH',
       'NATURAL_BOOKING_KEY',
       'LINEAGE_ROOT_V1',
       'LINEAGE_GEN_V1'
     ) THEN
    RAISE EXCEPTION 'LINEAGE_MAC_INVALID_INPUT: Finalidade (purpose) inválida ou payload nulo para cálculo de HMAC-SHA-256.'
      USING ERRCODE = '23514';
  END IF;

  IF p_key_version IS NOT NULL THEN
    SELECT k.secret_material, k.key_version
      INTO v_secret, v_ver
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.key_version = p_key_version
      AND k.is_verify_enabled = true
    LIMIT 1;
  ELSE
    v_ver := internal_guard.require_active_hmac_secret();
    SELECT k.secret_material
      INTO v_secret
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.key_version = v_ver
      AND k.is_current = true
      AND k.is_verify_enabled = true
    LIMIT 1;
  END IF;

  IF v_secret IS NULL OR v_ver IS NULL THEN
    RAISE EXCEPTION 'LINEAGE_MAC_KEY_UNAVAILABLE: Versão de chave HMAC-SHA-256 solicitada inexistente ou desabilitada.'
      USING ERRCODE = 'P0001';
  END IF;

  IF pg_catalog.char_length(v_secret) < 64
     OR pg_catalog.char_length(v_secret) > 128
     OR (pg_catalog.char_length(v_secret) % 2) <> 0
     OR v_secret !~ '^[0-9a-f]+$' THEN
    RAISE EXCEPTION 'INVALID_HMAC_SECRET_FORMAT: Material secreto com codificação hexadecimal inválida.'
      USING ERRCODE = '23514';
  END IF;

  v_canonical_msg := 'v' || v_ver::text
    || ':' || pg_catalog.char_length(p_purpose)::text || ':' || p_purpose
    || ':' || pg_catalog.char_length(p_payload)::text || ':' || p_payload;

  v_mac_bytes := public.hmac(
    pg_catalog.convert_to(v_canonical_msg, 'UTF8'),
    pg_catalog.decode(v_secret, 'hex'),
    'sha256'::text
  );

  IF v_mac_bytes IS NULL OR pg_catalog.octet_length(v_mac_bytes) <> 32 THEN
    RAISE EXCEPTION 'HMAC_COMPUTATION_FAILURE: Falha na execução de HMAC-SHA-256 via pgcrypto.'
      USING ERRCODE = 'P0001';
  END IF;

  RETURN pg_catalog.lower(pg_catalog.encode(v_mac_bytes, 'hex'));
END;
$$;

-- Remove a assinatura antiga de 3 parâmetros antes de recriar com p_key_version DEFAULT NULL,
-- preservando exatamente 1 sobrecarga no catálogo pg_proc.
DROP FUNCTION IF EXISTS internal_guard.verify_lineage_mac(TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION internal_guard.verify_lineage_mac(
  p_purpose TEXT,
  p_payload TEXT,
  p_expected_mac TEXT,
  p_key_version SMALLINT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), ''), '');
  r_key RECORD;
  v_req_len INTEGER := 0;
  v_cand_mac TEXT;
  v_cand_bytes BYTEA;
  v_exp_bytes BYTEA;
  v_diff INTEGER;
  v_idx INTEGER;
  v_matched BOOLEAN := false;
  v_leg_in1 TEXT;
  v_leg_out1 TEXT;
  v_leg_in2 TEXT;
  v_leg_out2 TEXT;
  v_leg_cand TEXT;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  IF (
       v_db_role IN ('anon', 'authenticated', 'service_role')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('admin_anonymize_customer_pii' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_CRYPTO_ORACLE_CALL: Chamada direta a internal_guard.verify_lineage_mac proibida fora dos fluxos internos autorizados.'
      USING ERRCODE = '42501';
  END IF;

  v_req_len := CASE p_purpose
    WHEN 'LGPD_IDEM_AUTH' THEN 16
    WHEN 'LGPD_OWNER_SCOPE' THEN 20
    WHEN 'LINEAGE_ROOT_V1' THEN 24
    WHEN 'LINEAGE_GEN_V1' THEN 24
    WHEN 'NATURAL_BOOKING_KEY' THEN 64
    ELSE 0
  END;

  IF v_req_len = 0
     OR p_payload IS NULL
     OR p_expected_mac IS NULL
     OR pg_catalog.char_length(p_expected_mac) <> v_req_len
     OR p_expected_mac !~ '^[0-9a-f]+$' THEN
    RETURN false;
  END IF;

  v_exp_bytes := pg_catalog.convert_to(p_expected_mac, 'UTF8');

  -- M02.11-F04 (Seção 8):
  --   - Se p_key_version IS NOT NULL, verifica diretamente (O(1)) apenas a versão indicada
  --     (desde que habilitada em internal_guard.lineage_hmac_keys), evitando percorrer
  --     desnecessariamente todas as versões.
  --   - Se p_key_version IS NULL (registros históricos sem versão explícita), percorre as
  --     versões habilitadas sem retorno antecipado no laço.
  --   - Nota de precisão técnica: A comparação por acumulador XOR (`#`) percorre todos os
  --     bytes do tag sem curto-circuito lógico no laço PL/pgSQL, mas não fornece garantia
  --     formal de tempo constante em nível de CPU ou interpretador PostgreSQL.
  FOR r_key IN
    SELECT k.key_version, k.secret_material
    FROM internal_guard.lineage_hmac_keys k
    WHERE k.is_verify_enabled = true
      AND (p_key_version IS NULL OR k.key_version = p_key_version)
    ORDER BY k.is_current DESC, k.key_version DESC
  LOOP
    v_cand_mac := pg_catalog.left(
      internal_guard.compute_lineage_mac(p_purpose, p_payload, r_key.key_version),
      v_req_len
    );
    v_cand_bytes := pg_catalog.convert_to(v_cand_mac, 'UTF8');
    v_diff := 0;
    FOR v_idx IN 0..(v_req_len - 1) LOOP
      v_diff := v_diff | (pg_catalog.get_byte(v_cand_bytes, v_idx) # pg_catalog.get_byte(v_exp_bytes, v_idx));
    END LOOP;
    IF v_diff = 0 THEN
      v_matched := true;
    END IF;

    -- Compatibilidade autenticada por chave com registros gerados sob key_version = 1 na 000016
    IF r_key.key_version = 1 AND p_purpose IN ('LGPD_IDEM_AUTH', 'LGPD_OWNER_SCOPE') THEN
      v_leg_in1 := pg_catalog.md5(r_key.secret_material || ':in1:v1:' || p_purpose || ':' || p_payload);
      v_leg_out1 := pg_catalog.md5(r_key.secret_material || ':out1:v1:' || v_leg_in1);
      v_leg_in2 := pg_catalog.md5(r_key.secret_material || ':in2:v1:' || p_purpose || ':' || p_payload);
      v_leg_out2 := pg_catalog.md5(r_key.secret_material || ':out2:v1:' || v_leg_in2);
      v_leg_cand := pg_catalog.left(v_leg_out1 || v_leg_out2, v_req_len);
      v_cand_bytes := pg_catalog.convert_to(v_leg_cand, 'UTF8');
      v_diff := 0;
      FOR v_idx IN 0..(v_req_len - 1) LOOP
        v_diff := v_diff | (pg_catalog.get_byte(v_cand_bytes, v_idx) # pg_catalog.get_byte(v_exp_bytes, v_idx));
      END LOOP;
      IF v_diff = 0 THEN
        v_matched := true;
      END IF;
    END IF;
  END LOOP;

  -- NUNCA aceita md5(p_payload) sem chave secreta
  RETURN v_matched;
END;
$$;

CREATE OR REPLACE FUNCTION internal_guard.rotate_lineage_hmac_key(
  p_new_secret TEXT DEFAULT NULL,
  p_disable_previous_verification BOOLEAN DEFAULT false
)
RETURNS SMALLINT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_next_version SMALLINT;
  v_secret TEXT;
  v_raw_bytes BYTEA;
  v_distinct_hex INTEGER := 0;
  v_distinct_bytes INTEGER := 0;
  v_w1_distinct INTEGER := 0;
  v_w2_distinct INTEGER := 0;
  v_w3_distinct INTEGER := 0;
  v_w4_distinct INTEGER := 0;
BEGIN
  IF v_uid IS NOT NULL
     OR v_json_sub IS NOT NULL
     OR v_db_role IN ('anon', 'authenticated')
     OR v_jwt_role IN ('anon', 'authenticated')
     OR NOT (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_KEY_ROTATION: Apenas service_role ou superusuário administrativo pode rotacionar chaves de linhagem.'
      USING ERRCODE = '42501';
  END IF;

  IF p_new_secret IS NULL THEN
    -- Geração automática estrita via CSPRNG de 256 bits (32 bytes) sem fallback inseguro
    BEGIN
      v_raw_bytes := public.gen_random_bytes(32);
    EXCEPTION WHEN OTHERS THEN
      RAISE EXCEPTION 'CSPRNG_FAILURE: Fonte criptográfica public.gen_random_bytes(32) indisponível ou falhou durante a rotação.'
        USING ERRCODE = 'P0001';
    END;

    IF v_raw_bytes IS NULL OR pg_catalog.octet_length(v_raw_bytes) <> 32 THEN
      RAISE EXCEPTION 'CSPRNG_FAILURE: public.gen_random_bytes(32) retornou comprimento inválido.'
        USING ERRCODE = 'P0001';
    END IF;

    v_secret := pg_catalog.lower(pg_catalog.encode(v_raw_bytes, 'hex'));
  ELSE
    v_secret := pg_catalog.lower(pg_catalog.btrim(p_new_secret));
  END IF;

  IF pg_catalog.char_length(v_secret) < 64
     OR pg_catalog.char_length(v_secret) > 128
     OR (pg_catalog.char_length(v_secret) % 2) <> 0 THEN
    RAISE EXCEPTION 'INVALID_SECRET_LENGTH: O material secreto de rotação deve possuir entre 64 e 128 caracteres hexadecimais pares (256 a 512 bits).'
      USING ERRCODE = '23514';
  END IF;

  IF v_secret !~ '^[0-9a-f]+$' THEN
    RAISE EXCEPTION 'INVALID_SECRET_CHARACTERS: O material secreto deve conter exclusivamente caracteres hexadecimais (0-9, a-f).'
      USING ERRCODE = '23514';
  END IF;

  SELECT COUNT(DISTINCT ch) INTO v_distinct_hex
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 64), '') AS ch WHERE ch <> '';

  SELECT COUNT(DISTINCT pg_catalog.substr(v_secret, i * 2 + 1, 2)) INTO v_distinct_bytes
  FROM pg_catalog.generate_series(0, 31) AS g(i);

  SELECT COUNT(DISTINCT ch) INTO v_w1_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w2_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 17, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w3_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 33, 16), '') AS ch WHERE ch <> '';
  SELECT COUNT(DISTINCT ch) INTO v_w4_distinct
  FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 49, 16), '') AS ch WHERE ch <> '';

  IF v_distinct_hex < 8
     OR v_distinct_bytes < 10
     OR v_w1_distinct < 5
     OR v_w2_distinct < 5
     OR v_w3_distinct < 5
     OR v_w4_distinct < 5
     OR v_secret ~ '([0-9a-f])\1{7,}'
     OR pg_catalog.substr(v_secret, 1, 64) ~ '^([0-9a-f]{1,32})\1+$'
     OR v_secret ~ '(01234567|12345678|23456789|89abcdef|fedcba98|98765432|76543210|a1b2c3d4e5f6)' THEN
    RAISE EXCEPTION 'WEAK_SECRET_MATERIAL_REJECTED: Segredo rejeitado por conter padrão periódico, repetitivo, sequencial ou baixa diversidade estrutural.'
      USING ERRCODE = '23514';
  END IF;

  IF EXISTS (SELECT 1 FROM internal_guard.lineage_hmac_keys k WHERE k.secret_material = v_secret) THEN
    RAISE EXCEPTION 'DUPLICATE_SECRET_MATERIAL_REJECTED: O segredo informado já foi utilizado em uma versão anterior.'
      USING ERRCODE = '23505';
  END IF;

  SELECT COALESCE(MAX(k.key_version), 0) + 1
    INTO v_next_version
  FROM internal_guard.lineage_hmac_keys k;

  IF v_next_version > 999 THEN
    RAISE EXCEPTION 'KEY_VERSION_LIMIT_EXCEEDED: Limite máximo de versões de chave atingido (999).'
      USING ERRCODE = '23514';
  END IF;

  UPDATE internal_guard.lineage_hmac_keys
  SET is_current = false,
      is_verify_enabled = CASE WHEN p_disable_previous_verification THEN false ELSE is_verify_enabled END,
      rotated_at = COALESCE(rotated_at, now())
  WHERE is_current = true;

  INSERT INTO internal_guard.lineage_hmac_keys (key_version, secret_material, is_current, is_verify_enabled)
  VALUES (v_next_version, v_secret, true, true);

  PERFORM internal_guard.require_active_hmac_secret();

  RETURN v_next_version;
END;
$$;

-- M02.11-F02 (Seção 6): RPC administrativa controlada para ciclo de vida de chaves históricas:
--   - 'RETIRE' / 'DISABLE_VERIFY': desabilita verificação (is_verify_enabled = false) de versão histórica sem dependentes;
--   - 'ENABLE_VERIFY': reabilita verificação (is_verify_enabled = true) de versão histórica existente;
--   - 'RESTORE': restaura versão histórica a partir de backup autorizado (is_current = false, is_verify_enabled = true);
--   - 'PURGE_RETIRED': remove versão histórica já desabilitada e sem registros dependentes.
CREATE OR REPLACE FUNCTION internal_guard.manage_lineage_hmac_key_lifecycle(
  p_action TEXT,
  p_key_version SMALLINT,
  p_secret_material TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_action TEXT := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_action, '')));
  v_existing RECORD;
  v_secret TEXT;
  v_distinct_hex INTEGER := 0;
  v_distinct_bytes INTEGER := 0;
  v_w1_distinct INTEGER := 0;
  v_w2_distinct INTEGER := 0;
  v_w3_distinct INTEGER := 0;
  v_w4_distinct INTEGER := 0;
BEGIN
  IF v_uid IS NOT NULL
     OR v_json_sub IS NOT NULL
     OR v_db_role IN ('anon', 'authenticated')
     OR v_jwt_role IN ('anon', 'authenticated')
     OR NOT (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_KEY_LIFECYCLE_MANAGEMENT: Apenas service_role ou superusuário administrativo pode gerenciar o ciclo de vida das chaves HMAC.'
      USING ERRCODE = '42501';
  END IF;

  IF p_key_version IS NULL OR p_key_version < 1 OR p_key_version > 999 THEN
    RAISE EXCEPTION 'INVALID_KEY_VERSION: Informe uma versão de chave válida (1 a 999).'
      USING ERRCODE = '23514';
  END IF;

  IF v_action NOT IN ('RETIRE', 'DISABLE_VERIFY', 'ENABLE_VERIFY', 'RESTORE', 'PURGE_RETIRED') THEN
    RAISE EXCEPTION 'INVALID_KEY_LIFECYCLE_ACTION: Ação inválida (%). Use RETIRE, DISABLE_VERIFY, ENABLE_VERIFY, RESTORE ou PURGE_RETIRED.', v_action
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_existing
  FROM internal_guard.lineage_hmac_keys k
  WHERE k.key_version = p_key_version
  FOR UPDATE;

  IF v_action IN ('RETIRE', 'DISABLE_VERIFY') THEN
    IF v_existing.key_version IS NULL THEN
      RAISE EXCEPTION 'KEY_VERSION_NOT_FOUND: Versão de chave (%) não encontrada.', p_key_version
        USING ERRCODE = 'P0002';
    END IF;
    IF v_existing.is_current = true THEN
      RAISE EXCEPTION 'KEY_DISABLE_ACTIVE_FORBIDDEN: Não é permitido aposentar/desabilitar a versão atualmente ativa (key_version=%). Rotacione a chave antes.', p_key_version
        USING ERRCODE = '42501';
    END IF;

    UPDATE internal_guard.lineage_hmac_keys
    SET is_verify_enabled = false,
        rotated_at = COALESCE(rotated_at, now())
    WHERE key_version = p_key_version;

    PERFORM internal_guard.require_active_hmac_secret();
    RETURN jsonb_build_object('action', v_action, 'key_version', p_key_version, 'is_verify_enabled', false);
  END IF;

  IF v_action = 'ENABLE_VERIFY' THEN
    IF v_existing.key_version IS NULL THEN
      RAISE EXCEPTION 'KEY_VERSION_NOT_FOUND: Versão de chave (%) não encontrada.', p_key_version
        USING ERRCODE = 'P0002';
    END IF;

    UPDATE internal_guard.lineage_hmac_keys
    SET is_verify_enabled = true
    WHERE key_version = p_key_version;

    PERFORM internal_guard.require_active_hmac_secret();
    RETURN jsonb_build_object('action', v_action, 'key_version', p_key_version, 'is_verify_enabled', true);
  END IF;

  IF v_action = 'RESTORE' THEN
    v_secret := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_secret_material, '')));
    IF pg_catalog.char_length(v_secret) < 64
       OR pg_catalog.char_length(v_secret) > 128
       OR (pg_catalog.char_length(v_secret) % 2) <> 0 THEN
      RAISE EXCEPTION 'INVALID_SECRET_LENGTH: O segredo restaurado deve possuir entre 64 e 128 caracteres hexadecimais pares.'
        USING ERRCODE = '23514';
    END IF;
    IF v_secret !~ '^[0-9a-f]+$' THEN
      RAISE EXCEPTION 'INVALID_SECRET_CHARACTERS: O segredo restaurado deve conter exclusivamente caracteres hexadecimais (0-9, a-f).'
        USING ERRCODE = '23514';
    END IF;

    SELECT COUNT(DISTINCT ch) INTO v_distinct_hex
    FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 64), '') AS ch WHERE ch <> '';
    SELECT COUNT(DISTINCT pg_catalog.substr(v_secret, i * 2 + 1, 2)) INTO v_distinct_bytes
    FROM pg_catalog.generate_series(0, 31) AS g(i);
    SELECT COUNT(DISTINCT ch) INTO v_w1_distinct
    FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 1, 16), '') AS ch WHERE ch <> '';
    SELECT COUNT(DISTINCT ch) INTO v_w2_distinct
    FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 17, 16), '') AS ch WHERE ch <> '';
    SELECT COUNT(DISTINCT ch) INTO v_w3_distinct
    FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 33, 16), '') AS ch WHERE ch <> '';
    SELECT COUNT(DISTINCT ch) INTO v_w4_distinct
    FROM pg_catalog.regexp_split_to_table(pg_catalog.substr(v_secret, 49, 16), '') AS ch WHERE ch <> '';

    IF v_distinct_hex < 8
       OR v_distinct_bytes < 10
       OR v_w1_distinct < 5
       OR v_w2_distinct < 5
       OR v_w3_distinct < 5
       OR v_w4_distinct < 5
       OR v_secret ~ '([0-9a-f])\1{7,}'
       OR pg_catalog.substr(v_secret, 1, 64) ~ '^([0-9a-f]{1,32})\1+$'
       OR v_secret ~ '(01234567|12345678|23456789|89abcdef|fedcba98|98765432|76543210|a1b2c3d4e5f6)' THEN
      RAISE EXCEPTION 'WEAK_SECRET_MATERIAL_REJECTED: Segredo de restauração rejeitado por padrão periódico, repetitivo, sequencial ou baixa diversidade.'
        USING ERRCODE = '23514';
    END IF;

    IF v_existing.key_version IS NOT NULL THEN
      IF v_existing.secret_material <> v_secret THEN
        RAISE EXCEPTION 'KEY_VERSION_CONFLICT: A versão (%) já existe com material secreto diferente; conflito de versão bloqueado.', p_key_version
          USING ERRCODE = '23505';
      END IF;
      UPDATE internal_guard.lineage_hmac_keys
      SET is_verify_enabled = true
      WHERE key_version = p_key_version;
      RETURN jsonb_build_object('action', 'RESTORE', 'key_version', p_key_version, 'restored', true, 'idempotent_replay', true);
    END IF;

    IF EXISTS (SELECT 1 FROM internal_guard.lineage_hmac_keys k WHERE k.secret_material = v_secret) THEN
      RAISE EXCEPTION 'DUPLICATE_SECRET_MATERIAL_REJECTED: O segredo informado já pertence a outra versão de chave.'
        USING ERRCODE = '23505';
    END IF;

    INSERT INTO internal_guard.lineage_hmac_keys (key_version, secret_material, is_current, is_verify_enabled, rotated_at)
    VALUES (p_key_version, v_secret, false, true, now());

    PERFORM internal_guard.require_active_hmac_secret();
    RETURN jsonb_build_object('action', 'RESTORE', 'key_version', p_key_version, 'restored', true, 'idempotent_replay', false);
  END IF;

  -- v_action = 'PURGE_RETIRED'
  IF v_existing.key_version IS NULL THEN
    RAISE EXCEPTION 'KEY_VERSION_NOT_FOUND: Versão de chave (%) não encontrada para expurgo.', p_key_version
      USING ERRCODE = 'P0002';
  END IF;
  IF v_existing.is_current = true OR v_existing.is_verify_enabled = true THEN
    RAISE EXCEPTION 'KEY_PURGE_MUST_BE_RETIRED_FIRST: A versão (%) deve estar inativa e desabilitada para verificação (RETIRE) antes do expurgo físico.', p_key_version
      USING ERRCODE = '42501';
  END IF;

  DELETE FROM internal_guard.lineage_hmac_keys
  WHERE key_version = p_key_version;

  PERFORM internal_guard.require_active_hmac_secret();
  RETURN jsonb_build_object('action', 'PURGE_RETIRED', 'key_version', p_key_version, 'deleted', true);
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. HARDENING DE public.derive_idempotency_lineage_key() (M02.11-F05 — Seção 9)
--    Convertida para SECURITY DEFINER (OWNER postgres) com search_path fixo,
--    REVOKE de PUBLIC/anon/authenticated, GRANT explícito apenas a service_role
--    e validação de contexto de 4 fatores.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.derive_idempotency_lineage_key(
  p_root_key TEXT,
  p_generation INTEGER
)
RETURNS VARCHAR(64)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_call_stack TEXT;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_root TEXT := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_root_key, '')));
  v_clamped_gen INTEGER := LEAST(GREATEST(COALESCE(p_generation, 0), 1), 9999);
  v_root_hash24 TEXT;
  v_gen_hash24 TEXT;
BEGIN
  GET DIAGNOSTICS v_call_stack = PG_CONTEXT;
  -- Bloqueia qualquer chamada direta por anon ou authenticated (permitindo apenas
  -- chamada interna via create_booking_request / backfill_and_verify_booking_lineage
  -- ou chamada administrativa direta por service_role / postgres).
  IF (
       v_uid IS NOT NULL
       OR v_json_sub IS NOT NULL
       OR v_db_role IN ('anon', 'authenticated')
       OR v_jwt_role IN ('anon', 'authenticated')
     )
     AND pg_catalog.position('create_booking_request' in COALESCE(v_call_stack, '')) = 0
     AND pg_catalog.position('backfill_and_verify_booking_lineage' in COALESCE(v_call_stack, '')) = 0 THEN
    RAISE EXCEPTION 'UNAUTHORIZED_DERIVE_LINEAGE_KEY: Chamada direta a public.derive_idempotency_lineage_key proibida para anon/authenticated.'
      USING ERRCODE = '42501';
  END IF;

  IF COALESCE(p_generation, 0) <= 0 THEN
    RETURN pg_catalog.left(v_clean_root, 64)::varchar(64);
  END IF;

  IF v_clean_root ~ '^idg-root-[0-9a-f]{24}$' THEN
    v_root_hash24 := pg_catalog.substring(v_clean_root from 10 for 24);
  ELSIF v_clean_root ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
    v_root_hash24 := pg_catalog.substring(v_clean_root from 10 for 24);
  ELSE
    v_root_hash24 := pg_catalog.left(
      internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_clean_root),
      24
    );
  END IF;

  v_gen_hash24 := pg_catalog.left(
    internal_guard.compute_lineage_mac(
      'LINEAGE_GEN_V1',
      v_root_hash24 || ':gen:' || v_clamped_gen::text
    ),
    24
  );

  RETURN (
    'idg-'
    || v_root_hash24
    || '-g'
    || pg_catalog.lpad(v_clamped_gen::text, 4, '0')
    || '-'
    || v_gen_hash24
  )::varchar(64);
END;
$$;

-- ----------------------------------------------------------------------------
-- 6. ATUALIZAÇÃO DE public.enforce_booking_invariants_and_transitions()
--    Protege a imutabilidade de hmac_key_version, lineage_root_key_version,
--    lineage_idem_key_version e lineage_scope_key_version fora de LINEAGE_BACKFILL
--    e LGPD_ANONYMIZE.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
  v_lineage_backfill BOOLEAN := false;
  v_expected_lgpd_email TEXT;
  v_active_ver SMALLINT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    IF NEW.original_idempotency_key IS NULL OR pg_catalog.btrim(NEW.original_idempotency_key) = '' THEN
      NEW.original_idempotency_key := pg_catalog.lower(pg_catalog.btrim(NEW.idempotency_key));
    END IF;

    IF NEW.idempotency_generation IS NULL THEN
      NEW.idempotency_generation := 0;
    END IF;

    IF NEW.original_idempotency_key ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      RAISE EXCEPTION 'INVALID_ORIGINAL_IDEMPOTENCY_KEY: Uma chave derivada de geração (idg-...-gNNNN-...) não pode ser gravada como original_idempotency_key.'
        USING ERRCODE = '23514';
    END IF;

    IF NEW.hmac_key_version IS NULL THEN
      v_active_ver := internal_guard.require_active_hmac_secret();
      NEW.hmac_key_version := v_active_ver;
      NEW.lineage_root_key_version := COALESCE(NEW.lineage_root_key_version, v_active_ver);
      NEW.lineage_idem_key_version := COALESCE(NEW.lineage_idem_key_version, v_active_ver);
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      v_lineage_backfill := internal_guard.consume_token(
        'BOOKING_MUTATION',
        OLD.id,
        'LINEAGE_BACKFILL:' || NEW.status::text
      );
    END IF;

    IF NOT v_lgpd_anonymize AND NOT v_lineage_backfill THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF v_lineage_backfill THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.code IS DISTINCT FROM OLD.code
         OR NEW.status IS DISTINCT FROM OLD.status
         OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.channel IS DISTINCT FROM OLD.channel
         OR NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
         OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
         OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
         OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
         OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
         OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
         OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
         OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
         OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
         OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.rejection_or_cancel_reason IS DISTINCT FROM OLD.rejection_or_cancel_reason
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_IMMUTABLE_VIOLATION: O reparo de linhagem não pode modificar dados operacionais, financeiros, UTMs, notas, timestamps ou dados de cliente.'
          USING ERRCODE = '42501';
      END IF;

      IF (
           OLD.customer_name = 'TITULAR ANONIMIZADO LGPD'
           OR OLD.idempotency_key LIKE 'lgpd-%'
           OR OLD.original_idempotency_key LIKE 'lgpd-%'
         )
         AND (
           NEW.idempotency_key !~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
           OR NEW.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         ) THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_LGPD_DOWNGRADE_FORBIDDEN: O backfill não pode remover a pseudonimização LGPD nem restaurar identificadores originais em reserva anonimizada.'
          USING ERRCODE = '42501';
      END IF;

      IF NEW.original_idempotency_key IS NULL
         OR pg_catalog.char_length(pg_catalog.btrim(NEW.original_idempotency_key)) < 8
         OR pg_catalog.char_length(NEW.original_idempotency_key) > 64
         OR NEW.original_idempotency_key ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$'
         OR NEW.idempotency_generation IS NULL
         OR NEW.idempotency_generation < 0
         OR NEW.idempotency_generation > 9999 THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_INVALID_VALUES: Valores de original_idempotency_key ou idempotency_generation inválidos durante backfill.'
          USING ERRCODE = '23514';
      END IF;

      RETURN NEW;
    END IF;

    v_expected_lgpd_email := 'anonimizado.' || pg_catalog.lower(OLD.code) || '@lgpd.invalid';

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR (
         NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         )
       )
       OR (
         NEW.original_idempotency_key IS DISTINCT FROM OLD.original_idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         )
       )
       OR NEW.idempotency_generation IS DISTINCT FROM OLD.idempotency_generation
       OR (
         (
           NEW.hmac_key_version IS DISTINCT FROM OLD.hmac_key_version
           OR NEW.lineage_root_key_version IS DISTINCT FROM OLD.lineage_root_key_version
           OR NEW.lineage_idem_key_version IS DISTINCT FROM OLD.lineage_idem_key_version
           OR NEW.lineage_scope_key_version IS DISTINCT FROM OLD.lineage_scope_key_version
         )
         AND NOT v_lgpd_anonymize
       )
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de linhagem de idempotência, de versão de chave HMAC, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    IF v_lgpd_anonymize THEN
      IF NEW.status IS DISTINCT FROM OLD.status
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_OPERATIONAL_FIELDS: A operação de anonimização LGPD não pode alterar status, data, passageiros, UTMs ou timestamps operacionais da reserva.'
          USING ERRCODE = '42501';
      END IF;

      IF NEW.customer_name <> 'TITULAR ANONIMIZADO LGPD'
         OR NEW.customer_phone <> '(00) 00000-0000'
         OR NEW.customer_email <> v_expected_lgpd_email
         OR NEW.tourist_user_id IS NOT NULL
         OR NEW.idempotency_key !~ ('^lgpd-' || pg_catalog.replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         OR NEW.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         OR NEW.notes IS NULL
         OR NEW.notes NOT LIKE '[LGPD %'
         OR (NEW.rejection_or_cancel_reason IS NOT NULL AND NEW.rejection_or_cancel_reason NOT LIKE '[LGPD %') THEN
        RAISE EXCEPTION 'LGPD_INVALID_TARGET_VALUES: O token LGPD_ANONYMIZE permite gravar exclusivamente os valores canônicos de anonimização LGPD.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) AND NEW.status IS DISTINCT FROM OLD.status THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status inválida (% -> %) para a reserva %.', OLD.status, NEW.status, OLD.code
          USING ERRCODE = '23514';
      END IF;
      IF NEW.status NOT IN ('CANCELADA', 'RECUSADA') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          OLD.id
        );
      END IF;
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status inválida (% -> %) para a reserva %.', OLD.status, NEW.status, OLD.code
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'FORBIDDEN_STATUS_TRANSITION: O papel % não possui permissão para realizar a transição % -> %.', v_actor_role, OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          OLD.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' THEN
        NEW.confirmed_at := COALESCE(NEW.confirmed_at, now());
        NEW.completed_at := COALESCE(NEW.completed_at, now());
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 7. ATUALIZAÇÃO DE public.backfill_and_verify_booking_lineage()
--    (M02.11-F01 & M02.11-F02 — Seções 5 e 6)
--    - Migra registros legados (000013..000016) para HMAC-SHA-256 quando houver
--      material suficiente para reconstruir e validar sua linhagem;
--    - Registra as versões de chave (hmac_key_version, lineage_root_key_version,
--      lineage_idem_key_version, lineage_scope_key_version);
--    - Se uma reserva estiver completamente anonimizada (ex.: 000014 sem lgpd-lin-
--      e sem PII/irmã autenticável), NÃO inventa associação e preserva os dados
--      existentes de forma segura.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.backfill_and_verify_booking_lineage()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_active_ver SMALLINT;
  r_bk RECORD;
  r_sib RECORD;
  v_new_idem VARCHAR(64);
  v_new_orig VARCHAR(64);
  v_new_gen INTEGER;
  v_new_hmac_ver SMALLINT;
  v_new_root_ver SMALLINT;
  v_new_idem_ver SMALLINT;
  v_new_scope_ver SMALLINT;
  v_root_hash24 TEXT;
  v_scope_hash20 TEXT;
  v_sib_scope_payload TEXT;
  v_is_anon_row BOOLEAN;
  v_has_real_pii BOOLEAN;
  v_skip_row BOOLEAN;
  v_updated_count INTEGER := 0;
  v_skipped_unreconstructable_count INTEGER := 0;
BEGIN
  IF v_uid IS NOT NULL
     OR v_json_sub IS NOT NULL
     OR v_db_role IN ('anon', 'authenticated')
     OR v_jwt_role IN ('anon', 'authenticated')
     OR NOT (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_LINEAGE_BACKFILL: Apenas service_role ou superusuário administrativo pode executar o reparo de linhagem.'
      USING ERRCODE = '42501';
  END IF;

  v_active_ver := internal_guard.require_active_hmac_secret();

  FOR r_bk IN
    SELECT
      b.id,
      b.status,
      b.idempotency_key,
      b.original_idempotency_key,
      b.idempotency_generation,
      b.hmac_key_version,
      b.lineage_root_key_version,
      b.lineage_idem_key_version,
      b.lineage_scope_key_version,
      b.tour_id,
      b.booking_date,
      b.customer_name,
      b.customer_phone,
      b.customer_email,
      b.created_at
    FROM public.bookings b
    ORDER BY b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    v_skip_row := false;
    v_new_idem := pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.idempotency_key, '')));
    v_new_orig := pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.original_idempotency_key, '')));
    v_new_hmac_ver := r_bk.hmac_key_version;
    v_new_root_ver := r_bk.lineage_root_key_version;
    v_new_idem_ver := r_bk.lineage_idem_key_version;
    v_new_scope_ver := r_bk.lineage_scope_key_version;

    v_is_anon_row := (
      r_bk.customer_name = 'TITULAR ANONIMIZADO LGPD'
      OR v_new_idem LIKE 'lgpd-%'
      OR v_new_orig LIKE 'lgpd-%'
    );

    v_has_real_pii := (
      r_bk.customer_name <> 'TITULAR ANONIMIZADO LGPD'
      AND r_bk.customer_phone <> '(00) 00000-0000'
      AND pg_catalog.lower(COALESCE(r_bk.customer_email, '')) NOT LIKE 'anonimizado.%@lgpd.invalid'
    );

    IF v_is_anon_row THEN
      IF v_new_orig ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
        v_root_hash24 := pg_catalog.substring(v_new_orig from 10 for 24);
        v_scope_hash20 := pg_catalog.substring(v_new_orig from 35 for 20);

        -- Se a linha anonimizada possui <root24> ou <scope20> legado (MD5 de 000015/000016)
        -- e existe uma reserva irmã não anonimizada na mesma linhagem cujo titular e chave
        -- raiz confirmam matematicamente tanto <root24> quanto <scope20>, migra para HMAC-SHA-256!
        IF v_new_root_ver IS NULL OR v_new_scope_ver IS NULL THEN
          r_sib := NULL;
          FOR r_sib IN
            SELECT
              p.id,
              p.tour_id,
              p.booking_date,
              p.customer_phone,
              p.customer_email,
              pg_catalog.lower(pg_catalog.btrim(COALESCE(NULLIF(p.original_idempotency_key, 'legacy-orig-key'), p.idempotency_key))) AS cand_root
            FROM public.bookings p
            WHERE p.id <> r_bk.id
              AND p.tour_id = r_bk.tour_id
              AND p.booking_date = r_bk.booking_date
              AND p.customer_name <> 'TITULAR ANONIMIZADO LGPD'
              AND pg_catalog.lower(COALESCE(p.original_idempotency_key, '')) NOT LIKE 'lgpd-%'
              AND pg_catalog.lower(COALESCE(p.original_idempotency_key, '')) NOT LIKE 'idg-root-%'
              AND pg_catalog.lower(COALESCE(p.idempotency_key, '')) NOT LIKE 'lgpd-%'
            ORDER BY p.idempotency_generation ASC, p.created_at ASC
          LOOP
            v_sib_scope_payload := r_sib.tour_id::text || ':' || r_sib.booking_date::text || ':'
              || pg_catalog.regexp_replace(COALESCE(r_sib.customer_phone, ''), '[^0-9]', '', 'g') || ':'
              || pg_catalog.lower(pg_catalog.btrim(COALESCE(r_sib.customer_email, '')));

            IF (
                 internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', r_sib.cand_root, v_root_hash24)
                 OR pg_catalog.left(pg_catalog.md5(r_sib.cand_root), 24) = v_root_hash24
               )
               AND (
                 internal_guard.verify_lineage_mac('LGPD_OWNER_SCOPE', v_sib_scope_payload, v_scope_hash20)
                 OR pg_catalog.left(pg_catalog.md5(v_sib_scope_payload), 20) = v_scope_hash20
               ) THEN
              v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', r_sib.cand_root, v_active_ver), 24);
              v_scope_hash20 := pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_OWNER_SCOPE', v_sib_scope_payload, v_active_ver), 20);
              v_new_orig := ('lgpd-lin-' || v_root_hash24 || '-' || v_scope_hash20)::varchar(64);
              v_new_root_ver := v_active_ver;
              v_new_scope_ver := v_active_ver;
              v_new_hmac_ver := v_active_ver;
              EXIT;
            END IF;
          END LOOP;
        END IF;

        IF v_new_idem !~ ('^lgpd-' || pg_catalog.replace(r_bk.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
          v_new_idem := (
            'lgpd-'
            || pg_catalog.replace(r_bk.id::text, '-', '')
            || '-'
            || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', COALESCE(NULLIF(v_new_idem, ''), r_bk.id::text), v_active_ver), 16)
          )::varchar(64);
          v_new_idem_ver := v_active_ver;
        ELSE
          v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver, v_active_ver);
        END IF;

        v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
        v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
        v_new_scope_ver := COALESCE(v_new_scope_ver, v_new_hmac_ver);
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
      ELSIF v_has_real_pii THEN
        -- Registro parcialmente marcado com lgpd- mas que ainda detém PII real para construir lgpd-lin- autenticado
        IF v_new_idem !~ ('^lgpd-' || pg_catalog.replace(r_bk.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
          v_new_idem := (
            'lgpd-'
            || pg_catalog.replace(r_bk.id::text, '-', '')
            || '-'
            || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', COALESCE(NULLIF(v_new_idem, ''), r_bk.id::text), v_active_ver), 16)
          )::varchar(64);
        END IF;

        IF v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_root_hash24 := pg_catalog.substring(v_new_orig from 5 for 24);
        ELSIF v_new_orig ~ '^idg-root-[0-9a-f]{24}$' THEN
          v_root_hash24 := pg_catalog.substring(v_new_orig from 10 for 24);
        ELSIF v_new_orig <> '' AND v_new_orig NOT LIKE 'lgpd-%' THEN
          v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_new_orig, v_active_ver), 24);
        ELSE
          v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_new_idem, v_active_ver), 24);
        END IF;

        v_scope_hash20 := pg_catalog.left(
          internal_guard.compute_lineage_mac(
            'LGPD_OWNER_SCOPE',
            r_bk.tour_id::text || ':' || r_bk.booking_date::text || ':'
              || pg_catalog.regexp_replace(COALESCE(r_bk.customer_phone, ''), '[^0-9]', '', 'g') || ':'
              || pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.customer_email, ''))),
            v_active_ver
          ),
          20
        );
        v_new_orig := ('lgpd-lin-' || v_root_hash24 || '-' || v_scope_hash20)::varchar(64);
        v_new_hmac_ver := v_active_ver;
        v_new_root_ver := v_active_ver;
        v_new_idem_ver := v_active_ver;
        v_new_scope_ver := v_active_ver;
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
      ELSE
        -- Condição de Segurança (Seção 5): Reserva totalmente anonimizada (ex.: 000014) sem
        -- lgpd-lin- e sem material suficiente para autenticar ou reconstruir sua linhagem.
        -- NÃO inventa associação sobre placeholders '(00) 00000-0000'/'@lgpd.invalid'; preserva os dados existentes!
        v_skip_row := true;
        v_skipped_unreconstructable_count := v_skipped_unreconstructable_count + 1;
      END IF;
    ELSE
      IF v_new_idem = '' THEN
        v_new_idem := ('legacy-' || pg_catalog.replace(r_bk.id::text, '-', ''))::varchar(64);
      END IF;

      IF v_new_idem ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
        v_new_gen := pg_catalog.substring(v_new_idem from 31 for 4)::integer;
        v_root_hash24 := pg_catalog.substring(v_new_idem from 5 for 24);

        IF v_new_orig = ''
           OR v_new_orig = 'legacy-orig-key'
           OR v_new_orig = v_new_idem
           OR v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          SELECT COALESCE(
                   NULLIF(pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)), ''),
                   pg_catalog.lower(pg_catalog.btrim(p.idempotency_key))
                 )
            INTO v_new_orig
          FROM public.bookings p
          WHERE p.id <> r_bk.id
            AND p.customer_name <> 'TITULAR ANONIMIZADO LGPD'
            AND p.tour_id = r_bk.tour_id
            AND p.booking_date = r_bk.booking_date
            AND pg_catalog.regexp_replace(COALESCE(p.customer_phone, ''), '[^0-9]', '', 'g')
                = pg_catalog.regexp_replace(COALESCE(r_bk.customer_phone, ''), '[^0-9]', '', 'g')
            AND pg_catalog.lower(pg_catalog.btrim(COALESCE(p.customer_email, '')))
                = pg_catalog.lower(pg_catalog.btrim(COALESCE(r_bk.customer_email, '')))
            AND (
              (
                pg_catalog.lower(pg_catalog.btrim(COALESCE(p.original_idempotency_key, ''))) <> ''
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) <> 'legacy-orig-key'
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) !~ '^idg-'
                AND pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)) !~ '^lgpd-'
                AND (
                  internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key)), v_root_hash24)
                  OR (
                    r_bk.lineage_root_key_version IS NULL
                    AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(p.original_idempotency_key))), 24) = v_root_hash24
                  )
                )
              )
              OR (
                pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)) !~ '^idg-'
                AND pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)) !~ '^lgpd-'
                AND (
                  internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(p.idempotency_key)), v_root_hash24)
                  OR (
                    r_bk.lineage_root_key_version IS NULL
                    AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(p.idempotency_key))), 24) = v_root_hash24
                  )
                )
              )
            )
          ORDER BY p.created_at ASC, p.id ASC
          LIMIT 1;

          v_new_orig := COALESCE(NULLIF(v_new_orig, ''), ('idg-root-' || v_root_hash24)::varchar(64));
        END IF;

        -- M02.11-F01 (Itens 9 & 10): Quando há material suficiente (chave raiz em texto claro ou alias canônico),
        -- migra chaves idg- legadas (MD5) para HMAC-SHA-256 e registra a versão HMAC correspondente.
        IF v_new_orig NOT LIKE 'idg-root-%' AND v_new_orig NOT LIKE 'lgpd-%' THEN
          IF NOT internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', v_new_orig, v_root_hash24, r_bk.lineage_root_key_version)
             OR NOT internal_guard.verify_lineage_mac('LINEAGE_GEN_V1', v_root_hash24 || ':gen:' || v_new_gen::text, pg_catalog.right(v_new_idem, 24), r_bk.lineage_idem_key_version) THEN
            v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
            v_new_hmac_ver := v_active_ver;
            v_new_root_ver := v_active_ver;
            v_new_idem_ver := v_active_ver;
          ELSE
            v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
            v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
            v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
          END IF;
        ELSE
          -- Raiz órfã ('idg-root-<root24>'): garante que o sufixo <gen24> esteja assinado com HMAC-SHA-256
          IF NOT internal_guard.verify_lineage_mac('LINEAGE_GEN_V1', v_root_hash24 || ':gen:' || v_new_gen::text, pg_catalog.right(v_new_idem, 24), r_bk.lineage_idem_key_version) THEN
            v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
            v_new_hmac_ver := v_active_ver;
            v_new_idem_ver := v_active_ver;
          ELSE
            v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
            v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
          END IF;
        END IF;
        v_new_scope_ver := NULL;
      ELSE
        v_new_gen := GREATEST(COALESCE(r_bk.idempotency_generation, 0), 0);
        IF v_new_orig = ''
           OR v_new_orig = 'legacy-orig-key'
           OR v_new_orig ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_new_orig := v_new_idem;
        END IF;
        v_new_hmac_ver := COALESCE(v_new_hmac_ver, v_active_ver);
        v_new_root_ver := COALESCE(v_new_root_ver, v_new_hmac_ver);
        v_new_idem_ver := COALESCE(v_new_idem_ver, v_new_hmac_ver);
        v_new_scope_ver := NULL;
      END IF;
    END IF;

    IF NOT v_skip_row THEN
      WHILE EXISTS (
        SELECT 1 FROM public.bookings x
        WHERE x.id <> r_bk.id
          AND x.original_idempotency_key = v_new_orig
          AND x.idempotency_generation = v_new_gen
      ) LOOP
        v_new_gen := v_new_gen + 1;
        IF v_new_idem ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
          v_new_idem := public.derive_idempotency_lineage_key(v_new_orig, v_new_gen);
          v_new_hmac_ver := v_active_ver;
          v_new_idem_ver := v_active_ver;
        END IF;
      END LOOP;

      IF r_bk.idempotency_key IS DISTINCT FROM v_new_idem
         OR r_bk.original_idempotency_key IS DISTINCT FROM v_new_orig
         OR r_bk.idempotency_generation IS DISTINCT FROM v_new_gen
         OR r_bk.hmac_key_version IS DISTINCT FROM v_new_hmac_ver
         OR r_bk.lineage_root_key_version IS DISTINCT FROM v_new_root_ver
         OR r_bk.lineage_idem_key_version IS DISTINCT FROM v_new_idem_ver
         OR r_bk.lineage_scope_key_version IS DISTINCT FROM v_new_scope_ver THEN
        PERFORM internal_guard.issue_token('BOOKING_MUTATION', r_bk.id, 'LINEAGE_BACKFILL:' || r_bk.status::text);
        UPDATE public.bookings
        SET idempotency_key = v_new_idem,
            original_idempotency_key = v_new_orig,
            idempotency_generation = v_new_gen,
            hmac_key_version = v_new_hmac_ver,
            lineage_root_key_version = v_new_root_ver,
            lineage_idem_key_version = v_new_idem_ver,
            lineage_scope_key_version = v_new_scope_ver
        WHERE id = r_bk.id;
        PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', r_bk.id);
        v_updated_count := v_updated_count + 1;
      END IF;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'verified', true,
    'updated_rows', v_updated_count,
    'skipped_unreconstructable_anon_rows', v_skipped_unreconstructable_count,
    'active_hmac_key_version', v_active_ver
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 8. ATUALIZAÇÃO DE public.admin_anonymize_customer_pii()
--    (M02.11-F01 & M02.11-F02 — Seções 5 e 6)
--    - Utiliza exclusivamente HMAC-SHA-256 (v_active_key_ver) para novas gravações;
--    - Quando original_idempotency_key contém a chave raiz em texto claro (mesmo
--      em reserva idg- pré-000017), calcula v_root_hash24 via HMAC-SHA-256 sobre
--      original_idempotency_key, migrando o <root24> para HMAC-SHA-256;
--    - Registra as versões de chave HMAC em hmac_key_version,
--      lineage_root_key_version, lineage_idem_key_version e lineage_scope_key_version.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := pg_catalog.btrim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_active_key_ver SMALLINT;
  v_root_key_ver SMALLINT;
  v_idem_key_ver SMALLINT;
  v_scope_key_ver SMALLINT;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_orig_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_owner_scope_hash20 TEXT;
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_norm_old_name TEXT;
  v_norm_comment TEXT;
  v_norm_comment_geo_stripped TEXT;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND v_json_role IS DISTINCT FROM 'anon'
        AND v_json_role IS DISTINCT FROM 'authenticated'
        AND (
          (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  v_active_key_ver := internal_guard.require_active_hmac_secret();

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || pg_catalog.lower(v_target.code) || '@lgpd.invalid';
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$')
     AND v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %') THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'original_idempotency_key', v_target.original_idempotency_key,
      'idempotency_generation', v_target.idempotency_generation,
      'hmac_key_version', v_target.hmac_key_version,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := pg_catalog.btrim(COALESCE(v_target.customer_name, ''));
  v_old_email := pg_catalog.lower(pg_catalog.btrim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := pg_catalog.regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  IF v_target.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
    v_anon_idem_key := v_target.idempotency_key;
    v_idem_key_ver := COALESCE(v_target.lineage_idem_key_version, v_target.hmac_key_version, v_active_key_ver);
  ELSE
    v_anon_idem_key := (
      'lgpd-'
      || pg_catalog.replace(v_target.id::text, '-', '')
      || '-'
      || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)), v_active_key_ver), 16)
    )::varchar(64);
    v_idem_key_ver := v_active_key_ver;
  END IF;

  IF v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
    v_anon_orig_idem_key := v_target.original_idempotency_key;
    v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version, v_active_key_ver);
    v_scope_key_ver := COALESCE(v_target.lineage_scope_key_version, v_target.hmac_key_version, v_active_key_ver);
  ELSE
    -- Se idempotency_key é uma chave derivada idg-<root24>-gNNNN-<gen24>, preserva <root24>
    -- e sua versão (lineage_root_key_version) para que o cliente que detém a chave idg-
    -- continue autenticando a linha mesmo após rotações de chave subsequentes!
    IF pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)) ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      v_root_hash24 := pg_catalog.substring(pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)) from 5 for 24);
      v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version);
    ELSIF pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)) ~ '^idg-root-[0-9a-f]{24}$' THEN
      v_root_hash24 := pg_catalog.substring(pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)) from 10 for 24);
      v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version);
    ELSE
      v_root_hash24 := pg_catalog.left(
        internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)), v_active_key_ver),
        24
      );
      v_root_key_ver := v_active_key_ver;
    END IF;

    v_owner_scope_hash20 := pg_catalog.left(
      internal_guard.compute_lineage_mac(
        'LGPD_OWNER_SCOPE',
        v_target.tour_id::text || ':' || v_target.booking_date::text || ':' || v_old_phone_digits || ':' || v_old_email,
        v_active_key_ver
      ),
      20
    );
    v_scope_key_ver := v_active_key_ver;
    v_anon_orig_idem_key := ('lgpd-lin-' || v_root_hash24 || '-' || v_owner_scope_hash20)::varchar(64);
  END IF;

  v_anon_notes := pg_catalog.format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      pg_catalog.format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      original_idempotency_key = v_anon_orig_idem_key,
      hmac_key_version = v_active_key_ver,
      lineage_root_key_version = v_root_key_ver,
      lineage_idem_key_version = v_idem_key_ver,
      lineage_scope_key_version = v_scope_key_ver,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  UPDATE public.booking_status_history
  SET reason = pg_catalog.format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        pg_catalog.format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_norm_old_name := public.normalize_lgpd_text(v_old_name);
    v_norm_comment := public.normalize_lgpd_text(v_review.comment);

    v_norm_comment_geo_stripped := pg_catalog.regexp_replace(
      ' ' || v_norm_comment || ' ',
      ' (pela costa norte|da costa norte|na costa norte|costa norte|pela costa sul|da costa sul|na costa sul|costa sul|costa verde|costa brava|costa atlantica|praia da costa|pela costa|da costa|na costa|base marina|marina do saco|marina no saco|marina saco|marina itagua|marina porto|vaga na marina|praia da rosa|praia brava|praia grande|ilha anchieta|ilha das couves|ilha do prumirim|ilha comprida|ilha grande|ilha bela|praia do prumirim|cachoeira do prumirim|rio escuro|mar aberto|mar calmo) ',
      ' ',
      'g'
    );

    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR pg_catalog.regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (pg_catalog.char_length(v_old_email) >= 5 AND pg_catalog.position(v_old_email in pg_catalog.lower(v_review.comment)) > 0)
      OR (pg_catalog.char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND pg_catalog.position(v_old_phone_digits in pg_catalog.regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
      OR (
        pg_catalog.char_length(v_norm_old_name) >= 3
        AND v_old_name <> v_anon_name
        AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_norm_old_name || '($|[^a-z0-9])')
      )
    );

    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT pg_catalog.regexp_split_to_table(v_norm_old_name, '\s+')
      LOOP
        IF pg_catalog.char_length(v_name_token) >= 3
           AND v_name_token NOT IN (
             'dos', 'das', 'com', 'sem', 'por', 'que', 'uma', 'uns', 'meu', 'sua', 'seu', 'foi', 'era',
             'bom', 'boa', 'dia', 'mar', 'sol', 'sul', 'rio', 'rua', 'cep', 'cpf', 'pii',
             'para', 'pelo', 'pela', 'como', 'mais', 'muito', 'toda', 'todo', 'todos', 'todas',
             'ilha', 'ilhas', 'praia', 'praias', 'lancha', 'escuna', 'passeio', 'barco', 'roteiro',
             'norte', 'verde', 'anchieta', 'prumirim', 'couves',
             'ubatuba', 'saco', 'ribeira', 'itagua', 'familia', 'aguas', 'calmas',
             'titular', 'anonimizado', 'lgpd', 'cliente', 'turista', 'visitante', 'grupo', 'comentario'
           )
           AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_name_token || '($|[^a-z0-9])') THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := pg_catalog.format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            old_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            new_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'original_idempotency_key', v_updated.original_idempotency_key,
    'idempotency_generation', v_updated.idempotency_generation,
    'hmac_key_version', v_updated.hmac_key_version,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 9. ATUALIZAÇÃO DE public.create_booking_request()
--    (M02.11-F01, M02.11-F02 & M02.11-F04 — Seções 5, 6 e 8)
--    - Resolução de leitura restrita a registros históricos existentes (000013..000016)
--      vinculados ao passeio, data e titular;
--    - Verificação O(1) por versão (p_key_version) quando a versão do artefato
--      está armazenada em lineage_root_key_version, lineage_idem_key_version ou
--      lineage_scope_key_version;
--    - Gravação exclusiva em HMAC-SHA-256 para toda nova reserva criada,
--      persistindo hmac_key_version, lineage_root_key_version e lineage_idem_key_version.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_active_key_ver SMALLINT;
  v_root_key_ver SMALLINT;
  v_derived_row public.bookings;
  v_non_anon_root VARCHAR(64);
  v_input_root_hash24 TEXT;
  v_input_gen INTEGER;
  v_input_gen_hash24 TEXT;
  v_legacy_md5_root24 TEXT;
  v_key_match RECORD;
  v_key_same_owner BOOLEAN := false;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_existing_same_owner BOOLEAN := false;
  v_next_generation INTEGER := 0;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_has_explicit_key BOOLEAN := false;
  v_root_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_candidate_root_hashes TEXT[] := ARRAY[]::TEXT[];
  v_candidate_root_aliases TEXT[] := ARRAY[]::TEXT[];
  v_candidate_idg_prefixes TEXT[] := ARRAY[]::TEXT[];
  v_candidate_lgpd_prefixes TEXT[] := ARRAY[]::TEXT[];
  r_kver RECORD;
  v_ver_h24 TEXT;
  v_caller_scope_payload TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_raw_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_uid UUID := NULL;
BEGIN
  IF (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_raw_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_raw_uid::text <> v_json_sub) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_CONTEXT: Conflito de identidade entre claims JWT GUC e JSON.'
      USING ERRCODE = '42501';
  END IF;

  IF v_raw_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     )
     AND EXISTS (SELECT 1 FROM public.profiles WHERE id = v_raw_uid AND is_active = true) THEN
    v_uid := v_raw_uid;
  END IF;

  v_clean_name := pg_catalog.btrim(COALESCE(p_customer_name, ''));
  v_clean_phone := pg_catalog.btrim(COALESCE(p_customer_phone, ''));
  v_phone_digits := pg_catalog.regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_customer_email, '')));
  v_clean_channel := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_channel, '')));

  v_clean_idem_input := pg_catalog.lower(
    pg_catalog.regexp_replace(
      COALESCE(p_idempotency_key, ''),
      '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$',
      '',
      'g'
    )
  );
  v_has_explicit_key := (v_clean_idem_input <> '');

  IF v_has_explicit_key THEN
    IF v_clean_idem_input LIKE 'lgpd-%' OR v_clean_idem_input LIKE 'idg-root-%' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Os prefixos "lgpd-" e "idg-root-" são reservados exclusivamente para controle interno de linhagem e conformidade LGPD.'
        USING ERRCODE = '23514';
    END IF;

    IF pg_catalog.char_length(v_clean_idem_input) < 8
       OR pg_catalog.char_length(v_clean_idem_input) > 64
       OR v_clean_idem_input !~ '^[a-z0-9._:-]+$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: A chave de idempotência deve conter entre 8 e 64 caracteres alfanuméricos (a-z, 0-9, ., _, :, -) sem espaços internos.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF pg_catalog.char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_phone_digits) < 10 OR pg_catalog.char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.position('@' in v_clean_email) <= 1 OR pg_catalog.char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_active_key_ver := internal_guard.require_active_hmac_secret();

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  -- Hierarquia Canônica de Locks:
  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  -- Lock #2: Advisory lock transacional (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_caller_scope_payload := v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits || ':' || v_clean_email;

  IF v_clean_idem_input LIKE 'idg-%' THEN
    IF v_clean_idem_input !~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "idg-" é reservado para chaves derivadas de linhagem de idempotência.'
        USING ERRCODE = '23514';
    END IF;

    v_input_root_hash24 := pg_catalog.substring(v_clean_idem_input from 5 for 24);
    v_input_gen := pg_catalog.substring(v_clean_idem_input from 31 for 4)::integer;
    v_input_gen_hash24 := pg_catalog.right(v_clean_idem_input, 24);

    -- Localiza a reserva derivada correspondente em public.bookings:
    --   1) Correspondência exata em idempotency_key;
    --   2) Reserva anonimizada cuja tag LGPD_IDEM_AUTH autentica a chave idg- informada
    --      (ou compatibilidade restrita a linha histórica 000015 com lineage_idem_key_version IS NULL);
    --   3) Reserva derivada histórica (000013..000016) já migrada pelo backfill para HMAC-SHA-256
    --      cujo original_idempotency_key existente na mesma geração reproduz exatamente o par legado.
    SELECT b.*
      INTO v_derived_row
    FROM public.bookings b
    WHERE pg_catalog.lower(b.idempotency_key) = v_clean_idem_input
       OR (
         b.idempotency_generation = v_input_gen
         AND b.original_idempotency_key LIKE ('lgpd-lin-' || v_input_root_hash24 || '-%')
         AND (
           internal_guard.verify_lineage_mac('LGPD_IDEM_AUTH', v_clean_idem_input, pg_catalog.right(b.idempotency_key, 16), b.lineage_idem_key_version)
           OR (
             b.lineage_idem_key_version IS NULL
             AND b.hmac_key_version IS NULL
             AND pg_catalog.right(b.idempotency_key, 16) = pg_catalog.left(pg_catalog.md5(v_clean_idem_input), 16)
           )
         )
       )
       OR (
         b.idempotency_generation = v_input_gen
         AND b.original_idempotency_key NOT LIKE 'lgpd-%'
         AND b.original_idempotency_key NOT LIKE 'idg-root-%'
         AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key))), 24) = v_input_root_hash24
         AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key)) || ':gen:' || v_input_gen::text), 24) = v_input_gen_hash24
       )
    ORDER BY CASE WHEN pg_catalog.lower(b.idempotency_key) = v_clean_idem_input THEN 0 ELSE 1 END ASC
    LIMIT 1
    FOR UPDATE;

    IF v_derived_row.id IS NULL
       OR v_derived_row.original_idempotency_key IS NULL
       OR v_derived_row.idempotency_generation <= 0 THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
        USING ERRCODE = '23514';
    END IF;

    IF v_derived_row.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      IF NOT (
           internal_guard.verify_lineage_mac('LGPD_IDEM_AUTH', v_clean_idem_input, pg_catalog.right(v_derived_row.idempotency_key, 16), v_derived_row.lineage_idem_key_version)
           OR (
             v_derived_row.lineage_idem_key_version IS NULL
             AND v_derived_row.hmac_key_version IS NULL
             AND pg_catalog.right(v_derived_row.idempotency_key, 16) = pg_catalog.left(pg_catalog.md5(v_clean_idem_input), 16)
           )
         ) THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;

      SELECT b.original_idempotency_key
        INTO v_non_anon_root
      FROM public.bookings b
      WHERE b.original_idempotency_key NOT LIKE 'lgpd-%'
        AND b.original_idempotency_key NOT LIKE 'idg-root-%'
        AND (
          internal_guard.verify_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key)), v_input_root_hash24, b.lineage_root_key_version)
          OR (
            v_derived_row.lineage_root_key_version IS NULL
            AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(b.original_idempotency_key))), 24) = v_input_root_hash24
          )
        )
      ORDER BY b.idempotency_generation ASC
      LIMIT 1;

      v_root_idem_key := COALESCE(v_non_anon_root, ('idg-root-' || v_input_root_hash24)::varchar(64));
      IF v_non_anon_root IS NOT NULL THEN
        v_root_hash24 := pg_catalog.left(internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_non_anon_root, v_active_key_ver), 24);
        v_root_key_ver := v_active_key_ver;
      ELSE
        v_root_hash24 := v_input_root_hash24;
        v_root_key_ver := COALESCE(v_derived_row.lineage_root_key_version, v_active_key_ver);
      END IF;
    ELSE
      IF NOT (
           internal_guard.verify_lineage_mac(
             'LINEAGE_GEN_V1',
             v_input_root_hash24 || ':gen:' || v_derived_row.idempotency_generation::text,
             v_input_gen_hash24,
             v_derived_row.lineage_idem_key_version
           )
           OR (
             v_derived_row.original_idempotency_key NOT LIKE 'idg-root-%'
             AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(v_derived_row.original_idempotency_key))), 24) = v_input_root_hash24
             AND pg_catalog.left(pg_catalog.md5(pg_catalog.lower(pg_catalog.btrim(v_derived_row.original_idempotency_key)) || ':gen:' || v_derived_row.idempotency_generation::text), 24) = v_input_gen_hash24
           )
           OR (
             v_derived_row.lineage_idem_key_version IS NULL
             AND v_derived_row.original_idempotency_key = ('idg-root-' || v_input_root_hash24)
             AND pg_catalog.left(pg_catalog.md5(v_input_root_hash24 || ':gen:' || v_derived_row.idempotency_generation::text), 24) = v_input_gen_hash24
           )
         ) THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;

      v_root_idem_key := v_derived_row.original_idempotency_key;
      IF v_root_idem_key NOT LIKE 'idg-root-%' AND v_root_idem_key NOT LIKE 'lgpd-%' THEN
        v_root_hash24 := pg_catalog.left(
          internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, v_active_key_ver),
          24
        );
        v_root_key_ver := v_active_key_ver;
      ELSE
        v_root_hash24 := v_input_root_hash24;
        v_root_key_ver := COALESCE(v_derived_row.lineage_root_key_version, v_active_key_ver);
      END IF;
    END IF;
  ELSE
    v_root_idem_key := pg_catalog.left(
      COALESCE(
        NULLIF(v_clean_idem_input, ''),
        internal_guard.compute_lineage_mac('NATURAL_BOOKING_KEY', v_caller_scope_payload, v_active_key_ver)
      ),
      64
    );
    v_root_hash24 := pg_catalog.left(
      internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, v_active_key_ver),
      24
    );
    v_root_key_ver := v_active_key_ver;
  END IF;

  -- Constrói a lista de hashes raiz candidatos em TODAS as versões de chave habilitadas
  v_candidate_root_hashes := ARRAY[v_root_hash24];
  IF v_clean_idem_input LIKE 'idg-%' AND NOT (v_input_root_hash24 = ANY(v_candidate_root_hashes)) THEN
    v_candidate_root_hashes := array_append(v_candidate_root_hashes, v_input_root_hash24);
  END IF;

  IF v_root_idem_key NOT LIKE 'idg-root-%' AND v_root_idem_key NOT LIKE 'lgpd-%' THEN
    FOR r_kver IN
      SELECT k.key_version
      FROM internal_guard.lineage_hmac_keys k
      WHERE k.is_verify_enabled = true
      ORDER BY k.is_current DESC, k.key_version DESC
    LOOP
      v_ver_h24 := pg_catalog.left(
        internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', v_root_idem_key, r_kver.key_version),
        24
      );
      IF NOT (v_ver_h24 = ANY(v_candidate_root_hashes)) THEN
        v_candidate_root_hashes := array_append(v_candidate_root_hashes, v_ver_h24);
      END IF;
    END LOOP;

    -- M02.11-F01: Calcula o identificador legado MD5 da raiz k1 APENAS para localizar
    -- registros históricos já existentes em public.bookings (000013..000016).
    v_legacy_md5_root24 := pg_catalog.left(pg_catalog.md5(v_root_idem_key), 24);
  ELSE
    v_legacy_md5_root24 := NULL;
  END IF;

  FOREACH v_ver_h24 IN ARRAY v_candidate_root_hashes LOOP
    v_candidate_root_aliases := array_append(v_candidate_root_aliases, 'idg-root-' || v_ver_h24);
    v_candidate_idg_prefixes := array_append(v_candidate_idg_prefixes, 'idg-' || v_ver_h24 || '-g%');
    v_candidate_lgpd_prefixes := array_append(v_candidate_lgpd_prefixes, 'lgpd-lin-' || v_ver_h24 || '-%');
  END LOOP;

  -- 1) Trava (FOR UPDATE) e valida TODAS as reservas pertencentes à linhagem
  --    (incluindo registros históricos 000013..000016 com lineage_root_key_version IS NULL)
  FOR v_key_match IN
    SELECT b.*
    FROM public.bookings b
    WHERE b.original_idempotency_key = v_root_idem_key
       OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
       OR b.original_idempotency_key LIKE ANY(v_candidate_lgpd_prefixes)
       OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
       OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
       OR (
         v_legacy_md5_root24 IS NOT NULL
         AND b.lineage_root_key_version IS NULL
         AND (
           b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
           OR b.original_idempotency_key LIKE ('lgpd-lin-' || v_legacy_md5_root24 || '-%')
           OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
         )
       )
    ORDER BY b.idempotency_generation ASC, b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    IF v_key_match.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      v_key_same_owner := (
        (
          internal_guard.verify_lineage_mac(
            'LGPD_OWNER_SCOPE',
            v_caller_scope_payload,
            pg_catalog.substring(v_key_match.original_idempotency_key from 35 for 20),
            v_key_match.lineage_scope_key_version
          )
          OR (
            v_key_match.lineage_scope_key_version IS NULL
            AND v_key_match.hmac_key_version IS NULL
            AND pg_catalog.substring(v_key_match.original_idempotency_key from 35 for 20) = pg_catalog.left(pg_catalog.md5(v_caller_scope_payload), 20)
          )
        )
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    ELSE
      v_key_same_owner := (
        (v_key_match.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_key_match.tourist_user_id OR public.is_admin())
        AND pg_catalog.regexp_replace(v_key_match.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
        AND pg_catalog.lower(pg_catalog.btrim(v_key_match.customer_email)) = v_clean_email
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    END IF;

    IF NOT v_key_same_owner THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: A chave de idempotência informada já pertence a outro titular, outro passeio ou outra data.'
        USING ERRCODE = '23505';
    END IF;
  END LOOP;

  -- 2) Busca reserva existente NÃO ANONIMIZADA na linhagem (inclusive através de rotações e registros históricos)
  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE (
      b.original_idempotency_key = v_root_idem_key
      OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
      OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
      OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
      OR (
        v_legacy_md5_root24 IS NOT NULL
        AND b.lineage_root_key_version IS NULL
        AND (
          b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
          OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
        )
      )
      OR (
        NOT v_has_explicit_key
        AND b.tour_id = v_tour.id
        AND b.booking_date = p_booking_date
        AND pg_catalog.regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      )
    )
    AND b.original_idempotency_key NOT LIKE 'lgpd-%'
    AND b.idempotency_key NOT LIKE 'lgpd-%'
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.idempotency_generation DESC,
    b.created_at DESC,
    b.id DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );

    v_existing_same_owner := (
      (v_existing.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_existing.tourist_user_id OR public.is_admin())
      AND pg_catalog.regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND pg_catalog.lower(pg_catalog.btrim(v_existing.customer_email)) = v_clean_email
      AND v_existing.tour_id = v_tour.id
      AND v_existing.booking_date = p_booking_date
    );
  END IF;

  IF v_existing.id IS NOT NULL AND NOT v_existing_same_owner THEN
    RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação conflitante ou a chave de idempotência pertence a outro titular/passeio/data.'
      USING ERRCODE = '23505';
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'original_idempotency_key', v_existing.original_idempotency_key,
      'idempotency_generation', v_existing.idempotency_generation,
      'hmac_key_version', v_existing.hmac_key_version,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  -- 3) Calcula a próxima geração por MAX(idempotency_generation) + 1 através de TODAS as versões e registros históricos da linhagem
  SELECT COALESCE(MAX(b.idempotency_generation) + 1, 0)::integer
    INTO v_next_generation
  FROM public.bookings b
  WHERE b.original_idempotency_key = v_root_idem_key
     OR b.original_idempotency_key = ANY(v_candidate_root_aliases)
     OR b.original_idempotency_key LIKE ANY(v_candidate_lgpd_prefixes)
     OR pg_catalog.lower(b.idempotency_key) = v_root_idem_key
     OR pg_catalog.lower(b.idempotency_key) LIKE ANY(v_candidate_idg_prefixes)
     OR (
       v_legacy_md5_root24 IS NOT NULL
       AND b.lineage_root_key_version IS NULL
       AND (
         b.original_idempotency_key = ('idg-root-' || v_legacy_md5_root24)
         OR b.original_idempotency_key LIKE ('lgpd-lin-' || v_legacy_md5_root24 || '-%')
         OR pg_catalog.lower(b.idempotency_key) LIKE ('idg-' || v_legacy_md5_root24 || '-g%')
       )
     );

  v_computed_idem_key := public.derive_idempotency_lineage_key(v_root_idem_key, v_next_generation);

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || pg_catalog.lpad((pg_catalog.floor(1000 + pg_catalog.random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || pg_catalog.upper(pg_catalog.substr(pg_catalog.replace(pg_catalog.gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    original_idempotency_key,
    idempotency_generation,
    hmac_key_version,
    lineage_root_key_version,
    lineage_idem_key_version,
    lineage_scope_key_version,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_root_idem_key,
    v_next_generation,
    v_active_key_ver,
    v_root_key_ver,
    v_active_key_ver,
    NULL,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(pg_catalog.btrim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(pg_catalog.btrim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'original_idempotency_key', v_inserted.original_idempotency_key,
    'idempotency_generation', v_inserted.idempotency_generation,
    'hmac_key_version', v_inserted.hmac_key_version,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- Executa o backfill de linhagem para migrar quaisquer registros existentes e registrar
-- as versões de chave HMAC de cada artefato.
DO $$
BEGIN
  PERFORM public.backfill_and_verify_booking_lineage();
END
$$;

-- ----------------------------------------------------------------------------
-- 10. CONSOLIDAÇÃO DE OWNERS, PRIVILÉGIOS MÍNIMOS E ISOLAMENTO DE ORÁCULOS
--     (M02.11-F03 Parte B & M02.11-F05 Parte A — Seções 7B e 9A)
--     - Remove `GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role`;
--     - Revoga EXECUTE de todas as funções internas de internal_guard inclusive para service_role;
--     - Concede EXECUTE a service_role em internal_guard APENAS para:
--         * internal_guard.rotate_lineage_hmac_key(TEXT, BOOLEAN)
--         * internal_guard.manage_lineage_hmac_key_lifecycle(TEXT, SMALLINT, TEXT)
--     - Garante OWNER TO postgres em todas as funções SECURITY DEFINER.
-- ----------------------------------------------------------------------------
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA internal_guard FROM PUBLIC;
REVOKE ALL ON TABLE internal_guard.lineage_hmac_keys FROM PUBLIC;
REVOKE ALL ON TABLE internal_guard.execution_tokens FROM PUBLIC;

DO $$
DECLARE
  r_fn RECORD;
BEGIN
  ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
  ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
    FOR r_fn IN
      SELECT proc_row.oid::regprocedure AS fn_sig
      FROM pg_catalog.pg_proc proc_row
      JOIN pg_catalog.pg_namespace ns_row ON ns_row.oid = proc_row.pronamespace
      WHERE ns_row.nspname IN ('public', 'internal_guard')
        AND proc_row.prosecdef = true
    LOOP
      EXECUTE format('ALTER FUNCTION %s OWNER TO postgres', r_fn.fn_sig);
    END LOOP;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE CREATE ON SCHEMA public FROM anon;
    REVOKE ALL ON SCHEMA internal_guard FROM anon;
    REVOKE ALL ON TABLE internal_guard.lineage_hmac_keys FROM anon;
    REVOKE ALL ON TABLE internal_guard.execution_tokens FROM anon;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM anon;
    ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE CREATE ON SCHEMA public FROM authenticated;
    REVOKE ALL ON SCHEMA internal_guard FROM authenticated;
    REVOKE ALL ON TABLE internal_guard.lineage_hmac_keys FROM authenticated;
    REVOKE ALL ON TABLE internal_guard.execution_tokens FROM authenticated;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM authenticated;
    ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM authenticated;
  END IF;

  FOR r_fn IN
    SELECT
      ns_row.nspname AS schema_name,
      proc_row.oid::regprocedure AS fn_sig
    FROM pg_catalog.pg_proc proc_row
    JOIN pg_catalog.pg_namespace ns_row ON ns_row.oid = proc_row.pronamespace
    WHERE ns_row.nspname IN ('public', 'internal_guard', 'auth')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);
    END IF;
    IF r_fn.schema_name = 'internal_guard' AND EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM service_role', r_fn.fn_sig);
    END IF;
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION auth.uid() TO anon;
    GRANT EXECUTE ON FUNCTION auth.jwt() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION auth.uid() TO authenticated;
    GRANT EXECUTE ON FUNCTION auth.jwt() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT ALL ON SCHEMA public TO service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
    -- M02.11-F03 (Seção 7B): service_role NÃO possui acesso às tabelas de internal_guard
    -- e NÃO recebe EXECUTE genérico nas primitivas internas de MAC ou tokens.
    REVOKE ALL ON ALL TABLES IN SCHEMA internal_guard FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.compute_lineage_mac(TEXT, TEXT, SMALLINT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.verify_lineage_mac(TEXT, TEXT, TEXT, SMALLINT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.require_active_hmac_secret() FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.cleanup_tokens(TEXT, UUID) FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.enforce_lineage_hmac_key_lifecycle() FROM service_role;
    REVOKE ALL ON FUNCTION internal_guard.assert_active_lineage_hmac_key_invariant() FROM service_role;
    GRANT EXECUTE ON FUNCTION internal_guard.rotate_lineage_hmac_key(TEXT, BOOLEAN) TO service_role;
    GRANT EXECUTE ON FUNCTION internal_guard.manage_lineage_hmac_key_lifecycle(TEXT, SMALLINT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.derive_idempotency_lineage_key(TEXT, INTEGER) TO service_role;
    GRANT USAGE ON SCHEMA auth TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA auth TO service_role;
  END IF;
END;
$$;

COMMIT;
