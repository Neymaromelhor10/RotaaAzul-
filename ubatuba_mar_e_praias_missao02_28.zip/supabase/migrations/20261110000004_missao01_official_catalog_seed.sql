-- ============================================================================
-- MIGRATION 0004: SEED OFICIAL IDEMPOTENTE DO CATÁLOGO UBATUBA MAR & PRAIAS (MP-020)
-- Popula parceiros, regras de comissão, embarcações, roteiros, passeios e bloqueios
-- oficiais para garantir integridade referencial das RPCs em banco inicializado.
-- ============================================================================

-- 1. PARCEIROS OFICIAIS
INSERT INTO public.partners (
  id, slug, name, legal_name, cnpj, whatsapp, email, base_marina,
  status, verified, years_operating, bio, avatar_url, rating_avg, reviews_count
) VALUES
  (
    '11111111-1111-4111-8111-111111111101',
    'part-kaimares',
    'Kaimares Náutica & Charter',
    'Kaimares Turismo Náutico Ubatuba Ltda',
    '34.819.201/0001-48',
    '5512997766789',
    'reservas@kaimaresnautica.com.br',
    'Avenida Leovigildo Dias Vieira, Itaguá & Saco da Ribeira',
    'APROVADO',
    true,
    9,
    'Especialistas em lanchas privativas e roteiros compartilhados para a Ilha das Couves, Ilha do Prumirim e Ilha Anchieta com marinheiros habilitados pela Capitania dos Portos.',
    'https://ubatubamarepraias.com.br/media/lancha-kaimares.jpg',
    4.90,
    354
  ),
  (
    '11111111-1111-4111-8111-111111111102',
    'part-rotadomar',
    'Rota do Mar Lanchas',
    'Rota do Mar Operadora Náutica Ltda',
    '29.402.118/0001-90',
    '5512991766084',
    'contato@rotadomarubatuba.com.br',
    'Marina Saco da Ribeira & Píer do Itaguá',
    'APROVADO',
    true,
    12,
    'Frota própria de lanchas cabinadas e open deck de 28 a 38 pés, oferecendo experiências privativas sob medida no litoral norte e sul de Ubatuba.',
    'https://ubatubamarepraias.com.br/media/lancha-rotadomar.jpg',
    5.00,
    418
  ),
  (
    '11111111-1111-4111-8111-111111111103',
    'part-escunascaicara',
    'Escunas Tradicionais Caiçara',
    'Navegação Turística Ilha Anchieta & Norte S/A',
    '18.920.554/0001-12',
    '5512991847933',
    'embarque@escunascaicara.com.br',
    'Píer do Saco da Ribeira e Praia do Itaguá',
    'APROVADO',
    true,
    16,
    'Operadora tradicional de escunas temáticas e familiares com paradas homologadas no Parque Estadual da Ilha Anchieta, Praia das Sete Fontes e Ilha do Prumirim.',
    'https://ubatubamarepraias.com.br/media/escuna-caicara.jpg',
    4.80,
    358
  ),
  (
    '11111111-1111-4111-8111-111111111104',
    'part-nativaeco',
    'Nativa Ecotrilhas & Expedições',
    'Nativa Ecoturismo e Monitoria Ambiental Ltda',
    '41.209.882/0001-05',
    '5512996460990',
    'trilhas@nativaecotrilhas.com.br',
    'Sertão da Quina / Núcleo Picinguaba',
    'PENDENTE',
    true,
    7,
    'Monitores ambientais credenciados pelo Parque Estadual da Serra do Mar para a Trilha da Cachoeira da Água Branca, Sete Praias e Sete Fontes.',
    'https://ubatubamarepraias.com.br/media/nativa-eco.jpg',
    4.90,
    192
  )
ON CONFLICT (slug) DO NOTHING;

-- 2. REGRAS DE COMISSÃO OFICIAIS DOS PARCEIROS
INSERT INTO public.commission_rules (
  id, scope_type, partner_id, tour_id, commission_model,
  commission_rate_percent, commission_fixed_amount, is_active
) VALUES
  (
    '22222222-2222-4222-8222-222222222201',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111101',
    NULL,
    'PERCENTAGE',
    15.00,
    0.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222202',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111102',
    NULL,
    'HYBRID_PERCENT_PLUS_FIXED',
    12.00,
    150.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222203',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111103',
    NULL,
    'FIXED_PER_PASSENGER',
    0.00,
    25.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222204',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111104',
    NULL,
    'PERCENTAGE',
    18.00,
    0.00,
    true
  )
ON CONFLICT DO NOTHING;

-- 3. EMBARCAÇÕES OFICIAIS
INSERT INTO public.vessels (
  id, slug, partner_id, name, vessel_type, operation_mode,
  capacity, length_feet, engine_spec, base_location, description,
  features, structure, safety_equipment, hero_image_url, video_title,
  rating_avg, status, is_active
) VALUES
  (
    '33333333-3333-4333-8333-333333333301',
    'ves-phantom-340',
    '11111111-1111-4111-8111-111111111101',
    'Lancha Oceano Azul 340 (34 Pés)',
    'Lancha',
    'Ambos',
    12,
    34,
    '2x Mercury 250HP 4 Tempos',
    'Píer do Itaguá & Saco da Ribeira',
    'Lancha rápida e confortável com solário de proa acolchoado, plataforma de popa estendida com escada submersível, churrasqueira inox, som Bluetooth marinizado e banheiro fechado.',
    ARRAY['Solário de proa duplo', 'Som Bluetooth Premium', 'Churrasqueira a bordo', 'Toldo retrátil amplo', 'Ducha de água doce'],
    ARRAY['Cabine de apoio com banheiro elétrico', 'Cooler térmico de 120L', 'Plataforma de popa revestida em EVA náutico'],
    ARRAY['Coletes salva-vidas homologados Marinha do Brasil', 'Flutuadores espaguete', 'Rádio VHF e GPS Sonar Garmin'],
    'https://ubatubamarepraias.com.br/media/ves-phantom-340.jpg',
    'Tour a Bordo da Lancha Oceano Azul 340 em Navegação',
    4.90,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333302',
    'ves-focker-280',
    '11111111-1111-4111-8111-111111111102',
    'Lancha Brisa do Norte 280 (28 Pés)',
    'Lancha',
    'Privativo',
    9,
    28,
    'Mercruiser 300HP V8',
    'Marina Saco da Ribeira',
    'Embarcação ágil e exclusiva dedicada a passeios privativos para casais, famílias e pequenos grupos.',
    ARRAY['Exclusiva para Charter Privativo', 'Kit Snorkel e Máscaras a bordo', 'Prancha de Stand Up Paddle inclusa'],
    ARRAY['Toalete reservado', 'Mesa de centro em teca', '2 caixas térmicas integradas'],
    ARRAY['Coletes homologados Classe II e III', 'Boia circular com retinida', 'Rádio VHF e Rastreador Satelital'],
    'https://ubatubamarepraias.com.br/media/ves-focker-280.jpg',
    'Experiência Privativa na Lancha Brisa do Norte 28 Pés',
    5.00,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333303',
    'ves-escuna-corsario',
    '11111111-1111-4111-8111-111111111103',
    'Escuna Tradicional Rainha de Anchieta',
    'Escuna',
    'Compartilhado',
    65,
    62,
    'Scania Marítimo 320HP Diesel',
    'Saco da Ribeira & Praia do Itaguá',
    'Escuna clássica de madeira naval certificada, com amplo convés sombreado, bar de bordo, dois banheiros e bote motorizado de apoio.',
    ARRAY['Amplo convés coberto e solário', 'Bar de bordo', 'Bote de apoio motorizado', 'Guia credenciado a bordo'],
    ARRAY['2 Banheiros', 'Bancos anatômicos com encosto', 'Escadas laterais duplas para mergulho'],
    ARRAY['Balsas salva-vidas rígidas', '75 Coletes homologados pela Capitania dos Portos', 'Tripulação completa'],
    'https://ubatubamarepraias.com.br/media/ves-escuna-corsario.jpg',
    'Navegação na Escuna Rainha de Anchieta pela Baía de Ubatuba',
    4.80,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333304',
    'ves-flexboat-nativa',
    '11111111-1111-4111-8111-111111111104',
    'Flexboat Nativa Eco 26 Pés (Apoio Costeiro & Ilhas)',
    'Catamarã / Flexboat',
    'Ambos',
    14,
    26,
    'Yamaha 200HP 4 Tempos Ecológico',
    'Praia de Picinguaba & Sertão da Quina',
    'Embarcação semirrígida de alta estabilidade homologada para travessias rápidas em Picinguaba e Ilha das Couves.',
    ARRAY['Casco semirrígido insubmersível', 'Escada de popa para mergulhadores', 'Toldo de proteção UV'],
    ARRAY['Bancos náuticos anti-impacto', 'Compartimento estanque', 'Caixa térmica 90L'],
    ARRAY['16 Coletes salva-vidas homologados Classe II', 'Rádio VHF Marítimo e GPS'],
    'https://ubatubamarepraias.com.br/media/ves-flexboat-nativa.jpg',
    'Travessia Ecológica Picinguaba — Ilha das Couves no Flexboat Nativa',
    4.90,
    'APROVADO',
    true
  )
ON CONFLICT (slug) DO NOTHING;

-- 4. ROTEIROS OFICIAIS
INSERT INTO public.itineraries (
  id, slug, title, region, estimated_duration, navigation_level,
  description, stops_count, stops_details, navigation_notes, hero_image_url, video_title, is_active
) VALUES
  (
    '44444444-4444-4444-8444-444444444401',
    'itin-ilhas-norte',
    'Roteiro Ilhas do Norte: Couves, Prumirim e Porcos',
    'Costa Norte',
    '5h30 a 6h30',
    'Costeira Moderada',
    'O roteiro mais desejado pelas águas verde-esmeralda do norte de Ubatuba, combinando paradas na Ilha das Couves, Ilha do Prumirim e Ilha dos Porcos.',
    3,
    ARRAY['Parada 1: Ilha das Couves (1h30)', 'Parada 2: Ilha dos Porcos (1h)', 'Parada 3: Ilha do Prumirim (1h30)'],
    'Saídas confirmadas da Praia do Itaguá (check-in 09h00).',
    'https://ubatubamarepraias.com.br/media/itin-norte.jpg',
    'Mapa Animado e Imagens Aéreas do Roteiro Ilhas do Norte',
    true
  ),
  (
    '44444444-4444-4444-8444-444444444402',
    'itin-sul-anchieta',
    'Roteiro Sul Clássico: Ilha Anchieta & Praia das Sete Fontes',
    'Costa Sul & Ilha Anchieta',
    '5h00 a 6h00',
    'Águas Abrigadas (Calmo)',
    'Navegação por águas abrigadas saindo do Saco da Ribeira rumo ao Parque Estadual da Ilha Anchieta e Praia das Sete Fontes.',
    3,
    ARRAY['Parada 1: Praia do Engenho / Aquário Natural', 'Parada 2: Praia do Presídio ou Palmas', 'Parada 3: Praia das Sete Fontes'],
    'Excelente opção para famílias e pessoas sensíveis ao balanço do mar.',
    'https://ubatubamarepraias.com.br/media/itin-sul.jpg',
    'Roteiro Ilha Anchieta e Sete Fontes: Navegação em Águas Abrigadas',
    true
  )
ON CONFLICT (slug) DO NOTHING;

-- 5. PASSEIOS OFICIAIS (SLUGS ALINHADOS AOS IDS DO FRONTEND)
INSERT INTO public.tours (
  id, slug, partner_id, vessel_id, itinerary_id, title, category,
  tour_type, vessel_type, pricing_model, price, capacity, duration_hours,
  check_in_time, departure_time, return_time, departure_point,
  swimming_stops, included_items, important_info, cancellation_policy,
  status, featured, hero_image_url, video_title, rating_avg, reviews_count
) VALUES
  (
    '55555555-5555-4555-8555-555555555501',
    'tour-lancha-norte-comp',
    '11111111-1111-4111-8111-111111111101',
    '33333333-3333-4333-8333-333333333301',
    '44444444-4444-4444-8444-444444444401',
    'Expedição Ilhas Norte de Lancha: Ilha das Couves, Prumirim e Porcos',
    'Passeios de lancha',
    'Compartilhado',
    'Lancha',
    'POR_PESSOA',
    240.00,
    12,
    5.5,
    '09:00:00',
    '09:30:00',
    '15:00:00',
    'Praia do Itaguá',
    '[{"place":"Ilha das Couves","duration":"1h30","description":"Mergulho em águas cristalinas"}]'::jsonb,
    ARRAY['Marinheiro habilitado pela Capitania dos Portos', 'Combustível', 'Máscara de mergulho e flutuadores'],
    ARRAY['Embarque na Avenida Leovigildo Dias Vieira (Praia do Itaguá).'],
    'Reembolso integral ou remarcação sem custos em caso de interdição marítima/mau tempo ou cancelamento até 48h antes.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-couves.jpg',
    'Passeio de Lancha para Ilha das Couves e Ilha do Prumirim',
    4.90,
    214
  ),
  (
    '55555555-5555-4555-8555-555555555502',
    'tour-lancha-privativa-sul',
    '11111111-1111-4111-8111-111111111102',
    '33333333-3333-4333-8333-333333333302',
    '44444444-4444-4444-8444-444444444402',
    'Charter Lancha Privativa (Até 9 Pessoas): Ilha Anchieta, Sete Fontes & Domingas Dias',
    'Passeios privativos',
    'Privativo',
    'Lancha',
    'POR_EMBARCACAO',
    1850.00,
    9,
    6.0,
    '09:30:00',
    '10:00:00',
    '16:00:00',
    'Saco da Ribeira',
    '[{"place":"Praia do Engenho (Ilha Anchieta)","duration":"1h30","description":"Fundeio próximo às tartarugas"}]'::jsonb,
    ARRAY['Lancha exclusiva para até 9 passageiros', 'Comandante particular e combustível incluso'],
    ARRAY['Saída de marina estruturada no Saco da Ribeira.'],
    'Remarcação garantida em caso de chuva contínua ou vento forte. Cancelamento gratuito até 72h antes.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-privativo-sul.jpg',
    'Dia Completo em Lancha Privativa pela Ilha Anchieta e Sete Fontes',
    5.00,
    168
  ),
  (
    '55555555-5555-4555-8555-555555555503',
    'tour-escuna-anchieta',
    '11111111-1111-4111-8111-111111111103',
    '33333333-3333-4333-8333-333333333303',
    '44444444-4444-4444-8444-444444444402',
    'Passeio Tradicional de Escuna: Ilha Anchieta & Praia das Sete Fontes',
    'Passeios de escuna',
    'Compartilhado',
    'Escuna',
    'POR_PESSOA',
    110.00,
    65,
    5.5,
    '09:30:00',
    '10:00:00',
    '15:30:00',
    'Saco da Ribeira',
    '[{"place":"Parque Estadual da Ilha Anchieta","duration":"2h00","description":"Desembarque no píer da Praia do Presídio"}]'::jsonb,
    ARRAY['Navegação em escuna homologada com guia a bordo', 'Bote motorizado de apoio'],
    ARRAY['Ingresso do Parque Estadual da Ilha Anchieta cobrado à parte.'],
    'Cancelamento sem custos até 24h antes da saída.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-escuna.jpg',
    'Passeio de Escuna para Ilha Anchieta e Praia das Sete Fontes',
    4.80,
    312
  ),
  (
    '55555555-5555-4555-8555-555555555504',
    'tour-familia-prumirim',
    '11111111-1111-4111-8111-111111111101',
    '33333333-3333-4333-8333-333333333301',
    '44444444-4444-4444-8444-444444444401',
    'Experiência Família: Ilha do Prumirim, Praia do Félix & Praia do Português',
    'Passeios para famílias',
    'Privativo',
    'Lancha',
    'POR_EMBARCACAO',
    2100.00,
    12,
    6.0,
    '09:00:00',
    '09:30:00',
    '15:30:00',
    'Praia do Itaguá',
    '[{"place":"Praia do Cedro","duration":"1h15","description":"Águas calmas e cristalinas"}]'::jsonb,
    ARRAY['Lancha privativa de 34 pés para até 12 pessoas', 'Coletes infantis homologados'],
    ARRAY['Roteiro desenhado para priorizar enseadas abrigadas.'],
    'Cancelamento gratuito até 48h antes.',
    'APROVADO',
    false,
    'https://ubatubamarepraias.com.br/media/tour-familia.jpg',
    'Roteiro Família em Águas Calmas: Prumirim, Félix e Cedro',
    5.00,
    94
  )
ON CONFLICT (slug) DO NOTHING;

-- 6. BLOQUEIO DE AGENDA INICIAL
INSERT INTO public.availability_blocks (
  id, partner_id, vessel_id, tour_id, block_date, block_type, reason
) VALUES (
  '66666666-6666-4666-8666-666666666601',
  '11111111-1111-4111-8111-111111111101',
  '33333333-3333-4333-8333-333333333301',
  NULL,
  DATE '2026-11-25',
  'MANUTENCAO',
  'Revisão preventiva programada dos motores Mercury 250HP'
)
ON CONFLICT (id) DO NOTHING;
