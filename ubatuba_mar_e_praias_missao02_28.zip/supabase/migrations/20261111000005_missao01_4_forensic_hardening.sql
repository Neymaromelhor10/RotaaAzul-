-- ============================================================================
-- MIGRATION 0005: MISSÃO 01.4 — ENDURECIMENTO FORENSE DE TOKENS TRANSACIONAIS
-- (SUBSTITUIÇÃO DE SUBSTRINGS PG_CONTEXT POR SCHEMA PRIVADO internal_guard),
-- ELIMINAÇÃO DE INVERSÃO DE LOCK IMPLÍCITO EM availability_blocks E BLINDAGEM RLS
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. SCHEMA PRIVADO DE GUARDA TRANSACIONAL (internal_guard)
-- Inacessível a PUBLIC, anon e authenticated; substitui buscas textuais em PG_CONTEXT
-- por tokens transacionais de uso único verificados e consumidos via DELETE ... RETURNING.
-- ----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS internal_guard;

REVOKE ALL ON SCHEMA internal_guard FROM PUBLIC;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON SCHEMA internal_guard FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE ALL ON SCHEMA internal_guard FROM authenticated;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
  END IF;
END
$$;

CREATE TABLE IF NOT EXISTS internal_guard.execution_tokens (
  id BIGSERIAL PRIMARY KEY,
  txid BIGINT NOT NULL DEFAULT txid_current(),
  trigger_depth INTEGER NOT NULL DEFAULT pg_trigger_depth(),
  scope TEXT NOT NULL CHECK (
    scope IN (
      'AUTH_PROFILE_SYNC',
      'BOOKING_MUTATION',
      'LEDGER_SYNC',
      'LEDGER_SETTLE',
      'CATALOG_RATING_SYNC',
      'AVAILABILITY_BLOCK_MUTATION'
    )
  ),
  target_id UUID NOT NULL,
  expected_state TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS idx_internal_guard_tokens_lookup
  ON internal_guard.execution_tokens(txid, scope, target_id);

ALTER TABLE internal_guard.execution_tokens ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE internal_guard.execution_tokens FROM PUBLIC;
REVOKE ALL ON SEQUENCE internal_guard.execution_tokens_id_seq FROM PUBLIC;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON TABLE internal_guard.execution_tokens FROM anon;
    REVOKE ALL ON SEQUENCE internal_guard.execution_tokens_id_seq FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE ALL ON TABLE internal_guard.execution_tokens FROM authenticated;
    REVOKE ALL ON SEQUENCE internal_guard.execution_tokens_id_seq FROM authenticated;
  END IF;
END
$$;

-- Emite um token transacional de uso único (exclusivo para funções SECURITY DEFINER internas)
CREATE OR REPLACE FUNCTION internal_guard.issue_token(
  p_scope TEXT,
  p_target_id UUID,
  p_expected_state TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
BEGIN
  INSERT INTO internal_guard.execution_tokens (txid, trigger_depth, scope, target_id, expected_state)
  VALUES (txid_current(), pg_trigger_depth(), p_scope, p_target_id, p_expected_state);
END;
$$;

-- Consome atomicamente um token transacional de uso único (retorna true se e somente se existir e for válido)
CREATE OR REPLACE FUNCTION internal_guard.consume_token(
  p_scope TEXT,
  p_target_id UUID,
  p_expected_state TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, internal_guard, pg_temp
AS $$
DECLARE
  v_token_id BIGINT;
BEGIN
  DELETE FROM internal_guard.execution_tokens
  WHERE id = (
    SELECT t.id
    FROM internal_guard.execution_tokens t
    WHERE t.txid = txid_current()
      AND t.scope = p_scope
      AND t.target_id = p_target_id
      AND (p_expected_state IS NULL OR t.expected_state IS NOT DISTINCT FROM p_expected_state)
    ORDER BY t.id DESC
    LIMIT 1
  )
  RETURNING id INTO v_token_id;

  RETURN (v_token_id IS NOT NULL);
END;
$$;

REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM PUBLIC;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE ALL ON FUNCTION internal_guard.issue_token(TEXT, UUID, TEXT) FROM authenticated;
    REVOKE ALL ON FUNCTION internal_guard.consume_token(TEXT, UUID, TEXT) FROM authenticated;
  END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- 2. SUBSTITUIÇÃO DE PG_CONTEXT POR TOKEN UNFORGEABLE EM PROFILES (Seção 6)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_updated_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_email TEXT;
  v_role_str TEXT;
BEGIN
  v_email := lower(trim(COALESCE(NEW.email, OLD.email, '')));
  IF v_email <> '' AND position('@' in v_email) > 1 AND NEW.email IS DISTINCT FROM OLD.email THEN
    PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', NEW.id, v_email);
    UPDATE public.profiles
    SET email = v_email,
        updated_at = now()
    WHERE id = NEW.id;
  END IF;

  IF NEW.raw_app_meta_data IS DISTINCT FROM OLD.raw_app_meta_data THEN
    v_role_str := lower(trim(COALESCE(NEW.raw_app_meta_data->>'system_role', NEW.raw_app_meta_data->>'role', '')));
    IF v_role_str IN ('tourist', 'partner', 'admin') THEN
      PERFORM internal_guard.issue_token('AUTH_PROFILE_SYNC', NEW.id, v_role_str);
      UPDATE public.profiles
      SET system_role = v_role_str::public.app_role,
          updated_at = now()
      WHERE id = NEW.id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.protect_profile_privileged_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_jwt_role TEXT;
  v_db_role TEXT;
  v_auth_email TEXT;
  v_auth_role_str TEXT;
  v_auth_expected_role public.app_role;
BEGIN
  IF NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'PROFILE_IMMUTABLE_ID: Não é permitido alterar o identificador do perfil.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.system_role IS NOT DISTINCT FROM OLD.system_role
     AND NEW.is_active IS NOT DISTINCT FROM OLD.is_active
     AND NEW.email IS NOT DISTINCT FROM OLD.email THEN
    RETURN NEW;
  END IF;

  v_uid := (SELECT auth.uid());
  v_jwt_role := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    ((SELECT auth.jwt()) ->> 'role'),
    ''
  );
  v_db_role := COALESCE(NULLIF(current_setting('role', true), ''), 'none');

  -- Caso A: Sincronização disparada por auth.users comprovada por token de uso único em internal_guard + paridade com auth.users
  IF pg_trigger_depth() >= 2 THEN
    SELECT lower(trim(u.email)),
           lower(trim(COALESCE(u.raw_app_meta_data->>'system_role', u.raw_app_meta_data->>'role', '')))
      INTO v_auth_email, v_auth_role_str
    FROM auth.users u
    WHERE u.id = NEW.id;

    v_auth_expected_role := CASE
      WHEN v_auth_role_str IN ('tourist', 'partner', 'admin') THEN v_auth_role_str::public.app_role
      ELSE OLD.system_role
    END;

    IF (
         (NEW.email IS DISTINCT FROM OLD.email AND internal_guard.consume_token('AUTH_PROFILE_SYNC', NEW.id, v_auth_email))
         OR (NEW.system_role IS DISTINCT FROM OLD.system_role AND internal_guard.consume_token('AUTH_PROFILE_SYNC', NEW.id, v_auth_expected_role::text))
       )
       AND (NEW.email IS NOT DISTINCT FROM OLD.email OR NEW.email = v_auth_email)
       AND (NEW.system_role IS NOT DISTINCT FROM OLD.system_role OR NEW.system_role = v_auth_expected_role)
       AND (NEW.is_active IS NOT DISTINCT FROM OLD.is_active) THEN
      RETURN NEW;
    END IF;
  END IF;

  -- Caso B: Administrador autenticado e ativo no banco
  IF v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin() THEN
    RETURN NEW;
  END IF;

  -- Caso C: Operação administrativa de backend via service_role ou superuser puro
  IF v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND v_uid IS NULL
     AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'supabase_auth_admin', 'service_role') THEN
    RETURN NEW;
  END IF;

  IF NEW.system_role IS DISTINCT FROM OLD.system_role THEN
    RAISE EXCEPTION 'PROFILE_ROLE_ESCALATION_FORBIDDEN: Somente administradores podem alterar o papel (system_role) do usuário.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
    RAISE EXCEPTION 'PROFILE_ACTIVE_STATUS_FORBIDDEN: Somente administradores podem alterar o status ativo do perfil.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'PROFILE_EMAIL_DIRECT_CHANGE_FORBIDDEN: O e-mail deve ser atualizado via Supabase Auth.'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. ELIMINAÇÃO DE INVERSÃO DE LOCK IMPLÍCITO EM availability_blocks (Seção 7)
-- Toda escrita/atualização/exclusão em availability_blocks passa por RPCs que
-- adquirem Lock #1 (vessels FOR UPDATE) e Lock #2 (advisory_lock) ANTES de
-- tocar na tabela availability_blocks, emitindo token em internal_guard.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.validate_availability_block_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
  v_tour_partner UUID;
  v_tour_vessel UUID;
  v_active_confirmed INTEGER := 0;
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_server_seed BOOLEAN;
BEGIN
  v_is_server_seed := (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
                       AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  -- Em UPDATE de availability_blocks, exige obrigatoriamente que a chamada venha da RPC upsert_availability_block
  -- (que já adquiriu Lock #1 em vessels e Lock #2 advisory_lock antes do lock implícito da linha em availability_blocks!)
  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.block_date IS DISTINCT FROM OLD.block_date THEN
      RAISE EXCEPTION 'BLOCK_IMMUTABLE_KEYS: Não é permitido alterar embarcação, parceiro ou data de um bloqueio existente; exclua e recrie via RPC.'
        USING ERRCODE = '42501';
    END IF;

    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_UPDATE_FORBIDDEN: Atualização direta em availability_blocks é proibida para evitar inversão da ordem de locks. Utilize public.upsert_availability_block().'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_OP = 'INSERT' THEN
    -- Se não consumiu token da RPC (ex: INSERT direto em SQL), adquire Lock #1 (vessels FOR UPDATE) e Lock #2 (advisory_lock) agora
    -- (No INSERT, a tupla ainda não existe no heap antes da trigger BEFORE INSERT, logo não há inversão de lock implícito).
    IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', NEW.vessel_id, NEW.block_date::text) THEN
      IF NOT v_is_server_seed AND NOT public.is_admin() AND NOT public.is_partner_member(NEW.partner_id) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Sem permissão para criar bloqueio nesta embarcação.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  END IF;

  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels
  WHERE id = NEW.vessel_id
  FOR UPDATE;

  IF v_vessel_partner IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', NEW.vessel_id
      USING ERRCODE = '23503';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(NEW.block_date::text));

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'BLOCK_VESSEL_OWNERSHIP_MISMATCH: A embarcação bloqueada não pertence ao parceiro informado.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS NOT NULL THEN
    SELECT partner_id, vessel_id INTO v_tour_partner, v_tour_vessel
    FROM public.tours
    WHERE id = NEW.tour_id;

    IF v_tour_partner IS DISTINCT FROM NEW.partner_id OR v_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
      RAISE EXCEPTION 'BLOCK_TOUR_MISMATCH: O passeio informado no bloqueio não pertence à mesma embarcação/parceiro.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override > v_vessel_cap THEN
    RAISE EXCEPTION 'OVERRIDE_EXCEEDS_VESSEL_CAPACITY: Ajuste de capacidade (%) excede a capacidade máxima da embarcação (%).',
      NEW.custom_capacity_override, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  SELECT COALESCE(SUM(passengers), 0)::integer INTO v_active_confirmed
  FROM public.bookings
  WHERE vessel_id = NEW.vessel_id
    AND booking_date = NEW.block_date
    AND status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA');

  IF NEW.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') AND v_active_confirmed > 0 THEN
    RAISE EXCEPTION 'BLOCK_CONFLICTS_WITH_CONFIRMED_BOOKINGS: Não é possível aplicar % em % pois já existem % passageiros confirmados na data.',
      NEW.block_type, NEW.block_date, v_active_confirmed
      USING ERRCODE = 'P0001';
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override < v_active_confirmed THEN
    RAISE EXCEPTION 'OVERRIDE_BELOW_OCCUPIED_SEATS: Ajuste de capacidade (%) é inferior aos % passageiros já confirmados na data %.',
      NEW.custom_capacity_override, v_active_confirmed, NEW.block_date
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;

-- Trigger BEFORE DELETE em availability_blocks exigindo passagem pela RPC delete_availability_block (que adquire Lock #1 vessels primeiro)
CREATE OR REPLACE FUNCTION public.validate_availability_block_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
BEGIN
  IF NOT internal_guard.consume_token('AVAILABILITY_BLOCK_MUTATION', OLD.vessel_id, OLD.block_date::text) THEN
    RAISE EXCEPTION 'DIRECT_AVAILABILITY_BLOCK_DELETE_FORBIDDEN: Exclusão direta em availability_blocks é proibida para preservar a ordem de locks. Utilize public.delete_availability_block().'
      USING ERRCODE = '42501';
  END IF;
  RETURN OLD;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_availability_block_delete ON public.availability_blocks;
CREATE TRIGGER trg_validate_availability_block_delete
  BEFORE DELETE ON public.availability_blocks
  FOR EACH ROW EXECUTE FUNCTION public.validate_availability_block_delete();

-- RPC 8: upsert_availability_block — Cria ou atualiza bloqueio de agenda respeitando Lock #1 (vessels) -> Lock #2 (advisory_lock) -> Lock #3 (availability_blocks)
CREATE OR REPLACE FUNCTION public.upsert_availability_block(
  p_vessel_id TEXT,
  p_block_date DATE,
  p_block_type TEXT,
  p_reason TEXT DEFAULT NULL,
  p_custom_capacity_override SMALLINT DEFAULT NULL,
  p_tour_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_vessel RECORD;
  v_resolved_tour_id UUID := NULL;
  v_existing_id UUID;
  v_result public.availability_blocks;
  v_clean_vessel TEXT := trim(COALESCE(p_vessel_id, ''));
BEGIN
  IF v_clean_vessel = '' OR p_block_date IS NULL THEN
    RAISE EXCEPTION 'INVALID_BLOCK_INPUT: Embarcação e data são obrigatórias.'
      USING ERRCODE = '23514';
  END IF;

  -- Localiza a embarcação e adquire Lock #1 (vessels FOR UPDATE) ANTES de qualquer operação em availability_blocks
  SELECT id, partner_id, name, capacity
    INTO v_vessel
  FROM public.vessels
  WHERE id::text = v_clean_vessel OR slug = v_clean_vessel
  FOR UPDATE;

  IF v_vessel.id IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', v_clean_vessel
      USING ERRCODE = 'P0002';
  END IF;

  IF NOT (public.is_admin() OR public.is_partner_member(v_vessel.partner_id)
          OR ((SELECT auth.uid()) IS NULL AND COALESCE(NULLIF(current_setting('role', true), ''), 'none') IN ('none', 'postgres', 'service_role'))) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Você não possui permissão para gerenciar a agenda desta embarcação.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_block_date::text));

  IF p_tour_id IS NOT NULL AND trim(p_tour_id) <> '' THEN
    v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  END IF;

  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_vessel.id, p_block_date::text);

  SELECT id INTO v_existing_id
  FROM public.availability_blocks
  WHERE vessel_id = v_vessel.id
    AND block_date = p_block_date
    AND block_type = p_block_type
  FOR UPDATE;

  IF v_existing_id IS NOT NULL THEN
    UPDATE public.availability_blocks
    SET custom_capacity_override = p_custom_capacity_override,
        reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional atualizado'),
        tour_id = v_resolved_tour_id
    WHERE id = v_existing_id
    RETURNING * INTO v_result;
  ELSE
    INSERT INTO public.availability_blocks (
      partner_id,
      vessel_id,
      tour_id,
      block_date,
      block_type,
      custom_capacity_override,
      reason,
      created_by
    ) VALUES (
      v_vessel.partner_id,
      v_vessel.id,
      v_resolved_tour_id,
      p_block_date,
      p_block_type,
      p_custom_capacity_override,
      COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), 'Bloqueio operacional agendado'),
      (SELECT auth.uid())
    )
    RETURNING * INTO v_result;
  END IF;

  RETURN to_jsonb(v_result);
END;
$$;

-- RPC 9: delete_availability_block — Remove bloqueio de agenda respeitando Lock #1 (vessels) -> Lock #2 (advisory_lock) -> Lock #3 (availability_blocks)
CREATE OR REPLACE FUNCTION public.delete_availability_block(
  p_block_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_block RECORD;
BEGIN
  -- 1. Lê identificadores sem lock para adquirir Lock #1 (vessels) primeiro
  SELECT id, partner_id, vessel_id, block_date, block_type
    INTO v_block
  FROM public.availability_blocks
  WHERE id = p_block_id;

  IF v_block.id IS NULL THEN
    RAISE EXCEPTION 'BLOCK_NOT_FOUND: Bloqueio de agenda (%) não encontrado.', p_block_id
      USING ERRCODE = 'P0002';
  END IF;

  IF NOT (public.is_admin() OR public.is_partner_member(v_block.partner_id)
          OR ((SELECT auth.uid()) IS NULL AND COALESCE(NULLIF(current_setting('role', true), ''), 'none') IN ('none', 'postgres', 'service_role'))) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_AVAILABILITY_BLOCK: Sem permissão para remover este bloqueio.'
      USING ERRCODE = '42501';
  END IF;

  -- Lock #1: Embarcação em public.vessels (FOR UPDATE)
  PERFORM 1 FROM public.vessels WHERE id = v_block.vessel_id FOR UPDATE;

  -- Lock #2: Advisory Lock (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_block.vessel_id::text), hashtext(v_block.block_date::text));

  -- Emite token de uso único e executa DELETE (Lock #3)
  PERFORM internal_guard.issue_token('AVAILABILITY_BLOCK_MUTATION', v_block.vessel_id, v_block.block_date::text);

  DELETE FROM public.availability_blocks WHERE id = v_block.id;

  RETURN jsonb_build_object(
    'deleted', true,
    'id', v_block.id,
    'vessel_id', v_block.vessel_id,
    'block_date', v_block.block_date
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. SUBSTITUIÇÃO DE PG_CONTEXT POR TOKENS EM BOOKINGS, LEDGER E AVALIAÇÕES (Seções 6, 7 e 9)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    -- Comprova mediante consumo atômico de token em internal_guard que a atualização veio de uma das RPCs canônicas
    -- (transition_booking_status, admin_update_booking ou expire_stale_bookings) que já adquiriram Lock #1 (vessels) e Lock #2 (advisory_lock).
    IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
      RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
       OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.sync_booking_history_ledger_and_audit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_actor_role public.app_role;
  v_next_ledger_status public.ledger_status_type;
BEGIN
  v_uid := (SELECT auth.uid());
  v_actor_role := public.resolve_booking_actor_role(NEW.partner_id, NEW.tourist_user_id);

  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      NULL,
      NEW.status,
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      COALESCE(NEW.notes, 'Solicitação inicial de reserva criada')
    );

    PERFORM internal_guard.issue_token('LEDGER_SYNC', NEW.id, 'PREVISTA');

    INSERT INTO public.commission_ledger (
      booking_id,
      partner_id,
      tour_id,
      ledger_status,
      gross_amount,
      commission_amount,
      net_partner_amount,
      rule_snapshot_json
    ) VALUES (
      NEW.id,
      NEW.partner_id,
      NEW.tour_id,
      'PREVISTA',
      NEW.gross_amount,
      NEW.commission_amount,
      NEW.net_partner_amount,
      jsonb_build_object(
        'commission_rule_id', NEW.commission_rule_id,
        'commission_model', NEW.commission_model_snapshot,
        'commission_rate', NEW.commission_rate_snapshot,
        'commission_fixed', NEW.commission_fixed_snapshot,
        'commission_rule_label', NEW.commission_rule_label
      )
    )
    ON CONFLICT (booking_id) DO NOTHING;

    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      'bookings',
      NEW.code,
      'CREATE_BOOKING',
      NULL,
      to_jsonb(NEW)
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      v_uid,
      v_actor_role,
      COALESCE(NEW.rejection_or_cancel_reason, 'Transição de status validada pelo servidor')
    );

    IF NEW.status = 'PASSEIO_REALIZADO' THEN
      v_next_ledger_status := 'CONFIRMADA';
    ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') THEN
      v_next_ledger_status := 'REVERTIDA';
    ELSIF NEW.status = 'EM_DISPUTA' THEN
      v_next_ledger_status := 'EM_DISPUTA';
    ELSE
      v_next_ledger_status := 'PREVISTA';
    END IF;

    PERFORM internal_guard.issue_token('LEDGER_SYNC', NEW.id, v_next_ledger_status::text);

    UPDATE public.commission_ledger
    SET ledger_status = CASE
          WHEN ledger_status = 'PAGA' AND v_next_ledger_status = 'CONFIRMADA' THEN 'PAGA'::public.ledger_status_type
          ELSE v_next_ledger_status
        END,
        consolidated_at = CASE
          WHEN NEW.status = 'PASSEIO_REALIZADO' THEN COALESCE(consolidated_at, now())
          ELSE consolidated_at
        END,
        reversed_at = CASE
          WHEN NEW.status IN ('CANCELADA', 'RECUSADA') THEN COALESCE(reversed_at, now())
          ELSE reversed_at
        END,
        adjustment_notes = COALESCE(NEW.rejection_or_cancel_reason, adjustment_notes),
        updated_by = v_uid,
        updated_at = now()
    WHERE booking_id = NEW.id;

    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      v_actor_role,
      'bookings',
      NEW.code,
      'STATUS_TRANSITION',
      jsonb_build_object('status', OLD.status),
      jsonb_build_object(
        'status', NEW.status,
        'reason', NEW.rejection_or_cancel_reason,
        'ledger_status', v_next_ledger_status
      )
    );
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.enforce_commission_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_expected_ledger_status public.ledger_status_type;
BEGIN
  SELECT id, partner_id, tour_id, status, gross_amount, commission_amount, net_partner_amount
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_BOOKING_NOT_FOUND: Reserva (%) não encontrada para o livro-razão.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Os valores financeiros e vínculos do livro-razão devem corresponder exatamente à reserva e são imutáveis.'
      USING ERRCODE = '42501';
  END IF;

  v_expected_ledger_status := CASE
    WHEN v_booking.status = 'PASSEIO_REALIZADO' THEN 'CONFIRMADA'::public.ledger_status_type
    WHEN v_booking.status IN ('CANCELADA', 'RECUSADA') THEN 'REVERTIDA'::public.ledger_status_type
    WHEN v_booking.status = 'EM_DISPUTA' THEN 'EM_DISPUTA'::public.ledger_status_type
    ELSE 'PREVISTA'::public.ledger_status_type
  END;

  IF TG_OP = 'INSERT' THEN
    IF pg_trigger_depth() < 2
       OR NEW.ledger_status <> 'PREVISTA'
       OR NOT internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'PREVISTA') THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_INSERT_FORBIDDEN: O registro no livro-razão é criado exclusivamente pela trigger sync_booking_history_ledger_and_audit com status PREVISTA.'
        USING ERRCODE = '42501';
    END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id OR NEW.booking_id IS DISTINCT FROM OLD.booking_id THEN
      RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Identificadores do livro-razão são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    -- Caso 1: Liquidação financeira ('CONFIRMADA' -> 'PAGA') via RPC settle_commission_ledger
    IF NEW.ledger_status = 'PAGA' AND OLD.ledger_status = 'CONFIRMADA' THEN
      IF v_booking.status IS DISTINCT FROM 'PASSEIO_REALIZADO' THEN
        RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Comissão só pode ser paga quando a reserva estiver em PASSEIO_REALIZADO.'
          USING ERRCODE = '23514';
      END IF;
      IF NOT internal_guard.consume_token('LEDGER_SETTLE', NEW.booking_id, 'PAGA') THEN
        RAISE EXCEPTION 'LEDGER_DIRECT_SETTLE_FORBIDDEN: A liquidação para PAGA deve ser executada exclusivamente via RPC public.settle_commission_ledger().'
          USING ERRCODE = '42501';
      END IF;
      NEW.paid_at := COALESCE(NEW.paid_at, now());
      RETURN NEW;
    END IF;

    -- Caso 2: Sincronização automática via token LEDGER_SYNC emitido por sync_booking_history_ledger_and_audit
    IF pg_trigger_depth() >= 2
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, v_expected_ledger_status::text)
       AND (
         NEW.ledger_status = v_expected_ledger_status
         OR (OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' AND v_booking.status = 'PASSEIO_REALIZADO')
       ) THEN
      RETURN NEW;
    END IF;

    IF OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' THEN
      RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão desta reserva já foi liquidada anteriormente em %.', OLD.paid_at
        USING ERRCODE = '23514';
    END IF;

    RAISE EXCEPTION 'LEDGER_DIRECT_STATUS_FORBIDDEN: O status do livro-razão (%) não pode divergir do estado da reserva (%) nem ser alterado fora da máquina de estados.',
      NEW.ledger_status, v_booking.status
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.recalculate_ratings_after_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_tour_id UUID := COALESCE(NEW.tour_id, OLD.tour_id);
  v_partner_id UUID := COALESCE(NEW.partner_id, OLD.partner_id);
BEGIN
  PERFORM internal_guard.issue_token('CATALOG_RATING_SYNC', v_tour_id, 'tours');
  UPDATE public.tours
  SET rating_avg = COALESCE((
        SELECT ROUND(AVG(rating)::numeric, 2)
        FROM public.reviews
        WHERE tour_id = v_tour_id AND is_published = true
      ), 5.00),
      reviews_count = (
        SELECT COUNT(*)::integer
        FROM public.reviews
        WHERE tour_id = v_tour_id AND is_published = true
      )
  WHERE id = v_tour_id;

  PERFORM internal_guard.issue_token('CATALOG_RATING_SYNC', v_partner_id, 'partners');
  UPDATE public.partners
  SET rating_avg = COALESCE((
        SELECT ROUND(AVG(rating)::numeric, 2)
        FROM public.reviews
        WHERE partner_id = v_partner_id AND is_published = true
      ), 5.00),
      reviews_count = (
        SELECT COUNT(*)::integer
        FROM public.reviews
        WHERE partner_id = v_partner_id AND is_published = true
      )
  WHERE id = v_partner_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_admin_or_server BOOLEAN;
  v_max_tour_cap SMALLINT;
  v_max_occupied_date RECORD;
  v_confirmed_count INTEGER;
BEGIN
  IF TG_TABLE_NAME = 'vessels' AND TG_OP = 'UPDATE' THEN
    IF NEW.capacity < OLD.capacity THEN
      SELECT MAX(capacity) INTO v_max_tour_cap
      FROM public.tours
      WHERE vessel_id = NEW.id;

      IF v_max_tour_cap IS NOT NULL AND NEW.capacity < v_max_tour_cap THEN
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_TOUR: A nova capacidade da embarcação (%) é menor que a capacidade configurada em passeio vinculado (%).',
          NEW.capacity, v_max_tour_cap
          USING ERRCODE = '23514';
      END IF;

      FOR v_max_occupied_date IN
        SELECT booking_date, SUM(passengers)::integer AS total_pax
        FROM (
          SELECT bk.booking_date, bk.passengers
          FROM public.bookings bk
          WHERE bk.vessel_id = NEW.id
            AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
          ORDER BY bk.booking_date, bk.id
          FOR UPDATE
        ) locked_bk
        GROUP BY booking_date
        HAVING SUM(passengers) > NEW.capacity
        LIMIT 1
      LOOP
        RAISE EXCEPTION 'VESSEL_CAPACITY_BELOW_ACTIVE_BOOKINGS: Não é possível reduzir a capacidade para % pois a data % já possui % passageiros reservados.',
          NEW.capacity, v_max_occupied_date.booking_date, v_max_occupied_date.total_pax
          USING ERRCODE = 'P0001';
      END LOOP;
    END IF;

    IF (NEW.is_active = false AND OLD.is_active = true) OR (NEW.status <> 'APROVADO' AND OLD.status = 'APROVADO') THEN
      SELECT COUNT(*)::integer INTO v_confirmed_count
      FROM public.bookings
      WHERE vessel_id = NEW.id
        AND status = 'CONFIRMADA';

      IF v_confirmed_count > 0 THEN
        RAISE EXCEPTION 'VESSEL_HAS_CONFIRMED_BOOKINGS: Não é possível desativar ou suspender a embarcação enquanto existirem % reservas confirmadas pendentes de realização.',
          v_confirmed_count
          USING ERRCODE = 'P0001';
      END IF;
    END IF;
  END IF;

  -- Verifica se é atualização automática de rating_avg/reviews_count disparada por recalculate_ratings_after_review via token de uso único
  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    IF internal_guard.consume_token('CATALOG_RATING_SYNC', NEW.id, TG_TABLE_NAME) THEN
      IF TG_TABLE_NAME = 'partners'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.slug IS NOT DISTINCT FROM OLD.slug
         AND NEW.cnpj IS NOT DISTINCT FROM OLD.cnpj
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.verified IS NOT DISTINCT FROM OLD.verified THEN
        RETURN NEW;
      ELSIF TG_TABLE_NAME = 'tours'
         AND NEW.id IS NOT DISTINCT FROM OLD.id
         AND NEW.partner_id IS NOT DISTINCT FROM OLD.partner_id
         AND NEW.status IS NOT DISTINCT FROM OLD.status
         AND NEW.featured IS NOT DISTINCT FROM OLD.featured THEN
        RETURN NEW;
      END IF;
    END IF;
  END IF;

  v_is_admin_or_server := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF v_is_admin_or_server THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status NOT IN ('PENDENTE_APROVACAO', 'APROVADO') THEN
        RAISE EXCEPTION 'VESSEL_INVALID_INITIAL_STATUS: Status inicial inválido para embarcação.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem reativar embarcação suspensa ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' AND TG_OP = 'INSERT' THEN
    IF NEW.owner_type <> 'PARTNER' OR NEW.authorized = true THEN
      RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem aguardar autorização administrativa.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Atualiza as RPCs de mutação de reserva e liquidação para emitirem tokens de uso único em internal_guard
CREATE OR REPLACE FUNCTION public.transition_booking_status(
  p_booking_id TEXT,
  p_new_status public.booking_status_type,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_actor_role public.app_role;
  v_ledger_status public.ledger_status_type;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
BEGIN
  IF v_clean_id = '' THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: Identificador ou código da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_actor_role := public.resolve_booking_actor_role(v_target.partner_id, v_target.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Você não possui permissão sobre a reserva %.', v_target.code
      USING ERRCODE = '42501';
  END IF;

  -- Hierarquia canônica de bloqueio: Lock #1 Embarcação FOR UPDATE, Lock #2 Advisory Lock (embarcação+data), Lock #3 Reserva FOR UPDATE
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF p_new_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', v_target.code, v_target.status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, p_new_status::text);

  UPDATE public.bookings
  SET status = p_new_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'commission_consolidated', (v_updated.status = 'PASSEIO_REALIZADO'),
    'rejection_or_cancel_reason', v_updated.rejection_or_cancel_reason,
    'confirmed_at', v_updated.confirmed_at,
    'completed_at', v_updated.completed_at,
    'cancelled_at', v_updated.cancelled_at,
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.expire_stale_bookings()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_rec RECORD;
  v_expired_count INTEGER := 0;
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
BEGIN
  IF (v_db_role IN ('anon', 'authenticated') OR v_jwt_role IN ('anon', 'authenticated'))
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'UNAUTHORIZED_EXPIRATION_CALL: Apenas service_role ou administrador pode executar a rotina de expiração.'
      USING ERRCODE = '42501';
  END IF;

  FOR v_rec IN
    SELECT id, vessel_id, booking_date
    FROM public.bookings
    WHERE status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    ORDER BY vessel_id, booking_date, id
  LOOP
    PERFORM 1 FROM public.vessels WHERE id = v_rec.vessel_id FOR UPDATE;
    PERFORM pg_advisory_xact_lock(hashtext(v_rec.vessel_id::text), hashtext(v_rec.booking_date::text));

    PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_rec.id, 'CANCELADA');

    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = 'Reserva expirada automaticamente por decurso do prazo de confirmação (SLA 48h)',
        cancelled_at = now(),
        updated_at = now()
    WHERE id = v_rec.id
      AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO');

    IF FOUND THEN
      v_expired_count := v_expired_count + 1;
    END IF;
  END LOOP;

  RETURN v_expired_count;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_update_booking(
  p_booking_id TEXT,
  p_new_booking_date DATE DEFAULT NULL,
  p_new_passengers SMALLINT DEFAULT NULL,
  p_new_status public.booking_status_type DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN;
  v_eff_date DATE;
  v_eff_pax SMALLINT;
  v_eff_status public.booking_status_type;
  v_date_min DATE;
  v_date_max DATE;
  v_ledger_status public.ledger_status_type;
BEGIN
  v_is_authorized_admin := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Somente administradores podem executar admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_eff_date := COALESCE(p_new_booking_date, v_target.booking_date);
  v_eff_pax := COALESCE(p_new_passengers, v_target.passengers);
  v_eff_status := COALESCE(p_new_status, v_target.status);

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;

  v_date_min := LEAST(v_target.booking_date, v_eff_date);
  v_date_max := GREATEST(v_target.booking_date, v_eff_date);
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_min::text));
  IF v_date_max IS DISTINCT FROM v_date_min THEN
    PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_max::text));
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF v_eff_date IS NOT DISTINCT FROM v_target.booking_date
     AND v_eff_pax IS NOT DISTINCT FROM v_target.passengers
     AND v_eff_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_BOOKING_UPDATE: Nenhuma alteração efetiva de data, passageiros ou status foi solicitada para a reserva %.', v_target.code
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, v_eff_status::text);

  UPDATE public.bookings
  SET booking_date = v_eff_date,
      passengers = v_eff_pax,
      status = v_eff_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'booking_date', v_updated.booking_date,
    'passengers', v_updated.passengers,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.settle_commission_ledger(
  p_booking_id TEXT,
  p_adjustment_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_ledger public.commission_ledger;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN;
BEGIN
  v_is_authorized_admin := (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
    OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
        AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role'));

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));
  PERFORM 1 FROM public.bookings WHERE id = v_booking.id FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_ledger.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_NOT_FOUND: Registro financeiro não encontrado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF v_ledger.ledger_status = 'PAGA' THEN
    RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão da reserva % já foi liquidada em %.', v_booking.code, v_ledger.paid_at
      USING ERRCODE = '23514';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' OR v_ledger.ledger_status <> 'CONFIRMADA' THEN
    RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (atual: reserva=%, ledger=%).',
      v_booking.status, v_ledger.ledger_status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('LEDGER_SETTLE', v_booking.id, 'PAGA');

  UPDATE public.commission_ledger
  SET ledger_status = 'PAGA',
      paid_at = now(),
      adjustment_notes = COALESCE(NULLIF(trim(COALESCE(p_adjustment_notes, '')), ''), adjustment_notes),
      updated_by = v_uid,
      updated_at = now()
  WHERE id = v_ledger.id
  RETURNING * INTO v_ledger;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'commission_ledger',
    v_booking.code,
    'SETTLE_COMMISSION',
    jsonb_build_object('ledger_status', 'CONFIRMADA'),
    jsonb_build_object('ledger_status', 'PAGA', 'paid_at', v_ledger.paid_at, 'commission_amount', v_ledger.commission_amount)
  );

  RETURN jsonb_build_object(
    'ledger_id', v_ledger.id,
    'booking_id', v_booking.id,
    'booking_code', v_booking.code,
    'ledger_status', v_ledger.ledger_status,
    'gross_amount', v_ledger.gross_amount,
    'commission_amount', v_ledger.commission_amount,
    'net_partner_amount', v_ledger.net_partner_amount,
    'paid_at', v_ledger.paid_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. AJUSTE FINO DE POLÍTICAS RLS E PERMISSÕES PARA availability_blocks E commission_ledger
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "availability_blocks_partner_write" ON public.availability_blocks;
CREATE POLICY "availability_blocks_partner_insert" ON public.availability_blocks
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "ledger_admin_update" ON public.commission_ledger;

DO $$
DECLARE
  r_fn RECORD;
BEGIN
  -- Revoga EXECUTE default de PUBLIC em todas as funções de public e internal_guard
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON public.bookings, public.commission_ledger, public.booking_status_history, public.audit_logs FROM authenticated;
    REVOKE UPDATE, DELETE, TRUNCATE ON public.availability_blocks FROM authenticated;
    REVOKE DELETE, TRUNCATE ON public.profiles FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    FOR r_fn IN
      SELECT p.oid::regprocedure AS fn_sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('public', 'internal_guard')
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END LOOP;
  END IF;
END
$$;
