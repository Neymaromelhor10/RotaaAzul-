-- ============================================================================
-- MIGRATION 0015: MISSÃO 02.8 — AUDITORIA INDEPENDENTE DA MIGRATION 000014,
-- INTEGRIDADE DE LINHAGEM SOB ANONIMIZAÇÃO LGPD E HARDENING DE SECURITY DEFINER
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations históricas 000001 a 000014 preservadas byte a byte.
--
-- Defeitos Comprovados na Auditoria 02.8 e Corrigidos Cirurgicamente Aqui:
--   1. M02.8-F01 (F01 — Backfill Autenticado por Token, Saneamento de NULL e
--      Desempate Monotônico de Gerações Legadas):
--      - O backfill top-level em `000014` (`UPDATE public.bookings ... WHERE original_idempotency_key IS NULL`)
--        não emitia token `BOOKING_MUTATION` (falhando em bancos que já contivessem
--        reservas pré-000014 devido aos triggers `trg_enforce_booking_invariants`)
--        e não tratava `idempotency_key IS NULL` nem possíveis colisões legadas de
--        `(original_idempotency_key, idempotency_generation)`.
--      - Correção: Cria e executa `public.backfill_and_verify_booking_lineage()`,
--        que emite token `BOOKING_MUTATION` com `LINEAGE_BACKFILL:<status>` na
--        profundidade exata `pg_trigger_depth() - 1`, garante `idempotency_key NOT NULL`
--        e normaliza gerações duplicadas legadas sem violar os triggers de proteção.
--
--   2. M02.8-F02 (F01 & F03 — Preservação Criptográfica da Linhagem e do Escopo do
--      Titular Após Anonimização LGPD de B1, B2 ou da Reserva Mais Recente):
--      - Em `000014`, `public.admin_anonymize_customer_pii()` sobrescrevia tanto
--        `idempotency_key` quanto `original_idempotency_key` com
--        `'lgpd-' || replace(id, '-', '') || '-' || left(md5(id), 16)` (derivado apenas
--        do UUID da reserva, sem preservar o hash raiz `left(md5(k1), 24)` nem o hash
--        de escopo do titular). Isso causava 4 falhas:
--          a) Se a reserva mais recente (`B2`, `gen = 1`) fosse anonimizada enquanto
--             `B1` (`gen = 0`, cancelada) não estava anonimizada, `MAX(idempotency_generation)+1`
--             para `k1` deixava de enxergar `B2` e recalculava `gen = 1` (`g0001`),
--             reutilizando a geração já consumida por `B2`;
--          b) Se `B1` e `B2` fossem ambas anonimizadas, o reenvio de `k1` encontrava
--             0 linhas na linhagem e reiniciava em `gen = 0` em vez de `gen = 2` (`g0002`);
--          c) Após anonimizar todas as reservas de `k1`, outro titular conseguia
--             reutilizar `k1` em outro passeio/data/titular sem sofrer
--             `IDEMPOTENCY_KEY_CONFLICT`;
--          d) Reenviar a chave derivada `idg-...` de uma reserva já anonimizada
--             não localizava a linhagem.
--      - Correção:
--        * `idempotency_key` recebe `'lgpd-' || replace(id, '-', '') || '-' || left(md5(pre_lgpd_idem_key), 16)`
--          (54 chars, 0 PII, autenticando criptograficamente a chave pré-LGPD).
--        * `original_idempotency_key` recebe `'lgpd-lin-' || v_root_hash24 || '-' || v_owner_scope_hash20`
--          (54 chars, prefixo `'lgpd-lin-'`, 0 PII), onde `v_root_hash24 = left(md5(k1), 24)`
--          mantém todas as gerações (`B1`, `B2`, ..., `Bn`) unidas na mesma linhagem e
--          `v_owner_scope_hash20 = left(md5(tour_id || ':' || booking_date || ':' || phone_digits || ':' || email), 20)`
--          permite comprovar se quem reenvia `k1` ou `idg-...` é o mesmo titular
--          (avançando para `MAX(idempotency_generation) + 1`) ou outro titular/passeio/data
--          (bloqueando com `IDEMPOTENCY_KEY_CONFLICT`).
--
--   3. M02.8-F04 (F02 — Hardening de SECURITY DEFINER, Remoção de `auth` Desnecessário
--      do `search_path` e Revogação Universal Explícita para `PUBLIC, anon, authenticated`):
--      - Remove o schema `auth` do `SET search_path` das 5 funções `SECURITY DEFINER`
--        que já qualificam `auth.uid()`/`auth.jwt()` explicitamente.
--      - Executa `ALTER DEFAULT PRIVILEGES` e `REVOKE ALL ON FUNCTION ... FROM PUBLIC, anon, authenticated`
--        em todas as funções de `public`, `internal_guard` e `auth`, re-concedendo
--        `EXECUTE` estritamente à whitelist de RPCs públicas/autenticadas.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ATUALIZAÇÃO DE public.enforce_booking_invariants_and_transitions()
--    Suporta pseudonimização de linhagem `lgpd-lin-<root24>-<scope20>` (54 chars)
--    e token administrativo `LINEAGE_BACKFILL:<status>` para reparo seguro.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
  v_lineage_backfill BOOLEAN := false;
  v_expected_lgpd_email TEXT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    IF NEW.original_idempotency_key IS NULL OR btrim(NEW.original_idempotency_key) = '' THEN
      NEW.original_idempotency_key := lower(btrim(NEW.idempotency_key));
    END IF;

    IF NEW.idempotency_generation IS NULL THEN
      NEW.idempotency_generation := 0;
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      v_lineage_backfill := internal_guard.consume_token(
        'BOOKING_MUTATION',
        OLD.id,
        'LINEAGE_BACKFILL:' || NEW.status::text
      );
    END IF;

    IF NOT v_lgpd_anonymize AND NOT v_lineage_backfill THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    IF v_lineage_backfill THEN
      -- O token LINEAGE_BACKFILL permite exclusivamente preencher/normalizar chaves de linhagem sem tocar em nenhum campo operacional ou financeiro
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.code IS DISTINCT FROM OLD.code
         OR NEW.status IS DISTINCT FROM OLD.status
         OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
         OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
         OR NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
         OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
         OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
        RAISE EXCEPTION 'LINEAGE_BACKFILL_IMMUTABLE_VIOLATION: O reparo de linhagem não pode modificar dados operacionais, financeiros ou de cliente.'
          USING ERRCODE = '42501';
      END IF;
      RETURN NEW;
    END IF;

    v_expected_lgpd_email := 'anonimizado.' || lower(OLD.code) || '@lgpd.invalid';

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR (
         NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.idempotency_key ~ ('^lgpd-' || replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         )
       )
       OR (
         NEW.original_idempotency_key IS DISTINCT FROM OLD.original_idempotency_key
         AND NOT (
           v_lgpd_anonymize
           AND NEW.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         )
       )
       OR NEW.idempotency_generation IS DISTINCT FROM OLD.idempotency_generation
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.commission_rule_label IS DISTINCT FROM OLD.commission_rule_label
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de linhagem de idempotência, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    IF v_lgpd_anonymize THEN
      IF NEW.status IS DISTINCT FROM OLD.status
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_OPERATIONAL_FIELDS: A operação de anonimização LGPD não pode alterar status, data, passageiros, UTMs ou timestamps operacionais da reserva.'
          USING ERRCODE = '42501';
      END IF;

      IF NEW.customer_name <> 'TITULAR ANONIMIZADO LGPD'
         OR NEW.customer_phone <> '(00) 00000-0000'
         OR NEW.customer_email <> v_expected_lgpd_email
         OR NEW.tourist_user_id IS NOT NULL
         OR NEW.idempotency_key !~ ('^lgpd-' || replace(OLD.id::text, '-', '') || '-[0-9a-f]{16}$')
         OR NEW.original_idempotency_key !~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
         OR NEW.notes IS NULL
         OR NEW.notes NOT LIKE '[LGPD %'
         OR (NEW.rejection_or_cancel_reason IS NOT NULL AND NEW.rejection_or_cancel_reason NOT LIKE '[LGPD %') THEN
        RAISE EXCEPTION 'LGPD_INVALID_TARGET_VALUES: O token LGPD_ANONYMIZE permite gravar exclusivamente os valores canônicos de anonimização LGPD.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. FUNÇÃO DE BACKFILL E VERIFICAÇÃO DE LINHAGEM AUTENTICADA POR TOKEN (M02.8-F01)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.backfill_and_verify_booking_lineage()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  r_bk RECORD;
  v_new_idem VARCHAR(64);
  v_new_orig VARCHAR(64);
  v_new_gen INTEGER;
  v_updated_count INTEGER := 0;
BEGIN
  IF v_uid IS NOT NULL
     OR v_json_sub IS NOT NULL
     OR v_db_role IN ('anon', 'authenticated')
     OR v_jwt_role IN ('anon', 'authenticated')
     OR NOT (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_LINEAGE_BACKFILL: Apenas service_role ou superusuário administrativo pode executar o reparo de linhagem.'
      USING ERRCODE = '42501';
  END IF;

  FOR r_bk IN
    SELECT
      b.id,
      b.status,
      b.idempotency_key,
      b.original_idempotency_key,
      b.idempotency_generation,
      b.tour_id,
      b.booking_date,
      b.customer_phone,
      b.customer_email,
      b.created_at
    FROM public.bookings b
    ORDER BY b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    v_new_idem := lower(btrim(COALESCE(r_bk.idempotency_key, '')));
    IF v_new_idem = '' THEN
      v_new_idem := ('legacy-' || replace(r_bk.id::text, '-', ''))::varchar(64);
    END IF;

    IF v_new_idem ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      v_new_gen := substring(v_new_idem from 31 for 4)::integer;
      v_new_orig := lower(btrim(COALESCE(r_bk.original_idempotency_key, '')));
      IF v_new_orig = '' OR v_new_orig = v_new_idem THEN
        SELECT COALESCE(
                 NULLIF(lower(btrim(p.original_idempotency_key)), ''),
                 lower(btrim(p.idempotency_key))
               )
          INTO v_new_orig
        FROM public.bookings p
        WHERE p.id <> r_bk.id
          AND (
            (
              lower(btrim(COALESCE(p.original_idempotency_key, ''))) <> ''
              AND lower(btrim(p.original_idempotency_key)) !~ '^idg-'
              AND lower(btrim(p.original_idempotency_key)) !~ '^lgpd-'
              AND left(md5(lower(btrim(p.original_idempotency_key))), 24) = substring(v_new_idem from 5 for 24)
            )
            OR (
              lower(btrim(p.idempotency_key)) !~ '^idg-'
              AND lower(btrim(p.idempotency_key)) !~ '^lgpd-'
              AND left(md5(lower(btrim(p.idempotency_key))), 24) = substring(v_new_idem from 5 for 24)
            )
          )
        ORDER BY p.created_at ASC, p.id ASC
        LIMIT 1;
        v_new_orig := COALESCE(NULLIF(v_new_orig, ''), v_new_idem);
      END IF;
    ELSE
      v_new_gen := COALESCE(r_bk.idempotency_generation, 0);
      v_new_orig := COALESCE(NULLIF(lower(btrim(COALESCE(r_bk.original_idempotency_key, ''))), ''), v_new_idem);
    END IF;

    -- Desempata caso já exista outra linha com o mesmo par (original_idempotency_key, idempotency_generation)
    WHILE EXISTS (
      SELECT 1 FROM public.bookings x
      WHERE x.id <> r_bk.id
        AND x.original_idempotency_key = v_new_orig
        AND x.idempotency_generation = v_new_gen
    ) LOOP
      v_new_gen := v_new_gen + 1;
    END LOOP;

    IF r_bk.idempotency_key IS DISTINCT FROM v_new_idem
       OR r_bk.original_idempotency_key IS DISTINCT FROM v_new_orig
       OR r_bk.idempotency_generation IS DISTINCT FROM v_new_gen THEN
      PERFORM internal_guard.issue_token('BOOKING_MUTATION', r_bk.id, 'LINEAGE_BACKFILL:' || r_bk.status::text);
      UPDATE public.bookings
      SET idempotency_key = v_new_idem,
          original_idempotency_key = v_new_orig,
          idempotency_generation = v_new_gen
      WHERE id = r_bk.id;
      PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', r_bk.id);
      v_updated_count := v_updated_count + 1;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'verified', true,
    'updated_rows', v_updated_count
  );
END;
$$;

SELECT public.backfill_and_verify_booking_lineage();

ALTER TABLE public.bookings
  ALTER COLUMN idempotency_key SET NOT NULL,
  ALTER COLUMN original_idempotency_key SET NOT NULL,
  ALTER COLUMN idempotency_generation SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'bookings_original_idempotency_key_nonempty_check'
      AND conrelid = 'public.bookings'::regclass
  ) THEN
    ALTER TABLE public.bookings
      ADD CONSTRAINT bookings_original_idempotency_key_nonempty_check
      CHECK (char_length(btrim(original_idempotency_key)) >= 8 AND char_length(original_idempotency_key) <= 64);
  END IF;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. ATUALIZAÇÃO DE public.admin_anonymize_customer_pii() (M02.8-F02 / F03)
--    Preserva o vínculo criptográfico da linhagem (`lgpd-lin-<root24>-<scope20>`)
--    e o contador `idempotency_generation`, sem expor PII em texto claro.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_orig_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_owner_scope_hash20 TEXT;
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_norm_old_name TEXT;
  v_norm_comment TEXT;
  v_norm_comment_geo_stripped TEXT;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND v_json_role IS DISTINCT FROM 'anon'
        AND v_json_role IS DISTINCT FROM 'authenticated'
        AND (
          (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key ~ ('^lgpd-' || replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$')
     AND v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %') THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'original_idempotency_key', v_target.original_idempotency_key,
      'idempotency_generation', v_target.idempotency_generation,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := trim(COALESCE(v_target.customer_name, ''));
  v_old_email := lower(trim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  -- Calcula os pseudônimos determinísticos LGPD preservando a linhagem criptográfica (M02.8-F02)
  IF v_target.idempotency_key ~ ('^lgpd-' || replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
    v_anon_idem_key := v_target.idempotency_key;
  ELSE
    v_anon_idem_key := (
      'lgpd-'
      || replace(v_target.id::text, '-', '')
      || '-'
      || left(md5(lower(btrim(v_target.idempotency_key))), 16)
    )::varchar(64);
  END IF;

  IF v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
    v_anon_orig_idem_key := v_target.original_idempotency_key;
  ELSE
    IF lower(btrim(v_target.idempotency_key)) ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      v_root_hash24 := substring(lower(btrim(v_target.idempotency_key)) from 5 for 24);
    ELSE
      v_root_hash24 := left(md5(lower(btrim(v_target.original_idempotency_key))), 24);
    END IF;
    v_owner_scope_hash20 := left(
      md5(v_target.tour_id::text || ':' || v_target.booking_date::text || ':' || v_old_phone_digits || ':' || v_old_email),
      20
    );
    v_anon_orig_idem_key := ('lgpd-lin-' || v_root_hash24 || '-' || v_owner_scope_hash20)::varchar(64);
  END IF;

  v_anon_notes := format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      original_idempotency_key = v_anon_orig_idem_key,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  UPDATE public.booking_status_history
  SET reason = format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_norm_old_name := public.normalize_lgpd_text(v_old_name);
    v_norm_comment := public.normalize_lgpd_text(v_review.comment);

    v_norm_comment_geo_stripped := regexp_replace(
      ' ' || v_norm_comment || ' ',
      ' (pela costa norte|da costa norte|na costa norte|costa norte|pela costa sul|da costa sul|na costa sul|costa sul|costa verde|costa brava|costa atlantica|praia da costa|pela costa|da costa|na costa|base marina|marina do saco|marina no saco|marina saco|marina itagua|marina porto|vaga na marina|praia da rosa|praia brava|praia grande|ilha anchieta|ilha das couves|ilha do prumirim|ilha comprida|ilha grande|ilha bela|praia do prumirim|cachoeira do prumirim|rio escuro|mar aberto|mar calmo) ',
      ' ',
      'g'
    );

    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (char_length(v_old_email) >= 5 AND position(v_old_email in lower(v_review.comment)) > 0)
      OR (char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND position(v_old_phone_digits in regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
      OR (
        char_length(v_norm_old_name) >= 3
        AND v_old_name <> v_anon_name
        AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_norm_old_name || '($|[^a-z0-9])')
      )
    );

    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT regexp_split_to_table(v_norm_old_name, '\s+')
      LOOP
        IF char_length(v_name_token) >= 3
           AND v_name_token NOT IN (
             'dos', 'das', 'com', 'sem', 'por', 'que', 'uma', 'uns', 'meu', 'sua', 'seu', 'foi', 'era',
             'bom', 'boa', 'dia', 'mar', 'sol', 'sul', 'rio', 'rua', 'cep', 'cpf', 'pii',
             'para', 'pelo', 'pela', 'como', 'mais', 'muito', 'toda', 'todo', 'todos', 'todas',
             'ilha', 'ilhas', 'praia', 'praias', 'lancha', 'escuna', 'passeio', 'barco', 'roteiro',
             'norte', 'verde', 'anchieta', 'prumirim', 'couves',
             'ubatuba', 'saco', 'ribeira', 'itagua', 'familia', 'aguas', 'calmas',
             'titular', 'anonimizado', 'lgpd', 'cliente', 'turista', 'visitante', 'grupo', 'comentario'
           )
           AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_name_token || '($|[^a-z0-9])') THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            old_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            new_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'original_idempotency_key', v_updated.original_idempotency_key,
    'idempotency_generation', v_updated.idempotency_generation,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. ATUALIZAÇÃO DE public.create_booking_request() (M02.8-F02 / F03)
--    Reconhece gerações anonimizadas (`lgpd-lin-<root24>-<scope20>`), impede
--    reuso por outro titular após LGPD e suporta reenvio de `idg-...` pós-LGPD.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_derived_row public.bookings;
  v_non_anon_root VARCHAR(64);
  v_input_root_hash24 TEXT;
  v_input_gen INTEGER;
  v_key_match RECORD;
  v_key_same_owner BOOLEAN := false;
  v_existing RECORD;
  v_existing_active BOOLEAN := false;
  v_existing_same_owner BOOLEAN := false;
  v_next_generation INTEGER := 0;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_clean_idem_input TEXT;
  v_has_explicit_key BOOLEAN := false;
  v_root_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_caller_scope_hash20 TEXT;
  v_lineage_prefix TEXT;
  v_lgpd_lineage_prefix TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_raw_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_uid UUID := NULL;
BEGIN
  IF (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_raw_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_raw_uid::text <> v_json_sub) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_CONTEXT: Conflito de identidade entre claims JWT GUC e JSON.'
      USING ERRCODE = '42501';
  END IF;

  IF v_raw_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     )
     AND EXISTS (SELECT 1 FROM public.profiles WHERE id = v_raw_uid AND is_active = true) THEN
    v_uid := v_raw_uid;
  END IF;

  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));

  v_clean_idem_input := lower(
    regexp_replace(
      COALESCE(p_idempotency_key, ''),
      '^[[:space:][:cntrl:]]+|[[:space:][:cntrl:]]+$',
      '',
      'g'
    )
  );
  v_has_explicit_key := (v_clean_idem_input <> '');

  IF v_has_explicit_key THEN
    IF v_clean_idem_input LIKE 'lgpd-%' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "lgpd-" é reservado exclusivamente para chaves pseudonimizadas pela rotina de conformidade LGPD.'
        USING ERRCODE = '23514';
    END IF;

    IF char_length(v_clean_idem_input) < 8
       OR char_length(v_clean_idem_input) > 64
       OR v_clean_idem_input !~ '^[a-z0-9._:-]+$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: A chave de idempotência deve conter entre 8 e 64 caracteres alfanuméricos (a-z, 0-9, ., _, :, -) sem espaços internos.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  -- Hierarquia Canônica de Locks:
  -- Lock #1: Linha da embarcação em public.vessels (FOR UPDATE)
  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id
  FOR UPDATE;

  -- Lock #2: Advisory lock transacional (embarcação + data)
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  v_caller_scope_hash20 := left(
    md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits || ':' || v_clean_email),
    20
  );

  -- M02.7-F01 + M02.8-F02: Resolução determinística e verificada da chave raiz (`v_root_idem_key`)
  IF v_clean_idem_input LIKE 'idg-%' THEN
    IF v_clean_idem_input !~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: O prefixo "idg-" é reservado para chaves derivadas de linhagem de idempotência.'
        USING ERRCODE = '23514';
    END IF;

    v_input_root_hash24 := substring(v_clean_idem_input from 5 for 24);
    v_input_gen := substring(v_clean_idem_input from 31 for 4)::integer;

    SELECT b.*
      INTO v_derived_row
    FROM public.bookings b
    WHERE lower(b.idempotency_key) = v_clean_idem_input
       OR (
         b.idempotency_generation = v_input_gen
         AND b.original_idempotency_key LIKE ('lgpd-lin-' || v_input_root_hash24 || '-%')
         AND right(b.idempotency_key, 16) = left(md5(v_clean_idem_input), 16)
       )
    ORDER BY CASE WHEN lower(b.idempotency_key) = v_clean_idem_input THEN 0 ELSE 1 END ASC
    LIMIT 1
    FOR UPDATE;

    IF v_derived_row.id IS NULL
       OR v_derived_row.original_idempotency_key IS NULL
       OR v_derived_row.idempotency_generation <= 0 THEN
      RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
        USING ERRCODE = '23514';
    END IF;

    IF v_derived_row.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      -- Linha correspondente foi anonimizada via LGPD: verifica hash criptográfico de 16 hex da chave idg- pré-LGPD
      IF right(v_derived_row.idempotency_key, 16) <> left(md5(v_clean_idem_input), 16) THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;
      -- Tenta localizar alguma geração não anonimizada da mesma linhagem para restaurar o texto original de k1;
      -- se todas as gerações da linhagem estiverem anonimizadas, usa a raiz pseudonimizada da linhagem.
      SELECT b.original_idempotency_key
        INTO v_non_anon_root
      FROM public.bookings b
      WHERE b.original_idempotency_key NOT LIKE 'lgpd-%'
        AND left(md5(lower(btrim(b.original_idempotency_key))), 24) = v_input_root_hash24
      ORDER BY b.idempotency_generation ASC
      LIMIT 1;

      v_root_idem_key := COALESCE(v_non_anon_root, v_derived_row.original_idempotency_key);
      v_root_hash24 := v_input_root_hash24;
    ELSE
      IF public.derive_idempotency_lineage_key(v_derived_row.original_idempotency_key, v_derived_row.idempotency_generation) <> v_clean_idem_input THEN
        RAISE EXCEPTION 'INVALID_IDEMPOTENCY_KEY: Chave derivada "idg-" inexistente, adulterada ou não autenticada pela linhagem.'
          USING ERRCODE = '23514';
      END IF;
      v_root_idem_key := v_derived_row.original_idempotency_key;
      v_root_hash24 := left(md5(v_root_idem_key), 24);
    END IF;

    v_lineage_prefix := 'idg-' || v_root_hash24 || '-g';
    v_lgpd_lineage_prefix := 'lgpd-lin-' || v_root_hash24 || '-';
  ELSE
    v_root_idem_key := left(
      COALESCE(
        NULLIF(v_clean_idem_input, ''),
        md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
        || md5(v_phone_digits || ':' || v_tour.id::text)
      ),
      64
    );
    v_root_hash24 := left(md5(v_root_idem_key), 24);
    v_lineage_prefix := 'idg-' || v_root_hash24 || '-g';
    v_lgpd_lineage_prefix := 'lgpd-lin-' || v_root_hash24 || '-';
  END IF;

  -- 1) Trava (FOR UPDATE) e valida TODAS as reservas pertencentes à linhagem (incluindo gerações anonimizadas via LGPD!)
  FOR v_key_match IN
    SELECT b.*
    FROM public.bookings b
    WHERE b.original_idempotency_key = v_root_idem_key
       OR b.original_idempotency_key LIKE (v_lgpd_lineage_prefix || '%')
       OR lower(b.idempotency_key) = v_root_idem_key
       OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%')
    ORDER BY b.idempotency_generation ASC, b.created_at ASC, b.id ASC
    FOR UPDATE
  LOOP
    IF v_key_match.original_idempotency_key LIKE 'lgpd-lin-%' THEN
      v_key_same_owner := (
        substring(v_key_match.original_idempotency_key from 35 for 20) = v_caller_scope_hash20
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    ELSE
      v_key_same_owner := (
        (v_key_match.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_key_match.tourist_user_id OR public.is_admin())
        AND regexp_replace(v_key_match.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
        AND lower(trim(v_key_match.customer_email)) = v_clean_email
        AND v_key_match.tour_id = v_tour.id
        AND v_key_match.booking_date = p_booking_date
      );
    END IF;

    IF NOT v_key_same_owner THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: A chave de idempotência informada já pertence a outro titular, outro passeio ou outra data.'
        USING ERRCODE = '23505';
    END IF;
  END LOOP;

  -- 2) Busca reserva existente NÃO ANONIMIZADA na linhagem (reservas anonimizadas por LGPD encerram seu ciclo de PII
  --    e não devem ser retornadas como replay de dados pessoais ativos, mas mantêm sua posição na linhagem)
  SELECT b.*
    INTO v_existing
    FROM public.bookings b
  WHERE (
      b.original_idempotency_key = v_root_idem_key
      OR lower(b.idempotency_key) = v_root_idem_key
      OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%')
      OR (
        NOT v_has_explicit_key
        AND b.tour_id = v_tour.id
        AND b.booking_date = p_booking_date
        AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      )
    )
    AND b.original_idempotency_key NOT LIKE 'lgpd-%'
    AND b.idempotency_key NOT LIKE 'lgpd-%'
  ORDER BY
    CASE
      WHEN b.status NOT IN ('CANCELADA', 'RECUSADA')
           AND (
             b.expires_at IS NULL
             OR b.expires_at > now()
             OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
           ) THEN 0
      ELSE 1
    END ASC,
    b.idempotency_generation DESC,
    b.created_at DESC,
    b.id DESC
  LIMIT 1
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    v_existing_active := (
      v_existing.status NOT IN ('CANCELADA', 'RECUSADA')
      AND (
        v_existing.expires_at IS NULL
        OR v_existing.expires_at > now()
        OR v_existing.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
      )
    );

    v_existing_same_owner := (
      (v_existing.tourist_user_id IS NULL OR v_uid IS NOT DISTINCT FROM v_existing.tourist_user_id OR public.is_admin())
      AND regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
      AND lower(trim(v_existing.customer_email)) = v_clean_email
      AND v_existing.tour_id = v_tour.id
      AND v_existing.booking_date = p_booking_date
    );
  END IF;

  IF v_existing.id IS NOT NULL AND NOT v_existing_same_owner THEN
    RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação conflitante ou a chave de idempotência pertence a outro titular/passeio/data.'
      USING ERRCODE = '23505';
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing_active THEN
    IF v_existing.passengers IS DISTINCT FROM p_passengers THEN
      RAISE EXCEPTION 'ACTIVE_BOOKING_PASSENGERS_CONFLICT: Já existe uma reserva ativa (%) para este passeio e data com % passageiros (solicitado: % passageiros).',
        v_existing.code, v_existing.passengers, p_passengers
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'original_idempotency_key', v_existing.original_idempotency_key,
      'idempotency_generation', v_existing.idempotency_generation,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  -- 3) Calcula a próxima geração por MAX(idempotency_generation) + 1 considerando TODAS as gerações da linhagem
  --    (inclusive gerações anonimizadas via LGPD que possuem original_idempotency_key LIKE 'lgpd-lin-<root24>-%')
  SELECT COALESCE(MAX(b.idempotency_generation) + 1, 0)::integer
    INTO v_next_generation
  FROM public.bookings b
  WHERE b.original_idempotency_key = v_root_idem_key
     OR b.original_idempotency_key LIKE (v_lgpd_lineage_prefix || '%')
     OR lower(b.idempotency_key) = v_root_idem_key
     OR lower(b.idempotency_key) LIKE (v_lineage_prefix || '%');

  IF v_root_idem_key LIKE 'lgpd-lin-%' THEN
    -- Caso extremo: cliente enviou chave derivada `idg-...` quando TODAS as gerações anteriores da linhagem
    -- foram anonimizadas via LGPD; gera a chave derivada determinística a partir de `v_root_hash24`.
    v_computed_idem_key := (
      'idg-'
      || v_root_hash24
      || '-g'
      || lpad(LEAST(GREATEST(v_next_generation, 1), 9999)::text, 4, '0')
      || '-'
      || left(md5(v_root_idem_key || ':gen:' || LEAST(GREATEST(v_next_generation, 1), 9999)::text), 24)
    )::varchar(64);
  ELSE
    v_computed_idem_key := public.derive_idempotency_lineage_key(v_root_idem_key, v_next_generation);
  END IF;

  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;

  INSERT INTO public.bookings (
    code,
    idempotency_key,
    original_idempotency_key,
    idempotency_generation,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_root_idem_key,
    v_next_generation,
    v_uid,
    v_tour.partner_id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(COALESCE(p_utm_source, '')), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(COALESCE(p_utm_campaign, '')), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    NULLIF(trim(COALESCE(p_notes, '')), ''),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'original_idempotency_key', v_inserted.original_idempotency_key,
    'idempotency_generation', v_inserted.idempotency_generation,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. HARDENING DE search_path E PRIVILÉGIOS EXECUTE EM TODAS AS 42 FUNÇÕES (M02.8-F04)
--    Remove `auth` supérfluo do search_path das 5 funções SECURITY DEFINER que já
--    qualificam `auth.uid()`/`auth.jwt()` explicitamente e revoga EXECUTE de
--    PUBLIC, anon e authenticated em todas as funções antes de aplicar a whitelist.
-- ----------------------------------------------------------------------------
ALTER FUNCTION public.handle_new_auth_user()
  SET search_path = pg_catalog, public, pg_temp;

ALTER FUNCTION public.handle_updated_auth_user()
  SET search_path = pg_catalog, public, internal_guard, pg_temp;

ALTER FUNCTION public.protect_profile_privileged_columns()
  SET search_path = pg_catalog, public, internal_guard, pg_temp;

ALTER FUNCTION public.validate_verified_review()
  SET search_path = pg_catalog, public, internal_guard, pg_temp;

ALTER FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT)
  SET search_path = pg_catalog, public, internal_guard, pg_temp;

DO $$
DECLARE
  r_fn RECORD;
BEGIN
  ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
  ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM anon;
    ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM authenticated;
    ALTER DEFAULT PRIVILEGES IN SCHEMA internal_guard REVOKE EXECUTE ON FUNCTIONS FROM authenticated;
  END IF;

  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard', 'auth')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);
    END IF;
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION auth.uid() TO anon;
    GRANT EXECUTE ON FUNCTION auth.jwt() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION auth.uid() TO authenticated;
    GRANT EXECUTE ON FUNCTION auth.jwt() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT ALL ON SCHEMA public TO service_role;
    GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
    GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
    GRANT USAGE ON SCHEMA internal_guard TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA internal_guard TO service_role;
    GRANT USAGE ON SCHEMA auth TO service_role;
    GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA auth TO service_role;
  END IF;
END;
$$;
