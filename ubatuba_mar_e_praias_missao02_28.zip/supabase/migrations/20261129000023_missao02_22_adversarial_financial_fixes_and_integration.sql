-- ============================================================================
-- UBATUBA MAR & PRAIAS (ROTA AZUL) — ARGON 4 — MISSÃO 02.22
-- MIGRATION 000023: CORREÇÃO ADVERSARIAL E INTEGRAÇÃO FINANCEIRA (F01 A F09)
-- Arquivo: supabase/migrations/20261129000023_missao02_22_adversarial_financial_fixes_and_integration.sql
--
-- Escopo Técnico (Seção 3 — Defeitos F01 a F08):
--   1. F01 (Autorização e Confirmação de Pagamentos):
--      - Bloqueia partner de confirmar pagamentos como PAGO (PARTNER_PAYMENT_CONFIRM_FORBIDDEN).
--      - Bloqueia tourist de alterar estados financeiros diretamente (TOURIST_FINANCIAL_ACCESS_FORBIDDEN).
--      - Exige external_transaction_id para confirmação PAGO e justificativa auditável
--        (reason >= 5 caracteres) para confirmação manual administrativa (MANUAL_ADMIN).
--      - Registra todas as operações financeiras críticas em public.audit_logs.
--   2. F02 (Estornos Seguros em Duas Etapas — Solicitação vs. Confirmação):
--      - Nova RPC public.request_booking_refund(...) para transição PAGO/ESTORNO_PARCIAL -> ESTORNO_PENDENTE
--        sem reduzir comissão ou saldo líquido antes da confirmação.
--      - Restringe public.process_booking_refund(...) exclusivamente a admin e service_role
--        (PARTNER_REFUND_CONFIRM_FORBIDDEN / UNAUTHORIZED_REFUND_OPERATION).
--      - Suporta falha de processamento de estorno (ESTORNO_PENDENTE -> PAGO quando refunded_gross_amount = 0
--        ou ESTORNO_PENDENTE -> ESTORNO_PARCIAL quando refunded_gross_amount > 0).
--   3. F04 (Sincronização Transacional dos Cancelamentos e Liquidação):
--      - Atualiza public.sync_booking_history_ledger_and_audit() para sincronizar atomicamente
--        booking_payments, booking_payment_history, financial_ledger_entries e commission_ledger
--        em todos os caminhos de cancelamento/recusa/expiração:
--        * PENDENTE / PROCESSANDO / FALHOU -> CANCELADO
--        * PAGO / ESTORNO_PARCIAL -> ESTORNO_PENDENTE (jamais ESTORNADO sem confirmação)
--      - Atualiza public.settle_commission_ledger(...) para exigir pagamento confirmado
--        (PAGO ou ESTORNO_PARCIAL com saldo líquido positivo) e lançar PARTNER_PAYOUT_SETTLED
--        em financial_ledger_entries.
--   4. F05 (Conciliação Financeira Completa em 5 Tabelas com Snapshot Histórico):
--      - Reescreve public.get_financial_reconciliation_report(...) utilizando exclusivamente os
--        snapshots históricos persistidos na reserva e cruzando bookings, commission_ledger,
--        booking_payments, booking_payment_history e financial_ledger_entries.
--   5. F06 (Idempotência Rigorosa de Payload):
--      - Valida equivalência completa de parâmetros em create_or_initiate_booking_payment,
--        confirm_or_fail_booking_payment, request_booking_refund e process_booking_refund,
--        rejeitando reuso de chave com payload divergente via FINANCIAL_IDEMPOTENCY_CONFLICT.
--   6. F08 (Segurança de RPC, Ownership, Privilégios Mínimos e LGPD Financeiro):
--      - ALTER FUNCTION ... OWNER TO postgres em todas as funções SECURITY DEFINER.
--      - REVOKE EXECUTE nas funções de trigger para PUBLIC, anon, authenticated e service_role.
--      - Sanitização LGPD de motivos/descrições em booking_payments, booking_payment_history
--        e financial_ledger_entries dentro de public.admin_anonymize_customer_pii(...)
--        preservando 100% dos valores contábeis.
-- ============================================================================

-- 1. Máquina de Estados de Pagamento com suporte a solicitação e falha de estorno (F02)
CREATE OR REPLACE FUNCTION public.is_valid_payment_status_transition(
  p_old_status public.payment_status_type,
  p_new_status public.payment_status_type
)
RETURNS BOOLEAN
LANGUAGE plpgsql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $body$
BEGIN
  IF p_old_status IS NULL OR p_new_status IS NULL THEN
    RETURN false;
  END IF;

  CASE p_old_status
    WHEN 'PENDENTE' THEN
      RETURN p_new_status IN ('PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO');
    WHEN 'PROCESSANDO' THEN
      RETURN p_new_status IN ('PAGO', 'FALHOU', 'CANCELADO');
    WHEN 'FALHOU' THEN
      RETURN p_new_status IN ('PROCESSANDO', 'CANCELADO');
    WHEN 'PAGO' THEN
      RETURN p_new_status IN ('ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL');
    WHEN 'ESTORNO_PENDENTE' THEN
      RETURN p_new_status IN ('ESTORNADO', 'ESTORNO_PARCIAL', 'PAGO');
    WHEN 'ESTORNO_PARCIAL' THEN
      RETURN p_new_status IN ('ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL');
    WHEN 'CANCELADO' THEN
      RETURN false;
    WHEN 'ESTORNADO' THEN
      RETURN false;
    ELSE
      RETURN false;
  END CASE;
END;
$body$;

-- 2. Trigger de Blindagem de Pagamentos com validação de estorno parcial, transação externa e sanitização LGPD (F01, F02, F08)
CREATE OR REPLACE FUNCTION public.enforce_booking_payment_invariants()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_is_lgpd_sanitize BOOLEAN := false;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD_DELETE_FORBIDDEN: Registros financeiros em booking_payments não podem ser excluídos.'
      USING ERRCODE = '42501';
  END IF;

  IF TG_OP = 'UPDATE' AND internal_guard.consume_token('PAYMENT_MUTATION', NEW.booking_id, 'LGPD_FINANCIAL_SANITIZE:' || OLD.payment_status::text) THEN
    v_is_lgpd_sanitize := true;
  ELSIF NOT internal_guard.consume_token('PAYMENT_MUTATION', NEW.booking_id, NEW.payment_status::text) THEN
    RAISE EXCEPTION 'DIRECT_PAYMENT_MUTATION_FORBIDDEN: Alteração direta em booking_payments é proibida. Utilize as RPCs financeiras autorizadas.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_BOOKING_NOT_FOUND: Reserva (%) não encontrada.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'PAYMENT_AMOUNT_TAMPERING_FORBIDDEN: Os valores bruto, comissão e líquido do pagamento devem corresponder exatamente aos valores persistidos da reserva.'
      USING ERRCODE = '42501';
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount
       OR NEW.commission_rule_snapshot IS DISTINCT FROM OLD.commission_rule_snapshot
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'PAYMENT_IMMUTABLE_FIELDS_FORBIDDEN: Campos estruturais, snapshot histórico de comissão e valores nominais do pagamento são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    IF v_is_lgpd_sanitize THEN
      IF NEW.payment_status IS DISTINCT FROM OLD.payment_status
         OR NEW.payment_method IS DISTINCT FROM OLD.payment_method
         OR NEW.refunded_gross_amount IS DISTINCT FROM OLD.refunded_gross_amount
         OR NEW.refunded_commission_amount IS DISTINCT FROM OLD.refunded_commission_amount
         OR NEW.refunded_net_partner_amount IS DISTINCT FROM OLD.refunded_net_partner_amount
         OR NEW.effective_gross_amount IS DISTINCT FROM OLD.effective_gross_amount
         OR NEW.effective_commission_amount IS DISTINCT FROM OLD.effective_commission_amount
         OR NEW.effective_net_partner_amount IS DISTINCT FROM OLD.effective_net_partner_amount
         OR NEW.external_transaction_id IS DISTINCT FROM OLD.external_transaction_id
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.refunded_at IS DISTINCT FROM OLD.refunded_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_FINANCIAL_FIELDS: A sanitização LGPD em booking_payments permite alterar exclusivamente campos textuais de motivo.'
          USING ERRCODE = '42501';
      END IF;
      RETURN NEW;
    END IF;

    IF NEW.payment_status IS DISTINCT FROM OLD.payment_status
       AND NOT public.is_valid_payment_status_transition(OLD.payment_status, NEW.payment_status) THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Transição financeira proibida de % para %.',
        OLD.payment_status, NEW.payment_status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.payment_status = 'PAGO' AND NEW.refunded_gross_amount > 0 THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Pagamento com saldo parcialmente estornado (%) deve permanecer em ESTORNO_PARCIAL, nunca PAGO.',
        NEW.refunded_gross_amount
        USING ERRCODE = '23514';
    END IF;

    IF NEW.payment_status = 'PAGO' AND NULLIF(pg_catalog.btrim(COALESCE(NEW.external_transaction_id, '')), '') IS NULL THEN
      RAISE EXCEPTION 'EXTERNAL_TRANSACTION_ID_REQUIRED: Pagamentos confirmados (PAGO) exigem external_transaction_id válido.'
        USING ERRCODE = '23514';
    END IF;

    IF NEW.refunded_gross_amount < OLD.refunded_gross_amount THEN
      RAISE EXCEPTION 'REFUND_ROLLBACK_FORBIDDEN: O montante acumulado de estorno não pode retroceder.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$body$;

-- 3. Trigger de Tabelas Financeiras Append-Only com suporte estrito à sanitização textual LGPD sem alterar valores contábeis (F08-B)
CREATE OR REPLACE FUNCTION public.enforce_append_only_financial_audit_tables()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'FINANCIAL_HISTORY_IMMUTABLE_FORBIDDEN: Lançamentos históricos em % são imutáveis e não podem ser removidos.',
      TG_TABLE_NAME
      USING ERRCODE = '42501';
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NOT internal_guard.consume_token('FINANCIAL_LEDGER_MUTATION', NEW.booking_id, 'LGPD_SANITIZE:' || TG_TABLE_NAME) THEN
      RAISE EXCEPTION 'FINANCIAL_HISTORY_IMMUTABLE_FORBIDDEN: Lançamentos históricos em % são imutáveis e não podem ser editados fora de sanitização LGPD autorizada. Utilize lançamentos compensatórios.',
        TG_TABLE_NAME
        USING ERRCODE = '42501';
    END IF;

    IF TG_TABLE_NAME = 'booking_payment_history' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.payment_id IS DISTINCT FROM OLD.payment_id
         OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.previous_status IS DISTINCT FROM OLD.previous_status
         OR NEW.new_status IS DISTINCT FROM OLD.new_status
         OR NEW.operation_type IS DISTINCT FROM OLD.operation_type
         OR NEW.operation_amount IS DISTINCT FROM OLD.operation_amount
         OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         OR NEW.external_transaction_id IS DISTINCT FROM OLD.external_transaction_id
         OR NEW.actor_role IS DISTINCT FROM OLD.actor_role
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_FINANCIAL_FIELDS: A sanitização LGPD em booking_payment_history preserva integralmente valores, status e timestamps.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_TABLE_NAME = 'financial_ledger_entries' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
         OR NEW.payment_id IS DISTINCT FROM OLD.payment_id
         OR NEW.commission_ledger_id IS DISTINCT FROM OLD.commission_ledger_id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
         OR NEW.entry_type IS DISTINCT FROM OLD.entry_type
         OR NEW.gross_delta IS DISTINCT FROM OLD.gross_delta
         OR NEW.commission_delta IS DISTINCT FROM OLD.commission_delta
         OR NEW.net_partner_delta IS DISTINCT FROM OLD.net_partner_delta
         OR NEW.currency IS DISTINCT FROM OLD.currency
         OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         OR NEW.reference_transaction_id IS DISTINCT FROM OLD.reference_transaction_id
         OR NEW.actor_role IS DISTINCT FROM OLD.actor_role
         OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'LGPD_IMMUTABLE_FINANCIAL_FIELDS: A sanitização LGPD em financial_ledger_entries preserva integralmente todos os deltas e vínculos contábeis.'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  IF NOT internal_guard.consume_token('FINANCIAL_LEDGER_MUTATION', NEW.booking_id, TG_TABLE_NAME) THEN
    RAISE EXCEPTION 'DIRECT_FINANCIAL_LEDGER_INSERT_FORBIDDEN: Inserção manual em % fora das RPCs financeiras é proibida.',
      TG_TABLE_NAME
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$body$;

-- 4. RPC 1: Criar ou Iniciar Pagamento com guarda 4-fatores, idempotência simétrica de payload e auditoria (F01, F06-A, F08)
CREATE OR REPLACE FUNCTION public.create_or_initiate_booking_payment(
  p_booking_id UUID,
  p_payment_method public.payment_method_type,
  p_idempotency_key TEXT,
  p_client_gross_amount NUMERIC DEFAULT NULL,
  p_external_transaction_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_existing public.booking_payments%ROWTYPE;
  v_key_conflict public.booking_payments%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_ext TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_external_transaction_id, '')), '');
  v_rule_snap JSONB;
BEGIN
  -- Guarda 4-fatores de autenticação antes de qualquer leitura de dados (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Contexto de autenticação inválido ou não autorizado para iniciar pagamento.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF p_payment_method IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_METHOD_REQUIRED: O método de pagamento é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: A chave de idempotência financeira deve ter entre 8 e 128 caracteres válidos.'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock: Lock #1 vessels -> Lock #2 advisory_lock -> Lock #3 bookings
  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Usuário sem permissão para iniciar pagamento desta reserva.'
      USING ERRCODE = '42501';
  END IF;

  IF p_client_gross_amount IS NOT NULL AND pg_catalog.round(p_client_gross_amount::numeric, 2) <> v_booking.gross_amount THEN
    RAISE EXCEPTION 'PAYMENT_CLIENT_AMOUNT_MISMATCH: Valor enviado pelo cliente (%) diverge do valor oficial calculado no servidor (%).',
      pg_catalog.round(p_client_gross_amount::numeric, 2), v_booking.gross_amount
      USING ERRCODE = '42501';
  END IF;

  -- F06-A: Verificação estrita e simétrica de equivalência de payload na chave de idempotência
  SELECT * INTO v_key_conflict
  FROM public.booking_payments
  WHERE idempotency_key = v_clean_idem
  FOR UPDATE;

  IF v_key_conflict.id IS NOT NULL THEN
    IF v_key_conflict.booking_id IS DISTINCT FROM v_booking.id
       OR v_key_conflict.payment_method IS DISTINCT FROM p_payment_method
       OR v_key_conflict.external_transaction_id IS DISTINCT FROM v_clean_ext THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: A chave de idempotência (%) já foi utilizada com parâmetros financeiros incompatíveis.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_key_conflict.id,
      'booking_id', v_key_conflict.booking_id,
      'partner_id', v_key_conflict.partner_id,
      'payment_status', v_key_conflict.payment_status,
      'payment_method', v_key_conflict.payment_method,
      'currency', v_key_conflict.currency,
      'gross_amount', v_key_conflict.gross_amount,
      'commission_amount', v_key_conflict.commission_amount,
      'net_partner_amount', v_key_conflict.net_partner_amount,
      'effective_gross_amount', v_key_conflict.effective_gross_amount,
      'effective_commission_amount', v_key_conflict.effective_commission_amount,
      'effective_net_partner_amount', v_key_conflict.effective_net_partner_amount,
      'idempotency_key', v_key_conflict.idempotency_key
    );
  END IF;

  SELECT * INTO v_existing
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    IF v_existing.payment_status IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL') THEN
      RAISE EXCEPTION 'PAYMENT_ALREADY_PROCESSED: A reserva % já possui pagamento processado com status %.',
        v_booking.code, v_existing.payment_status
        USING ERRCODE = '23505';
    END IF;

    IF v_existing.payment_method IS DISTINCT FROM p_payment_method
       OR v_existing.external_transaction_id IS DISTINCT FROM v_clean_ext THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: A reserva % já possui pagamento iniciado com método ou transação externa divergente.',
        v_booking.code
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_existing.id,
      'booking_id', v_existing.booking_id,
      'partner_id', v_existing.partner_id,
      'payment_status', v_existing.payment_status,
      'payment_method', v_existing.payment_method,
      'currency', v_existing.currency,
      'gross_amount', v_existing.gross_amount,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'effective_gross_amount', v_existing.effective_gross_amount,
      'effective_commission_amount', v_existing.effective_commission_amount,
      'effective_net_partner_amount', v_existing.effective_net_partner_amount,
      'idempotency_key', v_existing.idempotency_key
    );
  END IF;

  IF v_booking.status IN ('CANCELADA', 'RECUSADA') THEN
    RAISE EXCEPTION 'PAYMENT_ON_CANCELLED_BOOKING_FORBIDDEN: Não é permitido iniciar pagamento para reserva em status %.',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  v_rule_snap := jsonb_build_object(
    'commission_rule_id', v_booking.commission_rule_id,
    'commission_model', v_booking.commission_model_snapshot,
    'commission_rate', v_booking.commission_rate_snapshot,
    'commission_fixed', v_booking.commission_fixed_snapshot,
    'commission_rule_label', v_booking.commission_rule_label,
    'pricing_model', v_booking.pricing_model_snapshot,
    'unit_price', v_booking.unit_price_snapshot,
    'passengers', v_booking.passengers
  );

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, 'PENDENTE');
  INSERT INTO public.booking_payments (
    booking_id,
    partner_id,
    tour_id,
    currency,
    payment_method,
    payment_status,
    gross_amount,
    commission_amount,
    net_partner_amount,
    refunded_gross_amount,
    refunded_commission_amount,
    refunded_net_partner_amount,
    effective_gross_amount,
    effective_commission_amount,
    effective_net_partner_amount,
    commission_rule_snapshot,
    external_transaction_id,
    idempotency_key,
    last_operation_idempotency_key
  ) VALUES (
    v_booking.id,
    v_booking.partner_id,
    v_booking.tour_id,
    'BRL',
    p_payment_method,
    'PENDENTE',
    v_booking.gross_amount,
    v_booking.commission_amount,
    v_booking.net_partner_amount,
    0.00,
    0.00,
    0.00,
    v_booking.gross_amount,
    v_booking.commission_amount,
    v_booking.net_partner_amount,
    v_rule_snap,
    v_clean_ext,
    v_clean_idem,
    v_clean_idem
  )
  RETURNING * INTO v_existing;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    external_transaction_id,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_existing.id,
    v_booking.id,
    v_booking.partner_id,
    NULL,
    'PENDENTE',
    'CREATE_PAYMENT',
    v_booking.gross_amount,
    'hist-init-' || v_clean_idem,
    v_clean_ext,
    v_uid,
    v_actor_role,
    'Pagamento iniciado no servidor com valores calculados da reserva',
    jsonb_build_object(
      'payment_method', p_payment_method,
      'external_transaction_id', v_clean_ext
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_existing.id,
    v_booking.partner_id,
    v_booking.tour_id,
    'COMMISSION_PROVISIONED',
    0.00,
    0.00,
    0.00,
    'BRL',
    'fled-init-' || v_clean_idem,
    v_clean_ext,
    pg_catalog.format('Provisão inicial de pagamento (%s) para reserva %s', p_payment_method, v_booking.code),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    'INITIATE_BOOKING_PAYMENT',
    NULL,
    jsonb_build_object(
      'payment_id', v_existing.id,
      'booking_id', v_booking.id,
      'payment_status', v_existing.payment_status,
      'payment_method', v_existing.payment_method,
      'gross_amount', v_existing.gross_amount,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'idempotency_key', v_existing.idempotency_key
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_existing.id,
    'booking_id', v_existing.booking_id,
    'partner_id', v_existing.partner_id,
    'payment_status', v_existing.payment_status,
    'payment_method', v_existing.payment_method,
    'currency', v_existing.currency,
    'gross_amount', v_existing.gross_amount,
    'commission_amount', v_existing.commission_amount,
    'net_partner_amount', v_existing.net_partner_amount,
    'effective_gross_amount', v_existing.effective_gross_amount,
    'effective_commission_amount', v_existing.effective_commission_amount,
    'effective_net_partner_amount', v_existing.effective_net_partner_amount,
    'idempotency_key', v_existing.idempotency_key
  );
END;
$body$;

-- 5. RPC 2: Transição/Confirmação de Pagamento com bloqueio de Partner/Tourist, Origem de Confirmação, Reversão de Falha de Estorno e Idempotência Completa (F01, F02-B, F06-B, F08)
CREATE OR REPLACE FUNCTION public.confirm_or_fail_booking_payment(
  p_booking_id UUID,
  p_target_status public.payment_status_type,
  p_idempotency_key TEXT,
  p_external_transaction_id TEXT DEFAULT NULL,
  p_client_gross_amount NUMERIC DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_prev_status public.payment_status_type;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_service_role BOOLEAN := false;
  v_confirmation_origin TEXT := NULL;
  v_is_refund_fail_revert BOOLEAN := false;
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_ext TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_external_transaction_id, '')), '');
  v_clean_reason TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), '');
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Contexto de autenticação inválido ou não autorizado para atualizar pagamento.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NULL
     AND v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND v_json_role IS DISTINCT FROM 'anon'
     AND v_json_role IS DISTINCT FROM 'authenticated'
     AND (
       (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    v_is_service_role := true;
  END IF;

  IF p_booking_id IS NULL OR p_target_status IS NULL THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_TRANSITION_ARGS: Reserva e status alvo são obrigatórios.'
      USING ERRCODE = '23514';
  END IF;

  IF p_target_status NOT IN ('PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'INVALID_TARGET_PAYMENT_STATUS: Utilize request_booking_refund() ou process_booking_refund() para operações de estorno.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência inválida.'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Sem permissão para atualizar pagamento desta reserva.'
      USING ERRCODE = '42501';
  END IF;

  -- F01-B: Turista jamais pode alterar diretamente estados financeiros (PROCESSANDO, PAGO, FALHOU, CANCELADO)
  IF v_actor_role = 'tourist' THEN
    IF p_target_status = 'PAGO' THEN
      RAISE EXCEPTION 'TOURIST_PAYMENT_CONFIRM_FORBIDDEN: O turista não tem permissão para confirmar pagamento diretamente.'
        USING ERRCODE = '42501';
    END IF;
    RAISE EXCEPTION 'TOURIST_FINANCIAL_ACCESS_FORBIDDEN: O turista não tem permissão para alterar estados financeiros diretamente (%).' ,
      p_target_status
      USING ERRCODE = '42501';
  END IF;

  -- F01-A: Parceiro jamais pode confirmar pagamento como PAGO ou reverter estorno
  IF v_actor_role = 'partner' AND p_target_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'PARTNER_PAYMENT_CONFIRM_FORBIDDEN: Parceiros não possuem permissão para confirmar pagamentos como PAGO.'
      USING ERRCODE = '42501';
  END IF;

  IF p_client_gross_amount IS NOT NULL AND pg_catalog.round(p_client_gross_amount::numeric, 2) <> v_booking.gross_amount THEN
    RAISE EXCEPTION 'PAYMENT_CLIENT_AMOUNT_MISMATCH: Valor informado (%) diverge do valor oficial da reserva (%).',
      pg_catalog.round(p_client_gross_amount::numeric, 2), v_booking.gross_amount
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Nenhum pagamento iniciado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- F06-B: Verifica idempotência rigorosa no histórico de operações financeiras (comparando todos os parâmetros do payload)
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.new_status IS DISTINCT FROM p_target_status
       OR v_hist_existing.external_transaction_id IS DISTINCT FROM v_clean_ext
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência (%) reutilizada com parâmetros incompatíveis.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'previous_status', v_hist_existing.previous_status,
      'payment_status', v_payment.payment_status,
      'gross_amount', v_payment.gross_amount,
      'commission_amount', v_payment.commission_amount,
      'net_partner_amount', v_payment.net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount,
      'confirmed_at', v_payment.confirmed_at
    );
  END IF;

  IF v_payment.payment_status = 'PAGO' AND p_target_status = 'PAGO' THEN
    RAISE EXCEPTION 'PAYMENT_ALREADY_CONFIRMED_DUPLICATE: O pagamento da reserva % já foi confirmado anteriormente.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  -- F02-B: Tratamento de falha de processamento de estorno (ESTORNO_PENDENTE -> PAGO ou ESTORNO_PARCIAL)
  IF v_payment.payment_status = 'ESTORNO_PENDENTE' AND p_target_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    IF v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou service_role podem reverter estorno pendente após falha no gateway.'
        USING ERRCODE = '42501';
    END IF;
    IF v_payment.refunded_gross_amount = 0 AND p_target_status <> 'PAGO' THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Estorno pendente sem saldo estornado anterior deve retornar para PAGO.'
        USING ERRCODE = '23514';
    END IF;
    IF v_payment.refunded_gross_amount > 0 AND p_target_status <> 'ESTORNO_PARCIAL' THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Estorno pendente com saldo parcialmente estornado (%) deve retornar para ESTORNO_PARCIAL.',
        v_payment.refunded_gross_amount
        USING ERRCODE = '23514';
    END IF;
    IF v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 5 THEN
      RAISE EXCEPTION 'REFUND_FAILURE_REASON_REQUIRED: É obrigatório informar o motivo da falha do estorno (mínimo 5 caracteres).'
        USING ERRCODE = '23514';
    END IF;
    v_is_refund_fail_revert := true;
  ELSIF p_target_status = 'ESTORNO_PARCIAL' THEN
    RAISE EXCEPTION 'INVALID_TARGET_PAYMENT_STATUS: Utilize process_booking_refund() para confirmar estorno parcial.'
      USING ERRCODE = '23514';
  END IF;

  -- F01-C: Validações obrigatórias para confirmação de pagamento (PAGO)
  IF p_target_status = 'PAGO' AND NOT v_is_refund_fail_revert THEN
    IF v_booking.status IN ('CANCELADA', 'RECUSADA') THEN
      RAISE EXCEPTION 'PAYMENT_CONFIRM_ON_CANCELLED_FORBIDDEN: Não é permitido confirmar pagamento de uma reserva cancelada ou recusada (%).',
        v_booking.status
        USING ERRCODE = '23514';
    END IF;

    IF COALESCE(v_clean_ext, v_payment.external_transaction_id) IS NULL THEN
      RAISE EXCEPTION 'EXTERNAL_TRANSACTION_ID_REQUIRED: A confirmação de pagamento (PAGO) exige external_transaction_id válido.'
        USING ERRCODE = '23514';
    END IF;

    IF v_is_service_role THEN
      v_confirmation_origin := 'GATEWAY_WEBHOOK';
    ELSE
      v_confirmation_origin := 'MANUAL_ADMIN';
      IF v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 5 THEN
        RAISE EXCEPTION 'ADMIN_CONFIRMATION_REASON_REQUIRED: Confirmação manual administrativa de pagamento exige justificativa auditável (mínimo 5 caracteres).'
          USING ERRCODE = '23514';
      END IF;
    END IF;
  END IF;

  IF NOT public.is_valid_payment_status_transition(v_payment.payment_status, p_target_status) THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Transição financeira inválida de % para %.',
      v_payment.payment_status, p_target_status
      USING ERRCODE = '23514';
  END IF;

  v_prev_status := v_payment.payment_status;

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, p_target_status::text);
  UPDATE public.booking_payments
  SET payment_status = p_target_status,
      external_transaction_id = COALESCE(v_clean_ext, external_transaction_id),
      last_operation_idempotency_key = v_clean_idem,
      confirmed_at = CASE WHEN p_target_status = 'PAGO' THEN COALESCE(confirmed_at, now()) ELSE confirmed_at END,
      cancelled_at = CASE WHEN p_target_status = 'CANCELADO' THEN COALESCE(cancelled_at, now()) ELSE cancelled_at END,
      failure_or_cancel_reason = CASE
        WHEN p_target_status IN ('FALHOU', 'CANCELADO') OR v_is_refund_fail_revert THEN COALESCE(v_clean_reason, failure_or_cancel_reason)
        ELSE failure_or_cancel_reason
      END
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    external_transaction_id,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_status,
    p_target_status,
    CASE WHEN v_is_refund_fail_revert THEN 'REFUND_FAILED_REVERT' ELSE 'TRANSITION_' || p_target_status::text END,
    CASE WHEN v_is_refund_fail_revert THEN 0.00 ELSE v_payment.gross_amount END,
    v_clean_idem,
    v_clean_ext,
    v_uid,
    v_actor_role,
    COALESCE(v_clean_reason, pg_catalog.format('Transição de pagamento %s -> %s', v_prev_status, p_target_status)),
    jsonb_build_object(
      'input_reason', v_clean_reason,
      'external_transaction_id', v_clean_ext,
      'confirmation_origin', v_confirmation_origin,
      'refund_fail_revert', v_is_refund_fail_revert
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  IF p_target_status = 'PAGO' AND NOT v_is_refund_fail_revert THEN
    PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
    INSERT INTO public.financial_ledger_entries (
      booking_id,
      payment_id,
      partner_id,
      tour_id,
      entry_type,
      gross_delta,
      commission_delta,
      net_partner_delta,
      currency,
      idempotency_key,
      reference_transaction_id,
      description,
      actor_user_id,
      actor_role
    ) VALUES (
      v_booking.id,
      v_payment.id,
      v_booking.partner_id,
      v_booking.tour_id,
      'PAYMENT_CONFIRMED',
      v_payment.gross_amount,
      v_payment.commission_amount,
      v_payment.net_partner_amount,
      'BRL',
      'fled-pay-' || v_clean_idem,
      v_payment.external_transaction_id,
      pg_catalog.format('Pagamento confirmado (%s) para reserva %s (%s)', v_confirmation_origin, v_booking.code, v_payment.commission_rule_snapshot->>'commission_rule_label'),
      v_uid,
      v_actor_role
    );
    PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    CASE
      WHEN v_is_refund_fail_revert THEN 'REVERT_FAILED_REFUND'
      WHEN p_target_status = 'PAGO' THEN 'CONFIRM_BOOKING_PAYMENT'
      ELSE 'TRANSITION_BOOKING_PAYMENT'
    END,
    jsonb_build_object('payment_status', v_prev_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'external_transaction_id', v_payment.external_transaction_id,
      'confirmation_origin', v_confirmation_origin,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_status,
    'payment_status', v_payment.payment_status,
    'confirmation_origin', v_confirmation_origin,
    'gross_amount', v_payment.gross_amount,
    'commission_amount', v_payment.commission_amount,
    'net_partner_amount', v_payment.net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount,
    'confirmed_at', v_payment.confirmed_at
  );
END;
$body$;

-- 6. RPC 3A (Nova): Solicitar Estorno em 2 Etapas sem alterar comissão/líquido antes da confirmação (F02, F06-C, F08)
CREATE OR REPLACE FUNCTION public.request_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC,
  p_idempotency_key TEXT,
  p_reason TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_preview_split JSONB;
  v_prev_pay_status public.payment_status_type;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Contexto de autenticação inválido para solicitar estorno.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de solicitação de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo da solicitação de estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL OR v_actor_role = 'tourist' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_REQUEST: Somente administradores ou o parceiro responsável podem solicitar estornos financeiros diretamente.'
      USING ERRCODE = '42501';
  END IF;

  IF p_refund_amount IS NOT NULL AND pg_catalog.round(p_refund_amount::numeric, 2) <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      pg_catalog.round(p_refund_amount::numeric, 2)
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para solicitação de estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF p_refund_amount IS NULL THEN
    v_req_amount := v_payment.effective_gross_amount;
  END IF;

  -- F06-C: Validação estrita de idempotência da solicitação de estorno
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_type <> 'REFUND_REQUESTED'
       OR v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de solicitação de estorno (%) reutilizada com parâmetros divergentes.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'previous_status', v_hist_existing.previous_status,
      'payment_status', v_payment.payment_status,
      'requested_refund_amount', v_req_amount,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status = 'ESTORNO_PENDENTE' THEN
    RAISE EXCEPTION 'REFUND_REQUEST_ALREADY_PENDING: O pagamento da reserva % já possui solicitação de estorno pendente de confirmação.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido solicitar estorno para pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  -- Valida matematicamente que o valor solicitado é positivo e não excede o saldo disponível
  v_preview_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_prev_pay_status := v_payment.payment_status;

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, 'ESTORNO_PENDENTE');
  UPDATE public.booking_payments
  SET payment_status = 'ESTORNO_PENDENTE',
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_pay_status,
    'ESTORNO_PENDENTE',
    'REFUND_REQUESTED',
    v_req_amount,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    jsonb_build_object(
      'input_reason', v_clean_reason,
      'requested_refund_amount', v_req_amount,
      'preview_split', v_preview_split
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    'REQUEST_BOOKING_REFUND',
    jsonb_build_object('payment_status', v_prev_pay_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'requested_refund_amount', v_req_amount,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'requested_refund_amount', v_req_amount,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;

-- 7. RPC 3B: Confirmar e Liquidar Estorno Integral ou Parcial — Restrito a Admin / service_role (F02-A, F06-C, F08)
CREATE OR REPLACE FUNCTION public.process_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC,
  p_idempotency_key TEXT,
  p_reason TEXT,
  p_mark_booking_cancelled BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_mark_cancel BOOLEAN := COALESCE(p_mark_booking_cancelled, false);
  v_split JSONB;
  v_is_full BOOLEAN;
  v_next_pay_status public.payment_status_type;
  v_prev_pay_status public.payment_status_type;
  v_delta_gross NUMERIC(12,2);
  v_delta_comm NUMERIC(12,2);
  v_delta_net NUMERIC(12,2);
  v_pending_req_amount NUMERIC(12,2);
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Contexto de autenticação inválido ou não autorizado para confirmar estorno.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo do estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);

  -- F02-A: Parceiro e turista nunca podem confirmar/liquidar estornos diretamente
  IF v_actor_role = 'partner' THEN
    RAISE EXCEPTION 'PARTNER_REFUND_CONFIRM_FORBIDDEN: Parceiros podem apenas solicitar estorno via request_booking_refund(), sendo a confirmação restrita à administração ou ao gateway.'
      USING ERRCODE = '42501';
  END IF;

  IF v_actor_role IS NULL OR v_actor_role <> 'admin' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou service_role podem confirmar e processar estornos financeiros.'
      USING ERRCODE = '42501';
  END IF;

  IF p_refund_amount IS NOT NULL AND pg_catalog.round(p_refund_amount::numeric, 2) <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      pg_catalog.round(p_refund_amount::numeric, 2)
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  SELECT bph.operation_amount INTO v_pending_req_amount
  FROM public.booking_payment_history AS bph
  WHERE bph.payment_id = v_payment.id
    AND bph.operation_type IN ('REFUND_REQUESTED', 'REFUND_REQUESTED_ON_BOOKING_CANCEL')
  ORDER BY bph.created_at DESC, bph.id DESC
  LIMIT 1;

  IF p_refund_amount IS NULL THEN
    IF v_payment.payment_status = 'ESTORNO_PENDENTE' AND COALESCE(v_pending_req_amount, 0) > 0 THEN
      v_req_amount := v_pending_req_amount;
    ELSE
      v_req_amount := v_payment.effective_gross_amount;
    END IF;
  ELSIF v_payment.payment_status = 'ESTORNO_PENDENTE'
        AND COALESCE(v_pending_req_amount, 0) > 0
        AND v_req_amount > v_pending_req_amount THEN
    RAISE EXCEPTION 'REFUND_EXCEEDS_REQUESTED_AMOUNT: O valor confirmado para estorno (%) excede o valor solicitado pendente (%).',
      v_req_amount, v_pending_req_amount
      USING ERRCODE = '23514';
  END IF;

  -- F06-C: Verifica idempotência rigorosa no histórico de operações financeiras (incluindo reason e mark_booking_cancelled)
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_type NOT IN ('REFUND_FULL', 'REFUND_PARTIAL')
       OR v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount
       OR (v_hist_existing.metadata_json->>'input_reason') IS DISTINCT FROM v_clean_reason
       OR COALESCE((v_hist_existing.metadata_json->>'mark_booking_cancelled')::boolean, false) IS DISTINCT FROM v_mark_cancel THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de estorno (%) reutilizada com parâmetros divergentes.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'payment_status', v_payment.payment_status,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'refunded_commission_amount', v_payment.refunded_commission_amount,
      'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido estornar um pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  v_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_is_full := (v_split->>'is_full_refund')::boolean;
  v_next_pay_status := CASE WHEN v_is_full THEN 'ESTORNADO'::public.payment_status_type ELSE 'ESTORNO_PARCIAL'::public.payment_status_type END;
  v_prev_pay_status := v_payment.payment_status;
  v_delta_gross := (v_split->>'refund_gross_delta')::numeric(12,2);
  v_delta_comm := (v_split->>'refund_commission_delta')::numeric(12,2);
  v_delta_net := (v_split->>'refund_net_delta')::numeric(12,2);

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, v_next_pay_status::text);
  UPDATE public.booking_payments
  SET payment_status = v_next_pay_status,
      refunded_gross_amount = (v_split->>'total_refunded_gross')::numeric(12,2),
      refunded_commission_amount = (v_split->>'total_refunded_commission')::numeric(12,2),
      refunded_net_partner_amount = (v_split->>'total_refunded_net')::numeric(12,2),
      effective_gross_amount = (v_split->>'effective_gross_amount')::numeric(12,2),
      effective_commission_amount = (v_split->>'effective_commission_amount')::numeric(12,2),
      effective_net_partner_amount = (v_split->>'effective_net_partner_amount')::numeric(12,2),
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason,
      refunded_at = now()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_pay_status,
    v_next_pay_status,
    CASE WHEN v_is_full THEN 'REFUND_FULL' ELSE 'REFUND_PARTIAL' END,
    v_delta_gross,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    v_split || jsonb_build_object(
      'input_reason', v_clean_reason,
      'mark_booking_cancelled', v_mark_cancel
    )
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Registra lançamento compensatório negativo (append-only) no razão financeiro
  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_payment.id,
    v_booking.partner_id,
    v_booking.tour_id,
    CASE WHEN v_is_full THEN 'REFUND_FULL'::public.financial_entry_type ELSE 'REFUND_PARTIAL'::public.financial_entry_type END,
    -v_delta_gross,
    -v_delta_comm,
    -v_delta_net,
    'BRL',
    'fled-ref-' || v_clean_idem,
    v_payment.external_transaction_id,
    pg_catalog.format('Estorno %s confirmado na reserva %s: %s', CASE WHEN v_is_full THEN 'integral' ELSE 'parcial' END, v_booking.code, v_clean_reason),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Se o estorno foi integral ou solicitado cancelamento conjunto da reserva e a reserva ainda está ativa
  IF (v_is_full OR v_mark_cancel) AND v_booking.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'EM_DISPUTA') THEN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_booking.id, 'CANCELADA');
    PERFORM internal_guard.issue_token('LEDGER_SYNC', v_booking.id, 'REVERTIDA');
    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = v_clean_reason,
        cancelled_at = COALESCE(cancelled_at, now())
    WHERE id = v_booking.id;
    PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_booking.id);
    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_booking.id);
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    v_actor_role,
    'booking_payments',
    v_booking.code,
    CASE WHEN v_is_full THEN 'CONFIRM_REFUND_FULL' ELSE 'CONFIRM_REFUND_PARTIAL' END,
    jsonb_build_object('payment_status', v_prev_pay_status),
    jsonb_build_object(
      'payment_id', v_payment.id,
      'booking_id', v_booking.id,
      'payment_status', v_payment.payment_status,
      'refund_gross_delta', v_delta_gross,
      'refund_commission_delta', v_delta_comm,
      'refund_net_delta', v_delta_net,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount,
      'reason', v_clean_reason,
      'idempotency_key', v_clean_idem
    )
  );

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'refund_gross_delta', v_delta_gross,
    'refund_commission_delta', v_delta_comm,
    'refund_net_delta', v_delta_net,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;

-- 8. Sincronização Transacional Automática entre Cancelamentos/Conclusão de Reserva e Camada Financeira (F04-A)
CREATE OR REPLACE FUNCTION public.sync_booking_history_ledger_and_audit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID;
  v_actor_role public.app_role;
  v_next_ledger_status public.ledger_status_type;
  v_payment public.booking_payments%ROWTYPE;
  v_ledger public.commission_ledger%ROWTYPE;
  v_prev_pay_status public.payment_status_type;
  v_sync_idem TEXT;
  v_reason_text TEXT;
BEGIN
  v_uid := (SELECT auth.uid());
  v_actor_role := public.resolve_booking_actor_role(NEW.partner_id, NEW.tourist_user_id);

  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      NULL,
      NEW.status,
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      COALESCE(NEW.notes, 'Solicitação inicial de reserva criada')
    );

    PERFORM internal_guard.issue_token('LEDGER_SYNC', NEW.id, 'PREVISTA');

    INSERT INTO public.commission_ledger (
      booking_id,
      partner_id,
      tour_id,
      ledger_status,
      gross_amount,
      commission_amount,
      net_partner_amount,
      rule_snapshot_json
    ) VALUES (
      NEW.id,
      NEW.partner_id,
      NEW.tour_id,
      'PREVISTA',
      NEW.gross_amount,
      NEW.commission_amount,
      NEW.net_partner_amount,
      jsonb_build_object(
        'commission_rule_id', NEW.commission_rule_id,
        'commission_model', NEW.commission_model_snapshot,
        'commission_rate', NEW.commission_rate_snapshot,
        'commission_fixed', NEW.commission_fixed_snapshot,
        'commission_rule_label', NEW.commission_rule_label
      )
    )
    ON CONFLICT (booking_id) DO NOTHING;

    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', NEW.id);

    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      'bookings',
      NEW.code,
      'CREATE_BOOKING',
      NULL,
      to_jsonb(NEW)
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    v_reason_text := COALESCE(NEW.rejection_or_cancel_reason, 'Transição de status validada pelo servidor');

    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      v_uid,
      v_actor_role,
      v_reason_text
    );

    IF NEW.status = 'PASSEIO_REALIZADO' THEN
      v_next_ledger_status := 'CONFIRMADA';
    ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') THEN
      v_next_ledger_status := 'REVERTIDA';
    ELSIF NEW.status = 'EM_DISPUTA' THEN
      v_next_ledger_status := 'EM_DISPUTA';
    ELSE
      v_next_ledger_status := 'PREVISTA';
    END IF;

    PERFORM internal_guard.issue_token('LEDGER_SYNC', NEW.id, v_next_ledger_status::text);

    UPDATE public.commission_ledger
    SET ledger_status = CASE
          WHEN ledger_status = 'PAGA' AND v_next_ledger_status = 'CONFIRMADA' THEN 'PAGA'::public.ledger_status_type
          ELSE v_next_ledger_status
        END,
        consolidated_at = CASE
          WHEN NEW.status = 'PASSEIO_REALIZADO' THEN COALESCE(consolidated_at, now())
          ELSE consolidated_at
        END,
        reversed_at = CASE
          WHEN NEW.status IN ('CANCELADA', 'RECUSADA') THEN COALESCE(reversed_at, now())
          ELSE reversed_at
        END,
        adjustment_notes = COALESCE(NEW.rejection_or_cancel_reason, adjustment_notes),
        updated_by = v_uid,
        updated_at = now()
    WHERE booking_id = NEW.id
    RETURNING * INTO v_ledger;

    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', NEW.id);

    -- F04-A: Sincronização transacional automática com booking_payments, booking_payment_history e financial_ledger_entries
    SELECT * INTO v_payment
    FROM public.booking_payments
    WHERE booking_id = NEW.id
    FOR UPDATE;

    IF v_payment.id IS NOT NULL THEN
      v_prev_pay_status := v_payment.payment_status;

      IF NEW.status IN ('CANCELADA', 'RECUSADA') THEN
        -- Caso 1: Pagamento não confirmado (PENDENTE, PROCESSANDO, FALHOU) -> CANCELADO
        IF v_payment.payment_status IN ('PENDENTE', 'PROCESSANDO', 'FALHOU') THEN
          v_sync_idem := 'sync-bkl-canc-' || pg_catalog.replace(NEW.id::text, '-', '');

          PERFORM internal_guard.issue_token('PAYMENT_MUTATION', NEW.id, 'CANCELADO');
          UPDATE public.booking_payments
          SET payment_status = 'CANCELADO',
              cancelled_at = COALESCE(cancelled_at, now()),
              failure_or_cancel_reason = COALESCE(NEW.rejection_or_cancel_reason, failure_or_cancel_reason, 'Pagamento cancelado automaticamente por cancelamento/recusa da reserva'),
              last_operation_idempotency_key = v_sync_idem
          WHERE id = v_payment.id
          RETURNING * INTO v_payment;
          PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', NEW.id);

          IF NOT EXISTS (SELECT 1 FROM public.booking_payment_history WHERE idempotency_key = v_sync_idem) THEN
            PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', NEW.id, 'booking_payment_history');
            INSERT INTO public.booking_payment_history (
              payment_id,
              booking_id,
              partner_id,
              previous_status,
              new_status,
              operation_type,
              operation_amount,
              idempotency_key,
              actor_user_id,
              actor_role,
              reason,
              metadata_json
            ) VALUES (
              v_payment.id,
              NEW.id,
              NEW.partner_id,
              v_prev_pay_status,
              'CANCELADO',
              'CANCEL_UNPAID_ON_BOOKING_CANCEL',
              0.00,
              v_sync_idem,
              v_uid,
              v_actor_role,
              v_reason_text,
              jsonb_build_object(
                'booking_previous_status', OLD.status,
                'booking_new_status', NEW.status,
                'input_reason', v_reason_text
              )
            );
            PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', NEW.id);
          END IF;

          IF NOT EXISTS (SELECT 1 FROM public.financial_ledger_entries WHERE idempotency_key = 'fled-' || v_sync_idem) THEN
            PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', NEW.id, 'financial_ledger_entries');
            INSERT INTO public.financial_ledger_entries (
              booking_id,
              payment_id,
              commission_ledger_id,
              partner_id,
              tour_id,
              entry_type,
              gross_delta,
              commission_delta,
              net_partner_delta,
              currency,
              idempotency_key,
              reference_transaction_id,
              description,
              actor_user_id,
              actor_role
            ) VALUES (
              NEW.id,
              v_payment.id,
              v_ledger.id,
              NEW.partner_id,
              NEW.tour_id,
              'COMPENSATORY_ADJUSTMENT',
              0.00,
              0.00,
              0.00,
              'BRL',
              'fled-' || v_sync_idem,
              v_payment.external_transaction_id,
              pg_catalog.format('Encerramento de pagamento não confirmado (%s -> CANCELADO) por cancelamento/recusa da reserva %s', v_prev_pay_status, NEW.code),
              v_uid,
              v_actor_role
            );
            PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', NEW.id);
          END IF;

        -- Caso 2: Pagamento confirmado (PAGO ou ESTORNO_PARCIAL) -> ESTORNO_PENDENTE (jamais ESTORNADO sem confirmação!)
        ELSIF v_payment.payment_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
          v_sync_idem := 'sync-bkl-refpend-' || pg_catalog.replace(NEW.id::text, '-', '');

          PERFORM internal_guard.issue_token('PAYMENT_MUTATION', NEW.id, 'ESTORNO_PENDENTE');
          UPDATE public.booking_payments
          SET payment_status = 'ESTORNO_PENDENTE',
              refund_reason = COALESCE(NEW.rejection_or_cancel_reason, refund_reason, 'Estorno pendente aberto automaticamente por cancelamento/recusa da reserva'),
              last_operation_idempotency_key = v_sync_idem
          WHERE id = v_payment.id
          RETURNING * INTO v_payment;
          PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', NEW.id);

          IF NOT EXISTS (SELECT 1 FROM public.booking_payment_history WHERE idempotency_key = v_sync_idem) THEN
            PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', NEW.id, 'booking_payment_history');
            INSERT INTO public.booking_payment_history (
              payment_id,
              booking_id,
              partner_id,
              previous_status,
              new_status,
              operation_type,
              operation_amount,
              idempotency_key,
              actor_user_id,
              actor_role,
              reason,
              metadata_json
            ) VALUES (
              v_payment.id,
              NEW.id,
              NEW.partner_id,
              v_prev_pay_status,
              'ESTORNO_PENDENTE',
              'REFUND_REQUESTED_ON_BOOKING_CANCEL',
              v_payment.effective_gross_amount,
              v_sync_idem,
              v_uid,
              v_actor_role,
              v_reason_text,
              jsonb_build_object(
                'booking_previous_status', OLD.status,
                'booking_new_status', NEW.status,
                'requested_refund_amount', v_payment.effective_gross_amount,
                'input_reason', v_reason_text
              )
            );
            PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', NEW.id);
          END IF;

          IF NOT EXISTS (SELECT 1 FROM public.financial_ledger_entries WHERE idempotency_key = 'fled-' || v_sync_idem) THEN
            PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', NEW.id, 'financial_ledger_entries');
            INSERT INTO public.financial_ledger_entries (
              booking_id,
              payment_id,
              commission_ledger_id,
              partner_id,
              tour_id,
              entry_type,
              gross_delta,
              commission_delta,
              net_partner_delta,
              currency,
              idempotency_key,
              reference_transaction_id,
              description,
              actor_user_id,
              actor_role
            ) VALUES (
              NEW.id,
              v_payment.id,
              v_ledger.id,
              NEW.partner_id,
              NEW.tour_id,
              'COMPENSATORY_ADJUSTMENT',
              0.00,
              0.00,
              0.00,
              'BRL',
              'fled-' || v_sync_idem,
              v_payment.external_transaction_id,
              pg_catalog.format('Abertura automática de estorno pendente (ESTORNO_PENDENTE) por cancelamento da reserva %s — aguardando confirmação administrativa/gateway', NEW.code),
              v_uid,
              v_actor_role
            );
            PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', NEW.id);
          END IF;
        END IF;
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND v_payment.payment_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
        v_sync_idem := 'fled-cons-' || pg_catalog.replace(NEW.id::text, '-', '');
        IF NOT EXISTS (SELECT 1 FROM public.financial_ledger_entries WHERE idempotency_key = v_sync_idem) THEN
          PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', NEW.id, 'financial_ledger_entries');
          INSERT INTO public.financial_ledger_entries (
            booking_id,
            payment_id,
            commission_ledger_id,
            partner_id,
            tour_id,
            entry_type,
            gross_delta,
            commission_delta,
            net_partner_delta,
            currency,
            idempotency_key,
            reference_transaction_id,
            description,
            actor_user_id,
            actor_role
          ) VALUES (
            NEW.id,
            v_payment.id,
            v_ledger.id,
            NEW.partner_id,
            NEW.tour_id,
            'COMMISSION_CONSOLIDATED',
            0.00,
            0.00,
            0.00,
            'BRL',
            v_sync_idem,
            v_payment.external_transaction_id,
            pg_catalog.format('Comissão consolidada após realização do passeio para reserva %s', NEW.code),
            v_uid,
            v_actor_role
          );
          PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', NEW.id);
        END IF;
      END IF;
    END IF;

    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      v_actor_role,
      'bookings',
      NEW.code,
      'STATUS_TRANSITION',
      jsonb_build_object('status', OLD.status),
      jsonb_build_object(
        'status', NEW.status,
        'reason', NEW.rejection_or_cancel_reason,
        'ledger_status', v_next_ledger_status,
        'payment_status', v_payment.payment_status
      )
    );
  END IF;

  RETURN NEW;
END;
$body$;

-- 9. Liquidação de Comissão com validação obrigatória de pagamento confirmado e registro no razão analítico (F04, F05, Cenário 13)
CREATE OR REPLACE FUNCTION public.settle_commission_ledger(
  p_booking_id TEXT,
  p_adjustment_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings;
  v_ledger public.commission_ledger;
  v_payment public.booking_payments%ROWTYPE;
  v_clean_id TEXT := pg_catalog.btrim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_has_any_payment_rows BOOLEAN := false;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND v_json_role IS DISTINCT FROM 'anon'
        AND v_json_role IS DISTINCT FROM 'authenticated'
        AND (
          (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock: Lock #1 vessels -> Lock #2 advisory_lock -> Lock #3 bookings -> Lock #4 commission_ledger
  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  PERFORM 1 FROM public.bookings WHERE id = v_booking.id FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_ledger.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_NOT_FOUND: Registro financeiro não encontrado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF v_ledger.ledger_status = 'PAGA' THEN
    RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão da reserva % já foi liquidada em %.', v_booking.code, v_ledger.paid_at
      USING ERRCODE = '23514';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' OR v_ledger.ledger_status <> 'CONFIRMADA' THEN
    RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (atual: reserva=%, ledger=%).',
      v_booking.status, v_ledger.ledger_status
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  SELECT EXISTS (SELECT 1 FROM public.booking_payments) INTO v_has_any_payment_rows;

  IF v_payment.id IS NOT NULL OR v_has_any_payment_rows THEN
    IF v_payment.id IS NULL
       OR v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL')
       OR v_payment.effective_net_partner_amount <= 0 THEN
      RAISE EXCEPTION 'LEDGER_SETTLEMENT_REQUIRES_CONFIRMED_PAYMENT: Somente reservas com pagamento confirmado (PAGO ou ESTORNO_PARCIAL com saldo líquido positivo) podem ter comissão liquidada (status do pagamento: %).',
        COALESCE(v_payment.payment_status::text, 'SEM_PAGAMENTO')
        USING ERRCODE = '23514';
    END IF;
  END IF;

  PERFORM internal_guard.issue_token('LEDGER_SETTLE', v_booking.id, 'PAGA');

  UPDATE public.commission_ledger
  SET ledger_status = 'PAGA',
      paid_at = now(),
      adjustment_notes = COALESCE(NULLIF(pg_catalog.btrim(COALESCE(p_adjustment_notes, '')), ''), adjustment_notes),
      updated_by = v_uid,
      updated_at = now()
  WHERE id = v_ledger.id
  RETURNING * INTO v_ledger;

  PERFORM internal_guard.cleanup_tokens('LEDGER_SETTLE', v_booking.id);

  IF v_payment.id IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM public.financial_ledger_entries WHERE idempotency_key = 'fled-settle-' || pg_catalog.replace(v_booking.id::text, '-', '')) THEN
      PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
      INSERT INTO public.financial_ledger_entries (
        booking_id,
        payment_id,
        commission_ledger_id,
        partner_id,
        tour_id,
        entry_type,
        gross_delta,
        commission_delta,
        net_partner_delta,
        currency,
        idempotency_key,
        reference_transaction_id,
        description,
        actor_user_id,
        actor_role
      ) VALUES (
        v_booking.id,
        v_payment.id,
        v_ledger.id,
        v_booking.partner_id,
        v_booking.tour_id,
        'PARTNER_PAYOUT_SETTLED',
        0.00,
        0.00,
        0.00,
        'BRL',
        'fled-settle-' || pg_catalog.replace(v_booking.id::text, '-', ''),
        v_payment.external_transaction_id,
        pg_catalog.format('Liquidação de comissão e repasse ao parceiro concluída para reserva %s (comissão efetiva R$ %s | líquido parceiro R$ %s)', v_booking.code, v_payment.effective_commission_amount, v_payment.effective_net_partner_amount),
        v_uid,
        'admin'
      );
      PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
    END IF;
  END IF;

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'commission_ledger',
    v_booking.code,
    'SETTLE_COMMISSION',
    jsonb_build_object('ledger_status', 'CONFIRMADA'),
    jsonb_build_object(
      'ledger_status', 'PAGA',
      'paid_at', v_ledger.paid_at,
      'commission_amount', v_ledger.commission_amount,
      'payment_status', v_payment.payment_status
    )
  );

  RETURN jsonb_build_object(
    'ledger_id', v_ledger.id,
    'booking_id', v_booking.id,
    'booking_code', v_booking.code,
    'ledger_status', v_ledger.ledger_status,
    'payment_status', v_payment.payment_status,
    'gross_amount', v_ledger.gross_amount,
    'commission_amount', v_ledger.commission_amount,
    'net_partner_amount', v_ledger.net_partner_amount,
    'paid_at', v_ledger.paid_at
  );
END;
$body$;

-- 10. RPC 4: Conciliação Financeira Completa em 5 Tabelas com Snapshot Histórico (F05-A, F05-B, F08)
CREATE OR REPLACE FUNCTION public.get_financial_reconciliation_report(
  p_partner_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_admin BOOLEAN := false;
  v_effective_partner_id UUID := p_partner_id;
  v_discrepancies JSONB := '[]'::jsonb;
  v_item RECORD;
  v_exp_gross NUMERIC(12,2);
  v_exp_comm NUMERIC(12,2);
  v_exp_net NUMERIC(12,2);
  v_last_hist_status public.payment_status_type;
  v_hist_count INTEGER;
  v_fle_count INTEGER;
  v_fle_sum_gross NUMERIC(12,2);
  v_fle_sum_comm NUMERIC(12,2);
  v_fle_sum_net NUMERIC(12,2);
  v_dup_pay_confirmed INTEGER;
  v_dup_refund_full INTEGER;
  v_dup_payout_settled INTEGER;
  v_exp_fle_gross NUMERIC(12,2);
  v_exp_fle_comm NUMERIC(12,2);
  v_exp_fle_net NUMERIC(12,2);
  v_total_gross_received NUMERIC(12,2) := 0.00;
  v_total_commissions NUMERIC(12,2) := 0.00;
  v_total_net_partner NUMERIC(12,2) := 0.00;
  v_total_refunded NUMERIC(12,2) := 0.00;
  v_pending_payments_count INTEGER := 0;
  v_confirmed_payments_count INTEGER := 0;
  v_refunded_payments_count INTEGER := 0;
  v_pending_refunds_count INTEGER := 0;
  v_orphan_payments_count INTEGER := 0;
  v_orphan_history_count INTEGER := 0;
  v_refund_req_count INTEGER := 0;
  v_improper_refund_count INTEGER := 0;
  v_orph_pay RECORD;
  v_orph_hist RECORD;
BEGIN
  -- Guarda 4-fatores de autenticação (F08)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Autenticação válida é obrigatória para consultar conciliação financeira.'
      USING ERRCODE = '42501';
  END IF;

  IF public.is_admin() OR (
    v_uid IS NULL
    AND v_db_role NOT IN ('anon', 'authenticated')
    AND v_jwt_role NOT IN ('anon', 'authenticated')
    AND v_json_role IS DISTINCT FROM 'anon'
    AND v_json_role IS DISTINCT FROM 'authenticated'
    AND (
      (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
      OR (
        v_db_role IN ('none', 'postgres', 'supabase_admin')
        AND session_user IN ('postgres', 'supabase_admin', 'service_role')
        AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
      )
    )
  ) THEN
    v_is_admin := true;
  END IF;

  IF NOT v_is_admin THEN
    IF v_uid IS NULL THEN
      RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Sessão não autenticada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_effective_partner_id IS NULL THEN
      SELECT pm.partner_id INTO v_effective_partner_id
      FROM public.partner_members AS pm
      WHERE pm.user_id = v_uid AND pm.is_active = true
      LIMIT 1;
    END IF;

    IF v_effective_partner_id IS NULL OR NOT public.is_partner_member(v_effective_partner_id) THEN
      RAISE EXCEPTION 'CROSS_TENANT_FINANCIAL_ACCESS_DENIED: Usuário não possui permissão financeira para consultar este parceiro.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  FOR v_item IN
    SELECT
      bk.id AS booking_id,
      bk.code AS booking_code,
      bk.partner_id,
      bk.tour_id,
      bk.passengers,
      bk.status AS booking_status,
      bk.pricing_model_snapshot,
      bk.unit_price_snapshot,
      bk.commission_model_snapshot,
      bk.commission_rate_snapshot,
      bk.commission_fixed_snapshot,
      bk.gross_amount AS booking_gross,
      bk.commission_amount AS booking_commission,
      bk.net_partner_amount AS booking_net,
      cl.id AS commission_ledger_id,
      cl.ledger_status,
      cl.gross_amount AS ledger_gross,
      cl.commission_amount AS ledger_commission,
      cl.net_partner_amount AS ledger_net,
      bp.id AS payment_id,
      bp.payment_status,
      bp.gross_amount AS payment_gross,
      bp.commission_amount AS payment_commission,
      bp.net_partner_amount AS payment_net,
      bp.refunded_gross_amount,
      bp.refunded_commission_amount,
      bp.refunded_net_partner_amount,
      bp.effective_gross_amount,
      bp.effective_commission_amount,
      bp.effective_net_partner_amount
    FROM public.bookings AS bk
    LEFT JOIN public.commission_ledger AS cl ON cl.booking_id = bk.id
    LEFT JOIN public.booking_payments AS bp ON bp.booking_id = bk.id
    WHERE (v_effective_partner_id IS NULL OR bk.partner_id = v_effective_partner_id)
    ORDER BY bk.created_at ASC
  LOOP
    -- F05-B: Calcula os valores esperados exclusivamente a partir do snapshot histórico persistido na reserva
    IF v_item.pricing_model_snapshot = 'POR_EMBARCACAO' THEN
      v_exp_gross := pg_catalog.round(COALESCE(v_item.unit_price_snapshot, 0)::numeric, 2);
    ELSE
      v_exp_gross := pg_catalog.round((COALESCE(v_item.unit_price_snapshot, 0) * COALESCE(v_item.passengers, 1))::numeric, 2);
    END IF;

    IF v_item.commission_model_snapshot = 'PERCENTUAL' THEN
      v_exp_comm := pg_catalog.round((v_exp_gross * COALESCE(v_item.commission_rate_snapshot, 0)) / 100.0, 2);
    ELSIF v_item.commission_model_snapshot = 'VALOR_FIXO' THEN
      v_exp_comm := pg_catalog.least(v_exp_gross, pg_catalog.round(COALESCE(v_item.commission_fixed_snapshot, 0)::numeric, 2));
    ELSE
      v_exp_comm := pg_catalog.least(
        v_exp_gross,
        pg_catalog.round(((v_exp_gross * COALESCE(v_item.commission_rate_snapshot, 0)) / 100.0) + COALESCE(v_item.commission_fixed_snapshot, 0), 2)
      );
    END IF;

    v_exp_net := v_exp_gross - v_exp_comm;

    -- 1. Divergência de split financeiro ou snapshot histórico (bookings vs snapshot vs commission_ledger vs booking_payments)
    IF v_item.booking_gross <> (v_item.booking_commission + v_item.booking_net)
       OR v_item.booking_gross <> v_exp_gross
       OR v_item.booking_commission <> v_exp_comm
       OR v_item.booking_net <> v_exp_net
       OR (v_item.ledger_gross IS NOT NULL AND (
            v_item.ledger_gross <> v_item.booking_gross
            OR v_item.ledger_commission <> v_item.booking_commission
            OR v_item.ledger_net <> v_item.booking_net
          ))
       OR (v_item.payment_id IS NOT NULL AND (
            v_item.payment_gross <> v_item.booking_gross
            OR v_item.payment_commission <> v_item.booking_commission
            OR v_item.payment_net <> v_item.booking_net
            OR v_item.effective_gross_amount <> (v_item.payment_gross - v_item.refunded_gross_amount)
            OR v_item.effective_commission_amount <> (v_item.payment_commission - v_item.refunded_commission_amount)
            OR v_item.effective_net_partner_amount <> (v_item.payment_net - v_item.refunded_net_partner_amount)
            OR v_item.effective_gross_amount <> (v_item.effective_commission_amount + v_item.effective_net_partner_amount)
          )) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'FINANCIAL_SPLIT_MISMATCH',
          'expected_gross', v_exp_gross,
          'expected_commission', v_exp_comm,
          'expected_net', v_exp_net,
          'recorded_booking_gross', v_item.booking_gross,
          'recorded_ledger_gross', v_item.ledger_gross,
          'recorded_payment_gross', v_item.payment_gross,
          'justification', 'Divergência entre o snapshot histórico da reserva, os valores da reserva, o livro-razão de comissões ou o pagamento.'
        )
      );
    END IF;

    -- 2. Reserva concluída (PASSEIO_REALIZADO) sem pagamento confirmado compatível
    IF v_item.booking_status = 'PASSEIO_REALIZADO'
       AND (v_item.payment_id IS NULL OR v_item.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL', 'ESTORNADO')) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'COMPLETED_BOOKING_UNPAID',
          'booking_status', v_item.booking_status,
          'payment_status', COALESCE(v_item.payment_status::text, 'SEM_PAGAMENTO'),
          'justification', 'Reserva marcada como PASSEIO_REALIZADO não possui pagamento confirmado.'
        )
      );
    END IF;

    -- 3. Reserva cancelada/recusada com pagamento não sincronizado (PENDENTE, PROCESSANDO, FALHOU, PAGO, ESTORNO_PARCIAL)
    IF v_item.booking_status IN ('CANCELADA', 'RECUSADA')
       AND v_item.payment_id IS NOT NULL
       AND v_item.payment_status IN ('PENDENTE', 'PROCESSANDO', 'FALHOU', 'PAGO', 'ESTORNO_PARCIAL') THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'CANCELLED_BOOKING_UNREFUNDED_PAYMENT',
          'booking_status', v_item.booking_status,
          'payment_status', v_item.payment_status,
          'justification', 'Reserva cancelada/recusada possui pagamento dessincronizado (sem transição para CANCELADO ou ESTORNO_PENDENTE/ESTORNADO).'
        )
      );
    END IF;

    -- 4. Estorno inconsistente
    IF v_item.payment_id IS NOT NULL AND (
         (v_item.payment_status = 'ESTORNADO' AND (v_item.refunded_gross_amount <> v_item.payment_gross OR v_item.effective_gross_amount <> 0))
         OR (v_item.payment_status = 'ESTORNO_PARCIAL' AND (v_item.refunded_gross_amount <= 0 OR v_item.refunded_gross_amount >= v_item.payment_gross))
         OR (v_item.payment_status IN ('PENDENTE', 'PROCESSANDO', 'FALHOU', 'CANCELADO') AND v_item.refunded_gross_amount > 0)
       ) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'INCONSISTENT_REFUND_STATE',
          'payment_status', v_item.payment_status,
          'refunded_gross_amount', v_item.refunded_gross_amount,
          'effective_gross_amount', v_item.effective_gross_amount,
          'justification', 'Estado de estorno do pagamento incompatível com os montantes estornado e efetivo.'
        )
      );
    END IF;

    -- 5. Liquidação de comissão (PAGA) sem pagamento confirmado ou saldo líquido positivo
    IF v_item.ledger_status = 'PAGA'
       AND (
         v_item.booking_status <> 'PASSEIO_REALIZADO'
         OR v_item.payment_id IS NULL
         OR v_item.payment_status NOT IN ('PAGO', 'ESTORNO_PARCIAL')
         OR v_item.effective_net_partner_amount <= 0
       ) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_item.booking_id,
          'booking_code', v_item.booking_code,
          'discrepancy_code', 'SETTLED_COMMISSION_WITHOUT_CONFIRMED_PAYMENT',
          'booking_status', v_item.booking_status,
          'ledger_status', v_item.ledger_status,
          'payment_status', COALESCE(v_item.payment_status::text, 'SEM_PAGAMENTO'),
          'justification', 'Comissão consta como PAGA no livro-razão sem pagamento confirmado ativo e passeio realizado.'
        )
      );
    END IF;

    -- 6. Conciliação cruzada com booking_payment_history e financial_ledger_entries
    IF v_item.payment_id IS NOT NULL THEN
      SELECT COUNT(*) INTO v_hist_count
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id;

      SELECT bph.new_status INTO v_last_hist_status
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id
      ORDER BY bph.created_at DESC, bph.id DESC
      LIMIT 1;

      IF v_hist_count = 0 OR v_last_hist_status IS DISTINCT FROM v_item.payment_status THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'PAYMENT_HISTORY_MISMATCH',
            'payment_status', v_item.payment_status,
            'last_history_status', v_last_hist_status,
            'history_entries_count', v_hist_count,
            'justification', 'O último estado registrado em booking_payment_history diverge do status atual em booking_payments.'
          )
        );
      END IF;

      -- 6B. Estorno sem solicitação prévia em 2 etapas (REFUND_WITHOUT_REQUEST)
      IF v_item.payment_status IN ('ESTORNADO', 'ESTORNO_PARCIAL') OR v_item.refunded_gross_amount > 0 THEN
        SELECT COUNT(*) INTO v_refund_req_count
        FROM public.booking_payment_history AS bph
        WHERE bph.payment_id = v_item.payment_id
          AND (
            bph.new_status = 'ESTORNO_PENDENTE'
            OR bph.operation_type IN ('REFUND_REQUESTED', 'REFUND_REQUESTED_ON_BOOKING_CANCEL')
          );

        IF v_refund_req_count = 0 THEN
          v_discrepancies := v_discrepancies || jsonb_build_array(
            jsonb_build_object(
              'booking_id', v_item.booking_id,
              'booking_code', v_item.booking_code,
              'discrepancy_code', 'REFUND_WITHOUT_REQUEST',
              'payment_status', v_item.payment_status,
              'refunded_gross_amount', v_item.refunded_gross_amount,
              'justification', 'Estorno confirmado sem registro prévio de solicitação (ESTORNO_PENDENTE) em booking_payment_history.'
            )
          );
        END IF;
      END IF;

      -- 6C. Estorno pendente indevidamente finalizado (PENDING_REFUND_IMPROPERLY_FINALIZED)
      SELECT COUNT(*) INTO v_improper_refund_count
      FROM public.booking_payment_history AS bph
      WHERE bph.payment_id = v_item.payment_id
        AND bph.operation_type IN ('REFUND_FULL', 'REFUND_PARTIAL')
        AND bph.actor_role IN ('partner', 'tourist');

      IF v_improper_refund_count > 0
         OR (
           v_item.payment_status = 'ESTORNO_PENDENTE'
           AND v_item.refunded_gross_amount > 0
           AND NOT EXISTS (
             SELECT 1 FROM public.booking_payment_history AS bph
             WHERE bph.payment_id = v_item.payment_id
               AND bph.operation_type = 'REFUND_PARTIAL'
           )
         ) THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'PENDING_REFUND_IMPROPERLY_FINALIZED',
            'payment_status', v_item.payment_status,
            'refunded_gross_amount', v_item.refunded_gross_amount,
            'justification', 'Estorno pendente finalizado por papel não autorizado ou com abatimento contábil prematuro antes da confirmação administrativa.'
          )
        );
      END IF;

      SELECT
        COUNT(*),
        COALESCE(SUM(fle.gross_delta), 0.00),
        COALESCE(SUM(fle.commission_delta), 0.00),
        COALESCE(SUM(fle.net_partner_delta), 0.00),
        COUNT(*) FILTER (WHERE fle.entry_type = 'PAYMENT_CONFIRMED'),
        COUNT(*) FILTER (WHERE fle.entry_type = 'REFUND_FULL'),
        COUNT(*) FILTER (WHERE fle.entry_type = 'PARTNER_PAYOUT_SETTLED')
      INTO
        v_fle_count,
        v_fle_sum_gross,
        v_fle_sum_comm,
        v_fle_sum_net,
        v_dup_pay_confirmed,
        v_dup_refund_full,
        v_dup_payout_settled
      FROM public.financial_ledger_entries AS fle
      WHERE fle.booking_id = v_item.booking_id;

      IF v_item.payment_status IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL', 'ESTORNADO') THEN
        v_exp_fle_gross := v_item.effective_gross_amount;
        v_exp_fle_comm := v_item.effective_commission_amount;
        v_exp_fle_net := v_item.effective_net_partner_amount;
      ELSE
        v_exp_fle_gross := 0.00;
        v_exp_fle_comm := 0.00;
        v_exp_fle_net := 0.00;
      END IF;

      IF v_fle_count = 0
         OR v_fle_sum_gross <> v_exp_fle_gross
         OR v_fle_sum_comm <> v_exp_fle_comm
         OR v_fle_sum_net <> v_exp_fle_net THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'LEDGER_ENTRIES_SUM_MISMATCH',
            'expected_effective_gross', v_exp_fle_gross,
            'ledger_entries_sum_gross', v_fle_sum_gross,
            'expected_effective_commission', v_exp_fle_comm,
            'ledger_entries_sum_commission', v_fle_sum_comm,
            'expected_effective_net', v_exp_fle_net,
            'ledger_entries_sum_net', v_fle_sum_net,
            'justification', 'A soma algébrica dos lançamentos em financial_ledger_entries diverge do saldo efetivo do pagamento.'
          )
        );
      END IF;

      IF v_dup_pay_confirmed > 1 OR v_dup_refund_full > 1 OR v_dup_payout_settled > 1 THEN
        v_discrepancies := v_discrepancies || jsonb_build_array(
          jsonb_build_object(
            'booking_id', v_item.booking_id,
            'booking_code', v_item.booking_code,
            'discrepancy_code', 'DUPLICATE_LEDGER_ENTRY',
            'payment_confirmed_entries', v_dup_pay_confirmed,
            'refund_full_entries', v_dup_refund_full,
            'payout_settled_entries', v_dup_payout_settled,
            'justification', 'Foram detectados lançamentos contábeis unitários duplicados em financial_ledger_entries.'
          )
        );
      END IF;

      -- Acumuladores financeiros por estado
      IF v_item.payment_status IN ('PENDENTE', 'PROCESSANDO') THEN
        v_pending_payments_count := v_pending_payments_count + 1;
      ELSIF v_item.payment_status = 'ESTORNO_PENDENTE' THEN
        v_pending_refunds_count := v_pending_refunds_count + 1;
        v_confirmed_payments_count := v_confirmed_payments_count + 1;
        v_total_gross_received := v_total_gross_received + v_item.effective_gross_amount;
        v_total_commissions := v_total_commissions + v_item.effective_commission_amount;
        v_total_net_partner := v_total_net_partner + v_item.effective_net_partner_amount;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      ELSIF v_item.payment_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
        v_confirmed_payments_count := v_confirmed_payments_count + 1;
        v_total_gross_received := v_total_gross_received + v_item.effective_gross_amount;
        v_total_commissions := v_total_commissions + v_item.effective_commission_amount;
        v_total_net_partner := v_total_net_partner + v_item.effective_net_partner_amount;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      ELSIF v_item.payment_status = 'ESTORNADO' THEN
        v_refunded_payments_count := v_refunded_payments_count + 1;
        v_total_refunded := v_total_refunded + v_item.refunded_gross_amount;
      END IF;
    END IF;
  END LOOP;

  -- 7. Pagamentos órfãos sem reserva correspondente (ORPHAN_PAYMENT_WITHOUT_BOOKING)
  FOR v_orph_pay IN
    SELECT bp.id AS payment_id, bp.booking_id, bp.partner_id, bp.payment_status, bp.gross_amount
    FROM public.booking_payments AS bp
    WHERE NOT EXISTS (SELECT 1 FROM public.bookings AS bk WHERE bk.id = bp.booking_id)
      AND (v_effective_partner_id IS NULL OR bp.partner_id = v_effective_partner_id)
  LOOP
    v_orphan_payments_count := v_orphan_payments_count + 1;
    v_discrepancies := v_discrepancies || jsonb_build_array(
      jsonb_build_object(
        'booking_id', v_orph_pay.booking_id,
        'payment_id', v_orph_pay.payment_id,
        'discrepancy_code', 'ORPHAN_PAYMENT_WITHOUT_BOOKING',
        'payment_status', v_orph_pay.payment_status,
        'recorded_payment_gross', v_orph_pay.gross_amount,
        'justification', 'Pagamento órfão em booking_payments sem reserva correspondente em bookings.'
      )
    );
  END LOOP;

  -- 8. Históricos de pagamento órfãos sem registro correspondente em booking_payments (ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT)
  FOR v_orph_hist IN
    SELECT bph.id AS history_id, bph.payment_id, bph.booking_id, bph.new_status, bph.operation_type
    FROM public.booking_payment_history AS bph
    WHERE NOT EXISTS (SELECT 1 FROM public.booking_payments AS bp WHERE bp.id = bph.payment_id)
      AND (v_effective_partner_id IS NULL OR bph.partner_id = v_effective_partner_id)
  LOOP
    v_orphan_history_count := v_orphan_history_count + 1;
    v_discrepancies := v_discrepancies || jsonb_build_array(
      jsonb_build_object(
        'booking_id', v_orph_hist.booking_id,
        'payment_id', v_orph_hist.payment_id,
        'history_id', v_orph_hist.history_id,
        'discrepancy_code', 'ORPHAN_PAYMENT_HISTORY_WITHOUT_PAYMENT',
        'last_history_status', v_orph_hist.new_status,
        'justification', 'Registro órfão em booking_payment_history sem pagamento correspondente em booking_payments.'
      )
    );
  END LOOP;

  RETURN jsonb_build_object(
    'ok', true,
    'scope_partner_id', v_effective_partner_id,
    'total_gross_received', v_total_gross_received,
    'total_commissions', v_total_commissions,
    'total_net_partner', v_total_net_partner,
    'total_refunded', v_total_refunded,
    'pending_payments_count', v_pending_payments_count,
    'pending_refunds_count', v_pending_refunds_count,
    'confirmed_payments_count', v_confirmed_payments_count,
    'refunded_payments_count', v_refunded_payments_count,
    'orphan_payments_count', v_orphan_payments_count,
    'orphan_history_count', v_orphan_history_count,
    'discrepancies_count', pg_catalog.jsonb_array_length(v_discrepancies),
    'discrepancies', v_discrepancies
  );
END;
$body$;

-- 11. Anonimização LGPD com Sanitização Textual nas Tabelas Financeiras e Preservação Integral dos Valores Contábeis (F08-B)
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_payment public.booking_payments%ROWTYPE;
  v_review RECORD;
  v_existing_audit RECORD;
  v_hist_row RECORD;
  v_fle_row RECORD;
  v_clean_protocol TEXT := pg_catalog.btrim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_active_key_ver SMALLINT;
  v_root_key_ver SMALLINT;
  v_idem_key_ver SMALLINT;
  v_scope_key_ver SMALLINT;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_orig_idem_key VARCHAR(64);
  v_root_hash24 TEXT;
  v_owner_scope_hash20 TEXT;
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_anon_fin_fail_reason TEXT;
  v_anon_fin_refund_reason TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_norm_old_name TEXT;
  v_norm_comment TEXT;
  v_norm_comment_geo_stripped TEXT;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_financial_payment_sanitized BOOLEAN := false;
  v_financial_history_sanitized_count INTEGER := 0;
  v_financial_entries_sanitized_count INTEGER := 0;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR v_json_role = 'anon'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_uid IS NOT NULL AND v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR (v_uid IS NULL AND v_json_sub IS NOT NULL)
     OR (v_db_role = 'authenticated' AND v_jwt_role <> 'authenticated')
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND (v_jwt_role NOT IN ('', 'service_role') OR v_uid IS NOT NULL)) THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL
     AND v_jwt_role = 'authenticated'
     AND (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND v_json_role IS DISTINCT FROM 'anon'
        AND v_json_role IS DISTINCT FROM 'authenticated'
        AND (
          (v_db_role = 'service_role' AND v_jwt_role IN ('', 'service_role'))
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  v_active_key_ver := internal_guard.require_active_hmac_secret();

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock: Lock #1 vessels -> Lock #2 advisory_lock -> Lock #3 bookings
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_target.vessel_id::text), pg_catalog.hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || pg_catalog.lower(v_target.code) || '@lgpd.invalid';
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$')
     AND v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$'
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %')
     AND (v_payment.id IS NULL OR (
          (v_payment.failure_or_cancel_reason IS NULL OR v_payment.failure_or_cancel_reason LIKE '[LGPD %')
          AND (v_payment.refund_reason IS NULL OR v_payment.refund_reason LIKE '[LGPD %')
     )) THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs AS al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'original_idempotency_key', v_target.original_idempotency_key,
      'idempotency_generation', v_target.idempotency_generation,
      'hmac_key_version', v_target.hmac_key_version,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := pg_catalog.btrim(COALESCE(v_target.customer_name, ''));
  v_old_email := pg_catalog.lower(pg_catalog.btrim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := pg_catalog.regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  IF v_target.idempotency_key ~ ('^lgpd-' || pg_catalog.replace(v_target.id::text, '-', '') || '-[0-9a-f]{16}$') THEN
    v_anon_idem_key := v_target.idempotency_key;
    v_idem_key_ver := COALESCE(v_target.lineage_idem_key_version, v_target.hmac_key_version, v_active_key_ver);
  ELSE
    v_anon_idem_key := (
      'lgpd-'
      || pg_catalog.replace(v_target.id::text, '-', '')
      || '-'
      || pg_catalog.left(internal_guard.compute_lineage_mac('LGPD_IDEM_AUTH', pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)), v_active_key_ver), 16)
    )::varchar(64);
    v_idem_key_ver := v_active_key_ver;
  END IF;

  IF v_target.original_idempotency_key ~ '^lgpd-lin-[0-9a-f]{24}-[0-9a-f]{20}$' THEN
    v_anon_orig_idem_key := v_target.original_idempotency_key;
    v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version, v_active_key_ver);
    v_scope_key_ver := COALESCE(v_target.lineage_scope_key_version, v_target.hmac_key_version, v_active_key_ver);
  ELSE
    IF pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)) ~ '^idg-[0-9a-f]{24}-g[0-9]{4}-[0-9a-f]{24}$' THEN
      v_root_hash24 := pg_catalog.substring(pg_catalog.lower(pg_catalog.btrim(v_target.idempotency_key)) from 5 for 24);
      v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version);
    ELSIF pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)) ~ '^idg-root-[0-9a-f]{24}$' THEN
      v_root_hash24 := pg_catalog.substring(pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)) from 10 for 24);
      v_root_key_ver := COALESCE(v_target.lineage_root_key_version, v_target.hmac_key_version);
    ELSE
      v_root_hash24 := pg_catalog.left(
        internal_guard.compute_lineage_mac('LINEAGE_ROOT_V1', pg_catalog.lower(pg_catalog.btrim(v_target.original_idempotency_key)), v_active_key_ver),
        24
      );
      v_root_key_ver := v_active_key_ver;
    END IF;

    v_owner_scope_hash20 := pg_catalog.left(
      internal_guard.compute_lineage_mac(
        'LGPD_OWNER_SCOPE',
        v_target.tour_id::text || ':' || v_target.booking_date::text || ':' || v_old_phone_digits || ':' || v_old_email,
        v_active_key_ver
      ),
      20
    );
    v_scope_key_ver := v_active_key_ver;
    v_anon_orig_idem_key := ('lgpd-lin-' || v_root_hash24 || '-' || v_owner_scope_hash20)::varchar(64);
  END IF;

  v_anon_notes := pg_catalog.format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      pg_catalog.format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      original_idempotency_key = v_anon_orig_idem_key,
      hmac_key_version = v_active_key_ver,
      lineage_root_key_version = v_root_key_ver,
      lineage_idem_key_version = v_idem_key_ver,
      lineage_scope_key_version = v_scope_key_ver,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  UPDATE public.booking_status_history
  SET reason = pg_catalog.format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        pg_catalog.format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  -- F08-B: Sanitização textual em booking_payments, booking_payment_history e financial_ledger_entries preservando 100% dos valores contábeis
  IF v_payment.id IS NOT NULL THEN
    v_anon_fin_fail_reason := CASE
      WHEN v_payment.failure_or_cancel_reason IS NOT NULL THEN
        pg_catalog.format('[LGPD %s] Motivo financeiro de falha/cancelamento sanitizado conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;
    v_anon_fin_refund_reason := CASE
      WHEN v_payment.refund_reason IS NOT NULL THEN
        pg_catalog.format('[LGPD %s] Motivo de estorno financeiro sanitizado conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_payment.failure_or_cancel_reason IS DISTINCT FROM v_anon_fin_fail_reason
       OR v_payment.refund_reason IS DISTINCT FROM v_anon_fin_refund_reason THEN
      PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_target.id, 'LGPD_FINANCIAL_SANITIZE:' || v_payment.payment_status::text);
      UPDATE public.booking_payments
      SET failure_or_cancel_reason = v_anon_fin_fail_reason,
          refund_reason = v_anon_fin_refund_reason
      WHERE id = v_payment.id;
      PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_target.id);
      v_financial_payment_sanitized := true;
    END IF;

    FOR v_hist_row IN
      SELECT bph.id, bph.previous_status, bph.new_status, bph.metadata_json
      FROM public.booking_payment_history AS bph
      WHERE bph.booking_id = v_target.id
      FOR UPDATE
    LOOP
      PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_target.id, 'LGPD_SANITIZE:booking_payment_history');
      UPDATE public.booking_payment_history
      SET reason = pg_catalog.format(
            '[LGPD %s] Histórico financeiro (%s -> %s) preservado com motivo sanitizado.',
            v_clean_protocol,
            COALESCE(v_hist_row.previous_status::text, 'INICIAL'),
            v_hist_row.new_status::text
          ),
          actor_user_id = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
            ELSE actor_user_id
          END,
          metadata_json = CASE
            WHEN v_hist_row.metadata_json ? 'input_reason' THEN
              v_hist_row.metadata_json || jsonb_build_object('input_reason', v_anon_notes, 'lgpd_anonymized', true)
            ELSE v_hist_row.metadata_json
          END
      WHERE id = v_hist_row.id;
      PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_target.id);
      v_financial_history_sanitized_count := v_financial_history_sanitized_count + 1;
    END LOOP;

    FOR v_fle_row IN
      SELECT fle.id, fle.entry_type
      FROM public.financial_ledger_entries AS fle
      WHERE fle.booking_id = v_target.id
      FOR UPDATE
    LOOP
      PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_target.id, 'LGPD_SANITIZE:financial_ledger_entries');
      UPDATE public.financial_ledger_entries
      SET description = pg_catalog.format(
            '[LGPD %s] Lançamento contábil (%s) preservado com descrição sanitizada (reserva %s).',
            v_clean_protocol,
            v_fle_row.entry_type::text,
            v_target.code
          ),
          actor_user_id = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
            ELSE actor_user_id
          END
      WHERE id = v_fle_row.id;
      PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_target.id);
      v_financial_entries_sanitized_count := v_financial_entries_sanitized_count + 1;
    END LOOP;
  END IF;

  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_norm_old_name := public.normalize_lgpd_text(v_old_name);
    v_norm_comment := public.normalize_lgpd_text(v_review.comment);

    v_norm_comment_geo_stripped := pg_catalog.regexp_replace(
      ' ' || v_norm_comment || ' ',
      ' (pela costa norte|da costa norte|na costa norte|costa norte|pela costa sul|da costa sul|na costa sul|costa sul|costa verde|costa brava|costa atlantica|praia da costa|pela costa|da costa|na costa|base marina|marina do saco|marina no saco|marina saco|marina itagua|marina porto|vaga na marina|praia da rosa|praia brava|praia grande|ilha anchieta|ilha das couves|ilha do prumirim|ilha comprida|ilha grande|ilha bela|praia do prumirim|cachoeira do prumirim|rio escuro|mar aberto|mar calmo) ',
      ' ',
      'g'
    );

    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR pg_catalog.regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (pg_catalog.char_length(v_old_email) >= 5 AND pg_catalog.position(v_old_email in pg_catalog.lower(v_review.comment)) > 0)
      OR (pg_catalog.char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND pg_catalog.position(v_old_phone_digits in pg_catalog.regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
      OR (
        pg_catalog.char_length(v_norm_old_name) >= 3
        AND v_old_name <> v_anon_name
        AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_norm_old_name || '($|[^a-z0-9])')
      )
    );

    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT pg_catalog.regexp_split_to_table(v_norm_old_name, '\s+')
      LOOP
        IF pg_catalog.char_length(v_name_token) >= 3
           AND v_name_token NOT IN (
             'dos', 'das', 'com', 'sem', 'por', 'que', 'uma', 'uns', 'meu', 'sua', 'seu', 'foi', 'era',
             'bom', 'boa', 'dia', 'mar', 'sol', 'sul', 'rio', 'rua', 'cep', 'cpf', 'pii',
             'para', 'pelo', 'pela', 'como', 'mais', 'muito', 'toda', 'todo', 'todos', 'todas',
             'ilha', 'ilhas', 'praia', 'praias', 'lancha', 'escuna', 'passeio', 'barco', 'roteiro',
             'norte', 'verde', 'anchieta', 'prumirim', 'couves',
             'ubatuba', 'saco', 'ribeira', 'itagua', 'familia', 'aguas', 'calmas',
             'titular', 'anonimizado', 'lgpd', 'cliente', 'turista', 'visitante', 'grupo', 'comentario'
           )
           AND v_norm_comment_geo_stripped ~ ('(^|[^a-z0-9])' || v_name_token || '($|[^a-z0-9])') THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := pg_catalog.format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            old_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          public.sanitize_lgpd_audit_jsonb(
            new_data,
            v_anon_name,
            v_anon_phone,
            v_anon_email,
            v_anon_idem_key,
            v_anon_notes,
            v_anon_cancel_reason,
            v_anon_ledger_notes,
            v_new_review_comment,
            v_old_tourist_uid
          ) || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_payment.id IS NOT NULL AND record_id = v_payment.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'financial_payment_sanitized', v_financial_payment_sanitized,
          'financial_history_rows_sanitized', v_financial_history_sanitized_count,
          'financial_entries_rows_sanitized', v_financial_entries_sanitized_count,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'financial_payment_sanitized', v_financial_payment_sanitized,
        'financial_history_rows_sanitized', v_financial_history_sanitized_count,
        'financial_entries_rows_sanitized', v_financial_entries_sanitized_count,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'original_idempotency_key', v_updated.original_idempotency_key,
    'idempotency_generation', v_updated.idempotency_generation,
    'hmac_key_version', v_updated.hmac_key_version,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'financial_payment_sanitized', v_financial_payment_sanitized,
    'financial_history_rows_sanitized', v_financial_history_sanitized_count,
    'financial_entries_rows_sanitized', v_financial_entries_sanitized_count,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$body$;

-- 12. F08-A & F08-C: Ownership explícito (OWNER TO postgres) e Privilégios Mínimos (REVOKE EXECUTE em triggers)
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  -- Garante OWNER TO postgres em todas as funções SECURITY DEFINER financeiras e sincronizadas (F08-A)
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') THEN
    ALTER FUNCTION public.enforce_booking_payment_invariants() OWNER TO postgres;
    ALTER FUNCTION public.enforce_append_only_financial_audit_tables() OWNER TO postgres;
    ALTER FUNCTION public.create_or_initiate_booking_payment(UUID, public.payment_method_type, TEXT, NUMERIC, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) OWNER TO postgres;
    ALTER FUNCTION public.get_financial_reconciliation_report(UUID) OWNER TO postgres;
    ALTER FUNCTION public.sync_booking_history_ledger_and_audit() OWNER TO postgres;
    ALTER FUNCTION public.settle_commission_ledger(TEXT, TEXT) OWNER TO postgres;
    ALTER FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) OWNER TO postgres;
  END IF;

  -- Revoga ALL de PUBLIC, anon, authenticated e service_role em todas as funções financeiras antes de conceder privilégios mínimos
  FOR r_fn IN
    SELECT p_proc.oid::regprocedure AS fn_sig
    FROM pg_proc AS p_proc
    JOIN pg_namespace AS n_ns ON n_ns.oid = p_proc.pronamespace
    WHERE n_ns.nspname = 'public'
      AND p_proc.proname IN (
        'is_valid_payment_status_transition',
        'calculate_proportional_refund_split',
        'enforce_booking_payment_invariants',
        'enforce_append_only_financial_audit_tables',
        'create_or_initiate_booking_payment',
        'confirm_or_fail_booking_payment',
        'request_booking_refund',
        'process_booking_refund',
        'get_financial_reconciliation_report',
        'sync_booking_history_ledger_and_audit',
        'settle_commission_ledger',
        'admin_anonymize_customer_pii'
      )
  LOOP
    EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
      EXECUTE pg_catalog.format('REVOKE ALL ON FUNCTION %s FROM service_role', r_fn.fn_sig);
    END IF;
  END LOOP;

  -- Concede EXECUTE apenas nas RPCs e helpers puros (NUNCA em funções de trigger — F08-C)
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_valid_payment_status_transition(public.payment_status_type, public.payment_status_type) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.calculate_proportional_refund_split(NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_or_initiate_booking_payment(UUID, public.payment_method_type, TEXT, NUMERIC, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_financial_reconciliation_report(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.is_valid_payment_status_transition(public.payment_status_type, public.payment_status_type) TO service_role;
    GRANT EXECUTE ON FUNCTION public.calculate_proportional_refund_split(NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC) TO service_role;
    GRANT EXECUTE ON FUNCTION public.create_or_initiate_booking_payment(UUID, public.payment_method_type, TEXT, NUMERIC, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.request_booking_refund(UUID, NUMERIC, TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO service_role;
    GRANT EXECUTE ON FUNCTION public.get_financial_reconciliation_report(UUID) TO service_role;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO service_role;
  END IF;
END
$$;
