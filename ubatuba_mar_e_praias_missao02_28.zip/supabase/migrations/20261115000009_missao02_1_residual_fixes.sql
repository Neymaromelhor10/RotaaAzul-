-- ============================================================================
-- MIGRATION 0009: MISSÃO 02.1 / 02.2 — CORREÇÃO CONTROLADA DOS RISCOS RESIDUAIS
-- E ENDURECIMENTO ADVERSARIAL (M02.0-F03, M02.0-F10, M02.2-F01 E M02.2-F02)
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Pré-requisito: Migrations 000001 a 000008 preservadas integralmente byte a byte.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ENDURECIMENTO ADVERSARIAL DE public.resolve_booking_actor_role(UUID, UUID),
--    public.admin_update_booking() E public.settle_commission_ledger() (M02.2-F01)
-- Exige guarda estrita de 4 fatores (incluindo session_user IN ('postgres',
-- 'supabase_admin', 'service_role') e rejeição de combinações incongruentes entre
-- current_setting('role') e request.jwt.claim.role), impedindo que uma role de
-- banco customizada não-administrativa sem SET ROLE (v_db_role = 'none') seja
-- tratada como 'admin'.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.resolve_booking_actor_role(
  p_partner_id UUID,
  p_tourist_user_id UUID
)
RETURNS public.app_role
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    NULLIF(v_jwt ->> 'role', ''),
    ''
  );
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
BEGIN
  -- 1. Bloqueia imediatamente papel anônimo ou combinações incongruentes de papéis (M02.2-F01)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RETURN NULL;
  END IF;

  -- 2. Usuário autenticado: valida exclusivamente nas tabelas profiles e partner_members
  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    IF public.is_admin() THEN
      RETURN 'admin';
    END IF;

    IF public.is_partner_member(p_partner_id) THEN
      RETURN 'partner';
    END IF;

    IF p_tourist_user_id IS NOT NULL AND v_uid = p_tourist_user_id THEN
      IF EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
        RETURN 'tourist';
      END IF;
    END IF;

    RETURN NULL;
  END IF;

  -- 3. Sessões administrativas de servidor (exige session_user verificado — M02.2-F01)
  IF v_uid IS NULL
     AND v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
     AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
     AND (
       v_db_role = 'service_role'
       OR (
         v_db_role IN ('none', 'postgres', 'supabase_admin')
         AND session_user IN ('postgres', 'supabase_admin', 'service_role')
         AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
       )
     ) THEN
    RETURN 'admin';
  END IF;

  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_update_booking(
  p_booking_id TEXT,
  p_new_booking_date DATE DEFAULT NULL,
  p_new_passengers SMALLINT DEFAULT NULL,
  p_new_status public.booking_status_type DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_eff_date DATE;
  v_eff_pax SMALLINT;
  v_eff_status public.booking_status_type;
  v_date_min DATE;
  v_date_max DATE;
  v_ledger_status public.ledger_status_type;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Contexto de autenticação inválido ou não autorizado para admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'ADMIN_ONLY_OPERATION: Somente administradores podem executar admin_update_booking.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  v_eff_date := COALESCE(p_new_booking_date, v_target.booking_date);
  v_eff_pax := COALESCE(p_new_passengers, v_target.passengers);
  v_eff_status := COALESCE(p_new_status, v_target.status);

  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;

  v_date_min := LEAST(v_target.booking_date, v_eff_date);
  v_date_max := GREATEST(v_target.booking_date, v_eff_date);
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_min::text));
  IF v_date_max IS DISTINCT FROM v_date_min THEN
    PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_date_max::text));
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF v_eff_date IS NOT DISTINCT FROM v_target.booking_date
     AND v_eff_pax IS NOT DISTINCT FROM v_target.passengers
     AND v_eff_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_BOOKING_UPDATE: Nenhuma alteração efetiva de data, passageiros ou status foi solicitada para a reserva %.', v_target.code
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, v_eff_status::text);

  UPDATE public.bookings
  SET booking_date = v_eff_date,
      passengers = v_eff_pax,
      status = v_eff_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'booking_date', v_updated.booking_date,
    'passengers', v_updated.passengers,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'updated_at', v_updated.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.settle_commission_ledger(
  p_booking_id TEXT,
  p_adjustment_notes TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_ledger public.commission_ledger;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
BEGIN
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissões.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_booking.vessel_id::text), hashtext(v_booking.booking_date::text));
  PERFORM 1 FROM public.bookings WHERE id = v_booking.id FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_ledger.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_NOT_FOUND: Registro financeiro não encontrado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  IF v_ledger.ledger_status = 'PAGA' THEN
    RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão da reserva % já foi liquidada em %.', v_booking.code, v_ledger.paid_at
      USING ERRCODE = '23514';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' OR v_ledger.ledger_status <> 'CONFIRMADA' THEN
    RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Somente comissões com status CONFIRMADA de reservas em PASSEIO_REALIZADO podem ser liquidadas (atual: reserva=%, ledger=%).',
      v_booking.status, v_ledger.ledger_status
      USING ERRCODE = '23514';
  END IF;

  PERFORM internal_guard.issue_token('LEDGER_SETTLE', v_booking.id, 'PAGA');

  UPDATE public.commission_ledger
  SET ledger_status = 'PAGA',
      paid_at = now(),
      adjustment_notes = COALESCE(NULLIF(trim(COALESCE(p_adjustment_notes, '')), ''), adjustment_notes),
      updated_by = v_uid,
      updated_at = now()
  WHERE id = v_ledger.id
  RETURNING * INTO v_ledger;

  PERFORM internal_guard.cleanup_tokens('LEDGER_SETTLE', v_booking.id);

  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    table_name,
    record_id,
    action,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin',
    'commission_ledger',
    v_booking.code,
    'SETTLE_COMMISSION',
    jsonb_build_object('ledger_status', 'CONFIRMADA'),
    jsonb_build_object('ledger_status', 'PAGA', 'paid_at', v_ledger.paid_at, 'commission_amount', v_ledger.commission_amount)
  );

  RETURN jsonb_build_object(
    'ledger_id', v_ledger.id,
    'booking_id', v_booking.id,
    'booking_code', v_booking.code,
    'ledger_status', v_ledger.ledger_status,
    'gross_amount', v_ledger.gross_amount,
    'commission_amount', v_ledger.commission_amount,
    'net_partner_amount', v_ledger.net_partner_amount,
    'paid_at', v_ledger.paid_at
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. ATUALIZAÇÃO DE public.enforce_booking_invariants_and_transitions()
--    (M02.0-F03 E M02.2-F02)
-- Além de validar o token 'LGPD_ANONYMIZE:<status>' e o formato determinístico
-- de idempotency_key, bloqueia explicitamente qualquer alteração de status,
-- data, passageiros, UTMs ou timestamps operacionais durante uma operação LGPD.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
  v_lgpd_anonymize BOOLEAN := false;
  v_expected_lgpd_idem_key VARCHAR(64);
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_lgpd_anonymize := internal_guard.consume_token(
      'BOOKING_MUTATION',
      OLD.id,
      'LGPD_ANONYMIZE:' || NEW.status::text
    );

    IF NOT v_lgpd_anonymize THEN
      IF NOT internal_guard.consume_token('BOOKING_MUTATION', OLD.id, NEW.status::text) THEN
        RAISE EXCEPTION 'DIRECT_BOOKING_UPDATE_FORBIDDEN: Atualização direta na tabela bookings é proibida para preservar a hierarquia de locks anti-deadlock e regras de negócio. Utilize public.transition_booking_status() ou public.admin_update_booking().'
          USING ERRCODE = '42501';
      END IF;
    END IF;

    v_expected_lgpd_idem_key := ('lgpd-' || replace(OLD.id::text, '-', '') || '-' || left(md5(OLD.id::text), 16))::varchar(64);

    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR (
         NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
         AND NOT (v_lgpd_anonymize AND NEW.idempotency_key = v_expected_lgpd_idem_key)
       )
       OR (
         NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
         AND NOT (v_lgpd_anonymize AND NEW.tourist_user_id IS NULL)
       )
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    -- M02.2-F02: Sob token LGPD_ANONYMIZE, proíbe alterar status, data, passageiros, UTMs ou timestamps operacionais
    IF v_lgpd_anonymize AND (
         NEW.status IS DISTINCT FROM OLD.status
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.expires_at IS DISTINCT FROM OLD.expires_at
         OR NEW.confirmed_at IS DISTINCT FROM OLD.confirmed_at
         OR NEW.completed_at IS DISTINCT FROM OLD.completed_at
         OR NEW.cancelled_at IS DISTINCT FROM OLD.cancelled_at
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'LGPD_IMMUTABLE_OPERATIONAL_FIELDS: A operação de anonimização LGPD não pode alterar status, data, passageiros, UTMs ou timestamps operacionais da reserva.'
        USING ERRCODE = '42501';
    END IF;

    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. EXCEÇÃO CONTROLADA POR TOKEN EM public.enforce_commission_ledger_integrity()
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_commission_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_expected_ledger_status public.ledger_status_type;
BEGIN
  SELECT id, partner_id, tour_id, status, gross_amount, commission_amount, net_partner_amount
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_BOOKING_NOT_FOUND: Reserva (%) não encontrada para o livro-razão.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Os valores financeiros e vínculos do livro-razão devem corresponder exatamente à reserva e são imutáveis.'
      USING ERRCODE = '42501';
  END IF;

  v_expected_ledger_status := CASE
    WHEN v_booking.status = 'PASSEIO_REALIZADO' THEN 'CONFIRMADA'::public.ledger_status_type
    WHEN v_booking.status IN ('CANCELADA', 'RECUSADA') THEN 'REVERTIDA'::public.ledger_status_type
    WHEN v_booking.status = 'EM_DISPUTA' THEN 'EM_DISPUTA'::public.ledger_status_type
    ELSE 'PREVISTA'::public.ledger_status_type
  END;

  IF TG_OP = 'INSERT' THEN
    IF pg_trigger_depth() < 2
       OR NEW.ledger_status <> 'PREVISTA'
       OR NOT internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'PREVISTA') THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_INSERT_FORBIDDEN: O registro no livro-razão é criado exclusivamente pela trigger sync_booking_history_ledger_and_audit com status PREVISTA.'
        USING ERRCODE = '42501';
    END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id OR NEW.booking_id IS DISTINCT FROM OLD.booking_id THEN
      RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Identificadores do livro-razão são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    -- Caso 1: Sanitização LGPD de adjustment_notes e updated_by sem alterar status nem valores financeiros (M02.0-F03)
    IF NEW.ledger_status IS NOT DISTINCT FROM OLD.ledger_status
       AND NEW.rule_snapshot_json IS NOT DISTINCT FROM OLD.rule_snapshot_json
       AND NEW.consolidated_at IS NOT DISTINCT FROM OLD.consolidated_at
       AND NEW.paid_at IS NOT DISTINCT FROM OLD.paid_at
       AND NEW.reversed_at IS NOT DISTINCT FROM OLD.reversed_at
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, 'LGPD_ANONYMIZE:' || OLD.ledger_status::text) THEN
      RETURN NEW;
    END IF;

    -- Caso 2: Liquidação financeira ('CONFIRMADA' -> 'PAGA') via RPC settle_commission_ledger
    IF NEW.ledger_status = 'PAGA' AND OLD.ledger_status = 'CONFIRMADA' THEN
      IF v_booking.status IS DISTINCT FROM 'PASSEIO_REALIZADO' THEN
        RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Comissão só pode ser paga quando a reserva estiver em PASSEIO_REALIZADO.'
          USING ERRCODE = '23514';
      END IF;
      IF NOT internal_guard.consume_token('LEDGER_SETTLE', NEW.booking_id, 'PAGA') THEN
        RAISE EXCEPTION 'LEDGER_DIRECT_SETTLE_FORBIDDEN: A liquidação para PAGA deve ser executada exclusivamente via RPC public.settle_commission_ledger().'
          USING ERRCODE = '42501';
      END IF;
      NEW.paid_at := COALESCE(NEW.paid_at, now());
      RETURN NEW;
    END IF;

    -- Caso 3: Sincronização automática via token LEDGER_SYNC emitido por sync_booking_history_ledger_and_audit
    IF pg_trigger_depth() >= 2
       AND internal_guard.consume_token('LEDGER_SYNC', NEW.booking_id, v_expected_ledger_status::text)
       AND (
         NEW.ledger_status = v_expected_ledger_status
         OR (OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' AND v_booking.status = 'PASSEIO_REALIZADO')
       ) THEN
      RETURN NEW;
    END IF;

    IF OLD.ledger_status = 'PAGA' AND NEW.ledger_status = 'PAGA' THEN
      RAISE EXCEPTION 'LEDGER_ALREADY_PAID: A comissão desta reserva já foi liquidada anteriormente em %.', OLD.paid_at
        USING ERRCODE = '23514';
    END IF;

    RAISE EXCEPTION 'LEDGER_DIRECT_STATUS_FORBIDDEN: O status do livro-razão (%) não pode divergir do estado da reserva (%) nem ser alterado fora da máquina de estados.',
      NEW.ledger_status, v_booking.status
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. ATUALIZAÇÃO DE public.admin_anonymize_customer_pii(UUID, TEXT)
--    (M02.0-F03, M02.0-F10 E M02.2-F02)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_anonymize_customer_pii(
  p_booking_id UUID,
  p_lgpd_protocol TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_ledger public.commission_ledger;
  v_review RECORD;
  v_existing_audit RECORD;
  v_clean_protocol TEXT := trim(COALESCE(p_lgpd_protocol, ''));
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), NULLIF(v_jwt ->> 'role', ''), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_is_authorized_admin BOOLEAN := false;
  v_anon_name CONSTANT TEXT := 'TITULAR ANONIMIZADO LGPD';
  v_anon_phone CONSTANT VARCHAR(25) := '(00) 00000-0000';
  v_anon_email TEXT;
  v_anon_idem_key VARCHAR(64);
  v_anon_notes TEXT;
  v_anon_cancel_reason TEXT;
  v_anon_ledger_notes TEXT;
  v_old_name TEXT;
  v_old_email TEXT;
  v_old_phone_digits TEXT;
  v_old_tourist_uid UUID;
  v_name_token TEXT;
  v_comment_has_pii BOOLEAN := false;
  v_new_review_comment TEXT;
  v_history_updated_count INTEGER := 0;
  v_ledger_updated BOOLEAN := false;
  v_audit_updated_count INTEGER := 0;
  v_review_updated BOOLEAN := false;
  v_responsible_actor TEXT;
  v_external_warning TEXT;
BEGIN
  -- 1. Guarda estrita de autorização ANTES de acessar qualquer dado da reserva (T9.2, T9.3, T9.14)
  IF v_db_role = 'anon'
     OR v_jwt_role = 'anon'
     OR (v_jwt ->> 'role') = 'anon'
     OR (v_db_role = 'authenticated' AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin'))
     OR (v_jwt_role = 'authenticated' AND v_uid IS NULL)
     OR (v_db_role = 'service_role' AND v_jwt_role = 'authenticated') THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Contexto de autenticação inválido ou não autorizado para anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF v_uid IS NOT NULL AND v_jwt_role = 'authenticated' AND v_db_role IN ('authenticated', 'none', 'postgres') THEN
    v_is_authorized_admin := public.is_admin();
  ELSIF v_uid IS NULL
        AND v_db_role NOT IN ('anon', 'authenticated')
        AND v_jwt_role NOT IN ('anon', 'authenticated')
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'anon'
        AND (v_jwt ->> 'role') IS DISTINCT FROM 'authenticated'
        AND (
          v_db_role = 'service_role'
          OR (
            v_db_role IN ('none', 'postgres', 'supabase_admin')
            AND session_user IN ('postgres', 'supabase_admin', 'service_role')
            AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin')
          )
        ) THEN
    v_is_authorized_admin := true;
  END IF;

  IF NOT v_is_authorized_admin THEN
    RAISE EXCEPTION 'LGPD_ADMIN_ONLY: Somente administradores ou service_role podem executar anonimização LGPD.'
      USING ERRCODE = '42501';
  END IF;

  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O UUID da reserva é obrigatório para anonimização LGPD.'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_clean_protocol) < 6 OR v_clean_protocol !~ '^[A-Za-z0-9._-]+$' THEN
    RAISE EXCEPTION 'INVALID_LGPD_PROTOCOL: Informe um protocolo LGPD alfanumérico válido (mínimo 6 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada para anonimização LGPD.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock:
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));

  SELECT * INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  SELECT * INTO v_ledger
  FROM public.commission_ledger
  WHERE booking_id = v_target.id
  FOR UPDATE;

  v_anon_email := 'anonimizado.' || lower(v_target.code) || '@lgpd.invalid';
  v_anon_idem_key := ('lgpd-' || replace(v_target.id::text, '-', '') || '-' || left(md5(v_target.id::text), 16))::varchar(64);
  v_responsible_actor := COALESCE(v_uid::text, 'service_role:' || session_user);
  v_external_warning := CASE
    WHEN v_target.channel = 'WHATSAPP' THEN
      'Reserva originada via canal WHATSAPP: mensagens enviadas externamente via wa.me antes da anonimização podem permanecer no histórico do dispositivo do parceiro e devem seguir procedimento operacional de expurgo.'
    ELSE NULL
  END;

  -- Idempotência completa (T9.5 & T9.6 & M02.2-F02)
  IF v_target.customer_name = v_anon_name
     AND v_target.customer_phone = v_anon_phone
     AND v_target.customer_email = v_anon_email
     AND v_target.tourist_user_id IS NULL
     AND v_target.idempotency_key = v_anon_idem_key
     AND (v_ledger.id IS NULL OR v_ledger.adjustment_notes IS NULL OR v_ledger.adjustment_notes LIKE '[LGPD %') THEN
    SELECT
      COALESCE(al.new_data->>'lgpd_protocol', v_clean_protocol) AS recorded_protocol,
      COALESCE(al.new_data->>'performed_by', v_responsible_actor) AS recorded_actor
      INTO v_existing_audit
    FROM public.audit_logs al
    WHERE al.table_name = 'bookings'
      AND al.record_id = v_target.code
      AND al.action = 'ANONYMIZE_PII_LGPD'
    ORDER BY al.created_at ASC
    LIMIT 1;

    RETURN jsonb_build_object(
      'anonymized', true,
      'idempotent_replay', true,
      'booking_id', v_target.id,
      'booking_code', v_target.code,
      'idempotency_key', v_target.idempotency_key,
      'lgpd_protocol', COALESCE(v_existing_audit.recorded_protocol, v_clean_protocol),
      'performed_by', COALESCE(v_existing_audit.recorded_actor, v_responsible_actor),
      'customer_name', v_target.customer_name,
      'customer_phone', v_target.customer_phone,
      'customer_email', v_target.customer_email,
      'tourist_user_id', v_target.tourist_user_id,
      'financials_preserved', true,
      'gross_amount', v_target.gross_amount,
      'commission_amount', v_target.commission_amount,
      'net_partner_amount', v_target.net_partner_amount,
      'external_channel_warning', v_external_warning
    );
  END IF;

  v_old_name := trim(COALESCE(v_target.customer_name, ''));
  v_old_email := lower(trim(COALESCE(v_target.customer_email, '')));
  v_old_phone_digits := regexp_replace(COALESCE(v_target.customer_phone, ''), '[^0-9]', '', 'g');
  v_old_tourist_uid := v_target.tourist_user_id;

  v_anon_notes := format('[LGPD %s] Dados pessoais e observações livres sanitizados conforme solicitação.', v_clean_protocol);
  v_anon_cancel_reason := CASE
    WHEN v_target.rejection_or_cancel_reason IS NOT NULL THEN
      format('[LGPD %s] Motivo de cancelamento/recusa sanitizado conforme solicitação.', v_clean_protocol)
    ELSE NULL
  END;

  -- 1. Atualiza PII, pseudonimiza idempotency_key e desvincula tourist_user_id em public.bookings
  PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_target.id, 'LGPD_ANONYMIZE:' || v_target.status::text);

  UPDATE public.bookings
  SET tourist_user_id = NULL,
      idempotency_key = v_anon_idem_key,
      customer_name = v_anon_name,
      customer_phone = v_anon_phone,
      customer_email = v_anon_email,
      notes = v_anon_notes,
      rejection_or_cancel_reason = v_anon_cancel_reason,
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_target.id);

  -- 2. Sanitiza TODOS os registros de public.booking_status_history da reserva (T9.8)
  UPDATE public.booking_status_history
  SET reason = format(
        '[LGPD %s] Histórico de transição (%s -> %s) preservado com campo livre sanitizado.',
        v_clean_protocol,
        COALESCE(previous_status::text, 'INICIAL'),
        new_status::text
      ),
      changed_by = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND changed_by = v_old_tourist_uid THEN NULL
        ELSE changed_by
      END
  WHERE booking_id = v_target.id;

  GET DIAGNOSTICS v_history_updated_count = ROW_COUNT;

  -- 3. Sanitiza public.commission_ledger.adjustment_notes e desvincula updated_by quando igual ao turista (M02.0-F03 / T9.15)
  IF v_ledger.id IS NOT NULL THEN
    v_anon_ledger_notes := CASE
      WHEN v_ledger.adjustment_notes IS NOT NULL THEN
        format('[LGPD %s] Notas de ajuste financeiro/cancelamento sanitizadas conforme solicitação.', v_clean_protocol)
      ELSE NULL
    END;

    IF v_ledger.adjustment_notes IS DISTINCT FROM v_anon_ledger_notes
       OR (v_old_tourist_uid IS NOT NULL AND v_ledger.updated_by = v_old_tourist_uid) THEN
      PERFORM internal_guard.issue_token('LEDGER_SYNC', v_target.id, 'LGPD_ANONYMIZE:' || v_ledger.ledger_status::text);

      UPDATE public.commission_ledger
      SET adjustment_notes = v_anon_ledger_notes,
          updated_by = CASE
            WHEN v_old_tourist_uid IS NOT NULL AND updated_by = v_old_tourist_uid THEN NULL
            ELSE updated_by
          END,
          updated_at = now()
      WHERE id = v_ledger.id;

      PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_target.id);
      v_ledger_updated := true;
    END IF;
  END IF;

  -- 4. Tratamento de public.reviews (T9.10 & M02.2-F02):
  SELECT * INTO v_review
  FROM public.reviews
  WHERE booking_id = v_target.id
  FOR UPDATE;

  IF v_review.id IS NOT NULL THEN
    v_comment_has_pii := (
      v_review.comment ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
      OR regexp_replace(v_review.comment, '[^0-9]', '', 'g') ~ '[0-9]{8,}'
      OR v_review.comment ~ '[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}'
      OR (char_length(v_old_name) >= 3 AND v_old_name <> v_anon_name AND position(lower(v_old_name) in lower(v_review.comment)) > 0)
      OR (char_length(v_old_email) >= 5 AND position(v_old_email in lower(v_review.comment)) > 0)
      OR (char_length(v_old_phone_digits) >= 8 AND v_old_phone_digits <> '0000000000' AND position(v_old_phone_digits in regexp_replace(v_review.comment, '[^0-9]', '', 'g')) > 0)
    );

    -- Verifica também tokens individuais do nome do titular (>= 4 letras) para cobrir menções parciais (M02.2-F02)
    IF NOT v_comment_has_pii AND v_old_name <> v_anon_name THEN
      FOR v_name_token IN
        SELECT regexp_split_to_table(lower(v_old_name), '\s+')
      LOOP
        IF char_length(v_name_token) >= 4
           AND v_name_token NOT IN ('para', 'pelo', 'pela', 'como', 'mais', 'muito', 'ilha', 'praia', 'lancha', 'escuna', 'passeio')
           AND position(v_name_token in lower(v_review.comment)) > 0 THEN
          v_comment_has_pii := true;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF v_comment_has_pii THEN
      v_new_review_comment := format(
        '[Avaliação verificada preservada — dados pessoais no comentário suprimidos conforme protocolo LGPD %s]',
        v_clean_protocol
      );
    ELSE
      v_new_review_comment := v_review.comment;
    END IF;

    PERFORM internal_guard.issue_token('REVIEW_MUTATION', v_target.id, 'ANONYMIZE_LGPD');

    UPDATE public.reviews
    SET tourist_user_id = NULL,
        author_name = 'Turista Verificado (LGPD)',
        author_city = 'Anonimizado',
        comment = v_new_review_comment
    WHERE id = v_review.id;

    PERFORM internal_guard.cleanup_tokens('REVIEW_MUTATION', v_target.id);
    v_review_updated := true;
  END IF;

  -- 5. Sanitização abrangente de public.audit_logs sem COALESCE vazio (M02.2-F02)
  UPDATE public.audit_logs
  SET actor_user_id = CASE
        WHEN v_old_tourist_uid IS NOT NULL AND actor_user_id = v_old_tourist_uid THEN NULL
        ELSE actor_user_id
      END,
      old_data = CASE
        WHEN old_data IS NOT NULL THEN
          old_data
          || CASE WHEN old_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'idempotency_key' THEN jsonb_build_object('idempotency_key', v_anon_idem_key) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'adjustment_notes' THEN jsonb_build_object('adjustment_notes', COALESCE(v_anon_ledger_notes, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'updated_by' AND v_old_tourist_uid IS NOT NULL AND (old_data->>'updated_by') = v_old_tourist_uid::text THEN jsonb_build_object('updated_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN old_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE old_data
      END,
      new_data = CASE
        WHEN new_data IS NOT NULL THEN
          new_data
          || CASE WHEN new_data ? 'customer_name' THEN jsonb_build_object('customer_name', v_anon_name) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_phone' THEN jsonb_build_object('customer_phone', v_anon_phone) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'customer_email' THEN jsonb_build_object('customer_email', v_anon_email) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'idempotency_key' THEN jsonb_build_object('idempotency_key', v_anon_idem_key) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'notes' THEN jsonb_build_object('notes', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'reason' THEN jsonb_build_object('reason', v_anon_notes) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_reason' THEN jsonb_build_object('rejection_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'cancel_reason' THEN jsonb_build_object('cancel_reason', COALESCE(v_anon_cancel_reason, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'rejection_or_cancel_reason' THEN jsonb_build_object('rejection_or_cancel_reason', v_anon_cancel_reason) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'adjustment_notes' THEN jsonb_build_object('adjustment_notes', COALESCE(v_anon_ledger_notes, v_anon_notes)) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'tourist_user_id' THEN jsonb_build_object('tourist_user_id', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'updated_by' AND v_old_tourist_uid IS NOT NULL AND (new_data->>'updated_by') = v_old_tourist_uid::text THEN jsonb_build_object('updated_by', NULL) ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_name' THEN jsonb_build_object('author_name', 'Turista Verificado (LGPD)') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'author_city' THEN jsonb_build_object('author_city', 'Anonimizado') ELSE '{}'::jsonb END
          || CASE WHEN new_data ? 'comment' THEN jsonb_build_object('comment', COALESCE(v_new_review_comment, v_anon_notes)) ELSE '{}'::jsonb END
          || jsonb_build_object('lgpd_anonymized', true, 'lgpd_protocol', v_clean_protocol)
        ELSE new_data
      END
  WHERE (
    record_id IN (v_target.code, v_target.id::text)
    OR (v_ledger.id IS NOT NULL AND record_id = v_ledger.id::text)
    OR (v_review.id IS NOT NULL AND record_id = v_review.id::text)
    OR (old_data->>'id') = v_target.id::text
    OR (new_data->>'id') = v_target.id::text
    OR (old_data->>'booking_id') = v_target.id::text
    OR (new_data->>'booking_id') = v_target.id::text
  )
  AND action <> 'ANONYMIZE_PII_LGPD';

  GET DIAGNOSTICS v_audit_updated_count = ROW_COUNT;

  -- 6. Registra ou atualiza o evento único ANONYMIZE_PII_LGPD sem duplicar linhas em caso de upgrade (M02.2-F02)
  IF EXISTS (
    SELECT 1 FROM public.audit_logs
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD'
  ) THEN
    UPDATE public.audit_logs
    SET new_data = COALESCE(new_data, '{}'::jsonb) || jsonb_build_object(
          'ledger_notes_sanitized', v_ledger_updated,
          'external_channel_warning', v_external_warning
        )
    WHERE table_name = 'bookings'
      AND record_id = v_target.code
      AND action = 'ANONYMIZE_PII_LGPD';
  ELSE
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      'admin',
      'bookings',
      v_target.code,
      'ANONYMIZE_PII_LGPD',
      jsonb_build_object(
        'booking_id', v_target.id,
        'pii_redacted', true
      ),
      jsonb_build_object(
        'booking_id', v_target.id,
        'booking_code', v_target.code,
        'lgpd_protocol', v_clean_protocol,
        'performed_by', v_responsible_actor,
        'history_rows_sanitized', v_history_updated_count,
        'ledger_notes_sanitized', v_ledger_updated,
        'audit_rows_sanitized', v_audit_updated_count,
        'review_author_anonymized', v_review_updated,
        'review_comment_redacted', v_comment_has_pii,
        'financials_preserved', true,
        'external_channel_warning', v_external_warning
      )
    );
  END IF;

  RETURN jsonb_build_object(
    'anonymized', true,
    'idempotent_replay', false,
    'booking_id', v_updated.id,
    'booking_code', v_updated.code,
    'idempotency_key', v_updated.idempotency_key,
    'lgpd_protocol', v_clean_protocol,
    'performed_by', v_responsible_actor,
    'customer_name', v_updated.customer_name,
    'customer_phone', v_updated.customer_phone,
    'customer_email', v_updated.customer_email,
    'tourist_user_id', v_updated.tourist_user_id,
    'history_rows_sanitized', v_history_updated_count,
    'ledger_notes_sanitized', v_ledger_updated,
    'audit_rows_sanitized', v_audit_updated_count,
    'review_author_anonymized', v_review_updated,
    'review_comment_redacted', v_comment_has_pii,
    'financials_preserved', true,
    'gross_amount', v_updated.gross_amount,
    'commission_amount', v_updated.commission_amount,
    'net_partner_amount', v_updated.net_partner_amount,
    'external_channel_warning', v_external_warning
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- 5. CONSOLIDAÇÃO DE PRIVILÉGIOS (GRANT / REVOKE) PÓS-MIGRATION 000009
-- ----------------------------------------------------------------------------
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('public', 'internal_guard')
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO anon;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO anon;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;
    REVOKE ALL ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) FROM anon;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_update_booking(TEXT, DATE, SMALLINT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.settle_commission_ledger(TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.delete_availability_block(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_anonymize_customer_pii(UUID, TEXT) TO authenticated;

    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON
      public.bookings,
      public.commission_ledger,
      public.booking_status_history,
      public.audit_logs,
      public.availability_blocks,
      public.reviews
    FROM authenticated;
    REVOKE DELETE, TRUNCATE ON public.profiles FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    FOR r_fn IN
      SELECT p.oid::regprocedure AS fn_sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('public', 'internal_guard')
    LOOP
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END LOOP;
  END IF;
END
$$;
