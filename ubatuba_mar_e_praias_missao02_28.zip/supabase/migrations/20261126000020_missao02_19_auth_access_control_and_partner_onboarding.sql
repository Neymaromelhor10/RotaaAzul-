-- ============================================================================
-- UBATUBA MAR & PRAIAS (ROTA AZUL) — ARGON 4 — MISSÃO 02.19
-- MIGRATION 000020: AUTENTICAÇÃO, CONTROLE DE ACESSO SERVER-SIDE, SESSÕES
--                   E ONBOARDING SEGURO DE PARCEIROS MULTI-TENANT
-- Arquivo: supabase/migrations/20261126000020_missao02_19_auth_access_control_and_partner_onboarding.sql
--
-- Objetivos (Seções 7, 8, 9, 10 e 12):
--   1. Estender `public.partners` com estágios formais de onboarding
--      (`onboarding_stage IN ('PENDENTE', 'EM_ANALISE', 'APROVADO', 'REJEITADO', 'SUSPENSO')`),
--      motivo de rejeição/suspensão (`rejection_reason`) e rastreabilidade
--      (`submitted_by_user_id`, `reviewed_by_user_id`, `reviewed_at`).
--   2. Garantir associação 1:1 segura entre usuário solicitante e parceiro em
--      `public.partner_members`, impedindo auto-atribuição de `partner_id`
--      arbitrário ou criação de vínculo cruzado com outro parceiro.
--   3. Criar RPC `public.get_authenticated_access_context()` para resolver no
--      servidor a identidade autenticada, situação da conta (`account_state`),
--      papel efetivo (`effective_role`) e `primary_partner_id` vinculado.
--   4. Criar RPC `public.submit_partner_onboarding_application(...)` para
--      registro seguro de novo parceiro pendente com associação automática
--      em `public.partner_members`.
--   5. Criar RPC `public.admin_moderate_partner_onboarding(...)` exclusiva para
--      administradores verificados no servidor (`public.is_admin()`), impedindo
--      autoaprovação pelo parceiro e promovendo o perfil para `'partner'`
--      somente após aprovação administrativa.
-- ============================================================================

-- 1. Colunas de controle de onboarding e deliberação administrativa em public.partners
ALTER TABLE public.partners
  ADD COLUMN IF NOT EXISTS onboarding_stage TEXT NOT NULL DEFAULT 'APROVADO',
  ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
  ADD COLUMN IF NOT EXISTS submitted_by_user_id UUID REFERENCES public.profiles(id) ON DELETE RESTRICT,
  ADD COLUMN IF NOT EXISTS reviewed_by_user_id UUID REFERENCES public.profiles(id) ON DELETE RESTRICT,
  ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'partners_onboarding_stage_check'
      AND conrelid = 'public.partners'::regclass
  ) THEN
    ALTER TABLE public.partners
      ADD CONSTRAINT partners_onboarding_stage_check
      CHECK (onboarding_stage IN ('PENDENTE', 'EM_ANALISE', 'APROVADO', 'REJEITADO', 'SUSPENSO'));
  END IF;
END;
$$;

-- Sincroniza registros existentes em public.partners com o estágio correspondente
UPDATE public.partners
SET onboarding_stage = CASE
  WHEN status = 'APROVADO' THEN 'APROVADO'
  WHEN status = 'PENDENTE' AND onboarding_stage NOT IN ('PENDENTE', 'EM_ANALISE') THEN 'PENDENTE'
  WHEN status = 'SUSPENSO' AND onboarding_stage NOT IN ('REJEITADO', 'SUSPENSO') THEN 'SUSPENSO'
  ELSE onboarding_stage
END;

-- 2. Políticas RLS adicionais de leitura do próprio processo de onboarding pelo parceiro solicitante
DROP POLICY IF EXISTS "partners_member_or_applicant_select" ON public.partners;
CREATE POLICY "partners_member_or_applicant_select"
  ON public.partners
  FOR SELECT
  TO authenticated
  USING (
    public.is_admin()
    OR public.is_partner_member(id)
    OR submitted_by_user_id = (SELECT auth.uid())
  );

DROP POLICY IF EXISTS "partner_members_self_or_admin_select" ON public.partner_members;
CREATE POLICY "partner_members_self_or_admin_select"
  ON public.partner_members
  FOR SELECT
  TO authenticated
  USING (
    user_id = (SELECT auth.uid())
    OR public.is_admin()
  );

-- 3. RPC: Resolução Server-Side do Contexto de Autenticação, Conta e Vínculo Multi-Tenant
CREATE OR REPLACE FUNCTION public.get_authenticated_access_context()
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_profile public.profiles%ROWTYPE;
  v_partner public.partners%ROWTYPE;
  v_authorized_partner_ids UUID[] := ARRAY[]::UUID[];
  v_primary_partner_id UUID := NULL;
  v_effective_role public.app_role := 'tourist';
  v_account_state TEXT := 'UNAUTHENTICATED';
BEGIN
  -- Guarda de 4 fatores: rejeita sessões anônimas, tokens inconsistentes ou sem sub válido
  IF v_uid IS NULL
     OR v_db_role = 'anon'
     OR v_jwt_role <> 'authenticated'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR NOT (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    RETURN pg_catalog.jsonb_build_object(
      'authenticated', false,
      'account_state', 'UNAUTHENTICATED',
      'user_id', NULL,
      'email', NULL,
      'full_name', NULL,
      'effective_role', 'tourist',
      'is_active_profile', false,
      'primary_partner_id', NULL,
      'authorized_partner_ids', '[]'::jsonb,
      'partner_status', NULL,
      'partner_onboarding_stage', NULL,
      'partner_rejection_reason', NULL
    );
  END IF;

  SELECT p.* INTO v_profile
  FROM public.profiles AS p
  WHERE p.id = v_uid;

  IF NOT FOUND THEN
    RETURN pg_catalog.jsonb_build_object(
      'authenticated', false,
      'account_state', 'ACCOUNT_DISABLED',
      'user_id', v_uid,
      'email', NULL,
      'full_name', NULL,
      'effective_role', 'tourist',
      'is_active_profile', false,
      'primary_partner_id', NULL,
      'authorized_partner_ids', '[]'::jsonb,
      'partner_status', NULL,
      'partner_onboarding_stage', NULL,
      'partner_rejection_reason', 'Perfil de usuário não localizado.'
    );
  END IF;

  IF v_profile.is_active IS DISTINCT FROM true THEN
    RETURN pg_catalog.jsonb_build_object(
      'authenticated', true,
      'account_state', 'ACCOUNT_DISABLED',
      'user_id', v_profile.id,
      'email', v_profile.email,
      'full_name', v_profile.full_name,
      'effective_role', 'tourist',
      'is_active_profile', false,
      'primary_partner_id', NULL,
      'authorized_partner_ids', '[]'::jsonb,
      'partner_status', NULL,
      'partner_onboarding_stage', NULL,
      'partner_rejection_reason', 'Conta desativada administrativamente.'
    );
  END IF;

  IF v_profile.system_role = 'admin' THEN
    SELECT COALESCE(pg_catalog.array_agg(pt.id ORDER BY pt.created_at ASC), ARRAY[]::UUID[])
      INTO v_authorized_partner_ids
    FROM public.partners AS pt;

    RETURN pg_catalog.jsonb_build_object(
      'authenticated', true,
      'account_state', 'AUTHENTICATED_ACTIVE',
      'user_id', v_profile.id,
      'email', v_profile.email,
      'full_name', v_profile.full_name,
      'effective_role', 'admin',
      'is_active_profile', true,
      'primary_partner_id', v_authorized_partner_ids[1],
      'authorized_partner_ids', pg_catalog.to_jsonb(v_authorized_partner_ids),
      'partner_status', 'APROVADO',
      'partner_onboarding_stage', 'APROVADO',
      'partner_rejection_reason', NULL
    );
  END IF;

  -- Busca vínculos ativos do usuário em public.partner_members
  SELECT COALESCE(pg_catalog.array_agg(pm.partner_id ORDER BY pm.created_at ASC), ARRAY[]::UUID[])
    INTO v_authorized_partner_ids
  FROM public.partner_members AS pm
  WHERE pm.user_id = v_profile.id
    AND pm.is_active = true;

  IF pg_catalog.array_length(v_authorized_partner_ids, 1) IS NOT NULL AND pg_catalog.array_length(v_authorized_partner_ids, 1) > 0 THEN
    v_primary_partner_id := v_authorized_partner_ids[1];
    SELECT pt.* INTO v_partner
    FROM public.partners AS pt
    WHERE pt.id = v_primary_partner_id;

    IF FOUND THEN
      IF v_partner.status = 'APROVADO' AND v_partner.onboarding_stage = 'APROVADO' THEN
        v_effective_role := 'partner';
        v_account_state := 'AUTHENTICATED_ACTIVE';
      ELSIF v_partner.onboarding_stage IN ('PENDENTE', 'EM_ANALISE') OR v_partner.status = 'PENDENTE' THEN
        v_effective_role := 'partner';
        v_account_state := 'PARTNER_PENDING_APPROVAL';
      ELSIF v_partner.onboarding_stage = 'REJEITADO' THEN
        v_effective_role := 'partner';
        v_account_state := 'PARTNER_REJECTED';
      ELSE
        v_effective_role := 'partner';
        v_account_state := 'PARTNER_SUSPENDED';
      END IF;

      RETURN pg_catalog.jsonb_build_object(
        'authenticated', true,
        'account_state', v_account_state,
        'user_id', v_profile.id,
        'email', v_profile.email,
        'full_name', v_profile.full_name,
        'effective_role', v_effective_role,
        'is_active_profile', true,
        'primary_partner_id', v_partner.id,
        'authorized_partner_ids', CASE
          WHEN v_account_state = 'AUTHENTICATED_ACTIVE' THEN pg_catalog.to_jsonb(v_authorized_partner_ids)
          ELSE '[]'::jsonb
        END,
        'partner_status', v_partner.status,
        'partner_onboarding_stage', v_partner.onboarding_stage,
        'partner_rejection_reason', v_partner.rejection_reason
      );
    END IF;
  END IF;

  -- Caso o perfil tenha system_role = 'partner' mas sem vínculo válido em partner_members, bloqueia acesso operacional
  IF v_profile.system_role = 'partner' THEN
    RETURN pg_catalog.jsonb_build_object(
      'authenticated', true,
      'account_state', 'PARTNER_PENDING_APPROVAL',
      'user_id', v_profile.id,
      'email', v_profile.email,
      'full_name', v_profile.full_name,
      'effective_role', 'tourist',
      'is_active_profile', true,
      'primary_partner_id', NULL,
      'authorized_partner_ids', '[]'::jsonb,
      'partner_status', 'PENDENTE',
      'partner_onboarding_stage', 'PENDENTE',
      'partner_rejection_reason', NULL
    );
  END IF;

  RETURN pg_catalog.jsonb_build_object(
    'authenticated', true,
    'account_state', 'AUTHENTICATED_ACTIVE',
    'user_id', v_profile.id,
    'email', v_profile.email,
    'full_name', v_profile.full_name,
    'effective_role', 'tourist',
    'is_active_profile', true,
    'primary_partner_id', NULL,
    'authorized_partner_ids', '[]'::jsonb,
    'partner_status', NULL,
    'partner_onboarding_stage', NULL,
    'partner_rejection_reason', NULL
  );
END;
$body$;

-- 4. RPC: Submissão Segura de Onboarding de Parceiro (Associação Backend Obrigatória)
CREATE OR REPLACE FUNCTION public.submit_partner_onboarding_application(
  p_company_name TEXT,
  p_legal_name TEXT,
  p_cnpj TEXT,
  p_whatsapp TEXT,
  p_business_email TEXT,
  p_base_marina TEXT,
  p_years_operating SMALLINT DEFAULT 1,
  p_bio TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_json_sub TEXT := NULLIF(v_jwt ->> 'sub', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_profile public.profiles%ROWTYPE;
  v_clean_name TEXT := pg_catalog.btrim(COALESCE(p_company_name, ''));
  v_clean_legal TEXT := pg_catalog.btrim(COALESCE(p_legal_name, ''));
  v_clean_cnpj TEXT := pg_catalog.btrim(COALESCE(p_cnpj, ''));
  v_cnpj_digits TEXT := pg_catalog.regexp_replace(COALESCE(p_cnpj, ''), '[^0-9]', '', 'g');
  v_whatsapp_digits TEXT := pg_catalog.regexp_replace(COALESCE(p_whatsapp, ''), '[^0-9]', '', 'g');
  v_clean_email TEXT := pg_catalog.lower(pg_catalog.btrim(COALESCE(p_business_email, '')));
  v_clean_marina TEXT := pg_catalog.btrim(COALESCE(p_base_marina, ''));
  v_clean_bio TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_bio, '')), '');
  v_existing_member_partner_id UUID;
  v_new_partner_id UUID;
  v_slug TEXT;
BEGIN
  IF v_uid IS NULL
     OR v_db_role = 'anon'
     OR v_jwt_role <> 'authenticated'
     OR (v_claim_role IS NOT NULL AND v_json_role IS NOT NULL AND v_claim_role <> v_json_role)
     OR (v_json_sub IS NOT NULL AND v_json_sub <> v_uid::text)
     OR NOT (
       v_db_role = 'authenticated'
       OR (v_db_role IN ('none', 'postgres') AND session_user IN ('postgres', 'supabase_admin'))
     ) THEN
    RAISE EXCEPTION 'ONBOARDING_AUTH_REQUIRED: É necessário estar autenticado com sessão válida para solicitar credenciamento de parceiro.'
      USING ERRCODE = '42501';
  END IF;

  SELECT pr.* INTO v_profile
  FROM public.profiles AS pr
  WHERE pr.id = v_uid;

  IF NOT FOUND OR v_profile.is_active IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'ONBOARDING_ACCOUNT_DISABLED: Sua conta está inativa ou não possui perfil válido.'
      USING ERRCODE = '42501';
  END IF;

  -- Impede que um usuário já vinculado a um parceiro crie vínculo com outro parceiro ou envie duplicatas
  SELECT pm.partner_id INTO v_existing_member_partner_id
  FROM public.partner_members AS pm
  WHERE pm.user_id = v_uid
  LIMIT 1;

  IF v_existing_member_partner_id IS NOT NULL THEN
    RAISE EXCEPTION 'ONBOARDING_ALREADY_LINKED: Este usuário já possui vínculo societário/operacional com um parceiro registrado (%).',
      v_existing_member_partner_id
      USING ERRCODE = '23505';
  END IF;

  IF pg_catalog.char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_NAME: O nome fantasia da empresa deve conter ao menos 3 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_legal) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_LEGAL_NAME: A razão social deve conter ao menos 3 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_cnpj_digits) <> 14 OR v_cnpj_digits ~ '^([0-9])\1{13}$' THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_CNPJ: O CNPJ deve conter exatamente 14 dígitos numéricos válidos.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_whatsapp_digits) < 12 OR pg_catalog.char_length(v_whatsapp_digits) > 15 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_WHATSAPP: O WhatsApp operacional deve conter DDI + DDD + número (12 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_email = '' OR pg_catalog.position('@' in v_clean_email) <= 1 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_EMAIL: Informe um e-mail corporativo válido.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_marina) < 3 THEN
    RAISE EXCEPTION 'ONBOARDING_INVALID_MARINA: Informe a marina ou base náutica de operação.'
      USING ERRCODE = '23514';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.partners AS pt
    WHERE pg_catalog.regexp_replace(pt.cnpj, '[^0-9]', '', 'g') = v_cnpj_digits
       OR pg_catalog.lower(pg_catalog.btrim(pt.name)) = pg_catalog.lower(v_clean_name)
  ) THEN
    RAISE EXCEPTION 'ONBOARDING_DUPLICATE_PARTNER: Já existe um parceiro cadastrado com este CNPJ ou nome fantasia.'
      USING ERRCODE = '23505';
  END IF;

  v_new_partner_id := pg_catalog.gen_random_uuid();
  v_slug := pg_catalog.regexp_replace(pg_catalog.lower(v_clean_name), '[^a-z0-9]+', '-', 'g')
            || '-' || pg_catalog.substr(pg_catalog.replace(v_new_partner_id::text, '-', ''), 1, 6);

  -- Insere sempre como PENDENTE e verified = false (parceiro jamais aprova o próprio cadastro)
  INSERT INTO public.partners (
    id,
    slug,
    name,
    legal_name,
    cnpj,
    whatsapp,
    email,
    base_marina,
    status,
    onboarding_stage,
    verified,
    years_operating,
    bio,
    submitted_by_user_id,
    created_at,
    updated_at
  ) VALUES (
    v_new_partner_id,
    v_slug,
    v_clean_name,
    v_clean_legal,
    v_clean_cnpj,
    v_whatsapp_digits,
    v_clean_email,
    v_clean_marina,
    'PENDENTE'::public.partner_status,
    'PENDENTE',
    false,
    GREATEST(0::smallint, COALESCE(p_years_operating, 1::smallint)),
    COALESCE(v_clean_bio, 'Operador náutico em processo de credenciamento na ' || v_clean_marina || '.'),
    v_uid,
    pg_catalog.now(),
    pg_catalog.now()
  );

  -- Cria vínculo seguro usuário <-> parceiro no servidor
  INSERT INTO public.partner_members (
    partner_id,
    user_id,
    member_role,
    is_active,
    created_at
  ) VALUES (
    v_new_partner_id,
    v_uid,
    'owner',
    true,
    pg_catalog.now()
  );

  PERFORM internal_guard.issue_token('AUDIT_LOG_WRITE', v_new_partner_id, 'SUBMIT_PARTNER_ONBOARDING');
  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    action,
    table_name,
    record_id,
    new_data
  ) VALUES (
    v_uid,
    v_profile.system_role,
    'SUBMIT_PARTNER_ONBOARDING',
    'partners',
    v_new_partner_id::text,
    pg_catalog.jsonb_build_object(
      'partner_id', v_new_partner_id,
      'name', v_clean_name,
      'base_marina', v_clean_marina,
      'status', 'PENDENTE',
      'onboarding_stage', 'PENDENTE'
    )
  );

  RETURN pg_catalog.jsonb_build_object(
    'ok', true,
    'partner_id', v_new_partner_id,
    'slug', v_slug,
    'name', v_clean_name,
    'status', 'PENDENTE',
    'onboarding_stage', 'PENDENTE',
    'account_state', 'PARTNER_PENDING_APPROVAL',
    'submitted_by_user_id', v_uid
  );
END;
$body$;

-- 5. RPC: Deliberação Administrativa de Onboarding de Parceiros (Exclusiva para Admin Master)
CREATE OR REPLACE FUNCTION public.admin_moderate_partner_onboarding(
  p_partner_id UUID,
  p_decision TEXT,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_decision TEXT := pg_catalog.upper(pg_catalog.btrim(COALESCE(p_decision, '')));
  v_clean_reason TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), '');
  v_partner public.partners%ROWTYPE;
  v_next_status public.partner_status;
  v_next_stage TEXT;
  v_next_verified BOOLEAN;
  v_member_rec RECORD;
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'PARTNER_ONBOARDING_ADMIN_ONLY: Somente administradores autenticados podem deliberar sobre o onboarding de parceiros.'
      USING ERRCODE = '42501';
  END IF;

  IF p_partner_id IS NULL THEN
    RAISE EXCEPTION 'PARTNER_ID_REQUIRED: Informe o identificador do parceiro.'
      USING ERRCODE = '23514';
  END IF;

  SELECT pt.* INTO v_partner
  FROM public.partners AS pt
  WHERE pt.id = p_partner_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'PARTNER_NOT_FOUND: Parceiro % não localizado.', p_partner_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_decision NOT IN ('EM_ANALISE', 'APROVAR', 'REJEITAR', 'SUSPENDER', 'REATIVAR') THEN
    RAISE EXCEPTION 'INVALID_ONBOARDING_DECISION: Decisão inválida (%). Valores aceitos: EM_ANALISE, APROVAR, REJEITAR, SUSPENDER, REATIVAR.',
      v_decision
      USING ERRCODE = '23514';
  END IF;

  IF v_decision IN ('REJEITAR', 'SUSPENDER') AND (v_clean_reason IS NULL OR pg_catalog.char_length(v_clean_reason) < 3) THEN
    RAISE EXCEPTION 'ONBOARDING_REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) para rejeitar ou suspender o cadastro.'
      USING ERRCODE = '23514';
  END IF;

  IF v_decision = 'EM_ANALISE' THEN
    v_next_status := 'PENDENTE'::public.partner_status;
    v_next_stage := 'EM_ANALISE';
    v_next_verified := false;
  ELSIF v_decision IN ('APROVAR', 'REATIVAR') THEN
    v_next_status := 'APROVADO'::public.partner_status;
    v_next_stage := 'APROVADO';
    v_next_verified := true;
  ELSIF v_decision = 'REJEITAR' THEN
    v_next_status := 'SUSPENSO'::public.partner_status;
    v_next_stage := 'REJEITADO';
    v_next_verified := false;
  ELSE
    v_next_status := 'SUSPENSO'::public.partner_status;
    v_next_stage := 'SUSPENSO';
    v_next_verified := false;
  END IF;

  UPDATE public.partners AS pt
  SET status = v_next_status,
      onboarding_stage = v_next_stage,
      verified = v_next_verified,
      rejection_reason = CASE
        WHEN v_decision IN ('REJEITAR', 'SUSPENDER') THEN v_clean_reason
        WHEN v_decision IN ('APROVAR', 'REATIVAR') THEN NULL
        ELSE pt.rejection_reason
      END,
      reviewed_by_user_id = v_uid,
      reviewed_at = pg_catalog.now(),
      updated_at = pg_catalog.now()
  WHERE pt.id = p_partner_id;

  -- Quando aprovado/reativado pelo Admin, garante que os membros ativos do parceiro recebam system_role = 'partner'
  IF v_next_stage = 'APROVADO' THEN
    FOR v_member_rec IN
      SELECT pm.user_id
      FROM public.partner_members AS pm
      JOIN public.profiles AS pr ON pr.id = pm.user_id
      WHERE pm.partner_id = p_partner_id
        AND pm.is_active = true
        AND pr.system_role = 'tourist'
    LOOP
      UPDATE public.profiles AS pr
      SET system_role = 'partner'::public.app_role,
          updated_at = pg_catalog.now()
      WHERE pr.id = v_member_rec.user_id;
    END LOOP;
  END IF;

  PERFORM internal_guard.issue_token('AUDIT_LOG_WRITE', p_partner_id, 'MODERATE_PARTNER_ONBOARDING:' || v_decision);
  INSERT INTO public.audit_logs (
    actor_user_id,
    actor_role,
    action,
    table_name,
    record_id,
    old_data,
    new_data
  ) VALUES (
    v_uid,
    'admin'::public.app_role,
    'MODERATE_PARTNER_ONBOARDING:' || v_decision,
    'partners',
    p_partner_id::text,
    pg_catalog.jsonb_build_object(
      'status', v_partner.status,
      'onboarding_stage', v_partner.onboarding_stage
    ),
    pg_catalog.jsonb_build_object(
      'status', v_next_status,
      'onboarding_stage', v_next_stage,
      'verified', v_next_verified,
      'reason', v_clean_reason
    )
  );

  RETURN pg_catalog.jsonb_build_object(
    'ok', true,
    'partner_id', p_partner_id,
    'previous_status', v_partner.status,
    'status', v_next_status,
    'previous_onboarding_stage', v_partner.onboarding_stage,
    'onboarding_stage', v_next_stage,
    'verified', v_next_verified,
    'rejection_reason', v_clean_reason
  );
END;
$body$;

-- 6. Controle estrito de privilégios para as 3 novas funções da Missão 02.19
REVOKE ALL ON FUNCTION public.get_authenticated_access_context() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) FROM PUBLIC;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION public.get_authenticated_access_context() FROM anon;
    REVOKE ALL ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.get_authenticated_access_context() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) TO authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.get_authenticated_access_context() TO service_role;
    GRANT EXECUTE ON FUNCTION public.submit_partner_onboarding_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, SMALLINT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.admin_moderate_partner_onboarding(UUID, TEXT, TEXT) TO service_role;
  END IF;
END;
$$;
