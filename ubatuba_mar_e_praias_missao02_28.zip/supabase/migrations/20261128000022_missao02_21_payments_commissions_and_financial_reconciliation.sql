-- ============================================================================
-- UBATUBA MAR & PRAIAS (ROTA AZUL) — ARGON 4 — MISSÃO 02.21
-- MIGRATION 000022: PAGAMENTOS, COMISSÕES, ESTORNOS, RAZÃO FINANCEIRA E CONCILIAÇÃO
-- Arquivo: supabase/migrations/20261128000022_missao02_21_payments_commissions_and_financial_reconciliation.sql
--
-- Escopo Técnico (Seções 4 a 11):
--   1. Tipos ENUM financeiros:
--      - public.payment_status_type ('PENDENTE', 'PROCESSANDO', 'PAGO', 'FALHOU',
--        'CANCELADO', 'ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL')
--      - public.payment_method_type ('PIX', 'CARTAO_CREDITO', 'CARTAO_DEBITO',
--        'BOLETO', 'LINK_PAGAMENTO', 'TRANSFERENCIA_DIRETA')
--      - public.financial_entry_type ('PAYMENT_CONFIRMED', 'COMMISSION_PROVISIONED',
--        'COMMISSION_CONSOLIDATED', 'REFUND_FULL', 'REFUND_PARTIAL',
--        'COMMISSION_REVERSAL_FULL', 'COMMISSION_REVERSAL_PARTIAL',
--        'PARTNER_PAYOUT_SETTLED', 'COMPENSATORY_ADJUSTMENT')
--   2. Tabelas Financeiras sob RLS e FORCE RLS:
--      - public.booking_payments (transações de pagamento vinculadas às reservas com
--        NUMERIC(12,2), idempotency_key UNIQUE, controle de saldo estornado e efetivo)
--      - public.booking_payment_history (histórico imutável append-only de transições)
--      - public.financial_ledger_entries (razão analítico append-only com lançamentos
--        originais e compensatórios sem exclusão ou sobrescrita histórica)
--   3. Funções e Triggers de Integridade, Máquina de Estados e Arredondamento:
--      - public.is_valid_payment_status_transition(payment_status_type, payment_status_type)
--      - public.calculate_proportional_refund_split(...)
--      - public.enforce_booking_payment_invariants()
--      - public.enforce_append_only_financial_audit_tables()
--   4. RPCs Financeiras Transacionais (SECURITY DEFINER com search_path seguro):
--      - public.create_or_initiate_booking_payment(...)
--      - public.confirm_or_fail_booking_payment(...)
--      - public.process_booking_refund(...)
--      - public.get_financial_reconciliation_report(...)
-- ============================================================================

-- 1. Criação idempotente dos tipos ENUM financeiros
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace WHERE n.nspname = 'public' AND t.typname = 'payment_status_type') THEN
    CREATE TYPE public.payment_status_type AS ENUM (
      'PENDENTE',
      'PROCESSANDO',
      'PAGO',
      'FALHOU',
      'CANCELADO',
      'ESTORNO_PENDENTE',
      'ESTORNADO',
      'ESTORNO_PARCIAL'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace WHERE n.nspname = 'public' AND t.typname = 'payment_method_type') THEN
    CREATE TYPE public.payment_method_type AS ENUM (
      'PIX',
      'CARTAO_CREDITO',
      'CARTAO_DEBITO',
      'BOLETO',
      'LINK_PAGAMENTO',
      'TRANSFERENCIA_DIRETA'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace WHERE n.nspname = 'public' AND t.typname = 'financial_entry_type') THEN
    CREATE TYPE public.financial_entry_type AS ENUM (
      'PAYMENT_CONFIRMED',
      'COMMISSION_PROVISIONED',
      'COMMISSION_CONSOLIDATED',
      'REFUND_FULL',
      'REFUND_PARTIAL',
      'COMMISSION_REVERSAL_FULL',
      'COMMISSION_REVERSAL_PARTIAL',
      'PARTNER_PAYOUT_SETTLED',
      'COMPENSATORY_ADJUSTMENT'
    );
  END IF;
END
$$;

-- 2. Expansão controlada dos escopos válidos em internal_guard.execution_tokens
DO $$
DECLARE
  v_con_name TEXT;
BEGIN
  FOR v_con_name IN
    SELECT con.conname
    FROM pg_constraint con
    JOIN pg_class rel ON rel.oid = con.conrelid
    JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
    WHERE nsp.nspname = 'internal_guard'
      AND rel.relname = 'execution_tokens'
      AND con.contype = 'c'
      AND pg_get_constraintdef(con.oid) LIKE '%scope%'
  LOOP
    EXECUTE format('ALTER TABLE internal_guard.execution_tokens DROP CONSTRAINT %I', v_con_name);
  END LOOP;
END
$$;

ALTER TABLE internal_guard.execution_tokens
  ADD CONSTRAINT chk_internal_guard_execution_tokens_scope
  CHECK (
    scope IN (
      'AUTH_PROFILE_SYNC',
      'BOOKING_MUTATION',
      'LEDGER_SYNC',
      'LEDGER_SETTLE',
      'CATALOG_RATING_SYNC',
      'AVAILABILITY_BLOCK_MUTATION',
      'REVIEW_MUTATION',
      'PAYMENT_MUTATION',
      'FINANCIAL_LEDGER_MUTATION'
    )
  );

-- 3. Tabela de Pagamentos de Reservas (public.booking_payments — Seções 4, 5, 6 e 8)
CREATE TABLE IF NOT EXISTS public.booking_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  currency CHAR(3) NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
  payment_method public.payment_method_type NOT NULL DEFAULT 'PIX',
  payment_status public.payment_status_type NOT NULL DEFAULT 'PENDENTE',
  gross_amount NUMERIC(12,2) NOT NULL CHECK (gross_amount > 0),
  commission_amount NUMERIC(12,2) NOT NULL CHECK (commission_amount >= 0 AND commission_amount <= gross_amount),
  net_partner_amount NUMERIC(12,2) NOT NULL CHECK (net_partner_amount >= 0),
  refunded_gross_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (refunded_gross_amount >= 0 AND refunded_gross_amount <= gross_amount),
  refunded_commission_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (refunded_commission_amount >= 0 AND refunded_commission_amount <= commission_amount),
  refunded_net_partner_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (refunded_net_partner_amount >= 0 AND refunded_net_partner_amount <= net_partner_amount),
  effective_gross_amount NUMERIC(12,2) NOT NULL CHECK (effective_gross_amount >= 0),
  effective_commission_amount NUMERIC(12,2) NOT NULL CHECK (effective_commission_amount >= 0),
  effective_net_partner_amount NUMERIC(12,2) NOT NULL CHECK (effective_net_partner_amount >= 0),
  commission_rule_snapshot JSONB NOT NULL,
  external_transaction_id VARCHAR(128) UNIQUE,
  idempotency_key VARCHAR(128) NOT NULL UNIQUE,
  last_operation_idempotency_key VARCHAR(128),
  failure_or_cancel_reason TEXT,
  refund_reason TEXT,
  confirmed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  refunded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_booking_payments_initial_split
    CHECK (gross_amount = commission_amount + net_partner_amount),
  CONSTRAINT chk_booking_payments_refund_split
    CHECK (refunded_gross_amount = refunded_commission_amount + refunded_net_partner_amount),
  CONSTRAINT chk_booking_payments_effective_gross
    CHECK (effective_gross_amount = gross_amount - refunded_gross_amount),
  CONSTRAINT chk_booking_payments_effective_commission
    CHECK (effective_commission_amount = commission_amount - refunded_commission_amount),
  CONSTRAINT chk_booking_payments_effective_net
    CHECK (effective_net_partner_amount = net_partner_amount - refunded_net_partner_amount),
  CONSTRAINT chk_booking_payments_effective_split
    CHECK (effective_gross_amount = effective_commission_amount + effective_net_partner_amount),
  CONSTRAINT chk_booking_payments_confirmed_timestamp
    CHECK (
      (payment_status IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL') AND confirmed_at IS NOT NULL)
      OR (payment_status NOT IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL'))
    ),
  CONSTRAINT chk_booking_payments_full_refund_consistency
    CHECK (
      (payment_status = 'ESTORNADO' AND refunded_gross_amount = gross_amount AND effective_gross_amount = 0)
      OR (payment_status <> 'ESTORNADO')
    ),
  CONSTRAINT chk_booking_payments_partial_refund_consistency
    CHECK (
      (payment_status = 'ESTORNO_PARCIAL' AND refunded_gross_amount > 0 AND refunded_gross_amount < gross_amount)
      OR (payment_status <> 'ESTORNO_PARCIAL')
    )
);

CREATE INDEX IF NOT EXISTS idx_booking_payments_partner_status
  ON public.booking_payments(partner_id, payment_status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_booking_payments_booking_id
  ON public.booking_payments(booking_id);

DROP TRIGGER IF EXISTS trg_booking_payments_set_updated_at ON public.booking_payments;
CREATE TRIGGER trg_booking_payments_set_updated_at
  BEFORE UPDATE ON public.booking_payments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 4. Tabela de Histórico de Pagamentos (public.booking_payment_history — Append-Only)
CREATE TABLE IF NOT EXISTS public.booking_payment_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID NOT NULL REFERENCES public.booking_payments(id) ON DELETE RESTRICT,
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  previous_status public.payment_status_type,
  new_status public.payment_status_type NOT NULL,
  operation_type TEXT NOT NULL,
  operation_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (operation_amount >= 0),
  idempotency_key VARCHAR(128) NOT NULL UNIQUE,
  external_transaction_id VARCHAR(128),
  actor_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  actor_role public.app_role,
  reason TEXT,
  metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_booking_payment_history_payment_id
  ON public.booking_payment_history(payment_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_booking_payment_history_booking_id
  ON public.booking_payment_history(booking_id, created_at ASC);

-- 5. Tabela de Lançamentos Analíticos do Razão Financeiro (public.financial_ledger_entries — Append-Only)
CREATE TABLE IF NOT EXISTS public.financial_ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE RESTRICT,
  payment_id UUID REFERENCES public.booking_payments(id) ON DELETE RESTRICT,
  commission_ledger_id UUID REFERENCES public.commission_ledger(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  entry_type public.financial_entry_type NOT NULL,
  gross_delta NUMERIC(12,2) NOT NULL,
  commission_delta NUMERIC(12,2) NOT NULL,
  net_partner_delta NUMERIC(12,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
  idempotency_key VARCHAR(128) NOT NULL UNIQUE,
  reference_transaction_id VARCHAR(128),
  description TEXT NOT NULL,
  actor_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  actor_role public.app_role,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_financial_ledger_entries_exact_split
    CHECK (gross_delta = commission_delta + net_partner_delta)
);

CREATE INDEX IF NOT EXISTS idx_financial_ledger_entries_partner_created
  ON public.financial_ledger_entries(partner_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_financial_ledger_entries_booking_id
  ON public.financial_ledger_entries(booking_id, created_at ASC);

-- 6. Habilitação de RLS, FORCE RLS e Políticas de Isolamento Financeiro (Seção 9)
ALTER TABLE public.booking_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_payments FORCE ROW LEVEL SECURITY;

ALTER TABLE public.booking_payment_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_payment_history FORCE ROW LEVEL SECURITY;

ALTER TABLE public.financial_ledger_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_ledger_entries FORCE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.booking_payments FROM PUBLIC;
REVOKE ALL ON TABLE public.booking_payment_history FROM PUBLIC;
REVOKE ALL ON TABLE public.financial_ledger_entries FROM PUBLIC;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON TABLE public.booking_payments FROM anon;
    REVOKE ALL ON TABLE public.booking_payment_history FROM anon;
    REVOKE ALL ON TABLE public.financial_ledger_entries FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON TABLE public.booking_payments FROM authenticated;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON TABLE public.booking_payment_history FROM authenticated;
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON TABLE public.financial_ledger_entries FROM authenticated;
    GRANT SELECT ON TABLE public.booking_payments TO authenticated;
    GRANT SELECT ON TABLE public.booking_payment_history TO authenticated;
    GRANT SELECT ON TABLE public.financial_ledger_entries TO authenticated;
  END IF;
END
$$;

DROP POLICY IF EXISTS "booking_payments_select_admin_or_partner" ON public.booking_payments;
CREATE POLICY "booking_payments_select_admin_or_partner"
  ON public.booking_payments
  FOR SELECT
  TO authenticated
  USING (public.is_admin() OR public.is_partner_member(partner_id));

DROP POLICY IF EXISTS "booking_payment_history_select_admin_or_partner" ON public.booking_payment_history;
CREATE POLICY "booking_payment_history_select_admin_or_partner"
  ON public.booking_payment_history
  FOR SELECT
  TO authenticated
  USING (public.is_admin() OR public.is_partner_member(partner_id));

DROP POLICY IF EXISTS "financial_ledger_entries_select_admin_or_partner" ON public.financial_ledger_entries;
CREATE POLICY "financial_ledger_entries_select_admin_or_partner"
  ON public.financial_ledger_entries
  FOR SELECT
  TO authenticated
  USING (public.is_admin() OR public.is_partner_member(partner_id));

-- 7. Máquina de Estados de Pagamento e Cálculo Proporcional de Estorno (Seções 5, 6 e 10)
CREATE OR REPLACE FUNCTION public.is_valid_payment_status_transition(
  p_old_status public.payment_status_type,
  p_new_status public.payment_status_type
)
RETURNS BOOLEAN
LANGUAGE plpgsql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $body$
BEGIN
  IF p_old_status IS NULL OR p_new_status IS NULL THEN
    RETURN false;
  END IF;

  CASE p_old_status
    WHEN 'PENDENTE' THEN
      RETURN p_new_status IN ('PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO');
    WHEN 'PROCESSANDO' THEN
      RETURN p_new_status IN ('PAGO', 'FALHOU', 'CANCELADO');
    WHEN 'FALHOU' THEN
      RETURN p_new_status IN ('PROCESSANDO', 'CANCELADO');
    WHEN 'PAGO' THEN
      RETURN p_new_status IN ('ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL');
    WHEN 'ESTORNO_PENDENTE' THEN
      RETURN p_new_status IN ('ESTORNADO', 'ESTORNO_PARCIAL', 'PAGO');
    WHEN 'ESTORNO_PARCIAL' THEN
      RETURN p_new_status IN ('ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL');
    WHEN 'CANCELADO' THEN
      RETURN false;
    WHEN 'ESTORNADO' THEN
      RETURN false;
    ELSE
      RETURN false;
  END CASE;
END;
$body$;

-- Cálculo proporcional exato de estorno (Regra de arredondamento HALF_UP em NUMERIC(12,2) sem resíduo de centavos)
CREATE OR REPLACE FUNCTION public.calculate_proportional_refund_split(
  p_gross_amount NUMERIC,
  p_commission_amount NUMERIC,
  p_net_amount NUMERIC,
  p_prev_refunded_gross NUMERIC,
  p_prev_refunded_commission NUMERIC,
  p_prev_refunded_net NUMERIC,
  p_new_refund_gross NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
IMMUTABLE
SECURITY INVOKER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_gross NUMERIC(12,2) := pg_catalog.round(COALESCE(p_gross_amount, 0)::numeric, 2);
  v_comm NUMERIC(12,2) := pg_catalog.round(COALESCE(p_commission_amount, 0)::numeric, 2);
  v_net NUMERIC(12,2) := pg_catalog.round(COALESCE(p_net_amount, 0)::numeric, 2);
  v_prev_gross NUMERIC(12,2) := pg_catalog.round(COALESCE(p_prev_refunded_gross, 0)::numeric, 2);
  v_prev_comm NUMERIC(12,2) := pg_catalog.round(COALESCE(p_prev_refunded_commission, 0)::numeric, 2);
  v_prev_net NUMERIC(12,2) := pg_catalog.round(COALESCE(p_prev_refunded_net, 0)::numeric, 2);
  v_req_gross NUMERIC(12,2) := pg_catalog.round(COALESCE(p_new_refund_gross, 0)::numeric, 2);
  v_Remaining_gross NUMERIC(12,2);
  v_delta_comm NUMERIC(12,2);
  v_delta_net NUMERIC(12,2);
  v_total_ref_gross NUMERIC(12,2);
  v_total_ref_comm NUMERIC(12,2);
  v_total_ref_net NUMERIC(12,2);
BEGIN
  IF v_gross <= 0 OR v_gross <> (v_comm + v_net) THEN
    RAISE EXCEPTION 'INVALID_ORIGINAL_SPLIT: Valores originais inválidos (bruto=%, comissão=%, líquido=%).',
      v_gross, v_comm, v_net
      USING ERRCODE = '23514';
  END IF;

  IF v_req_gross <= 0 THEN
    RAISE EXCEPTION 'INVALID_REFUND_AMOUNT: O valor do estorno deve ser estritamente positivo (recebido: %).',
      v_req_gross
      USING ERRCODE = '23514';
  END IF;

  v_Remaining_gross := v_gross - v_prev_gross;
  IF v_req_gross > v_Remaining_gross THEN
    RAISE EXCEPTION 'REFUND_EXCEEDS_PAID_AMOUNT: O valor solicitado para estorno (%) excede o saldo disponível (%).',
      v_req_gross, v_Remaining_gross
      USING ERRCODE = '23514';
  END IF;

  -- Se o estorno quita 100% do saldo restante, absorve exatamente o saldo residual de comissão e líquido
  IF (v_prev_gross + v_req_gross) = v_gross THEN
    v_delta_comm := v_comm - v_prev_comm;
    v_delta_net := v_net - v_prev_net;
  ELSE
    v_delta_comm := pg_catalog.round((v_comm * v_req_gross) / v_gross, 2);
    IF (v_prev_comm + v_delta_comm) > v_comm THEN
      v_delta_comm := v_comm - v_prev_comm;
    END IF;
    v_delta_net := v_req_gross - v_delta_comm;
  END IF;

  v_total_ref_gross := v_prev_gross + v_req_gross;
  v_total_ref_comm := v_prev_comm + v_delta_comm;
  v_total_ref_net := v_prev_net + v_delta_net;

  RETURN jsonb_build_object(
    'refund_gross_delta', v_req_gross,
    'refund_commission_delta', v_delta_comm,
    'refund_net_delta', v_delta_net,
    'total_refunded_gross', v_total_ref_gross,
    'total_refunded_commission', v_total_ref_comm,
    'total_refunded_net', v_total_ref_net,
    'effective_gross_amount', v_gross - v_total_ref_gross,
    'effective_commission_amount', v_comm - v_total_ref_comm,
    'effective_net_partner_amount', v_net - v_total_ref_net,
    'is_full_refund', (v_total_ref_gross = v_gross)
  );
END;
$body$;

-- 8. Triggers de Blindagem de Pagamentos e Tabelas Append-Only (Seções 5, 7 e 9)
CREATE OR REPLACE FUNCTION public.enforce_booking_payment_invariants()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD_DELETE_FORBIDDEN: Registros financeiros em booking_payments não podem ser excluídos.'
      USING ERRCODE = '42501';
  END IF;

  IF NOT internal_guard.consume_token('PAYMENT_MUTATION', NEW.booking_id, NEW.payment_status::text) THEN
    RAISE EXCEPTION 'DIRECT_PAYMENT_MUTATION_FORBIDDEN: Alteração direta em booking_payments é proibida. Utilize as RPCs financeiras autorizadas.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_BOOKING_NOT_FOUND: Reserva (%) não encontrada.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'PAYMENT_AMOUNT_TAMPERING_FORBIDDEN: Os valores bruto, comissão e líquido do pagamento devem corresponder exatamente aos valores persistidos da reserva.'
      USING ERRCODE = '42501';
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount
       OR NEW.commission_rule_snapshot IS DISTINCT FROM OLD.commission_rule_snapshot
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
       OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
      RAISE EXCEPTION 'PAYMENT_IMMUTABLE_FIELDS_FORBIDDEN: Campos estruturais, snapshot histórico de comissão e valores nominais do pagamento são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    IF NEW.payment_status IS DISTINCT FROM OLD.payment_status
       AND NOT public.is_valid_payment_status_transition(OLD.payment_status, NEW.payment_status) THEN
      RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Transição financeira proibida de % para %.',
        OLD.payment_status, NEW.payment_status
        USING ERRCODE = '23514';
    END IF;

    IF NEW.refunded_gross_amount < OLD.refunded_gross_amount THEN
      RAISE EXCEPTION 'REFUND_ROLLBACK_FORBIDDEN: O montante acumulado de estorno não pode retroceder.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END;
$body$;

DROP TRIGGER IF EXISTS trg_enforce_booking_payment_invariants ON public.booking_payments;
CREATE TRIGGER trg_enforce_booking_payment_invariants
  BEFORE INSERT OR UPDATE OR DELETE ON public.booking_payments
  FOR EACH ROW EXECUTE FUNCTION public.enforce_booking_payment_invariants();

CREATE OR REPLACE FUNCTION public.enforce_append_only_financial_audit_tables()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
BEGIN
  IF TG_OP IN ('UPDATE', 'DELETE') THEN
    RAISE EXCEPTION 'FINANCIAL_HISTORY_IMMUTABLE_FORBIDDEN: Lançamentos históricos em % são imutáveis e não podem ser editados ou removidos. Utilize lançamentos compensatórios.',
      TG_TABLE_NAME
      USING ERRCODE = '42501';
  END IF;

  IF NOT internal_guard.consume_token('FINANCIAL_LEDGER_MUTATION', NEW.booking_id, TG_TABLE_NAME) THEN
    RAISE EXCEPTION 'DIRECT_FINANCIAL_LEDGER_INSERT_FORBIDDEN: Inserção manual em % fora das RPCs financeiras é proibida.',
      TG_TABLE_NAME
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$body$;

DROP TRIGGER IF EXISTS trg_append_only_booking_payment_history ON public.booking_payment_history;
CREATE TRIGGER trg_append_only_booking_payment_history
  BEFORE INSERT OR UPDATE OR DELETE ON public.booking_payment_history
  FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_financial_audit_tables();

DROP TRIGGER IF EXISTS trg_append_only_financial_ledger_entries ON public.financial_ledger_entries;
CREATE TRIGGER trg_append_only_financial_ledger_entries
  BEFORE INSERT OR UPDATE OR DELETE ON public.financial_ledger_entries
  FOR EACH ROW EXECUTE FUNCTION public.enforce_append_only_financial_audit_tables();

-- 9. RPC 1: Criar ou Iniciar Pagamento de Reserva (public.create_or_initiate_booking_payment)
CREATE OR REPLACE FUNCTION public.create_or_initiate_booking_payment(
  p_booking_id UUID,
  p_payment_method public.payment_method_type,
  p_idempotency_key TEXT,
  p_client_gross_amount NUMERIC DEFAULT NULL,
  p_external_transaction_id TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_existing public.booking_payments%ROWTYPE;
  v_key_conflict public.booking_payments%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_ext TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_external_transaction_id, '')), '');
  v_rule_snap JSONB;
BEGIN
  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF p_payment_method IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_METHOD_REQUIRED: O método de pagamento é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: A chave de idempotência financeira deve ter entre 8 e 128 caracteres válidos.'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id = p_booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  -- Ordem Canônica Anti-Deadlock: Lock #1 vessels -> Lock #2 advisory_lock -> Lock #3 bookings
  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Usuário sem permissão para iniciar pagamento desta reserva.'
      USING ERRCODE = '42501';
  END IF;

  -- Rejeita manipulação de valor enviada pelo cliente (Seção 4 e Teste 6)
  IF p_client_gross_amount IS NOT NULL AND pg_catalog.round(p_client_gross_amount::numeric, 2) <> v_booking.gross_amount THEN
    RAISE EXCEPTION 'PAYMENT_CLIENT_AMOUNT_MISMATCH: Valor enviado pelo cliente (%) diverge do valor oficial calculado no servidor (%).',
      pg_catalog.round(p_client_gross_amount::numeric, 2), v_booking.gross_amount
      USING ERRCODE = '42501';
  END IF;

  -- Verifica se a chave de idempotência já foi utilizada em outra reserva ou com payload incompatível (Teste 4 e Teste 5)
  SELECT * INTO v_key_conflict
  FROM public.booking_payments
  WHERE idempotency_key = v_clean_idem
  FOR UPDATE;

  IF v_key_conflict.id IS NOT NULL THEN
    IF v_key_conflict.booking_id IS DISTINCT FROM v_booking.id
       OR v_key_conflict.payment_method IS DISTINCT FROM p_payment_method
       OR (v_clean_ext IS NOT NULL AND v_key_conflict.external_transaction_id IS NOT NULL AND v_key_conflict.external_transaction_id <> v_clean_ext) THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: A chave de idempotência (%) já foi utilizada com parâmetros financeiros incompatíveis.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_key_conflict.id,
      'booking_id', v_key_conflict.booking_id,
      'partner_id', v_key_conflict.partner_id,
      'payment_status', v_key_conflict.payment_status,
      'payment_method', v_key_conflict.payment_method,
      'currency', v_key_conflict.currency,
      'gross_amount', v_key_conflict.gross_amount,
      'commission_amount', v_key_conflict.commission_amount,
      'net_partner_amount', v_key_conflict.net_partner_amount,
      'effective_gross_amount', v_key_conflict.effective_gross_amount,
      'effective_commission_amount', v_key_conflict.effective_commission_amount,
      'effective_net_partner_amount', v_key_conflict.effective_net_partner_amount,
      'idempotency_key', v_key_conflict.idempotency_key
    );
  END IF;

  SELECT * INTO v_existing
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_existing.id IS NOT NULL THEN
    IF v_existing.payment_status IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNADO', 'ESTORNO_PARCIAL') THEN
      RAISE EXCEPTION 'PAYMENT_ALREADY_PROCESSED: A reserva % já possui pagamento processado com status %.',
        v_booking.code, v_existing.payment_status
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_existing.id,
      'booking_id', v_existing.booking_id,
      'partner_id', v_existing.partner_id,
      'payment_status', v_existing.payment_status,
      'payment_method', v_existing.payment_method,
      'currency', v_existing.currency,
      'gross_amount', v_existing.gross_amount,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'effective_gross_amount', v_existing.effective_gross_amount,
      'effective_commission_amount', v_existing.effective_commission_amount,
      'effective_net_partner_amount', v_existing.effective_net_partner_amount,
      'idempotency_key', v_existing.idempotency_key
    );
  END IF;

  IF v_booking.status IN ('CANCELADA', 'RECUSADA') THEN
    RAISE EXCEPTION 'PAYMENT_ON_CANCELLED_BOOKING_FORBIDDEN: Não é permitido iniciar pagamento para reserva em status %.',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  v_rule_snap := jsonb_build_object(
    'commission_rule_id', v_booking.commission_rule_id,
    'commission_model', v_booking.commission_model_snapshot,
    'commission_rate', v_booking.commission_rate_snapshot,
    'commission_fixed', v_booking.commission_fixed_snapshot,
    'commission_rule_label', v_booking.commission_rule_label,
    'pricing_model', v_booking.pricing_model_snapshot,
    'unit_price', v_booking.unit_price_snapshot,
    'passengers', v_booking.passengers
  );

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, 'PENDENTE');
  INSERT INTO public.booking_payments (
    booking_id,
    partner_id,
    tour_id,
    currency,
    payment_method,
    payment_status,
    gross_amount,
    commission_amount,
    net_partner_amount,
    refunded_gross_amount,
    refunded_commission_amount,
    refunded_net_partner_amount,
    effective_gross_amount,
    effective_commission_amount,
    effective_net_partner_amount,
    commission_rule_snapshot,
    external_transaction_id,
    idempotency_key,
    last_operation_idempotency_key
  ) VALUES (
    v_booking.id,
    v_booking.partner_id,
    v_booking.tour_id,
    'BRL',
    p_payment_method,
    'PENDENTE',
    v_booking.gross_amount,
    v_booking.commission_amount,
    v_booking.net_partner_amount,
    0.00,
    0.00,
    0.00,
    v_booking.gross_amount,
    v_booking.commission_amount,
    v_booking.net_partner_amount,
    v_rule_snap,
    v_clean_ext,
    v_clean_idem,
    v_clean_idem
  )
  RETURNING * INTO v_existing;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    external_transaction_id,
    actor_user_id,
    actor_role,
    reason
  ) VALUES (
    v_existing.id,
    v_booking.id,
    v_booking.partner_id,
    NULL,
    'PENDENTE',
    'CREATE_PAYMENT',
    v_booking.gross_amount,
    'hist-init-' || v_clean_idem,
    v_clean_ext,
    v_uid,
    v_actor_role,
    'Pagamento iniciado no servidor com valores calculados da reserva'
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_existing.id,
    v_booking.partner_id,
    v_booking.tour_id,
    'COMMISSION_PROVISIONED',
    0.00,
    0.00,
    0.00,
    'BRL',
    'fled-init-' || v_clean_idem,
    v_clean_ext,
    format('Provisão inicial de pagamento (%s) para reserva %s', p_payment_method, v_booking.code),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_existing.id,
    'booking_id', v_existing.booking_id,
    'partner_id', v_existing.partner_id,
    'payment_status', v_existing.payment_status,
    'payment_method', v_existing.payment_method,
    'currency', v_existing.currency,
    'gross_amount', v_existing.gross_amount,
    'commission_amount', v_existing.commission_amount,
    'net_partner_amount', v_existing.net_partner_amount,
    'effective_gross_amount', v_existing.effective_gross_amount,
    'effective_commission_amount', v_existing.effective_commission_amount,
    'effective_net_partner_amount', v_existing.effective_net_partner_amount,
    'idempotency_key', v_existing.idempotency_key
  );
END;
$body$;

-- 10. RPC 2: Transição/Confirmação de Pagamento (public.confirm_or_fail_booking_payment)
CREATE OR REPLACE FUNCTION public.confirm_or_fail_booking_payment(
  p_booking_id UUID,
  p_target_status public.payment_status_type,
  p_idempotency_key TEXT,
  p_external_transaction_id TEXT DEFAULT NULL,
  p_client_gross_amount NUMERIC DEFAULT NULL,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_prev_status public.payment_status_type;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_ext TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_external_transaction_id, '')), '');
  v_clean_reason TEXT := NULLIF(pg_catalog.btrim(COALESCE(p_reason, '')), '');
BEGIN
  IF p_booking_id IS NULL OR p_target_status IS NULL THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_TRANSITION_ARGS: Reserva e status alvo são obrigatórios.'
      USING ERRCODE = '23514';
  END IF;

  IF p_target_status NOT IN ('PROCESSANDO', 'PAGO', 'FALHOU', 'CANCELADO') THEN
    RAISE EXCEPTION 'INVALID_TARGET_PAYMENT_STATUS: Utilize process_booking_refund() para operações de estorno.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência inválida.'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_FINANCIAL_OPERATION: Sem permissão para atualizar pagamento desta reserva.'
      USING ERRCODE = '42501';
  END IF;

  -- Turistas nunca podem marcar pagamento como PAGO pelo cliente (Seção 5 & 9)
  IF v_actor_role = 'tourist' AND p_target_status = 'PAGO' THEN
    RAISE EXCEPTION 'TOURIST_PAYMENT_CONFIRM_FORBIDDEN: O cliente não tem permissão para confirmar pagamento diretamente.'
      USING ERRCODE = '42501';
  END IF;

  IF p_client_gross_amount IS NOT NULL AND pg_catalog.round(p_client_gross_amount::numeric, 2) <> v_booking.gross_amount THEN
    RAISE EXCEPTION 'PAYMENT_CLIENT_AMOUNT_MISMATCH: Valor informado (%) diverge do valor oficial da reserva (%).',
      pg_catalog.round(p_client_gross_amount::numeric, 2), v_booking.gross_amount
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Nenhum pagamento iniciado para a reserva %.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- Verifica idempotência no histórico de operações financeiras
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.new_status IS DISTINCT FROM p_target_status THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência (%) reutilizada com parâmetros incompatíveis.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'previous_status', v_hist_existing.previous_status,
      'payment_status', v_payment.payment_status,
      'gross_amount', v_payment.gross_amount,
      'commission_amount', v_payment.commission_amount,
      'net_partner_amount', v_payment.net_partner_amount,
      'confirmed_at', v_payment.confirmed_at
    );
  END IF;

  -- Bloqueia confirmação duplicada com chave distinta quando já está PAGO (Teste 3 e Teste 18)
  IF v_payment.payment_status = 'PAGO' AND p_target_status = 'PAGO' THEN
    RAISE EXCEPTION 'PAYMENT_ALREADY_CONFIRMED_DUPLICATE: O pagamento da reserva % já foi confirmado anteriormente.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  -- Impede confirmar pagamento se a reserva já foi cancelada/recusada (Seção 5, 8 e Teste 17)
  IF p_target_status = 'PAGO' AND v_booking.status IN ('CANCELADA', 'RECUSADA') THEN
    RAISE EXCEPTION 'PAYMENT_CONFIRM_ON_CANCELLED_FORBIDDEN: Não é permitido confirmar pagamento de uma reserva cancelada ou recusada (%).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NOT public.is_valid_payment_status_transition(v_payment.payment_status, p_target_status) THEN
    RAISE EXCEPTION 'INVALID_PAYMENT_STATUS_TRANSITION: Transição financeira inválida de % para %.',
      v_payment.payment_status, p_target_status
      USING ERRCODE = '23514';
  END IF;

  v_prev_status := v_payment.payment_status;

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, p_target_status::text);
  UPDATE public.booking_payments
  SET payment_status = p_target_status,
      external_transaction_id = COALESCE(v_clean_ext, external_transaction_id),
      last_operation_idempotency_key = v_clean_idem,
      confirmed_at = CASE WHEN p_target_status = 'PAGO' THEN COALESCE(confirmed_at, now()) ELSE confirmed_at END,
      cancelled_at = CASE WHEN p_target_status = 'CANCELADO' THEN COALESCE(cancelled_at, now()) ELSE cancelled_at END,
      failure_or_cancel_reason = CASE WHEN p_target_status IN ('FALHOU', 'CANCELADO') THEN COALESCE(v_clean_reason, failure_or_cancel_reason) ELSE failure_or_cancel_reason END
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    external_transaction_id,
    actor_user_id,
    actor_role,
    reason
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_status,
    p_target_status,
    'TRANSITION_' || p_target_status::text,
    v_payment.gross_amount,
    v_clean_idem,
    v_clean_ext,
    v_uid,
    v_actor_role,
    COALESCE(v_clean_reason, format('Transição de pagamento %s -> %s', v_prev_status, p_target_status))
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  IF p_target_status = 'PAGO' THEN
    PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
    INSERT INTO public.financial_ledger_entries (
      booking_id,
      payment_id,
      partner_id,
      tour_id,
      entry_type,
      gross_delta,
      commission_delta,
      net_partner_delta,
      currency,
      idempotency_key,
      reference_transaction_id,
      description,
      actor_user_id,
      actor_role
    ) VALUES (
      v_booking.id,
      v_payment.id,
      v_booking.partner_id,
      v_booking.tour_id,
      'PAYMENT_CONFIRMED',
      v_payment.gross_amount,
      v_payment.commission_amount,
      v_payment.net_partner_amount,
      'BRL',
      'fled-pay-' || v_clean_idem,
      v_payment.external_transaction_id,
      format('Pagamento confirmado para reserva %s (%s)', v_booking.code, v_payment.commission_rule_snapshot->>'commission_rule_label'),
      v_uid,
      v_actor_role
    );
    PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_status,
    'payment_status', v_payment.payment_status,
    'gross_amount', v_payment.gross_amount,
    'commission_amount', v_payment.commission_amount,
    'net_partner_amount', v_payment.net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount,
    'confirmed_at', v_payment.confirmed_at
  );
END;
$body$;

-- 11. RPC 3: Processar Estorno Integral ou Parcial Auditável (public.process_booking_refund)
CREATE OR REPLACE FUNCTION public.process_booking_refund(
  p_booking_id UUID,
  p_refund_amount NUMERIC,
  p_idempotency_key TEXT,
  p_reason TEXT,
  p_mark_booking_cancelled BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = pg_catalog, public, internal_guard, pg_temp
AS $body$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_payment public.booking_payments%ROWTYPE;
  v_hist_existing public.booking_payment_history%ROWTYPE;
  v_actor_role public.app_role;
  v_uid UUID := (SELECT auth.uid());
  v_clean_idem TEXT := pg_catalog.btrim(COALESCE(p_idempotency_key, ''));
  v_clean_reason TEXT := pg_catalog.btrim(COALESCE(p_reason, ''));
  v_req_amount NUMERIC(12,2) := pg_catalog.round(COALESCE(p_refund_amount, 0)::numeric, 2);
  v_split JSONB;
  v_is_full BOOLEAN;
  v_next_pay_status public.payment_status_type;
  v_prev_pay_status public.payment_status_type;
  v_delta_gross NUMERIC(12,2);
  v_delta_comm NUMERIC(12,2);
  v_delta_net NUMERIC(12,2);
BEGIN
  IF p_booking_id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: O identificador da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_idem) < 8 OR pg_catalog.char_length(v_clean_idem) > 128 OR v_clean_idem !~ '^[A-Za-z0-9._:-]+$' THEN
    RAISE EXCEPTION 'INVALID_FINANCIAL_IDEMPOTENCY_KEY: Chave de idempotência de estorno inválida.'
      USING ERRCODE = '23514';
  END IF;

  IF pg_catalog.char_length(v_clean_reason) < 3 THEN
    RAISE EXCEPTION 'REFUND_REASON_REQUIRED: É obrigatório informar o motivo do estorno (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;
  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', p_booking_id
      USING ERRCODE = 'P0002';
  END IF;

  PERFORM 1 FROM public.vessels WHERE id = v_booking.vessel_id FOR UPDATE;
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_booking.vessel_id::text), pg_catalog.hashtext(v_booking.booking_date::text));
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;

  v_actor_role := public.resolve_booking_actor_role(v_booking.partner_id, v_booking.tourist_user_id);
  IF v_actor_role IS NULL OR v_actor_role = 'tourist' THEN
    RAISE EXCEPTION 'UNAUTHORIZED_REFUND_OPERATION: Somente administradores ou o parceiro responsável podem processar estornos financeiros.'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_payment
  FROM public.booking_payments
  WHERE booking_id = v_booking.id
  FOR UPDATE;

  IF v_payment.id IS NULL THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOUND: Reserva % não possui registro de pagamento para estorno.', v_booking.code
      USING ERRCODE = 'P0002';
  END IF;

  -- Verifica idempotência no histórico de operações financeiras (Teste 4, 5 e 15)
  SELECT * INTO v_hist_existing
  FROM public.booking_payment_history
  WHERE idempotency_key = v_clean_idem;

  IF v_hist_existing.id IS NOT NULL THEN
    IF v_hist_existing.booking_id IS DISTINCT FROM v_booking.id
       OR v_hist_existing.operation_amount IS DISTINCT FROM v_req_amount THEN
      RAISE EXCEPTION 'FINANCIAL_IDEMPOTENCY_CONFLICT: Chave de idempotência de estorno (%) reutilizada com valor ou reserva divergente.',
        v_clean_idem
        USING ERRCODE = '23505';
    END IF;

    RETURN jsonb_build_object(
      'ok', true,
      'idempotent_replay', true,
      'payment_id', v_payment.id,
      'booking_id', v_payment.booking_id,
      'payment_status', v_payment.payment_status,
      'refunded_gross_amount', v_payment.refunded_gross_amount,
      'refunded_commission_amount', v_payment.refunded_commission_amount,
      'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
      'effective_gross_amount', v_payment.effective_gross_amount,
      'effective_commission_amount', v_payment.effective_commission_amount,
      'effective_net_partner_amount', v_payment.effective_net_partner_amount
    );
  END IF;

  IF v_payment.payment_status = 'ESTORNADO' THEN
    RAISE EXCEPTION 'REFUND_ALREADY_COMPLETED_DUPLICATE: O pagamento da reserva % já foi integralmente estornado.',
      v_booking.code
      USING ERRCODE = '23505';
  END IF;

  IF v_payment.payment_status NOT IN ('PAGO', 'ESTORNO_PENDENTE', 'ESTORNO_PARCIAL') THEN
    RAISE EXCEPTION 'REFUND_NOT_ALLOWED_FOR_STATUS: Não é permitido estornar um pagamento com status %.',
      v_payment.payment_status
      USING ERRCODE = '23514';
  END IF;

  v_split := public.calculate_proportional_refund_split(
    v_payment.gross_amount,
    v_payment.commission_amount,
    v_payment.net_partner_amount,
    v_payment.refunded_gross_amount,
    v_payment.refunded_commission_amount,
    v_payment.refunded_net_partner_amount,
    v_req_amount
  );

  v_is_full := (v_split->>'is_full_refund')::boolean;
  v_next_pay_status := CASE WHEN v_is_full THEN 'ESTORNADO'::public.payment_status_type ELSE 'ESTORNO_PARCIAL'::public.payment_status_type END;
  v_prev_pay_status := v_payment.payment_status;
  v_delta_gross := (v_split->>'refund_gross_delta')::numeric(12,2);
  v_delta_comm := (v_split->>'refund_commission_delta')::numeric(12,2);
  v_delta_net := (v_split->>'refund_net_delta')::numeric(12,2);

  PERFORM internal_guard.issue_token('PAYMENT_MUTATION', v_booking.id, v_next_pay_status::text);
  UPDATE public.booking_payments
  SET payment_status = v_next_pay_status,
      refunded_gross_amount = (v_split->>'total_refunded_gross')::numeric(12,2),
      refunded_commission_amount = (v_split->>'total_refunded_commission')::numeric(12,2),
      refunded_net_partner_amount = (v_split->>'total_refunded_net')::numeric(12,2),
      effective_gross_amount = (v_split->>'effective_gross_amount')::numeric(12,2),
      effective_commission_amount = (v_split->>'effective_commission_amount')::numeric(12,2),
      effective_net_partner_amount = (v_split->>'effective_net_partner_amount')::numeric(12,2),
      last_operation_idempotency_key = v_clean_idem,
      refund_reason = v_clean_reason,
      refunded_at = now()
  WHERE id = v_payment.id
  RETURNING * INTO v_payment;
  PERFORM internal_guard.cleanup_tokens('PAYMENT_MUTATION', v_booking.id);

  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'booking_payment_history');
  INSERT INTO public.booking_payment_history (
    payment_id,
    booking_id,
    partner_id,
    previous_status,
    new_status,
    operation_type,
    operation_amount,
    idempotency_key,
    actor_user_id,
    actor_role,
    reason,
    metadata_json
  ) VALUES (
    v_payment.id,
    v_booking.id,
    v_booking.partner_id,
    v_prev_pay_status,
    v_next_pay_status,
    CASE WHEN v_is_full THEN 'REFUND_FULL' ELSE 'REFUND_PARTIAL' END,
    v_delta_gross,
    v_clean_idem,
    v_uid,
    v_actor_role,
    v_clean_reason,
    v_split
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Registra lançamento compensatório negativo (append-only) no razão financeiro
  PERFORM internal_guard.issue_token('FINANCIAL_LEDGER_MUTATION', v_booking.id, 'financial_ledger_entries');
  INSERT INTO public.financial_ledger_entries (
    booking_id,
    payment_id,
    partner_id,
    tour_id,
    entry_type,
    gross_delta,
    commission_delta,
    net_partner_delta,
    currency,
    idempotency_key,
    reference_transaction_id,
    description,
    actor_user_id,
    actor_role
  ) VALUES (
    v_booking.id,
    v_payment.id,
    v_booking.partner_id,
    v_booking.tour_id,
    CASE WHEN v_is_full THEN 'REFUND_FULL'::public.financial_entry_type ELSE 'REFUND_PARTIAL'::public.financial_entry_type END,
    -v_delta_gross,
    -v_delta_comm,
    -v_delta_net,
    'BRL',
    'fled-ref-' || v_clean_idem,
    v_payment.external_transaction_id,
    format('Estorno %s na reserva %s: %s', CASE WHEN v_is_full THEN 'integral' ELSE 'parcial' END, v_booking.code, v_clean_reason),
    v_uid,
    v_actor_role
  );
  PERFORM internal_guard.cleanup_tokens('FINANCIAL_LEDGER_MUTATION', v_booking.id);

  -- Se o estorno foi integral ou solicitado cancelamento conjunto da reserva e a reserva ainda está ativa
  IF (v_is_full OR p_mark_booking_cancelled) AND v_booking.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'EM_DISPUTA') THEN
    PERFORM internal_guard.issue_token('BOOKING_MUTATION', v_booking.id, 'CANCELADA');
    PERFORM internal_guard.issue_token('LEDGER_SYNC', v_booking.id, 'REVERTIDA');
    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = v_clean_reason,
        cancelled_at = COALESCE(cancelled_at, now())
    WHERE id = v_booking.id;
    PERFORM internal_guard.cleanup_tokens('BOOKING_MUTATION', v_booking.id);
    PERFORM internal_guard.cleanup_tokens('LEDGER_SYNC', v_booking.id);
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'idempotent_replay', false,
    'payment_id', v_payment.id,
    'booking_id', v_payment.booking_id,
    'previous_status', v_prev_pay_status,
    'payment_status', v_payment.payment_status,
    'refund_gross_delta', v_delta_gross,
    'refund_commission_delta', v_delta_comm,
    'refund_net_delta', v_delta_net,
    'refunded_gross_amount', v_payment.refunded_gross_amount,
    'refunded_commission_amount', v_payment.refunded_commission_amount,
    'refunded_net_partner_amount', v_payment.refunded_net_partner_amount,
    'effective_gross_amount', v_payment.effective_gross_amount,
    'effective_commission_amount', v_payment.effective_commission_amount,
    'effective_net_partner_amount', v_payment.effective_net_partner_amount
  );
END;
$body$;

-- 12. RPC 4: Conciliação Financeira e Indicadores Autorizados no Servidor (public.get_financial_reconciliation_report)
CREATE OR REPLACE FUNCTION public.get_financial_reconciliation_report(
  p_partner_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $body$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt JSONB := COALESCE((SELECT auth.jwt()), '{}'::jsonb);
  v_claim_role TEXT := NULLIF(pg_catalog.current_setting('request.jwt.claim.role', true), '');
  v_json_role TEXT := NULLIF(v_jwt ->> 'role', '');
  v_jwt_role TEXT := COALESCE(v_claim_role, v_json_role, '');
  v_db_role TEXT := COALESCE(NULLIF(pg_catalog.current_setting('role', true), ''), 'none');
  v_is_admin BOOLEAN := false;
  v_effective_partner_id UUID := p_partner_id;
  v_discrepancies JSONB := '[]'::jsonb;
  v_row RECORD;
  v_expected JSONB;
  v_exp_gross NUMERIC(12,2);
  v_exp_comm NUMERIC(12,2);
  v_exp_net NUMERIC(12,2);
  v_total_gross_received NUMERIC(12,2) := 0.00;
  v_total_commissions NUMERIC(12,2) := 0.00;
  v_total_net_partner NUMERIC(12,2) := 0.00;
  v_total_refunded NUMERIC(12,2) := 0.00;
  v_pending_payments_count INTEGER := 0;
  v_confirmed_payments_count INTEGER := 0;
  v_refunded_payments_count INTEGER := 0;
BEGIN
  IF v_db_role = 'anon' OR v_jwt_role = 'anon' THEN
    RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Autenticação obrigatória para consultar conciliação financeira.'
      USING ERRCODE = '42501';
  END IF;

  IF public.is_admin() OR (
    v_uid IS NULL
    AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
    AND session_user IN ('postgres', 'supabase_admin', 'service_role')
  ) THEN
    v_is_admin := true;
  END IF;

  IF NOT v_is_admin THEN
    IF v_uid IS NULL THEN
      RAISE EXCEPTION 'FINANCIAL_AUTH_REQUIRED: Sessão não autenticada.'
        USING ERRCODE = '42501';
    END IF;

    IF v_effective_partner_id IS NULL THEN
      SELECT pm.partner_id INTO v_effective_partner_id
      FROM public.partner_members pm
      WHERE pm.user_id = v_uid AND pm.is_active = true
      LIMIT 1;
    END IF;

    IF v_effective_partner_id IS NULL OR NOT public.is_partner_member(v_effective_partner_id) THEN
      RAISE EXCEPTION 'CROSS_TENANT_FINANCIAL_ACCESS_DENIED: Usuário não possui permissão financeira para consultar este parceiro.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  FOR v_row IN
    SELECT
      bk.id AS booking_id,
      bk.code AS booking_code,
      bk.partner_id,
      bk.tour_id,
      bk.passengers,
      bk.status AS booking_status,
      bk.gross_amount AS booking_gross,
      bk.commission_amount AS booking_commission,
      bk.net_partner_amount AS booking_net,
      cl.ledger_status,
      cl.gross_amount AS ledger_gross,
      cl.commission_amount AS ledger_commission,
      cl.net_partner_amount AS ledger_net,
      bp.id AS payment_id,
      bp.payment_status,
      bp.gross_amount AS payment_gross,
      bp.commission_amount AS payment_commission,
      bp.net_partner_amount AS payment_net,
      bp.refunded_gross_amount,
      bp.effective_gross_amount,
      bp.effective_commission_amount,
      bp.effective_net_partner_amount
    FROM public.bookings bk
    LEFT JOIN public.commission_ledger cl ON cl.booking_id = bk.id
    LEFT JOIN public.booking_payments bp ON bp.booking_id = bk.id
    WHERE (v_effective_partner_id IS NULL OR bk.partner_id = v_effective_partner_id)
    ORDER BY bk.created_at ASC
  LOOP
    v_expected := public.calculate_booking_financials(v_row.tour_id, v_row.passengers);
    v_exp_gross := (v_expected->>'gross_amount')::numeric(12,2);
    v_exp_comm := (v_expected->>'commission_amount')::numeric(12,2);
    v_exp_net := (v_expected->>'net_partner_amount')::numeric(12,2);

    IF v_row.booking_gross <> (v_row.booking_commission + v_row.booking_net)
       OR (v_row.ledger_gross IS NOT NULL AND (
            v_row.ledger_gross <> v_row.booking_gross
            OR v_row.ledger_commission <> v_row.booking_commission
            OR v_row.ledger_net <> v_row.booking_net
          ))
       OR (v_row.payment_id IS NOT NULL AND (
            v_row.payment_gross <> v_row.booking_gross
            OR v_row.payment_commission <> v_row.booking_commission
            OR v_row.payment_net <> v_row.booking_net
          )) THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_row.booking_id,
          'booking_code', v_row.booking_code,
          'discrepancy_code', 'FINANCIAL_SPLIT_MISMATCH',
          'expected_gross', v_row.booking_gross,
          'recorded_ledger_gross', v_row.ledger_gross,
          'recorded_payment_gross', v_row.payment_gross,
          'justification', 'Divergência entre os valores registrados na reserva, no livro-razão ou no pagamento.'
        )
      );
    END IF;

    IF v_row.booking_status IN ('CANCELADA', 'RECUSADA')
       AND v_row.payment_id IS NOT NULL
       AND v_row.payment_status = 'PAGO' THEN
      v_discrepancies := v_discrepancies || jsonb_build_array(
        jsonb_build_object(
          'booking_id', v_row.booking_id,
          'booking_code', v_row.booking_code,
          'discrepancy_code', 'CANCELLED_BOOKING_UNREFUNDED_PAYMENT',
          'booking_status', v_row.booking_status,
          'payment_status', v_row.payment_status,
          'justification', 'Reserva cancelada/recusada possui pagamento confirmado ainda não estornado.'
        )
      );
    END IF;

    IF v_row.payment_id IS NOT NULL THEN
      IF v_row.payment_status IN ('PENDENTE', 'PROCESSANDO') THEN
        v_pending_payments_count := v_pending_payments_count + 1;
      ELSIF v_row.payment_status IN ('PAGO', 'ESTORNO_PARCIAL') THEN
        v_confirmed_payments_count := v_confirmed_payments_count + 1;
        v_total_gross_received := v_total_gross_received + v_row.effective_gross_amount;
        v_total_commissions := v_total_commissions + v_row.effective_commission_amount;
        v_total_net_partner := v_total_net_partner + v_row.effective_net_partner_amount;
        v_total_refunded := v_total_refunded + v_row.refunded_gross_amount;
      ELSIF v_row.payment_status = 'ESTORNADO' THEN
        v_refunded_payments_count := v_refunded_payments_count + 1;
        v_total_refunded := v_total_refunded + v_row.refunded_gross_amount;
      END IF;
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'ok', true,
    'scope_partner_id', v_effective_partner_id,
    'total_gross_received', v_total_gross_received,
    'total_commissions', v_total_commissions,
    'total_net_partner', v_total_net_partner,
    'total_refunded', v_total_refunded,
    'pending_payments_count', v_pending_payments_count,
    'confirmed_payments_count', v_confirmed_payments_count,
    'refunded_payments_count', v_refunded_payments_count,
    'discrepancies_count', pg_catalog.jsonb_array_length(v_discrepancies),
    'discrepancies', v_discrepancies
  );
END;
$body$;

-- 13. Privilégios Mínimos (REVOKE ALL FROM PUBLIC / anon / authenticated + GRANT EXECUTE seletivo)
DO $$
DECLARE
  r_fn RECORD;
BEGIN
  FOR r_fn IN
    SELECT p.oid::regprocedure AS fn_sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.proname IN (
        'is_valid_payment_status_transition',
        'calculate_proportional_refund_split',
        'enforce_booking_payment_invariants',
        'enforce_append_only_financial_audit_tables',
        'create_or_initiate_booking_payment',
        'confirm_or_fail_booking_payment',
        'process_booking_refund',
        'get_financial_reconciliation_report'
      )
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', r_fn.fn_sig);
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
      EXECUTE format('REVOKE ALL ON FUNCTION %s FROM authenticated', r_fn.fn_sig);
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r_fn.fn_sig);
    END IF;
  END LOOP;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT EXECUTE ON FUNCTION public.is_valid_payment_status_transition(public.payment_status_type, public.payment_status_type) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.calculate_proportional_refund_split(NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC, NUMERIC) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_or_initiate_booking_payment(UUID, public.payment_method_type, TEXT, NUMERIC, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.confirm_or_fail_booking_payment(UUID, public.payment_status_type, TEXT, TEXT, NUMERIC, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.process_booking_refund(UUID, NUMERIC, TEXT, TEXT, BOOLEAN) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_financial_reconciliation_report(UUID) TO authenticated;
  END IF;
END
$$;
