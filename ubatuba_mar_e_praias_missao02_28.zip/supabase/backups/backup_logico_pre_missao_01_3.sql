-- ============================================================================
-- MIGRATION 0001: ARQUITETURA RELACIONAL COMPLETA (19 TABELAS + ENUMS)
-- Projeto: Ubatuba Mar & Praias Marketplace Multi-Tenant
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE public.app_role AS ENUM ('tourist', 'partner', 'admin');
CREATE TYPE public.partner_status AS ENUM ('PENDENTE', 'APROVADO', 'SUSPENSO');
CREATE TYPE public.moderation_status AS ENUM ('RASCUNHO', 'PENDENTE_APROVACAO', 'APROVADO', 'REPROVADO', 'SUSPENSO');
CREATE TYPE public.pricing_model_type AS ENUM ('POR_PESSOA', 'POR_EMBARCACAO');
CREATE TYPE public.commission_model_type AS ENUM (
  'PERCENTAGE',
  'FIXED_PER_PASSENGER',
  'FIXED_PER_BOOKING',
  'HYBRID_PERCENT_PLUS_FIXED'
);
CREATE TYPE public.booking_status_type AS ENUM (
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
  'RECUSADA',
  'CANCELADA',
  'PASSEIO_REALIZADO',
  'EM_DISPUTA'
);
CREATE TYPE public.ledger_status_type AS ENUM (
  'PREVISTA',
  'CONFIRMADA',
  'PAGA',
  'REVERTIDA',
  'EM_DISPUTA'
);

-- 1. PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL CHECK (char_length(trim(full_name)) >= 2),
  phone VARCHAR(25),
  city TEXT,
  system_role public.app_role NOT NULL DEFAULT 'tourist',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. PARTNERS
CREATE TABLE public.partners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  legal_name TEXT NOT NULL,
  cnpj VARCHAR(18) NOT NULL UNIQUE,
  whatsapp VARCHAR(20) NOT NULL CHECK (whatsapp ~ '^[0-9]{12,15}$'),
  email TEXT NOT NULL,
  base_marina TEXT NOT NULL,
  status public.partner_status NOT NULL DEFAULT 'PENDENTE',
  verified BOOLEAN NOT NULL DEFAULT false,
  years_operating SMALLINT NOT NULL DEFAULT 0 CHECK (years_operating >= 0),
  bio TEXT,
  avatar_url TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00 CHECK (rating_avg BETWEEN 0.00 AND 5.00),
  reviews_count INTEGER NOT NULL DEFAULT 0 CHECK (reviews_count >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. PARTNER_MEMBERS (Multi-Tenant N:N)
CREATE TABLE public.partner_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  member_role TEXT NOT NULL DEFAULT 'owner' CHECK (member_role IN ('owner', 'manager', 'operator')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (partner_id, user_id)
);

-- 4. DESTINATIONS
CREATE TABLE public.destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Praias', 'Ilhas', 'Cachoeiras', 'Trilhas e Aventuras')),
  region TEXT NOT NULL CHECK (region IN ('Norte', 'Centro', 'Sul', 'Sertão / Serra do Mar')),
  short_description TEXT NOT NULL,
  full_description TEXT NOT NULL,
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  map_x SMALLINT NOT NULL CHECK (map_x BETWEEN 0 AND 100),
  map_y SMALLINT NOT NULL CHECK (map_y BETWEEN 0 AND 100),
  how_to_get_there TEXT NOT NULL,
  access_type TEXT NOT NULL CHECK (access_type IN ('Barco / Lancha', 'Trilha', 'Acesso Asfaltado / Carro', 'Barco ou Trilha')),
  characteristics TEXT[] NOT NULL DEFAULT '{}',
  infrastructure TEXT NOT NULL,
  visitor_tips TEXT[] NOT NULL DEFAULT '{}',
  environmental_rules TEXT[] NOT NULL DEFAULT '{}',
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  video_duration VARCHAR(10),
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00 CHECK (rating_avg BETWEEN 0.00 AND 5.00),
  reviews_count INTEGER NOT NULL DEFAULT 0,
  featured BOOLEAN NOT NULL DEFAULT false,
  seo_title TEXT,
  seo_description TEXT,
  source_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. VESSELS
CREATE TABLE public.vessels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  name TEXT NOT NULL,
  vessel_type TEXT NOT NULL CHECK (vessel_type IN ('Lancha', 'Escuna', 'Catamarã / Flexboat')),
  operation_mode TEXT NOT NULL CHECK (operation_mode IN ('Privativo', 'Compartilhado', 'Ambos')),
  capacity SMALLINT NOT NULL CHECK (capacity > 0 AND capacity <= 250),
  length_feet SMALLINT NOT NULL CHECK (length_feet > 0),
  engine_spec TEXT NOT NULL,
  navy_registration_code TEXT,
  base_location TEXT NOT NULL,
  description TEXT NOT NULL,
  features TEXT[] NOT NULL DEFAULT '{}',
  structure TEXT[] NOT NULL DEFAULT '{}',
  safety_equipment TEXT[] NOT NULL DEFAULT '{}',
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00,
  status public.moderation_status NOT NULL DEFAULT 'APROVADO',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. ITINERARIES
CREATE TABLE public.itineraries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  region TEXT NOT NULL,
  estimated_duration TEXT NOT NULL,
  navigation_level TEXT NOT NULL,
  description TEXT NOT NULL,
  stops_count SMALLINT NOT NULL DEFAULT 1 CHECK (stops_count >= 0),
  stops_details TEXT[] NOT NULL DEFAULT '{}',
  navigation_notes TEXT,
  hero_image_url TEXT,
  video_title TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. ITINERARY_DESTINATIONS
CREATE TABLE public.itinerary_destinations (
  itinerary_id UUID NOT NULL REFERENCES public.itineraries(id) ON DELETE CASCADE,
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE RESTRICT,
  stop_order SMALLINT NOT NULL DEFAULT 1,
  PRIMARY KEY (itinerary_id, destination_id),
  UNIQUE (itinerary_id, stop_order)
);

-- 8. ITINERARY_VESSELS
CREATE TABLE public.itinerary_vessels (
  itinerary_id UUID NOT NULL REFERENCES public.itineraries(id) ON DELETE CASCADE,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  confirmed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (itinerary_id, vessel_id)
);

-- 9. TOURS
CREATE TABLE public.tours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  itinerary_id UUID REFERENCES public.itineraries(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  tour_type TEXT NOT NULL CHECK (tour_type IN ('Privativo', 'Compartilhado')),
  vessel_type TEXT NOT NULL CHECK (vessel_type IN ('Lancha', 'Escuna')),
  pricing_model public.pricing_model_type NOT NULL,
  price NUMERIC(12,2) NOT NULL CHECK (price > 0),
  capacity SMALLINT NOT NULL CHECK (capacity > 0),
  duration_hours NUMERIC(4,1) NOT NULL CHECK (duration_hours > 0),
  check_in_time TIME NOT NULL,
  departure_time TIME NOT NULL,
  return_time TIME NOT NULL,
  departure_point TEXT NOT NULL,
  swimming_stops JSONB NOT NULL DEFAULT '[]'::jsonb,
  included_items TEXT[] NOT NULL DEFAULT '{}',
  important_info TEXT[] NOT NULL DEFAULT '{}',
  cancellation_policy TEXT NOT NULL,
  status public.moderation_status NOT NULL DEFAULT 'PENDENTE_APROVACAO',
  featured BOOLEAN NOT NULL DEFAULT false,
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00,
  reviews_count INTEGER NOT NULL DEFAULT 0,
  seo_keywords TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Trigger garantindo que a embarcação pertença ao mesmo parceiro do passeio
CREATE OR REPLACE FUNCTION public.validate_tour_vessel_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
BEGIN
  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels WHERE id = NEW.vessel_id;

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'VESSEL_OWNERSHIP_MISMATCH: A embarcação selecionada não pertence ao parceiro do passeio.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.capacity > v_vessel_cap THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDS_VESSEL: Capacidade do passeio (%) excede capacidade da embarcação (%).', NEW.capacity, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_tour_vessel_ownership
  BEFORE INSERT OR UPDATE ON public.tours
  FOR EACH ROW EXECUTE FUNCTION public.validate_tour_vessel_ownership();

-- 10. TOUR_DESTINATIONS
CREATE TABLE public.tour_destinations (
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE CASCADE,
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE RESTRICT,
  stop_order SMALLINT NOT NULL DEFAULT 1,
  PRIMARY KEY (tour_id, destination_id)
);

-- 11. MEDIA_ASSETS
CREATE TABLE public.media_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('photo', 'video')),
  storage_bucket TEXT NOT NULL DEFAULT 'public-catalog-media',
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT 'image/jpeg',
  file_size_bytes BIGINT,
  video_duration VARCHAR(10),
  category TEXT NOT NULL CHECK (category IN ('Destino', 'Embarcação', 'Passeio', 'Experiência')),
  destination_id UUID REFERENCES public.destinations(id) ON DELETE RESTRICT,
  vessel_id UUID REFERENCES public.vessels(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  owner_type TEXT NOT NULL CHECK (owner_type IN ('PLATFORM', 'PARTNER')),
  partner_id UUID REFERENCES public.partners(id) ON DELETE RESTRICT,
  uploaded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  authorized BOOLEAN NOT NULL DEFAULT false,
  is_provisional BOOLEAN NOT NULL DEFAULT false,
  display_order SMALLINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((owner_type = 'PLATFORM' AND partner_id IS NULL) OR (owner_type = 'PARTNER' AND partner_id IS NOT NULL))
);

-- 12. AVAILABILITY_BLOCKS
CREATE TABLE public.availability_blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  block_date DATE NOT NULL,
  block_type TEXT NOT NULL CHECK (block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA', 'AJUSTE_CAPACIDADE')),
  custom_capacity_override SMALLINT,
  reason TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 13. COMMISSION_RULES
CREATE TABLE public.commission_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_type TEXT NOT NULL CHECK (scope_type IN ('PARTNER_DEFAULT', 'TOUR_OVERRIDE')),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  commission_model public.commission_model_type NOT NULL,
  commission_rate_percent NUMERIC(5,2) NOT NULL DEFAULT 0.00 CHECK (commission_rate_percent BETWEEN 0 AND 100),
  commission_fixed_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (commission_fixed_amount >= 0),
  is_active BOOLEAN NOT NULL DEFAULT true,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_until TIMESTAMPTZ,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((scope_type = 'PARTNER_DEFAULT' AND tour_id IS NULL) OR (scope_type = 'TOUR_OVERRIDE' AND tour_id IS NOT NULL)),
  CHECK (NOT (commission_rate_percent = 0 AND commission_fixed_amount = 0))
);

CREATE UNIQUE INDEX idx_active_partner_comm_rule
  ON public.commission_rules(partner_id)
  WHERE is_active = true AND scope_type = 'PARTNER_DEFAULT';

CREATE UNIQUE INDEX idx_active_tour_comm_rule
  ON public.commission_rules(tour_id)
  WHERE is_active = true AND scope_type = 'TOUR_OVERRIDE';

-- 14. BOOKINGS
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(16) NOT NULL UNIQUE,
  idempotency_key VARCHAR(64) NOT NULL UNIQUE,
  tourist_user_id UUID REFERENCES public.profiles(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  customer_name TEXT NOT NULL,
  customer_phone VARCHAR(25) NOT NULL,
  customer_email TEXT NOT NULL,
  booking_date DATE NOT NULL,
  passengers SMALLINT NOT NULL CHECK (passengers > 0),
  channel TEXT NOT NULL CHECK (channel IN ('WHATSAPP', 'SITE_DIRECT')),
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  status public.booking_status_type NOT NULL,
  pricing_model_snapshot public.pricing_model_type NOT NULL,
  unit_price_snapshot NUMERIC(12,2) NOT NULL,
  gross_amount NUMERIC(12,2) NOT NULL CHECK (gross_amount >= 0),
  commission_rule_id UUID REFERENCES public.commission_rules(id) ON DELETE RESTRICT,
  commission_model_snapshot public.commission_model_type NOT NULL,
  commission_rate_snapshot NUMERIC(5,2) NOT NULL,
  commission_fixed_snapshot NUMERIC(12,2) NOT NULL,
  commission_rule_label TEXT NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL CHECK (commission_amount >= 0),
  net_partner_amount NUMERIC(12,2) NOT NULL CHECK (net_partner_amount >= 0),
  notes TEXT,
  rejection_or_cancel_reason TEXT,
  expires_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (gross_amount = commission_amount + net_partner_amount)
);

-- 15. BOOKING_STATUS_HISTORY
CREATE TABLE public.booking_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE RESTRICT,
  previous_status public.booking_status_type,
  new_status public.booking_status_type NOT NULL,
  changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  changed_by_role public.app_role,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 16. COMMISSION_LEDGER
CREATE TABLE public.commission_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  ledger_status public.ledger_status_type NOT NULL DEFAULT 'PREVISTA',
  gross_amount NUMERIC(12,2) NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL,
  net_partner_amount NUMERIC(12,2) NOT NULL,
  rule_snapshot_json JSONB NOT NULL,
  consolidated_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  reversed_at TIMESTAMPTZ,
  adjustment_notes TEXT,
  updated_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (gross_amount = commission_amount + net_partner_amount)
);

-- 17. REVIEWS
CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tourist_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  author_name TEXT NOT NULL,
  author_city TEXT,
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 18. PLATFORM_SETTINGS
CREATE TABLE public.platform_settings (
  key TEXT PRIMARY KEY,
  value_json JSONB NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 19. AUDIT_LOGS
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID,
  actor_role public.app_role,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  action TEXT NOT NULL,
  old_data JSONB,
  new_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- ============================================================================
-- MIGRATION 0002: FUNÇÕES DE SEGURANÇA, RLS MULTI-TENANT E RPCS TRANSACIONAIS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND system_role = 'admin' AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_partner_member(p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.partner_members pm
    JOIN public.profiles pr ON pr.id = pm.user_id
    WHERE pm.partner_id = p_partner_id
      AND pm.user_id = auth.uid()
      AND pm.is_active = true
      AND pr.is_active = true
  );
$$;

-- Habilita RLS em todas as tabelas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itineraries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tour_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.availability_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Políticas Principais
CREATE POLICY "profiles_self_or_admin" ON public.profiles
  FOR SELECT USING (id = auth.uid() OR public.is_admin());

CREATE POLICY "partners_public_or_member_or_admin" ON public.partners
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(id) OR public.is_admin());

CREATE POLICY "destinations_public_read" ON public.destinations
  FOR SELECT USING (is_published = true OR public.is_admin());

CREATE POLICY "vessels_public_or_owner" ON public.vessels
  FOR SELECT USING ((status = 'APROVADO' AND is_active = true) OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "vessels_partner_write" ON public.vessels
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_public_or_owner" ON public.tours
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_partner_insert" ON public.tours
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_isolated_read" ON public.commission_rules
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_admin_only_write" ON public.commission_rules
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "bookings_isolated_read" ON public.bookings
  FOR SELECT USING (tourist_user_id = auth.uid() OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "ledger_isolated_read" ON public.commission_ledger
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "audit_logs_admin_only" ON public.audit_logs
  FOR SELECT USING (public.is_admin());
-- ============================================================================
-- MIGRATION 0003: MISSÃO 01 — AUDITORIA, CORREÇÃO DE CONTRATOS, PERFIS AUTH,
-- MÁQUINA DE TRANSIÇÃO DE ESTADOS, ANTI-OVERBOOKING CONCORRENTE E RPCS
-- Projeto: Ubatuba Mar & Praias — ARGON 4
-- Escopo: MP-002, MP-004, MP-006, MP-007, MP-008, MP-009, MP-010, MP-011,
--         MP-012, MP-013, MP-014, MP-015, MP-016, MP-018, MP-019, MP-024
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0. GARANTIA DE COMPATIBILIDADE COM AMBIENTES POSTGRES ISOLADOS (FORA DO SUPABASE)
-- ----------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'auth') THEN
    CREATE SCHEMA auth;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'auth' AND table_name = 'users'
  ) THEN
    CREATE TABLE auth.users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email TEXT UNIQUE,
      raw_user_meta_data JSONB DEFAULT '{}'::jsonb,
      raw_app_meta_data JSONB DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'auth' AND p.proname = 'uid'
  ) THEN
    EXECUTE $fn$
      CREATE FUNCTION auth.uid() RETURNS UUID LANGUAGE sql STABLE AS $body$
        SELECT NULLIF(current_setting('request.jwt.claim.sub', true), '')::uuid;
      $body$;
    $fn$;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'auth' AND p.proname = 'jwt'
  ) THEN
    EXECUTE $fn$
      CREATE FUNCTION auth.jwt() RETURNS JSONB LANGUAGE sql STABLE AS $body$
        SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
      $body$;
    $fn$;
  END IF;
END
$$;

-- ----------------------------------------------------------------------------
-- 1. CORREÇÕES DE CONSTRAINTS E INTEGRIDADE ESTRUTURAL (MP-004, MP-009, MP-016, MP-018, MP-019)
-- ----------------------------------------------------------------------------

-- MP-004: Alinha tours.vessel_type com vessels.vessel_type ('Lancha', 'Escuna', 'Catamarã / Flexboat')
DO $$
DECLARE
  v_con_name TEXT;
BEGIN
  FOR v_con_name IN
    SELECT con.conname
    FROM pg_constraint con
    JOIN pg_class rel ON rel.oid = con.conrelid
    JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
    WHERE nsp.nspname = 'public'
      AND rel.relname = 'tours'
      AND con.contype = 'c'
      AND pg_get_constraintdef(con.oid) LIKE '%vessel_type%'
  LOOP
    EXECUTE format('ALTER TABLE public.tours DROP CONSTRAINT %I', v_con_name);
  END LOOP;
END
$$;

ALTER TABLE public.tours
  ADD CONSTRAINT chk_tours_vessel_type_valid
  CHECK (vessel_type IN ('Lancha', 'Escuna', 'Catamarã / Flexboat'));

-- MP-018: Garante consistência de horários em public.tours
ALTER TABLE public.tours
  DROP CONSTRAINT IF EXISTS chk_tours_time_sequence,
  ADD CONSTRAINT chk_tours_time_sequence
  CHECK (check_in_time <= departure_time AND departure_time < return_time);

-- MP-004: Aprimora trigger de propriedade e compatibilidade entre Passeio e Embarcação
CREATE OR REPLACE FUNCTION public.validate_tour_vessel_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
  v_vessel_type TEXT;
  v_vessel_op_mode TEXT;
BEGIN
  SELECT partner_id, capacity, vessel_type, operation_mode
    INTO v_vessel_partner, v_vessel_cap, v_vessel_type, v_vessel_op_mode
  FROM public.vessels
  WHERE id = NEW.vessel_id;

  IF v_vessel_partner IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', NEW.vessel_id
      USING ERRCODE = '23503';
  END IF;

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'VESSEL_OWNERSHIP_MISMATCH: A embarcação selecionada não pertence ao parceiro do passeio.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.capacity > v_vessel_cap THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDS_VESSEL: Capacidade do passeio (%) excede capacidade da embarcação (%).', NEW.capacity, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  IF NEW.vessel_type IS DISTINCT FROM v_vessel_type THEN
    RAISE EXCEPTION 'VESSEL_TYPE_MISMATCH: O tipo de embarcação do passeio (%) difere do tipo real da embarcação (%).', NEW.vessel_type, v_vessel_type
      USING ERRCODE = '23514';
  END IF;

  IF v_vessel_op_mode <> 'Ambos' AND v_vessel_op_mode IS DISTINCT FROM NEW.tour_type THEN
    RAISE EXCEPTION 'VESSEL_OPERATION_MODE_MISMATCH: A embarcação opera somente no modo %, incompatível com passeio %.', v_vessel_op_mode, NEW.tour_type
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

-- MP-016: Validação de availability_blocks (override de capacidade e titularidade da embarcação)
ALTER TABLE public.availability_blocks
  DROP CONSTRAINT IF EXISTS chk_availability_blocks_override_consistency,
  ADD CONSTRAINT chk_availability_blocks_override_consistency
  CHECK (
    (block_type = 'AJUSTE_CAPACIDADE' AND custom_capacity_override IS NOT NULL AND custom_capacity_override > 0)
    OR (block_type <> 'AJUSTE_CAPACIDADE' AND custom_capacity_override IS NULL)
  );

CREATE OR REPLACE FUNCTION public.validate_availability_block_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
  v_tour_partner UUID;
  v_tour_vessel UUID;
  v_active_confirmed INTEGER := 0;
BEGIN
  -- Hierarquia canônica de lock (1º Advisory Lock embarcação+data, 2º Lock na embarcação)
  PERFORM pg_advisory_xact_lock(hashtext(NEW.vessel_id::text), hashtext(NEW.block_date::text));

  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels
  WHERE id = NEW.vessel_id
  FOR UPDATE;

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'BLOCK_VESSEL_OWNERSHIP_MISMATCH: A embarcação bloqueada não pertence ao parceiro informado.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS NOT NULL THEN
    SELECT partner_id, vessel_id INTO v_tour_partner, v_tour_vessel
    FROM public.tours
    WHERE id = NEW.tour_id;

    IF v_tour_partner IS DISTINCT FROM NEW.partner_id OR v_tour_vessel IS DISTINCT FROM NEW.vessel_id THEN
      RAISE EXCEPTION 'BLOCK_TOUR_MISMATCH: O passeio informado no bloqueio não pertence à mesma embarcação/parceiro.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override > v_vessel_cap THEN
    RAISE EXCEPTION 'OVERRIDE_EXCEEDS_VESSEL_CAPACITY: Ajuste de capacidade (%) excede a capacidade máxima da embarcação (%).',
      NEW.custom_capacity_override, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  -- Verifica se já existem reservas confirmadas/realizadas na data que conflitem com o bloqueio
  SELECT COALESCE(SUM(passengers), 0)::integer INTO v_active_confirmed
  FROM public.bookings
  WHERE vessel_id = NEW.vessel_id
    AND booking_date = NEW.block_date
    AND status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA');

  IF NEW.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') AND v_active_confirmed > 0 THEN
    RAISE EXCEPTION 'BLOCK_CONFLICTS_WITH_CONFIRMED_BOOKINGS: Não é possível aplicar % em % pois já existem % passageiros confirmados na data.',
      NEW.block_type, NEW.block_date, v_active_confirmed
      USING ERRCODE = 'P0001';
  END IF;

  IF NEW.block_type = 'AJUSTE_CAPACIDADE' AND NEW.custom_capacity_override < v_active_confirmed THEN
    RAISE EXCEPTION 'OVERRIDE_BELOW_OCCUPIED_SEATS: Ajuste de capacidade (%) é inferior aos % passageiros já confirmados na data %.',
      NEW.custom_capacity_override, v_active_confirmed, NEW.block_date
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_availability_block_ownership ON public.availability_blocks;
CREATE TRIGGER trg_validate_availability_block_ownership
  BEFORE INSERT OR UPDATE ON public.availability_blocks
  FOR EACH ROW EXECUTE FUNCTION public.validate_availability_block_ownership();

-- MP-019: Valida que em commission_rules do tipo TOUR_OVERRIDE o passeio pertence ao parceiro
CREATE OR REPLACE FUNCTION public.validate_commission_rule_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
DECLARE
  v_tour_partner UUID;
BEGIN
  IF NEW.tour_id IS NOT NULL THEN
    SELECT partner_id INTO v_tour_partner
    FROM public.tours
    WHERE id = NEW.tour_id;

    IF v_tour_partner IS DISTINCT FROM NEW.partner_id THEN
      RAISE EXCEPTION 'COMMISSION_RULE_TOUR_MISMATCH: O passeio da regra de comissão não pertence ao parceiro informado.'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF NEW.effective_until IS NOT NULL AND NEW.effective_until <= NEW.effective_from THEN
    RAISE EXCEPTION 'COMMISSION_RULE_INVALID_PERIOD: effective_until deve ser posterior a effective_from.'
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_commission_rule_ownership ON public.commission_rules;
CREATE TRIGGER trg_validate_commission_rule_ownership
  BEFORE INSERT OR UPDATE ON public.commission_rules
  FOR EACH ROW EXECUTE FUNCTION public.validate_commission_rule_ownership();

-- MP-009 & MP-018: Constraints adicionais de integridade financeira e dados de cliente em bookings e commission_ledger
ALTER TABLE public.bookings
  DROP CONSTRAINT IF EXISTS chk_bookings_customer_name_valid,
  ADD CONSTRAINT chk_bookings_customer_name_valid
    CHECK (char_length(trim(customer_name)) >= 3),
  DROP CONSTRAINT IF EXISTS chk_bookings_customer_email_valid,
  ADD CONSTRAINT chk_bookings_customer_email_valid
    CHECK (position('@' in trim(customer_email)) > 1 AND char_length(trim(customer_email)) >= 5),
  DROP CONSTRAINT IF EXISTS chk_bookings_customer_phone_valid,
  ADD CONSTRAINT chk_bookings_customer_phone_valid
    CHECK (char_length(regexp_replace(customer_phone, '[^0-9]', '', 'g')) BETWEEN 10 AND 15),
  DROP CONSTRAINT IF EXISTS chk_bookings_unit_price_positive,
  ADD CONSTRAINT chk_bookings_unit_price_positive
    CHECK (unit_price_snapshot > 0),
  DROP CONSTRAINT IF EXISTS chk_bookings_comm_rate_valid,
  ADD CONSTRAINT chk_bookings_comm_rate_valid
    CHECK (commission_rate_snapshot BETWEEN 0 AND 100),
  DROP CONSTRAINT IF EXISTS chk_bookings_comm_fixed_valid,
  ADD CONSTRAINT chk_bookings_comm_fixed_valid
    CHECK (commission_fixed_snapshot >= 0);

ALTER TABLE public.commission_ledger
  DROP CONSTRAINT IF EXISTS chk_commission_ledger_non_negative,
  ADD CONSTRAINT chk_commission_ledger_non_negative
    CHECK (gross_amount >= 0 AND commission_amount >= 0 AND net_partner_amount >= 0);

-- ----------------------------------------------------------------------------
-- 2. TRIGGERS DE ATUALIZAÇÃO AUTOMÁTICA DE updated_at (MP-008)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profiles_set_updated_at ON public.profiles;
CREATE TRIGGER trg_profiles_set_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_partners_set_updated_at ON public.partners;
CREATE TRIGGER trg_partners_set_updated_at
  BEFORE UPDATE ON public.partners
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_destinations_set_updated_at ON public.destinations;
CREATE TRIGGER trg_destinations_set_updated_at
  BEFORE UPDATE ON public.destinations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_vessels_set_updated_at ON public.vessels;
CREATE TRIGGER trg_vessels_set_updated_at
  BEFORE UPDATE ON public.vessels
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_tours_set_updated_at ON public.tours;
CREATE TRIGGER trg_tours_set_updated_at
  BEFORE UPDATE ON public.tours
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_bookings_set_updated_at ON public.bookings;
CREATE TRIGGER trg_bookings_set_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_commission_ledger_set_updated_at ON public.commission_ledger;
CREATE TRIGGER trg_commission_ledger_set_updated_at
  BEFORE UPDATE ON public.commission_ledger
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_platform_settings_set_updated_at ON public.platform_settings;
CREATE TRIGGER trg_platform_settings_set_updated_at
  BEFORE UPDATE ON public.platform_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ----------------------------------------------------------------------------
-- 3. ÍNDICES DE CHAVES ESTRANGEIRAS, RLS E CONSULTAS DE CAPACIDADE (MP-006)
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_partner_members_user_id
  ON public.partner_members(user_id) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_partner_members_partner_active
  ON public.partner_members(partner_id, is_active);
CREATE INDEX IF NOT EXISTS idx_vessels_partner_status
  ON public.vessels(partner_id, status, is_active);
CREATE INDEX IF NOT EXISTS idx_tours_partner_status
  ON public.tours(partner_id, status);
CREATE INDEX IF NOT EXISTS idx_tours_vessel_id
  ON public.tours(vessel_id);
CREATE INDEX IF NOT EXISTS idx_tours_itinerary_id
  ON public.tours(itinerary_id);
CREATE INDEX IF NOT EXISTS idx_tour_destinations_dest_id
  ON public.tour_destinations(destination_id);
CREATE INDEX IF NOT EXISTS idx_itinerary_destinations_dest_id
  ON public.itinerary_destinations(destination_id);
CREATE INDEX IF NOT EXISTS idx_itinerary_vessels_vessel_id
  ON public.itinerary_vessels(vessel_id);
CREATE INDEX IF NOT EXISTS idx_media_assets_partner_cat
  ON public.media_assets(partner_id, category);
CREATE INDEX IF NOT EXISTS idx_media_assets_destination_id
  ON public.media_assets(destination_id);
CREATE INDEX IF NOT EXISTS idx_media_assets_vessel_id
  ON public.media_assets(vessel_id);
CREATE INDEX IF NOT EXISTS idx_media_assets_tour_id
  ON public.media_assets(tour_id);
CREATE INDEX IF NOT EXISTS idx_availability_blocks_vessel_date
  ON public.availability_blocks(vessel_id, block_date);
CREATE INDEX IF NOT EXISTS idx_availability_blocks_partner_date
  ON public.availability_blocks(partner_id, block_date);
CREATE INDEX IF NOT EXISTS idx_bookings_vessel_date_status
  ON public.bookings(vessel_id, booking_date, status);
CREATE INDEX IF NOT EXISTS idx_bookings_tour_date_status
  ON public.bookings(tour_id, booking_date, status);
CREATE INDEX IF NOT EXISTS idx_bookings_partner_status_date
  ON public.bookings(partner_id, status, booking_date);
CREATE INDEX IF NOT EXISTS idx_bookings_tourist_user_id
  ON public.bookings(tourist_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_booking_status_history_booking_id
  ON public.booking_status_history(booking_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_commission_ledger_partner_status
  ON public.commission_ledger(partner_id, ledger_status);
CREATE INDEX IF NOT EXISTS idx_reviews_tour_published
  ON public.reviews(tour_id, is_published);
CREATE INDEX IF NOT EXISTS idx_reviews_partner_published
  ON public.reviews(partner_id, is_published);
CREATE INDEX IF NOT EXISTS idx_audit_logs_table_record
  ON public.audit_logs(table_name, record_id, created_at DESC);

-- ----------------------------------------------------------------------------
-- 4. CRIAÇÃO AUTOMÁTICA E PROTEÇÃO DE PERFIL SUPABASE AUTH (MP-012 & MP-013)
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_email TEXT;
  v_raw_name TEXT;
  v_full_name TEXT;
  v_phone VARCHAR(25);
  v_city TEXT;
  v_role_str TEXT;
  v_role public.app_role := 'tourist';
  v_existing_profile_id UUID;
BEGIN
  v_email := lower(trim(COALESCE(NEW.email, '')));

  IF v_email = '' OR position('@' in v_email) <= 1 THEN
    RAISE EXCEPTION 'AUTH_PROFILE_INVALID_EMAIL: O cadastro requer um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  -- Verifica se o e-mail já pertence a outro perfil com UUID distinto
  SELECT id INTO v_existing_profile_id
  FROM public.profiles
  WHERE lower(email) = v_email AND id <> NEW.id
  LIMIT 1;

  IF v_existing_profile_id IS NOT NULL THEN
    RAISE EXCEPTION 'AUTH_PROFILE_DUPLICATE_EMAIL: O e-mail % já está vinculado a outro perfil.', v_email
      USING ERRCODE = '23505';
  END IF;

  -- Validação de nome: se o usuário enviou explicitamente o campo full_name no metadata,
  -- exige ao menos 2 caracteres úteis; se omitiu, deriva do prefixo do e-mail.
  IF NEW.raw_user_meta_data IS NOT NULL AND (NEW.raw_user_meta_data ? 'full_name') THEN
    v_raw_name := trim(COALESCE(NEW.raw_user_meta_data->>'full_name', ''));
    IF char_length(v_raw_name) < 2 THEN
      RAISE EXCEPTION 'AUTH_PROFILE_INVALID_NAME: O nome completo deve conter ao menos 2 caracteres.'
        USING ERRCODE = '23514';
    END IF;
    v_full_name := v_raw_name;
  ELSIF NEW.raw_user_meta_data IS NOT NULL AND (NEW.raw_user_meta_data ? 'name') THEN
    v_raw_name := trim(COALESCE(NEW.raw_user_meta_data->>'name', ''));
    IF char_length(v_raw_name) < 2 THEN
      RAISE EXCEPTION 'AUTH_PROFILE_INVALID_NAME: O nome informado deve conter ao menos 2 caracteres.'
        USING ERRCODE = '23514';
    END IF;
    v_full_name := v_raw_name;
  ELSE
    v_full_name := split_part(v_email, '@', 1);
    IF char_length(trim(v_full_name)) < 2 THEN
      v_full_name := 'Turista ' || v_full_name;
    END IF;
  END IF;

  v_phone := NULLIF(left(trim(COALESCE(NEW.raw_user_meta_data->>'phone', '')), 25), '');
  v_city := NULLIF(trim(COALESCE(NEW.raw_user_meta_data->>'city', '')), '');

  -- Segurança (Supabase RLS Best Practice): NUNCA confiar em raw_user_meta_data para papéis!
  -- Apenas raw_app_meta_data (controlado pelo servidor/service_role) pode definir system_role diferente de 'tourist'.
  v_role_str := lower(trim(COALESCE(NEW.raw_app_meta_data->>'system_role', NEW.raw_app_meta_data->>'role', '')));
  IF v_role_str IN ('tourist', 'partner', 'admin') THEN
    v_role := v_role_str::public.app_role;
  ELSE
    v_role := 'tourist';
  END IF;

  -- Inserção idempotente evitando perfis duplicados
  INSERT INTO public.profiles (
    id,
    email,
    full_name,
    phone,
    city,
    system_role,
    is_active,
    created_at,
    updated_at
  ) VALUES (
    NEW.id,
    v_email,
    v_full_name,
    v_phone,
    v_city,
    v_role,
    true,
    COALESCE(NEW.created_at, now()),
    now()
  )
  ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        full_name = COALESCE(NULLIF(EXCLUDED.full_name, ''), public.profiles.full_name),
        phone = COALESCE(EXCLUDED.phone, public.profiles.phone),
        city = COALESCE(EXCLUDED.city, public.profiles.city),
        updated_at = now();

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

CREATE OR REPLACE FUNCTION public.handle_updated_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_email TEXT;
  v_role_str TEXT;
BEGIN
  v_email := lower(trim(COALESCE(NEW.email, OLD.email, '')));
  IF v_email <> '' AND position('@' in v_email) > 1 THEN
    UPDATE public.profiles
    SET email = v_email,
        updated_at = now()
    WHERE id = NEW.id;
  END IF;

  IF NEW.raw_app_meta_data IS DISTINCT FROM OLD.raw_app_meta_data THEN
    v_role_str := lower(trim(COALESCE(NEW.raw_app_meta_data->>'system_role', NEW.raw_app_meta_data->>'role', '')));
    IF v_role_str IN ('tourist', 'partner', 'admin') THEN
      UPDATE public.profiles
      SET system_role = v_role_str::public.app_role,
          updated_at = now()
      WHERE id = NEW.id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_updated ON auth.users;
CREATE TRIGGER on_auth_user_updated
  AFTER UPDATE OF email, raw_app_meta_data ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_auth_user();

-- Backfill idempotente para quaisquer usuários já presentes em auth.users sem perfil em public.profiles
INSERT INTO public.profiles (id, email, full_name, system_role, is_active)
SELECT
  u.id,
  lower(trim(u.email)),
  CASE
    WHEN char_length(trim(COALESCE(u.raw_user_meta_data->>'full_name', ''))) >= 2
      THEN trim(u.raw_user_meta_data->>'full_name')
    WHEN char_length(split_part(lower(trim(u.email)), '@', 1)) >= 2
      THEN split_part(lower(trim(u.email)), '@', 1)
    ELSE 'Turista Ubatuba'
  END,
  CASE
    WHEN lower(COALESCE(u.raw_app_meta_data->>'system_role', '')) IN ('tourist', 'partner', 'admin')
      THEN (lower(u.raw_app_meta_data->>'system_role'))::public.app_role
    ELSE 'tourist'::public.app_role
  END,
  true
FROM auth.users u
WHERE u.email IS NOT NULL
  AND position('@' in u.email) > 1
  AND NOT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = u.id)
ON CONFLICT (id) DO NOTHING;

-- MP-013: Impede que usuários comuns alterem system_role, id, email ou is_active diretamente em public.profiles
CREATE OR REPLACE FUNCTION public.protect_profile_privileged_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_jwt_role TEXT;
  v_db_role TEXT;
  v_auth_email TEXT;
  v_auth_role_str TEXT;
  v_auth_expected_role public.app_role;
BEGIN
  -- 1. ID do perfil é incondicionalmente imutável para qualquer papel
  IF NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'PROFILE_IMMUTABLE_ID: Não é permitido alterar o identificador do perfil.'
      USING ERRCODE = '42501';
  END IF;

  -- Se nenhuma coluna privilegiada foi modificada, permite atualização de dados cadastrais (full_name, phone, city)
  IF NEW.system_role IS NOT DISTINCT FROM OLD.system_role
     AND NEW.is_active IS NOT DISTINCT FROM OLD.is_active
     AND NEW.email IS NOT DISTINCT FROM OLD.email THEN
    RETURN NEW;
  END IF;

  v_uid := (SELECT auth.uid());
  v_jwt_role := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    ((SELECT auth.jwt()) ->> 'role'),
    ''
  );
  v_db_role := COALESCE(NULLIF(current_setting('role', true), ''), 'none');

  -- 2. Segregação estrita: NUNCA confia em variáveis GUC 'app.*' (como app.internal_auth_sync ou app.current_actor_role),
  --    pois variáveis 'app.*' são USERSET no PostgreSQL e podem ser definidas por clientes via set_config()/SET LOCAL.

  -- Caso A: Quando disparado por trigger interna (pg_trigger_depth() >= 2, ex: on_auth_user_created / on_auth_user_updated),
  -- comprova a veracidade consultando diretamente a tabela protegida auth.users (inacessível para escrita por anon/authenticated).
  IF pg_trigger_depth() >= 2 THEN
    SELECT lower(trim(u.email)),
           lower(trim(COALESCE(u.raw_app_meta_data->>'system_role', u.raw_app_meta_data->>'role', 'tourist')))
      INTO v_auth_email, v_auth_role_str
    FROM auth.users u
    WHERE u.id = NEW.id;

    v_auth_expected_role := CASE
      WHEN v_auth_role_str IN ('tourist', 'partner', 'admin') THEN v_auth_role_str::public.app_role
      ELSE OLD.system_role
    END;

    IF (NEW.email IS NOT DISTINCT FROM OLD.email OR NEW.email = v_auth_email)
       AND (NEW.system_role IS NOT DISTINCT FROM OLD.system_role OR NEW.system_role = v_auth_expected_role)
       AND (NEW.is_active IS NOT DISTINCT FROM OLD.is_active) THEN
      RETURN NEW;
    END IF;
  END IF;

  -- Caso B: Administrador autenticado e ativo no banco (public.is_admin())
  IF v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin() THEN
    RETURN NEW;
  END IF;

  -- Caso C: Operação administrativa de backend via service_role ou sessão superuser pura (sem papel/JWT de cliente)
  IF v_db_role NOT IN ('anon', 'authenticated')
     AND v_jwt_role NOT IN ('anon', 'authenticated')
     AND v_uid IS NULL
     AND COALESCE(NULLIF(current_setting('app.current_actor_role', true), ''), '') NOT IN ('anon', 'tourist', 'partner')
     AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'supabase_auth_admin', 'service_role') THEN
    RETURN NEW;
  END IF;

  IF NEW.system_role IS DISTINCT FROM OLD.system_role THEN
    RAISE EXCEPTION 'PROFILE_ROLE_ESCALATION_FORBIDDEN: Somente administradores podem alterar o papel (system_role) do usuário.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
    RAISE EXCEPTION 'PROFILE_ACTIVE_STATUS_FORBIDDEN: Somente administradores podem alterar o status ativo do perfil.'
      USING ERRCODE = '42501';
  END IF;

  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'PROFILE_EMAIL_DIRECT_CHANGE_FORBIDDEN: O e-mail deve ser atualizado via Supabase Auth.'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_profile_privileged_columns ON public.profiles;
CREATE TRIGGER trg_protect_profile_privileged_columns
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.protect_profile_privileged_columns();

-- ----------------------------------------------------------------------------
-- 5. FUNÇÕES DE SEGURANÇA OTIMIZADAS (MP-007)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = (SELECT auth.uid())
      AND system_role = 'admin'
      AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_partner_member(p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.partner_members pm
    JOIN public.profiles pr ON pr.id = pm.user_id
    WHERE pm.partner_id = p_partner_id
      AND pm.user_id = (SELECT auth.uid())
      AND pm.is_active = true
      AND pr.is_active = true
  );
$$;

-- ----------------------------------------------------------------------------
-- 6. VALIDAÇÃO DE TRANSIÇÕES DE STATUS E CONTROLE TRANSACIONAL DE CAPACIDADE (MP-011, MP-014, MP-015)
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_valid_booking_transition(
  p_old_status public.booking_status_type,
  p_new_status public.booking_status_type
)
RETURNS BOOLEAN
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
BEGIN
  IF p_old_status IS NULL OR p_new_status IS NULL OR p_old_status = p_new_status THEN
    RETURN false;
  END IF;

  CASE p_old_status
    WHEN 'SOLICITADA' THEN
      RETURN p_new_status IN ('AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'RECUSADA', 'CANCELADA');
    WHEN 'AGUARDANDO_CONFIRMACAO' THEN
      RETURN p_new_status IN ('CONFIRMADA', 'RECUSADA', 'CANCELADA');
    WHEN 'CONFIRMADA' THEN
      RETURN p_new_status IN ('PASSEIO_REALIZADO', 'CANCELADA', 'EM_DISPUTA');
    WHEN 'PASSEIO_REALIZADO' THEN
      RETURN p_new_status IN ('EM_DISPUTA');
    WHEN 'EM_DISPUTA' THEN
      RETURN p_new_status IN ('PASSEIO_REALIZADO', 'CANCELADA');
    WHEN 'RECUSADA' THEN
      RETURN false;
    WHEN 'CANCELADA' THEN
      RETURN false;
    ELSE
      RETURN false;
  END CASE;
END;
$$;

-- Determina o papel efetivo do usuário que está executando uma operação sobre uma reserva
CREATE OR REPLACE FUNCTION public.resolve_booking_actor_role(
  p_partner_id UUID,
  p_tourist_user_id UUID
)
RETURNS public.app_role
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_jwt_role TEXT;
  v_db_role TEXT;
BEGIN
  v_uid := (SELECT auth.uid());
  v_jwt_role := COALESCE(
    NULLIF(current_setting('request.jwt.claim.role', true), ''),
    ((SELECT auth.jwt()) ->> 'role'),
    ''
  );
  v_db_role := COALESCE(NULLIF(current_setting('role', true), ''), 'none');

  -- 1. Bloqueia imediatamente papel anônimo (nunca pode alterar status de reservas)
  IF v_jwt_role = 'anon' OR v_db_role = 'anon' THEN
    RETURN NULL;
  END IF;

  -- 2. Para qualquer usuário autenticado (via ROLE authenticated ou JWT sub),
  --    NUNCA confia em variáveis de sessão 'app.*', validando exclusivamente nas tabelas profiles e partner_members.
  IF v_uid IS NOT NULL OR v_db_role = 'authenticated' OR v_jwt_role = 'authenticated' THEN
    IF public.is_admin() THEN
      RETURN 'admin';
    END IF;

    IF public.is_partner_member(p_partner_id) THEN
      RETURN 'partner';
    END IF;

    IF v_uid IS NOT NULL AND p_tourist_user_id IS NOT NULL AND v_uid = p_tourist_user_id THEN
      IF EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
        RETURN 'tourist';
      END IF;
    END IF;

    RETURN NULL;
  END IF;

  -- 3. Apenas sessões administrativas de backend (service_role / postgres superuser sem contexto de cliente)
  IF v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')
     AND v_jwt_role IN ('', 'service_role', 'postgres', 'supabase_admin') THEN
    RETURN 'admin';
  END IF;

  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.can_actor_execute_booking_transition(
  p_old_status public.booking_status_type,
  p_new_status public.booking_status_type,
  p_actor_role public.app_role
)
RETURNS BOOLEAN
LANGUAGE plpgsql
IMMUTABLE
SET search_path = public, pg_temp
AS $$
BEGIN
  IF p_actor_role IS NULL THEN
    RETURN false;
  END IF;

  IF NOT public.is_valid_booking_transition(p_old_status, p_new_status) THEN
    RETURN false;
  END IF;

  IF p_actor_role = 'admin' THEN
    RETURN true;
  END IF;

  IF p_actor_role = 'partner' THEN
    -- Parceiro pode conduzir o fluxo operacional, mas não encerrar disputa unilateralmente
    IF p_old_status = 'EM_DISPUTA' THEN
      RETURN false;
    END IF;
    RETURN p_new_status IN (
      'AGUARDANDO_CONFIRMACAO',
      'CONFIRMADA',
      'RECUSADA',
      'CANCELADA',
      'PASSEIO_REALIZADO',
      'EM_DISPUTA'
    );
  END IF;

  IF p_actor_role = 'tourist' THEN
    -- Turista pode apenas cancelar sua reserva antes da realização ou abrir disputa após confirmação/realização
    IF p_old_status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA') AND p_new_status = 'CANCELADA' THEN
      RETURN true;
    END IF;
    IF p_old_status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') AND p_new_status = 'EM_DISPUTA' THEN
      RETURN true;
    END IF;
    RETURN false;
  END IF;

  RETURN false;
END;
$$;

-- MP-015: Controle Transacional de Capacidade com Lock Pessimista (FOR UPDATE + Advisory Lock)
CREATE OR REPLACE FUNCTION public.check_and_lock_vessel_capacity(
  p_vessel_id UUID,
  p_tour_id UUID,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_exclude_booking_id UUID DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_vessel RECORD;
  v_tour RECORD;
  v_partner RECORD;
  v_block RECORD;
  v_effective_capacity INTEGER;
  v_occupied_seats INTEGER := 0;
  v_active_bookings_count INTEGER := 0;
  v_active_private_count INTEGER := 0;
  v_remaining_seats INTEGER := 0;
BEGIN
  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data da reserva é obrigatória.'
      USING ERRCODE = '23514';
  END IF;

  -- 1. Lock transacional ao nível de (embarcação + data) para serializar requisições simultâneas
  PERFORM pg_advisory_xact_lock(hashtext(p_vessel_id::text), hashtext(p_booking_date::text));

  -- 2. Lock de linha pessimista na embarcação
  SELECT id, name, partner_id, capacity, status, is_active, operation_mode
    INTO v_vessel
  FROM public.vessels
  WHERE id = p_vessel_id
  FOR UPDATE;

  IF v_vessel.id IS NULL THEN
    RAISE EXCEPTION 'VESSEL_NOT_FOUND: Embarcação (%) não encontrada.', p_vessel_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_vessel.status <> 'APROVADO' OR v_vessel.is_active = false THEN
    RAISE EXCEPTION 'VESSEL_UNAVAILABLE: Embarcação (%) não está ativa/aprovada para reservas.', v_vessel.name
      USING ERRCODE = 'P0001';
  END IF;

  -- 3. Lock e validação do passeio e do parceiro
  SELECT id, title, partner_id, vessel_id, tour_type, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = p_tour_id
  FOR SHARE;

  IF v_tour.id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_tour.vessel_id IS DISTINCT FROM v_vessel.id THEN
    RAISE EXCEPTION 'TOUR_VESSEL_MISMATCH: O passeio não pertence à embarcação informada.'
      USING ERRCODE = '23514';
  END IF;

  IF v_tour.status <> 'APROVADO' THEN
    RAISE EXCEPTION 'TOUR_NOT_APPROVED: O passeio (%) não está publicado/aprovado para reservas.', v_tour.title
      USING ERRCODE = 'P0001';
  END IF;

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id
  FOR SHARE;

  IF v_partner.id IS NULL OR v_partner.status <> 'APROVADO' THEN
    RAISE EXCEPTION 'PARTNER_UNAVAILABLE: O parceiro operador não está ativo para reservas.'
      USING ERRCODE = 'P0001';
  END IF;

  v_effective_capacity := LEAST(v_tour.capacity::integer, v_vessel.capacity::integer);

  -- 4. Verifica bloqueios operacionais de agenda (availability_blocks)
  FOR v_block IN
    SELECT block_type, custom_capacity_override, COALESCE(reason, 'Bloqueio operacional') AS reason
    FROM public.availability_blocks
    WHERE vessel_id = p_vessel_id
      AND block_date = p_booking_date
      AND (tour_id IS NULL OR tour_id = p_tour_id)
    ORDER BY CASE WHEN block_type = 'AJUSTE_CAPACIDADE' THEN 2 ELSE 1 END
  LOOP
    IF v_block.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') THEN
      RAISE EXCEPTION 'DATE_BLOCKED: Embarcação indisponível em % (% - %).',
        p_booking_date, v_block.block_type, v_block.reason
        USING ERRCODE = 'P0001';
    ELSIF v_block.block_type = 'AJUSTE_CAPACIDADE' AND v_block.custom_capacity_override IS NOT NULL THEN
      v_effective_capacity := LEAST(v_effective_capacity, v_block.custom_capacity_override::integer);
    END IF;
  END LOOP;

  -- 5. Bloqueia pessimistamente as linhas de reservas ativas da embarcação na data (evita 0A000 FOR UPDATE com agregação)
  PERFORM 1
  FROM public.bookings bk
  WHERE bk.vessel_id = p_vessel_id
    AND bk.booking_date = p_booking_date
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    )
    AND (p_exclude_booking_id IS NULL OR bk.id <> p_exclude_booking_id)
  FOR UPDATE;

  -- 6. Calcula ocupação ativa após adquirir os locks
  SELECT
    COALESCE(SUM(bk.passengers), 0)::integer,
    COUNT(*)::integer,
    COALESCE(SUM(CASE WHEN t.tour_type = 'Privativo' OR bk.pricing_model_snapshot = 'POR_EMBARCACAO' THEN 1 ELSE 0 END), 0)::integer
  INTO
    v_occupied_seats,
    v_active_bookings_count,
    v_active_private_count
  FROM public.bookings bk
  JOIN public.tours t ON t.id = bk.tour_id
  WHERE bk.vessel_id = p_vessel_id
    AND bk.booking_date = p_booking_date
    AND bk.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      bk.expires_at IS NULL
      OR bk.expires_at > now()
      OR bk.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    )
    AND (p_exclude_booking_id IS NULL OR bk.id <> p_exclude_booking_id);

  -- Se já existe charter privativo ativo na embarcação nesta data, nenhuma outra reserva pode entrar
  IF v_active_private_count > 0 THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDED: Embarcação já possui reserva privativa ativa na data %.', p_booking_date
      USING ERRCODE = 'P0001';
  END IF;

  -- Se o passeio solicitado é Privativo, a embarcação não pode ter nenhuma outra reserva ativa na data
  IF v_tour.tour_type = 'Privativo' AND v_active_bookings_count > 0 THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDED: Embarcação já possui vagas ocupadas na data %, indisponível para charter privativo.', p_booking_date
      USING ERRCODE = 'P0001';
  END IF;

  v_remaining_seats := GREATEST(0, v_effective_capacity - v_occupied_seats);

  IF p_passengers > v_remaining_seats THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDED: Solicitação de % passageiros excede as % vagas disponíveis na data %.',
      p_passengers, v_remaining_seats, p_booking_date
      USING ERRCODE = 'P0001';
  END IF;

  RETURN jsonb_build_object(
    'effective_capacity', v_effective_capacity,
    'occupied_seats', v_occupied_seats,
    'remaining_seats_before', v_remaining_seats,
    'remaining_seats_after', v_remaining_seats - p_passengers
  );
END;
$$;

-- Trigger BEFORE INSERT OR UPDATE em public.bookings (protege regras de negócio contra escrita direta)
CREATE OR REPLACE FUNCTION public.enforce_booking_invariants_and_transitions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_actor_role public.app_role;
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Estado inicial válido obrigatório
    IF NEW.status NOT IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO') THEN
      RAISE EXCEPTION 'INVALID_INITIAL_STATUS: Novas reservas devem iniciar como SOLICITADA ou AGUARDANDO_CONFIRMACAO (recebido: %).', NEW.status
        USING ERRCODE = '23514';
    END IF;

    -- Garante coerência com canal caso não especificado
    IF NEW.expires_at IS NULL THEN
      NEW.expires_at := now() + interval '48 hours';
    END IF;

    -- Executa lock pessimista e validação transacional de capacidade (MP-015)
    PERFORM public.check_and_lock_vessel_capacity(
      NEW.vessel_id,
      NEW.tour_id,
      NEW.booking_date,
      NEW.passengers,
      NULL
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    -- Impede adulteração de colunas estruturais, de titularidade e financeiras imutáveis da reserva
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.code IS DISTINCT FROM OLD.code
       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
       OR NEW.tourist_user_id IS DISTINCT FROM OLD.tourist_user_id
       OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
       OR NEW.tour_id IS DISTINCT FROM OLD.tour_id
       OR NEW.vessel_id IS DISTINCT FROM OLD.vessel_id
       OR NEW.channel IS DISTINCT FROM OLD.channel
       OR NEW.pricing_model_snapshot IS DISTINCT FROM OLD.pricing_model_snapshot
       OR NEW.unit_price_snapshot IS DISTINCT FROM OLD.unit_price_snapshot
       OR NEW.commission_rule_id IS DISTINCT FROM OLD.commission_rule_id
       OR NEW.commission_model_snapshot IS DISTINCT FROM OLD.commission_model_snapshot
       OR NEW.commission_rate_snapshot IS DISTINCT FROM OLD.commission_rate_snapshot
       OR NEW.commission_fixed_snapshot IS DISTINCT FROM OLD.commission_fixed_snapshot
       OR NEW.gross_amount IS DISTINCT FROM OLD.gross_amount
       OR NEW.commission_amount IS DISTINCT FROM OLD.commission_amount
       OR NEW.net_partner_amount IS DISTINCT FROM OLD.net_partner_amount THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_FIELDS: Não é permitido alterar dados financeiros, de titularidade ou estruturais de uma reserva existente.'
        USING ERRCODE = '42501';
    END IF;

    -- Resolve o papel do ator no banco antes de permitir qualquer UPDATE na reserva
    v_actor_role := public.resolve_booking_actor_role(OLD.partner_id, OLD.tourist_user_id);
    IF v_actor_role IS NULL THEN
      RAISE EXCEPTION 'UNAUTHORIZED_BOOKING_UPDATE: Usuário sem autorização para atualizar esta reserva.'
        USING ERRCODE = '42501';
    END IF;

    -- Dados do cliente, data e quantidade de passageiros são imutáveis para não-administradores
    IF v_actor_role <> 'admin' AND (
         NEW.customer_name IS DISTINCT FROM OLD.customer_name
         OR NEW.customer_phone IS DISTINCT FROM OLD.customer_phone
         OR NEW.customer_email IS DISTINCT FROM OLD.customer_email
         OR NEW.booking_date IS DISTINCT FROM OLD.booking_date
         OR NEW.passengers IS DISTINCT FROM OLD.passengers
         OR NEW.notes IS DISTINCT FROM OLD.notes
         OR NEW.utm_source IS DISTINCT FROM OLD.utm_source
         OR NEW.utm_medium IS DISTINCT FROM OLD.utm_medium
         OR NEW.utm_campaign IS DISTINCT FROM OLD.utm_campaign
         OR NEW.created_at IS DISTINCT FROM OLD.created_at
    ) THEN
      RAISE EXCEPTION 'BOOKING_IMMUTABLE_CUSTOMER_FIELDS: Não é permitido alterar dados do cliente, data ou passageiros de uma reserva criada.'
        USING ERRCODE = '42501';
    END IF;

    -- Impede atualizações silenciosas sem mudança de status (ex: tentativa de sobrescrever motivo em chamada no-op)
    IF NEW.status IS NOT DISTINCT FROM OLD.status AND v_actor_role <> 'admin' THEN
      RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', OLD.code, OLD.status
        USING ERRCODE = '23514';
    END IF;

    -- Adquire lock transacional canônico (embarcação + data) em qualquer mutação da reserva
    PERFORM pg_advisory_xact_lock(hashtext(OLD.vessel_id::text), hashtext(OLD.booking_date::text));

    -- Se um administrador alterou booking_date ou passengers (apenas antes da finalização), revalida capacidade
    IF (NEW.booking_date IS DISTINCT FROM OLD.booking_date OR NEW.passengers IS DISTINCT FROM OLD.passengers) THEN
      IF OLD.status IN ('PASSEIO_REALIZADO', 'RECUSADA', 'CANCELADA') THEN
        RAISE EXCEPTION 'BOOKING_CLOSED_MODIFICATION: Não é permitido alterar data ou passageiros de uma reserva finalizada (%).', OLD.status
          USING ERRCODE = '23514';
      END IF;
      PERFORM public.check_and_lock_vessel_capacity(
        NEW.vessel_id,
        NEW.tour_id,
        NEW.booking_date,
        NEW.passengers,
        NEW.id
      );
    END IF;

    -- Validação rigorosa de transição de status (MP-014)
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      IF NOT public.is_valid_booking_transition(OLD.status, NEW.status) THEN
        RAISE EXCEPTION 'INVALID_STATUS_TRANSITION: Transição de status proibida de % para %.', OLD.status, NEW.status
          USING ERRCODE = '23514';
      END IF;

      IF NOT public.can_actor_execute_booking_transition(OLD.status, NEW.status, v_actor_role) THEN
        RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Usuário com papel (%) não tem autorização para alterar status de % para %.',
          COALESCE(v_actor_role::text, 'anonymous'), OLD.status, NEW.status
          USING ERRCODE = '42501';
      END IF;

      IF NEW.status IN ('RECUSADA', 'CANCELADA')
         AND char_length(trim(COALESCE(NEW.rejection_or_cancel_reason, ''))) < 3 THEN
        RAISE EXCEPTION 'REASON_REQUIRED: É obrigatório informar o motivo (mínimo 3 caracteres) ao transitar para %.', NEW.status
          USING ERRCODE = '23514';
      END IF;

      -- Ao confirmar ou realizar passeio, revalida lock e capacidade contra overbooking concorrente
      IF NEW.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO') THEN
        PERFORM public.check_and_lock_vessel_capacity(
          NEW.vessel_id,
          NEW.tour_id,
          NEW.booking_date,
          NEW.passengers,
          NEW.id
        );
      END IF;

      -- Atualiza carimbos temporais da etapa
      IF NEW.status = 'CONFIRMADA' AND NEW.confirmed_at IS NULL THEN
        NEW.confirmed_at := now();
      ELSIF NEW.status = 'PASSEIO_REALIZADO' AND NEW.completed_at IS NULL THEN
        NEW.completed_at := now();
      ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') AND NEW.cancelled_at IS NULL THEN
        NEW.cancelled_at := now();
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_before_bookings_invariants ON public.bookings;
CREATE TRIGGER trg_before_bookings_invariants
  BEFORE INSERT OR UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.enforce_booking_invariants_and_transitions();

-- Trigger AFTER INSERT OR UPDATE em public.bookings:
-- Registra histórico (booking_status_history), sincroniza livro-razão (commission_ledger) e grava audit_logs
CREATE OR REPLACE FUNCTION public.sync_booking_history_ledger_and_audit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_uid UUID;
  v_actor_role public.app_role;
  v_next_ledger_status public.ledger_status_type;
BEGIN
  v_uid := (SELECT auth.uid());
  v_actor_role := public.resolve_booking_actor_role(NEW.partner_id, NEW.tourist_user_id);

  IF TG_OP = 'INSERT' THEN
    -- 1. Histórico inicial de status
    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      NULL,
      NEW.status,
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      COALESCE(NEW.notes, 'Solicitação inicial de reserva criada')
    );

    -- 2. Registro inicial no livro-razão de comissões (sempre PREVISTA na criação)
    INSERT INTO public.commission_ledger (
      booking_id,
      partner_id,
      tour_id,
      ledger_status,
      gross_amount,
      commission_amount,
      net_partner_amount,
      rule_snapshot_json
    ) VALUES (
      NEW.id,
      NEW.partner_id,
      NEW.tour_id,
      'PREVISTA',
      NEW.gross_amount,
      NEW.commission_amount,
      NEW.net_partner_amount,
      jsonb_build_object(
        'commission_rule_id', NEW.commission_rule_id,
        'commission_model', NEW.commission_model_snapshot,
        'commission_rate', NEW.commission_rate_snapshot,
        'commission_fixed', NEW.commission_fixed_snapshot,
        'commission_rule_label', NEW.commission_rule_label
      )
    )
    ON CONFLICT (booking_id) DO NOTHING;

    -- 3. Log de auditoria
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      COALESCE(v_actor_role, 'tourist'),
      'bookings',
      NEW.code,
      'CREATE_BOOKING',
      NULL,
      to_jsonb(NEW)
    );

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    -- 1. Histórico da transição
    INSERT INTO public.booking_status_history (
      booking_id,
      previous_status,
      new_status,
      changed_by,
      changed_by_role,
      reason
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      v_uid,
      v_actor_role,
      COALESCE(NEW.rejection_or_cancel_reason, 'Transição de status validada pelo servidor')
    );

    -- 2. Sincronização determinística do commission_ledger
    IF NEW.status = 'PASSEIO_REALIZADO' THEN
      v_next_ledger_status := 'CONFIRMADA';
    ELSIF NEW.status IN ('CANCELADA', 'RECUSADA') THEN
      v_next_ledger_status := 'REVERTIDA';
    ELSIF NEW.status = 'EM_DISPUTA' THEN
      v_next_ledger_status := 'EM_DISPUTA';
    ELSE
      v_next_ledger_status := 'PREVISTA';
    END IF;

    UPDATE public.commission_ledger
    SET ledger_status = CASE
          WHEN ledger_status = 'PAGA' AND v_next_ledger_status = 'CONFIRMADA' THEN 'PAGA'::public.ledger_status_type
          ELSE v_next_ledger_status
        END,
        consolidated_at = CASE
          WHEN NEW.status = 'PASSEIO_REALIZADO' THEN COALESCE(consolidated_at, now())
          ELSE consolidated_at
        END,
        reversed_at = CASE
          WHEN NEW.status IN ('CANCELADA', 'RECUSADA') THEN COALESCE(reversed_at, now())
          ELSE reversed_at
        END,
        adjustment_notes = COALESCE(NEW.rejection_or_cancel_reason, adjustment_notes),
        updated_by = v_uid,
        updated_at = now()
    WHERE booking_id = NEW.id;


    -- 3. Log de auditoria da transição
    INSERT INTO public.audit_logs (
      actor_user_id,
      actor_role,
      table_name,
      record_id,
      action,
      old_data,
      new_data
    ) VALUES (
      v_uid,
      v_actor_role,
      'bookings',
      NEW.code,
      'STATUS_TRANSITION',
      jsonb_build_object('status', OLD.status),
      jsonb_build_object(
        'status', NEW.status,
        'reason', NEW.rejection_or_cancel_reason,
        'ledger_status', v_next_ledger_status
      )
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_after_bookings_sync ON public.bookings;
CREATE TRIGGER trg_after_bookings_sync
  AFTER INSERT OR UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.sync_booking_history_ledger_and_audit();

-- MP-009: Impede adulteração financeira direta e garante que commission_ledger reflita deterministicamente o estado real de public.bookings (sem confiar em variáveis GUC de sessão)
CREATE OR REPLACE FUNCTION public.enforce_commission_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_booking RECORD;
  v_expected_ledger_status public.ledger_status_type;
BEGIN
  SELECT id, partner_id, tour_id, status, gross_amount, commission_amount, net_partner_amount
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'LEDGER_BOOKING_NOT_FOUND: Reserva (%) não encontrada para o livro-razão.', NEW.booking_id
      USING ERRCODE = '23503';
  END IF;

  -- Garante paridade financeira estrita com a reserva original tanto no INSERT quanto no UPDATE
  IF NEW.partner_id IS DISTINCT FROM v_booking.partner_id
     OR NEW.tour_id IS DISTINCT FROM v_booking.tour_id
     OR NEW.gross_amount IS DISTINCT FROM v_booking.gross_amount
     OR NEW.commission_amount IS DISTINCT FROM v_booking.commission_amount
     OR NEW.net_partner_amount IS DISTINCT FROM v_booking.net_partner_amount THEN
    RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Os valores financeiros e vínculos do livro-razão devem corresponder exatamente à reserva e são imutáveis.'
      USING ERRCODE = '42501';
  END IF;

  v_expected_ledger_status := CASE
    WHEN v_booking.status = 'PASSEIO_REALIZADO' THEN 'CONFIRMADA'::public.ledger_status_type
    WHEN v_booking.status IN ('CANCELADA', 'RECUSADA') THEN 'REVERTIDA'::public.ledger_status_type
    WHEN v_booking.status = 'EM_DISPUTA' THEN 'EM_DISPUTA'::public.ledger_status_type
    ELSE 'PREVISTA'::public.ledger_status_type
  END;

  IF TG_OP = 'INSERT' THEN
    IF pg_trigger_depth() < 2 OR NEW.ledger_status <> 'PREVISTA' THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_INSERT_FORBIDDEN: O registro no livro-razão é criado exclusivamente pela trigger de criação da reserva com status PREVISTA.'
        USING ERRCODE = '42501';
    END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id OR NEW.booking_id IS DISTINCT FROM OLD.booking_id THEN
      RAISE EXCEPTION 'LEDGER_IMMUTABLE_FINANCIALS: Identificadores do livro-razão são imutáveis.'
        USING ERRCODE = '42501';
    END IF;

    -- Caso 1: Liquidação financeira ('CONFIRMADA' -> 'PAGA') exclusiva para Administrador após PASSEIO_REALIZADO
    IF NEW.ledger_status = 'PAGA' AND OLD.ledger_status = 'CONFIRMADA' THEN
      IF v_booking.status IS DISTINCT FROM 'PASSEIO_REALIZADO' THEN
        RAISE EXCEPTION 'LEDGER_CONSOLIDATION_FORBIDDEN: Comissão só pode ser paga quando a reserva estiver em PASSEIO_REALIZADO.'
          USING ERRCODE = '23514';
      END IF;
      IF NOT (public.is_admin() OR (pg_trigger_depth() >= 2 AND NEW.ledger_status = v_expected_ledger_status)) THEN
        RAISE EXCEPTION 'LEDGER_PAYMENT_ADMIN_ONLY: Somente administradores podem liquidar comissão como PAGA.'
          USING ERRCODE = '42501';
      END IF;
      NEW.paid_at := COALESCE(NEW.paid_at, now());
      RETURN NEW;
    END IF;

    -- Caso 2: Qualquer outra transição de ledger_status deve vir obrigatoriamente da trigger de bookings (pg_trigger_depth() >= 2)
    --         E bater exatamente com v_expected_ledger_status derivado do estado atual de public.bookings!
    IF pg_trigger_depth() < 2 OR NEW.ledger_status IS DISTINCT FROM v_expected_ledger_status THEN
      RAISE EXCEPTION 'LEDGER_DIRECT_STATUS_FORBIDDEN: O status do livro-razão (%) não pode divergir do estado da reserva (%) nem ser alterado fora da máquina de estados.',
        NEW.ledger_status, v_booking.status
        USING ERRCODE = '42501';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_commission_ledger_integrity ON public.commission_ledger;
CREATE TRIGGER trg_enforce_commission_ledger_integrity
  BEFORE INSERT OR UPDATE ON public.commission_ledger
  FOR EACH ROW EXECUTE FUNCTION public.enforce_commission_ledger_integrity();

-- ----------------------------------------------------------------------------
-- 7. VALIDAÇÃO DE AVALIAÇÕES VERIFICADAS E RECÁLCULO DE MÉDIAS (MP-010)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.validate_verified_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_booking RECORD;
BEGIN
  SELECT id, status, tour_id, partner_id, tourist_user_id, customer_name
    INTO v_booking
  FROM public.bookings
  WHERE id = NEW.booking_id;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: Reserva informada para avaliação não existe.'
      USING ERRCODE = '23503';
  END IF;

  IF v_booking.status <> 'PASSEIO_REALIZADO' THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_COMPLETED: Somente reservas com status PASSEIO_REALIZADO podem ser avaliadas (status atual: %).',
      v_booking.status
      USING ERRCODE = '23514';
  END IF;

  IF NEW.tour_id IS DISTINCT FROM v_booking.tour_id OR NEW.partner_id IS DISTINCT FROM v_booking.partner_id THEN
    RAISE EXCEPTION 'REVIEW_ENTITY_MISMATCH: O passeio ou parceiro da avaliação não corresponde à reserva original.'
      USING ERRCODE = '23514';
  END IF;

  -- Verifica titularidade: se a reserva possui tourist_user_id ou se há usuário autenticado,
  -- impede que outro turista avalie reserva de terceiros
  IF v_booking.tourist_user_id IS NOT NULL THEN
    IF NEW.tourist_user_id IS DISTINCT FROM v_booking.tourist_user_id THEN
      RAISE EXCEPTION 'REVIEW_OWNERSHIP_MISMATCH: O autor da avaliação não corresponde ao turista titular da reserva.'
        USING ERRCODE = '42501';
    END IF;
    IF (SELECT auth.uid()) IS NOT NULL AND (SELECT auth.uid()) IS DISTINCT FROM v_booking.tourist_user_id AND NOT public.is_admin() THEN
      RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Você só pode avaliar reservas pertencentes ao seu próprio perfil.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  IF char_length(trim(COALESCE(NEW.comment, ''))) < 5 THEN
    RAISE EXCEPTION 'REVIEW_COMMENT_TOO_SHORT: O comentário da avaliação deve ter ao menos 5 caracteres.'
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_verified_review ON public.reviews;
CREATE TRIGGER trg_validate_verified_review
  BEFORE INSERT OR UPDATE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.validate_verified_review();

CREATE OR REPLACE FUNCTION public.recalculate_ratings_after_review()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_tour_id UUID := COALESCE(NEW.tour_id, OLD.tour_id);
  v_partner_id UUID := COALESCE(NEW.partner_id, OLD.partner_id);
BEGIN
  UPDATE public.tours
  SET rating_avg = COALESCE((
        SELECT ROUND(AVG(rating)::numeric, 2)
        FROM public.reviews
        WHERE tour_id = v_tour_id AND is_published = true
      ), 5.00),
      reviews_count = (
        SELECT COUNT(*)::integer
        FROM public.reviews
        WHERE tour_id = v_tour_id AND is_published = true
      )
  WHERE id = v_tour_id;

  UPDATE public.partners
  SET rating_avg = COALESCE((
        SELECT ROUND(AVG(rating)::numeric, 2)
        FROM public.reviews
        WHERE partner_id = v_partner_id AND is_published = true
      ), 5.00),
      reviews_count = (
        SELECT COUNT(*)::integer
        FROM public.reviews
        WHERE partner_id = v_partner_id AND is_published = true
      )
  WHERE id = v_partner_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_recalculate_ratings_after_review ON public.reviews;
CREATE TRIGGER trg_recalculate_ratings_after_review
  AFTER INSERT OR UPDATE OR DELETE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.recalculate_ratings_after_review();

-- ----------------------------------------------------------------------------
-- 8. IMPLEMENTAÇÃO DAS RPCS TRANSACIONAIS (MP-002, MP-011, MP-014, MP-015, MP-024)
-- ----------------------------------------------------------------------------

-- Resolve um passeio tanto por UUID quanto por slug
CREATE OR REPLACE FUNCTION public.resolve_tour_id(p_tour_identifier TEXT)
RETURNS UUID
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_clean TEXT := trim(COALESCE(p_tour_identifier, ''));
  v_tour_id UUID;
BEGIN
  IF v_clean = '' THEN
    RETURN NULL;
  END IF;

  SELECT t.id INTO v_tour_id
  FROM public.tours t
  WHERE t.id::text = v_clean
     OR t.slug = v_clean
  LIMIT 1;

  RETURN v_tour_id;
END;
$$;

-- Cálculo financeiro determinístico de comissão no servidor
CREATE OR REPLACE FUNCTION public.calculate_booking_financials(
  p_tour_id UUID,
  p_passengers SMALLINT
)
RETURNS TABLE (
  pricing_model public.pricing_model_type,
  unit_price NUMERIC(12,2),
  gross_amount NUMERIC(12,2),
  commission_rule_id UUID,
  commission_model public.commission_model_type,
  commission_rate NUMERIC(5,2),
  commission_fixed NUMERIC(12,2),
  commission_rule_label TEXT,
  commission_amount NUMERIC(12,2),
  net_partner_amount NUMERIC(12,2)
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_tour RECORD;
  v_rule RECORD;
  v_gross NUMERIC(12,2);
  v_comm NUMERIC(12,2);
  v_net NUMERIC(12,2);
  v_model public.commission_model_type;
  v_rate NUMERIC(5,2);
  v_fixed NUMERIC(12,2);
  v_label TEXT;
  v_rule_id UUID := NULL;
BEGIN
  SELECT id, partner_id, pricing_model, price
    INTO v_tour
  FROM public.tours
  WHERE id = p_tour_id;

  IF v_tour.id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado para cálculo financeiro.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: Número de passageiros deve ser positivo.'
      USING ERRCODE = '23514';
  END IF;

  v_gross := ROUND(
    CASE
      WHEN v_tour.pricing_model = 'POR_PESSOA' THEN v_tour.price * p_passengers
      ELSE v_tour.price
    END,
    2
  );

  -- Busca regra ativa prioritária: 1º TOUR_OVERRIDE, 2º PARTNER_DEFAULT
  SELECT r.id, r.scope_type, r.commission_model, r.commission_rate_percent, r.commission_fixed_amount
    INTO v_rule
  FROM public.commission_rules r
  WHERE r.is_active = true
    AND r.effective_from <= now()
    AND (r.effective_until IS NULL OR r.effective_until > now())
    AND (
      (r.scope_type = 'TOUR_OVERRIDE' AND r.tour_id = v_tour.id)
      OR (r.scope_type = 'PARTNER_DEFAULT' AND r.partner_id = v_tour.partner_id)
    )
  ORDER BY CASE WHEN r.scope_type = 'TOUR_OVERRIDE' THEN 1 ELSE 2 END
  LIMIT 1;

  IF v_rule.id IS NOT NULL THEN
    v_rule_id := v_rule.id;
    v_model := v_rule.commission_model;
    v_rate := v_rule.commission_rate_percent;
    v_fixed := v_rule.commission_fixed_amount;
  ELSE
    -- Fallback padrão da plataforma (15% percentual)
    v_rule_id := NULL;
    v_model := 'PERCENTAGE';
    v_rate := 15.00;
    v_fixed := 0.00;
  END IF;

  CASE v_model
    WHEN 'PERCENTAGE' THEN
      v_comm := LEAST(v_gross, ROUND((v_gross * v_rate) / 100.0, 2));
      v_label := format('Percentual Padrão Parceiro (%s%%)', trim(to_char(v_rate, 'FM999990.##')));
    WHEN 'FIXED_PER_PASSENGER' THEN
      v_comm := LEAST(v_gross, ROUND(v_fixed * p_passengers, 2));
      v_label := format('Comissão Fixa por Passageiro (R$ %s/pax)', trim(to_char(v_fixed, 'FM999990.00')));
    WHEN 'FIXED_PER_BOOKING' THEN
      v_comm := LEAST(v_gross, ROUND(v_fixed, 2));
      v_label := format('Taxa Fixa por Charter (R$ %s)', trim(to_char(v_fixed, 'FM999990.00')));
    WHEN 'HYBRID_PERCENT_PLUS_FIXED' THEN
      v_comm := LEAST(v_gross, ROUND(((v_gross * v_rate) / 100.0) + v_fixed, 2));
      v_label := format('Regra Personalizada (%s%% + Taxa R$ %s)',
        trim(to_char(v_rate, 'FM999990.##')),
        trim(to_char(v_fixed, 'FM999990.##'))
      );
  END CASE;

  v_net := ROUND(GREATEST(0.00, v_gross - v_comm), 2);

  RETURN QUERY SELECT
    v_tour.pricing_model,
    v_tour.price,
    v_gross,
    v_rule_id,
    v_model,
    v_rate,
    v_fixed,
    v_label,
    v_comm,
    v_net;
END;
$$;

-- RPC 1: get_tour_availability — Consulta disponibilidade real no banco
CREATE OR REPLACE FUNCTION public.get_tour_availability(
  p_tour_id TEXT,
  p_booking_date DATE
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_block RECORD;
  v_effective_capacity INTEGER;
  v_occupied_seats INTEGER := 0;
  v_active_count INTEGER := 0;
  v_active_private INTEGER := 0;
  v_blocked BOOLEAN := false;
  v_block_reason TEXT := '';
  v_remaining INTEGER := 0;
BEGIN
  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, vessel_id, partner_id, tour_type, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id;

  v_effective_capacity := LEAST(v_tour.capacity::integer, v_vessel.capacity::integer);

  IF v_tour.status <> 'APROVADO' OR v_vessel.status <> 'APROVADO' OR v_vessel.is_active = false THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'blocked', true,
      'block_reason', 'Passeio ou embarcação indisponível para reservas',
      'effective_capacity', v_effective_capacity,
      'occupied_seats', 0,
      'remaining_seats', 0
    );
  END IF;

  FOR v_block IN
    SELECT block_type, custom_capacity_override, COALESCE(reason, 'Bloqueio operacional') AS reason
    FROM public.availability_blocks
    WHERE vessel_id = v_vessel.id
      AND block_date = p_booking_date
      AND (tour_id IS NULL OR tour_id = v_tour.id)
    ORDER BY CASE WHEN block_type = 'AJUSTE_CAPACIDADE' THEN 2 ELSE 1 END
  LOOP
    IF v_block.block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA') THEN
      v_blocked := true;
      v_block_reason := v_block.block_type || ': ' || v_block.reason;
      EXIT;
    ELSIF v_block.block_type = 'AJUSTE_CAPACIDADE' AND v_block.custom_capacity_override IS NOT NULL THEN
      v_effective_capacity := LEAST(v_effective_capacity, v_block.custom_capacity_override::integer);
    END IF;
  END LOOP;

  IF v_blocked THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'blocked', true,
      'block_reason', v_block_reason,
      'effective_capacity', v_effective_capacity,
      'occupied_seats', 0,
      'remaining_seats', 0
    );
  END IF;

  SELECT
    COALESCE(SUM(b.passengers), 0)::integer,
    COUNT(*)::integer,
    COALESCE(SUM(CASE WHEN t.tour_type = 'Privativo' OR b.pricing_model_snapshot = 'POR_EMBARCACAO' THEN 1 ELSE 0 END), 0)::integer
  INTO v_occupied_seats, v_active_count, v_active_private
  FROM public.bookings b
  JOIN public.tours t ON t.id = b.tour_id
  WHERE b.vessel_id = v_vessel.id
    AND b.booking_date = p_booking_date
    AND b.status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO', 'CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    AND (
      b.expires_at IS NULL
      OR b.expires_at > now()
      OR b.status IN ('CONFIRMADA', 'PASSEIO_REALIZADO', 'EM_DISPUTA')
    );

  IF v_active_private > 0 OR (v_tour.tour_type = 'Privativo' AND v_active_count > 0) THEN
    RETURN jsonb_build_object(
      'tour_id', v_tour.id,
      'vessel_id', v_vessel.id,
      'booking_date', p_booking_date,
      'blocked', true,
      'block_reason', 'Embarcação já reservada nesta data',
      'effective_capacity', v_effective_capacity,
      'occupied_seats', v_effective_capacity,
      'remaining_seats', 0
    );
  END IF;

  v_remaining := GREATEST(0, v_effective_capacity - v_occupied_seats);

  RETURN jsonb_build_object(
    'tour_id', v_tour.id,
    'vessel_id', v_vessel.id,
    'booking_date', p_booking_date,
    'blocked', (v_remaining = 0),
    'block_reason', CASE WHEN v_remaining = 0 THEN 'Lotação máxima atingida nesta data' ELSE '' END,
    'effective_capacity', v_effective_capacity,
    'occupied_seats', v_occupied_seats,
    'remaining_seats', v_remaining
  );
END;
$$;

-- RPC 2: create_booking_request (MP-002, MP-011, MP-015)
-- Implementa a RPC chamada pelo frontend e pela Edge Function whatsapp-lead-tracker
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_tour_id TEXT,
  p_booking_date DATE,
  p_passengers SMALLINT,
  p_channel TEXT,
  p_customer_name TEXT,
  p_customer_phone TEXT,
  p_customer_email TEXT,
  p_utm_source TEXT DEFAULT 'direct_organic',
  p_utm_medium TEXT DEFAULT NULL,
  p_utm_campaign TEXT DEFAULT 'marketplace_ubatuba_2026',
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_resolved_tour_id UUID;
  v_tour RECORD;
  v_vessel RECORD;
  v_partner RECORD;
  v_fin RECORD;
  v_existing RECORD;
  v_clean_name TEXT;
  v_clean_phone TEXT;
  v_phone_digits TEXT;
  v_clean_email TEXT;
  v_clean_channel TEXT;
  v_computed_idem_key VARCHAR(64);
  v_initial_status public.booking_status_type;
  v_unique_code VARCHAR(16);
  v_attempt INTEGER := 0;
  v_inserted public.bookings;
  v_uid UUID;
BEGIN
  v_clean_name := trim(COALESCE(p_customer_name, ''));
  v_clean_phone := trim(COALESCE(p_customer_phone, ''));
  v_phone_digits := regexp_replace(v_clean_phone, '[^0-9]', '', 'g');
  v_clean_email := lower(trim(COALESCE(p_customer_email, '')));
  v_clean_channel := upper(trim(COALESCE(p_channel, '')));

  -- 1. Validações de contrato de entrada
  IF char_length(v_clean_name) < 3 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_NAME: Informe o nome completo (mínimo 3 caracteres).'
      USING ERRCODE = '23514';
  END IF;

  IF char_length(v_phone_digits) < 10 OR char_length(v_phone_digits) > 15 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_PHONE: Informe um telefone/WhatsApp válido com DDD (10 a 15 dígitos).'
      USING ERRCODE = '23514';
  END IF;

  IF position('@' in v_clean_email) <= 1 OR char_length(v_clean_email) < 5 THEN
    RAISE EXCEPTION 'INVALID_CUSTOMER_EMAIL: Informe um endereço de e-mail válido.'
      USING ERRCODE = '23514';
  END IF;

  IF v_clean_channel NOT IN ('WHATSAPP', 'SITE_DIRECT') THEN
    RAISE EXCEPTION 'INVALID_BOOKING_CHANNEL: Canal inválido (%). Utilize WHATSAPP ou SITE_DIRECT.', v_clean_channel
      USING ERRCODE = '23514';
  END IF;

  IF p_booking_date IS NULL OR p_booking_date < DATE '2026-11-08' THEN
    RAISE EXCEPTION 'INVALID_BOOKING_DATE: A data do passeio deve ser igual ou posterior a 2026-11-08.'
      USING ERRCODE = '23514';
  END IF;

  IF p_passengers IS NULL OR p_passengers <= 0 THEN
    RAISE EXCEPTION 'INVALID_PASSENGERS: A quantidade de passageiros deve ser maior que zero.'
      USING ERRCODE = '23514';
  END IF;

  v_resolved_tour_id := public.resolve_tour_id(p_tour_id);
  IF v_resolved_tour_id IS NULL THEN
    RAISE EXCEPTION 'TOUR_NOT_FOUND: Passeio (%) não encontrado.', p_tour_id
      USING ERRCODE = 'P0002';
  END IF;

  SELECT id, title, partner_id, vessel_id, pricing_model, price, capacity, status
    INTO v_tour
  FROM public.tours
  WHERE id = v_resolved_tour_id;

  SELECT id, name, capacity, status, is_active
    INTO v_vessel
  FROM public.vessels
  WHERE id = v_tour.vessel_id;

  SELECT id, name, whatsapp, status
    INTO v_partner
  FROM public.partners
  WHERE id = v_tour.partner_id;

  -- 2. Chave de idempotência determinística caso não tenha sido enviada (usa md5/gen_random_uuid nativos de pg_catalog sem depender do schema de pgcrypto)
  v_computed_idem_key := left(
    COALESCE(
      NULLIF(trim(p_idempotency_key), ''),
      md5(v_tour.id::text || ':' || p_booking_date::text || ':' || v_phone_digits)
      || md5(v_phone_digits || ':' || v_tour.id::text)
    ),
    64
  );

  -- Lock transacional ao nível da embarcação e data antes da checagem de idempotência e capacidade
  PERFORM pg_advisory_xact_lock(hashtext(v_vessel.id::text), hashtext(p_booking_date::text));

  v_uid := (SELECT auth.uid());
  IF v_uid IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = v_uid AND is_active = true) THEN
    v_uid := NULL;
  END IF;

  -- 3. Verifica repetição idempotente por idempotency_key ou reserva ativa do mesmo cliente/passeio/data
  SELECT b.*
    INTO v_existing
  FROM public.bookings b
  WHERE b.idempotency_key = v_computed_idem_key
     OR (
       b.tour_id = v_tour.id
       AND b.booking_date = p_booking_date
       AND regexp_replace(b.customer_phone, '[^0-9]', '', 'g') = v_phone_digits
       AND b.status NOT IN ('CANCELADA', 'RECUSADA')
     )
  ORDER BY b.created_at DESC
  LIMIT 1;

  -- Proteção contra vazamento de PII por colisão/força bruta de idempotency_key entre clientes distintos
  IF v_existing.id IS NOT NULL THEN
    IF (v_existing.tourist_user_id IS NOT NULL AND v_uid IS DISTINCT FROM v_existing.tourist_user_id AND NOT public.is_admin())
       OR regexp_replace(v_existing.customer_phone, '[^0-9]', '', 'g') <> v_phone_digits
       OR lower(trim(v_existing.customer_email)) <> v_clean_email THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_CONFLICT: Já existe uma solicitação ativa conflitante ou a chave de idempotência pertence a outro titular.'
        USING ERRCODE = '23505';
    END IF;
  END IF;

  IF v_existing.id IS NOT NULL AND v_existing.status NOT IN ('CANCELADA', 'RECUSADA') THEN
    RETURN jsonb_build_object(
      'id', v_existing.id,
      'booking_id', v_existing.id,
      'code', v_existing.code,
      'booking_code', v_existing.code,
      'idempotency_key', v_existing.idempotency_key,
      'idempotent_replay', true,
      'status', v_existing.status,
      'ledger_status', COALESCE((SELECT cl.ledger_status FROM public.commission_ledger cl WHERE cl.booking_id = v_existing.id), 'PREVISTA'),
      'tour_id', v_existing.tour_id,
      'tour_title', v_tour.title,
      'vessel_id', v_existing.vessel_id,
      'vessel_name', v_vessel.name,
      'partner_id', v_existing.partner_id,
      'partner_name', v_partner.name,
      'partner_whatsapp', v_partner.whatsapp,
      'customer_name', v_existing.customer_name,
      'customer_phone', v_existing.customer_phone,
      'customer_email', v_existing.customer_email,
      'booking_date', v_existing.booking_date,
      'passengers', v_existing.passengers,
      'channel', v_existing.channel,
      'utm_source', v_existing.utm_source,
      'utm_medium', v_existing.utm_medium,
      'utm_campaign', v_existing.utm_campaign,
      'pricing_model_snapshot', v_existing.pricing_model_snapshot,
      'unit_price_snapshot', v_existing.unit_price_snapshot,
      'gross_amount', v_existing.gross_amount,
      'commission_model_snapshot', v_existing.commission_model_snapshot,
      'commission_rate_snapshot', v_existing.commission_rate_snapshot,
      'commission_fixed_snapshot', v_existing.commission_fixed_snapshot,
      'commission_rule_label', v_existing.commission_rule_label,
      'commission_amount', v_existing.commission_amount,
      'net_partner_amount', v_existing.net_partner_amount,
      'commission_consolidated', (v_existing.status = 'PASSEIO_REALIZADO'),
      'notes', v_existing.notes,
      'expires_at', v_existing.expires_at,
      'created_at', v_existing.created_at
    );
  END IF;

  -- Se existia uma reserva anterior CANCELADA/RECUSADA com a mesma chave de idempotência, gera sufixo único
  IF v_existing.id IS NOT NULL AND v_existing.idempotency_key = v_computed_idem_key THEN
    v_computed_idem_key := left(md5(v_computed_idem_key || ':' || clock_timestamp()::text) || md5(gen_random_uuid()::text), 64);
  END IF;

  -- 4. Cálculo financeiro no servidor
  SELECT * INTO v_fin
  FROM public.calculate_booking_financials(v_tour.id, p_passengers);

  -- 5. Define estado inicial conforme contrato único MP-011
  v_initial_status := CASE
    WHEN v_clean_channel = 'WHATSAPP' THEN 'SOLICITADA'::public.booking_status_type
    ELSE 'AGUARDANDO_CONFIRMACAO'::public.booking_status_type
  END;

  -- 6. Gera código único UBT-XXXX
  LOOP
    v_attempt := v_attempt + 1;
    v_unique_code := 'UBT-' || lpad((floor(1000 + random() * 9000))::int::text, 4, '0');
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.bookings WHERE code = v_unique_code);
    IF v_attempt > 50 THEN
      v_unique_code := 'UBT-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
      EXIT;
    END IF;
  END LOOP;



  -- 7. Insere a reserva (a trigger BEFORE INSERT valida lock e capacidade atômica MP-015,
  --    e a trigger AFTER INSERT cria booking_status_history, commission_ledger e audit_logs)
  INSERT INTO public.bookings (
    code,
    idempotency_key,
    tourist_user_id,
    partner_id,
    tour_id,
    vessel_id,
    customer_name,
    customer_phone,
    customer_email,
    booking_date,
    passengers,
    channel,
    utm_source,
    utm_medium,
    utm_campaign,
    status,
    pricing_model_snapshot,
    unit_price_snapshot,
    gross_amount,
    commission_rule_id,
    commission_model_snapshot,
    commission_rate_snapshot,
    commission_fixed_snapshot,
    commission_rule_label,
    commission_amount,
    net_partner_amount,
    notes,
    expires_at
  ) VALUES (
    v_unique_code,
    v_computed_idem_key,
    v_uid,
    v_partner.id,
    v_tour.id,
    v_vessel.id,
    v_clean_name,
    v_clean_phone,
    v_clean_email,
    p_booking_date,
    p_passengers,
    v_clean_channel,
    COALESCE(NULLIF(trim(p_utm_source), ''), 'direct_organic'),
    NULLIF(trim(COALESCE(p_utm_medium, '')), ''),
    COALESCE(NULLIF(trim(p_utm_campaign), ''), 'marketplace_ubatuba_2026'),
    v_initial_status,
    v_fin.pricing_model,
    v_fin.unit_price,
    v_fin.gross_amount,
    v_fin.commission_rule_id,
    v_fin.commission_model,
    v_fin.commission_rate,
    v_fin.commission_fixed,
    v_fin.commission_rule_label,
    v_fin.commission_amount,
    v_fin.net_partner_amount,
    COALESCE(
      NULLIF(trim(COALESCE(p_notes, '')), ''),
      CASE
        WHEN v_clean_channel = 'WHATSAPP'
          THEN format('Lead rastreado enviado ao WhatsApp oficial de %s (%s).', v_partner.name, v_partner.whatsapp)
        ELSE 'Solicitação registrada no site; aguardando confirmação de disponibilidade pelo parceiro.'
      END
    ),
    now() + interval '48 hours'
  )
  RETURNING * INTO v_inserted;

  RETURN jsonb_build_object(
    'id', v_inserted.id,
    'booking_id', v_inserted.id,
    'code', v_inserted.code,
    'booking_code', v_inserted.code,
    'idempotency_key', v_inserted.idempotency_key,
    'idempotent_replay', false,
    'status', v_inserted.status,
    'ledger_status', 'PREVISTA',
    'tour_id', v_inserted.tour_id,
    'tour_title', v_tour.title,
    'vessel_id', v_inserted.vessel_id,
    'vessel_name', v_vessel.name,
    'partner_id', v_inserted.partner_id,
    'partner_name', v_partner.name,
    'partner_whatsapp', v_partner.whatsapp,
    'customer_name', v_inserted.customer_name,
    'customer_phone', v_inserted.customer_phone,
    'customer_email', v_inserted.customer_email,
    'booking_date', v_inserted.booking_date,
    'passengers', v_inserted.passengers,
    'channel', v_inserted.channel,
    'utm_source', v_inserted.utm_source,
    'utm_medium', v_inserted.utm_medium,
    'utm_campaign', v_inserted.utm_campaign,
    'pricing_model_snapshot', v_inserted.pricing_model_snapshot,
    'unit_price_snapshot', v_inserted.unit_price_snapshot,
    'gross_amount', v_inserted.gross_amount,
    'commission_model_snapshot', v_inserted.commission_model_snapshot,
    'commission_rate_snapshot', v_inserted.commission_rate_snapshot,
    'commission_fixed_snapshot', v_inserted.commission_fixed_snapshot,
    'commission_rule_label', v_inserted.commission_rule_label,
    'commission_amount', v_inserted.commission_amount,
    'net_partner_amount', v_inserted.net_partner_amount,
    'commission_consolidated', false,
    'notes', v_inserted.notes,
    'expires_at', v_inserted.expires_at,
    'created_at', v_inserted.created_at
  );
END;
$$;

-- RPC 3: transition_booking_status (MP-011, MP-014, MP-015)
CREATE OR REPLACE FUNCTION public.transition_booking_status(
  p_booking_id TEXT,
  p_new_status public.booking_status_type,
  p_reason TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_target public.bookings;
  v_updated public.bookings;
  v_actor_role public.app_role;
  v_ledger_status public.ledger_status_type;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
BEGIN
  IF v_clean_id = '' THEN
    RAISE EXCEPTION 'BOOKING_ID_REQUIRED: Identificador ou código da reserva é obrigatório.'
      USING ERRCODE = '23514';
  END IF;

  -- 1. Localiza a reserva (sem lock ainda) para adquirir os locks na ordem hierárquica canônica (evita Deadlock AB-BA)
  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_target.id IS NULL THEN
    RAISE EXCEPTION 'BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  -- 2. Valida identidade e autorização do ator ANTES de adquirir locks de escrita ou executar UPDATE
  v_actor_role := public.resolve_booking_actor_role(v_target.partner_id, v_target.tourist_user_id);
  IF v_actor_role IS NULL THEN
    RAISE EXCEPTION 'UNAUTHORIZED_STATUS_TRANSITION: Você não possui permissão sobre a reserva %.', v_target.code
      USING ERRCODE = '42501';
  END IF;

  -- 3. Hierarquia canônica de bloqueio: 1º Advisory Lock (embarcação+data), 2º Embarcação FOR UPDATE, 3º Reserva FOR UPDATE
  PERFORM pg_advisory_xact_lock(hashtext(v_target.vessel_id::text), hashtext(v_target.booking_date::text));
  PERFORM 1 FROM public.vessels WHERE id = v_target.vessel_id FOR UPDATE;

  SELECT *
    INTO v_target
  FROM public.bookings
  WHERE id = v_target.id
  FOR UPDATE;

  IF p_new_status IS NOT DISTINCT FROM v_target.status THEN
    RAISE EXCEPTION 'NOOP_STATUS_TRANSITION: A reserva % já se encontra no status %.', v_target.code, v_target.status
      USING ERRCODE = '23514';
  END IF;

  UPDATE public.bookings
  SET status = p_new_status,
      rejection_or_cancel_reason = COALESCE(NULLIF(trim(COALESCE(p_reason, '')), ''), rejection_or_cancel_reason),
      updated_at = now()
  WHERE id = v_target.id
  RETURNING * INTO v_updated;

  SELECT ledger_status INTO v_ledger_status
  FROM public.commission_ledger
  WHERE booking_id = v_updated.id;

  RETURN jsonb_build_object(
    'id', v_updated.id,
    'booking_id', v_updated.id,
    'code', v_updated.code,
    'booking_code', v_updated.code,
    'previous_status', v_target.status,
    'status', v_updated.status,
    'new_status', v_updated.status,
    'ledger_status', COALESCE(v_ledger_status, 'PREVISTA'),
    'commission_consolidated', (v_updated.status = 'PASSEIO_REALIZADO'),
    'rejection_or_cancel_reason', v_updated.rejection_or_cancel_reason,
    'confirmed_at', v_updated.confirmed_at,
    'completed_at', v_updated.completed_at,
    'cancelled_at', v_updated.cancelled_at,
    'updated_at', v_updated.updated_at
  );
END;
$$;

-- RPC 4: create_verified_review (MP-010)
CREATE OR REPLACE FUNCTION public.create_verified_review(
  p_booking_id TEXT,
  p_rating SMALLINT,
  p_comment TEXT,
  p_author_name TEXT DEFAULT NULL,
  p_author_city TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_booking public.bookings;
  v_review public.reviews;
  v_clean_id TEXT := trim(COALESCE(p_booking_id, ''));
BEGIN
  SELECT * INTO v_booking
  FROM public.bookings
  WHERE id::text = v_clean_id OR code = v_clean_id
  LIMIT 1;

  IF v_booking.id IS NULL THEN
    RAISE EXCEPTION 'REVIEW_BOOKING_NOT_FOUND: Reserva (%) não encontrada.', v_clean_id
      USING ERRCODE = 'P0002';
  END IF;

  IF v_booking.tourist_user_id IS NOT NULL
     AND (SELECT auth.uid()) IS DISTINCT FROM v_booking.tourist_user_id
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'REVIEW_UNAUTHORIZED_ACTOR: Somente o turista titular da reserva (%) pode publicar avaliação.', v_booking.code
      USING ERRCODE = '42501';
  END IF;

  INSERT INTO public.reviews (
    booking_id,
    tour_id,
    partner_id,
    tourist_user_id,
    author_name,
    author_city,
    rating,
    comment,
    is_published
  ) VALUES (
    v_booking.id,
    v_booking.tour_id,
    v_booking.partner_id,
    COALESCE((SELECT auth.uid()), v_booking.tourist_user_id),
    COALESCE(NULLIF(trim(COALESCE(p_author_name, '')), ''), v_booking.customer_name),
    COALESCE(NULLIF(trim(COALESCE(p_author_city, '')), ''), 'Visitante Verificado'),
    p_rating,
    trim(p_comment),
    true
  )
  RETURNING * INTO v_review;

  RETURN jsonb_build_object(
    'id', v_review.id,
    'booking_id', v_review.booking_id,
    'verified_booking_code', v_booking.code,
    'tour_id', v_review.tour_id,
    'partner_id', v_review.partner_id,
    'author_name', v_review.author_name,
    'author_city', v_review.author_city,
    'rating', v_review.rating,
    'comment', v_review.comment,
    'created_at', v_review.created_at
  );
END;
$$;

-- RPC 5: expire_stale_bookings (MP-024)
CREATE OR REPLACE FUNCTION public.expire_stale_bookings()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_rec RECORD;
  v_expired_count INTEGER := 0;
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
BEGIN
  -- Permite apenas service_role, postgres superuser ou administrador autenticado
  IF (v_db_role IN ('anon', 'authenticated') OR v_jwt_role IN ('anon', 'authenticated'))
     AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'UNAUTHORIZED_EXPIRATION_CALL: Apenas service_role ou administrador pode executar a rotina de expiração.'
      USING ERRCODE = '42501';
  END IF;

  -- Itera na ordem determinística (vessel_id, booking_date, id) adquirindo o lock canônico para evitar deadlocks
  FOR v_rec IN
    SELECT id, vessel_id, booking_date
    FROM public.bookings
    WHERE status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO')
      AND expires_at IS NOT NULL
      AND expires_at <= now()
    ORDER BY vessel_id, booking_date, id
  LOOP
    PERFORM pg_advisory_xact_lock(hashtext(v_rec.vessel_id::text), hashtext(v_rec.booking_date::text));
    PERFORM 1 FROM public.vessels WHERE id = v_rec.vessel_id FOR UPDATE;

    UPDATE public.bookings
    SET status = 'CANCELADA',
        rejection_or_cancel_reason = 'Reserva expirada automaticamente por decurso do prazo de confirmação (SLA 48h)',
        cancelled_at = now(),
        updated_at = now()
    WHERE id = v_rec.id
      AND status IN ('SOLICITADA', 'AGUARDANDO_CONFIRMACAO');

    IF FOUND THEN
      v_expired_count := v_expired_count + 1;
    END IF;
  END LOOP;

  RETURN v_expired_count;
END;
$$;

-- ----------------------------------------------------------------------------
-- 9. POLÍTICAS RLS COMPLETAS PARA AS 19 TABELAS E PERMISSÕES DE EXECUÇÃO (MP-007)
-- ----------------------------------------------------------------------------

-- PROFILES
DROP POLICY IF EXISTS "profiles_self_or_admin" ON public.profiles;
CREATE POLICY "profiles_select_self_or_admin" ON public.profiles
  FOR SELECT USING (id = (SELECT auth.uid()) OR public.is_admin());

DROP POLICY IF EXISTS "profiles_update_self_or_admin" ON public.profiles;
CREATE POLICY "profiles_update_self_or_admin" ON public.profiles
  FOR UPDATE
  USING (id = (SELECT auth.uid()) OR public.is_admin())
  WITH CHECK (id = (SELECT auth.uid()) OR public.is_admin());

-- PARTNERS
DROP POLICY IF EXISTS "partners_public_or_member_or_admin" ON public.partners;
CREATE POLICY "partners_select_public_or_member_or_admin" ON public.partners
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(id) OR public.is_admin());

DROP POLICY IF EXISTS "partners_update_member_or_admin" ON public.partners;
CREATE POLICY "partners_update_member_or_admin" ON public.partners
  FOR UPDATE
  USING (public.is_partner_member(id) OR public.is_admin())
  WITH CHECK (public.is_partner_member(id) OR public.is_admin());

DROP POLICY IF EXISTS "partners_insert_admin" ON public.partners;
CREATE POLICY "partners_insert_admin" ON public.partners
  FOR INSERT WITH CHECK (public.is_admin());

-- PARTNER_MEMBERS
DROP POLICY IF EXISTS "partner_members_select_isolated" ON public.partner_members;
CREATE POLICY "partner_members_select_isolated" ON public.partner_members
  FOR SELECT USING (user_id = (SELECT auth.uid()) OR public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "partner_members_write_admin" ON public.partner_members;
CREATE POLICY "partner_members_write_admin" ON public.partner_members
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- DESTINATIONS
DROP POLICY IF EXISTS "destinations_public_read" ON public.destinations;
CREATE POLICY "destinations_public_read" ON public.destinations
  FOR SELECT USING (is_published = true OR public.is_admin());

DROP POLICY IF EXISTS "destinations_admin_write" ON public.destinations;
CREATE POLICY "destinations_admin_write" ON public.destinations
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- VESSELS
DROP POLICY IF EXISTS "vessels_public_or_owner" ON public.vessels;
CREATE POLICY "vessels_public_or_owner" ON public.vessels
  FOR SELECT USING ((status = 'APROVADO' AND is_active = true) OR public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "vessels_partner_write" ON public.vessels;
CREATE POLICY "vessels_partner_insert" ON public.vessels
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "vessels_partner_update" ON public.vessels;
CREATE POLICY "vessels_partner_update" ON public.vessels
  FOR UPDATE
  USING (public.is_partner_member(partner_id) OR public.is_admin())
  WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

-- ITINERARIES, ITINERARY_DESTINATIONS, ITINERARY_VESSELS
DROP POLICY IF EXISTS "itineraries_public_read" ON public.itineraries;
CREATE POLICY "itineraries_public_read" ON public.itineraries
  FOR SELECT USING (is_active = true OR public.is_admin());

DROP POLICY IF EXISTS "itineraries_admin_write" ON public.itineraries;
CREATE POLICY "itineraries_admin_write" ON public.itineraries
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "itinerary_destinations_public_read" ON public.itinerary_destinations;
CREATE POLICY "itinerary_destinations_public_read" ON public.itinerary_destinations
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "itinerary_vessels_public_read" ON public.itinerary_vessels;
CREATE POLICY "itinerary_vessels_public_read" ON public.itinerary_vessels
  FOR SELECT USING (true);

-- TOURS & TOUR_DESTINATIONS
DROP POLICY IF EXISTS "tours_public_or_owner" ON public.tours;
CREATE POLICY "tours_public_or_owner" ON public.tours
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "tours_partner_insert" ON public.tours;
CREATE POLICY "tours_partner_insert" ON public.tours
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "tours_partner_update" ON public.tours;
CREATE POLICY "tours_partner_update" ON public.tours
  FOR UPDATE
  USING (public.is_partner_member(partner_id) OR public.is_admin())
  WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "tour_destinations_public_read" ON public.tour_destinations;
CREATE POLICY "tour_destinations_public_read" ON public.tour_destinations
  FOR SELECT USING (true);

-- MEDIA_ASSETS
DROP POLICY IF EXISTS "media_assets_public_or_owner" ON public.media_assets;
CREATE POLICY "media_assets_public_or_owner" ON public.media_assets
  FOR SELECT USING (authorized = true OR (partner_id IS NOT NULL AND public.is_partner_member(partner_id)) OR public.is_admin());

DROP POLICY IF EXISTS "media_assets_partner_insert" ON public.media_assets;
CREATE POLICY "media_assets_partner_insert" ON public.media_assets
  FOR INSERT WITH CHECK (
    (owner_type = 'PARTNER' AND partner_id IS NOT NULL AND public.is_partner_member(partner_id))
    OR public.is_admin()
  );

-- AVAILABILITY_BLOCKS
DROP POLICY IF EXISTS "availability_blocks_public_read" ON public.availability_blocks;
CREATE POLICY "availability_blocks_public_read" ON public.availability_blocks
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "availability_blocks_partner_write" ON public.availability_blocks;
CREATE POLICY "availability_blocks_partner_write" ON public.availability_blocks
  FOR ALL
  USING (public.is_partner_member(partner_id) OR public.is_admin())
  WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

-- BOOKINGS & BOOKING_STATUS_HISTORY
DROP POLICY IF EXISTS "bookings_isolated_read" ON public.bookings;
CREATE POLICY "bookings_isolated_read" ON public.bookings
  FOR SELECT USING (
    tourist_user_id = (SELECT auth.uid())
    OR public.is_partner_member(partner_id)
    OR public.is_admin()
  );

-- Bloqueia UPDATE/INSERT direto via PostgREST em bookings para usuários comuns/parceiros,
-- exigindo que toda criação e transição de status passe pelas RPCs create_booking_request e transition_booking_status.
DROP POLICY IF EXISTS "bookings_isolated_update" ON public.bookings;
CREATE POLICY "bookings_admin_only_direct_update" ON public.bookings
  FOR UPDATE
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "booking_status_history_isolated_read" ON public.booking_status_history;
CREATE POLICY "booking_status_history_isolated_read" ON public.booking_status_history
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.bookings b
      WHERE b.id = booking_status_history.booking_id
        AND (
          b.tourist_user_id = (SELECT auth.uid())
          OR public.is_partner_member(b.partner_id)
          OR public.is_admin()
        )
    )
  );

-- REVIEWS & PLATFORM_SETTINGS
DROP POLICY IF EXISTS "reviews_public_read" ON public.reviews;
CREATE POLICY "reviews_public_read" ON public.reviews
  FOR SELECT USING (is_published = true OR public.is_partner_member(partner_id) OR public.is_admin());

DROP POLICY IF EXISTS "reviews_tourist_insert" ON public.reviews;
CREATE POLICY "reviews_tourist_insert" ON public.reviews
  FOR INSERT WITH CHECK (
    tourist_user_id = (SELECT auth.uid()) OR public.is_admin()
  );

DROP POLICY IF EXISTS "platform_settings_public_read" ON public.platform_settings;
CREATE POLICY "platform_settings_public_read" ON public.platform_settings
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "platform_settings_admin_write" ON public.platform_settings;
CREATE POLICY "platform_settings_admin_write" ON public.platform_settings
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Políticas complementares de escrita administrativa/parceiro nas tabelas associativas e de mídia
DROP POLICY IF EXISTS "itinerary_destinations_admin_write" ON public.itinerary_destinations;
CREATE POLICY "itinerary_destinations_admin_write" ON public.itinerary_destinations
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "itinerary_vessels_admin_write" ON public.itinerary_vessels;
CREATE POLICY "itinerary_vessels_admin_write" ON public.itinerary_vessels
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "tour_destinations_partner_or_admin_write" ON public.tour_destinations;
CREATE POLICY "tour_destinations_partner_or_admin_write" ON public.tour_destinations
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.tours t
      WHERE t.id = tour_destinations.tour_id
        AND (public.is_partner_member(t.partner_id) OR public.is_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.tours t
      WHERE t.id = tour_destinations.tour_id
        AND (public.is_partner_member(t.partner_id) OR public.is_admin())
    )
  );

DROP POLICY IF EXISTS "media_assets_admin_write" ON public.media_assets;
CREATE POLICY "media_assets_admin_write" ON public.media_assets
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "ledger_admin_update" ON public.commission_ledger;
CREATE POLICY "ledger_admin_update" ON public.commission_ledger
  FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Proteção de colunas administrativas/moderação em partners, vessels, tours e media_assets (VULN-M01.2-05)
CREATE OR REPLACE FUNCTION public.protect_catalog_moderation_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_uid UUID := (SELECT auth.uid());
  v_jwt_role TEXT := COALESCE(NULLIF(current_setting('request.jwt.claim.role', true), ''), ((SELECT auth.jwt()) ->> 'role'), '');
  v_db_role TEXT := COALESCE(NULLIF(current_setting('role', true), ''), 'none');
BEGIN
  -- Permite quando executado por Admin autenticado ou sessão de servidor/seed (service_role / postgres sem papel de cliente)
  IF (v_db_role <> 'anon' AND v_jwt_role <> 'anon' AND public.is_admin())
     OR (v_db_role NOT IN ('anon', 'authenticated') AND v_jwt_role NOT IN ('anon', 'authenticated') AND v_uid IS NULL
         AND v_db_role IN ('none', 'postgres', 'supabase_admin', 'service_role')) THEN
    RETURN NEW;
  END IF;

  -- Permite atualização interna automática de rating_avg/reviews_count disparada por recalculate_ratings_after_review
  IF pg_trigger_depth() >= 2 AND TG_OP = 'UPDATE' AND TG_TABLE_NAME IN ('partners', 'tours') THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'partners' AND TG_OP = 'UPDATE' THEN
    IF NEW.id IS DISTINCT FROM OLD.id
       OR NEW.slug IS DISTINCT FROM OLD.slug
       OR NEW.cnpj IS DISTINCT FROM OLD.cnpj
       OR NEW.status IS DISTINCT FROM OLD.status
       OR NEW.verified IS DISTINCT FROM OLD.verified
       OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
       OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
      RAISE EXCEPTION 'PARTNER_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem auto-aprovar status, selo de verificação, CNPJ ou avaliações.'
        USING ERRCODE = '42501';
    END IF;
  ELSIF TG_TABLE_NAME = 'tours' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status <> 'PENDENTE_APROVACAO' OR NEW.featured = true THEN
        RAISE EXCEPTION 'TOUR_SELF_APPROVAL_FORBIDDEN: Novos passeios criados por parceiros devem iniciar como PENDENTE_APROVACAO e sem destaque.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (NEW.status IS DISTINCT FROM OLD.status AND NEW.status = 'APROVADO')
         OR NEW.featured IS DISTINCT FROM OLD.featured
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg
         OR NEW.reviews_count IS DISTINCT FROM OLD.reviews_count THEN
        RAISE EXCEPTION 'TOUR_MODERATION_COLUMNS_FORBIDDEN: Somente o Admin Master pode aprovar passeios, destacar ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'vessels' THEN
    IF TG_OP = 'INSERT' THEN
      IF NEW.status NOT IN ('PENDENTE_APROVACAO', 'APROVADO') THEN
        RAISE EXCEPTION 'VESSEL_INVALID_INITIAL_STATUS: Status inicial inválido para embarcação.'
          USING ERRCODE = '42501';
      END IF;
    ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.id IS DISTINCT FROM OLD.id
         OR NEW.partner_id IS DISTINCT FROM OLD.partner_id
         OR (OLD.status = 'SUSPENSO' AND NEW.status <> 'SUSPENSO')
         OR NEW.rating_avg IS DISTINCT FROM OLD.rating_avg THEN
        RAISE EXCEPTION 'VESSEL_MODERATION_COLUMNS_FORBIDDEN: Parceiros não podem reativar embarcação suspensa ou alterar avaliações.'
          USING ERRCODE = '42501';
      END IF;
    END IF;
  ELSIF TG_TABLE_NAME = 'media_assets' AND TG_OP = 'INSERT' THEN
    IF NEW.owner_type <> 'PARTNER' OR NEW.authorized = true THEN
      RAISE EXCEPTION 'MEDIA_SELF_AUTHORIZATION_FORBIDDEN: Mídias enviadas por parceiros devem aguardar autorização administrativa.'
        USING ERRCODE = '42501';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_partners_moderation ON public.partners;
CREATE TRIGGER trg_protect_partners_moderation
  BEFORE UPDATE ON public.partners
  FOR EACH ROW EXECUTE FUNCTION public.protect_catalog_moderation_columns();

DROP TRIGGER IF EXISTS trg_protect_tours_moderation ON public.tours;
CREATE TRIGGER trg_protect_tours_moderation
  BEFORE INSERT OR UPDATE ON public.tours
  FOR EACH ROW EXECUTE FUNCTION public.protect_catalog_moderation_columns();

DROP TRIGGER IF EXISTS trg_protect_vessels_moderation ON public.vessels;
CREATE TRIGGER trg_protect_vessels_moderation
  BEFORE INSERT OR UPDATE ON public.vessels
  FOR EACH ROW EXECUTE FUNCTION public.protect_catalog_moderation_columns();

DROP TRIGGER IF EXISTS trg_protect_media_moderation ON public.media_assets;
CREATE TRIGGER trg_protect_media_moderation
  BEFORE INSERT ON public.media_assets
  FOR EACH ROW EXECUTE FUNCTION public.protect_catalog_moderation_columns();

-- Blindagem de ACLs (REVOKE / GRANT) para todas as funções SECURITY DEFINER e tabelas sensíveis (VULN-M01.2-04)
DO $$
BEGIN
  -- 1. Revoga EXECUTE de PUBLIC em funções internas e RPCs restritas
  REVOKE ALL ON FUNCTION public.check_and_lock_vessel_capacity(UUID, UUID, DATE, SMALLINT, UUID) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.calculate_booking_financials(UUID, SMALLINT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.resolve_tour_id(TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.resolve_booking_actor_role(UUID, UUID) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) FROM PUBLIC;
  REVOKE ALL ON FUNCTION public.expire_stale_bookings() FROM PUBLIC;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION public.check_and_lock_vessel_capacity(UUID, UUID, DATE, SMALLINT, UUID) FROM anon;
    REVOKE ALL ON FUNCTION public.calculate_booking_financials(UUID, SMALLINT) FROM anon;
    REVOKE ALL ON FUNCTION public.resolve_tour_id(TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.resolve_booking_actor_role(UUID, UUID) FROM anon;
    REVOKE ALL ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) FROM anon;
    REVOKE ALL ON FUNCTION public.expire_stale_bookings() FROM anon;

    -- Anon pode apenas consultar disponibilidade e solicitar reserva via RPC
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO anon;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon;

    -- Revoga escrita direta em todas as tabelas para anon
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public FROM anon;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    REVOKE ALL ON FUNCTION public.check_and_lock_vessel_capacity(UUID, UUID, DATE, SMALLINT, UUID) FROM authenticated;
    REVOKE ALL ON FUNCTION public.calculate_booking_financials(UUID, SMALLINT) FROM authenticated;
    REVOKE ALL ON FUNCTION public.resolve_tour_id(TEXT) FROM authenticated;
    REVOKE ALL ON FUNCTION public.resolve_booking_actor_role(UUID, UUID) FROM authenticated;
    REVOKE ALL ON FUNCTION public.expire_stale_bookings() FROM authenticated;

    GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO authenticated;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO authenticated;

    -- Revoga escrita direta em tabelas de trilha imutável para authenticated
    REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON public.booking_status_history, public.audit_logs FROM authenticated;
    REVOKE INSERT, DELETE, TRUNCATE ON public.commission_ledger, public.bookings FROM authenticated;
  END IF;

  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    GRANT EXECUTE ON FUNCTION public.is_admin() TO service_role;
    GRANT EXECUTE ON FUNCTION public.is_partner_member(UUID) TO service_role;
    GRANT EXECUTE ON FUNCTION public.check_and_lock_vessel_capacity(UUID, UUID, DATE, SMALLINT, UUID) TO service_role;
    GRANT EXECUTE ON FUNCTION public.calculate_booking_financials(UUID, SMALLINT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.resolve_tour_id(TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.resolve_booking_actor_role(UUID, UUID) TO service_role;
    GRANT EXECUTE ON FUNCTION public.get_tour_availability(TEXT, DATE) TO service_role;
    GRANT EXECUTE ON FUNCTION public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.transition_booking_status(TEXT, public.booking_status_type, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT) TO service_role;
    GRANT EXECUTE ON FUNCTION public.expire_stale_bookings() TO service_role;
  END IF;
END
$$;
-- ============================================================================
-- MIGRATION 0004: SEED OFICIAL IDEMPOTENTE DO CATÁLOGO UBATUBA MAR & PRAIAS (MP-020)
-- Popula parceiros, regras de comissão, embarcações, roteiros, passeios e bloqueios
-- oficiais para garantir integridade referencial das RPCs em banco inicializado.
-- ============================================================================

-- 1. PARCEIROS OFICIAIS
INSERT INTO public.partners (
  id, slug, name, legal_name, cnpj, whatsapp, email, base_marina,
  status, verified, years_operating, bio, avatar_url, rating_avg, reviews_count
) VALUES
  (
    '11111111-1111-4111-8111-111111111101',
    'part-kaimares',
    'Kaimares Náutica & Charter',
    'Kaimares Turismo Náutico Ubatuba Ltda',
    '34.819.201/0001-48',
    '5512997766789',
    'reservas@kaimaresnautica.com.br',
    'Avenida Leovigildo Dias Vieira, Itaguá & Saco da Ribeira',
    'APROVADO',
    true,
    9,
    'Especialistas em lanchas privativas e roteiros compartilhados para a Ilha das Couves, Ilha do Prumirim e Ilha Anchieta com marinheiros habilitados pela Capitania dos Portos.',
    'https://ubatubamarepraias.com.br/media/lancha-kaimares.jpg',
    4.90,
    354
  ),
  (
    '11111111-1111-4111-8111-111111111102',
    'part-rotadomar',
    'Rota do Mar Lanchas',
    'Rota do Mar Operadora Náutica Ltda',
    '29.402.118/0001-90',
    '5512991766084',
    'contato@rotadomarubatuba.com.br',
    'Marina Saco da Ribeira & Píer do Itaguá',
    'APROVADO',
    true,
    12,
    'Frota própria de lanchas cabinadas e open deck de 28 a 38 pés, oferecendo experiências privativas sob medida no litoral norte e sul de Ubatuba.',
    'https://ubatubamarepraias.com.br/media/lancha-rotadomar.jpg',
    5.00,
    418
  ),
  (
    '11111111-1111-4111-8111-111111111103',
    'part-escunascaicara',
    'Escunas Tradicionais Caiçara',
    'Navegação Turística Ilha Anchieta & Norte S/A',
    '18.920.554/0001-12',
    '5512991847933',
    'embarque@escunascaicara.com.br',
    'Píer do Saco da Ribeira e Praia do Itaguá',
    'APROVADO',
    true,
    16,
    'Operadora tradicional de escunas temáticas e familiares com paradas homologadas no Parque Estadual da Ilha Anchieta, Praia das Sete Fontes e Ilha do Prumirim.',
    'https://ubatubamarepraias.com.br/media/escuna-caicara.jpg',
    4.80,
    358
  ),
  (
    '11111111-1111-4111-8111-111111111104',
    'part-nativaeco',
    'Nativa Ecotrilhas & Expedições',
    'Nativa Ecoturismo e Monitoria Ambiental Ltda',
    '41.209.882/0001-05',
    '5512996460990',
    'trilhas@nativaecotrilhas.com.br',
    'Sertão da Quina / Núcleo Picinguaba',
    'PENDENTE',
    true,
    7,
    'Monitores ambientais credenciados pelo Parque Estadual da Serra do Mar para a Trilha da Cachoeira da Água Branca, Sete Praias e Sete Fontes.',
    'https://ubatubamarepraias.com.br/media/nativa-eco.jpg',
    4.90,
    192
  )
ON CONFLICT (slug) DO NOTHING;

-- 2. REGRAS DE COMISSÃO OFICIAIS DOS PARCEIROS
INSERT INTO public.commission_rules (
  id, scope_type, partner_id, tour_id, commission_model,
  commission_rate_percent, commission_fixed_amount, is_active
) VALUES
  (
    '22222222-2222-4222-8222-222222222201',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111101',
    NULL,
    'PERCENTAGE',
    15.00,
    0.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222202',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111102',
    NULL,
    'HYBRID_PERCENT_PLUS_FIXED',
    12.00,
    150.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222203',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111103',
    NULL,
    'FIXED_PER_PASSENGER',
    0.00,
    25.00,
    true
  ),
  (
    '22222222-2222-4222-8222-222222222204',
    'PARTNER_DEFAULT',
    '11111111-1111-4111-8111-111111111104',
    NULL,
    'PERCENTAGE',
    18.00,
    0.00,
    true
  )
ON CONFLICT DO NOTHING;

-- 3. EMBARCAÇÕES OFICIAIS
INSERT INTO public.vessels (
  id, slug, partner_id, name, vessel_type, operation_mode,
  capacity, length_feet, engine_spec, base_location, description,
  features, structure, safety_equipment, hero_image_url, video_title,
  rating_avg, status, is_active
) VALUES
  (
    '33333333-3333-4333-8333-333333333301',
    'ves-phantom-340',
    '11111111-1111-4111-8111-111111111101',
    'Lancha Oceano Azul 340 (34 Pés)',
    'Lancha',
    'Ambos',
    12,
    34,
    '2x Mercury 250HP 4 Tempos',
    'Píer do Itaguá & Saco da Ribeira',
    'Lancha rápida e confortável com solário de proa acolchoado, plataforma de popa estendida com escada submersível, churrasqueira inox, som Bluetooth marinizado e banheiro fechado.',
    ARRAY['Solário de proa duplo', 'Som Bluetooth Premium', 'Churrasqueira a bordo', 'Toldo retrátil amplo', 'Ducha de água doce'],
    ARRAY['Cabine de apoio com banheiro elétrico', 'Cooler térmico de 120L', 'Plataforma de popa revestida em EVA náutico'],
    ARRAY['Coletes salva-vidas homologados Marinha do Brasil', 'Flutuadores espaguete', 'Rádio VHF e GPS Sonar Garmin'],
    'https://ubatubamarepraias.com.br/media/ves-phantom-340.jpg',
    'Tour a Bordo da Lancha Oceano Azul 340 em Navegação',
    4.90,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333302',
    'ves-focker-280',
    '11111111-1111-4111-8111-111111111102',
    'Lancha Brisa do Norte 280 (28 Pés)',
    'Lancha',
    'Privativo',
    9,
    28,
    'Mercruiser 300HP V8',
    'Marina Saco da Ribeira',
    'Embarcação ágil e exclusiva dedicada a passeios privativos para casais, famílias e pequenos grupos.',
    ARRAY['Exclusiva para Charter Privativo', 'Kit Snorkel e Máscaras a bordo', 'Prancha de Stand Up Paddle inclusa'],
    ARRAY['Toalete reservado', 'Mesa de centro em teca', '2 caixas térmicas integradas'],
    ARRAY['Coletes homologados Classe II e III', 'Boia circular com retinida', 'Rádio VHF e Rastreador Satelital'],
    'https://ubatubamarepraias.com.br/media/ves-focker-280.jpg',
    'Experiência Privativa na Lancha Brisa do Norte 28 Pés',
    5.00,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333303',
    'ves-escuna-corsario',
    '11111111-1111-4111-8111-111111111103',
    'Escuna Tradicional Rainha de Anchieta',
    'Escuna',
    'Compartilhado',
    65,
    62,
    'Scania Marítimo 320HP Diesel',
    'Saco da Ribeira & Praia do Itaguá',
    'Escuna clássica de madeira naval certificada, com amplo convés sombreado, bar de bordo, dois banheiros e bote motorizado de apoio.',
    ARRAY['Amplo convés coberto e solário', 'Bar de bordo', 'Bote de apoio motorizado', 'Guia credenciado a bordo'],
    ARRAY['2 Banheiros', 'Bancos anatômicos com encosto', 'Escadas laterais duplas para mergulho'],
    ARRAY['Balsas salva-vidas rígidas', '75 Coletes homologados pela Capitania dos Portos', 'Tripulação completa'],
    'https://ubatubamarepraias.com.br/media/ves-escuna-corsario.jpg',
    'Navegação na Escuna Rainha de Anchieta pela Baía de Ubatuba',
    4.80,
    'APROVADO',
    true
  ),
  (
    '33333333-3333-4333-8333-333333333304',
    'ves-flexboat-nativa',
    '11111111-1111-4111-8111-111111111104',
    'Flexboat Nativa Eco 26 Pés (Apoio Costeiro & Ilhas)',
    'Catamarã / Flexboat',
    'Ambos',
    14,
    26,
    'Yamaha 200HP 4 Tempos Ecológico',
    'Praia de Picinguaba & Sertão da Quina',
    'Embarcação semirrígida de alta estabilidade homologada para travessias rápidas em Picinguaba e Ilha das Couves.',
    ARRAY['Casco semirrígido insubmersível', 'Escada de popa para mergulhadores', 'Toldo de proteção UV'],
    ARRAY['Bancos náuticos anti-impacto', 'Compartimento estanque', 'Caixa térmica 90L'],
    ARRAY['16 Coletes salva-vidas homologados Classe II', 'Rádio VHF Marítimo e GPS'],
    'https://ubatubamarepraias.com.br/media/ves-flexboat-nativa.jpg',
    'Travessia Ecológica Picinguaba — Ilha das Couves no Flexboat Nativa',
    4.90,
    'APROVADO',
    true
  )
ON CONFLICT (slug) DO NOTHING;

-- 4. ROTEIROS OFICIAIS
INSERT INTO public.itineraries (
  id, slug, title, region, estimated_duration, navigation_level,
  description, stops_count, stops_details, navigation_notes, hero_image_url, video_title, is_active
) VALUES
  (
    '44444444-4444-4444-8444-444444444401',
    'itin-ilhas-norte',
    'Roteiro Ilhas do Norte: Couves, Prumirim e Porcos',
    'Costa Norte',
    '5h30 a 6h30',
    'Costeira Moderada',
    'O roteiro mais desejado pelas águas verde-esmeralda do norte de Ubatuba, combinando paradas na Ilha das Couves, Ilha do Prumirim e Ilha dos Porcos.',
    3,
    ARRAY['Parada 1: Ilha das Couves (1h30)', 'Parada 2: Ilha dos Porcos (1h)', 'Parada 3: Ilha do Prumirim (1h30)'],
    'Saídas confirmadas da Praia do Itaguá (check-in 09h00).',
    'https://ubatubamarepraias.com.br/media/itin-norte.jpg',
    'Mapa Animado e Imagens Aéreas do Roteiro Ilhas do Norte',
    true
  ),
  (
    '44444444-4444-4444-8444-444444444402',
    'itin-sul-anchieta',
    'Roteiro Sul Clássico: Ilha Anchieta & Praia das Sete Fontes',
    'Costa Sul & Ilha Anchieta',
    '5h00 a 6h00',
    'Águas Abrigadas (Calmo)',
    'Navegação por águas abrigadas saindo do Saco da Ribeira rumo ao Parque Estadual da Ilha Anchieta e Praia das Sete Fontes.',
    3,
    ARRAY['Parada 1: Praia do Engenho / Aquário Natural', 'Parada 2: Praia do Presídio ou Palmas', 'Parada 3: Praia das Sete Fontes'],
    'Excelente opção para famílias e pessoas sensíveis ao balanço do mar.',
    'https://ubatubamarepraias.com.br/media/itin-sul.jpg',
    'Roteiro Ilha Anchieta e Sete Fontes: Navegação em Águas Abrigadas',
    true
  )
ON CONFLICT (slug) DO NOTHING;

-- 5. PASSEIOS OFICIAIS (SLUGS ALINHADOS AOS IDS DO FRONTEND)
INSERT INTO public.tours (
  id, slug, partner_id, vessel_id, itinerary_id, title, category,
  tour_type, vessel_type, pricing_model, price, capacity, duration_hours,
  check_in_time, departure_time, return_time, departure_point,
  swimming_stops, included_items, important_info, cancellation_policy,
  status, featured, hero_image_url, video_title, rating_avg, reviews_count
) VALUES
  (
    '55555555-5555-4555-8555-555555555501',
    'tour-lancha-norte-comp',
    '11111111-1111-4111-8111-111111111101',
    '33333333-3333-4333-8333-333333333301',
    '44444444-4444-4444-8444-444444444401',
    'Expedição Ilhas Norte de Lancha: Ilha das Couves, Prumirim e Porcos',
    'Passeios de lancha',
    'Compartilhado',
    'Lancha',
    'POR_PESSOA',
    240.00,
    12,
    5.5,
    '09:00:00',
    '09:30:00',
    '15:00:00',
    'Praia do Itaguá',
    '[{"place":"Ilha das Couves","duration":"1h30","description":"Mergulho em águas cristalinas"}]'::jsonb,
    ARRAY['Marinheiro habilitado pela Capitania dos Portos', 'Combustível', 'Máscara de mergulho e flutuadores'],
    ARRAY['Embarque na Avenida Leovigildo Dias Vieira (Praia do Itaguá).'],
    'Reembolso integral ou remarcação sem custos em caso de interdição marítima/mau tempo ou cancelamento até 48h antes.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-couves.jpg',
    'Passeio de Lancha para Ilha das Couves e Ilha do Prumirim',
    4.90,
    214
  ),
  (
    '55555555-5555-4555-8555-555555555502',
    'tour-lancha-privativa-sul',
    '11111111-1111-4111-8111-111111111102',
    '33333333-3333-4333-8333-333333333302',
    '44444444-4444-4444-8444-444444444402',
    'Charter Lancha Privativa (Até 9 Pessoas): Ilha Anchieta, Sete Fontes & Domingas Dias',
    'Passeios privativos',
    'Privativo',
    'Lancha',
    'POR_EMBARCACAO',
    1850.00,
    9,
    6.0,
    '09:30:00',
    '10:00:00',
    '16:00:00',
    'Saco da Ribeira',
    '[{"place":"Praia do Engenho (Ilha Anchieta)","duration":"1h30","description":"Fundeio próximo às tartarugas"}]'::jsonb,
    ARRAY['Lancha exclusiva para até 9 passageiros', 'Comandante particular e combustível incluso'],
    ARRAY['Saída de marina estruturada no Saco da Ribeira.'],
    'Remarcação garantida em caso de chuva contínua ou vento forte. Cancelamento gratuito até 72h antes.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-privativo-sul.jpg',
    'Dia Completo em Lancha Privativa pela Ilha Anchieta e Sete Fontes',
    5.00,
    168
  ),
  (
    '55555555-5555-4555-8555-555555555503',
    'tour-escuna-anchieta',
    '11111111-1111-4111-8111-111111111103',
    '33333333-3333-4333-8333-333333333303',
    '44444444-4444-4444-8444-444444444402',
    'Passeio Tradicional de Escuna: Ilha Anchieta & Praia das Sete Fontes',
    'Passeios de escuna',
    'Compartilhado',
    'Escuna',
    'POR_PESSOA',
    110.00,
    65,
    5.5,
    '09:30:00',
    '10:00:00',
    '15:30:00',
    'Saco da Ribeira',
    '[{"place":"Parque Estadual da Ilha Anchieta","duration":"2h00","description":"Desembarque no píer da Praia do Presídio"}]'::jsonb,
    ARRAY['Navegação em escuna homologada com guia a bordo', 'Bote motorizado de apoio'],
    ARRAY['Ingresso do Parque Estadual da Ilha Anchieta cobrado à parte.'],
    'Cancelamento sem custos até 24h antes da saída.',
    'APROVADO',
    true,
    'https://ubatubamarepraias.com.br/media/tour-escuna.jpg',
    'Passeio de Escuna para Ilha Anchieta e Praia das Sete Fontes',
    4.80,
    312
  ),
  (
    '55555555-5555-4555-8555-555555555504',
    'tour-familia-prumirim',
    '11111111-1111-4111-8111-111111111101',
    '33333333-3333-4333-8333-333333333301',
    '44444444-4444-4444-8444-444444444401',
    'Experiência Família: Ilha do Prumirim, Praia do Félix & Praia do Português',
    'Passeios para famílias',
    'Privativo',
    'Lancha',
    'POR_EMBARCACAO',
    2100.00,
    12,
    6.0,
    '09:00:00',
    '09:30:00',
    '15:30:00',
    'Praia do Itaguá',
    '[{"place":"Praia do Cedro","duration":"1h15","description":"Águas calmas e cristalinas"}]'::jsonb,
    ARRAY['Lancha privativa de 34 pés para até 12 pessoas', 'Coletes infantis homologados'],
    ARRAY['Roteiro desenhado para priorizar enseadas abrigadas.'],
    'Cancelamento gratuito até 48h antes.',
    'APROVADO',
    false,
    'https://ubatubamarepraias.com.br/media/tour-familia.jpg',
    'Roteiro Família em Águas Calmas: Prumirim, Félix e Cedro',
    5.00,
    94
  )
ON CONFLICT (slug) DO NOTHING;

-- 6. BLOQUEIO DE AGENDA INICIAL
INSERT INTO public.availability_blocks (
  id, partner_id, vessel_id, tour_id, block_date, block_type, reason
) VALUES (
  '66666666-6666-4666-8666-666666666601',
  '11111111-1111-4111-8111-111111111101',
  '33333333-3333-4333-8333-333333333301',
  NULL,
  DATE '2026-11-25',
  'MANUTENCAO',
  'Revisão preventiva programada dos motores Mercury 250HP'
)
ON CONFLICT (id) DO NOTHING;
