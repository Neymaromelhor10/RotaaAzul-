-- ============================================================================
-- MIGRATION 0001: ARQUITETURA RELACIONAL COMPLETA (19 TABELAS + ENUMS)
-- Projeto: Ubatuba Mar & Praias Marketplace Multi-Tenant
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE public.app_role AS ENUM ('tourist', 'partner', 'admin');
CREATE TYPE public.partner_status AS ENUM ('PENDENTE', 'APROVADO', 'SUSPENSO');
CREATE TYPE public.moderation_status AS ENUM ('RASCUNHO', 'PENDENTE_APROVACAO', 'APROVADO', 'REPROVADO', 'SUSPENSO');
CREATE TYPE public.pricing_model_type AS ENUM ('POR_PESSOA', 'POR_EMBARCACAO');
CREATE TYPE public.commission_model_type AS ENUM (
  'PERCENTAGE',
  'FIXED_PER_PASSENGER',
  'FIXED_PER_BOOKING',
  'HYBRID_PERCENT_PLUS_FIXED'
);
CREATE TYPE public.booking_status_type AS ENUM (
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
  'RECUSADA',
  'CANCELADA',
  'PASSEIO_REALIZADO',
  'EM_DISPUTA'
);
CREATE TYPE public.ledger_status_type AS ENUM (
  'PREVISTA',
  'CONFIRMADA',
  'PAGA',
  'REVERTIDA',
  'EM_DISPUTA'
);

-- 1. PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL CHECK (char_length(trim(full_name)) >= 2),
  phone VARCHAR(25),
  city TEXT,
  system_role public.app_role NOT NULL DEFAULT 'tourist',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. PARTNERS
CREATE TABLE public.partners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  legal_name TEXT NOT NULL,
  cnpj VARCHAR(18) NOT NULL UNIQUE,
  whatsapp VARCHAR(20) NOT NULL CHECK (whatsapp ~ '^[0-9]{12,15}$'),
  email TEXT NOT NULL,
  base_marina TEXT NOT NULL,
  status public.partner_status NOT NULL DEFAULT 'PENDENTE',
  verified BOOLEAN NOT NULL DEFAULT false,
  years_operating SMALLINT NOT NULL DEFAULT 0 CHECK (years_operating >= 0),
  bio TEXT,
  avatar_url TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00 CHECK (rating_avg BETWEEN 0.00 AND 5.00),
  reviews_count INTEGER NOT NULL DEFAULT 0 CHECK (reviews_count >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. PARTNER_MEMBERS (Multi-Tenant N:N)
CREATE TABLE public.partner_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  member_role TEXT NOT NULL DEFAULT 'owner' CHECK (member_role IN ('owner', 'manager', 'operator')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (partner_id, user_id)
);

-- 4. DESTINATIONS
CREATE TABLE public.destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Praias', 'Ilhas', 'Cachoeiras', 'Trilhas e Aventuras')),
  region TEXT NOT NULL CHECK (region IN ('Norte', 'Centro', 'Sul', 'Sertão / Serra do Mar')),
  short_description TEXT NOT NULL,
  full_description TEXT NOT NULL,
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  map_x SMALLINT NOT NULL CHECK (map_x BETWEEN 0 AND 100),
  map_y SMALLINT NOT NULL CHECK (map_y BETWEEN 0 AND 100),
  how_to_get_there TEXT NOT NULL,
  access_type TEXT NOT NULL CHECK (access_type IN ('Barco / Lancha', 'Trilha', 'Acesso Asfaltado / Carro', 'Barco ou Trilha')),
  characteristics TEXT[] NOT NULL DEFAULT '{}',
  infrastructure TEXT NOT NULL,
  visitor_tips TEXT[] NOT NULL DEFAULT '{}',
  environmental_rules TEXT[] NOT NULL DEFAULT '{}',
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  video_duration VARCHAR(10),
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00 CHECK (rating_avg BETWEEN 0.00 AND 5.00),
  reviews_count INTEGER NOT NULL DEFAULT 0,
  featured BOOLEAN NOT NULL DEFAULT false,
  seo_title TEXT,
  seo_description TEXT,
  source_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. VESSELS
CREATE TABLE public.vessels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  name TEXT NOT NULL,
  vessel_type TEXT NOT NULL CHECK (vessel_type IN ('Lancha', 'Escuna', 'Catamarã / Flexboat')),
  operation_mode TEXT NOT NULL CHECK (operation_mode IN ('Privativo', 'Compartilhado', 'Ambos')),
  capacity SMALLINT NOT NULL CHECK (capacity > 0 AND capacity <= 250),
  length_feet SMALLINT NOT NULL CHECK (length_feet > 0),
  engine_spec TEXT NOT NULL,
  navy_registration_code TEXT,
  base_location TEXT NOT NULL,
  description TEXT NOT NULL,
  features TEXT[] NOT NULL DEFAULT '{}',
  structure TEXT[] NOT NULL DEFAULT '{}',
  safety_equipment TEXT[] NOT NULL DEFAULT '{}',
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00,
  status public.moderation_status NOT NULL DEFAULT 'APROVADO',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. ITINERARIES
CREATE TABLE public.itineraries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  region TEXT NOT NULL,
  estimated_duration TEXT NOT NULL,
  navigation_level TEXT NOT NULL,
  description TEXT NOT NULL,
  stops_count SMALLINT NOT NULL DEFAULT 1 CHECK (stops_count >= 0),
  stops_details TEXT[] NOT NULL DEFAULT '{}',
  navigation_notes TEXT,
  hero_image_url TEXT,
  video_title TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. ITINERARY_DESTINATIONS
CREATE TABLE public.itinerary_destinations (
  itinerary_id UUID NOT NULL REFERENCES public.itineraries(id) ON DELETE CASCADE,
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE RESTRICT,
  stop_order SMALLINT NOT NULL DEFAULT 1,
  PRIMARY KEY (itinerary_id, destination_id),
  UNIQUE (itinerary_id, stop_order)
);

-- 8. ITINERARY_VESSELS
CREATE TABLE public.itinerary_vessels (
  itinerary_id UUID NOT NULL REFERENCES public.itineraries(id) ON DELETE CASCADE,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  confirmed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (itinerary_id, vessel_id)
);

-- 9. TOURS
CREATE TABLE public.tours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  itinerary_id UUID REFERENCES public.itineraries(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  tour_type TEXT NOT NULL CHECK (tour_type IN ('Privativo', 'Compartilhado')),
  vessel_type TEXT NOT NULL CHECK (vessel_type IN ('Lancha', 'Escuna')),
  pricing_model public.pricing_model_type NOT NULL,
  price NUMERIC(12,2) NOT NULL CHECK (price > 0),
  capacity SMALLINT NOT NULL CHECK (capacity > 0),
  duration_hours NUMERIC(4,1) NOT NULL CHECK (duration_hours > 0),
  check_in_time TIME NOT NULL,
  departure_time TIME NOT NULL,
  return_time TIME NOT NULL,
  departure_point TEXT NOT NULL,
  swimming_stops JSONB NOT NULL DEFAULT '[]'::jsonb,
  included_items TEXT[] NOT NULL DEFAULT '{}',
  important_info TEXT[] NOT NULL DEFAULT '{}',
  cancellation_policy TEXT NOT NULL,
  status public.moderation_status NOT NULL DEFAULT 'PENDENTE_APROVACAO',
  featured BOOLEAN NOT NULL DEFAULT false,
  hero_image_url TEXT NOT NULL,
  video_title TEXT,
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 5.00,
  reviews_count INTEGER NOT NULL DEFAULT 0,
  seo_keywords TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Trigger garantindo que a embarcação pertença ao mesmo parceiro do passeio
CREATE OR REPLACE FUNCTION public.validate_tour_vessel_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_vessel_partner UUID;
  v_vessel_cap SMALLINT;
BEGIN
  SELECT partner_id, capacity INTO v_vessel_partner, v_vessel_cap
  FROM public.vessels WHERE id = NEW.vessel_id;

  IF v_vessel_partner IS DISTINCT FROM NEW.partner_id THEN
    RAISE EXCEPTION 'VESSEL_OWNERSHIP_MISMATCH: A embarcação selecionada não pertence ao parceiro do passeio.'
      USING ERRCODE = '23514';
  END IF;

  IF NEW.capacity > v_vessel_cap THEN
    RAISE EXCEPTION 'CAPACITY_EXCEEDS_VESSEL: Capacidade do passeio (%) excede capacidade da embarcação (%).', NEW.capacity, v_vessel_cap
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_tour_vessel_ownership
  BEFORE INSERT OR UPDATE ON public.tours
  FOR EACH ROW EXECUTE FUNCTION public.validate_tour_vessel_ownership();

-- 10. TOUR_DESTINATIONS
CREATE TABLE public.tour_destinations (
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE CASCADE,
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE RESTRICT,
  stop_order SMALLINT NOT NULL DEFAULT 1,
  PRIMARY KEY (tour_id, destination_id)
);

-- 11. MEDIA_ASSETS
CREATE TABLE public.media_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('photo', 'video')),
  storage_bucket TEXT NOT NULL DEFAULT 'public-catalog-media',
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT 'image/jpeg',
  file_size_bytes BIGINT,
  video_duration VARCHAR(10),
  category TEXT NOT NULL CHECK (category IN ('Destino', 'Embarcação', 'Passeio', 'Experiência')),
  destination_id UUID REFERENCES public.destinations(id) ON DELETE RESTRICT,
  vessel_id UUID REFERENCES public.vessels(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  owner_type TEXT NOT NULL CHECK (owner_type IN ('PLATFORM', 'PARTNER')),
  partner_id UUID REFERENCES public.partners(id) ON DELETE RESTRICT,
  uploaded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  authorized BOOLEAN NOT NULL DEFAULT false,
  is_provisional BOOLEAN NOT NULL DEFAULT false,
  display_order SMALLINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((owner_type = 'PLATFORM' AND partner_id IS NULL) OR (owner_type = 'PARTNER' AND partner_id IS NOT NULL))
);

-- 12. AVAILABILITY_BLOCKS
CREATE TABLE public.availability_blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  block_date DATE NOT NULL,
  block_type TEXT NOT NULL CHECK (block_type IN ('BLOQUEIO_TOTAL', 'MANUTENCAO', 'INTERDICAO_MARINHA', 'AJUSTE_CAPACIDADE')),
  custom_capacity_override SMALLINT,
  reason TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 13. COMMISSION_RULES
CREATE TABLE public.commission_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_type TEXT NOT NULL CHECK (scope_type IN ('PARTNER_DEFAULT', 'TOUR_OVERRIDE')),
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID REFERENCES public.tours(id) ON DELETE RESTRICT,
  commission_model public.commission_model_type NOT NULL,
  commission_rate_percent NUMERIC(5,2) NOT NULL DEFAULT 0.00 CHECK (commission_rate_percent BETWEEN 0 AND 100),
  commission_fixed_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (commission_fixed_amount >= 0),
  is_active BOOLEAN NOT NULL DEFAULT true,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_until TIMESTAMPTZ,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((scope_type = 'PARTNER_DEFAULT' AND tour_id IS NULL) OR (scope_type = 'TOUR_OVERRIDE' AND tour_id IS NOT NULL)),
  CHECK (NOT (commission_rate_percent = 0 AND commission_fixed_amount = 0))
);

CREATE UNIQUE INDEX idx_active_partner_comm_rule
  ON public.commission_rules(partner_id)
  WHERE is_active = true AND scope_type = 'PARTNER_DEFAULT';

CREATE UNIQUE INDEX idx_active_tour_comm_rule
  ON public.commission_rules(tour_id)
  WHERE is_active = true AND scope_type = 'TOUR_OVERRIDE';

-- 14. BOOKINGS
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(16) NOT NULL UNIQUE,
  idempotency_key VARCHAR(64) NOT NULL UNIQUE,
  tourist_user_id UUID REFERENCES public.profiles(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  vessel_id UUID NOT NULL REFERENCES public.vessels(id) ON DELETE RESTRICT,
  customer_name TEXT NOT NULL,
  customer_phone VARCHAR(25) NOT NULL,
  customer_email TEXT NOT NULL,
  booking_date DATE NOT NULL,
  passengers SMALLINT NOT NULL CHECK (passengers > 0),
  channel TEXT NOT NULL CHECK (channel IN ('WHATSAPP', 'SITE_DIRECT')),
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  status public.booking_status_type NOT NULL,
  pricing_model_snapshot public.pricing_model_type NOT NULL,
  unit_price_snapshot NUMERIC(12,2) NOT NULL,
  gross_amount NUMERIC(12,2) NOT NULL CHECK (gross_amount >= 0),
  commission_rule_id UUID REFERENCES public.commission_rules(id) ON DELETE RESTRICT,
  commission_model_snapshot public.commission_model_type NOT NULL,
  commission_rate_snapshot NUMERIC(5,2) NOT NULL,
  commission_fixed_snapshot NUMERIC(12,2) NOT NULL,
  commission_rule_label TEXT NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL CHECK (commission_amount >= 0),
  net_partner_amount NUMERIC(12,2) NOT NULL CHECK (net_partner_amount >= 0),
  notes TEXT,
  rejection_or_cancel_reason TEXT,
  expires_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (gross_amount = commission_amount + net_partner_amount)
);

-- 15. BOOKING_STATUS_HISTORY
CREATE TABLE public.booking_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE RESTRICT,
  previous_status public.booking_status_type,
  new_status public.booking_status_type NOT NULL,
  changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  changed_by_role public.app_role,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 16. COMMISSION_LEDGER
CREATE TABLE public.commission_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  ledger_status public.ledger_status_type NOT NULL DEFAULT 'PREVISTA',
  gross_amount NUMERIC(12,2) NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL,
  net_partner_amount NUMERIC(12,2) NOT NULL,
  rule_snapshot_json JSONB NOT NULL,
  consolidated_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  reversed_at TIMESTAMPTZ,
  adjustment_notes TEXT,
  updated_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (gross_amount = commission_amount + net_partner_amount)
);

-- 17. REVIEWS
CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE RESTRICT,
  tour_id UUID NOT NULL REFERENCES public.tours(id) ON DELETE RESTRICT,
  partner_id UUID NOT NULL REFERENCES public.partners(id) ON DELETE RESTRICT,
  tourist_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  author_name TEXT NOT NULL,
  author_city TEXT,
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 18. PLATFORM_SETTINGS
CREATE TABLE public.platform_settings (
  key TEXT PRIMARY KEY,
  value_json JSONB NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 19. AUDIT_LOGS
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID,
  actor_role public.app_role,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  action TEXT NOT NULL,
  old_data JSONB,
  new_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- ============================================================================
-- MIGRATION 0002: FUNÇÕES DE SEGURANÇA, RLS MULTI-TENANT E RPCS TRANSACIONAIS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND system_role = 'admin' AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_partner_member(p_partner_id UUID)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.partner_members pm
    JOIN public.profiles pr ON pr.id = pm.user_id
    WHERE pm.partner_id = p_partner_id
      AND pm.user_id = auth.uid()
      AND pm.is_active = true
      AND pr.is_active = true
  );
$$;

-- Habilita RLS em todas as tabelas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itineraries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itinerary_vessels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tour_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.availability_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commission_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Políticas Principais
CREATE POLICY "profiles_self_or_admin" ON public.profiles
  FOR SELECT USING (id = auth.uid() OR public.is_admin());

CREATE POLICY "partners_public_or_member_or_admin" ON public.partners
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(id) OR public.is_admin());

CREATE POLICY "destinations_public_read" ON public.destinations
  FOR SELECT USING (is_published = true OR public.is_admin());

CREATE POLICY "vessels_public_or_owner" ON public.vessels
  FOR SELECT USING ((status = 'APROVADO' AND is_active = true) OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "vessels_partner_write" ON public.vessels
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_public_or_owner" ON public.tours
  FOR SELECT USING (status = 'APROVADO' OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "tours_partner_insert" ON public.tours
  FOR INSERT WITH CHECK (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_isolated_read" ON public.commission_rules
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "commission_rules_admin_only_write" ON public.commission_rules
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "bookings_isolated_read" ON public.bookings
  FOR SELECT USING (tourist_user_id = auth.uid() OR public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "ledger_isolated_read" ON public.commission_ledger
  FOR SELECT USING (public.is_partner_member(partner_id) OR public.is_admin());

CREATE POLICY "audit_logs_admin_only" ON public.audit_logs
  FOR SELECT USING (public.is_admin());
