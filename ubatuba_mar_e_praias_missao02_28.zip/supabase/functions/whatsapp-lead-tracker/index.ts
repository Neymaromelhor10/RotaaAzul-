// ============================================================================
// SUPABASE EDGE FUNCTION: whatsapp-lead-tracker
// Registra lead rastreado via RPC create_booking_request, valida parceiro real,
// restringe CORS às origens permitidas e valida rigorosamente o payload (MP-002 / MP-003 / MP-011)
// ============================================================================
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.46.1';

const DEFAULT_ALLOWED_ORIGINS = [
  'https://ubatubamarepraias.com.br',
  'https://www.ubatubamarepraias.com.br',
  'http://localhost:3000',
  'http://localhost:5173',
];

function getAllowedOrigins(): Set<string> {
  const raw = Deno.env.get('ALLOWED_ORIGINS');
  if (!raw || !raw.trim()) {
    return new Set(DEFAULT_ALLOWED_ORIGINS);
  }
  return new Set(
    raw
      .split(',')
      .map((item) => item.trim())
      .filter((item) => item.length > 0 && item !== '*')
  );
}

function buildCorsHeaders(requestOrigin: string | null): { allowed: boolean; headers: Record<string, string> } {
  const allowedOrigins = getAllowedOrigins();
  const fallbackOrigin = DEFAULT_ALLOWED_ORIGINS[0];
  const isAllowed = !requestOrigin || allowedOrigins.has(requestOrigin);

  return {
    allowed: isAllowed,
    headers: {
      'Access-Control-Allow-Origin': requestOrigin && isAllowed ? requestOrigin : fallbackOrigin,
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Vary': 'Origin',
    },
  };
}

const VALID_BOOKING_STATUSES = new Set([
  'SOLICITADA',
  'AGUARDANDO_CONFIRMACAO',
  'CONFIRMADA',
  'RECUSADA',
  'CANCELADA',
  'PASSEIO_REALIZADO',
  'EM_DISPUTA',
]);

const ISO_DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const SAFE_ID_REGEX = /^[a-zA-Z0-9_-]{3,80}$/;

Deno.serve(async (req: Request) => {
  const origin = req.headers.get('Origin');
  const cors = buildCorsHeaders(origin);

  if (!cors.allowed) {
    return new Response(
      JSON.stringify({ success: false, error: 'FORBIDDEN_ORIGIN: Origem não autorizada pela política de CORS.' }),
      { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 403 }
    );
  }

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: cors.headers, status: 200 });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ success: false, error: 'METHOD_NOT_ALLOWED: Utilize exclusivamente o método POST.' }),
      { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 405 }
    );
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error('SERVER_MISCONFIGURED: Variáveis SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY são obrigatórias.');
    }

    const contentType = req.headers.get('Content-Type') || '';
    if (!contentType.toLowerCase().includes('application/json')) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_CONTENT_TYPE: Content-Type deve ser application/json.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 415 }
      );
    }

    let payload: Record<string, unknown>;
    try {
      const parsed = await req.json();
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('Payload JSON deve ser um objeto.');
      }
      payload = parsed as Record<string, unknown>;
    } catch {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_JSON: Corpo da requisição não é um JSON válido.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const tourId = typeof payload.tourId === 'string' ? payload.tourId.trim() : '';
    const bookingDate = typeof payload.bookingDate === 'string' ? payload.bookingDate.trim() : '';
    const customerName = typeof payload.customerName === 'string' ? payload.customerName.trim() : '';
    const customerPhone = typeof payload.customerPhone === 'string' ? payload.customerPhone.trim() : '';
    const customerEmail = typeof payload.customerEmail === 'string' ? payload.customerEmail.trim().toLowerCase() : '';
    const phoneDigits = customerPhone.replace(/\D/g, '');
    const parsedPassengers = Number(payload.passengers);

    if (!SAFE_ID_REGEX.test(tourId)) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_TOUR_ID: Identificador do passeio inválido.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (!ISO_DATE_REGEX.test(bookingDate) || bookingDate < '2026-11-08') {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_BOOKING_DATE: Informe uma data válida (YYYY-MM-DD >= 2026-11-08).' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (!Number.isInteger(parsedPassengers) || parsedPassengers < 1 || parsedPassengers > 250) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_PASSENGERS: Quantidade de passageiros deve ser um inteiro entre 1 e 250.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (customerName.length < 3 || customerName.length > 120) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_CUSTOMER_NAME: Nome do cliente deve ter entre 3 e 120 caracteres.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (phoneDigits.length < 10 || phoneDigits.length > 15) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_CUSTOMER_PHONE: Telefone/WhatsApp deve conter entre 10 e 15 dígitos.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (customerEmail.length > 160 || !EMAIL_REGEX.test(customerEmail)) {
      return new Response(
        JSON.stringify({ success: false, error: 'INVALID_CUSTOMER_EMAIL: Endereço de e-mail inválido.' }),
        { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const utmSource = typeof payload.utmSource === 'string' && payload.utmSource.trim()
      ? payload.utmSource.trim().slice(0, 64)
      : 'direct_organic';
    const utmMedium = typeof payload.utmMedium === 'string' && payload.utmMedium.trim()
      ? payload.utmMedium.trim().slice(0, 64)
      : null;
    const utmCampaign = typeof payload.utmCampaign === 'string' && payload.utmCampaign.trim()
      ? payload.utmCampaign.trim().slice(0, 64)
      : 'marketplace_ubatuba_2026';
    const idempotencyKey = typeof payload.idempotencyKey === 'string' && payload.idempotencyKey.trim()
      ? payload.idempotencyKey.trim().slice(0, 64)
      : null;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    const { data, error } = await supabase.rpc('create_booking_request', {
      p_tour_id: tourId,
      p_booking_date: bookingDate,
      p_passengers: parsedPassengers,
      p_channel: 'WHATSAPP',
      p_customer_name: customerName,
      p_customer_phone: customerPhone,
      p_customer_email: customerEmail,
      p_utm_source: utmSource,
      p_utm_medium: utmMedium,
      p_utm_campaign: utmCampaign,
      p_notes: 'Lead rastreado via Edge Function whatsapp-lead-tracker',
      p_idempotency_key: idempotencyKey,
    });

    if (error) throw error;
    if (!data || !VALID_BOOKING_STATUSES.has(String(data.status))) {
      throw new Error('CONTRACT_MISMATCH: A RPC create_booking_request retornou um estado fora do contrato único.');
    }

    const cleanPhone = String(data.partner_whatsapp || '').replace(/\D/g, '');
    const message = [
      `Olá ${data.partner_name}! Solicitação #${data.code} via Ubatuba Mar & Praias.`,
      `Passeio: ${data.tour_title || tourId}`,
      `Data: ${bookingDate}`,
      `Passageiros: ${parsedPassengers}`,
      `Status: ${data.status}`,
      `Valor Estimado: R$ ${data.gross_amount}`,
      `Turista: ${customerName} (${customerPhone})`,
    ].join('\n');

    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;

    return new Response(
      JSON.stringify({
        success: true,
        booking: data,
        whatsappUrl,
      }),
      { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 200 }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({
        success: false,
        error: err?.message || 'Erro interno ao processar reserva',
      }),
      { headers: { ...cors.headers, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
