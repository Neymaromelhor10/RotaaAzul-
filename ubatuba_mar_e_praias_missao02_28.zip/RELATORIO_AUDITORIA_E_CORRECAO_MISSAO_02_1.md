# RELATÓRIO TÉCNICO E FORENSE — ARGON 4 — MISSÃO 02.1
## CORREÇÃO CONTROLADA DOS ACHADOS `M02.0-F01` A `M02.0-F10` — UBATUBA MAR & PRAIAS

- **Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)
- **Missão:** 02.1 (Correção controlada dos achados da Auditoria Independente 02.0)
- **Data da Execução:** 13/11/2026
- **Veredito Oficial da Missão 02.1:** **`APROVADA COM RESSALVAS`** *(100% dos achados `P0` e `P1` corrigidos e comprovados; permanecem pendentes exclusivamente a execução runtime em PostgreSQL 15+ real e a execução de `npm install` / `npm ci` / `tsc` / `vite build` em ambiente externo com acesso à internet).*

---

## SEÇÃO A — IDENTIFICAÇÃO DO PACOTE DE ENTRADA E INVESTIGAÇÃO DE HASHES (`2f31aa...` VS `957b43...`)

1. **Pacote de Entrada Efetivamente Utilizado como Base (`Missão 01.9`):**
   - **Arquivo:** `ubatuba_mar_e_praias_missao01_9_corrigido.zip`
   - **Tamanho:** `1.077.128 bytes`
   - **Estrutura:** `57` entradas (`45` arquivos + `12` entradas explícitas de diretório sob a pasta raiz única `ubatuba_mar_e_praias_marketplace/`)
   - **SHA-256:** `957b43064486d2c17b090d2de03d77ce370584a70ca646554162d85e34b64bee`

2. **Investigação Forense da Divergência entre `1.072.104 bytes` (`2f31aa...`) e `1.077.128 bytes` (`957b43...`):**
   - **Pacote 1 (`1.072.104 bytes`, SHA-256 `2f31aa6360141a49ec5773c709278e9ced40b7da39ff3f2d4c91ea2d92bb6815`):** foi o primeiro empacotamento da Missão 01.9, no qual os `45` arquivos estavam gravados diretamente na raiz do `.zip` (sem diretório-pai `ubatuba_mar_e_praias_marketplace/`).
   - **Pacote 2 (`1.077.128 bytes`, SHA-256 `957b43064486d2c17b090d2de03d77ce370584a70ca646554162d85e34b64bee`):** foi gerado imediatamente em seguida a pedido do usuário para que todos os `45` arquivos ficassem dentro da pasta raiz única `ubatuba_mar_e_praias_marketplace/` (adicionando o prefixo `ubatuba_mar_e_praias_marketplace/` e `12` entradas de diretório no cabeçalho ZIP, o que explica exatamente os `+5.024 bytes` no container ZIP, mantendo o conteúdo interno 100% consistente).
   - **Base Escolhida:** `ubatuba_mar_e_praias_missao01_9_corrigido.zip` (`1.077.128 bytes`, SHA-256 `957b43064486d2c17b090d2de03d77ce370584a70ca646554162d85e34b64bee`), sem qualquer mistura de versões.

---

## SEÇÃO B — BACKUP PRÉ-ALTERAÇÃO E PRESERVAÇÃO DAS MIGRATIONS `000001` A `000008`

- **Backup Integral do ZIP Pré-02.1:** `ubatuba_mar_e_praias_missao01_9_corrigido_BACKUP_PRE_02_1.zip` (`1.077.128 bytes`, SHA-256 `957b43064486d2c17b090d2de03d77ce370584a70ca646554162d85e34b64bee`).
- **Snapshot Lógico SQL Pré-02.1 (`000001` a `000008`):** `supabase/backups/backup_logico_pre_missao_02_1.sql` (`372.272 bytes`, SHA-256 `9a8e270f0eccf2a1bcc9ac23c9b351c345f743c0b14b8c78160e68fd5fe12781`).
- **Preservação Byte a Byte das Migrations `000001` a `000008`:** todas as 8 migrations anteriores permaneceram 100% intocadas.

---

## SEÇÃO C — MATRIZ COMPLETA DE CORREÇÃO DOS ACHADOS (`M02.0-F01` A `M02.0-F10`)

| ID | Sev. | Status | Correção Implementada | Arquivos e Linhas | Teste Correspondente | Resultado | Pendências |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **`M02.0-F01`** | **P0** | **CORRIGIDO** | Substituídas todas as referências `cl.status` / `status` em `public.commission_ledger` por `cl.ledger_status` / `ledger_status`, `v_ledger_after.status` por `v_ledger_after.ledger_status` e `'PROVISIONADA'` por `'PREVISTA'`, respeitando a máquina de estados da `000005`. Implementado validador cruzado `STATIC-12`. | `supabase/tests/load_stability_plan_pg.py` (`L290`, `L479–486`, `L600`, `L685–689`); `supabase/tests/homologacao_postgresql_real.sql` (`L1768`); `supabase/tests/verify_pg_contracts_and_ast.py` (`L115–218`, `L532–551`) | `STATIC-12` (`verify_pg_contracts_and_ast.py`) + `T9.11` (`homologacao_postgresql_real.sql`) | **`STATIC PASS` (`0` divergências)** | Execução runtime em PostgreSQL 15+ real. |
| **`M02.0-F02`** | **P0** | **CORRIGIDO** | Implementado `ensure_load_test_partner_users()` provisionando de forma idempotente `PARTNER_KAIMARES_USER` (`1111...101`) e `PARTNER_ESCUNA_USER` (`1111...103`) em `auth.users`, `public.profiles` (via token `AUTH_PROFILE_SYNC`) e `public.partner_members`, validando `public.is_partner_member() = true`. Corrigido `block_type` para `'AJUSTE_CAPACIDADE'` e validação de `INVALID_STATUS_TRANSITION` em `L3`. | `supabase/tests/load_stability_plan_pg.py` (`L35–42`, `L172–255`, `L379–449`, `L671–682`) | `STATIC-11`, `STATIC-12` e `M02.1-REG` | **`PASS`** | Execução runtime de `L2` e `L3` em PostgreSQL 15+ real. |
| **`M02.0-F03`** | **P1** | **CORRIGIDO** | Criada migration incremental `000009` atualizando `enforce_booking_invariants_and_transitions()`, `enforce_commission_ledger_integrity()` e `admin_anonymize_customer_pii(UUID, TEXT)` para sanitizar `commission_ledger.adjustment_notes`, desvincular `commission_ledger.updated_by` (quando igual ao turista), pseudonimizar `bookings.idempotency_key` (`lgpd-<uuid>-<md5>`) e limpar 15 chaves em `audit_logs`. | `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` (`L1–798`); `supabase/tests/homologacao_postgresql_real.sql` (`T9.15`, `L1796–1896`) | `M02.1-LGPD-ISOLATED` (`run_isolated_test_suite.py`) + `T9.15` (`homologacao_postgresql_real.sql`) | **`PASS` (Offline)** | Execução runtime de `T9.15` em PostgreSQL 15+ real. |
| **`M02.0-F04`** | **P1** | **CORRIGIDO** | Reaplicação de `000003` a `000009` unificada em transação atômica única (`psql --single-transaction`) no `Passo 2` do runner, seguida de auditoria em `pg_policies` (confirmando `0` políticas obsoletas) e em `pg_proc` (confirmando corpo `000009` ativo). | `supabase/tests/run_postgresql_homologation.sh` (`L376–435`) | `GUARD-00-SAME-SESSION-AND-ATOMIC-REAPPLY` (`test_runner_destructive_guards.py`) | **`PASS`** | Execução runtime de `PG-02` em PostgreSQL 15+ real. |
| **`M02.0-F05`** | **P1** | **CORRIGIDO** | Implementado `ensure_partner_users_and_verify_rls_isolation()` e atualizado `worker_reduce_tour_cap()` em `test_concorrencia_real_pg.py` para executar sob `SET LOCAL ROLE authenticated` com claims JWT de `PARTNER_KAIMARES_USER`, comprovando bloqueio de parceiro alheio (`FOREIGN_ROWS=0`) e restaurando `vessels` e `tours` no cleanup. | `supabase/tests/test_concorrencia_real_pg.py` (`L28–33`, `L81–171`, `L195–201`, `L306–326`) | `STATIC-11` e `STATIC-12` | **`PASS` (Offline)** | Execução runtime das 2 rodadas em PostgreSQL 15+ real. |
| **`M02.0-F06`** | **P2** | **CORRIGIDO** | Parser de `DATABASE_URL` no runner atualizado com extração gulosa `${URL_WITHOUT_PROTO##*@}` (suportando `@` na senha) e inspeção prévia da query string bloqueando `host=`, `hostaddr=`, `dbname=`, `user=`, `service=`, `passfile=`, `options=` e `target_session_attrs=`. | `supabase/tests/run_postgresql_homologation.sh` (`L202–268`) | `GUARD-10` e `GUARD-11` (`test_runner_destructive_guards.py`) | **`PASS` (`14/14`)** | Nenhuma. |
| **`M02.0-F07`** | **P2** | **CORRIGIDO** | `cleanup_owned_container()` captura e preserva `local original_rc=$?`, registra `trap` para `EXIT`, `INT` (`130`) e `TERM` (`143`), e valida disponibilidade da porta TCP local via `is_local_tcp_port_free()` antes do `docker run`. | `supabase/tests/run_postgresql_homologation.sh` (`L73–183`) | `GUARD-12` e `GUARD-13` (`test_runner_destructive_guards.py`) | **`PASS` (`14/14`)** | Nenhuma. |
| **`M02.0-F08`** | **P2** | **CORRIGIDO** | Implementado `execute_prewarmed_psql_at_barrier()` com `subprocess.Popen`, pré-aquecendo cada sessão `psql` (`SELECT 'UBATUBA_SESSION_READY';`) antes de `barrier.wait()` e separando `process_spawn_ms`, `connection_ready_ms`, `sql_exec_ms` e `total_client_ms`. | `supabase/tests/load_stability_plan_pg.py` (`L57–133`, `L275–286`, `L451–460`, `L649–658`) | `STATIC-11` e `M02.1-REG` | **`PASS`** | Coleta das métricas reais em PostgreSQL 15+. |
| **`M02.0-F09`** | **P2** | **TRATADO E DOCUMENTADO** | Inspecionados `package.json` e `package-lock.json` sem inventar hashes `integrity` falsos; documentada a exigência de `npm install` (ou regeneração do lockfile com acesso a `registry.npmjs.org`) antes de `npm ci`, `npx tsc --noEmit` e `npm run build`. | `package.json` (`L1–36`), `package-lock.json` (`L1–95`) | `STATIC-08` (AST Babel) + Seção J deste relatório | **AUDITADO (PENDENTE DE REDE NPM)** | Executar `npm install && npm ci && npx tsc --noEmit && npm run build` em máquina com internet. |
| **`M02.0-F10`** | **P3** | **CORRIGIDO** | Adicionado o campo `'external_channel_warning'` no retorno de `admin_anonymize_customer_pii` e no log `ANONYMIZE_PII_LGPD` quando `channel = 'WHATSAPP'`, orientando o expurgo operacional de mensagens externas sem quebrar o fluxo comercial do WhatsApp. | `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` (`L477–482`, `L515`, `L685`, `L709`); `homologacao_postgresql_real.sql` (`T9.15e`, `L1856–1871`) | `T9.15e` e `M02.1-LGPD-ISOLATED` | **`PASS`** | Execução runtime de `T9.15e` em PostgreSQL 15+ real. |

---

## SEÇÃO D — ANÁLISE COMPLETA DA MIGRATION `000009` (`20261115000009_missao02_1_residual_fixes.sql`)

A migration `000009` (`37.711 bytes`, SHA-256 `1bd0824422e8cb1d93c0a6f73d67a549f40981e051d0870946f38d08cc64eb9e`) atualiza exatamente 3 funções e reaplica a consolidação de privilégios:

1. **`public.enforce_booking_invariants_and_transitions()` (`Linhas 46–198`):**
   - Mantém o bloqueio total de alterações estruturais e financeiras em `public.bookings`.
   - Permite alterar `NEW.idempotency_key` **exclusivamente** quando o token transacional `'BOOKING_MUTATION'` com estado `'LGPD_ANONYMIZE:' || NEW.status::text` foi consumido na profundidade exata da trigger (`pg_trigger_depth() - 1`) **E** o novo valor é exatamente `('lgpd-' || replace(OLD.id::text, '-', '') || '-' || left(md5(OLD.id::text), 16))::varchar(64)` (`54` caracteres).
2. **`public.enforce_commission_ledger_integrity()` (`Linhas 208–308`):**
   - Mantém imutáveis `id`, `booking_id`, `partner_id`, `tour_id`, `gross_amount`, `commission_amount`, `net_partner_amount`, `rule_snapshot_json`, `consolidated_at`, `paid_at`, `reversed_at` e `ledger_status`.
   - Adiciona o **Caso 1 (Exceção Controlada LGPD, linhas `258–266`)**: quando todos os campos financeiros, timestamps e `ledger_status` permanecem inalterados (`IS NOT DISTINCT FROM OLD.*`) e a trigger consome o token `'LEDGER_SYNC'` com estado `'LGPD_ANONYMIZE:' || OLD.ledger_status::text`, permite a sanitização de `adjustment_notes` e a desvinculação de `updated_by`.
3. **`public.admin_anonymize_customer_pii(UUID, TEXT)` (`Linhas 325–712`):**
   - Adquire locks na ordem canônica: `public.vessels FOR UPDATE` -> `pg_advisory_xact_lock` -> `public.bookings FOR UPDATE` -> `public.commission_ledger FOR UPDATE` -> `public.reviews FOR UPDATE`.
   - Sanitiza `public.bookings` (incluindo `tourist_user_id = NULL`, `idempotency_key = v_anon_idem_key`, `customer_name`, `customer_phone`, `customer_email`, `notes`, `rejection_or_cancel_reason`).
   - Sanitiza todos os registros de `public.booking_status_history` da reserva.
   - Sanitiza `public.commission_ledger.adjustment_notes` e define `updated_by = NULL` quando igual ao `tourist_user_id` original, preservando `updated_by` quando a atualização foi feita por parceiro/admin.
   - Sanitiza `public.reviews` e `15` chaves em `public.audit_logs` (`old_data` e `new_data`), registrando `ANONYMIZE_PII_LGPD` e retornando `external_channel_warning` quando `channel = 'WHATSAPP'`.

---

## SEÇÃO E — ANÁLISE DE INTEGRIDADE FINANCEIRA E LGPD

- **Preservação Contábil Integral:** `gross_amount`, `commission_amount`, `net_partner_amount`, `pricing_model_snapshot`, `unit_price_snapshot`, `commission_rule_id`, `commission_model_snapshot`, `commission_rate_snapshot`, `commission_fixed_snapshot`, `rule_snapshot_json` e `ledger_status` são verificados como `IS NOT DISTINCT FROM OLD` tanto em `enforce_booking_invariants_and_transitions()` quanto em `enforce_commission_ledger_integrity()`.
- **Prevenção de Colisão e Preservação de Retries em `idempotency_key`:**
  - Como o frontend (`src/App.tsx`) envia `p_idempotency_key = null`, o servidor gera por padrão o hash MD5 de `(tour_id, booking_date, phone_digits)`.
  - Ao anonimizar uma reserva via LGPD, substituir `idempotency_key` por `'lgpd-' || replace(id::text, '-', '') || '-' || left(md5(id::text), 16)` elimina qualquer hash de telefone ou string fornecida pelo cliente, garante unicidade global matemática (pois deriva da chave primária `id UUID` da própria reserva) e permite que o cliente volte a reservar no futuro sem sofrer erro `IDEMPOTENCY_KEY_CONFLICT` contra a reserva antiga já anonimizada.

---

## SEÇÃO F — EVIDÊNCIA DE CORREÇÃO DE `L1`, `L2` E `L3` (`load_stability_plan_pg.py`)

1. **`M02.0-F01`:** Todas as queries de verificação em `L1` (`L290`), `L2` (`L479–486`) e `L3` (`L600`, `L685–689`) utilizam `ledger_status` e `'PREVISTA'`/`'CONFIRMADA'`/`'PAGA'`/`'REVERTIDA'`/`'EM_DISPUTA'`, validado por `STATIC-12` (`0` divergências).
2. **`M02.0-F02`:** `ensure_load_test_partner_users()` (`L172–255`) provisiona `PARTNER_KAIMARES_USER` (`11111111-1111-4111-8111-111111111101`) e `PARTNER_ESCUNA_USER` (`11111111-1111-4111-8111-111111111103`) e comprova `public.is_partner_member() = true` sob `SET LOCAL ROLE authenticated` antes de iniciar `L1`, `L2` e `L3`. Em `L2` (`L429`), `upsert_availability_block` utiliza `'AJUSTE_CAPACIDADE'`. Em `L3` (`L671–682`), a tentativa de reativação exige `INVALID_STATUS_TRANSITION` e rejeita qualquer erro `UNAUTHORIZED`.
3. **`M02.0-F08`:** `execute_prewarmed_psql_at_barrier()` (`L57–133`) inicia cada processo `psql` via `Popen`, envia `SELECT 'UBATUBA_SESSION_READY';`, aguarda confirmação de prontidão da sessão PostgreSQL, sincroniza em `barrier.wait()` e mede separadamente `process_spawn_ms`, `connection_ready_ms`, `sql_exec_ms` e `total_client_ms`.

---

## SEÇÃO G — EVIDÊNCIA DE HARDENING DO RUNNER (`run_postgresql_homologation.sh`)

Executada a suíte `python3 supabase/tests/test_runner_destructive_guards.py` com **`14/14 PASS` (`rc=0`)**:
- `GUARD-00-SAME-SESSION-AND-ATOMIC-REAPPLY`: `PASS` (bloco único `DO $guard$` na mesma sessão `psql` e reaplicação `--single-transaction` de `000003`..`000009`).
- `GUARD-01-DOCKER-AUTORIZADO` a `GUARD-09-CONTAINER-OWNERSHIP-PROTECTION`: `9/9 PASS`.
- `GUARD-10-PASSWORD-AT-AND-QUERY-PARAMS`: `PASS` (senha `p@ss@word!123` com `@` aprovada em banco local autorizado `rc=0`, e 8 URLs com `?host=`, `?hostaddr=`, `?dbname=`, `?user=`, `?service=`, `?passfile=`, `?options=` bloqueadas com `QUERY_PARAM_FORBIDDEN` antes de invocar `psql`).
- `GUARD-11-MALFORMED-AND-AMBIGUOUS-URLS`: `PASS` (5 URLs sem `@`, com múltiplos `?`, porta `99999`, caminho extra ou protocolo inválido bloqueadas antes do `psql`).
- `GUARD-12-EXIT-CODE-PRESERVATION-AND-CLEANUP`: `PASS` (falha pós-guarda com `rc=42` limpou o container próprio e preservou exatamente o código de saída `42`).
- `GUARD-13-PORT-COLLISION-DETECTION`: `PASS` (porta ocupada `55499` bloqueada com `PORT_IN_USE` antes do `docker run`).

---

## SEÇÃO H — EVIDÊNCIA DE CORREÇÃO DOS TESTES DE CONCORRÊNCIA SOB RLS (`test_concorrencia_real_pg.py`)

Em `supabase/tests/test_concorrencia_real_pg.py`:
- `ensure_partner_users_and_verify_rls_isolation()` (`L81–171`) provisiona `PARTNER_KAIMARES_USER` (`1111...101`) e `PARTNER_ROTADOMAR_USER` (`1111...102`), comprova sob `SET LOCAL ROLE authenticated` que `PARTNER_ROTADOMAR_USER` afeta `0` linhas ao tentar alterar `tour-lancha-norte-comp` (`FOREIGN_ROWS=0`, bloqueado pela política RLS `tours_partner_update`) e que `PARTNER_KAIMARES_USER` atualiza `1` linha (`OWNER_ROWS=1`).
- `worker_reduce_tour_cap()` (`L306–326`) executa sob `SET LOCAL ROLE authenticated` com `request.jwt.claim.sub = PARTNER_KAIMARES_USER` e `request.jwt.claim.role = 'authenticated'`, verificando `ROW_COUNT = 1`.
- `cancel_active_bookings_and_restore_tour()` (`L195–201`) restaura tanto `public.vessels.capacity = 12` quanto `public.tours.capacity = 12`.

---

## SEÇÃO I — RESULTADO DOS TESTES OFFLINE EXECUTADOS NESTA MISSÃO

| Suíte Executada | Comando | Resultado | Detalhamento |
| --- | --- | --- | --- |
| **Guarda Destrutiva, URL Parser, Sinais e Porta** | `python3 supabase/tests/test_runner_destructive_guards.py` | **`14/14 PASS` (`rc=0`)** | `GUARD-00` a `GUARD-13` aprovados sem falsos positivos. |
| **Verificador Estático, AST Babel e Validador Cruzado de Schema/Enums** | `python3 supabase/tests/verify_pg_contracts_and_ast.py` | **`12/12 STATIC PASS` (`rc=0`)** | `STATIC-01` a `STATIC-12` aprovados (`19` tabelas, `7` enums e `38` funções ativas pós-`000009` validados contra todos os scripts Python/SQL). |
| **Suíte Isolada Comportamental e de Regressão** | `python3 supabase/tests/run_isolated_test_suite.py` | **`25/25 PASS` (`rc=0`)** | Inclui `BD-01..06`, `CAD-01..05`, `RES-01..08`, `INT-01..05`, `M01.8-REG`, `M01.9-REG`, `M02.1-LGPD-ISOLATED` e `M02.1-REG`. *(Nota: simulação SQLite/offline não substitui a homologação PostgreSQL 15+ real).* |

---

## SEÇÃO J — RESULTADO DE `npm install`, `npm ci`, TYPESCRIPT E BUILD (`M02.0-F09`)

- **Estado de `package.json` e `package-lock.json`:** `package.json` (`1.134 B`) declara 4 `dependencies` e 8 `devDependencies` compatíveis. Como o ambiente sandbox não possui acesso à internet (`EAI_AGAIN registry.npmjs.org`), não foram inventados hashes `integrity` artificiais em `package-lock.json`.
- **Etapas Pendentes de Rede Externa:**
  1. `npm install` (para hidratar a árvore transitiva completa e os hashes `integrity` reais em `package-lock.json`);
  2. `npm ci` (instalação limpa reproduzível a partir do lockfile completo);
  3. `npx tsc --noEmit` (checagem semântica completa de tipos TypeScript);
  4. `npm run build` (bundling de produção Vite + Tailwind CSS).

---

## SEÇÃO K — LISTA EXATA DOS ARQUIVOS CRIADOS OU ALTERADOS NA MISSÃO 02.1

1. `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` (**CRIADO** — Migration incremental `000009`)
2. `supabase/backups/backup_logico_pre_missao_02_1.sql` (**CRIADO** — Snapshot lógico consolidado `000001`–`000008`)
3. `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_1.md` (**CRIADO** — Relatório técnico completo da Missão 02.1)
4. `supabase/tests/load_stability_plan_pg.py` (**MODIFICADO** — Correções `M02.0-F01`, `M02.0-F02` e `M02.0-F08`)
5. `supabase/tests/homologacao_postgresql_real.sql` (**MODIFICADO** — Correção `M02.0-F01` em `T9.11` e adição de `T9.15`)
6. `supabase/tests/test_concorrencia_real_pg.py` (**MODIFICADO** — Correção `M02.0-F05` de concorrência sob RLS)
7. `supabase/tests/run_postgresql_homologation.sh` (**MODIFICADO** — Correções `M02.0-F04`, `M02.0-F06` e `M02.0-F07`)
8. `supabase/tests/test_runner_destructive_guards.py` (**MODIFICADO** — Expansão para `GUARD-00` a `GUARD-13`)
9. `supabase/tests/verify_pg_contracts_and_ast.py` (**MODIFICADO** — Suporte à `000009` e validador cruzado `STATIC-12`)
10. `supabase/tests/run_isolated_test_suite.py` (**MODIFICADO** — Adição de `M02.1-LGPD-ISOLATED` e `M02.1-REG`)
11. `supabase/tests/function_inventory.json` (**MODIFICADO** — Adição de `cumulative_active_after_000009`)

---

## SEÇÃO L — HASHES SHA-256 DOS ARQUIVOS CRIADOS / MODIFICADOS E PRESERVADOS

| Arquivo (`ubatuba_mar_e_praias_marketplace/...`) | Status | Tamanho (Bytes) | SHA-256 |
| --- | --- | --- | --- |
| `supabase/migrations/20261108000001_initial_schema.sql` | **PRESERVADO** | `17.194` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` |
| `supabase/migrations/20261108000002_rls_and_rpcs.sql` | **PRESERVADO** | `3.875` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` |
| `supabase/migrations/20261110000003_missao01_audit_fixes_and_rpcs.sql` | **PRESERVADO** | `120.783` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` |
| `supabase/migrations/20261110000004_missao01_official_catalog_seed.sql` | **PRESERVADO** | `14.727` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` |
| `supabase/migrations/20261111000005_missao01_4_forensic_hardening.sql` | **PRESERVADO** | `58.943` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` |
| `supabase/migrations/20261112000006_missao01_6_forensic_fixes.sql` | **PRESERVADO** | `54.113` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` |
| `supabase/migrations/20261113000007_missao01_8_controlled_fixes.sql` | **PRESERVADO** | `64.902` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` |
| `supabase/migrations/20261114000008_missao01_9_controlled_fixes.sql` | **PRESERVADO** | `36.333` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` |
| `src/App.tsx` | **PRESERVADO** | `313.961` | `52f7d1d9a33c7b1f82bf49c63d3e575483b173800286985b64bb07eb2765979e` |
| `src/lib/bookingService.ts` | **PRESERVADO** | `19.016` | `625ea68e1f2b99c411fde66272fc0cc445012c98bc2113e9330919663f03171a` |
| `src/types/database.types.ts` | **PRESERVADO** | `12.407` | `085e2526e93451b78f233e0ceccd7d359f60573f048f7a7ade3dae2e863e0f25` |
| `supabase/migrations/20261115000009_missao02_1_residual_fixes.sql` | **CRIADO** | `37.711` | `1bd0824422e8cb1d93c0a6f73d67a549f40981e051d0870946f38d08cc64eb9e` |
| `supabase/backups/backup_logico_pre_missao_02_1.sql` | **CRIADO** | `372.272` | `9a8e270f0eccf2a1bcc9ac23c9b351c345f743c0b14b8c78160e68fd5fe12781` |
| `supabase/tests/load_stability_plan_pg.py` | **MODIFICADO** | `54.289` | `d1d7bf19c1138dd0cf543287a7773a2b7777bdaa17e44c1856bc854bf8bfb89e` |
| `supabase/tests/homologacao_postgresql_real.sql` | **MODIFICADO** | `92.775` | `52b44bed8ffafe7065fea2c65b584329ef637e5c439a7ff49006fda9ddd34d6d` |
| `supabase/tests/test_concorrencia_real_pg.py` | **MODIFICADO** | `19.588` | `7c0f9a42c75cc9527db0f861f0f7d66eafa3021192e21222048cb2c3a4f85a79` |
| `supabase/tests/run_postgresql_homologation.sh` | **MODIFICADO** | `27.077` | `72798d819e0e5ccd5837550d89bb59857e377e255e55a7b4bc552f22f3769170` |
| `supabase/tests/test_runner_destructive_guards.py` | **MODIFICADO** | `29.241` | `3e8836da10019ce46a36dce61f8111651f47c3a4422b9b6a4266364975278a1d` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | **MODIFICADO** | `33.710` | `9d9b9d812695bf977ec4a2aba342d15eb9d529f4a587b723ca92438684a71b37` |
| `supabase/tests/run_isolated_test_suite.py` | **MODIFICADO** | `79.416` | `533052ca1504b39a11b435c6a2cd88e63867040ebe4a50c05d889de7533bcf68` |
| `supabase/tests/function_inventory.json` | **MODIFICADO** | `118.206` | `eed30354c411db55f9cb0bcca9edb2da41cb09d5df3e268ba9f0b7e98dd7293f` |

---

## SEÇÃO M — PENDÊNCIAS QUE AINDA DEPENDEM DE POSTGRESQL 15+ REAL E REDE EXTERNA

1. **Execução completa do runner `bash supabase/tests/run_postgresql_homologation.sh --docker`** em máquina com Docker e PostgreSQL 15+ para validar em runtime:
   - Aplicação do zero das migrations `000001` a `000009` (`PG-01`);
   - Reaplicação transacional atômica (`--single-transaction`) de `000003` a `000009` e auditoria de `pg_policies`/`pg_proc` (`PG-02`, `PG-14`, `M02.0-F04`);
   - Suíte `homologacao_postgresql_real.sql` (`PG-03..PG-13`, `SEG-01..SEG-07`, `T8.1..T8.15` e `T9.1..T9.15`);
   - Suíte `test_concorrencia_real_pg.py` (2 rodadas consecutivas sob `ROLE authenticated`);
   - Suíte `load_stability_plan_pg.py` (`L1`, `L2` e `L3` com sessões `psql` pré-conectadas).
2. **Execução de `npm install && npm ci && npx tsc --noEmit && npm run build`** em ambiente com acesso a `registry.npmjs.org`.

---

## SEÇÃO N — PLANO DA PRÓXIMA ETAPA

1. Revisar o pacote final `ubatuba_mar_e_praias_missao02_1_corrigido.zip` (empacotado com a pasta raiz única `ubatuba_mar_e_praias_marketplace/`).
2. Em ambiente externo com Docker, PostgreSQL 15+ e Node.js/npm conectados à internet:
   - Executar `npm install && npm ci && npx tsc --noEmit && npm run build` para consolidar o `package-lock.json` completo e validar a tipagem e o bundle de produção;
   - Executar `bash supabase/tests/run_postgresql_homologation.sh --docker` e coletar o log completo e o arquivo `supabase/tests/load_stability_report.json` para homologação final.
