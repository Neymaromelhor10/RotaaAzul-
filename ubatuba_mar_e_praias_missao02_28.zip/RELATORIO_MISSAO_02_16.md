# RELATÓRIO TÉCNICO — ARGON 4 — MISSÃO 02.16
## IMPLEMENTAÇÃO E AUDITORIA DO FLUXO DE RESERVAS, CONSULTA SEGURA DO TURISTA E DATAS DINÂMICAS

- **Projeto**: Ubatuba Mar & Praias — Marketplace de Turismo Náutico (`ubatuba-mar-e-praias-marketplace`)
- **Missão**: `02.16` (Escopo: **Missão B** do Plano de Correções da Auditoria Independente `02.14`)
- **Base Obrigatória Recebida**: `ubatuba_mar_e_praias_missao02_15_3.zip` (`1.517.336 bytes`, `78 arquivos`)
- **SHA-256 da Base `02.15.3`**: `10e8ebbf2109f469c57c4a69650513180db0193c842cf8ccff6d11bca0ff6250`
- **Nova Migration Entregue**: `supabase/migrations/20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql`
- **Status Geral**: **CONCLUÍDA COM SUCESSO (`16/16` GUARD + `19/19` STATIC/AST + `42/42` ISOLATED SUITES + `7/7` DEMO GUARD + `npm run lint` = EXIT CODE `0`)**

---

## 1. Integridade e Identificação da Base `02.15.3` (Seção 2)

Antes de qualquer alteração, a base `ubatuba_mar_e_praias_missao02_15_3.zip` foi auditada e extraída em diretório isolado:

1. **Arquivo de Entrada**: `ubatuba_mar_e_praias_missao02_15_3.zip` (`1.517.336 bytes`, `78 arquivos`, `zipfile.testzip() == None`).
2. **SHA-256 da Base `02.15.3`**: `10e8ebbf2109f469c57c4a69650513180db0193c842cf8ccff6d11bca0ff6250`.
3. **Preservação Intacta de `package.json` e `package-lock.json` (Seção 12)**:
   - `package.json`: `cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379` (inalterado).
   - `package-lock.json`: `ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013` (inalterado).
4. **Preservação Intacta das 18 Migrations Históricas (`000001` a `000018`)**:
   - `20261108000001_initial_schema.sql`: `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198`
   - `20261108000002_rls_and_rpcs.sql`: `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f`
   - `20261110000003_missao01_audit_fixes_and_rpcs.sql`: `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a`
   - `20261110000004_missao01_official_catalog_seed.sql`: `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef`
   - `20261111000005_missao01_4_forensic_hardening.sql`: `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f`
   - `20261112000006_missao01_6_forensic_fixes.sql`: `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a`
   - `20261113000007_missao01_8_controlled_fixes.sql`: `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425`
   - `20261114000008_missao01_9_controlled_fixes.sql`: `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251`
   - `20261115000009_missao02_1_residual_fixes.sql`: `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081`
   - `20261116000010_missao02_3_surgical_fixes.sql`: `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa`
   - `20261117000011_missao02_4_adversarial_fixes.sql`: `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e`
   - `20261118000012_missao02_5_integrity_closure.sql`: `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c`
   - `20261119000013_missao02_6_post_cancel_idempotency.sql`: `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc`
   - `20261120000014_missao02_7_lineage_persistence_and_hardening.sql`: `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4`
   - `20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql`: `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201`
   - `20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql`: `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6`
   - `20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql`: `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e`
   - `20261124000018_missao02_12_legacy_lineage_compatibility_and_hmac_key_lifecycle.sql`: `b948b7768c8b97908bb9480557ab10325883be60d66b2859b42b9d5347537cda`

---

## 2. Auditoria Inicial Obrigatória do Fluxo de Reservas (Seção 3)

A inspeção completa de `src/App.tsx`, `src/lib/bookingService.ts`, `src/lib/runtimeConfig.ts`, `src/lib/supabaseClient.ts`, `src/types/database.types.ts` e das migrations `000001` a `000018` identificou os pontos abaixo:

| Funcionalidade | Situação atual (Base `02.15.3`) | Problema | Correção necessária |
| :--- | :--- | :--- | :--- |
| **Consulta de passeios** | `fetchAuthorizedCatalogAndBookings` carrega `partners`, `destinations`, `vessels`, `tours`, `availability_blocks` e `reviews` aprovados quando `isSupabaseConfigured === true`. | Horários de saída/retorno e check-in não eram expostos na resposta da RPC de disponibilidade para alimentar o modal de reserva em tempo real. | Incluir `departure_time`, `return_time`, `check_in_time` e `departure_point` no retorno de `public.get_tour_availability` e sincronizar com o modal de reserva. |
| **Consulta de disponibilidade** | Existia a RPC `public.get_tour_availability(p_tour_id, p_booking_date)` no banco, porém `src/App.tsx` calculava disponibilidade apenas localmente sobre `bookings` em memória. | Como RLS bloqueia leitura de `public.bookings` para turistas anônimos (`effectiveRole === 'tourist'`), `bookings` vinha vazio (`[]`) para visitantes e a interface ignorava a ocupação real de outros clientes no servidor; além disso, a RPC usava a data fixa `'2026-11-08'` como referência de passado. | Substituir a referência fixa `'2026-11-08'` por `public.current_brazil_date()` (`America/Sao_Paulo`) na RPC `get_tour_availability` e acionar `rpcGetTourAvailability` em `src/App.tsx` sempre que passeio/data mudarem em modo conectado (`isSupabaseConfigured`). |
| **Seleção de data** | `src/App.tsx` inicializava `bookingForm.date`, `searchDate` e `newBlock.blockDate` com strings fixas (`'2026-11-20'`, `'2026-11-28'`) e usava `min="2026-11-08"` nos inputs `<input type="date">`. | Datas fixas permitiam selecionar datas passadas após `2026-11-08` e exibiam datas estáticas de novembro de 2026 independentemente da data real de operação. | Criar `getBrazilCurrentDateIso()` e `addDaysToIsoDate()` em `bookingService.ts` (`America/Sao_Paulo`), inicializar seletores com datas dinâmicas futuras e aplicar `min={todayBrazilIso}` em todos os seletores de data e validação pré-envio (`isBookingDateValidInBrazil`). |
| **Criação de reserva** | `handleCreateBooking` em `src/App.tsx` chamava `rpcCreateBookingRequest`, mas não passava `idempotencyKey` nem possuía trava de botão (`isSubmittingBooking`) durante a requisição. | Cliques rápidos consecutivos podiam disparar duas chamadas RPC sem `p_idempotency_key` antes do retorno da primeira requisição. | Adicionar estado `isSubmittingBooking` bloqueando reenvio de UI, gerar `idempotencyKey` determinística no cliente (`generateClientBookingIdempotencyKey`) e enviá-la em `rpcCreateBookingRequest`. |
| **Persistência** | Em modo conectado (`isSupabaseConfigured`), `create_booking_request` grava em `public.bookings`, `public.booking_status_history`, `public.commission_ledger` e `public.audit_logs`. | Faltava persistir o autenticador criptográfico de consulta pública do turista (`lookup_token_hmac` + `lookup_token_hmac_version`) junto à reserva. | Adicionar colunas `lookup_token_hmac` (64 hex) e `lookup_token_hmac_version` em `public.bookings` com constraint `bookings_lookup_token_hmac_Check`, populando-as atomicamente em `create_booking_request` e realizando backfill nas reservas existentes. |
| **Idempotência** | O banco já possuía linhagem criptográfica HMAC-SHA-256 (`000013`–`000018`), mas `bookingService.ts` não enviava `p_idempotency_key` a partir da UI pública e o replay idempotente não retornava o `lookup_token`. | Em caso de queda de conexão ou retry com a mesma chave de idempotência, o turista precisava receber o mesmo `lookup_token` determinístico para guardar seu comprovante. | Derivar `lookup_token` via PRF HMAC-SHA-256 determinística vinculada ao segredo de versão da reserva (`internal_guard.generate_booking_lookup_token`) e retorná-lo tanto na criação quanto no replay idempotente autenticado. |
| **Consulta posterior** | Em `src/App.tsx`, a aba `Minhas Reservas` dependia de `bookings` carregado em memória ou de `user.id` autenticado; visitantes sem login perdiam a visualização da reserva ao atualizar a página (`F5`). | Turista anônimo ficava com `bookings = []` após `F5` porque RLS impede `SELECT` público direto em `public.bookings`. | Criar a RPC `public.lookup_booking_by_tourist_token(p_booking_code, p_lookup_token)` com rate-limiting e zero PII, persistir comprovantes sanitizados (`bookingCode` + `lookupToken`) em `localStorage` (`ubatuba_tourist_receipts_v1`), recarregar automaticamente do servidor após `F5` e oferecer formulário manual por `Código + Chave de Acesso`. |
| **Cancelamento** | Apenas `transition_booking_status` existia no banco, exigindo `auth.uid()` (turista logado, parceiro ou admin); turistas sem conta não conseguiam cancelar sua própria reserva. | Um turista que reservou pelo site sem criar conta não tinha RPC autenticada por credencial da reserva para solicitar cancelamento e liberar vagas da embarcação. | Criar a RPC `public.cancel_booking_by_tourist_token(p_booking_code, p_lookup_token, p_reason)` respeitando a hierarquia canônica de locks (`vessels -> pg_advisory_xact_lock -> bookings`), liberando vagas imediatamente, revertendo comissão (`REVERTIDA`) e suportando replay idempotente. |
| **Proteção de dados** | RLS já bloqueava leitura direta de `public.bookings` por `anon` e `authenticated` de terceiros. | Era necessário garantir que a nova consulta pública não permitisse enumeração sequencial de códigos `UBT-XXXX` nem retornasse telefone, e-mail, nome completo, UUIDs internos ou comissões. | Exigir `booking_code` + `lookup_token` (128 bits de entropia, `ubtk-<32hex>`), aplicar rate-limiting (`internal_guard.booking_lookup_rate_limits`: máx. 5 falhas / 15 min), retornar mensagem uniforme (`INVALID_LOOKUP_CREDENTIALS`) e expor somente campos operacionais do passeio. |

---

## 3. Datas e Disponibilidade Dinâmicas (Seção 4)

1. **Banco de Dados (`public.current_brazil_date()` e `public.get_tour_availability`)**:
   - Foi criada a função `public.current_brazil_date() RETURNS DATE` (`STABLE SECURITY INVOKER SET search_path = pg_catalog, public, pg_temp`), que retorna `(pg_catalog.now() AT TIME ZONE 'America/Sao_Paulo')::DATE`.
   - A RPC `public.get_tour_availability(p_tour_id TEXT, p_booking_date DATE)` foi atualizada na migration `000019` para:
     - Rejeitar datas nulas ou anteriores a `public.current_brazil_date()` com `available = false` e `reason = 'BOOKING_DATE_IN_PAST'` (eliminando a constante legada `'2026-11-08'`).
     - Retornar os horários e ponto de embarque reais cadastrados no passeio: `departure_time`, `return_time`, `check_in_time`, `departure_point`, além de `base_capacity`, `effective_capacity`, `occupied_passengers`, `remaining_seats`, `private_booked`, `shared_booked` e `reference_date`.
   - A RPC `public.create_booking_request` valida `IF p_booking_date < public.current_brazil_date() THEN RAISE EXCEPTION 'BOOKING_DATE_IN_PAST: ...'`.
2. **Frontend (`src/lib/bookingService.ts` e `src/App.tsx`)**:
   - Foram implementadas e exportadas `getBrazilCurrentDateIso(referenceDate?: Date)`, `addDaysToIsoDate(isoDate: string, daysToAdd: number)` e `isBookingDateValidInBrazil(bookingDateIso: string, referenceDate?: Date)` usando `Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' })`.
   - Todas as datas fixas (`'2026-11-08'`, `'2026-11-20'`, `'2026-11-28'`) foram removidas de `src/App.tsx`.
   - Os seletores de data (`searchDate`, `bookingForm.date`, `newBlock.blockDate`) utilizam `min={todayBrazilIso}` e consultam `rpcGetTourAvailability` em tempo real quando `isSupabaseConfigured === true`.

---

## 4. Criação de Reservas, Idempotência e Resiliência (Seções 5 e 6)

1. **Validação Server-Side e Recálculo Financeiro**:
   - `public.create_booking_request` valida no servidor: passeio existente e `APROVADO`, parceiro `APROVADO`, embarcação ativa, `p_booking_date >= public.current_brazil_date()`, `p_passengers >= 1`, nome (`>= 3` caracteres), telefone (`>= 8` dígitos), canal (`SITE_DIRECT` ou `WHATSAPP`) e disponibilidade real sob lock pessimista (`FOR UPDATE` na embarcação + `pg_advisory_xact_lock`).
   - Os valores financeiros (`v_unit_price`, `v_gross_amount`, `v_commission_amount`, `v_net_partner_amount`) são integralmente recalculados no servidor a partir de `public.tours` e `public.partners`, ignorando qualquer valor do cliente.
2. **Idempotência Determinística e Proteção contra Duplo Clique**:
   - Em `src/lib/bookingService.ts`, a função `generateClientBookingIdempotencyKey` gera uma chave determinística normalizada (`idemp-ubt-v1-...`, 16 a 64 caracteres) a partir de `(tourId, bookingDate, passengers, channel, customerPhone, customerEmail)`.
   - Em `src/App.tsx`, o botão de envio fica desabilitado durante `isSubmittingBooking === true`, impedindo cliques duplicados concorrentes na interface, e a chave determinística garante que reenvios ou quedas de rede após commit retornem a mesma reserva (`idempotent_replay = true`) com o mesmo `lookup_token`, sem duplicar ocupação nem lançamento no `commission_ledger`.
   - Quando `isSupabaseConfigured === true`, nenhuma reserva é confirmada visualmente se a RPC falhar.

---

## 5. Solução Adotada para Consulta Segura da Reserva pelo Turista (Seção 7)

Para atender simultaneamente aos requisitos de **persistência pós-refresh (`F5`) / reabertura do navegador** e **proteção absoluta contra enumeração e vazamento de PII (LGPD)**:

1. **Credencial Criptográfica de Alta Entropia (`lookup_token`)**:
   - Cada reserva recebe um token de consulta pública no formato `ubtk-<32 caracteres hexadecimais>` (128 bits de entropia criptográfica), derivado em `internal_guard.generate_booking_lookup_token(p_booking_id, p_booking_code, p_key_version)` via PRF HMAC-SHA-256 (RFC 2104) sobre a chave mestra da versão em `internal_guard.lineage_hmac_keys` com separação de domínio (`ubatuba:lookup_token_gen:v1`).
   - O `lookup_token` em texto puro **nunca é armazenado no banco de dados**: a tabela `public.bookings` armazena exclusivamente o verificador `lookup_token_hmac` (`HMAC-SHA-256` de 256 bits / 64 hex sob o domínio `ubatuba:lookup_token_verify:v1`) e `lookup_token_hmac_version`.
   - A comparação em `internal_guard.verify_booking_lookup_token_hmac` utiliza comparação em tempo constante (`internal_guard.constant_time_hex_equals`) e resolução $O(1)$ pela versão da chave (`lookup_token_hmac_version`).
2. **Proteção Anti-Enumeração e Rate-Limiting (`public.lookup_booking_by_tourist_token`)**:
   - A tabela `internal_guard.booking_lookup_rate_limits` (`FORCE ROW LEVEL SECURITY`, inacessível diretamente por `anon`, `authenticated` e `service_role`) contabiliza tentativas falhas por `booking_code` em janelas de 15 minutos.
   - Após **5 tentativas inválidas** dentro de 15 minutos, o código é bloqueado por 15 minutos (`error_code = 'LOOKUP_RATE_LIMIT_EXCEEDED'`).
   - Tentativas com código `UBT-XXXX` inexistente ou com `lookup_token` incorreto retornam exatamente a mesma estrutura e mensagem (`ok = false, error_code = 'INVALID_LOOKUP_CREDENTIALS'`), impedindo que um atacante descubra quais códigos `UBT-XXXX` existem no banco.
3. **Zero Exposição de Dados Pessoais (LGPD)**:
   - O payload de retorno de `public.lookup_booking_by_tourist_token` contém **apenas dados operacionais do passeio**: `booking_code`, `status`, `booking_date`, `passengers`, `channel`, `gross_amount`, `created_at`, `cancelled_at`, `cancel_reason`, `tour_title`, `tour_slug`, `tour_type`, `pricing_model`, `duration_hours`, `departure_time`, `return_time`, `check_in_time`, `departure_point`, `destination_name`, `vessel_name`, `vessel_type` e `partner_name`.
   - **Nenhum** dado pessoal ou interno (`customer_name`, `customer_phone`, `customer_email`, `id`, `tourist_user_id`, `idempotency_key`, `commission_amount`, `net_partner_amount`) é retornado na consulta pública.
4. **Persistência Pós-Refresh (`F5`) e Reabertura do Navegador**:
   - No navegador do turista, `saveTouristReceipt` armazena em `localStorage` (`ubatuba_tourist_receipts_v1`) apenas o recibo sanitizado (`bookingCode`, `lookupToken`, `tourTitle`, `bookingDate`, `createdAt`) — sem nome, sem telefone e sem e-mail.
   - Ao atualizar a página (`F5`) ou fechar e reabrir o navegador, `src/App.tsx` lê `loadTouristSavedReceipts()` e sincroniza automaticamente cada comprovante via `rpcLookupBookingByTouristToken`, exibindo o status atualizado na área **Minhas Reservas**, além de oferecer o formulário manual de consulta por `Código da Reserva (UBT-XXXX)` + `Chave de Acesso (ubtk-...)`.

---

## 6. Cancelamento Seguro pelo Turista (Seção 8)

1. **RPC `public.cancel_booking_by_tourist_token(p_booking_code, p_lookup_token, p_reason)`**:
   - Autentica o turista validando `p_booking_code` + `p_lookup_token` (incluindo verificação de rate-limit e HMAC-SHA-256 em tempo constante).
   - Adquire os locks na **ordem canônica obrigatória** (`STATIC-06`):
     1. `Lock #1`: `SELECT v.id FROM public.vessels v WHERE v.id = v_vessel_id FOR UPDATE`
     2. `Lock #2`: `PERFORM pg_catalog.pg_advisory_xact_lock(...)`
     3. `Lock #3`: `SELECT b.* FROM public.bookings b WHERE b.id = v_booking_id FOR UPDATE`
   - **Idempotência de Cancelamento**: Se a reserva já estiver `CANCELADA`, retorna `ok = true, status = 'CANCELADA', idempotent_replay = true` sem duplicar histórico ou auditoria.
   - **Bloqueio de Estados Finais**: Se a reserva estiver em `PASSEIO_REALIZADO` ou `RECUSADA`, rejeita o cancelamento com `BOOKING_CANCELLATION_NOT_ALLOWED`.
   - **Liberação de Vagas e Reversão de Comissão**: Para reservas ativas (`SOLICITADA`, `AGUARDANDO_CONFIRMACAO`, `CONFIRMADA`), emite os tokens internos `internal_guard.issue_token` (`bookings_write` e `ledger_write`), atualiza `status = 'CANCELADA'`, grava em `public.booking_status_history`, reverte o lançamento em `public.commission_ledger` para `REVERTIDA` e libera imediatamente as vagas da embarcação para novas reservas na mesma data.

---

## 7. Testes Realizados e Resultados Obtidos (Seções 10 e 13)

Todos os testes exigidos nas Seções 10 e 13 foram executados e aprovados com código de saída `0`:

| Comando / Suíte Executada | Escopo Validado | Resultado | Código de Saída |
| :--- | :--- | :--- | :--- |
| `python3 supabase/tests/test_runner_destructive_guards.py` | `GUARD-00` a `GUARD-15`: travas anti-destruição do runner PostgreSQL | **16/16 APROVADOS** | `0` |
| `python3 supabase/tests/verify_pg_contracts_and_ast.py` | `STATIC-01` a `STATIC-19`: 19 migrations parseadas, 52 funções (`42 SD + 10 SI`), 13 rotinas com ordem canônica de locks, 118 bindings SQL x TS, transpilação AST Babel de todos os módulos TS/JSX e contratos da Missão `02.16` | **19/19 APROVADOS** | `0` |
| `python3 supabase/tests/run_isolated_test_suite.py` | `42/42` suítes comportamentais completas, incluindo as 4 novas suítes da Missão `02.16`:<br>- `M02.16-AVAILABILITY-DYNAMIC-DATES-05` (5/5 cenários: data futura, bloqueio manutenção, lotação máxima, conflito privativo, data passada `BOOKING_DATE_IN_PAST`)<br>- `M02.16-BOOKING-AND-IDEMPOTENCY-09` (9/9 cenários: `SITE_DIRECT`, `WHATSAPP`, 5 bloqueios de entrada inválida, duplo clique/retry idempotente com mesmo `lookup_token`, nova reserva pós-cancelamento `g0001`)<br>- `M02.16-PUBLIC-LOOKUP-RATE-LIMIT-AND-ZERO-PII-07` (7/7 verificações: consulta imediata, persistência pós-refresh `F5` / reabertura em Node.js, erro uniforme `INVALID_LOOKUP_CREDENTIALS`, bloqueio rate-limit após 5 falhas, 0 PII/comissão exposta)<br>- `M02.16-SECURE-TOURIST-CANCELLATION-04` (4/4 cenários: cancelamento válido, liberação imediata de vagas + comissão `REVERTIDA`, replay idempotente, bloqueio sem permissão ou pós-passeio) | **42/42 APROVADOS** | `0` |
| `node scripts/test_runtime_demo_guard.mjs` | `7/7` cenários positivos, negativos e estruturais do bloqueio de modo demonstrativo em produção (`runtimeConfig.ts`) | **7/7 APROVADOS** | `0` |
| `npm test` | Pipeline integrada completa de testes do projeto | **APROVADO** | `0` |
| `npm run lint` | Validação estrutural, configurações JSON, `@babel/*`, segredos `VITE_` e proteção anti-demo | **APROVADO** | `0` |

---

## 8. Lista de Arquivos Modificados/Criados e Hashes SHA-256 (Seção 14)

| Arquivo | Ação | SHA-256 |
| :--- | :--- | :--- |
| `supabase/migrations/20261125000019_missao02_16_dynamic_dates_and_secure_tourist_lookup.sql` | Criado (Migration `000019`) | `0e41c7a657b89e1dc852f077ca02f05d299132ea84a7f02227050fda85614d76` |
| `src/types/database.types.ts` | Modificado | `c36b203dbd9ce81eaa1b5209a072536547419ca98a479f4069572039e6535571` |
| `src/lib/bookingService.ts` | Modificado | `5f873180d970e701dad51548fb5520686e54a6073dd84119499c859b92ed8c0b` |
| `src/App.tsx` | Modificado | `138a1eddb2bfd17a8ece25bab847ee6dfed57e64f0ac0ba562a9a4de1c77aca0` |
| `supabase/tests/function_inventory.json` | Modificado (`52` funções ativas) | `30e343239635714003edb5537022be350a28141a4e595318f1eb2a6979a749a6` |
| `supabase/tests/run_postgresql_homologation.sh` | Modificado (`19` migrations na lista de aplicação) | `2fefedbc2ff784462e9b380cffa5374e62a979e976b5471cfd906f42cefd1e2c` |
| `supabase/tests/homologacao_postgresql_real.sql` | Modificado (adicionado bloco `T9.26` para homologação PostgreSQL real da `000019`) | `763ab7183c1ef7a3fdc090aa7fac09cf23462526e4b22658df574dd941af8653` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | Modificado (adicionado `STATIC-19`) | `5e589adae19bf3d57a64635e81f402d376b767eba916ad47fdabad3b8358d30f` |
| `supabase/tests/run_isolated_test_suite.py` | Modificado (adicionadas suítes `37` a `40` da Missão `02.16`) | `b33214bd23e470b075f393467bb4704facd5b1589b456d430d67b9c7e83ea1da` |
| `package.json` | **Preservado Intacto (Seção 12)** | `cc6a6ebfb5cf61554e8365e046284d74a0051858f4c700c263d9c9ceed9fd379` |
| `package-lock.json` | **Preservado Intacto (Seção 12)** | `ef02719ab11085138289fc2ced51b4aec12c5f8a52a5594df5e9a574e276c013` |

---

## 9. Limites de Escopo Respeitados e O Que Falta para as Próximas Missões (Seções 12 e 14)

Em estrita conformidade com a **Seção 12 (Limites de Escopo)**, esta missão **não** implementou gateway de pagamento, **não** alterou o painel administrativo além do necessário para compatibilidade com reservas e **não** modificou `package.json` nem `package-lock.json`.

**Próximas etapas planejadas (Missões C a G do Plano de Prontidão Comercial `02.14`)**:
- **Missão C (Operação do Parceiro e Painel Administrativo)**: Fluxo completo de gestão operacional pelo parceiro/marinheiro (confirmação/recusa com notificação, gestão de embarcações/passeios e conciliação de repasses no painel).
- **Missão D (Autenticação, Recuperação de Senha e Onboarding de Parceiros)**: Fluxos de login/cadastro com verificação de e-mail, redefinição de senha e aprovação cadastral de novos operadores náuticos.
- **Missão E (Pagamentos e Liquidação Financeira)**: Integração com meio de pagamento (Pix / cartão via gateway), webhook transacional autenticado e conciliação automática com `public.commission_ledger`.
- **Missão F (Notificações Transacionais e WhatsApp Oficial)**: Disparo automatizado de comprovantes (`UBT-XXXX` + `ubtk-...`), lembretes de check-in e alertas de mudança de status.
- **Missão G (Homologação em Staging Conectado ao Supabase Cloud e Go-Live na Vercel)**: Execução de `npm ci && npm run build`, aplicação das 19 migrations no projeto Supabase de produção/staging e smoke tests E2E pós-deploy.
