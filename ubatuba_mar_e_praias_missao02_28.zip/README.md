# Ubatuba Mar & Praias — Marketplace Náutico Multi-Parceiro

Plataforma completa de Turismo Náutico, Lanchas Privativas, Escunas Tradicionais e Guia Georreferenciado de Ubatuba/SP, construída em React + TypeScript + Tailwind CSS e preparada para produção com **Supabase (PostgreSQL, Auth, Row Level Security, Storage e Edge Functions)** e fallback local persistente (`localStorage`).

## Estrutura do Projeto

- `src/App.tsx`: Aplicação principal completa com os 9 módulos, modais, motor de reservas anti-overbooking, motor financeiro de comissões exato, rastreamento de reservas pelo turista, gestão de frota/agenda do parceiro e governança administrativa com logs de auditoria.
- `src/lib/supabaseClient.ts`: Cliente Supabase com detecção automática de variáveis de ambiente (`VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`).
- `supabase/migrations/20261108000001_initial_schema.sql`: Schema PostgreSQL com as 19 tabelas relacionais, ENUMs, constraints `CHECK`/`UNIQUE`, FKs `ON DELETE RESTRICT` e triggers de integridade.
- `supabase/migrations/20261108000002_rls_and_rpcs.sql`: Funções de autorização (`is_admin`, `is_partner_member`) e políticas RLS Multi-Tenant.
- `supabase/functions/whatsapp-lead-tracker/index.ts`: Edge Function para geração dinâmica e segura de links de WhatsApp por parceiro e integração server-side.

## Como Executar Localmente

1. Instale as dependências:
   ```bash
   npm install
   ```
2. Copie `.env.example` para `.env.local` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` (opcional: sem `.env.local`, o sistema opera com persistência automática em `localStorage`).
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
