# ARGON 4 — RELATÓRIO TÉCNICO DE AUDITORIA ADVERSARIAL INDEPENDENTE E CORREÇÃO CIRÚRGICA — MISSÃO 02.10
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)  
**Missão:** 02.10 — Auditoria Independente da Migration 000016 — Validação Criptográfica, HMAC, CSPRNG, `search_path` e Privilégios  
**Base Recebida:** `ubatuba_mar_e_praias_missao02_9_corrigido.zip` (`1.392.815 bytes` | `66 arquivos` | SHA-256 `1b08454e7b395ae4fe5e94e5d633a40f40e1cf6649105800dc744fa4daac6a38`)  
**Classificação Final (Seção 11):** **APROVADO COM PENDÊNCIAS DOCUMENTADAS**

## SEÇÃO A — PROVENIÊNCIA, BACKUP E ACHADOS COMPROVADOS ANTES DAS CORREÇÕES

1. **Verificação de Proveniência da Base (`02.9`):**
   - **Arquivo recebido:** `ubatuba_mar_e_praias_missao02_9_corrigido.zip`
   - **Tamanho:** `1.392.815 bytes`
   - **Quantidade de arquivos:** `66`
   - **SHA-256 (64 hex):** `1b08454e7b395ae4fe5e94e5d633a40f40e1cf6649105800dc744fa4daac6a38` (100% idêntico ao hash esperado na especificação da Missão 02.10)
   - **Integridade do arquivo ZIP (`zipfile.testzip()`):** `None` (`0` erros)
   - **Backup integral pré-Missão 02.10:** `ubatuba_mar_e_praias_missao02_9_corrigido_BACKUP_PRE_02_10.zip` (`1.392.815 bytes` | SHA-256 `1b08454e7b395ae4fe5e94e5d633a40f40e1cf6649105800dc744fa4daac6a38`)

2. **Achados Comprovados na Inspeção Direta de `000016` e Arquivos Modificados (Seções 2 e 9):**
   A inspeção direta do código SQL de `supabase/migrations/20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql` (sem aceitar as conclusões do relatório 02.9 como prova) comprovou **5 defeitos reais (`M02.10-F01` a `M02.10-F05`)**:

| ID | Severidade | Seção | Evidência no Código de `000016` e Cenário de Exploração | Correção Mínima Aplicada (`000017` e Testes) |
|---|---|---|---|---|
| **M02.10-F01** | **CRÍTICA (P0)** | 3.1 | 1) `compute_lineage_mac` (`000016` L160–165) não implementava HMAC (RFC 2104), e sim duas cadeias proprietárias de `md5(...)` concatenadas (`v_out1 \|\| v_out2`), sem prefixo de comprimento entre `p_purpose` e `p_payload` (permitindo colisão de domínio se `p_purpose` ou `p_payload` contiver `':'`); 2) `verify_lineage_mac` (`000016` L201–203) continha o fallback incondicional `IF left(md5(p_payload), v_len) = p_expected_mac THEN RETURN true;`, permitindo que um atacante forjasse qualquer validação enviando o MD5 puro sem conhecer o segredo; 3) comparação `=` não era constant-time; 4) `require_active_hmac_secret()` não existia no SQL. | Em `000017`: substituição por **HMAC-SHA-256 padronizado (RFC 2104 / FIPS 198-1)** via `public.hmac(bytea, bytea, 'sha256')` da extensão `pgcrypto`, validado na migration contra os 4 vetores oficiais da IETF RFC 4231; framing canônico prefixado por comprimento (`v<ver>:<len(purpose)>:<purpose>:<len(payload)>:<payload>`); comparação byte a byte em tempo constante (XOR `#`); validação de comprimento exato por domínio e remoção do fallback de MD5 sem chave; criação de `internal_guard.require_active_hmac_secret()`. |
| **M02.10-F02** | **CRÍTICA (P0)** | 3.2 | Em `000016` (L107–108 e L248–249), a semente inicial e a rotação default geravam segredos via `md5(gen_random_uuid() \|\| clock_timestamp() \|\| random()) \|\| md5(txid_current() \|\| pg_backend_pid() \|\| gen_random_uuid())` em vez de CSPRNG `gen_random_bytes(32)`, e `rotate_lineage_hmac_key` não rejeitava strings não-hexadecimais ou segredos repetitivos/fracos (`repeat('a', 64)`). | Em `000017`: geração de segredos exclusivamente via `public.gen_random_bytes(32)` (256 bits reais de CSPRNG) com aborto fail-closed (`CSPRNG_FAILURE`) se indisponível; validação de formato hex (`^[0-9a-f]{64,128}$`), paridade de bytes e entropia mínima (`>= 8` símbolos hex distintos, bloqueio de padrões repetitivos/sequenciais); rotação imediata da chave `v1` da `000016` para `v2` CSPRNG. |
| **M02.10-F03** | **ALTA (P1)** | 3.3 / 7 | Em `000016` (L574, L580, L978, L1279, L1796), `v_root_hash24` e o sufixo de geração em `derive_idempotency_lineage_key` ainda usavam `left(md5(...), 24)` sem segredo, e `create_booking_request` não resolvia `v_root_hash24` através de múltiplas versões de chave após rotação. | Em `000017`: `LINEAGE_ROOT_V1` e `LINEAGE_GEN_V1` passam a usar `HMAC-SHA-256` via `compute_lineage_mac`, e `create_booking_request` / `backfill_and_verify_booking_lineage` verificam todas as versões habilitadas (`v_candidate_root_hashes`), impedindo que a rotação reinicie gerações. |
| **M02.10-F04** | **ALTA (P1)** | 4 / 4.1 | Em `000016` (L77–101 e L2161), `internal_guard.lineage_hmac_keys` não possuía `FORCE ROW LEVEL SECURITY`, não tinha índice único parcial para `is_current = true`, não tinha trigger impedindo exclusão da chave ativa/histórica com reservas dependentes ou mutação de `secret_material`, e concedia `GRANT ALL ON TABLE ... TO service_role`. | Em `000017`: `FORCE ROW LEVEL SECURITY` + política restritiva `lineage_hmac_keys_definer_only`; índice único parcial `uq_lineage_hmac_keys_single_active`; trigger `trg_protect_lineage_hmac_keys_lifecycle` (`KEY_DELETE_ACTIVE_FORBIDDEN`, `KEY_DELETE_DEPENDENT_RECORDS_EXIST`, `KEY_MATERIAL_IMMUTABLE`); `REVOKE ALL ON ALL TABLES IN SCHEMA internal_guard FROM PUBLIC, anon, authenticated, service_role`. |
| **M02.10-F05** | **ALTA (P1)** | 5 / 6 | 1) `internal_guard.rotate_lineage_hmac_key` (`000016` L217) incluía `public` no `search_path`; 2) `compute_lineage_mac` e `verify_lineage_mac` não possuíam guarda interna (`PG_CONTEXT`) contra chamadas diretas de oráculo por `anon`/`authenticated`; 3) `homologacao_postgresql_real.sql` (`T9.20b`/`T9.21b`) chamava `derive_idempotency_lineage_key` sob `SET LOCAL ROLE authenticated`. | Em `000017`: remoção de `public` do `search_path` de `rotate_lineage_hmac_key` (8/8 funções `internal_guard` sem `public` no `search_path`); reafirmação de `REVOKE CREATE ON SCHEMA public FROM PUBLIC, anon, authenticated`; guarda `PG_CONTEXT` (`UNAUTHORIZED_CRYPTO_ORACLE_CALL`); correção de `T9.20b`/`T9.21b` e adição de `T9.24` em `homologacao_postgresql_real.sql`. |

---

## SEÇÃO B — AUDITORIA CRIPTOGRÁFICA (SEÇÃO 3.1 E 3.3)

1. **Algoritmo Efetivo (`HMAC-SHA-256` — RFC 2104 / FIPS 198-1):**
   - Disponibilizado pela função nativa `public.hmac(data bytea, key bytea, 'sha256'::text)` da extensão oficial `pgcrypto` do PostgreSQL (instalada desde a migration `000001`).
   - Framing canônico com separação estrita de versão, domínio e payload por prefixo de comprimento:
     $$\text{Msg} = \text{UTF8}\big(\text{"v"} \parallel v_{\text{ver}} \parallel \text{":"} \parallel \text{len}(\text{purpose}) \parallel \text{":"} \parallel \text{purpose} \parallel \text{":"} \parallel \text{len}(\text{payload}) \parallel \text{":"} \parallel \text{payload}\big)$$
     $$\text{MAC} = \text{hex}\Big(\text{HMAC-SHA-256}\big(\text{key} = \text{decode}(\text{secret\_material}, \text{'hex'}), \text{data} = \text{Msg}\big)\Big)$$
   - A codificação por prefixo de comprimento garante injetividade: dois pares distintos $(\text{purpose}_1, \text{payload}_1) \neq (\text{purpose}_2, \text{payload}_2)$ jamais produzem a mesma mensagem canônica, mesmo que contenham `:` internos.

2. **Vetores Oficiais de Teste IETF RFC 4231 (Validados na Migration `000017`, em `T9.24` e em `run_isolated_test_suite.py`):**
   - **RFC 4231 Test Case 1:** `Key = 0x0b * 20`, `Data = "Hi There"`  
     `HMAC-SHA-256 = b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7`
   - **RFC 4231 Test Case 2:** `Key = "Jefe"`, `Data = "what do ya want for nothing?"`  
     `HMAC-SHA-256 = 5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843`
   - **RFC 4231 Test Case 3:** `Key = 0xaa * 20`, `Data = 0xdd * 50`  
     `HMAC-SHA-256 = 773ea91e36800e46854db8ebd09181a72959098b3ef8c122d9635514ced565fe`
   - **RFC 4231 Test Case 4:** `Key = 0x0102...19 (25 B)`, `Data = 0xcd * 50`  
     `HMAC-SHA-256 = 82558a389a443c0ea4cc819899f2083a85f0faa3e578f8077a2e3ff46729665b`

3. **Comparação em Tempo Constante e Validação Estrita de Formato:**
   - `internal_guard.verify_lineage_mac(p_purpose, p_payload, p_expected_mac)` exige que `p_expected_mac` obedeça simultaneamente a `p_expected_mac ~ '^[0-9a-f]+$'` e ao comprimento exato do domínio (`16` hex para `LGPD_IDEM_AUTH`, `20` hex para `LGPD_OWNER_SCOPE`, `24` hex para `LINEAGE_ROOT_V1` e `LINEAGE_GEN_V1`, `64` hex para `NATURAL_BOOKING_KEY`).
   - A comparação entre o candidato e `p_expected_mac` acumula o XOR byte a byte (`v_diff := v_diff | (pg_catalog.get_byte(v_cand_bytes, v_idx) # pg_catalog.get_byte(v_exp_bytes, v_idx))`) percorrendo todos os bytes sem curto-circuito.

4. **Análise Matemática Rigorosa da Truncagem (Seção 3.3):**
   - **Distinção entre Inversão (Pré-imagem), Falsificação (Forging) e Colisão:**
     - **Resistência à inversão e enumeração de dicionário:** Depende exclusivamente da **confidencialidade do segredo de 256 bits ($K$)** e da propriedade de PRF (Pseudo-Random Function) do `HMAC-SHA-256`, e **não** da truncagem. Truncar de 256 para 96 bits descarta 160 bits de saída; isso jamais aumenta a segurança contra um atacante que já possua $K$ (que ainda não pode inverter algebricamente o SHA-256, mas poderia testar candidatos previsíveis de baixa entropia como os $\approx 10^8$ telefones de um DDD). Sem o segredo $K$, entretanto, o atacante é incapaz de calcular o HMAC de qualquer candidato offline.
     - **Tamanho efetivo em bits e resistência à falsificação (Existential Forgery sem $K$, NIST SP 800-107 Rev. 1):**
       - `LINEAGE_ROOT_V1` e `LINEAGE_GEN_V1`: `24 hex = 96 bits` $\implies$ probabilidade de acerto por tentativa sem a chave é $2^{-96} \approx 1{,}26 \times 10^{-29}$.
       - `LGPD_OWNER_SCOPE`: `20 hex = 80 bits` $\implies$ probabilidade de acerto por tentativa é $2^{-80} \approx 8{,}27 \times 10^{-25}$.
       - `LGPD_IDEM_AUTH`: `16 hex = 64 bits` (sempre vinculado ao UUID único de 128 bits da reserva em `lgpd-<uuid32>-<mac16>`) $\implies$ probabilidade de acerto por tentativa é $2^{-64} \approx 5{,}42 \times 10^{-20}$.
     - **Resistência a colisões e escala suportada (Birthday Bound):**
       - Para o identificador de linhagem raiz (`24 hex = 96 bits`), o limite de aniversário (probabilidade de colisão de $50\%$) exige $\approx 1{,}18 \times 2^{96/2} = 1{,}18 \times 2^{48} \approx 3{,}31 \times 10^{14}$ chaves raiz distintas.
       - Em escala operacional de $N = 10^6$ (1 milhão) a $N = 10^7$ (10 milhões) de linhagens de reservas, a probabilidade de ocorrer ao menos uma colisão acidental em 96 bits é $P \approx \frac{N^2}{2 \cdot 2^{96}} \in [6{,}31 \times 10^{-18},\; 6{,}31 \times 10^{-16}]$, suportando com folga de mais de 7 ordens de grandeza a operação plurianual do marketplace.

---

## SEÇÃO C — GERAÇÃO DE SEGREDOS E CSPRNG (SEÇÃO 3.2)

1. **Fonte de Entropia e CSPRNG:**
   - Em `000017`, toda geração automática de segredos utiliza **exclusivamente `public.gen_random_bytes(32)`** (`pgcrypto` / OpenSSL `RAND_bytes` alimentado pelo CSPRNG do kernel `/dev/urandom` / `getrandom(2)`), produzindo 32 bytes (256 bits reais de entropia criptográfica) codificados em 64 caracteres hexadecimais minúsculos (`pg_catalog.lower(pg_catalog.encode(v_raw_bytes, 'hex'))`).
2. **Tratamento Fail-Closed de Falhas e Bloqueio de Segredos Fracos:**
   - Foi eliminada toda expressão baseada em `random()`, `clock_timestamp()`, `txid_current()`, `pg_backend_pid()` ou `md5()`.
   - Se `public.gen_random_bytes(32)` lançar exceção, retornar `NULL` ou retornar `octet_length <> 32`, `rotate_lineage_hmac_key` aborta imediatamente em modo fail-closed com `CSPRNG_FAILURE`.
   - Segredos fornecidos manualmente ou verificados por `require_active_hmac_secret()` passam por 4 validações obrigatórias:
     1. Comprimento par entre 64 e 128 caracteres (`INVALID_SECRET_LENGTH`);
     2. Apenas caracteres hexadecimais `[0-9a-f]` (`INVALID_SECRET_CHARACTERS`);
     3. Pelo menos 8 dígitos hexadecimais distintos nos primeiros 64 caracteres e ausência de repetições `^([0-9a-f])\1{15,}` ou sequências conhecidas como `0123456789abcdef...` e `a1b2c3d4...` (`WEAK_SECRET_MATERIAL_REJECTED`);
     4. Proibição de reutilizar segredo de versão anterior (`DUPLICATE_SECRET_MATERIAL_REJECTED`).

---

## SEÇÃO D — GESTÃO, ROTAÇÃO E RECUPERAÇÃO DE CHAVES (SEÇÕES 4 E 4.1)

1. **Isolamento da Tabela `internal_guard.lineage_hmac_keys`:**
   - Proprietário: `postgres` (superusuário/owner das migrations).
   - `ENABLE ROW LEVEL SECURITY` + `FORCE ROW LEVEL SECURITY` + política restritiva `lineage_hmac_keys_definer_only` (`USING (current_user IN ('postgres', 'supabase_admin'))`).
   - `REVOKE ALL ON TABLE internal_guard.lineage_hmac_keys FROM PUBLIC, anon, authenticated, service_role;` (nenhum papel de API, nem mesmo `service_role`, possui `SELECT`, `INSERT`, `UPDATE`, `DELETE` ou `TRUNCATE` direto sobre a tabela).
   - Índice único parcial `uq_lineage_hmac_keys_single_active ON internal_guard.lineage_hmac_keys (is_current) WHERE is_current = true` impede a existência de duas versões simultaneamente ativas.
   - Trigger `trg_protect_lineage_hmac_keys_lifecycle` (`BEFORE UPDATE OR DELETE`):
     - Bloqueia `DELETE` da chave ativa (`KEY_DELETE_ACTIVE_FORBIDDEN`), da última chave da tabela (`KEY_DELETE_LAST_KEY_FORBIDDEN`) ou de qualquer versão histórica enquanto existirem reservas dependentes (`KEY_DELETE_DEPENDENT_RECORDS_EXIST`).
     - Bloqueia `UPDATE` de `secret_material`, `key_version` ou `created_at` (`KEY_MATERIAL_IMMUTABLE`).
     - Bloqueia desativar `is_verify_enabled = false` enquanto existirem reservas dependentes (`KEY_DISABLE_DEPENDENT_RECORDS_EXIST`).

2. **Matriz de Privilégios Criptográficos e Modelo de Ameaça (Seção 6):**

| Objeto / Função | `PUBLIC` | `anon` | `authenticated` | `service_role` | `postgres` (Owner) | Guarda Interna Adicional |
|---|---|---|---|---|---|---|
| `internal_guard.lineage_hmac_keys` (Tabela) | `NONE` | `NONE` | `NONE` | `NONE` (`REVOKE ALL`) | `ALL` | `FORCE RLS` + Trigger anti-DELETE/anti-UPDATE de segredo |
| `internal_guard.require_active_hmac_secret()` | `NONE` | `NONE` | `NONE` | `EXECUTE` (retorna apenas `SMALLINT` `key_version`) | `EXECUTE` | Guarda `PG_CONTEXT` contra `anon`/`authenticated`; nunca retorna `secret_material` |
| `internal_guard.compute_lineage_mac(...)` | `NONE` | `NONE` | `NONE` | `EXECUTE` | `EXECUTE` | Guarda `PG_CONTEXT` contra oráculo direto por `anon`/`authenticated`; whitelist de 5 domínios |
| `internal_guard.verify_lineage_mac(...)` | `NONE` | `NONE` | `NONE` | `EXECUTE` | `EXECUTE` | Guarda `PG_CONTEXT` + comparação constant-time + comprimento exato por domínio |
| `internal_guard.rotate_lineage_hmac_key(...)` | `NONE` | `NONE` | `NONE` | `EXECUTE` | `EXECUTE` | Guarda de 4 fatores (`v_uid IS NULL`, `service_role`/`postgres`) + validação CSPRNG |
| `internal_guard.enforce_lineage_hmac_key_lifecycle()` | `NONE` | `NONE` | `NONE` | `EXECUTE` (Trigger) | `EXECUTE` | Executada como trigger `BEFORE UPDATE OR DELETE` |

   - **Modelo de Ameaça Documentado:** A revogação de `SELECT/INSERT/UPDATE/DELETE` em `internal_guard.lineage_hmac_keys` para `anon`, `authenticated` e `service_role` impede que tokens JWT de API (mesmo uma chave `service_role` usada pelo backend em chamadas PostgREST padrão) leiam `secret_material` diretamente via tabela. Contra um superusuário PostgreSQL (`postgres` / `supabase_admin` com acesso SQL arbitrário ao banco), nenhuma política RLS ou `REVOKE` no mesmo banco oferece isolamento absoluto, pois o superusuário possui `BYPASSRLS` e pode inspecionar páginas de disco ou alterar funções. Por isso, o backup e a custódia administrativa de `postgres` seguem o procedimento operacional abaixo.

3. **Procedimento Operacional de Rotação, Backup e Recuperação de Chaves:**
   - **Rotação periódica padrão:** Executar `SELECT internal_guard.rotate_lineage_hmac_key(NULL, false);` via conexão administrativa (`postgres` ou `service_role`). A versão anterior passa para `is_current = false, is_verify_enabled = true`, preservando o reconhecimento de todas as linhagens antigas sem reiniciar gerações.
   - **Backup seguro das chaves:** Exportar periodicamente o conteúdo de `internal_guard.lineage_hmac_keys` (`key_version, secret_material, is_current, is_verify_enabled, created_at, rotated_at`) via sessão administrativa `postgres` criptografada com GPG/KMS externo (cofre de segredos fora do banco).
   - **Recuperação em caso de perda de versão antiga:** Restaurar a linha correspondente `(key_version, secret_material, false, true)` a partir do backup KMS externo; caso uma versão antiga seja permanentemente perdida e não haja backup, as reservas ativas ou já anonimizadas permanecem íntegras e sem exposição de PII, e uma nova reserva com chave raiz antiga iniciará uma linhagem autenticada sob a versão ativa atual após `backfill_and_verify_booking_lineage()`.

---

## SEÇÃO E — AUDITORIA DE `SECURITY DEFINER` E `search_path` (SEÇÃO 5)

1. **Privilégios do Schema `public` e Prevenção de Shadowing:**
   - Confirmado e reafirmado em `000017`: `REVOKE CREATE ON SCHEMA public FROM PUBLIC, anon, authenticated;` e `REVOKE ALL ON SCHEMA internal_guard FROM PUBLIC, anon, authenticated;`. Nenhum papel não confiável (`PUBLIC`, `anon`, `authenticated`) pode criar tabelas, funções, tipos ou operadores no schema `public` ou `internal_guard`.
   - Todas as **47 funções ativas** (`37 SECURITY DEFINER` + `10 SECURITY INVOKER`) possuem `SET search_path` iniciando explicitamente por **`pg_catalog`** e terminando explicitamente por **`pg_temp`** (`SET search_path = pg_catalog, ... , pg_temp`).
   - Posicionar `pg_catalog` **antes** de `public` e `pg_temp` **por último** impede que objetos temporários (`pg_temp`) ou objetos de usuário façam shadowing de funções nativas (`lower`, `btrim`, `encode`, `decode`, `get_byte`, `regexp_replace`, `coalesce`) ou operadores (`=`, `||`, `#`).
   - Todas as **8 funções do schema `internal_guard`** (`issue_token`, `consume_token`, `cleanup_tokens`, `require_active_hmac_secret`, `compute_lineage_mac`, `verify_lineage_mac`, `rotate_lineage_hmac_key`, `enforce_lineage_hmac_key_lifecycle`) operam com `SET search_path = pg_catalog, internal_guard, pg_temp` (**sem o schema `public` no `search_path`**), qualificando explicitamente `public.hmac`, `public.gen_random_bytes` e `public.bookings`.

2. **Matriz Individual das Funções Criadas ou Alteradas na Migration `000016` / `000017` (e Consolidação das 47 Funções Ativas):**

| # | Schema.Função | Tipo | `search_path` Efetivo em `000017` | Alterada em `000017`? | Motivo / Hardening Aplicado |
|---|---|---|---|---|---|
| 01 | `internal_guard.require_active_hmac_secret` | DEFINER | `pg_catalog, internal_guard, pg_temp` | **SIM (Nova)** | Valida unicidade, formato hex e entropia da chave ativa; guarda `PG_CONTEXT`. |
| 02 | `internal_guard.compute_lineage_mac` | DEFINER | `pg_catalog, internal_guard, pg_temp` | **SIM** | Substituído duplo-MD5 por `HMAC-SHA-256` (`public.hmac`) com framing de comprimento e guarda `PG_CONTEXT`. |
| 03 | `internal_guard.verify_lineage_mac` | DEFINER | `pg_catalog, internal_guard, pg_temp` | **SIM** | Comparação constant-time, comprimento exato por domínio e remoção do fallback MD5 sem segredo. |
| 04 | `internal_guard.rotate_lineage_hmac_key` | DEFINER | `pg_catalog, internal_guard, pg_temp` | **SIM** | Removido `public` do `search_path`; geração estrita via `public.gen_random_bytes(32)` fail-closed. |
| 05 | `internal_guard.enforce_lineage_hmac_key_lifecycle` | DEFINER | `pg_catalog, internal_guard, pg_temp` | **SIM (Nova)** | Trigger `BEFORE UPDATE OR DELETE` impedindo exclusão de chaves ou mutação de `secret_material`. |
| 06 | `internal_guard.issue_token` | DEFINER | `pg_catalog, internal_guard, pg_temp` | Não (`000016`) | Rejeita nulos/vazios e substitui token anterior na mesma `(txid, depth, scope, target_id)`. |
| 07 | `internal_guard.consume_token` | DEFINER | `pg_catalog, internal_guard, pg_temp` | Não (`000016`) | Consumo atômico single-use sem curinga `expected_state` e com `trigger_depth = pg_trigger_depth() - 1`. |
| 08 | `internal_guard.cleanup_tokens` | DEFINER | `pg_catalog, internal_guard, pg_temp` | Não (`000006`) | Limpeza transacional pós-operação. |
| 09 | `public.derive_idempotency_lineage_key` | INVOKER | `pg_catalog, public, internal_guard, pg_temp` | **SIM** | Substituído `md5` sem chave por `HMAC-SHA-256` (`LINEAGE_ROOT_V1` e `LINEAGE_GEN_V1`). |
| 10 | `public.backfill_and_verify_booking_lineage` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | **SIM** | Usa `LINEAGE_ROOT_V1` e `verify_lineage_mac` multi-versão em vez de `md5` sem chave. |
| 11 | `public.admin_anonymize_customer_pii` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | **SIM** | Usa `LINEAGE_ROOT_V1` (`HMAC-SHA-256`) também para `v_root_hash24`. |
| 12 | `public.create_booking_request` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | **SIM** | Usa `LINEAGE_ROOT_V1`/`LINEAGE_GEN_V1` e resolve `v_candidate_root_hashes` em todas as versões de chave. |
| 13 | `public.enforce_booking_invariants_and_transitions` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | Não (`000016`) | Bloqueia 32 colunas sob `LINEAGE_BACKFILL`, impede downgrade LGPD e valida tokens. |
| 14 | `public.handle_updated_auth_user` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | Não (`000016`) | Emite token `AUTH_PROFILE_SYNC` + `cleanup_tokens()`. |
| 15 | `public.sync_booking_history_ledger_and_audit` | DEFINER | `pg_catalog, public, internal_guard, pg_temp` | Não (`000016`) | Emite token `LEDGER_SYNC` + `cleanup_tokens()`. |
| 16–47 | Demais 32 funções (`25 DEFINER` + `7 INVOKER`) | Misto | `pg_catalog, public, [internal_guard,] pg_temp` | Preservadas | 100% com `pg_catalog` em 1º lugar, `pg_temp` por último e `REVOKE ALL FROM PUBLIC, anon, authenticated`. |

---

## SEÇÃO F — AUDITORIA DE REGRESSÃO E DISTINÇÃO RIGOROSA DE AMBIENTES DE TESTE (SEÇÃO 7)

1. **Distinção Metodológica Obrigatória entre Categorias de Teste:**
   - **Testes Estáticos e de AST (`verify_pg_contracts_and_ast.py`):** Analisam o código SQL das 17 migrations, o inventário de 47 funções, contratos de colunas/enums, scripts CI e transpilação AST TypeScript/JSX. **Limitação:** Não executam o motor de banco de dados PostgreSQL.
   - **Testes de Guarda do Runner (`test_runner_destructive_guards.py`):** Validam em bash/subshell o bloqueio pré-conexão e intra-sessão contra conexões remotas, bancos de produção e parâmetros proibidos na `DATABASE_URL`.
   - **Testes Comportamentais Isolados (`run_isolated_test_suite.py`):** Executam a lógica de negócios, concorrência por threads, máquina de estados, backfill, tokens e criptografia `HMAC-SHA-256` (`hmac` + `hashlib.sha256` + `os.urandom(32)` + SQLite em memória). **Limitação importante:** Simulações isoladas em Python/SQLite validam a lógica algorítmica e os vetores RFC 4231, mas **não substituem** a execução real do catálogo `pg_proc`, `pgcrypto`, RLS e triggers no motor PostgreSQL 15+ real.
   - **Homologação em PostgreSQL 15+ Real (`homologacao_postgresql_real.sql` via `run_postgresql_homologation.sh`):** Contém os blocos `PG-01` a `PG-14`, `T8.1` a `T8.15` e `T9.1` a `T9.24` para execução direta em instância PostgreSQL 15+ descartável (permanece **PENDENTE** de execução na etapa dedicada de homologação).

2. **Resultados Reais Executados nesta Missão:**
   - `python3 supabase/tests/test_runner_destructive_guards.py` $\implies$ **`16/16 APROVADOS`** (`exit code 0`).
   - `python3 supabase/tests/verify_pg_contracts_and_ast.py` $\implies$ **`17/17 STATIC PASS (STATIC-01 A STATIC-17)`** (`exit code 0`).
   - `python3 supabase/tests/run_isolated_test_suite.py` $\implies$ **`35/35 TESTES APROVADOS`** (`exit code 0`), incluindo:
     - Reexecução integral dos **14 cenários de linhagem LGPD** (`M02.9-ADVERSARIAL-LINEAGE-LGPD-14`), **12 cenários de backfill** (`M02.9-BACKFILL-12`) e **10 cenários de tokens internos** (`M02.9-TOKENS-10`);
     - **`M02.10-CRYPTO-RFC4231-AND-HMAC-SHA256`:** 4/4 vetores oficiais IETF RFC 4231, paridade exata do framing `HMAC-SHA-256`, isolamento dos 5 domínios, bloqueio do fallback `md5(payload)` sem segredo e rejeição de formatos/comprimentos inválidos;
     - **`M02.10-KEY-LIFECYCLE-PRIVILEGES-AND-REGRESSION-18`:** Todos os **18 cenários exigidos na Seção 7** aprovados (`18/18`): (1) MAC correto, (2) MAC adulterado, (3) segredo incorreto, (4) versão inexistente, (5) rotação com registros antigos, (6) rotação interrompida com rollback, (7) segredo com comprimento inválido, (8) segredo com caracteres inválidos/baixa entropia, (9) falha de CSPRNG fail-closed, (10) bloqueio de acesso/exclusão/mutação direta na tabela de segredos, (11) bloqueio de chamadas internas por `anon`, (12) bloqueio por `authenticated`, (13) bloqueio de `CREATE` no schema `public`, (14) proteção de `search_path` em `SECURITY DEFINER`, (15) não-reintrodução de PII pós-anonimização/backfill, (16) não-reinicialização de gerações após múltiplas rotações, (17) rejeição de entradas arbitrárias sem fallback legado incondicional e (18) bloqueio de falsificação de chave antiga por prefixo.

---

## SEÇÃO G — ARQUIVOS ALTERADOS E NOVOS (CAMINHO, MOTIVO, TAMANHO E SHA-256 ANTES VS DEPOIS)

| Caminho do Arquivo | Motivo Técnico da Alteração / Criação | Tamanho Antes | SHA-256 Antes (64 hex) | Tamanho Depois | SHA-256 Depois (64 hex) |
|---|---|---:|---|---:|---|
| `supabase/migrations/20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql` | Nova migration incremental `000017` com `HMAC-SHA-256` (RFC 2104 / 4 vetores RFC 4231), CSPRNG `gen_random_bytes(32)`, `FORCE RLS`, trigger de proteção de chaves e hardening de `search_path` / privilégios. | `0 B` | `N/A (NOVO ARQUIVO)` | `87.957 B` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` |
| `supabase/tests/run_postgresql_homologation.sh` | Inclusão da migration `000017` na instalação inicial (`PG-01`) e na reaplicação transacional atômica (`PG-02`). | `28.447 B` | `858aa687d81ce38abda5c7f17e3cc733683659222caa91eec970539b341d5629` | `28.692 B` | `536054f7d0ac571d8b3359d4eda72c18bc1dca09e955a2f5b4b2019e79abc6a9` |
| `supabase/tests/function_inventory.json` | Adição do snapshot cumulativo `cumulative_active_after_000017` (`47` funções ativas: `37 SECURITY DEFINER` + `10 SECURITY INVOKER`). | `317.266 B` | `7350c96157a9b3b50574fc9d5b4d84afc5c52c3ef877b014924b4d8f051560f1` | `330.843 B` | `d481de50a46638d0fdfa34cfaf1611cfabc10c0da2a1342b3d14c09681a99ea4` |
| `supabase/tests/homologacao_postgresql_real.sql` | Correção de role em `T9.20b`/`T9.21b` e adição do bloco `T9.24` (validação PostgreSQL de RFC 4231, CSPRNG, proteção anti-DELETE de chaves e rejeição de MD5 sem chave). | `118.308 B` | `02ff185197bc8f907765a405a6e742e7dd7839c2131824adc4e3296f14d09265` | `120.191 B` | `81406d80f038d92a893126c7a6eff5a7b94ee3292f8cb70244d0f3da8574f803` |
| `supabase/tests/verify_pg_contracts_and_ast.py` | Validação cruzada da migration `000017`, inventário de 47 funções e check estático `STATIC-17`. | `48.643 B` | `5a5d81293ab46c66cfb1483564cbe2d530054190b6f7d0a878421f17db5eb6c8` | `52.317 B` | `23022cfbfa57f941136520385c5e699273b20265ec11fcd8f6cd1a0e96e85d74` |
| `supabase/tests/run_isolated_test_suite.py` | Atualização para `HMAC-SHA-256` RFC 2104, CSPRNG `os.urandom(32)`, `compare_digest` e adição das suítes 32 (RFC 4231) e 33 (18 cenários da Seção 7). | `248.657 B` | `36a91a8a813ad6aa00296f978dafd59545d1d9a23f857afe6e01771132b049c5` | `273.692 B` | `988d44cb69c7677a0021197a12c5c45ac6a9ec919f8244e8f25bf8424f430ee5` |

---

## SEÇÃO H — INTEGRIDADE DAS MIGRATIONS (`000001` A `000017`)

Todas as **16 migrations históricas (`000001` a `000016`) foram preservadas byte a byte** sem nenhuma modificação:

| Migration | Tamanho | SHA-256 (64 hex) | Status |
|---|---:|---|---|
| `20261108000001_initial_schema.sql` | `17.194 B` | `de760ab7453f85e85c5068ef5a2c204d9f43648740802d6877da098be4b78198` | **PRESERVADA BYTE A BYTE** |
| `20261108000002_rls_and_rpcs.sql` | `3.875 B` | `223b5cc0a92aa65814f75b59f6ce77c782f56eee5a06251f041e8eaa08e6ad8f` | **PRESERVADA BYTE A BYTE** |
| `20261110000003_missao01_audit_fixes_and_rpcs.sql` | `120.783 B` | `6fd8edf50554997298461361a51c2680cf09d0e92dc267e86619ae2c8d474d4a` | **PRESERVADA BYTE A BYTE** |
| `20261110000004_missao01_official_catalog_seed.sql` | `14.727 B` | `171b834558c06363af49260c21593ff5f249eb571502a647904dca99d24008ef` | **PRESERVADA BYTE A BYTE** |
| `20261111000005_missao01_4_forensic_hardening.sql` | `58.943 B` | `6f6dfb3713275c579042ffa3fc2e0a0754cb33e213c732d036a82dff16877e4f` | **PRESERVADA BYTE A BYTE** |
| `20261112000006_missao01_6_forensic_fixes.sql` | `54.113 B` | `d408b5f9705c24481bb93c356cd7b9b2d58935c43d9bc3cbb0359a802091f99a` | **PRESERVADA BYTE A BYTE** |
| `20261113000007_missao01_8_controlled_fixes.sql` | `64.902 B` | `dfac1fdf05e851b82ceb66f32590ac70a25e7447956033799aca53310bf35425` | **PRESERVADA BYTE A BYTE** |
| `20261114000008_missao01_9_controlled_fixes.sql` | `36.333 B` | `fe1f0ae3313f824082a9ffe301efa4440d42947010ad212bea5af03021c99251` | **PRESERVADA BYTE A BYTE** |
| `20261115000009_missao02_1_residual_fixes.sql` | `49.149 B` | `131be3f30dc3b5f89be9dfaed77426b7a02721fed2c230521d97d832a9faa081` | **PRESERVADA BYTE A BYTE** |
| `20261116000010_missao02_3_surgical_fixes.sql` | `106.563 B` | `594f7fad0dcb9ecfffa4e5bfc08aa0bdfcb055291bea187417f5b74fafa40dfa` | **PRESERVADA BYTE A BYTE** |
| `20261117000011_missao02_4_adversarial_fixes.sql` | `113.335 B` | `5eb66ea5251fe64e7e180d7f40ac348892125b95b50becae42168175247e8d7e` | **PRESERVADA BYTE A BYTE** |
| `20261118000012_missao02_5_integrity_closure.sql` | `62.476 B` | `d85a76cd52c494822eefdb14d4924ee3980296e2120e3d13017b28735a20555c` | **PRESERVADA BYTE A BYTE** |
| `20261119000013_missao02_6_post_cancel_idempotency.sql` | `25.201 B` | `cc310bd4132c302b3021051e11835c74e0f7e8cae3be713eebadf9f2ede349dc` | **PRESERVADA BYTE A BYTE** |
| `20261120000014_missao02_7_lineage_persistence_and_hardening.sql` | `54.907 B` | `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4` | **PRESERVADA BYTE A BYTE** |
| `20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql` | `66.466 B` | `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201` | **PRESERVADA BYTE A BYTE** |
| `20261122000016_missao02_9_hmac_lineage_backfill_and_token_hardening.sql` | `88.970 B` | `60df7ad7a6a40bac1a74944aea01ac85a64cb81c2be0f10527266676ffe86cc6` | **PRESERVADA BYTE A BYTE** |
| `20261123000017_missao02_10_rfc2104_hmac_sha256_csprng_and_key_lifecycle.sql` | `87.957 B` | `74d6ac43db9f2615565b6ef7a8480d9d99cd840caadeb0f62105918f7292af9e` | **NOVA MIGRATION `000017`** |

---

## SEÇÃO I — VERIFICAÇÃO DE LOCKFILE/BUILD (SEÇÃO 8) E PENDÊNCIAS EXTERNAS

1. **Verificação Estrita do Pipeline de Lockfile e Build (Seção 8):**
   - Confirmado em `scripts/verify_ci_build.sh` e `.github/workflows/homologation-and-build.yml`:
     - O CI exige a presença de `package-lock.json` válido (`ABORT_MISSING_LOCKFILE` caso ausente ou inválido);
     - O CI executa exclusivamente `npm ci --no-audit --no-fund`, `npx tsc --noEmit` e `npm run build`;
     - O CI **não** gera lockfile dinamicamente (bloqueia e falha se `package-lock-only` aparecer em scripts de CI);
     - O script de bootstrap local (`scripts/materialize_and_verify_build.sh`) está isolado do CI e aborta com `ABORT_CI_FORBIDDEN` se `CI=true` ou `GITHUB_ACTIONS=true`.
2. **Pendências Externas Documentadas:**
   - **`PENDENTE — Materialização física do package-lock.json e execução de npm ci / vite build em ambiente com rede`:** O build de produção **não** é declarado aprovado nesta missão porque o sandbox opera sem rede externa (`EAI_AGAIN`). Deve ser executado `bash scripts/materialize_and_verify_build.sh` em ambiente conectado antes do commit do lockfile.
   - **`PENDENTE — Homologação em PostgreSQL 15+ real`:** Conforme diretriz da Missão 02.10, a homologação PostgreSQL 15+ real (`bash supabase/tests/run_postgresql_homologation.sh --docker`) **não** foi iniciada nesta missão e permanece reservada para a etapa própria de homologação.
   - **Riscos Remanescentes:** Comprometimento direto da conta superusuário PostgreSQL (`postgres` / `supabase_admin`) no banco de produção permitiria acesso administrativo ao schema `internal_guard`; mitigado por controle de acesso de infraestrutura (MFA/IAM no Supabase), rotação periódica via `rotate_lineage_hmac_key()` e backup externo criptografado (KMS) do cofre.

---

## SEÇÃO J — DADOS DO PACOTE ZIP FINAL ENTREGUE

- **Nome do arquivo:** `ubatuba_mar_e_praias_missao02_10_corrigido.zip`
- **Pasta raiz única:** `ubatuba_mar_e_praias_marketplace/`
- **Quantidade de arquivos:** `68` (`66` da base `02.9` + migration `000017` + `RELATORIO_AUDITORIA_E_CORRECAO_MISSAO_02_10.md`)
- **Teste de integridade (`zipfile.testzip()`):** `None` (`0` erros — arquivo íntegro)
- *(Tamanho exato em bytes e hash SHA-256 de 64 caracteres do `.zip` final constam no cabeçalho e rodapé de verificação abaixo.)*

---

## SEÇÃO 11 — CLASSIFICAÇÃO FINAL

**APROVADO COM PENDÊNCIAS DOCUMENTADAS**
