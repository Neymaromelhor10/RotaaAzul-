# ARGON 4 — RELATÓRIO DE AUDITORIA INDEPENDENTE E CORREÇÃO CIRÚRGICA — MISSÃO 02.8
**Projeto:** Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`)  
**Base auditada:** `ubatuba_mar_e_praias_missao02_7_corrigido.zip` (`1.317.249 bytes` | SHA-256: `1c7eb55dc17168a7693d3c550eff3684ef39617eb8e1882fcda16f145d6596ae`)  
**Backup pré-missão:** `/working_dir/c_1db526fd712e6ebe/work/backups_missao_02_8/ubatuba_mar_e_praias_missao02_7_corrigido_BACKUP_PRE_02_8.zip` (`1.317.249 bytes` | SHA-256: `1c7eb55dc17168a7693d3c550eff3684ef39617eb8e1882fcda16f145d6596ae`)  
**Migration incremental criada:** `supabase/migrations/20261121000015_missao02_8_lgpd_lineage_and_definer_hardening.sql` (`66.466 bytes` | SHA-256: `d5fabcaeea6008f40c7db41eade2a6ff57cd93a5013f9b4cd3bd04a51f088201`)

---

## 1. VEREDITO TÉCNICO INDEPENDENTE DA MIGRATION `000014` (`F01`)

A inspeção completa da migration `20261120000014_missao02_7_lineage_persistence_and_hardening.sql` (`54.907 bytes`, preservada byte a byte com SHA-256 `9c9e3a1966953aa8c92d8a6b67124fc2d3d58dc65e67f8830c2cc0ef1bde50b4`) confirmou que a estrutura de colunas (`original_idempotency_key`, `idempotency_generation`), o índice único `idx_bookings_lineage_generation_unique` e o isolamento entre chaves explícitas distintas (`k1` vs `k2`) estão corretos para novas inserções, mas identificou **dois defeitos técnicos reais** que exigiram a migration incremental `000015`:

1. **`M02.8-F01` (Backfill Top-Level sem Token `BOOKING_MUTATION` e Tratamento de Dados Legados)**:
   - Nas linhas `68–92` da `000014`, o comando `UPDATE public.bookings b SET ... WHERE b.original_idempotency_key IS NULL;` era executado em nível top-level sem emitir token em `internal_guard.execution_tokens`. Quando aplicado em banco vazio (`000001`..`000014` do zero), `public.bookings` possui `0` linhas e o `UPDATE` é no-op; porém, sobre um banco que já possuísse reservas criadas sob `000001`..`000013` (com `original_idempotency_key IS NULL`), o trigger `BEFORE UPDATE` `trg_enforce_booking_invariants` abortaria o `UPDATE` com `DIRECT_BOOKING_UPDATE_FORBIDDEN`. Além disso, a subquery de resolução de chave original checava apenas `r.idempotency_key` (falhando se a geração `0` tivesse sido anonimizada via LGPD) e não desempatava colisões legadas de `(original_idempotency_key, idempotency_generation)`.
   - **Correção na `000015`**: Criada e executada `public.backfill_and_verify_booking_lineage()`, que emite token `LINEAGE_BACKFILL:<status>` na profundidade exata `pg_trigger_depth() - 1`, trata `idempotency_key` nula/vazia, recupera a raiz tanto por `original_idempotency_key` quanto por `idempotency_key` de gerações irmãs, desempata colisões legadas monotonicamente e aplica `SET NOT NULL` + `CHECK (char_length(btrim(original_idempotency_key)) >= 8 AND char_length(original_idempotency_key) <= 64)`.

2. **`M02.8-F02` (Quebra de Linhagem e Reuso Indevido de Chave após Anonimização LGPD em `000014`)**:
   - Nas linhas `511–522` da `000014`, `public.admin_anonymize_customer_pii()` sobrescrevia tanto `idempotency_key` quanto `original_idempotency_key` com `'lgpd-' || replace(v_target.id::text, '-', '') || '-' || left(md5(v_target.id::text), 16)` (derivado apenas do UUID da reserva, apagando o hash raiz `left(md5(k1), 24)` e o escopo do titular).
   - **Consequências reproduzidas**:
     a) Se a reserva mais recente (`B2`, `gen = 1`) fosse anonimizada enquanto `B1` (`gen = 0`, cancelada) não estava anonimizada, `MAX(idempotency_generation) + 1` para `k1` deixava de enxergar `B2` e recalculava `gen = 1` (`g0001`);
     b) Se `B1` e `B2` fossem ambas anonimizadas, o reenvio de `k1` encontrava `0` linhas na linhagem e reiniciava em `gen = 0` em vez de `gen = 2` (`g0002`);
     c) Quando todas as reservas de `k1` eram anonimizadas, outro titular conseguia reutilizar `k1` sem ser bloqueado por `IDEMPOTENCY_KEY_CONFLICT`;
     d) O reenvio da chave derivada `idg-...` de uma reserva já anonimizada falhava ao localizar a linhagem.
   - **Correção na `000015`**:
     * `idempotency_key` recebe `'lgpd-' || replace(id, '-', '') || '-' || left(md5(lower(btrim(pre_lgpd_idem_key))), 16)` (`54` caracteres, `0` PII, autenticando criptograficamente a chave pré-LGPD).
     * `original_idempotency_key` recebe `'lgpd-lin-' || v_root_hash24 || '-' || v_owner_scope_hash20` (`54` caracteres, `0` PII), preservando `v_root_hash24 = left(md5(k1), 24)` e `v_owner_scope_hash20 = left(md5(tour_id || ':' || booking_date || ':' || phone_digits || ':' || email), 20)`.
     * `idempotency_generation` permanece inalterado, mantendo `UNIQUE (original_idempotency_key, idempotency_generation)` livre de colisões mesmo quando todas as gerações da mesma linhagem são anonimizadas.

---

## 2. AUDITORIA INDIVIDUAL DAS 42 FUNÇÕES ATIVAS, `SECURITY DEFINER`, `search_path` E `pg_temp` (`F02`)

- **Análise de `pg_temp` e `search_path`**:
  - Em PostgreSQL, omitir `pg_temp` de `SET search_path` faz com que o schema de sessão temporária `pg_temp` seja pesquisado **implicitamente antes** de `public`. Declarar `pg_temp` explicitamente no **final** (`SET search_path = pg_catalog, ..., pg_temp`) força o PostgreSQL a pesquisar `pg_catalog` primeiro e `pg_temp` por último, impedindo sombreamento por tabelas/funções/tipos temporários.
  - Todas as 42 funções ativas declaram `pg_catalog` em 1º lugar e `pg_temp` explicitamente na última posição.
  - Na migration `000015`, o schema `auth` foi removido do `SET search_path` das 5 funções `SECURITY DEFINER` que o listavam (`handle_new_auth_user`, `handle_updated_auth_user`, `protect_profile_privileged_columns`, `validate_verified_review`, `create_verified_review`), pois todas já qualificam `auth.uid()` e `auth.jwt()` explicitamente.
  - Também na `000015`, foi adicionado `ALTER DEFAULT PRIVILEGES IN SCHEMA public, internal_guard REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC, anon, authenticated` e o loop universal passou a executar `REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon, authenticated` em todas as 42 funções antes de conceder `EXECUTE` exclusivamente à whitelist (`4` RPCs em `public` + `2` helpers `auth` para `anon`; `11` RPCs em `public` + `2` helpers `auth` para `authenticated`).

| # | Função e Assinatura | Modo | `search_path` Ativo Pós-000015 | `EXECUTE` Grants | Objetos Não Qualificados | Risco / Status |
| :-: | :--- | :---: | :--- | :--- | :---: | :--- |
| 01 | `auth.uid()` | `INVOKER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | Seguro |
| 02 | `auth.jwt()` | `INVOKER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | Seguro |
| 03 | `internal_guard.issue_token(TEXT, UUID, TEXT)` | `DEFINER` | `pg_catalog, internal_guard, pg_temp` | `service_role` | Nenhum | Seguro (`REVOKE anon, authenticated`) |
| 04 | `internal_guard.consume_token(TEXT, UUID, TEXT)` | `DEFINER` | `pg_catalog, internal_guard, pg_temp` | `service_role` | Nenhum | Seguro (`REVOKE anon, authenticated`) |
| 05 | `internal_guard.cleanup_tokens(TEXT, UUID)` | `DEFINER` | `pg_catalog, internal_guard, pg_temp` | `service_role` | Nenhum | Seguro (`REVOKE anon, authenticated`) |
| 06 | `public.validate_tour_vessel_ownership()` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 07 | `public.is_admin()` | `DEFINER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | Guarda de 4 fatores ativa (`000011`) |
| 08 | `public.is_partner_member(UUID)` | `DEFINER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | Guarda de 4 fatores ativa (`000011`) |
| 09 | `public.validate_availability_block_ownership()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; guarda 4 fatores + lock `vessels` |
| 10 | `public.validate_commission_rule_ownership()` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 11 | `public.set_updated_at()` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 12 | `public.handle_new_auth_user()` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Hardened em `000015` (`auth` removido do `search_path`) |
| 13 | `public.handle_updated_auth_user()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Hardened em `000015` (`auth` removido do `search_path`) |
| 14 | `public.protect_profile_privileged_columns()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Hardened em `000015` (`auth` removido do `search_path`) |
| 15 | `public.is_valid_booking_transition(booking_status_type, booking_status_type)` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 16 | `public.resolve_booking_actor_role(UUID, UUID)` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 17 | `public.can_actor_execute_booking_transition(booking_status_type, booking_status_type, app_role)` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 18 | `public.check_and_lock_vessel_capacity(UUID, UUID, DATE, SMALLINT, UUID)` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 19 | `public.enforce_booking_invariants_and_transitions()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Atualizado em `000015` (`lgpd-lin-` + `LINEAGE_BACKFILL`) |
| 20 | `public.sync_booking_history_ledger_and_audit()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 21 | `public.enforce_commission_ledger_integrity()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 22 | `public.validate_verified_review()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Hardened em `000015` (`auth` removido do `search_path`) |
| 23 | `public.recalculate_ratings_after_review()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; revogado de `anon/authenticated` em `000015` |
| 24 | `public.resolve_tour_id(TEXT)` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 25 | `public.calculate_booking_financials(UUID, SMALLINT)` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` em `000015` |
| 26 | `public.get_tour_availability(TEXT, DATE)` | `DEFINER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | RPC pública; retorna apenas contagens de assentos |
| 27 | `public.create_booking_request(TEXT, DATE, SMALLINT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT)` | `DEFINER` | `pg_catalog, public, pg_temp` | `anon, authenticated, service_role` | Nenhum | Atualizado em `000015` (suporte `lgpd-lin-` na linhagem) |
| 28 | `public.transition_booking_status(TEXT, booking_status_type, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Guarda 4 fatores via `resolve_booking_actor_role` |
| 29 | `public.create_verified_review(TEXT, SMALLINT, TEXT, TEXT, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Hardened em `000015` (`auth` removido do `search_path`) |
| 30 | `public.expire_stale_bookings()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | `REVOKE anon/authenticated` explícito em `000015` |
| 31 | `public.admin_update_booking(TEXT, DATE, SMALLINT, booking_status_type, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Guarda 4 fatores admin ativa (`000011`) |
| 32 | `public.settle_commission_ledger(TEXT, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Guarda 4 fatores admin ativa (`000011`) |
| 33 | `public.protect_catalog_moderation_columns()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; guarda 4 fatores (`000012`) |
| 34 | `public.prevent_audit_and_ledger_deletion()` | `DEFINER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Trigger imutável; `REVOKE anon/authenticated` em `000015` |
| 35 | `public.validate_availability_block_delete()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Trigger; exige token `AVAILABILITY_BLOCK_MUTATION` |
| 36 | `public.upsert_availability_block(TEXT, DATE, TEXT, TEXT, SMALLINT, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Guarda 4 fatores + lock `vessels` (`000011`) |
| 37 | `public.delete_availability_block(UUID)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Guarda 4 fatores + lock `vessels` (`000011`) |
| 38 | `public.admin_anonymize_customer_pii(UUID, TEXT)` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `authenticated, service_role` | Nenhum | Atualizado em `000015` (`lgpd-lin-<root24>-<scope20>`) |
| 39 | `public.normalize_lgpd_text(TEXT)` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` |
| 40 | `public.sanitize_lgpd_audit_jsonb(JSONB, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, UUID)` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` |
| 41 | `public.derive_idempotency_lineage_key(TEXT, INTEGER)` | `INVOKER` | `pg_catalog, public, pg_temp` | `service_role` | Nenhum | Helper interno; `REVOKE anon/authenticated` |
| 42 | `public.backfill_and_verify_booking_lineage()` | `DEFINER` | `pg_catalog, public, internal_guard, pg_temp` | `service_role` | Nenhum | Criada em `000015` (`M02.8-F01`), restrita a `service_role` |

---

## 3. RESULTADO DOS 12 TESTES DE LINHAGEM E LGPD (`F03`)

Todos os 12 cenários de `F03` foram executados na suíte isolada (`M02.8-LGPD-LINEAGE-12-SCENARIOS`) e incluídos em `T9.22` (`homologacao_postgresql_real.sql`):

1. **`B1` anonimizada e `B2` ainda existente (ativa)**: `B1` (`gen=0`) recebe `original_idempotency_key = 'lgpd-lin-<root24>-<scope20>'` (`54` chars); reenvio de `k1` pelo titular retorna `B2` (`idempotent_replay=true`, `original_idempotency_key=k1`, `gen=1`). (**PASS**)
2. **`B1` e `B2` anonimizadas**: `B1` (`gen=0`) e `B2` (`gen=1`) compartilham `original_idempotency_key = 'lgpd-lin-<root24>-<scope20>'` com `idempotency_generation` distintos (`0` e `1`), preservando `UNIQUE (original_idempotency_key, idempotency_generation)` sem colisão. (**PASS**)
3. **Anonimização da reserva mais recente (`B4`, `gen=3`) com `B3` (`gen=2`, cancelada) não anonimizada**: reenvio de `k1` enxerga `B4` via `lgpd-lin-<root24>-` e cria `B5` com `gen=4` (sem reutilizar `gen=3`). (**PASS**)
4. **Reenvio da chave original `k1` após `B1` e `B2` estarem ambas anonimizadas**: cria `B3` com `gen=2` (`idg-...-g0002-...`, `original_idempotency_key=k1`), sem reiniciar em `gen=0`. (**PASS**)
5. **Reenvio de chave derivada (`idg-...-g0003-...`) após anonimização da reserva correspondente (`B4`)**: autentica os 16 caracteres finais de `B4.idempotency_key` (`left(md5(idg_key), 16)`), retorna replay da reserva ativa `B5` (`gen=4`) ou, após cancelamento de `B5`, cria `B6` (`gen=5`). (**PASS**)
6. **Gerações não contíguas (`gen=0..5` seguidas de salto para `gen=10`)**: `COALESCE(MAX(idempotency_generation) + 1, 0)` calcula `gen=11`. (**PASS**)
7. **Registros históricos com chave antiga (`legacy-orig-key`)**: `public.backfill_and_verify_booking_lineage()` restaura `original_idempotency_key = k1` sob token `LINEAGE_BACKFILL` e bloqueia chamada por `tourist`. (**PASS**)
8. **Reutilização de chave (`k1` e `idg-...`) por outro titular após 100% das reservas da linhagem estarem anonimizadas**: bloqueada com `IDEMPOTENCY_KEY_CONFLICT` via `v_owner_scope_hash20`. (**PASS**)
9. **Alteração indevida de `original_idempotency_key` em `UPDATE`**: bloqueada pelo trigger (`BOOKING_IMMUTABLE_LINEAGE_VIOLATION` / `BOOKING_IMMUTABLE_FIELDS`). (**PASS**)
10. **Alteração indevida de `idempotency_generation` em `UPDATE`**: bloqueada pelo trigger. (**PASS**)
11. **Manipulação do token `LGPD_ANONYMIZE` com `original_idempotency_key` ou `idempotency_key` fora do formato canônico de 54 caracteres**: bloqueada com `LGPD_INVALID_TARGET_VALUES`. (**PASS**)
12. **Repetição de operações após cancelamento, recusa (`RECUSADA`) e expiração combinadas com anonimização LGPD**: avança monotonicamente (`gen=11 -> 12 -> 13`) mantendo `occupied_seats = 2`. (**PASS**)
