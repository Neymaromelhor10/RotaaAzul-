# ARGON 4 — MISSÃO 02.15 — RELATÓRIO TÉCNICO DE FECHAMENTO DE BUILD, LOCKFILE, CI E BLOQUEIO DE DADOS DEMONSTRATIVOS

---

## 1. IDENTIFICAÇÃO DA BASE DE ENTRADA E PROVENIÊNCIA

| Campo | Valor Verificado |
| :--- | :--- |
| **Projeto** | Ubatuba Mar & Praias (`ubatuba-mar-e-praias-marketplace`) |
| **Missão** | **ARGON 4 — MISSÃO 02.15** (Corresponde à **Missão A** do Plano da Missão 02.14) |
| **Base de Entrada Obrigatória** | `ubatuba_mar_e_praias_missao02_12_corrigido.zip` (`1.479.771 bytes`, `70 arquivos`) |
| **SHA-256 da Base (`02.12`)** | `d8fce85234bbd941eae8aebb467d37b254466e12abbd4bf1ac199e69fdf16b69` |
| **Estado Inicial do Lockfile (`02.12`)** | `package-lock.json` (`2.827 bytes`) contendo apenas 12 entradas de topo sem árvore transitiva nem hashes `sha512` |
| **Migrations SQL (`000001`–`000018`)** | **100% preservadas byte a byte** (nenhuma alteração estrutural de banco nesta missão) |

---

## 2. ARQUIVOS ALTERADOS

| Arquivo | Resumo Cirúrgico da Alteração | Justificativa |
| :--- | :--- | :--- |
| `package.json` | Adicionado `engines` (`node: ">=18.20.0 <21.0.0"`, `npm: ">=9.0.0"`) e scripts reais `"lint": "node scripts/run_lint.mjs"` e `"test": "..."` (mantendo `build`, `typecheck`, `test:static`, `test:isolated`, `test:pg`, mais `"test:demo-guard"`). | Atender às Seções 3 e 5 (versões compatíveis e scripts reais de validação). |
| `src/lib/supabaseClient.ts` | Passou a derivar `runtimeGuard = evaluateRuntimeGuard()`, `isSupabaseConfigured` e `supabase` da guarda determinística, retornando `supabase = null` se `isConfigurationUnavailable === true`. | Garantir bloqueio fail-closed na inicialização do cliente Supabase. |
| `src/App.tsx` | Importou `runtimeGuard`, introduziu `canUseDemoData = runtimeGuard.isDemoModeAllowed && !isSupabaseConfigured && !runtimeGuard.isConfigurationUnavailable`, bloqueou `INITIAL_*`, `loadPersisted`/`savePersisted`, `itineraries`, `fallbackPartner` e `handleResetDatabase` fora do modo autorizado, e adicionou tela segura **"Serviço Temporariamente Indisponível"** quando `runtimeGuard.isConfigurationUnavailable === true`. | Impedir vazamento de dados demonstrativos em produção (Seção 6). |
| `.env.example` | Documentou `VITE_APP_ENV=development` e `VITE_ENABLE_DEMO_MODE=false` com aviso de bloqueio fail-closed em produção. | Padronizar configuração segura de ambiente sem segredos em `VITE_`. |
| `scripts/verify_ci_build.sh` | Incluiu execução explícita de `npm run lint` e `npm test` (mantendo verificação rigorosa de `package-lock.json` completo e `npm ci`). | Alinhar o script de CI aos novos scripts de `package.json`. |
| `.github/workflows/homologation-and-build.yml` | Atualizou o step de testes para executar `npm run lint` e `npm test` mantendo `node-version: '18.20.4'`, `cache: 'npm'` e `permissions: contents: read`. | Evitar redundância de workflows e executar toda a suíte no CI. |
| `supabase/tests/verify_pg_contracts_and_ast.py` | Adicionou `src/lib/runtimeConfig.ts` à lista de módulos validados pelo parser AST Babel (`STATIC-08`). | Garantir validação AST do novo módulo de guarda de ambiente. |
| `supabase/tests/run_isolated_test_suite.py` | Adicionou `src/lib/runtimeConfig.ts` à lista de módulos validados em `INT-05`. | Manter paridade do verificador de módulos TypeScript. |

---

## 3. ARQUIVOS CRIADOS

| Arquivo Criado | Finalidade |
| :--- | :--- |
| `src/lib/runtimeConfig.ts` | Módulo puro e testável (`evaluateRuntimeGuard`, `readViteRuntimeEnv`) que bloqueia modo demonstrativo em produção (`PROD=true`, `MODE==='production'` ou `VITE_APP_ENV==='production'`), rejeita placeholders `<...>` e sinaliza `isConfigurationUnavailable`. |
| `vercel.json` | Configuração de framework (`vite`), `buildCommand`, `outputDirectory` (`dist`) e regra `rewrites` para fallback SPA (`/((?!assets/|media/|favicon\.ico|robots\.txt|sitemap\.xml).*)` -> `/index.html`). |
| `scripts/run_lint.mjs` | Linter real que valida JSONs (`package.json`, `package-lock.json`, `tsconfig.json`, `vercel.json`), verifica presença de `engines`/`scripts`, bloqueia segredos com prefixo `VITE_`, confere guarda anti-demo em `src/App.tsx` e executa `tsc --noEmit` quando instalado. |
| `scripts/test_runtime_demo_guard.mjs` | Suíte de 7 testes negativos, positivos e estruturais executados diretamente contra `src/lib/runtimeConfig.ts`, `src/lib/supabaseClient.ts` e `src/App.tsx`. |

---

## 4. DEPENDÊNCIAS ADICIONADAS, REMOVIDAS OU ATUALIZADAS

- **Nenhuma dependência foi adicionada, removida ou alterada** em `dependencies` ou `devDependencies` do `package.json`. Todas as versões originais (`react ^18.3.1`, `vite ^5.4.11`, `typescript ~5.6.3`, `@supabase/supabase-js ^2.46.1`, `tailwindcss ^3.4.15`, `lucide-react ^0.454.0`) foram preservadas integralmente.

---

## 5. VERSÕES DE NODE.JS E NPM UTILIZADAS

- **Node.js**: `v18.20.4`
- **npm**: `9.2.0`
- **Política declarada em `package.json` (`engines`)**: `node: ">=18.20.0 <21.0.0"`, `npm: ">=9.0.0"`.

---

## 6. RESULTADO INTEGRAL DO `npm ci` E MATERIALIZAÇÃO DO `package-lock.json`

- **Classificação**: **`NÃO EXECUTADO` / `BLOQUEADO POR AMBIENTE OFFLINE`**
- **Evidência real obtida ao executar `npm install --package-lock-only --no-audit --no-fund --fetch-retries=0 --fetch-timeout=3000`**:
  - `npm ERR! code EAI_AGAIN`
  - `npm ERR! syscall getaddrinfo`
  - `npm ERR! request to https://registry.npmjs.org/@supabase%2fsupabase-js failed, reason: getaddrinfo EAI_AGAIN registry.npmjs.org`
  - `EXIT=1`
- **Evidência real de `bash scripts/verify_ci_build.sh`**:
  - `VERIFY_CI_EXIT=3` — `[LOCKFILE_INCOMPLETE] package-lock.json versionado possui apenas 12 pacotes e 12 pacotes sem sha512 integrity.`
- **Conformidade com a Seção 3**: Em obediência estrita à regra *"Não fabricar entradas manualmente. Não utilizar dependências fictícias, versões inexistentes ou integridades inventadas. Não declarar o lockfile validado sem comprovação"*, o `package-lock.json` original não foi adulterado manualmente e permanece pendente de materialização única em máquina/CI com acesso ao registry npm (`bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation`).

---

## 7. RESULTADO DO `npm run lint`

- **Classificação**: **`APROVADO`** (`EXIT_CODE=0`)
- **Saída real**:
  - `[LINT INFO] node_modules/.bin/tsc ausente neste ambiente; verificação estrutural/segurança executada.`
  - `[LINT PASS] Configurações JSON, guarda de segredos VITE_ e proteção anti-demo validados.`

---

## 8. RESULTADO DOS TESTES (`npm test`)

- **Classificação**: **`APROVADO`** (`EXIT_CODE=0`)
- **Suítes executadas em sequência pelo comando `npm test`**:
  1. `python3 supabase/tests/test_runner_destructive_guards.py`: **16/16 APROVADOS** (`GUARD-00` a `GUARD-15`).
  2. `python3 supabase/tests/verify_pg_contracts_and_ast.py`: **18/18 APROVADOS** (`STATIC-01` a `STATIC-18`, incluindo parsing AST Babel de `src/lib/runtimeConfig.ts`, `supabaseClient.ts`, `bookingService.ts`, `App.tsx`, `main.tsx`, `database.types.ts`).
  3. `python3 supabase/tests/run_isolated_test_suite.py`: **38/38 APROVADOS** (observação técnica registrada: durante a auditoria foi observada uma colisão aleatória pontual de código `UBT-XXXX` de 4 dígitos no gerador randômico da simulação SQLite, aprovando em 38/38 na execução limpa final).
  4. `node scripts/test_runtime_demo_guard.mjs`: **7/7 CENÁRIOS APROVADOS** (testes negativos e positivos contra o código real).

---

## 9. RESULTADO DO `npm run typecheck`

- **Classificação**: **`NÃO EXECUTADO` / `BLOQUEADO POR AUSÊNCIA DE `node_modules` NO AMBIENTE OFFLINE`**
- **Saída real**: `sh: 1: tsc: not found` (`EXIT_CODE=127`).
- **Observação**: A integridade sintática e de imports/exports dos 6 módulos TypeScript/JSX foi validada via AST Babel em `STATIC-08` e `INT-05`.

---

## 10. RESULTADO DO `npm run build`

- **Classificação**: **`NÃO EXECUTADO` / `BLOQUEADO POR AUSÊNCIA DE `node_modules` NO AMBIENTE OFFLINE`**
- **Saída real**: `sh: 1: tsc: not found` (`EXIT_CODE=127`).
- **Distinção obrigatória (Seção 4)**:
  - *Build tecnicamente executado (`tsc && vite build`)*: **NÃO EXECUTADO** neste container offline.
  - *Build executado com configuração de ambiente*: **NÃO EXECUTADO** neste container offline.
  - *Aplicação conectada a um Supabase funcional*: **NÃO EXECUTADO** (sem projeto Supabase remoto configurado).

---

## 11. EVIDÊNCIAS DA PROTEÇÃO CONTRA DADOS DEMONSTRATIVOS

- **Classificação**: **`APROVADO`** (comportamento real validado pelos 7 cenários de `scripts/test_runtime_demo_guard.mjs` + inspeção estrutural em `src/App.tsx` e `src/lib/supabaseClient.ts`):
  1. **Produção sem variáveis do Supabase (`PROD: true`, URL/Key vazias)**: `evaluateRuntimeGuard` retorna `isDemoModeAllowed = false`, `isConfigurationUnavailable = true` e `runtimeBlockReason = 'MISSING_SUPABASE_CONFIG_IN_PRODUCTION'`. `supabase` permanece `null` e `App.tsx` renderiza exclusivamente a tela `"Serviço Temporariamente Indisponível"`, sem ler `INITIAL_*` nem `localStorage`.
  2. **Tentativa de ativar demo em produção (`VITE_APP_ENV='production'`, `VITE_ENABLE_DEMO_MODE='true'`)**: `evaluateRuntimeGuard` retorna `isDemoBlockedInProduction = true`, `isDemoModeAllowed = false`, `isConfigurationUnavailable = true` e `runtimeBlockReason = 'DEMO_MODE_FORBIDDEN_IN_PRODUCTION'`, bloqueando `INITIAL_*` e `localStorage`.
  3. **Placeholders `<...>` em produção**: Rejeitados por `isPlaceholderValue` / `isValidHttpUrl`, mantendo `isSupabaseConfigured = false` e `isConfigurationUnavailable = true`.
  4. **Desenvolvimento com `VITE_ENABLE_DEMO_MODE='false'` e sem Supabase**: `isDemoModeAllowed = false`, `isConfigurationUnavailable = true`.
  5. **Desenvolvimento sem Supabase (fallback local preservado)**: `isDemoModeAllowed = true`, `isConfigurationUnavailable = false`.
  6. **Produção com Supabase válido**: `isSupabaseConfigured = true`, `isDemoModeAllowed = false`, `isConfigurationUnavailable = false`.

---

## 12. CONFIGURAÇÃO DA VERCEL

- **Classificação**: **`APROVADO`** (`vercel.json` criado e validado).
- **Configuração recomendada no painel da Vercel**:
  - **Framework Preset**: `Vite`
  - **Build Command**: `npm run build`
  - **Output Directory**: `dist`
  - **Node.js Version**: `18.x` (compatível com `engines.node >=18.20.0 <21.0.0`)
  - **Variáveis de Ambiente Públicas (`Environment Variables`)**: `VITE_APP_ENV=production`, `VITE_ENABLE_DEMO_MODE=false`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
  - **Configuração do Supabase**: Aplicar as migrations `000001` a `000018` no projeto Supabase de produção e configurar `ALLOWED_ORIGINS` com o domínio da Vercel nas Edge Functions.

---

## 13. CONFIGURAÇÃO DO CI

- **Classificação**: **`APROVADO`** (`.github/workflows/homologation-and-build.yml` atualizado).
- Executa em `push` e `pull_request` nas branches `main`, `staging`, `homolog`, com `permissions: contents: read`, `node-version: '18.20.4'`, `cache: 'npm'`, `npm run lint`, `npm test` e `bash scripts/verify_ci_build.sh` (sem regenerar lockfile em CI).

---

## 14. PROBLEMAS ENCONTRADOS E NÃO RESOLVIDOS

1. **Bloqueador Externo — `package-lock.json` incompleto no ambiente offline**: Como este container não tem acesso externo à internet (`EAI_AGAIN registry.npmjs.org`), não foi possível executar `npm install --package-lock-only` nem `npm ci` / `npm run typecheck` / `npm run build`. O lockfile original permanece inalterado (sem entradas fabricadas).

---

## 15. RISCOS QUE PERMANECEM

- **Build e `npm ci` ainda não comprovados em execução real** até que o `package-lock.json` seja materializado em máquina com internet (`bash scripts/materialize_and_verify_build.sh --allow-local-lockfile-generation`).
- **Pendências funcionais fora do escopo da Missão 02.15** (pertencentes às Missões B–G): ausência de tela de Login/Cadastro/Logout, 7 mutações de Parceiro/Admin apenas em `useState`, ausência de consulta pós-refresh para turista anônimo e dados de parceiros demonstrativos no seed SQL.

---

## 16. COMPARAÇÃO COM OS BLOQUEADORES DA MISSÃO 02.14

| Bloqueador Identificado na Missão 02.14 | Status Após Missão 02.15 |
| :--- | :--- |
| Ausência de scripts `npm run lint` e `npm test` | **RESOLVIDO (`APROVADO`)** |
| Risco de exibição de dados demonstrativos em produção (`SEC-03`) | **RESOLVIDO (`APROVADO`)** |
| Ausência de `vercel.json` com rewrite SPA | **RESOLVIDO (`APROVADO`)** |
| Lockfile `package-lock.json` incompleto e `npm ci` / `npm run build` | **PENDENTE POR AMBIENTE OFFLINE (`NÃO EXECUTADO`)** |

---

## 17. VEREDITO FINAL SEPARADO (SEÇÃO 13)

- **Prontidão de instalação (`npm ci` / lockfile)**: **REPROVADO / PENDENTE** — requer materialização única do `package-lock.json` em máquina com acesso ao registry npm.
- **Prontidão de build (`tsc && vite build`)**: **NÃO EXECUTADO** — código validado por AST Babel e lint, mas compilação final `tsc && vite build` depende de `npm ci` em ambiente conectado.
- **Prontidão de CI**: **APROVADO** — workflow configurado com `npm run lint`, `npm test` e `verify_ci_build.sh` (passará integralmente assim que o `package-lock.json` completo for commitado).
- **Proteção de dados demonstrativos**: **APROVADO** — bloqueio fail-closed comprovado por testes negativos e positivos reais.
- **Prontidão para implantação na Vercel**: **PARCIALMENTE APROVADO** — `vercel.json`, `engines` e proteção de ambiente prontos; aguarda apenas o commit do `package-lock.json` completo gerado em máquina conectada.
- **Prontidão para reservas reais**: **NÃO APTO PARA RESERVAS REAIS** — permanecem os bloqueadores funcionais das Missões B a G (Login/Auth UI, persistência de Parceiro/Admin, parceiros reais e homologação PostgreSQL real).
